#include "generated.hpp"
void sub_8080E1_E0M1X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8080E1u: goto L_8080E1;
    case 0x8080E5u: goto L_8080E5;
    case 0x8080E9u: goto L_8080E9;
    case 0x8080EDu: goto L_8080ED;
    case 0x8080EFu: goto L_8080EF;
    case 0x8080F1u: goto L_8080F1;
    case 0x8080F2u: goto L_8080F2;
    case 0x8080F3u: goto L_8080F3;
    case 0x8080F4u: goto L_8080F4;
    case 0x8080F5u: goto L_8080F5;
    case 0x8080F6u: goto L_8080F6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8080E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E1u, 8u, 4u, 0x808ADEu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080E1 JSL -> $808ADE stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80E4u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80E5u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808ADEu, 0x8080E1u); }
    goto L_8080E5;
L_8080E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E5u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80E5u,0x8080E5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E5u, 8u, 4u, 0x80A724u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080E5 JSL -> $80A724 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80E8u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80E9u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A724u, 0x8080E5u); }
    goto L_8080E9;
L_8080E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E9u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80E9u,0x8080E9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E9u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E9u, 8u, 4u, 0x808BEAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080E9 JSL -> $808BEA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80ECu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80EDu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808BEAu, 0x8080E9u); }
    goto L_8080ED;
L_8080ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80EDu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80EDu,0x8080EDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80EDu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80EDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080ED STZ
    hw.write(cpu.address("dp", 0x4Au), 0, cpu.m8?8:16);
    goto L_8080EF;
L_8080EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80EFu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80EFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080EF REP
    cpu.rep(0x20u);
    goto L_8080F1;
L_8080F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F1u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8080F1 PLB
    cpu.pop("PLB", hw);
    goto L_8080F2;
L_8080F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F2u,cpu,0x2Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F2u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8080F2 PLD
    cpu.pop("PLD", hw);
    goto L_8080F3;
L_8080F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F3u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F3u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8080F3 PLY
    cpu.pop("PLY", hw);
    goto L_8080F4;
L_8080F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F4u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F4u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8080F4 PLX
    cpu.pop("PLX", hw);
    goto L_8080F5;
L_8080F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F5u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F5u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8080F5 PLA
    cpu.pop("PLA", hw);
    goto L_8080F6;
L_8080F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F6u,cpu,0x40u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F6u, 7u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $8080F6 RTI stack real
    {auto dst=cpu.returnInterrupt(hw);hw.requestDispatch(dst,0x8080F6u);return;}
}

void sub_8080E1_E0M1X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8080E1u: goto L_8080E1;
    case 0x8080E5u: goto L_8080E5;
    case 0x8080E9u: goto L_8080E9;
    case 0x8080EDu: goto L_8080ED;
    case 0x8080EFu: goto L_8080EF;
    case 0x8080F1u: goto L_8080F1;
    case 0x8080F2u: goto L_8080F2;
    case 0x8080F3u: goto L_8080F3;
    case 0x8080F4u: goto L_8080F4;
    case 0x8080F5u: goto L_8080F5;
    case 0x8080F6u: goto L_8080F6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8080E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E1u, 8u, 4u, 0x808ADEu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080E1 JSL -> $808ADE stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80E4u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80E5u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808ADEu, 0x8080E1u); }
    goto L_8080E5;
L_8080E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E5u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80E5u,0x8080E5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E5u, 8u, 4u, 0x80A724u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080E5 JSL -> $80A724 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80E8u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80E9u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A724u, 0x8080E5u); }
    goto L_8080E9;
L_8080E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E9u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80E9u,0x8080E9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E9u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E9u, 8u, 4u, 0x808BEAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080E9 JSL -> $808BEA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80ECu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80EDu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808BEAu, 0x8080E9u); }
    goto L_8080ED;
L_8080ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80EDu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80EDu,0x8080EDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80EDu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80EDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080ED STZ
    hw.write(cpu.address("dp", 0x4Au), 0, cpu.m8?8:16);
    goto L_8080EF;
L_8080EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80EFu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80EFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080EF REP
    cpu.rep(0x20u);
    goto L_8080F1;
L_8080F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F1u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8080F1 PLB
    cpu.pop("PLB", hw);
    goto L_8080F2;
L_8080F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F2u,cpu,0x2Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F2u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8080F2 PLD
    cpu.pop("PLD", hw);
    goto L_8080F3;
L_8080F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F3u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F3u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8080F3 PLY
    cpu.pop("PLY", hw);
    goto L_8080F4;
L_8080F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F4u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F4u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8080F4 PLX
    cpu.pop("PLX", hw);
    goto L_8080F5;
L_8080F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F5u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F5u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8080F5 PLA
    cpu.pop("PLA", hw);
    goto L_8080F6;
L_8080F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F6u,cpu,0x40u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F6u, 7u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $8080F6 RTI stack real
    {auto dst=cpu.returnInterrupt(hw);hw.requestDispatch(dst,0x8080F6u);return;}
}

void sub_8080E1_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8080E1u: goto L_8080E1;
    case 0x8080E5u: goto L_8080E5;
    case 0x8080E9u: goto L_8080E9;
    case 0x8080EDu: goto L_8080ED;
    case 0x8080EFu: goto L_8080EF;
    case 0x8080F1u: goto L_8080F1;
    case 0x8080F2u: goto L_8080F2;
    case 0x8080F3u: goto L_8080F3;
    case 0x8080F4u: goto L_8080F4;
    case 0x8080F5u: goto L_8080F5;
    case 0x8080F6u: goto L_8080F6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8080E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E1u, 8u, 4u, 0x808ADEu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080E1 JSL -> $808ADE stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80E4u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80E5u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808ADEu, 0x8080E1u); }
    goto L_8080E5;
L_8080E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E5u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80E5u,0x8080E5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E5u, 8u, 4u, 0x80A724u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080E5 JSL -> $80A724 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80E8u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80E9u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A724u, 0x8080E5u); }
    goto L_8080E9;
L_8080E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E9u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80E9u,0x8080E9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E9u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E9u, 8u, 4u, 0x808BEAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080E9 JSL -> $808BEA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80ECu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80EDu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808BEAu, 0x8080E9u); }
    goto L_8080ED;
L_8080ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80EDu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80EDu,0x8080EDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80EDu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80EDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080ED STZ
    hw.write(cpu.address("dp", 0x4Au), 0, cpu.m8?8:16);
    goto L_8080EF;
L_8080EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80EFu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80EFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080EF REP
    cpu.rep(0x20u);
    goto L_8080F1;
L_8080F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F1u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8080F1 PLB
    cpu.pop("PLB", hw);
    goto L_8080F2;
L_8080F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F2u,cpu,0x2Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F2u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8080F2 PLD
    cpu.pop("PLD", hw);
    goto L_8080F3;
L_8080F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F3u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F3u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8080F3 PLY
    cpu.pop("PLY", hw);
    goto L_8080F4;
L_8080F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F4u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F4u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8080F4 PLX
    cpu.pop("PLX", hw);
    goto L_8080F5;
L_8080F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F5u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F5u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8080F5 PLA
    cpu.pop("PLA", hw);
    goto L_8080F6;
L_8080F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F6u,cpu,0x40u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F6u, 7u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $8080F6 RTI stack real
    {auto dst=cpu.returnInterrupt(hw);hw.requestDispatch(dst,0x8080F6u);return;}
}

void sub_808433_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808433u: goto L_808433;
    case 0x808436u: goto L_808436;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808433:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8433u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8433u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8433u, 5u + 1u, 3u, cpu.address("absy", 0x9F80u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808433 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x9F80u), cpu.m8?8:16));
    goto L_808436;
L_808436:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8436u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8436u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8436u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808436 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808436u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808436u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80846E_E0M0X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80842Au: goto L_80842A;
    case 0x80846Eu: goto L_80846E;
    case 0x808470u: goto L_808470;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80842A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x842Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x842Au,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x842Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80842A RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80842Au);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80842Au,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80846E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x846Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Eu,cpu,0xB3u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Eu, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0x84u) & 0xFFFFu), 2u, 0u);
    // $80846E LDA
    cpu.loadA(hw.readW(cpu.addressStackIndirectY(hw, 0x84u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808470;
L_808470:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8470u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8470u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8470u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808470 BRA -> $80842A
    goto L_80842A;
}

void sub_8084B9_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8084B9u: goto L_8084B9;
    case 0x8084BBu: goto L_8084BB;
    case 0x8084BDu: goto L_8084BD;
    case 0x8084C1u: goto L_8084C1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8084B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8084B9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8084BB;
L_8084BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BBu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8084BB STY
    hw.write(cpu.address("dp", 0x6Bu), cpu.y, cpu.x8?8:16);
    goto L_8084BD;
L_8084BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BDu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BDu, 8u, 4u, 0x84C5D6u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8084BD JSL -> $84C5D6 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x84C0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x84C1u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84C5D6u, 0x8084BDu); }
    goto L_8084C1;
L_8084C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84C1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84C1u,0x8084C1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C1u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8084C1 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8084C1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8084C1u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8084C5_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808459u: goto L_808459;
    case 0x80845Bu: goto L_80845B;
    case 0x80845Cu: goto L_80845C;
    case 0x80845Eu: goto L_80845E;
    case 0x808462u: goto L_808462;
    case 0x808463u: goto L_808463;
    case 0x808465u: goto L_808465;
    case 0x808469u: goto L_808469;
    case 0x80846Au: goto L_80846A;
    case 0x80846Bu: goto L_80846B;
    case 0x8084C5u: goto L_8084C5;
    case 0x8084C7u: goto L_8084C7;
    case 0x80A6C6u: goto L_80A6C6;
    case 0x80A735u: goto L_80A735;
    case 0x80A737u: goto L_80A737;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808459:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8459u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8459u,cpu,0x01u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8459u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xAAu + cpu.x) & 0xFFFFu), 2u, 0u);
    // $808459 ORA
    cpu.logicOr(hw.readW(cpu.addressDpIndirectX(hw, 0xAAu), cpu.m8?8:16));
    goto L_80845B;
L_80845B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x845Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x845Bu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x845Bu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80845B PLA
    cpu.pop("PLA", hw);
    goto L_80845C;
L_80845C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x845Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x845Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x845Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80845C SEP
    cpu.sep(0x20u);
    goto L_80845E;
L_80845E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x845Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x845Eu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x845Eu, 5u, 4u, ((0x808470u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80845E LDA
    cpu.loadA(hw.readW(((0x808470u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808462;
L_808462:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8462u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8462u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8462u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808462 PHA
    cpu.push("PHA", hw);
    goto L_808463;
L_808463:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8463u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8463u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8463u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808463 REP
    cpu.rep(0x20u);
    goto L_808465;
L_808465:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8465u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8465u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8465u, 6u, 4u, ((0x80846Eu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808465 LDA
    cpu.loadA(hw.readW(((0x80846Eu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808469;
L_808469:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8469u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8469u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8469u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808469 DEC
    cpu.decReg('A');
    goto L_80846A;
L_80846A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x846Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Au,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80846A PHA
    cpu.push("PHA", hw);
    goto L_80846B;
L_80846B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x846Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Bu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80846B RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80846Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80846Bu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_8084C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C5u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8084C5 BMI -> $808459
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_808459; }
    goto L_8084C7;
L_8084C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84C7u,cpu,0x82u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84C7u, 4u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8084C7 BRL -> $80A735
    goto L_80A735;
L_80A6C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C6u,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C6u, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $80A6C6 BRK
    hw.partial(0x80A6C6u, "BRK"); return;
L_80A735:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA735u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA735u,cpu,0x07u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA735u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xA9u) & 0xFFFFu), 3u, 0u);
    // $80A735 ORA
    cpu.logicOr(hw.readW(cpu.addressDpLong(hw, 0xA9u), cpu.m8?8:16));
    goto L_80A737;
L_80A737:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA737u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA737u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA737u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A737 BRA -> $80A6C6
    goto L_80A6C6;
}

void sub_80858D_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80858Du: goto L_80858D;
    case 0x80858Eu: goto L_80858E;
    case 0x808591u: goto L_808591;
    case 0x808593u: goto L_808593;
    case 0x808596u: goto L_808596;
    case 0x808599u: goto L_808599;
    case 0x80859Au: goto L_80859A;
    case 0x80859Du: goto L_80859D;
    case 0x8085A0u: goto L_8085A0;
    case 0x8085A3u: goto L_8085A3;
    case 0x8085A4u: goto L_8085A4;
    case 0x8085A7u: goto L_8085A7;
    case 0x8085A8u: goto L_8085A8;
    case 0x8085A9u: goto L_8085A9;
    case 0x8085ABu: goto L_8085AB;
    case 0x8085ACu: goto L_8085AC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80858D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x858Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x858Du,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x858Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80858D PHP
    cpu.push("PHP", hw);
    goto L_80858E;
L_80858E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x858Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x858Eu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x858Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80858E LDY
    cpu.setY(0x2u, 16);
    goto L_808591;
L_808591:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8591u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8591u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8591u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808591 REP
    cpu.rep(0x20u);
    goto L_808593;
L_808593:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8593u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8593u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8593u, 5u + 1u, 3u, cpu.address("absy", 0x4218u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808593 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4218u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808596;
L_808596:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8596u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8596u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8596u, 6u, 3u, cpu.address("absy", 0x009Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808596 STA
    hw.write(cpu.address("absy", 0x9Cu), cpu.a, cpu.m8?8:16);
    goto L_808599;
L_808599:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8599u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8599u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8599u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808599 PHA
    cpu.push("PHA", hw);
    goto L_80859A;
L_80859A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x859Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x859Au,cpu,0x59u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x859Au, 5u + 1u, 3u, cpu.address("absy", 0x00A4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80859A EOR
    cpu.logicXor(hw.readW(cpu.address("absy", 0xA4u), cpu.m8?8:16));
    goto L_80859D;
L_80859D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x859Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x859Du,cpu,0x39u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x859Du, 5u + 1u, 3u, cpu.address("absy", 0x009Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80859D AND
    cpu.logicAnd(hw.readW(cpu.address("absy", 0x9Cu), cpu.m8?8:16));
    goto L_8085A0;
L_8085A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85A0u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85A0u, 6u, 3u, cpu.address("absy", 0x00A0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085A0 STA
    hw.write(cpu.address("absy", 0xA0u), cpu.a, cpu.m8?8:16);
    goto L_8085A3;
L_8085A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85A3u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85A3u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8085A3 PLA
    cpu.pop("PLA", hw);
    goto L_8085A4;
L_8085A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85A4u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85A4u, 6u, 3u, cpu.address("absy", 0x00A4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085A4 STA
    hw.write(cpu.address("absy", 0xA4u), cpu.a, cpu.m8?8:16);
    goto L_8085A7;
L_8085A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85A7u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085A7 DEY
    cpu.decReg('Y');
    goto L_8085A8;
L_8085A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85A8u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85A8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085A8 DEY
    cpu.decReg('Y');
    goto L_8085A9;
L_8085A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85A9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85A9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085A9 BEQ -> $808593
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_808593; }
    goto L_8085AB;
L_8085AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85ABu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85ABu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8085AB PLP
    cpu.pop("PLP", hw);
    goto L_8085AC;
L_8085AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85ACu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85ACu,0x8085ACu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85ACu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85ACu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8085AC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8085ACu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8085ACu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8085AD_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8085ADu: goto L_8085AD;
    case 0x8085AFu: goto L_8085AF;
    case 0x8085B2u: goto L_8085B2;
    case 0x8085B4u: goto L_8085B4;
    case 0x8085B7u: goto L_8085B7;
    case 0x8085B9u: goto L_8085B9;
    case 0x8085BCu: goto L_8085BC;
    case 0x8085BEu: goto L_8085BE;
    case 0x8085C1u: goto L_8085C1;
    case 0x8085C3u: goto L_8085C3;
    case 0x8085C6u: goto L_8085C6;
    case 0x8085C8u: goto L_8085C8;
    case 0x8085CBu: goto L_8085CB;
    case 0x8085CDu: goto L_8085CD;
    case 0x8085D0u: goto L_8085D0;
    case 0x8085D2u: goto L_8085D2;
    case 0x8085D5u: goto L_8085D5;
    case 0x8085D7u: goto L_8085D7;
    case 0x8085DAu: goto L_8085DA;
    case 0x8085DCu: goto L_8085DC;
    case 0x8085DFu: goto L_8085DF;
    case 0x8085E1u: goto L_8085E1;
    case 0x8085E4u: goto L_8085E4;
    case 0x8085E6u: goto L_8085E6;
    case 0x8085E9u: goto L_8085E9;
    case 0x8085EBu: goto L_8085EB;
    case 0x8085EEu: goto L_8085EE;
    case 0x8085F0u: goto L_8085F0;
    case 0x8085F3u: goto L_8085F3;
    case 0x8085F5u: goto L_8085F5;
    case 0x8085F8u: goto L_8085F8;
    case 0x8085FAu: goto L_8085FA;
    case 0x8085FDu: goto L_8085FD;
    case 0x808600u: goto L_808600;
    case 0x808603u: goto L_808603;
    case 0x808606u: goto L_808606;
    case 0x808609u: goto L_808609;
    case 0x80860Cu: goto L_80860C;
    case 0x80860Fu: goto L_80860F;
    case 0x808612u: goto L_808612;
    case 0x808615u: goto L_808615;
    case 0x808618u: goto L_808618;
    case 0x80861Bu: goto L_80861B;
    case 0x80861Eu: goto L_80861E;
    case 0x808621u: goto L_808621;
    case 0x808624u: goto L_808624;
    case 0x808627u: goto L_808627;
    case 0x80862Au: goto L_80862A;
    case 0x80862Du: goto L_80862D;
    case 0x808630u: goto L_808630;
    case 0x808633u: goto L_808633;
    case 0x808636u: goto L_808636;
    case 0x808639u: goto L_808639;
    case 0x80863Cu: goto L_80863C;
    case 0x80863Fu: goto L_80863F;
    case 0x808642u: goto L_808642;
    case 0x808645u: goto L_808645;
    case 0x808647u: goto L_808647;
    case 0x80864Au: goto L_80864A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8085AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85ADu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85ADu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085AD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085AF;
L_8085AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85AFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85AFu, 5u, 3u, cpu.address("abs", 0x210Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085AF STA
    hw.write(cpu.address("abs", 0x210Du), cpu.a, cpu.m8?8:16);
    goto L_8085B2;
L_8085B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85B2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85B2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085B2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085B4;
L_8085B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85B4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85B4u, 5u, 3u, cpu.address("abs", 0x210Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085B4 STA
    hw.write(cpu.address("abs", 0x210Du), cpu.a, cpu.m8?8:16);
    goto L_8085B7;
L_8085B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85B7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85B7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085B7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x80u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085B9;
L_8085B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85B9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85B9u, 5u, 3u, cpu.address("abs", 0x210Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085B9 STA
    hw.write(cpu.address("abs", 0x210Eu), cpu.a, cpu.m8?8:16);
    goto L_8085BC;
L_8085BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85BCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85BCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x81u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085BC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x81u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085BE;
L_8085BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85BEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85BEu, 5u, 3u, cpu.address("abs", 0x210Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085BE STA
    hw.write(cpu.address("abs", 0x210Eu), cpu.a, cpu.m8?8:16);
    goto L_8085C1;
L_8085C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85C1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85C1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085C1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x82u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085C3;
L_8085C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85C3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85C3u, 5u, 3u, cpu.address("abs", 0x210Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085C3 STA
    hw.write(cpu.address("abs", 0x210Fu), cpu.a, cpu.m8?8:16);
    goto L_8085C6;
L_8085C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85C6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85C6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x83u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085C6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x83u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085C8;
L_8085C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85C8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85C8u, 5u, 3u, cpu.address("abs", 0x210Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085C8 STA
    hw.write(cpu.address("abs", 0x210Fu), cpu.a, cpu.m8?8:16);
    goto L_8085CB;
L_8085CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85CBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85CBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x84u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085CB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x84u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085CD;
L_8085CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85CDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85CDu, 5u, 3u, cpu.address("abs", 0x2110u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085CD STA
    hw.write(cpu.address("abs", 0x2110u), cpu.a, cpu.m8?8:16);
    goto L_8085D0;
L_8085D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x85u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085D0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x85u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085D2;
L_8085D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D2u, 5u, 3u, cpu.address("abs", 0x2110u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085D2 STA
    hw.write(cpu.address("abs", 0x2110u), cpu.a, cpu.m8?8:16);
    goto L_8085D5;
L_8085D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x86u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085D5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x86u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085D7;
L_8085D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D7u, 5u, 3u, cpu.address("abs", 0x2111u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085D7 STA
    hw.write(cpu.address("abs", 0x2111u), cpu.a, cpu.m8?8:16);
    goto L_8085DA;
L_8085DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85DAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85DAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x87u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085DA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x87u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085DC;
L_8085DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85DCu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85DCu, 5u, 3u, cpu.address("abs", 0x2111u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085DC STA
    hw.write(cpu.address("abs", 0x2111u), cpu.a, cpu.m8?8:16);
    goto L_8085DF;
L_8085DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85DFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85DFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085DF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085E1;
L_8085E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E1u, 5u, 3u, cpu.address("abs", 0x2112u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085E1 STA
    hw.write(cpu.address("abs", 0x2112u), cpu.a, cpu.m8?8:16);
    goto L_8085E4;
L_8085E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x89u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085E4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x89u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085E6;
L_8085E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E6u, 5u, 3u, cpu.address("abs", 0x2112u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085E6 STA
    hw.write(cpu.address("abs", 0x2112u), cpu.a, cpu.m8?8:16);
    goto L_8085E9;
L_8085E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085E9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085EB;
L_8085EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85EBu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85EBu, 5u, 3u, cpu.address("abs", 0x2113u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085EB STA
    hw.write(cpu.address("abs", 0x2113u), cpu.a, cpu.m8?8:16);
    goto L_8085EE;
L_8085EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85EEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85EEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085EE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085F0;
L_8085F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F0u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F0u, 5u, 3u, cpu.address("abs", 0x2113u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085F0 STA
    hw.write(cpu.address("abs", 0x2113u), cpu.a, cpu.m8?8:16);
    goto L_8085F3;
L_8085F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085F3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085F5;
L_8085F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F5u, 5u, 3u, cpu.address("abs", 0x2114u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085F5 STA
    hw.write(cpu.address("abs", 0x2114u), cpu.a, cpu.m8?8:16);
    goto L_8085F8;
L_8085F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085F8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8085FA;
L_8085FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85FAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85FAu, 5u, 3u, cpu.address("abs", 0x2114u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085FA STA
    hw.write(cpu.address("abs", 0x2114u), cpu.a, cpu.m8?8:16);
    goto L_8085FD;
L_8085FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85FDu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85FDu, 5u, 3u, cpu.address("abs", 0x0100u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8085FD LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x100u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808600;
L_808600:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8600u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8600u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8600u, 5u, 3u, cpu.address("abs", 0x211Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808600 STA
    hw.write(cpu.address("abs", 0x211Bu), cpu.a, cpu.m8?8:16);
    goto L_808603;
L_808603:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8603u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8603u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8603u, 5u, 3u, cpu.address("abs", 0x0101u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808603 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x101u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808606;
L_808606:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8606u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8606u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8606u, 5u, 3u, cpu.address("abs", 0x211Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808606 STA
    hw.write(cpu.address("abs", 0x211Bu), cpu.a, cpu.m8?8:16);
    goto L_808609;
L_808609:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8609u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8609u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8609u, 5u, 3u, cpu.address("abs", 0x0102u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808609 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x102u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80860C;
L_80860C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x860Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x860Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x860Cu, 5u, 3u, cpu.address("abs", 0x211Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80860C STA
    hw.write(cpu.address("abs", 0x211Cu), cpu.a, cpu.m8?8:16);
    goto L_80860F;
L_80860F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x860Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x860Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x860Fu, 5u, 3u, cpu.address("abs", 0x0103u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80860F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x103u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808612;
L_808612:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8612u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8612u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8612u, 5u, 3u, cpu.address("abs", 0x211Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808612 STA
    hw.write(cpu.address("abs", 0x211Cu), cpu.a, cpu.m8?8:16);
    goto L_808615;
L_808615:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8615u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8615u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8615u, 5u, 3u, cpu.address("abs", 0x0104u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808615 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x104u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808618;
L_808618:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8618u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8618u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8618u, 5u, 3u, cpu.address("abs", 0x211Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808618 STA
    hw.write(cpu.address("abs", 0x211Du), cpu.a, cpu.m8?8:16);
    goto L_80861B;
L_80861B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x861Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x861Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x861Bu, 5u, 3u, cpu.address("abs", 0x0105u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80861B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x105u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80861E;
L_80861E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x861Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x861Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x861Eu, 5u, 3u, cpu.address("abs", 0x211Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80861E STA
    hw.write(cpu.address("abs", 0x211Du), cpu.a, cpu.m8?8:16);
    goto L_808621;
L_808621:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8621u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8621u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8621u, 5u, 3u, cpu.address("abs", 0x0106u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808621 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x106u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808624;
L_808624:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8624u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8624u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8624u, 5u, 3u, cpu.address("abs", 0x211Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808624 STA
    hw.write(cpu.address("abs", 0x211Eu), cpu.a, cpu.m8?8:16);
    goto L_808627;
L_808627:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8627u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8627u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8627u, 5u, 3u, cpu.address("abs", 0x0107u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808627 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x107u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80862A;
L_80862A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x862Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x862Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x862Au, 5u, 3u, cpu.address("abs", 0x211Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80862A STA
    hw.write(cpu.address("abs", 0x211Eu), cpu.a, cpu.m8?8:16);
    goto L_80862D;
L_80862D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x862Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x862Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x862Du, 5u, 3u, cpu.address("abs", 0x0108u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80862D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x108u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808630;
L_808630:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8630u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8630u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8630u, 5u, 3u, cpu.address("abs", 0x211Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808630 STA
    hw.write(cpu.address("abs", 0x211Fu), cpu.a, cpu.m8?8:16);
    goto L_808633;
L_808633:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8633u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8633u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8633u, 5u, 3u, cpu.address("abs", 0x0109u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808633 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x109u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808636;
L_808636:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8636u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8636u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8636u, 5u, 3u, cpu.address("abs", 0x211Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808636 STA
    hw.write(cpu.address("abs", 0x211Fu), cpu.a, cpu.m8?8:16);
    goto L_808639;
L_808639:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8639u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8639u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8639u, 5u, 3u, cpu.address("abs", 0x010Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808639 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x10Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80863C;
L_80863C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x863Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x863Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x863Cu, 5u, 3u, cpu.address("abs", 0x2120u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80863C STA
    hw.write(cpu.address("abs", 0x2120u), cpu.a, cpu.m8?8:16);
    goto L_80863F;
L_80863F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x863Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x863Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x863Fu, 5u, 3u, cpu.address("abs", 0x010Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80863F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x10Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808642;
L_808642:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8642u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8642u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8642u, 5u, 3u, cpu.address("abs", 0x2120u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808642 STA
    hw.write(cpu.address("abs", 0x2120u), cpu.a, cpu.m8?8:16);
    goto L_808645;
L_808645:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8645u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8645u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8645u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808645 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808647;
L_808647:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8647u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8647u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8647u, 5u, 3u, cpu.address("abs", 0x2106u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808647 STA
    hw.write(cpu.address("abs", 0x2106u), cpu.a, cpu.m8?8:16);
    goto L_80864A;
L_80864A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x864Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x864Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x864Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80864A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80864Au);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80864Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80887E_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80887Eu: goto L_80887E;
    case 0x80887Fu: goto L_80887F;
    case 0x808881u: goto L_808881;
    case 0x808883u: goto L_808883;
    case 0x808885u: goto L_808885;
    case 0x808886u: goto L_808886;
    case 0x808887u: goto L_808887;
    case 0x808889u: goto L_808889;
    case 0x80888Au: goto L_80888A;
    case 0x80888Cu: goto L_80888C;
    case 0x80888Du: goto L_80888D;
    case 0x80888Eu: goto L_80888E;
    case 0x80888Fu: goto L_80888F;
    case 0x808891u: goto L_808891;
    case 0x808893u: goto L_808893;
    case 0x808896u: goto L_808896;
    case 0x808898u: goto L_808898;
    case 0x808899u: goto L_808899;
    case 0x80889Bu: goto L_80889B;
    case 0x80889Du: goto L_80889D;
    case 0x80889Fu: goto L_80889F;
    case 0x8088A1u: goto L_8088A1;
    case 0x8088A3u: goto L_8088A3;
    case 0x8088A6u: goto L_8088A6;
    case 0x8088A8u: goto L_8088A8;
    case 0x8088AAu: goto L_8088AA;
    case 0x8088ABu: goto L_8088AB;
    case 0x8088ACu: goto L_8088AC;
    case 0x8088ADu: goto L_8088AD;
    case 0x8088AEu: goto L_8088AE;
    case 0x8088B0u: goto L_8088B0;
    case 0x8088B3u: goto L_8088B3;
    case 0x8088B5u: goto L_8088B5;
    case 0x8088B7u: goto L_8088B7;
    case 0x8088B8u: goto L_8088B8;
    case 0x8088BBu: goto L_8088BB;
    case 0x8088BCu: goto L_8088BC;
    case 0x8088BEu: goto L_8088BE;
    case 0x8088C1u: goto L_8088C1;
    case 0x8088C2u: goto L_8088C2;
    case 0x8088C3u: goto L_8088C3;
    case 0x8088C5u: goto L_8088C5;
    case 0x8088C6u: goto L_8088C6;
    case 0x8088C7u: goto L_8088C7;
    case 0x8088C8u: goto L_8088C8;
    case 0x8088C9u: goto L_8088C9;
    case 0x8088CAu: goto L_8088CA;
    case 0x8088CBu: goto L_8088CB;
    case 0x8088CCu: goto L_8088CC;
    case 0x8088CEu: goto L_8088CE;
    case 0x8088D1u: goto L_8088D1;
    case 0x8088D2u: goto L_8088D2;
    case 0x8088D4u: goto L_8088D4;
    case 0x8088D7u: goto L_8088D7;
    case 0x8088DBu: goto L_8088DB;
    case 0x8088DFu: goto L_8088DF;
    case 0x8088E2u: goto L_8088E2;
    case 0x8088E3u: goto L_8088E3;
    case 0x8088E4u: goto L_8088E4;
    case 0x8088E7u: goto L_8088E7;
    case 0x8088E8u: goto L_8088E8;
    case 0x8088EAu: goto L_8088EA;
    case 0x8088EBu: goto L_8088EB;
    case 0x8088EEu: goto L_8088EE;
    case 0x8088F1u: goto L_8088F1;
    case 0x8088F2u: goto L_8088F2;
    case 0x8088F4u: goto L_8088F4;
    case 0x8088F7u: goto L_8088F7;
    case 0x8088F9u: goto L_8088F9;
    case 0x8088FBu: goto L_8088FB;
    case 0x8088FDu: goto L_8088FD;
    case 0x8088FFu: goto L_8088FF;
    case 0x808902u: goto L_808902;
    case 0x808904u: goto L_808904;
    case 0x808906u: goto L_808906;
    case 0x808909u: goto L_808909;
    case 0x80890Au: goto L_80890A;
    case 0x80890Bu: goto L_80890B;
    case 0x80890Cu: goto L_80890C;
    case 0x80890Du: goto L_80890D;
    case 0x80890Eu: goto L_80890E;
    case 0x80890Fu: goto L_80890F;
    case 0x808910u: goto L_808910;
    case 0x808911u: goto L_808911;
    case 0x808912u: goto L_808912;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80887E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x887Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x887Eu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x887Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80887E PHP
    cpu.push("PHP", hw);
    goto L_80887F;
L_80887F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x887Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x887Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x887Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80887F REP
    cpu.rep(0x20u);
    goto L_808881;
L_808881:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8881u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8881u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8881u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808881 STZ
    hw.write(cpu.address("dp", 0x3u), 0, cpu.m8?8:16);
    goto L_808883;
L_808883:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8883u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8883u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8883u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808883 STZ
    hw.write(cpu.address("dp", 0x4u), 0, cpu.m8?8:16);
    goto L_808885;
L_808885:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8885u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8885u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8885u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808885 PLP
    cpu.pop("PLP", hw);
    goto L_808886;
L_808886:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8886u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8886u,0x808886u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8886u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8886u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808886 PHP
    cpu.push("PHP", hw);
    goto L_808887;
L_808887:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8887u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8887u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8887u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808887 SEP
    cpu.sep(0x20u);
    goto L_808889;
L_808889:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8889u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8889u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8889u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808889 PHB
    cpu.push("PHB", hw);
    goto L_80888A;
L_80888A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x888Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x888Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x888Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80888A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80888C;
L_80888C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x888Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x888Cu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x888Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80888C PHA
    cpu.push("PHA", hw);
    goto L_80888D;
L_80888D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x888Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x888Du,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x888Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80888D PLB
    cpu.pop("PLB", hw);
    goto L_80888E;
L_80888E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x888Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x888Eu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x888Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80888E PHX
    cpu.push("PHX", hw);
    goto L_80888F;
L_80888F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x888Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x888Fu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x888Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80888F LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x96u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_808891;
L_808891:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8891u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8891u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8891u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808891 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_808893;
L_808893:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8893u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8893u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8893u, 4u + 1u, 3u, cpu.address("absy", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808893 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808896;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8893u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8893u, 4u + 1u, 3u, cpu.address("absy", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808893 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808896;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8893u,0x808893u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_808896:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8896u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8896u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8896u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808896 BMI -> $8088A8
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_8088A8; }
    goto L_808898;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8896u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8896u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808896 BMI -> $8088A8
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_8088A8; }
    goto L_808898;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8896u,0x808896u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_808898:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8898u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8898u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8898u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808898 ASL
    cpu.aslA();
    goto L_808899;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8898u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8898u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808898 ASL
    cpu.aslA();
    goto L_808899;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8898u,0x808898u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_808899:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8899u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8899u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8899u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808899 STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_80889B;
L_80889B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x889Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x889Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x889Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80889B BEQ -> $80889F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80889F; }
    goto L_80889D;
L_80889D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x889Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x889Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x889Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80889D LDA
    cpu.setA(0x8u, 8);
    goto L_80889F;
L_80889F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x889Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x889Fu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x889Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80889F EOR
    cpu.logicXor(0xF0u);
    goto L_8088A1;
L_8088A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88A1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88A1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088A1 STA
    hw.write(cpu.address("dp", 0x7u), cpu.a, cpu.m8?8:16);
    goto L_8088A3;
L_8088A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88A3u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88A3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088A3 CPX
    cpu.compareX(0x200u);
    goto L_8088A6;
L_8088A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88A6u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88A6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088A6 BCC -> $8088AE
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8088AE; }
    goto L_8088A8;
L_8088A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88A8u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88A8u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88A8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088A8 STX
    hw.write(cpu.address("dp", 0x96u), cpu.x, cpu.x8?8:16);
    goto L_8088AA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88A8u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88A8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088A8 STX
    hw.write(cpu.address("dp", 0x96u), cpu.x, cpu.x8?8:16);
    goto L_8088AA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88A8u,0x8088A8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8088AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88AAu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88AAu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88AAu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8088AA PLX
    cpu.pop("PLX", hw);
    goto L_8088AB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88AAu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88AAu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8088AA PLX
    cpu.pop("PLX", hw);
    goto L_8088AB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88AAu,0x8088AAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8088AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88ABu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88ABu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88ABu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8088AB PLB
    cpu.pop("PLB", hw);
    goto L_8088AC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88ABu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88ABu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8088AB PLB
    cpu.pop("PLB", hw);
    goto L_8088AC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88ABu,0x8088ABu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8088AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88ACu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88ACu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88ACu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8088AC PLP
    cpu.pop("PLP", hw);
    goto L_8088AD;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88ACu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88ACu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8088AC PLP
    cpu.pop("PLP", hw);
    goto L_8088AD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88ACu,0x8088ACu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8088AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88ADu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88ADu,0x8088ADu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88ADu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88ADu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8088AD RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8088ADu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8088ADu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_8088AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88AEu,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88AEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088AE BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16), false);
    goto L_8088B0;
L_8088B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88B0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88B0u, 4u + 1u, 3u, cpu.address("absy", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088B0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8088B3;
L_8088B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88B3u,cpu,0x50u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88B3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088B3 BVC -> $8088BB
    if (!cpu.v) { hw.addCpuInternalCycles(1u); goto L_8088BB; }
    goto L_8088B5;
L_8088B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88B5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88B5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088B5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8088B7;
L_8088B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88B7u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88B7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088B7 SEC
    cpu.setFlag('C', true);
    goto L_8088B8;
L_8088B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88B8u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88B8u, 4u + 1u, 3u, cpu.address("absy", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088B8 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x1u), cpu.m8?8:16));
    goto L_8088BB;
L_8088BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88BBu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088BB CLC
    cpu.setFlag('C', false);
    goto L_8088BC;
L_8088BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88BCu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88BCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088BC ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16));
    goto L_8088BE;
L_8088BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88BEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88BEu, 5u, 3u, cpu.address("absx", 0x1400u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088BE STA
    hw.write(cpu.address("absx", 0x1400u), cpu.a, cpu.m8?8:16);
    goto L_8088C1;
L_8088C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C1u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8088C1 PHX
    cpu.push("PHX", hw);
    goto L_8088C2;
L_8088C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C2u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C2u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8088C2 PHY
    cpu.push("PHY", hw);
    goto L_8088C3;
L_8088C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C3u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088C3 REP
    cpu.rep(0x20u);
    goto L_8088C5;
L_8088C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C5u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088C5 TXA
    cpu.transfer("TXA");
    goto L_8088C6;
L_8088C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C6u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088C6 LSR
    cpu.lsrA();
    goto L_8088C7;
L_8088C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C7u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088C7 LSR
    cpu.lsrA();
    goto L_8088C8;
L_8088C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C8u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088C8 LSR
    cpu.lsrA();
    goto L_8088C9;
L_8088C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C9u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088C9 LSR
    cpu.lsrA();
    goto L_8088CA;
L_8088CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88CAu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88CAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088CA TAY
    cpu.transfer("TAY");
    goto L_8088CB;
L_8088CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88CBu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88CBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088CB TXA
    cpu.transfer("TXA");
    goto L_8088CC;
L_8088CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88CCu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88CCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088CC ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x6u), cpu.m8?8:16));
    goto L_8088CE;
L_8088CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88CEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88CEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088CE AND
    cpu.logicAnd(0xFu);
    goto L_8088D1;
L_8088D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88D1u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88D1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088D1 TAX
    cpu.transfer("TAX");
    goto L_8088D2;
L_8088D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88D2u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88D2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088D2 SEP
    cpu.sep(0x20u);
    goto L_8088D4;
L_8088D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88D4u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88D4u, 4u + 1u, 3u, cpu.address("absy", 0x1600u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088D4 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1600u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8088D7;
L_8088D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88D7u,cpu,0x3Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88D7u, 5u, 4u, ((0x80886Eu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088D7 AND
    cpu.logicAnd(hw.readW(((0x80886Eu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_8088DB;
L_8088DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88DBu,cpu,0x1Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88DBu, 5u, 4u, ((0x80885Eu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088DB ORA
    cpu.logicOr(hw.readW(((0x80885Eu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_8088DF;
L_8088DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88DFu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88DFu, 5u, 3u, cpu.address("absy", 0x1600u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088DF STA
    hw.write(cpu.address("absy", 0x1600u), cpu.a, cpu.m8?8:16);
    goto L_8088E2;
L_8088E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E2u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E2u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8088E2 PLY
    cpu.pop("PLY", hw);
    goto L_8088E3;
L_8088E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E3u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E3u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8088E3 PLX
    cpu.pop("PLX", hw);
    goto L_8088E4;
L_8088E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E4u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E4u, 4u + 1u, 3u, cpu.address("absy", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088E4 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8088E7;
L_8088E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E7u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088E7 CLC
    cpu.setFlag('C', false);
    goto L_8088E8;
L_8088E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E8u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088E8 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_8088EA;
L_8088EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88EAu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88EAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088EA DEC
    cpu.decReg('A');
    goto L_8088EB;
L_8088EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88EBu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88EBu, 5u, 3u, cpu.address("absx", 0x1401u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088EB STA
    hw.write(cpu.address("absx", 0x1401u), cpu.a, cpu.m8?8:16);
    goto L_8088EE;
L_8088EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88EEu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88EEu, 4u + 1u, 3u, cpu.address("absy", 0x0003u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088EE LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8088F1;
L_8088F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F1u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088F1 CLC
    cpu.setFlag('C', false);
    goto L_8088F2;
L_8088F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F2u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088F2 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_8088F4;
L_8088F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F4u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F4u, 5u, 3u, cpu.address("absx", 0x1402u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088F4 STA
    hw.write(cpu.address("absx", 0x1402u), cpu.a, cpu.m8?8:16);
    goto L_8088F7;
L_8088F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088F7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8088F9;
L_8088F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F9u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088F9 BCC -> $8088FD
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8088FD; }
    goto L_8088FB;
L_8088FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88FBu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88FBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088FB ORA
    cpu.logicOr(0x1u);
    goto L_8088FD;
L_8088FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88FDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88FDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088FD STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_8088FF;
L_8088FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88FFu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88FFu, 4u + 1u, 3u, cpu.address("absy", 0x0004u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088FF LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808902;
L_808902:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8902u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8902u,cpu,0x45u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8902u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808902 EOR
    cpu.logicXor(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16));
    goto L_808904;
L_808904:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8904u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8904u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8904u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808904 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x6u), cpu.m8?8:16));
    goto L_808906;
L_808906:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8906u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8906u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8906u, 5u, 3u, cpu.address("absx", 0x1403u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808906 STA
    hw.write(cpu.address("absx", 0x1403u), cpu.a, cpu.m8?8:16);
    goto L_808909;
L_808909:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8909u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8909u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8909u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808909 INX
    cpu.inc('X');
    goto L_80890A;
L_80890A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Au,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80890A INX
    cpu.inc('X');
    goto L_80890B;
L_80890B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Bu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80890B INX
    cpu.inc('X');
    goto L_80890C;
L_80890C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Cu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80890C INX
    cpu.inc('X');
    goto L_80890D;
L_80890D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Du,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80890D INY
    cpu.inc('Y');
    goto L_80890E;
L_80890E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Eu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80890E INY
    cpu.inc('Y');
    goto L_80890F;
L_80890F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80890F INY
    cpu.inc('Y');
    goto L_808910;
L_808910:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8910u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8910u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8910u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808910 INY
    cpu.inc('Y');
    goto L_808911;
L_808911:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8911u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8911u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8911u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808911 INY
    cpu.inc('Y');
    goto L_808912;
L_808912:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8912u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8912u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8912u, 3u, 3u, cpu.address("abs", 0x8893u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808912 JMP -> $808893
    goto L_808893;
}

void sub_80887E_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80887Eu: goto L_80887E;
    case 0x80887Fu: goto L_80887F;
    case 0x808881u: goto L_808881;
    case 0x808883u: goto L_808883;
    case 0x808885u: goto L_808885;
    case 0x808886u: goto L_808886;
    case 0x808887u: goto L_808887;
    case 0x808889u: goto L_808889;
    case 0x80888Au: goto L_80888A;
    case 0x80888Cu: goto L_80888C;
    case 0x80888Du: goto L_80888D;
    case 0x80888Eu: goto L_80888E;
    case 0x80888Fu: goto L_80888F;
    case 0x808891u: goto L_808891;
    case 0x808893u: goto L_808893;
    case 0x808896u: goto L_808896;
    case 0x808898u: goto L_808898;
    case 0x808899u: goto L_808899;
    case 0x80889Bu: goto L_80889B;
    case 0x80889Du: goto L_80889D;
    case 0x80889Fu: goto L_80889F;
    case 0x8088A1u: goto L_8088A1;
    case 0x8088A3u: goto L_8088A3;
    case 0x8088A6u: goto L_8088A6;
    case 0x8088A8u: goto L_8088A8;
    case 0x8088AAu: goto L_8088AA;
    case 0x8088ABu: goto L_8088AB;
    case 0x8088ACu: goto L_8088AC;
    case 0x8088ADu: goto L_8088AD;
    case 0x8088AEu: goto L_8088AE;
    case 0x8088B0u: goto L_8088B0;
    case 0x8088B3u: goto L_8088B3;
    case 0x8088B5u: goto L_8088B5;
    case 0x8088B7u: goto L_8088B7;
    case 0x8088B8u: goto L_8088B8;
    case 0x8088BBu: goto L_8088BB;
    case 0x8088BCu: goto L_8088BC;
    case 0x8088BEu: goto L_8088BE;
    case 0x8088C1u: goto L_8088C1;
    case 0x8088C2u: goto L_8088C2;
    case 0x8088C3u: goto L_8088C3;
    case 0x8088C5u: goto L_8088C5;
    case 0x8088C6u: goto L_8088C6;
    case 0x8088C7u: goto L_8088C7;
    case 0x8088C8u: goto L_8088C8;
    case 0x8088C9u: goto L_8088C9;
    case 0x8088CAu: goto L_8088CA;
    case 0x8088CBu: goto L_8088CB;
    case 0x8088CCu: goto L_8088CC;
    case 0x8088CEu: goto L_8088CE;
    case 0x8088D1u: goto L_8088D1;
    case 0x8088D2u: goto L_8088D2;
    case 0x8088D4u: goto L_8088D4;
    case 0x8088D7u: goto L_8088D7;
    case 0x8088DBu: goto L_8088DB;
    case 0x8088DFu: goto L_8088DF;
    case 0x8088E2u: goto L_8088E2;
    case 0x8088E3u: goto L_8088E3;
    case 0x8088E4u: goto L_8088E4;
    case 0x8088E7u: goto L_8088E7;
    case 0x8088E8u: goto L_8088E8;
    case 0x8088EAu: goto L_8088EA;
    case 0x8088EBu: goto L_8088EB;
    case 0x8088EEu: goto L_8088EE;
    case 0x8088F1u: goto L_8088F1;
    case 0x8088F2u: goto L_8088F2;
    case 0x8088F4u: goto L_8088F4;
    case 0x8088F7u: goto L_8088F7;
    case 0x8088F9u: goto L_8088F9;
    case 0x8088FBu: goto L_8088FB;
    case 0x8088FDu: goto L_8088FD;
    case 0x8088FFu: goto L_8088FF;
    case 0x808902u: goto L_808902;
    case 0x808904u: goto L_808904;
    case 0x808906u: goto L_808906;
    case 0x808909u: goto L_808909;
    case 0x80890Au: goto L_80890A;
    case 0x80890Bu: goto L_80890B;
    case 0x80890Cu: goto L_80890C;
    case 0x80890Du: goto L_80890D;
    case 0x80890Eu: goto L_80890E;
    case 0x80890Fu: goto L_80890F;
    case 0x808910u: goto L_808910;
    case 0x808911u: goto L_808911;
    case 0x808912u: goto L_808912;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80887E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x887Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x887Eu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x887Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80887E PHP
    cpu.push("PHP", hw);
    goto L_80887F;
L_80887F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x887Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x887Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x887Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80887F REP
    cpu.rep(0x20u);
    goto L_808881;
L_808881:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8881u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8881u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8881u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808881 STZ
    hw.write(cpu.address("dp", 0x3u), 0, cpu.m8?8:16);
    goto L_808883;
L_808883:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8883u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8883u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8883u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808883 STZ
    hw.write(cpu.address("dp", 0x4u), 0, cpu.m8?8:16);
    goto L_808885;
L_808885:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8885u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8885u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8885u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808885 PLP
    cpu.pop("PLP", hw);
    goto L_808886;
L_808886:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8886u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8886u,0x808886u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8886u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8886u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808886 PHP
    cpu.push("PHP", hw);
    goto L_808887;
L_808887:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8887u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8887u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8887u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808887 SEP
    cpu.sep(0x20u);
    goto L_808889;
L_808889:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8889u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8889u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8889u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808889 PHB
    cpu.push("PHB", hw);
    goto L_80888A;
L_80888A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x888Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x888Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x888Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80888A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80888C;
L_80888C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x888Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x888Cu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x888Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80888C PHA
    cpu.push("PHA", hw);
    goto L_80888D;
L_80888D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x888Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x888Du,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x888Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80888D PLB
    cpu.pop("PLB", hw);
    goto L_80888E;
L_80888E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x888Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x888Eu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x888Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80888E PHX
    cpu.push("PHX", hw);
    goto L_80888F;
L_80888F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x888Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x888Fu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x888Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80888F LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x96u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_808891;
L_808891:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8891u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8891u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8891u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808891 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_808893;
L_808893:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8893u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8893u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8893u, 4u + 1u, 3u, cpu.address("absy", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808893 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808896;
L_808896:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8896u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8896u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8896u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808896 BMI -> $8088A8
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_8088A8; }
    goto L_808898;
L_808898:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8898u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8898u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8898u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808898 ASL
    cpu.aslA();
    goto L_808899;
L_808899:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8899u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8899u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8899u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808899 STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_80889B;
L_80889B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x889Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x889Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x889Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80889B BEQ -> $80889F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80889F; }
    goto L_80889D;
L_80889D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x889Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x889Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x889Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80889D LDA
    cpu.setA(0x8u, 8);
    goto L_80889F;
L_80889F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x889Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x889Fu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x889Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80889F EOR
    cpu.logicXor(0xF0u);
    goto L_8088A1;
L_8088A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88A1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88A1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088A1 STA
    hw.write(cpu.address("dp", 0x7u), cpu.a, cpu.m8?8:16);
    goto L_8088A3;
L_8088A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88A3u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88A3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088A3 CPX
    cpu.compareX(0x200u);
    goto L_8088A6;
L_8088A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88A6u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88A6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088A6 BCC -> $8088AE
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8088AE; }
    goto L_8088A8;
L_8088A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88A8u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88A8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088A8 STX
    hw.write(cpu.address("dp", 0x96u), cpu.x, cpu.x8?8:16);
    goto L_8088AA;
L_8088AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88AAu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88AAu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8088AA PLX
    cpu.pop("PLX", hw);
    goto L_8088AB;
L_8088AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88ABu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88ABu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8088AB PLB
    cpu.pop("PLB", hw);
    goto L_8088AC;
L_8088AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88ACu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88ACu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8088AC PLP
    cpu.pop("PLP", hw);
    goto L_8088AD;
L_8088AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88ADu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88ADu,0x8088ADu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88ADu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88ADu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8088AD RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8088ADu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8088ADu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_8088AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88AEu,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88AEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088AE BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16), false);
    goto L_8088B0;
L_8088B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88B0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88B0u, 4u + 1u, 3u, cpu.address("absy", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088B0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8088B3;
L_8088B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88B3u,cpu,0x50u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88B3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088B3 BVC -> $8088BB
    if (!cpu.v) { hw.addCpuInternalCycles(1u); goto L_8088BB; }
    goto L_8088B5;
L_8088B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88B5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88B5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088B5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8088B7;
L_8088B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88B7u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88B7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088B7 SEC
    cpu.setFlag('C', true);
    goto L_8088B8;
L_8088B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88B8u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88B8u, 4u + 1u, 3u, cpu.address("absy", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088B8 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x1u), cpu.m8?8:16));
    goto L_8088BB;
L_8088BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88BBu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088BB CLC
    cpu.setFlag('C', false);
    goto L_8088BC;
L_8088BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88BCu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88BCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088BC ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16));
    goto L_8088BE;
L_8088BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88BEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88BEu, 5u, 3u, cpu.address("absx", 0x1400u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088BE STA
    hw.write(cpu.address("absx", 0x1400u), cpu.a, cpu.m8?8:16);
    goto L_8088C1;
L_8088C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C1u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8088C1 PHX
    cpu.push("PHX", hw);
    goto L_8088C2;
L_8088C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C2u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C2u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8088C2 PHY
    cpu.push("PHY", hw);
    goto L_8088C3;
L_8088C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C3u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088C3 REP
    cpu.rep(0x20u);
    goto L_8088C5;
L_8088C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C5u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088C5 TXA
    cpu.transfer("TXA");
    goto L_8088C6;
L_8088C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C6u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088C6 LSR
    cpu.lsrA();
    goto L_8088C7;
L_8088C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C7u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088C7 LSR
    cpu.lsrA();
    goto L_8088C8;
L_8088C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C8u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088C8 LSR
    cpu.lsrA();
    goto L_8088C9;
L_8088C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C9u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088C9 LSR
    cpu.lsrA();
    goto L_8088CA;
L_8088CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88CAu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88CAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088CA TAY
    cpu.transfer("TAY");
    goto L_8088CB;
L_8088CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88CBu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88CBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088CB TXA
    cpu.transfer("TXA");
    goto L_8088CC;
L_8088CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88CCu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88CCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088CC ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x6u), cpu.m8?8:16));
    goto L_8088CE;
L_8088CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88CEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88CEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088CE AND
    cpu.logicAnd(0xFu);
    goto L_8088D1;
L_8088D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88D1u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88D1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088D1 TAX
    cpu.transfer("TAX");
    goto L_8088D2;
L_8088D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88D2u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88D2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088D2 SEP
    cpu.sep(0x20u);
    goto L_8088D4;
L_8088D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88D4u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88D4u, 4u + 1u, 3u, cpu.address("absy", 0x1600u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088D4 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1600u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8088D7;
L_8088D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88D7u,cpu,0x3Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88D7u, 5u, 4u, ((0x80886Eu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088D7 AND
    cpu.logicAnd(hw.readW(((0x80886Eu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_8088DB;
L_8088DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88DBu,cpu,0x1Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88DBu, 5u, 4u, ((0x80885Eu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088DB ORA
    cpu.logicOr(hw.readW(((0x80885Eu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_8088DF;
L_8088DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88DFu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88DFu, 5u, 3u, cpu.address("absy", 0x1600u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088DF STA
    hw.write(cpu.address("absy", 0x1600u), cpu.a, cpu.m8?8:16);
    goto L_8088E2;
L_8088E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E2u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E2u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8088E2 PLY
    cpu.pop("PLY", hw);
    goto L_8088E3;
L_8088E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E3u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E3u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8088E3 PLX
    cpu.pop("PLX", hw);
    goto L_8088E4;
L_8088E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E4u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E4u, 4u + 1u, 3u, cpu.address("absy", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088E4 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8088E7;
L_8088E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E7u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088E7 CLC
    cpu.setFlag('C', false);
    goto L_8088E8;
L_8088E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E8u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088E8 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_8088EA;
L_8088EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88EAu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88EAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088EA DEC
    cpu.decReg('A');
    goto L_8088EB;
L_8088EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88EBu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88EBu, 5u, 3u, cpu.address("absx", 0x1401u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088EB STA
    hw.write(cpu.address("absx", 0x1401u), cpu.a, cpu.m8?8:16);
    goto L_8088EE;
L_8088EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88EEu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88EEu, 4u + 1u, 3u, cpu.address("absy", 0x0003u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088EE LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8088F1;
L_8088F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F1u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088F1 CLC
    cpu.setFlag('C', false);
    goto L_8088F2;
L_8088F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F2u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088F2 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_8088F4;
L_8088F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F4u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F4u, 5u, 3u, cpu.address("absx", 0x1402u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088F4 STA
    hw.write(cpu.address("absx", 0x1402u), cpu.a, cpu.m8?8:16);
    goto L_8088F7;
L_8088F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088F7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8088F9;
L_8088F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F9u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088F9 BCC -> $8088FD
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8088FD; }
    goto L_8088FB;
L_8088FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88FBu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88FBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088FB ORA
    cpu.logicOr(0x1u);
    goto L_8088FD;
L_8088FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88FDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88FDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088FD STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_8088FF;
L_8088FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88FFu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88FFu, 4u + 1u, 3u, cpu.address("absy", 0x0004u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088FF LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808902;
L_808902:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8902u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8902u,cpu,0x45u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8902u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808902 EOR
    cpu.logicXor(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16));
    goto L_808904;
L_808904:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8904u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8904u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8904u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808904 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x6u), cpu.m8?8:16));
    goto L_808906;
L_808906:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8906u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8906u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8906u, 5u, 3u, cpu.address("absx", 0x1403u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808906 STA
    hw.write(cpu.address("absx", 0x1403u), cpu.a, cpu.m8?8:16);
    goto L_808909;
L_808909:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8909u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8909u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8909u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808909 INX
    cpu.inc('X');
    goto L_80890A;
L_80890A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Au,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80890A INX
    cpu.inc('X');
    goto L_80890B;
L_80890B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Bu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80890B INX
    cpu.inc('X');
    goto L_80890C;
L_80890C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Cu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80890C INX
    cpu.inc('X');
    goto L_80890D;
L_80890D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Du,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80890D INY
    cpu.inc('Y');
    goto L_80890E;
L_80890E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Eu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80890E INY
    cpu.inc('Y');
    goto L_80890F;
L_80890F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80890F INY
    cpu.inc('Y');
    goto L_808910;
L_808910:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8910u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8910u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8910u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808910 INY
    cpu.inc('Y');
    goto L_808911;
L_808911:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8911u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8911u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8911u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808911 INY
    cpu.inc('Y');
    goto L_808912;
L_808912:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8912u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8912u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8912u, 3u, 3u, cpu.address("abs", 0x8893u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808912 JMP -> $808893
    goto L_808893;
}

void sub_8096A3_E0M0X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8096A3u: goto L_8096A3;
    case 0x8096A5u: goto L_8096A5;
    case 0x8096A7u: goto L_8096A7;
    case 0x8096A8u: goto L_8096A8;
    case 0x8096AAu: goto L_8096AA;
    case 0x8096ACu: goto L_8096AC;
    case 0x8096AEu: goto L_8096AE;
    case 0x8096AFu: goto L_8096AF;
    case 0x8096B0u: goto L_8096B0;
    case 0x8096B1u: goto L_8096B1;
    case 0x8096B3u: goto L_8096B3;
    case 0x8096B5u: goto L_8096B5;
    case 0x8096B7u: goto L_8096B7;
    case 0x8096B9u: goto L_8096B9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8096A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A3u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096A3 SEP
    cpu.sep(0x20u);
    goto L_8096A5;
L_8096A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096A5 LDA
    cpu.setA(0xB3u, 8);
    goto L_8096A7;
L_8096A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A7u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096A7 CLC
    cpu.setFlag('C', false);
    goto L_8096A8;
L_8096A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A8u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x51u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096A8 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x51u), cpu.m8?8:16));
    goto L_8096AA;
L_8096AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96AAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96AAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x51u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096AA STA
    hw.write(cpu.address("dp", 0x51u), cpu.a, cpu.m8?8:16);
    goto L_8096AC;
L_8096AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96ACu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96ACu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096AC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x52u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8096AE;
L_8096AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96AEu,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96AEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096AE ROL
    cpu.rolA();
    goto L_8096AF;
L_8096AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96AFu,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96AFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096AF ROL
    cpu.rolA();
    goto L_8096B0;
L_8096B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B0u,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096B0 ROL
    cpu.rolA();
    goto L_8096B1;
L_8096B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B1u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096B1 EOR
    cpu.logicXor(0xFFu);
    goto L_8096B3;
L_8096B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B3u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x51u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096B3 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x51u), cpu.m8?8:16));
    goto L_8096B5;
L_8096B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096B5 STA
    hw.write(cpu.address("dp", 0x52u), cpu.a, cpu.m8?8:16);
    goto L_8096B7;
L_8096B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B7u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8096B7 REP
    cpu.rep(0x20u);
    goto L_8096B9;
L_8096B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B9u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8096B9 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8096B9u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8096B9u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_809D78_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809D78u: goto L_809D78;
    case 0x809D7Au: goto L_809D7A;
    case 0x809D7Du: goto L_809D7D;
    case 0x809D7Fu: goto L_809D7F;
    case 0x809D82u: goto L_809D82;
    case 0x809D84u: goto L_809D84;
    case 0x809D87u: goto L_809D87;
    case 0x809D8Au: goto L_809D8A;
    case 0x809D8Cu: goto L_809D8C;
    case 0x809D8Fu: goto L_809D8F;
    case 0x809D92u: goto L_809D92;
    case 0x809D94u: goto L_809D94;
    case 0x809D96u: goto L_809D96;
    case 0x809D97u: goto L_809D97;
    case 0x809D98u: goto L_809D98;
    case 0x809D99u: goto L_809D99;
    case 0x809D9Au: goto L_809D9A;
    case 0x809D9Cu: goto L_809D9C;
    case 0x809D9Eu: goto L_809D9E;
    case 0x809DA0u: goto L_809DA0;
    case 0x809DA1u: goto L_809DA1;
    case 0x809DA2u: goto L_809DA2;
    case 0x809DA3u: goto L_809DA3;
    case 0x809DA4u: goto L_809DA4;
    case 0x809DA5u: goto L_809DA5;
    case 0x809DA6u: goto L_809DA6;
    case 0x809DA9u: goto L_809DA9;
    case 0x809DAAu: goto L_809DAA;
    case 0x809DACu: goto L_809DAC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809D78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D78u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D78u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D78 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_809D7A;
L_809D7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D7Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D7Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D7A LDA
    cpu.setA(0x9u, 16);
    goto L_809D7D;
L_809D7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D7Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D7Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D7D STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_809D7F;
L_809D7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D7Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D7Fu, 5u + 1u, 3u, cpu.address("absy", 0x2000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D7F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2000u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809D82;
L_809D82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D82u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D82u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D82 BEQ -> $809D8C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_809D8C; }
    goto L_809D84;
L_809D84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D84u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D84u, 6u, 3u, cpu.address("abs", 0x9DADu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809D84 JSR -> $809DAD stack real
    { cpu.push16Value(hw,0x9D86u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9D87u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9DADu), 0x809D84u); }
    goto L_809D87;
L_809D87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D87u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D87u,0x809D87u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D87u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D87u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D87 ORA
    cpu.logicOr(0x2000u);
    goto L_809D8A;
L_809D8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D8Au,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D8Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D8A BRA -> $809D8F
    goto L_809D8F;
L_809D8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D8Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D8Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D8C LDA
    cpu.setA(0x1420u, 16);
    goto L_809D8F;
L_809D8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D8Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D8Fu, 6u, 3u, cpu.address("absx", 0x2800u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D8F STA
    hw.write(cpu.address("absx", 0x2800u), cpu.a, cpu.m8?8:16);
    goto L_809D92;
L_809D92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D92u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D92u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D92 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_809D94;
L_809D94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D94u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D94u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D94 BMI -> $809D9C
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_809D9C; }
    goto L_809D96;
L_809D96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D96u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D96u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D96 DEX
    cpu.decReg('X');
    goto L_809D97;
L_809D97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D97u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D97u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D97 DEX
    cpu.decReg('X');
    goto L_809D98;
L_809D98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D98u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D98u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D98 DEY
    cpu.decReg('Y');
    goto L_809D99;
L_809D99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D99u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D99u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D99 DEY
    cpu.decReg('Y');
    goto L_809D9A;
L_809D9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D9Au,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D9Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D9A BRA -> $809D7F
    goto L_809D7F;
L_809D9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D9Cu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D9Cu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D9C DEC
    cpu.decMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_809D9E;
L_809D9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D9Eu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D9Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D9E BMI -> $809DAC
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_809DAC; }
    goto L_809DA0;
L_809DA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DA0u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DA0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809DA0 DEY
    cpu.decReg('Y');
    goto L_809DA1;
L_809DA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DA1u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DA1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809DA1 DEY
    cpu.decReg('Y');
    goto L_809DA2;
L_809DA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DA2u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DA2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809DA2 DEY
    cpu.decReg('Y');
    goto L_809DA3;
L_809DA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DA3u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DA3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809DA3 DEY
    cpu.decReg('Y');
    goto L_809DA4;
L_809DA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DA4u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DA4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809DA4 TXA
    cpu.transfer("TXA");
    goto L_809DA5;
L_809DA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DA5u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DA5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809DA5 SEC
    cpu.setFlag('C', true);
    goto L_809DA6;
L_809DA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DA6u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DA6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809DA6 SBC
    cpu.sbc(0x2Eu);
    goto L_809DA9;
L_809DA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DA9u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DA9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809DA9 TAX
    cpu.transfer("TAX");
    goto L_809DAA;
L_809DAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DAAu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DAAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809DAA BRA -> $809D7A
    goto L_809D7A;
L_809DAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DACu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DACu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809DAC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x809DACu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x809DACu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80A392_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80A392u: goto L_80A392;
    case 0x80A395u: goto L_80A395;
    case 0x80A398u: goto L_80A398;
    case 0x80A39Bu: goto L_80A39B;
    case 0x80A39Eu: goto L_80A39E;
    case 0x80A3A2u: goto L_80A3A2;
    case 0x80A3A4u: goto L_80A3A4;
    case 0x80A3A6u: goto L_80A3A6;
    case 0x80A3A7u: goto L_80A3A7;
    case 0x80A3AAu: goto L_80A3AA;
    case 0x80A3ADu: goto L_80A3AD;
    case 0x80A3B0u: goto L_80A3B0;
    case 0x80A3B4u: goto L_80A3B4;
    case 0x80A3B7u: goto L_80A3B7;
    case 0x80A3BAu: goto L_80A3BA;
    case 0x80A3BDu: goto L_80A3BD;
    case 0x80A3C0u: goto L_80A3C0;
    case 0x80A3C4u: goto L_80A3C4;
    case 0x80A3C6u: goto L_80A3C6;
    case 0x80A3C8u: goto L_80A3C8;
    case 0x80A3C9u: goto L_80A3C9;
    case 0x80A3CCu: goto L_80A3CC;
    case 0x80A3CFu: goto L_80A3CF;
    case 0x80A3D2u: goto L_80A3D2;
    case 0x80A3D6u: goto L_80A3D6;
    case 0x80A3D9u: goto L_80A3D9;
    case 0x80A3DBu: goto L_80A3DB;
    case 0x80A3DEu: goto L_80A3DE;
    case 0x80A3E0u: goto L_80A3E0;
    case 0x80A3E3u: goto L_80A3E3;
    case 0x80A3E6u: goto L_80A3E6;
    case 0x80A3EAu: goto L_80A3EA;
    case 0x80A3EDu: goto L_80A3ED;
    case 0x80A3F0u: goto L_80A3F0;
    case 0x80A3F3u: goto L_80A3F3;
    case 0x80A3F6u: goto L_80A3F6;
    case 0x80A3FAu: goto L_80A3FA;
    case 0x80A3FBu: goto L_80A3FB;
    case 0x80A3FEu: goto L_80A3FE;
    case 0x80A401u: goto L_80A401;
    case 0x80A403u: goto L_80A403;
    case 0x80A404u: goto L_80A404;
    case 0x80A407u: goto L_80A407;
    case 0x80A408u: goto L_80A408;
    case 0x80A40Bu: goto L_80A40B;
    case 0x80A40Eu: goto L_80A40E;
    case 0x80A411u: goto L_80A411;
    case 0x80A414u: goto L_80A414;
    case 0x80A418u: goto L_80A418;
    case 0x80A419u: goto L_80A419;
    case 0x80A41Cu: goto L_80A41C;
    case 0x80A41Fu: goto L_80A41F;
    case 0x80A421u: goto L_80A421;
    case 0x80A422u: goto L_80A422;
    case 0x80A425u: goto L_80A425;
    case 0x80A426u: goto L_80A426;
    case 0x80A429u: goto L_80A429;
    case 0x80A42Cu: goto L_80A42C;
    case 0x80A42Fu: goto L_80A42F;
    case 0x80A432u: goto L_80A432;
    case 0x80A436u: goto L_80A436;
    case 0x80A437u: goto L_80A437;
    case 0x80A43Au: goto L_80A43A;
    case 0x80A43Du: goto L_80A43D;
    case 0x80A43Fu: goto L_80A43F;
    case 0x80A440u: goto L_80A440;
    case 0x80A443u: goto L_80A443;
    case 0x80A444u: goto L_80A444;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80A392:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA392u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA392u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA392u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A392 LDA
    cpu.setA(0x8000u, 16);
    goto L_80A395;
L_80A395:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA395u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA395u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA395u, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A395 STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_80A398;
L_80A398:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA398u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA398u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA398u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A398 LDA
    cpu.setA(0x91u, 16);
    goto L_80A39B;
L_80A39B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA39Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA39Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA39Bu, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A39B STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_80A39E;
L_80A39E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA39Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA39Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA39Eu, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A39E JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA3A1u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA3A2u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x80A39Eu); }
    goto L_80A3A2;
L_80A3A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA3A2u,0x80A3A2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A2u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A3A2 SEP
    cpu.sep(0x20u);
    goto L_80A3A4;
L_80A3A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A3A4 LDA
    cpu.setA(0x7Eu, 8);
    goto L_80A3A6;
L_80A3A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A6u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A6u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A3A6 PHA
    cpu.push("PHA", hw);
    goto L_80A3A7;
L_80A3A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A7u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3A7u, 5u, 3u, cpu.address("abs", 0x8000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A3A7 PEA
    cpu.push16Value(hw, 0x8000u);
    goto L_80A3AA;
L_80A3AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3AAu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3AAu, 5u, 3u, cpu.address("abs", 0x6000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A3AA PEA
    cpu.push16Value(hw, 0x6000u);
    goto L_80A3AD;
L_80A3AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3ADu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3ADu, 5u, 3u, cpu.address("abs", 0x2000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A3AD PEA
    cpu.push16Value(hw, 0x2000u);
    goto L_80A3B0;
L_80A3B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B0u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B0u, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A3B0 JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA3B3u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA3B4u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x80A3B0u); }
    goto L_80A3B4;
L_80A3B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3B4u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA3B4u,0x80A3B4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A3B4 LDA
    cpu.setA(0x8000u, 16);
    goto L_80A3B7;
L_80A3B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3B7u, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A3B7 STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_80A3BA;
L_80A3BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3BAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3BAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A3BA LDA
    cpu.setA(0x99u, 16);
    goto L_80A3BD;
L_80A3BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3BDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3BDu, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A3BD STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_80A3C0;
L_80A3C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C0u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C0u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A3C0 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA3C3u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA3C4u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x80A3C0u); }
    goto L_80A3C4;
L_80A3C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3C4u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA3C4u,0x80A3C4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C4u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A3C4 SEP
    cpu.sep(0x20u);
    goto L_80A3C6;
L_80A3C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A3C6 LDA
    cpu.setA(0x7Eu, 8);
    goto L_80A3C8;
L_80A3C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C8u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C8u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A3C8 PHA
    cpu.push("PHA", hw);
    goto L_80A3C9;
L_80A3C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C9u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3C9u, 5u, 3u, cpu.address("abs", 0x8000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A3C9 PEA
    cpu.push16Value(hw, 0x8000u);
    goto L_80A3CC;
L_80A3CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CCu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CCu, 5u, 3u, cpu.address("abs", 0x2000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A3CC PEA
    cpu.push16Value(hw, 0x2000u);
    goto L_80A3CF;
L_80A3CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CFu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3CFu, 5u, 3u, cpu.address("abs", 0x4000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A3CF PEA
    cpu.push16Value(hw, 0x4000u);
    goto L_80A3D2;
L_80A3D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D2u, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A3D2 JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA3D5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA3D6u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x80A3D2u); }
    goto L_80A3D6;
L_80A3D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3D6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA3D6u,0x80A3D6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A3D6 LDA
    cpu.setA(0x846Cu, 16);
    goto L_80A3D9;
L_80A3D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3D9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A3D9 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80A3DB;
L_80A3DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A3DB LDA
    cpu.setA(0x8Au, 16);
    goto L_80A3DE;
L_80A3DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3DEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A3DE STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_80A3E0;
L_80A3E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E0u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A3E0 LDX
    cpu.setX(0x0u, 16);
    goto L_80A3E3;
L_80A3E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E3u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A3E3 LDY
    cpu.setY(0x200u, 16);
    goto L_80A3E6;
L_80A3E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3E6u, 8u, 4u, 0x808BB9u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A3E6 JSL -> $808BB9 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA3E9u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA3EAu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808BB9u, 0x80A3E6u); }
    goto L_80A3EA;
L_80A3EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3EAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA3EAu,0x80A3EAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3EAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3EAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A3EA LDA
    cpu.setA(0xB685u, 16);
    goto L_80A3ED;
L_80A3ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3EDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3EDu, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A3ED STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_80A3F0;
L_80A3F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A3F0 LDA
    cpu.setA(0x8Au, 16);
    goto L_80A3F3;
L_80A3F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F3u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A3F3 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_80A3F6;
L_80A3F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3F6u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A3F6 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA3F9u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA3FAu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x80A3F6u); }
    goto L_80A3FA;
L_80A3FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3FAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA3FAu,0x80A3FAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3FAu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3FAu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A3FA PHB
    cpu.push("PHB", hw);
    goto L_80A3FB;
L_80A3FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3FBu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3FBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A3FB LDX
    cpu.setX(0x8000u, 16);
    goto L_80A3FE;
L_80A3FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3FEu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3FEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A3FE LDY
    cpu.setY(0x2800u, 16);
    goto L_80A401;
L_80A401:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA401u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA401u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA401u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A401 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A403;
L_80A403:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA403u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA403u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA403u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A403 DEC
    cpu.decReg('A');
    goto L_80A404;
L_80A404:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA404u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA404u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xA404u, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $80A404 MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_80A407;
L_80A407:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA407u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA407u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA407u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A407 PLB
    cpu.pop("PLB", hw);
    goto L_80A408;
L_80A408:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA408u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA408u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA408u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A408 LDA
    cpu.setA(0x9E42u, 16);
    goto L_80A40B;
L_80A40B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA40Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA40Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA40Bu, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A40B STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_80A40E;
L_80A40E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA40Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA40Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA40Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A40E LDA
    cpu.setA(0x8Bu, 16);
    goto L_80A411;
L_80A411:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA411u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA411u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA411u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A411 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_80A414;
L_80A414:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA414u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA414u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA414u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A414 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA417u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA418u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x80A414u); }
    goto L_80A418;
L_80A418:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA418u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA418u,0x80A418u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA418u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA418u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A418 PHB
    cpu.push("PHB", hw);
    goto L_80A419;
L_80A419:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA419u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA419u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA419u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A419 LDX
    cpu.setX(0x8000u, 16);
    goto L_80A41C;
L_80A41C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA41Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Cu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A41C LDY
    cpu.setY(0x4000u, 16);
    goto L_80A41F;
L_80A41F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA41Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A41F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A421;
L_80A421:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA421u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA421u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA421u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A421 DEC
    cpu.decReg('A');
    goto L_80A422;
L_80A422:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA422u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA422u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xA422u, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $80A422 MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_80A425;
L_80A425:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA425u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA425u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA425u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A425 PLB
    cpu.pop("PLB", hw);
    goto L_80A426;
L_80A426:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA426u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA426u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA426u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A426 LDA
    cpu.setA(0x88D0u, 16);
    goto L_80A429;
L_80A429:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA429u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA429u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA429u, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A429 STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_80A42C;
L_80A42C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA42Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA42Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA42Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A42C LDA
    cpu.setA(0x89u, 16);
    goto L_80A42F;
L_80A42F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA42Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA42Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA42Fu, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A42F STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_80A432;
L_80A432:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA432u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA432u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA432u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A432 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA435u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA436u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x80A432u); }
    goto L_80A436;
L_80A436:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA436u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA436u,0x80A436u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA436u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA436u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A436 PHB
    cpu.push("PHB", hw);
    goto L_80A437;
L_80A437:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA437u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA437u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA437u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A437 LDX
    cpu.setX(0x8000u, 16);
    goto L_80A43A;
L_80A43A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA43Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Au,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A43A LDY
    cpu.setY(0x6000u, 16);
    goto L_80A43D;
L_80A43D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA43Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A43D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A43F;
L_80A43F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA43Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Fu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A43F DEC
    cpu.decReg('A');
    goto L_80A440;
L_80A440:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA440u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA440u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xA440u, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $80A440 MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_80A443;
L_80A443:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA443u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA443u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA443u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A443 PLB
    cpu.pop("PLB", hw);
    goto L_80A444;
L_80A444:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA444u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA444u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA444u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A444 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80A444u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80A444u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80AA7C_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AA7Cu: goto L_80AA7C;
    case 0x80AA7Fu: goto L_80AA7F;
    case 0x80AA81u: goto L_80AA81;
    case 0x80AA83u: goto L_80AA83;
    case 0x80AA85u: goto L_80AA85;
    case 0x80AA87u: goto L_80AA87;
    case 0x80AA8Cu: goto L_80AA8C;
    case 0x80AA8Fu: goto L_80AA8F;
    case 0x80AA92u: goto L_80AA92;
    case 0x80AA95u: goto L_80AA95;
    case 0x80AA98u: goto L_80AA98;
    case 0x80AA9Cu: goto L_80AA9C;
    case 0x80AA9Eu: goto L_80AA9E;
    case 0x80AAA0u: goto L_80AAA0;
    case 0x80AAA1u: goto L_80AAA1;
    case 0x80AAA4u: goto L_80AAA4;
    case 0x80AAA7u: goto L_80AAA7;
    case 0x80AAAAu: goto L_80AAAA;
    case 0x80AAAEu: goto L_80AAAE;
    case 0x80AAB1u: goto L_80AAB1;
    case 0x80AAB4u: goto L_80AAB4;
    case 0x80AAB7u: goto L_80AAB7;
    case 0x80AABAu: goto L_80AABA;
    case 0x80AABEu: goto L_80AABE;
    case 0x80AABFu: goto L_80AABF;
    case 0x80AAC2u: goto L_80AAC2;
    case 0x80AAC5u: goto L_80AAC5;
    case 0x80AAC7u: goto L_80AAC7;
    case 0x80AAC8u: goto L_80AAC8;
    case 0x80AACBu: goto L_80AACB;
    case 0x80AACCu: goto L_80AACC;
    case 0x80AACEu: goto L_80AACE;
    case 0x80AAD0u: goto L_80AAD0;
    case 0x80AAD1u: goto L_80AAD1;
    case 0x80AAD4u: goto L_80AAD4;
    case 0x80AAD7u: goto L_80AAD7;
    case 0x80AADAu: goto L_80AADA;
    case 0x80AADEu: goto L_80AADE;
    case 0x80AAE1u: goto L_80AAE1;
    case 0x80AAE4u: goto L_80AAE4;
    case 0x80AAE7u: goto L_80AAE7;
    case 0x80AAEAu: goto L_80AAEA;
    case 0x80AAEDu: goto L_80AAED;
    case 0x80AAF0u: goto L_80AAF0;
    case 0x80AAF2u: goto L_80AAF2;
    case 0x80AAF4u: goto L_80AAF4;
    case 0x80AAF7u: goto L_80AAF7;
    case 0x80AAF9u: goto L_80AAF9;
    case 0x80AAFCu: goto L_80AAFC;
    case 0x80AAFEu: goto L_80AAFE;
    case 0x80AB01u: goto L_80AB01;
    case 0x80AB03u: goto L_80AB03;
    case 0x80AB05u: goto L_80AB05;
    case 0x80AB07u: goto L_80AB07;
    case 0x80AB09u: goto L_80AB09;
    case 0x80AB0Bu: goto L_80AB0B;
    case 0x80AB0Du: goto L_80AB0D;
    case 0x80AB0Eu: goto L_80AB0E;
    case 0x80AB10u: goto L_80AB10;
    case 0x80AB14u: goto L_80AB14;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AA7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA7Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA7Cu, 5u, 3u, cpu.address("abs", 0x019Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA7C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x19Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AA7F;
L_80AA7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA7Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA7Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA7F BNE -> $80AA8C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AA8C; }
    goto L_80AA81;
L_80AA81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA81u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA81u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA81 SEP
    cpu.sep(0x20u);
    goto L_80AA83;
L_80AA83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA83u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA83u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA83 LDA
    cpu.setA(0x81u, 8);
    goto L_80AA85;
L_80AA85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA85u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA85u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA85 STA
    hw.write(cpu.address("dp", 0x46u), cpu.a, cpu.m8?8:16);
    goto L_80AA87;
L_80AA87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA87u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA87u, 3u, 3u, cpu.address("abs", 0xAB14u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA87 JMP -> $80AB14
    goto L_80AB14;
L_80AA8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA8Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA8Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA8C LDA
    cpu.setA(0x8000u, 16);
    goto L_80AA8F;
L_80AA8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA8Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA8Fu, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA8F STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_80AA92;
L_80AA92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA92u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA92u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA92 LDA
    cpu.setA(0x81u, 16);
    goto L_80AA95;
L_80AA95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA95u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA95u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA95 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_80AA98;
L_80AA98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA98u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA98u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AA98 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAA9Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAA9Cu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x80AA98u); }
    goto L_80AA9C;
L_80AA9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA9Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAA9Cu,0x80AA9Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA9Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA9Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA9C SEP
    cpu.sep(0x20u);
    goto L_80AA9E;
L_80AA9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA9Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA9Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA9E LDA
    cpu.setA(0x7Eu, 8);
    goto L_80AAA0;
L_80AAA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA0u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA0u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80AAA0 PHA
    cpu.push("PHA", hw);
    goto L_80AAA1;
L_80AAA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA1u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA1u, 5u, 3u, cpu.address("abs", 0x8000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AAA1 PEA
    cpu.push16Value(hw, 0x8000u);
    goto L_80AAA4;
L_80AAA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA4u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA4u, 5u, 3u, cpu.address("abs", 0x0000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AAA4 PEA
    cpu.push16Value(hw, 0x0u);
    goto L_80AAA7;
L_80AAA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA7u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA7u, 5u, 3u, cpu.address("abs", 0x2000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AAA7 PEA
    cpu.push16Value(hw, 0x2000u);
    goto L_80AAAA;
L_80AAAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAAAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAAAu, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AAAA JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAAADu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAAAEu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x80AAAAu); }
    goto L_80AAAE;
L_80AAAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAAEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAAAEu,0x80AAAEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAAEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAAEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAAE LDA
    cpu.setA(0xBD97u, 16);
    goto L_80AAB1;
L_80AAB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB1u, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAB1 STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_80AAB4;
L_80AAB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAB4 LDA
    cpu.setA(0x8Au, 16);
    goto L_80AAB7;
L_80AAB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB7u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAB7 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_80AABA;
L_80AABA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAABAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAABAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAABAu, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AABA JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAABDu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAABEu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x80AABAu); }
    goto L_80AABE;
L_80AABE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAABEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAABEu,0x80AABEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAABEu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAABEu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80AABE PHB
    cpu.push("PHB", hw);
    goto L_80AABF;
L_80AABF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAABFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAABFu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAABFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AABF LDX
    cpu.setX(0x8000u, 16);
    goto L_80AAC2;
L_80AAC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC2u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAC2 LDY
    cpu.setY(0x2800u, 16);
    goto L_80AAC5;
L_80AAC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAC5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AAC7;
L_80AAC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC7u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAC7 DEC
    cpu.decReg('A');
    goto L_80AAC8;
L_80AAC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC8u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xAAC8u, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $80AAC8 MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_80AACB;
L_80AACB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAACBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAACBu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAACBu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80AACB PLB
    cpu.pop("PLB", hw);
    goto L_80AACC;
L_80AACC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAACCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAACCu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAACCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AACC SEP
    cpu.sep(0x20u);
    goto L_80AACE;
L_80AACE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAACEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAACEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAACEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AACE LDA
    cpu.setA(0x7Eu, 8);
    goto L_80AAD0;
L_80AAD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD0u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD0u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80AAD0 PHA
    cpu.push("PHA", hw);
    goto L_80AAD1;
L_80AAD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD1u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD1u, 5u, 3u, cpu.address("abs", 0x2800u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AAD1 PEA
    cpu.push16Value(hw, 0x2800u);
    goto L_80AAD4;
L_80AAD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD4u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD4u, 5u, 3u, cpu.address("abs", 0x2000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AAD4 PEA
    cpu.push16Value(hw, 0x2000u);
    goto L_80AAD7;
L_80AAD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD7u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD7u, 5u, 3u, cpu.address("abs", 0x0800u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AAD7 PEA
    cpu.push16Value(hw, 0x800u);
    goto L_80AADA;
L_80AADA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAADAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAADAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAADAu, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AADA JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAADDu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAADEu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x80AADAu); }
    goto L_80AADE;
L_80AADE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAADEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAADEu,0x80AADEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAADEu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAADEu, 5u, 3u, cpu.address("abs", 0x1900u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AADE STZ
    hw.write(cpu.address("abs", 0x1900u), 0, cpu.m8?8:16);
    goto L_80AAE1;
L_80AAE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAE1 LDA
    cpu.setA(0x7FFFu, 16);
    goto L_80AAE4;
L_80AAE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE4u, 5u, 3u, cpu.address("abs", 0x1902u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAE4 STA
    hw.write(cpu.address("abs", 0x1902u), cpu.a, cpu.m8?8:16);
    goto L_80AAE7;
L_80AAE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAE7 LDA
    cpu.setA(0x3DEFu, 16);
    goto L_80AAEA;
L_80AAEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAEAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAEAu, 5u, 3u, cpu.address("abs", 0x1904u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAEA STA
    hw.write(cpu.address("abs", 0x1904u), cpu.a, cpu.m8?8:16);
    goto L_80AAED;
L_80AAED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAEDu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAEDu, 8u, 3u, cpu.address("abs", 0x0122u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAED INC
    cpu.incMem(hw, cpu.address("abs", 0x122u), cpu.m8?8:16);
    goto L_80AAF0;
L_80AAF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF0u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAF0 SEP
    cpu.sep(0x20u);
    goto L_80AAF2;
L_80AAF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAF2 LDA
    cpu.setA(0x9u, 8);
    goto L_80AAF4;
L_80AAF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF4u, 4u, 3u, cpu.address("abs", 0x2105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAF4 STA
    hw.write(cpu.address("abs", 0x2105u), cpu.a, cpu.m8?8:16);
    goto L_80AAF7;
L_80AAF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAF7 LDA
    cpu.setA(0x20u, 8);
    goto L_80AAF9;
L_80AAF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF9u, 4u, 3u, cpu.address("abs", 0x2107u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAF9 STA
    hw.write(cpu.address("abs", 0x2107u), cpu.a, cpu.m8?8:16);
    goto L_80AAFC;
L_80AAFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAFCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAFCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAFC LDA
    cpu.setA(0x0u, 8);
    goto L_80AAFE;
L_80AAFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAFEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAFEu, 4u, 3u, cpu.address("abs", 0x210Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAFE STA
    hw.write(cpu.address("abs", 0x210Bu), cpu.a, cpu.m8?8:16);
    goto L_80AB01;
L_80AB01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB01u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB01u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB01 LDA
    cpu.setA(0x1u, 8);
    goto L_80AB03;
L_80AB03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB03u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB03u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB03 STA
    hw.write(cpu.address("dp", 0x7Au), cpu.a, cpu.m8?8:16);
    goto L_80AB05;
L_80AB05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB05u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB05u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB05 STZ
    hw.write(cpu.address("dp", 0x7Bu), 0, cpu.m8?8:16);
    goto L_80AB07;
L_80AB07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB07u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB07u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB07 STZ
    hw.write(cpu.address("dp", 0x47u), 0, cpu.m8?8:16);
    goto L_80AB09;
L_80AB09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB09u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB09u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB09 STZ
    hw.write(cpu.address("dp", 0x49u), 0, cpu.m8?8:16);
    goto L_80AB0B;
L_80AB0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB0Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB0Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB0B LDA
    cpu.setA(0xC2u, 8);
    goto L_80AB0D;
L_80AB0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB0Du,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB0Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB0D XBA
    cpu.xba();
    goto L_80AB0E;
L_80AB0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB0Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB0Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB0E LDA
    cpu.setA(0x0u, 8);
    goto L_80AB10;
L_80AB10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB10u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB10u, 8u, 4u, 0x8086F4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AB10 JSL -> $8086F4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAB13u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAB14u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8086F4u, 0x80AB10u); }
    goto L_80AB14;
L_80AB14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB14u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB14u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB14u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AB14 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80AB14u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AB14u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB14u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB14u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AB14 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80AB14u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AB14u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAB14u,0x80AB14u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80AA7C_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AA7Cu: goto L_80AA7C;
    case 0x80AA7Fu: goto L_80AA7F;
    case 0x80AA81u: goto L_80AA81;
    case 0x80AA83u: goto L_80AA83;
    case 0x80AA85u: goto L_80AA85;
    case 0x80AA87u: goto L_80AA87;
    case 0x80AA8Cu: goto L_80AA8C;
    case 0x80AA8Fu: goto L_80AA8F;
    case 0x80AA92u: goto L_80AA92;
    case 0x80AA95u: goto L_80AA95;
    case 0x80AA98u: goto L_80AA98;
    case 0x80AA9Cu: goto L_80AA9C;
    case 0x80AA9Eu: goto L_80AA9E;
    case 0x80AAA0u: goto L_80AAA0;
    case 0x80AAA1u: goto L_80AAA1;
    case 0x80AAA4u: goto L_80AAA4;
    case 0x80AAA7u: goto L_80AAA7;
    case 0x80AAAAu: goto L_80AAAA;
    case 0x80AAAEu: goto L_80AAAE;
    case 0x80AAB1u: goto L_80AAB1;
    case 0x80AAB4u: goto L_80AAB4;
    case 0x80AAB7u: goto L_80AAB7;
    case 0x80AABAu: goto L_80AABA;
    case 0x80AABEu: goto L_80AABE;
    case 0x80AABFu: goto L_80AABF;
    case 0x80AAC2u: goto L_80AAC2;
    case 0x80AAC5u: goto L_80AAC5;
    case 0x80AAC7u: goto L_80AAC7;
    case 0x80AAC8u: goto L_80AAC8;
    case 0x80AACBu: goto L_80AACB;
    case 0x80AACCu: goto L_80AACC;
    case 0x80AACEu: goto L_80AACE;
    case 0x80AAD0u: goto L_80AAD0;
    case 0x80AAD1u: goto L_80AAD1;
    case 0x80AAD4u: goto L_80AAD4;
    case 0x80AAD7u: goto L_80AAD7;
    case 0x80AADAu: goto L_80AADA;
    case 0x80AADEu: goto L_80AADE;
    case 0x80AAE1u: goto L_80AAE1;
    case 0x80AAE4u: goto L_80AAE4;
    case 0x80AAE7u: goto L_80AAE7;
    case 0x80AAEAu: goto L_80AAEA;
    case 0x80AAEDu: goto L_80AAED;
    case 0x80AAF0u: goto L_80AAF0;
    case 0x80AAF2u: goto L_80AAF2;
    case 0x80AAF4u: goto L_80AAF4;
    case 0x80AAF7u: goto L_80AAF7;
    case 0x80AAF9u: goto L_80AAF9;
    case 0x80AAFCu: goto L_80AAFC;
    case 0x80AAFEu: goto L_80AAFE;
    case 0x80AB01u: goto L_80AB01;
    case 0x80AB03u: goto L_80AB03;
    case 0x80AB05u: goto L_80AB05;
    case 0x80AB07u: goto L_80AB07;
    case 0x80AB09u: goto L_80AB09;
    case 0x80AB0Bu: goto L_80AB0B;
    case 0x80AB0Du: goto L_80AB0D;
    case 0x80AB0Eu: goto L_80AB0E;
    case 0x80AB10u: goto L_80AB10;
    case 0x80AB14u: goto L_80AB14;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AA7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA7Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA7Cu, 5u, 3u, cpu.address("abs", 0x019Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA7C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x19Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AA7F;
L_80AA7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA7Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA7Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA7F BNE -> $80AA8C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AA8C; }
    goto L_80AA81;
L_80AA81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA81u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA81u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA81 SEP
    cpu.sep(0x20u);
    goto L_80AA83;
L_80AA83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA83u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA83u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA83 LDA
    cpu.setA(0x81u, 8);
    goto L_80AA85;
L_80AA85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA85u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA85u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA85 STA
    hw.write(cpu.address("dp", 0x46u), cpu.a, cpu.m8?8:16);
    goto L_80AA87;
L_80AA87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA87u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA87u, 3u, 3u, cpu.address("abs", 0xAB14u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA87 JMP -> $80AB14
    goto L_80AB14;
L_80AA8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA8Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA8Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA8C LDA
    cpu.setA(0x8000u, 16);
    goto L_80AA8F;
L_80AA8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA8Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA8Fu, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA8F STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_80AA92;
L_80AA92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA92u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA92u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA92 LDA
    cpu.setA(0x81u, 16);
    goto L_80AA95;
L_80AA95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA95u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA95u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA95 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_80AA98;
L_80AA98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA98u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA98u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AA98 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAA9Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAA9Cu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x80AA98u); }
    goto L_80AA9C;
L_80AA9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA9Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAA9Cu,0x80AA9Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA9Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA9Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA9C SEP
    cpu.sep(0x20u);
    goto L_80AA9E;
L_80AA9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA9Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA9Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA9E LDA
    cpu.setA(0x7Eu, 8);
    goto L_80AAA0;
L_80AAA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA0u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA0u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80AAA0 PHA
    cpu.push("PHA", hw);
    goto L_80AAA1;
L_80AAA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA1u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA1u, 5u, 3u, cpu.address("abs", 0x8000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AAA1 PEA
    cpu.push16Value(hw, 0x8000u);
    goto L_80AAA4;
L_80AAA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA4u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA4u, 5u, 3u, cpu.address("abs", 0x0000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AAA4 PEA
    cpu.push16Value(hw, 0x0u);
    goto L_80AAA7;
L_80AAA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA7u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA7u, 5u, 3u, cpu.address("abs", 0x2000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AAA7 PEA
    cpu.push16Value(hw, 0x2000u);
    goto L_80AAAA;
L_80AAAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAAAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAAAu, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AAAA JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAAADu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAAAEu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x80AAAAu); }
    goto L_80AAAE;
L_80AAAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAAEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAAAEu,0x80AAAEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAAEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAAEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAAE LDA
    cpu.setA(0xBD97u, 16);
    goto L_80AAB1;
L_80AAB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB1u, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAB1 STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_80AAB4;
L_80AAB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAB4 LDA
    cpu.setA(0x8Au, 16);
    goto L_80AAB7;
L_80AAB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB7u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAB7 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_80AABA;
L_80AABA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAABAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAABAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAABAu, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AABA JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAABDu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAABEu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x80AABAu); }
    goto L_80AABE;
L_80AABE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAABEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAABEu,0x80AABEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAABEu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAABEu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80AABE PHB
    cpu.push("PHB", hw);
    goto L_80AABF;
L_80AABF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAABFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAABFu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAABFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AABF LDX
    cpu.setX(0x8000u, 16);
    goto L_80AAC2;
L_80AAC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC2u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAC2 LDY
    cpu.setY(0x2800u, 16);
    goto L_80AAC5;
L_80AAC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAC5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AAC7;
L_80AAC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC7u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAC7 DEC
    cpu.decReg('A');
    goto L_80AAC8;
L_80AAC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC8u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xAAC8u, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $80AAC8 MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_80AACB;
L_80AACB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAACBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAACBu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAACBu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80AACB PLB
    cpu.pop("PLB", hw);
    goto L_80AACC;
L_80AACC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAACCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAACCu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAACCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AACC SEP
    cpu.sep(0x20u);
    goto L_80AACE;
L_80AACE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAACEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAACEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAACEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AACE LDA
    cpu.setA(0x7Eu, 8);
    goto L_80AAD0;
L_80AAD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD0u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD0u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80AAD0 PHA
    cpu.push("PHA", hw);
    goto L_80AAD1;
L_80AAD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD1u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD1u, 5u, 3u, cpu.address("abs", 0x2800u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AAD1 PEA
    cpu.push16Value(hw, 0x2800u);
    goto L_80AAD4;
L_80AAD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD4u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD4u, 5u, 3u, cpu.address("abs", 0x2000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AAD4 PEA
    cpu.push16Value(hw, 0x2000u);
    goto L_80AAD7;
L_80AAD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD7u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD7u, 5u, 3u, cpu.address("abs", 0x0800u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AAD7 PEA
    cpu.push16Value(hw, 0x800u);
    goto L_80AADA;
L_80AADA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAADAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAADAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAADAu, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AADA JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAADDu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAADEu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x80AADAu); }
    goto L_80AADE;
L_80AADE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAADEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAADEu,0x80AADEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAADEu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAADEu, 5u, 3u, cpu.address("abs", 0x1900u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AADE STZ
    hw.write(cpu.address("abs", 0x1900u), 0, cpu.m8?8:16);
    goto L_80AAE1;
L_80AAE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAE1 LDA
    cpu.setA(0x7FFFu, 16);
    goto L_80AAE4;
L_80AAE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE4u, 5u, 3u, cpu.address("abs", 0x1902u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAE4 STA
    hw.write(cpu.address("abs", 0x1902u), cpu.a, cpu.m8?8:16);
    goto L_80AAE7;
L_80AAE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAE7 LDA
    cpu.setA(0x3DEFu, 16);
    goto L_80AAEA;
L_80AAEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAEAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAEAu, 5u, 3u, cpu.address("abs", 0x1904u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAEA STA
    hw.write(cpu.address("abs", 0x1904u), cpu.a, cpu.m8?8:16);
    goto L_80AAED;
L_80AAED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAEDu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAEDu, 8u, 3u, cpu.address("abs", 0x0122u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAED INC
    cpu.incMem(hw, cpu.address("abs", 0x122u), cpu.m8?8:16);
    goto L_80AAF0;
L_80AAF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF0u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAF0 SEP
    cpu.sep(0x20u);
    goto L_80AAF2;
L_80AAF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAF2 LDA
    cpu.setA(0x9u, 8);
    goto L_80AAF4;
L_80AAF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF4u, 4u, 3u, cpu.address("abs", 0x2105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAF4 STA
    hw.write(cpu.address("abs", 0x2105u), cpu.a, cpu.m8?8:16);
    goto L_80AAF7;
L_80AAF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAF7 LDA
    cpu.setA(0x20u, 8);
    goto L_80AAF9;
L_80AAF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF9u, 4u, 3u, cpu.address("abs", 0x2107u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAF9 STA
    hw.write(cpu.address("abs", 0x2107u), cpu.a, cpu.m8?8:16);
    goto L_80AAFC;
L_80AAFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAFCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAFCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAFC LDA
    cpu.setA(0x0u, 8);
    goto L_80AAFE;
L_80AAFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAFEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAFEu, 4u, 3u, cpu.address("abs", 0x210Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AAFE STA
    hw.write(cpu.address("abs", 0x210Bu), cpu.a, cpu.m8?8:16);
    goto L_80AB01;
L_80AB01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB01u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB01u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB01 LDA
    cpu.setA(0x1u, 8);
    goto L_80AB03;
L_80AB03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB03u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB03u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB03 STA
    hw.write(cpu.address("dp", 0x7Au), cpu.a, cpu.m8?8:16);
    goto L_80AB05;
L_80AB05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB05u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB05u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB05 STZ
    hw.write(cpu.address("dp", 0x7Bu), 0, cpu.m8?8:16);
    goto L_80AB07;
L_80AB07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB07u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB07u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB07 STZ
    hw.write(cpu.address("dp", 0x47u), 0, cpu.m8?8:16);
    goto L_80AB09;
L_80AB09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB09u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB09u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB09 STZ
    hw.write(cpu.address("dp", 0x49u), 0, cpu.m8?8:16);
    goto L_80AB0B;
L_80AB0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB0Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB0Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB0B LDA
    cpu.setA(0xC2u, 8);
    goto L_80AB0D;
L_80AB0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB0Du,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB0Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB0D XBA
    cpu.xba();
    goto L_80AB0E;
L_80AB0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB0Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB0Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB0E LDA
    cpu.setA(0x0u, 8);
    goto L_80AB10;
L_80AB10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB10u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB10u, 8u, 4u, 0x8086F4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AB10 JSL -> $8086F4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAB13u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAB14u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8086F4u, 0x80AB10u); }
    goto L_80AB14;
L_80AB14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB14u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB14u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB14u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AB14 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80AB14u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AB14u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB14u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB14u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AB14 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80AB14u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AB14u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAB14u,0x80AB14u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80AB6F_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AB6Fu: goto L_80AB6F;
    case 0x80AB71u: goto L_80AB71;
    case 0x80AB73u: goto L_80AB73;
    case 0x80AB75u: goto L_80AB75;
    case 0x80AB76u: goto L_80AB76;
    case 0x80AB78u: goto L_80AB78;
    case 0x80AB7Cu: goto L_80AB7C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AB6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB6Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB6Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB6F SEP
    cpu.sep(0x20u);
    goto L_80AB71;
L_80AB71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB71u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB71u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB71 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_80AB73;
L_80AB73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB73u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB73u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB73 LDA
    cpu.setA(0x82u, 8);
    goto L_80AB75;
L_80AB75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB75u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB75u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB75 XBA
    cpu.xba();
    goto L_80AB76;
L_80AB76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB76u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB76u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB76 LDA
    cpu.setA(0xFu, 8);
    goto L_80AB78;
L_80AB78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB78u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB78u, 8u, 4u, 0x8086F4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AB78 JSL -> $8086F4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAB7Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAB7Cu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8086F4u, 0x80AB78u); }
    goto L_80AB7C;
L_80AB7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB7Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAB7Cu,0x80AB7Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB7Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB7Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AB7C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AB7Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AB7Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80B07D_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B07Du: goto L_80B07D;
    case 0x80B080u: goto L_80B080;
    case 0x80B082u: goto L_80B082;
    case 0x80B085u: goto L_80B085;
    case 0x80B088u: goto L_80B088;
    case 0x80B08Au: goto L_80B08A;
    case 0x80B08Du: goto L_80B08D;
    case 0x80B090u: goto L_80B090;
    case 0x80B093u: goto L_80B093;
    case 0x80B096u: goto L_80B096;
    case 0x80B099u: goto L_80B099;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B07D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB07Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB07Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB07Du, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B07D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B080;
L_80B080:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB080u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB080u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB080u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B080 BEQ -> $80B093
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B093; }
    goto L_80B082;
L_80B082:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB082u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB082u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB082u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B082 LDX
    cpu.setX(0x380u, 16);
    goto L_80B085;
L_80B085:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB085u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB085u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB085u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B085 LDA
    cpu.setA(0x2u, 16);
    goto L_80B088;
L_80B088:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB088u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB088u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB088u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B088 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80B08A;
L_80B08A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB08Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB08Au,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB08Au, 8u, 3u, cpu.address("abs", 0x0986u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B08A INC
    cpu.incMem(hw, cpu.address("abs", 0x986u), cpu.m8?8:16);
    goto L_80B08D;
L_80B08D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB08Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB08Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB08Du, 6u, 3u, cpu.address("abs", 0xC829u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B08D JSR -> $80C829 stack real
    { cpu.push16Value(hw,0xB08Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB090u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC829u), 0x80B08Du); }
    goto L_80B090;
L_80B090:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB090u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB090u,0x80B090u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB090u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB090u, 6u, 3u, cpu.address("abs", 0xBBFAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B090 JSR -> $80BBFA stack real
    { cpu.push16Value(hw,0xB092u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB093u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBBFAu), 0x80B090u); }
    goto L_80B093;
L_80B093:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB093u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB093u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB093u, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B093 STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B096;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB093u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB093u, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B093 STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B096;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB093u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB093u, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B093 STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B096;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB093u,0x80B093u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B096:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB096u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB096u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB096u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B096 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B099;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB096u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB096u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B096 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B099;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB096u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB096u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B096 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B099;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB096u,0x80B096u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B099:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB099u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB099u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB099u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B099 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B099u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B099u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB099u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB099u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B099 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B099u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B099u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB099u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB099u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B099 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B099u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B099u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB099u,0x80B099u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80B204_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B204u: goto L_80B204;
    case 0x80B207u: goto L_80B207;
    case 0x80B209u: goto L_80B209;
    case 0x80B20Cu: goto L_80B20C;
    case 0x80B20Eu: goto L_80B20E;
    case 0x80B211u: goto L_80B211;
    case 0x80B214u: goto L_80B214;
    case 0x80B217u: goto L_80B217;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B204:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB204u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB204u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB204u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B204 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B207;
L_80B207:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB207u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB207u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB207u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B207 BEQ -> $80B214
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B214; }
    goto L_80B209;
L_80B209:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB209u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB209u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB209u, 5u, 3u, cpu.address("abs", 0x0916u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B209 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x916u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B20C;
L_80B20C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB20Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B20C BEQ -> $80B214
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B214; }
    goto L_80B20E;
L_80B20E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB20Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB20Eu, 5u, 3u, cpu.address("abs", 0x097Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B20E STA
    hw.write(cpu.address("abs", 0x97Au), cpu.a, cpu.m8?8:16);
    goto L_80B211;
L_80B211:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB211u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB211u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB211u, 6u, 3u, cpu.address("abs", 0xCE62u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B211 JSR -> $80CE62 stack real
    { cpu.push16Value(hw,0xB213u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB214u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCE62u), 0x80B211u); }
    goto L_80B214;
L_80B214:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB214u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB214u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB214u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B214 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B217;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB214u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB214u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B214 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B217;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB214u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB214u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B214 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B217;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB214u,0x80B214u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B217:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB217u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB217u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB217u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B217 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B217u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B217u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB217u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB217u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B217 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B217u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B217u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB217u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB217u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B217 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B217u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B217u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB217u,0x80B217u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80B265_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B265u: goto L_80B265;
    case 0x80B268u: goto L_80B268;
    case 0x80B26Au: goto L_80B26A;
    case 0x80B26Du: goto L_80B26D;
    case 0x80B270u: goto L_80B270;
    case 0x80B273u: goto L_80B273;
    case 0x80B276u: goto L_80B276;
    case 0x80B278u: goto L_80B278;
    case 0x80B27Bu: goto L_80B27B;
    case 0x80B27Eu: goto L_80B27E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B265:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB265u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB265u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB265u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B265 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B268;
L_80B268:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB268u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB268u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB268u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B268 BEQ -> $80B27B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B27B; }
    goto L_80B26A;
L_80B26A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB26Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Au, 5u, 3u, cpu.address("abs", 0x090Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B26A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x90Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B26D;
L_80B26D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB26Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Du,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Du, 5u, 3u, cpu.address("abs", 0x0910u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B26D ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x910u), cpu.m8?8:16));
    goto L_80B270;
L_80B270:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB270u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB270u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB270u, 5u, 3u, cpu.address("abs", 0x0912u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B270 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x912u), cpu.m8?8:16));
    goto L_80B273;
L_80B273:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB273u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB273u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB273u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B273 CMP
    cpu.compareA(0x4u);
    goto L_80B276;
L_80B276:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB276u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB276u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB276u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B276 BNE -> $80B27B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B27B; }
    goto L_80B278;
L_80B278:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB278u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB278u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB278u, 6u, 3u, cpu.address("abs", 0xD088u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B278 JSR -> $80D088 stack real
    { cpu.push16Value(hw,0xB27Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB27Bu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD088u), 0x80B278u); }
    goto L_80B27B;
L_80B27B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB27Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Bu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Bu, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B27B INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B27E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Bu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Bu, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B27B INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B27E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB27Bu,0x80B27Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B27E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB27Eu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B27E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B27Eu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B27Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B27E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B27Eu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B27Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB27Eu,0x80B27Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80BE99_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80BE99u: goto L_80BE99;
    case 0x80BE9Cu: goto L_80BE9C;
    case 0x80BE9Du: goto L_80BE9D;
    case 0x80BE9Fu: goto L_80BE9F;
    case 0x80BEA2u: goto L_80BEA2;
    case 0x80BEA3u: goto L_80BEA3;
    case 0x80BEA4u: goto L_80BEA4;
    case 0x80BEA5u: goto L_80BEA5;
    case 0x80BEA6u: goto L_80BEA6;
    case 0x80BEA8u: goto L_80BEA8;
    case 0x80BEAAu: goto L_80BEAA;
    case 0x80BEABu: goto L_80BEAB;
    case 0x80BEADu: goto L_80BEAD;
    case 0x80BEB0u: goto L_80BEB0;
    case 0x80BEB2u: goto L_80BEB2;
    case 0x80BEB4u: goto L_80BEB4;
    case 0x80BEB6u: goto L_80BEB6;
    case 0x80BEB9u: goto L_80BEB9;
    case 0x80BEBCu: goto L_80BEBC;
    case 0x80BEBEu: goto L_80BEBE;
    case 0x80BEC0u: goto L_80BEC0;
    case 0x80BEC3u: goto L_80BEC3;
    case 0x80BEC4u: goto L_80BEC4;
    case 0x80BEC7u: goto L_80BEC7;
    case 0x80BEC9u: goto L_80BEC9;
    case 0x80BECAu: goto L_80BECA;
    case 0x80BECBu: goto L_80BECB;
    case 0x80BECDu: goto L_80BECD;
    case 0x80BED0u: goto L_80BED0;
    case 0x80BED2u: goto L_80BED2;
    case 0x80BED5u: goto L_80BED5;
    case 0x80BED7u: goto L_80BED7;
    case 0x80BEDAu: goto L_80BEDA;
    case 0x80BEDBu: goto L_80BEDB;
    case 0x80BEDCu: goto L_80BEDC;
    case 0x80BEDDu: goto L_80BEDD;
    case 0x80BEDFu: goto L_80BEDF;
    case 0x80BEE2u: goto L_80BEE2;
    case 0x80BEE4u: goto L_80BEE4;
    case 0x80BEE6u: goto L_80BEE6;
    case 0x80BEE8u: goto L_80BEE8;
    case 0x80BEEBu: goto L_80BEEB;
    case 0x80BEEDu: goto L_80BEED;
    case 0x80BEEEu: goto L_80BEEE;
    case 0x80BEF1u: goto L_80BEF1;
    case 0x80BEF2u: goto L_80BEF2;
    case 0x80BEF6u: goto L_80BEF6;
    case 0x80BEF8u: goto L_80BEF8;
    case 0x80BEFCu: goto L_80BEFC;
    case 0x80BEFEu: goto L_80BEFE;
    case 0x80BF00u: goto L_80BF00;
    case 0x80BF02u: goto L_80BF02;
    case 0x80BF04u: goto L_80BF04;
    case 0x80BF05u: goto L_80BF05;
    case 0x80BF06u: goto L_80BF06;
    case 0x80BF08u: goto L_80BF08;
    case 0x80BF0Au: goto L_80BF0A;
    case 0x80BF0Cu: goto L_80BF0C;
    case 0x80BF0Fu: goto L_80BF0F;
    case 0x80BF10u: goto L_80BF10;
    case 0x80BF13u: goto L_80BF13;
    case 0x80BF15u: goto L_80BF15;
    case 0x80BF17u: goto L_80BF17;
    case 0x80BF1Au: goto L_80BF1A;
    case 0x80BF1Cu: goto L_80BF1C;
    case 0x80BF20u: goto L_80BF20;
    case 0x80BF22u: goto L_80BF22;
    case 0x80BF23u: goto L_80BF23;
    case 0x80BF24u: goto L_80BF24;
    case 0x80BF25u: goto L_80BF25;
    case 0x80BF26u: goto L_80BF26;
    case 0x80BF29u: goto L_80BF29;
    case 0x80BF2Cu: goto L_80BF2C;
    case 0x80BF2Eu: goto L_80BF2E;
    case 0x80BF2Fu: goto L_80BF2F;
    case 0x80BF30u: goto L_80BF30;
    case 0x80BF31u: goto L_80BF31;
    case 0x80BF34u: goto L_80BF34;
    case 0x80BF37u: goto L_80BF37;
    case 0x80BF3Au: goto L_80BF3A;
    case 0x80BF3Cu: goto L_80BF3C;
    case 0x80BF3Fu: goto L_80BF3F;
    case 0x80BF41u: goto L_80BF41;
    case 0x80BF44u: goto L_80BF44;
    case 0x80BF47u: goto L_80BF47;
    case 0x80BF49u: goto L_80BF49;
    case 0x80BF4Cu: goto L_80BF4C;
    case 0x80BF4Du: goto L_80BF4D;
    case 0x80BF50u: goto L_80BF50;
    case 0x80BF52u: goto L_80BF52;
    case 0x80BF55u: goto L_80BF55;
    case 0x80BF57u: goto L_80BF57;
    case 0x80BF59u: goto L_80BF59;
    case 0x80BF5Cu: goto L_80BF5C;
    case 0x80BF5Eu: goto L_80BF5E;
    case 0x80BF61u: goto L_80BF61;
    case 0x80BF63u: goto L_80BF63;
    case 0x80BF64u: goto L_80BF64;
    case 0x80BF65u: goto L_80BF65;
    case 0x80BF66u: goto L_80BF66;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80BE99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE99u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE99u, 5u, 3u, cpu.address("abs", 0x0926u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE99 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x926u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BE9C;
L_80BE9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE9Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE9Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE9C ASL
    cpu.aslA();
    goto L_80BE9D;
L_80BE9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE9Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE9Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE9D STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_80BE9F;
L_80BE9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE9Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE9Fu, 5u, 3u, cpu.address("abs", 0x0904u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE9F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x904u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BEA2;
L_80BEA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEA2 ASL
    cpu.aslA();
    goto L_80BEA3;
L_80BEA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA3u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEA3 ASL
    cpu.aslA();
    goto L_80BEA4;
L_80BEA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA4u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEA4 ASL
    cpu.aslA();
    goto L_80BEA5;
L_80BEA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA5u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEA5 CLC
    cpu.setFlag('C', false);
    goto L_80BEA6;
L_80BEA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA6u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEA6 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16));
    goto L_80BEA8;
L_80BEA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEA8 STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_80BEAA;
L_80BEAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEAAu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEAAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEAA TAY
    cpu.transfer("TAY");
    goto L_80BEAB;
L_80BEAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEABu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEABu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEAB LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x10u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BEAD;
L_80BEAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEADu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEADu, 5u + 1u, 3u, cpu.address("absx", 0xE706u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEAD LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xE706u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BEB0;
L_80BEB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEB0 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80BEB2;
L_80BEB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB2u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB2u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $80BEB2 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BEB4;
L_80BEB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEB4 STA
    hw.write(cpu.address("dp", 0x63u), cpu.a, cpu.m8?8:16);
    goto L_80BEB6;
L_80BEB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB6u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEB6 AND
    cpu.logicAnd(0xFFu);
    goto L_80BEB9;
L_80BEB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB9u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB9u, 5u, 3u, cpu.address("abs", 0x091Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEB9 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x91Eu), cpu.m8?8:16));
    goto L_80BEBC;
L_80BEBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEBCu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEBCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEBC BEQ -> $80BECB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BECB; }
    goto L_80BEBE;
L_80BEBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEBEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEBEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEBE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x63u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BEC0;
L_80BEC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC0u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEC0 AND
    cpu.logicAnd(0xFF00u);
    goto L_80BEC3;
L_80BEC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC3u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC3u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEC3 XBA
    cpu.xba();
    goto L_80BEC4;
L_80BEC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC4u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC4u, 5u, 3u, cpu.address("abs", 0x091Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEC4 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x91Eu), cpu.m8?8:16));
    goto L_80BEC7;
L_80BEC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEC7 BEQ -> $80BECB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BECB; }
    goto L_80BEC9;
L_80BEC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC9u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEC9 SEC
    cpu.setFlag('C', true);
    goto L_80BECA;
L_80BECA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBECAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBECAu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBECAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BECA RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80BECAu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80BECAu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80BECB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBECBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBECBu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBECBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BECB LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Fu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BECD;
L_80BECD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBECDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBECDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBECDu, 5u + 1u, 3u, cpu.address("absx", 0xE1B6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BECD LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xE1B6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BED0;
L_80BED0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBED0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBED0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBED0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xAEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BED0 STA
    hw.write(cpu.address("dp", 0xAEu), cpu.a, cpu.m8?8:16);
    goto L_80BED2;
L_80BED2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBED2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBED2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBED2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BED2 LDA
    cpu.setA(0x80u, 16);
    goto L_80BED5;
L_80BED5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBED5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBED5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBED5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BED5 STA
    hw.write(cpu.address("dp", 0xB0u), cpu.a, cpu.m8?8:16);
    goto L_80BED7;
L_80BED7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBED7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBED7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBED7u, 5u, 3u, cpu.address("abs", 0x091Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BED7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x91Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BEDA;
L_80BEDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEDAu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEDAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEDA ASL
    cpu.aslA();
    goto L_80BEDB;
L_80BEDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEDBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEDBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEDB ASL
    cpu.aslA();
    goto L_80BEDC;
L_80BEDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEDCu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEDCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEDC TAY
    cpu.transfer("TAY");
    goto L_80BEDD;
L_80BEDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEDDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEDDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEDD STA
    hw.write(cpu.address("dp", 0xB2u), cpu.a, cpu.m8?8:16);
    goto L_80BEDF;
L_80BEDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEDFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEDFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEDF LDA
    cpu.setA(0x3u, 16);
    goto L_80BEE2;
L_80BEE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEE2 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_80BEE4;
L_80BEE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE4u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEE4 STZ
    hw.write(cpu.address("dp", 0x4u), 0, cpu.m8?8:16);
    goto L_80BEE6;
L_80BEE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE6u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE6u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xAEu) & 0xFFFFu), 2u, 0u);
    // $80BEE6 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0xAEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BEE8;
L_80BEE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE8u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEE8 CMP
    cpu.compareA(0xFFFFu);
    goto L_80BEEB;
L_80BEEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEEBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEEBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEEB BEQ -> $80BF00
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BF00; }
    goto L_80BEED;
L_80BEED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEEDu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEEDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEED CLC
    cpu.setFlag('C', false);
    goto L_80BEEE;
L_80BEEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEEEu,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEEEu, 5u, 3u, cpu.address("abs", 0x0918u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEEE ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x918u), cpu.m8?8:16));
    goto L_80BEF1;
L_80BEF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEF1u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEF1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEF1 TAX
    cpu.transfer("TAX");
    goto L_80BEF2;
L_80BEF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEF2u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEF2u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEF2 LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BEF6;
L_80BEF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEF6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEF6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEF6 BNE -> $80BF65
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BF65; }
    goto L_80BEF8;
L_80BEF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEF8u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEF8u, 6u, 4u, ((0x7E2016u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEF8 LDA
    cpu.loadA(hw.readW(((0x7E2016u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BEFC;
L_80BEFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEFCu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEFCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEFC BEQ -> $80BF00
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BF00; }
    goto L_80BEFE;
L_80BEFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEFEu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEFEu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEFE INC
    cpu.incMem(hw, cpu.address("dp", 0x4u), cpu.m8?8:16);
    goto L_80BF00;
L_80BF00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF00u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF00u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF00 DEC
    cpu.decMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_80BF02;
L_80BF02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF02u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF02u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF02 BMI -> $80BF08
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BF08; }
    goto L_80BF04;
L_80BF04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF04u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF04u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF04 INY
    cpu.inc('Y');
    goto L_80BF05;
L_80BF05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF05u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF05u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF05 INY
    cpu.inc('Y');
    goto L_80BF06;
L_80BF06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF06u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF06u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF06 BRA -> $80BEE6
    goto L_80BEE6;
L_80BF08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF08u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF08u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF08 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BF0A;
L_80BF0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF0Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF0Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF0A BEQ -> $80BF65
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BF65; }
    goto L_80BF0C;
L_80BF0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF0Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF0Cu, 5u, 3u, cpu.address("abs", 0x0918u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF0C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x918u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BF0F;
L_80BF0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF0Fu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF0Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF0F SEC
    cpu.setFlag('C', true);
    goto L_80BF10;
L_80BF10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF10u,cpu,0xEDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF10u, 5u, 3u, cpu.address("abs", 0x099Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF10 SBC
    cpu.sbc(hw.readW(cpu.address("abs", 0x99Eu), cpu.m8?8:16));
    goto L_80BF13;
L_80BF13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF13u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF13u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF13 STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_80BF15;
L_80BF15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF15u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF15u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF15 STZ
    hw.write(cpu.address("dp", 0x38u), 0, cpu.m8?8:16);
    goto L_80BF17;
L_80BF17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF17u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF17u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF17 LDA
    cpu.setA(0x16u, 16);
    goto L_80BF1A;
L_80BF1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF1Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF1Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x39u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF1A STA
    hw.write(cpu.address("dp", 0x39u), cpu.a, cpu.m8?8:16);
    goto L_80BF1C;
L_80BF1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF1Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF1Cu, 8u, 4u, 0x809436u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BF1C JSL -> $809436 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBF1Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBF20u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809436u, 0x80BF1Cu); }
    goto L_80BF20;
L_80BF20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF20u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF20u,0x80BF20u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF20u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF20u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF20 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BF22;
L_80BF22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF22u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF22u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF22 ASL
    cpu.aslA();
    goto L_80BF23;
L_80BF23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF23u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF23u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF23 ASL
    cpu.aslA();
    goto L_80BF24;
L_80BF24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF24u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF24u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF24 ASL
    cpu.aslA();
    goto L_80BF25;
L_80BF25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF25u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF25u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF25 CLC
    cpu.setFlag('C', false);
    goto L_80BF26;
L_80BF26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF26u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF26u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF26 ADC
    cpu.adc(0x18u);
    goto L_80BF29;
L_80BF29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF29u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF29u, 5u, 3u, cpu.address("abs", 0x091Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF29 STA
    hw.write(cpu.address("abs", 0x91Cu), cpu.a, cpu.m8?8:16);
    goto L_80BF2C;
L_80BF2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF2Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF2Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF2C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BF2E;
L_80BF2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF2Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF2Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF2E ASL
    cpu.aslA();
    goto L_80BF2F;
L_80BF2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF2Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF2Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF2F ASL
    cpu.aslA();
    goto L_80BF30;
L_80BF30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF30u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF30u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF30 CLC
    cpu.setFlag('C', false);
    goto L_80BF31;
L_80BF31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF31u,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF31u, 5u, 3u, cpu.address("abs", 0x09A0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF31 ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x9A0u), cpu.m8?8:16));
    goto L_80BF34;
L_80BF34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF34u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF34u, 5u, 3u, cpu.address("abs", 0x091Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF34 STA
    hw.write(cpu.address("abs", 0x91Au), cpu.a, cpu.m8?8:16);
    goto L_80BF37;
L_80BF37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF37u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF37u, 5u, 3u, cpu.address("abs", 0x098Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF37 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x98Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BF3A;
L_80BF3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF3Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF3Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF3A BEQ -> $80BF5E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BF5E; }
    goto L_80BF3C;
L_80BF3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF3Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF3Cu, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF3C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x986u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BF3F;
L_80BF3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF3Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF3Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF3F BNE -> $80BF5E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BF5E; }
    goto L_80BF41;
L_80BF41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF41u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF41u, 5u, 3u, cpu.address("abs", 0x091Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF41 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x91Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BF44;
L_80BF44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF44u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF44u, 5u, 3u, cpu.address("abs", 0x0990u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF44 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x990u), cpu.m8?8:16));
    goto L_80BF47;
L_80BF47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF47u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF47u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF47 BCS -> $80BF5E
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80BF5E; }
    goto L_80BF49;
L_80BF49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF49u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF49u, 5u, 3u, cpu.address("abs", 0x091Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF49 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x91Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BF4C;
L_80BF4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF4Cu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF4Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF4C SEC
    cpu.setFlag('C', true);
    goto L_80BF4D;
L_80BF4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF4Du,cpu,0xEDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF4Du, 5u, 3u, cpu.address("abs", 0x0992u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF4D SBC
    cpu.sbc(hw.readW(cpu.address("abs", 0x992u), cpu.m8?8:16));
    goto L_80BF50;
L_80BF50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF50u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF50u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF50 BMI -> $80BF59
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BF59; }
    goto L_80BF52;
L_80BF52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF52u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF52u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF52 CMP
    cpu.compareA(0x19u);
    goto L_80BF55;
L_80BF55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF55u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF55u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF55 BCC -> $80BF65
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80BF65; }
    goto L_80BF57;
L_80BF57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF57u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF57u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF57 BRA -> $80BF5E
    goto L_80BF5E;
L_80BF59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF59u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF59u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF59 CMP
    cpu.compareA(0xFFE7u);
    goto L_80BF5C;
L_80BF5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF5Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF5Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF5C BCS -> $80BF65
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80BF65; }
    goto L_80BF5E;
L_80BF5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF5Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF5Eu, 6u, 3u, cpu.address("abs", 0xBF67u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BF5E JSR -> $80BF67 stack real
    { cpu.push16Value(hw,0xBF60u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBF61u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBF67u), 0x80BF5Eu); }
    goto L_80BF61;
L_80BF61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF61u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF61u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF61u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF61 BCS -> $80BF65
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80BF65; }
    goto L_80BF63;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF61u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF61u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF61 BCS -> $80BF65
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80BF65; }
    goto L_80BF63;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF61u,0x80BF61u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BF63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF63u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF63u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF63u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF63 CLC
    cpu.setFlag('C', false);
    goto L_80BF64;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF63u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF63u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF63 CLC
    cpu.setFlag('C', false);
    goto L_80BF64;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF63u,0x80BF63u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BF64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF64u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF64u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BF64 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80BF64u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80BF64u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80BF65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF65u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF65u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF65u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF65 SEC
    cpu.setFlag('C', true);
    goto L_80BF66;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF65u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF65u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF65 SEC
    cpu.setFlag('C', true);
    goto L_80BF66;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF65u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF65u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF65 SEC
    cpu.setFlag('C', true);
    goto L_80BF66;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF65u,0x80BF65u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BF66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF66u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF66u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BF66 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80BF66u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80BF66u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_829860_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829860u: goto L_829860;
    case 0x829862u: goto L_829862;
    case 0x829865u: goto L_829865;
    case 0x829867u: goto L_829867;
    case 0x82986Au: goto L_82986A;
    case 0x82986Cu: goto L_82986C;
    case 0x82986Fu: goto L_82986F;
    case 0x829871u: goto L_829871;
    case 0x829874u: goto L_829874;
    case 0x829876u: goto L_829876;
    case 0x829879u: goto L_829879;
    case 0x82987Cu: goto L_82987C;
    case 0x82987Eu: goto L_82987E;
    case 0x829881u: goto L_829881;
    case 0x829883u: goto L_829883;
    case 0x829886u: goto L_829886;
    case 0x829888u: goto L_829888;
    case 0x829889u: goto L_829889;
    case 0x82988Cu: goto L_82988C;
    case 0x82988Eu: goto L_82988E;
    case 0x829890u: goto L_829890;
    case 0x829894u: goto L_829894;
    case 0x829895u: goto L_829895;
    case 0x829896u: goto L_829896;
    case 0x829898u: goto L_829898;
    case 0x82989Au: goto L_82989A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829860:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9860u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9860u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9860u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829860 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829862;
L_829862:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9862u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9862u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9862u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829862 LDA
    cpu.setA(0x2u, 16);
    goto L_829865;
L_829865:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9865u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9865u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9865u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829865 STA
    hw.write(cpu.address("dp", 0x1Fu), cpu.a, cpu.m8?8:16);
    goto L_829867;
L_829867:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9867u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9867u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9867u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829867 LDA
    cpu.setA(0x81CCu, 16);
    goto L_82986A;
L_82986A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x986Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x986Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x986Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82986A STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82986C;
L_82986C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x986Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x986Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x986Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82986C LDA
    cpu.setA(0x9Eu, 16);
    goto L_82986F;
L_82986F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x986Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x986Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x986Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82986F STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_829871;
L_829871:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9871u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9871u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9871u, 5u + 1u, 3u, cpu.address("absx", 0x0418u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829871 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x418u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829874;
L_829874:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9874u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9874u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9874u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829874 BMI -> $829894
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_829894; }
    goto L_829876;
L_829876:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9876u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9876u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9876u, 5u + 1u, 3u, cpu.address("absx", 0x02C2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829876 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2C2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829879;
L_829879:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9879u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9879u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9879u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829879 AND
    cpu.logicAnd(0xFFu);
    goto L_82987C;
L_82987C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x987Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x987Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x987Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82987C BEQ -> $829894
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_829894; }
    goto L_82987E;
L_82987E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x987Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x987Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x987Eu, 5u + 1u, 3u, cpu.address("absx", 0x02B0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82987E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2B0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829881;
L_829881:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9881u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9881u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9881u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829881 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_829883;
L_829883:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9883u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9883u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9883u, 5u + 1u, 3u, cpu.address("absx", 0x02B6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829883 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2B6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829886;
L_829886:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9886u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9886u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9886u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829886 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_829888;
L_829888:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9888u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9888u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9888u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829888 TXA
    cpu.transfer("TXA");
    goto L_829889;
L_829889:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9889u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9889u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9889u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829889 ORA
    cpu.logicOr(0x8u);
    goto L_82988C;
L_82988C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x988Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x988Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x988Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82988C STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_82988E;
L_82988E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x988Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x988Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x988Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82988E STZ
    hw.write(cpu.address("dp", 0x4u), 0, cpu.m8?8:16);
    goto L_829890;
L_829890:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9890u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9890u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9890u, 8u, 4u, 0x808886u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829890 JSL -> $808886 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9893u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9894u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808886u, 0x829890u); }
    goto L_829894;
L_829894:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9894u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9894u,0x829894u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9894u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9894u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829894 INX
    cpu.inc('X');
    goto L_829895;
L_829895:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9895u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9895u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9895u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829895 INX
    cpu.inc('X');
    goto L_829896;
L_829896:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9896u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9896u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9896u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Fu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829896 DEC
    cpu.decMem(hw, cpu.address("dp", 0x1Fu), cpu.m8?8:16);
    goto L_829898;
L_829898:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9898u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9898u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9898u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829898 BPL -> $829871
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_829871; }
    goto L_82989A;
L_82989A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x989Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x989Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x989Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82989A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82989Au);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82989Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82A723_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82A723u: goto L_82A723;
    case 0x82A725u: goto L_82A725;
    case 0x82A726u: goto L_82A726;
    case 0x82A728u: goto L_82A728;
    case 0x82A729u: goto L_82A729;
    case 0x82A72Au: goto L_82A72A;
    case 0x82A72Eu: goto L_82A72E;
    case 0x82A72Fu: goto L_82A72F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82A723:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA723u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA723u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA723u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A723 LDA
    cpu.setA(0x0u, 8);
    goto L_82A725;
L_82A725:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA725u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA725u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA725u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A725 XBA
    cpu.xba();
    goto L_82A726;
L_82A726:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA726u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA726u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA726u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $82A726 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A728;
L_82A728:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA728u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA728u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA728u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A728 PHX
    cpu.push("PHX", hw);
    goto L_82A729;
L_82A729:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA729u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA729u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA729u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A729 TAX
    cpu.transfer("TAX");
    goto L_82A72A;
L_82A72A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA72Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA72Au,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA72Au, 5u, 4u, ((0x82A730u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A72A LDA
    cpu.loadA(hw.readW(((0x82A730u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A72E;
L_82A72E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA72Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA72Eu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA72Eu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A72E PLX
    cpu.pop("PLX", hw);
    goto L_82A72F;
L_82A72F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA72Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA72Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA72Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A72F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A72Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A72Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82AA07_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82AA07u: goto L_82AA07;
    case 0x82AA08u: goto L_82AA08;
    case 0x82AA0Au: goto L_82AA0A;
    case 0x82AA0Cu: goto L_82AA0C;
    case 0x82AA0Du: goto L_82AA0D;
    case 0x82AA0Fu: goto L_82AA0F;
    case 0x82AA10u: goto L_82AA10;
    case 0x82AA13u: goto L_82AA13;
    case 0x82AA16u: goto L_82AA16;
    case 0x82AA18u: goto L_82AA18;
    case 0x82AA1Bu: goto L_82AA1B;
    case 0x82AA1Eu: goto L_82AA1E;
    case 0x82AA20u: goto L_82AA20;
    case 0x82AA23u: goto L_82AA23;
    case 0x82AA26u: goto L_82AA26;
    case 0x82AA29u: goto L_82AA29;
    case 0x82AA2Cu: goto L_82AA2C;
    case 0x82AA2Fu: goto L_82AA2F;
    case 0x82AA32u: goto L_82AA32;
    case 0x82AA35u: goto L_82AA35;
    case 0x82AA37u: goto L_82AA37;
    case 0x82AA3Au: goto L_82AA3A;
    case 0x82AA3Cu: goto L_82AA3C;
    case 0x82AA40u: goto L_82AA40;
    case 0x82AA43u: goto L_82AA43;
    case 0x82AA44u: goto L_82AA44;
    case 0x82AA47u: goto L_82AA47;
    case 0x82AA48u: goto L_82AA48;
    case 0x82AA4Bu: goto L_82AA4B;
    case 0x82AA4Eu: goto L_82AA4E;
    case 0x82AA51u: goto L_82AA51;
    case 0x82AA54u: goto L_82AA54;
    case 0x82AA56u: goto L_82AA56;
    case 0x82AA58u: goto L_82AA58;
    case 0x82AA5Au: goto L_82AA5A;
    case 0x82AA5Du: goto L_82AA5D;
    case 0x82AA60u: goto L_82AA60;
    case 0x82AA62u: goto L_82AA62;
    case 0x82AA65u: goto L_82AA65;
    case 0x82AA68u: goto L_82AA68;
    case 0x82AA6Bu: goto L_82AA6B;
    case 0x82AA6Eu: goto L_82AA6E;
    case 0x82AA71u: goto L_82AA71;
    case 0x82AA73u: goto L_82AA73;
    case 0x82AA76u: goto L_82AA76;
    case 0x82AA78u: goto L_82AA78;
    case 0x82AA7Cu: goto L_82AA7C;
    case 0x82AA7Fu: goto L_82AA7F;
    case 0x82AA80u: goto L_82AA80;
    case 0x82AA83u: goto L_82AA83;
    case 0x82AA84u: goto L_82AA84;
    case 0x82AA87u: goto L_82AA87;
    case 0x82AA8Au: goto L_82AA8A;
    case 0x82AA8Du: goto L_82AA8D;
    case 0x82AA8Fu: goto L_82AA8F;
    case 0x82AA92u: goto L_82AA92;
    case 0x82AA94u: goto L_82AA94;
    case 0x82AA97u: goto L_82AA97;
    case 0x82AA99u: goto L_82AA99;
    case 0x82AA9Du: goto L_82AA9D;
    case 0x82AAA0u: goto L_82AAA0;
    case 0x82AAA1u: goto L_82AAA1;
    case 0x82AAA4u: goto L_82AAA4;
    case 0x82AAA5u: goto L_82AAA5;
    case 0x82AAA8u: goto L_82AAA8;
    case 0x82AAABu: goto L_82AAAB;
    case 0x82AAAEu: goto L_82AAAE;
    case 0x82AAAFu: goto L_82AAAF;
    case 0x82AAB1u: goto L_82AAB1;
    case 0x82AAB5u: goto L_82AAB5;
    case 0x82AAB8u: goto L_82AAB8;
    case 0x82AAB9u: goto L_82AAB9;
    case 0x82AABCu: goto L_82AABC;
    case 0x82AABDu: goto L_82AABD;
    case 0x82AAC0u: goto L_82AAC0;
    case 0x82AAC3u: goto L_82AAC3;
    case 0x82AAC6u: goto L_82AAC6;
    case 0x82AAC7u: goto L_82AAC7;
    case 0x82AAC8u: goto L_82AAC8;
    case 0x82AAC9u: goto L_82AAC9;
    case 0x82AACAu: goto L_82AACA;
    case 0x82AACDu: goto L_82AACD;
    case 0x82AACEu: goto L_82AACE;
    case 0x82AAD1u: goto L_82AAD1;
    case 0x82AAD2u: goto L_82AAD2;
    case 0x82AAD5u: goto L_82AAD5;
    case 0x82AAD7u: goto L_82AAD7;
    case 0x82AADAu: goto L_82AADA;
    case 0x82AADCu: goto L_82AADC;
    case 0x82AADFu: goto L_82AADF;
    case 0x82AAE1u: goto L_82AAE1;
    case 0x82AAE5u: goto L_82AAE5;
    case 0x82AAE8u: goto L_82AAE8;
    case 0x82AAEAu: goto L_82AAEA;
    case 0x82AAEEu: goto L_82AAEE;
    case 0x82AAF1u: goto L_82AAF1;
    case 0x82AAF2u: goto L_82AAF2;
    case 0x82AAF5u: goto L_82AAF5;
    case 0x82AAF6u: goto L_82AAF6;
    case 0x82AAF9u: goto L_82AAF9;
    case 0x82AAFCu: goto L_82AAFC;
    case 0x82AAFDu: goto L_82AAFD;
    case 0x82AB00u: goto L_82AB00;
    case 0x82AB01u: goto L_82AB01;
    case 0x82AB04u: goto L_82AB04;
    case 0x82AB05u: goto L_82AB05;
    case 0x82AB08u: goto L_82AB08;
    case 0x82AB09u: goto L_82AB09;
    case 0x82AB0Au: goto L_82AB0A;
    case 0x82AB0Du: goto L_82AB0D;
    case 0x82AB0Eu: goto L_82AB0E;
    case 0x82AB11u: goto L_82AB11;
    case 0x82AB15u: goto L_82AB15;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82AA07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA07u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA07u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82AA07 PHB
    cpu.push("PHB", hw);
    goto L_82AA08;
L_82AA08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA08u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA08u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA08 SEP
    cpu.sep(0x20u);
    goto L_82AA0A;
L_82AA0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA0A LDA
    cpu.setA(0x7Eu, 8);
    goto L_82AA0C;
L_82AA0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Cu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82AA0C PHA
    cpu.push("PHA", hw);
    goto L_82AA0D;
L_82AA0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA0D REP
    cpu.rep(0x20u);
    goto L_82AA0F;
L_82AA0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Fu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Fu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82AA0F PLB
    cpu.pop("PLB", hw);
    goto L_82AA10;
L_82AA10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA10u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA10u, 5u, 3u, cpu.address("abs", 0x0150u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA10 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x150u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AA13;
L_82AA13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA13u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA13u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA13 CMP
    cpu.compareA(0xFu);
    goto L_82AA16;
L_82AA16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA16u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA16u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA16 BCC -> $82AA32
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82AA32; }
    goto L_82AA18;
L_82AA18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA18u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA18u, 5u, 3u, cpu.address("abs", 0x014Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA18 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x14Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AA1B;
L_82AA1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA1B CMP
    cpu.compareA(0x4236u);
    goto L_82AA1E;
L_82AA1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA1E BCC -> $82AA32
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82AA32; }
    goto L_82AA20;
L_82AA20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA20u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA20u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA20 LDA
    cpu.setA(0xFu, 16);
    goto L_82AA23;
L_82AA23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA23u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA23u, 5u, 3u, cpu.address("abs", 0x0150u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA23 STA
    hw.write(cpu.address("abs", 0x150u), cpu.a, cpu.m8?8:16);
    goto L_82AA26;
L_82AA26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA26u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA26u, 5u, 3u, cpu.address("abs", 0x0154u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA26 STA
    hw.write(cpu.address("abs", 0x154u), cpu.a, cpu.m8?8:16);
    goto L_82AA29;
L_82AA29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA29u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA29u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA29 LDA
    cpu.setA(0x4236u, 16);
    goto L_82AA2C;
L_82AA2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Cu, 5u, 3u, cpu.address("abs", 0x014Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA2C STA
    hw.write(cpu.address("abs", 0x14Eu), cpu.a, cpu.m8?8:16);
    goto L_82AA2F;
L_82AA2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Fu, 5u, 3u, cpu.address("abs", 0x0152u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA2F STA
    hw.write(cpu.address("abs", 0x152u), cpu.a, cpu.m8?8:16);
    goto L_82AA32;
L_82AA32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA32u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA32u, 5u, 3u, cpu.address("abs", 0x014Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA32 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x14Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AA35;
L_82AA35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA35u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA35u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA35 STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_82AA37;
L_82AA37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA37u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA37u, 5u, 3u, cpu.address("abs", 0x0150u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA37 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x150u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AA3A;
L_82AA3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA3Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA3Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA3A STA
    hw.write(cpu.address("dp", 0x38u), cpu.a, cpu.m8?8:16);
    goto L_82AA3C;
L_82AA3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA3Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA3Cu, 8u, 4u, 0x80935Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AA3C JSL -> $80935E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAA3Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAA40u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80935Eu, 0x82AA3Cu); }
    goto L_82AA40;
L_82AA40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA40u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAA40u,0x82AA40u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA40u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA40u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA40 LDA
    cpu.setA(0x2C4u, 16);
    goto L_82AA43;
L_82AA43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA43u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA43u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA43 CLC
    cpu.setFlag('C', false);
    goto L_82AA44;
L_82AA44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA44u,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA44u, 5u, 3u, cpu.address("abs", 0x013Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA44 ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x13Fu), cpu.m8?8:16));
    goto L_82AA47;
L_82AA47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA47u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA47u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA47 TAY
    cpu.transfer("TAY");
    goto L_82AA48;
L_82AA48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA48u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA48u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA48 LDX
    cpu.setX(0x5u, 16);
    goto L_82AA4B;
L_82AA4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Bu, 6u, 3u, cpu.address("abs", 0xAB2Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AA4B JSR -> $82AB2E stack real
    { cpu.push16Value(hw,0xAA4Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAA4Eu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAB2Eu), 0x82AA4Bu); }
    goto L_82AA4E;
L_82AA4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA4Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAA4Eu,0x82AA4Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Eu, 5u, 3u, cpu.address("abs", 0x0150u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA4E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x150u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AA51;
L_82AA51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA51u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA51u, 5u, 3u, cpu.address("abs", 0x0154u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA51 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x154u), cpu.m8?8:16));
    goto L_82AA54;
L_82AA54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA54u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA54u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA54 BEQ -> $82AA5A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82AA5A; }
    goto L_82AA56;
L_82AA56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA56u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA56u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA56 BCS -> $82AA62
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82AA62; }
    goto L_82AA58;
L_82AA58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA58u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA58u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA58 BRA -> $82AA6E
    goto L_82AA6E;
L_82AA5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA5Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA5Au, 5u, 3u, cpu.address("abs", 0x014Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA5A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x14Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AA5D;
L_82AA5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA5Du,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA5Du, 5u, 3u, cpu.address("abs", 0x0152u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA5D CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x152u), cpu.m8?8:16));
    goto L_82AA60;
L_82AA60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA60u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA60u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA60 BCC -> $82AA6E
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82AA6E; }
    goto L_82AA62;
L_82AA62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA62u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA62u, 5u, 3u, cpu.address("abs", 0x014Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA62 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x14Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AA65;
L_82AA65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA65u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA65u, 5u, 3u, cpu.address("abs", 0x0152u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA65 STA
    hw.write(cpu.address("abs", 0x152u), cpu.a, cpu.m8?8:16);
    goto L_82AA68;
L_82AA68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA68u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA68u, 5u, 3u, cpu.address("abs", 0x0150u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA68 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x150u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AA6B;
L_82AA6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA6Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA6Bu, 5u, 3u, cpu.address("abs", 0x0154u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA6B STA
    hw.write(cpu.address("abs", 0x154u), cpu.a, cpu.m8?8:16);
    goto L_82AA6E;
L_82AA6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA6Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA6Eu, 5u, 3u, cpu.address("abs", 0x0152u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA6E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x152u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AA71;
L_82AA71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA71u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA71u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA71 STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_82AA73;
L_82AA73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA73u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA73u, 5u, 3u, cpu.address("abs", 0x0154u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA73 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x154u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AA76;
L_82AA76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA76u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA76u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA76 STA
    hw.write(cpu.address("dp", 0x38u), cpu.a, cpu.m8?8:16);
    goto L_82AA78;
L_82AA78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA78u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA78u, 8u, 4u, 0x80935Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AA78 JSL -> $80935E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAA7Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAA7Cu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80935Eu, 0x82AA78u); }
    goto L_82AA7C;
L_82AA7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA7Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAA7Cu,0x82AA7Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA7Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA7Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA7C LDA
    cpu.setA(0x3C4u, 16);
    goto L_82AA7F;
L_82AA7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA7Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA7Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA7F CLC
    cpu.setFlag('C', false);
    goto L_82AA80;
L_82AA80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA80u,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA80u, 5u, 3u, cpu.address("abs", 0x013Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA80 ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x13Fu), cpu.m8?8:16));
    goto L_82AA83;
L_82AA83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA83u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA83u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA83 TAY
    cpu.transfer("TAY");
    goto L_82AA84;
L_82AA84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA84u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA84u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA84 LDX
    cpu.setX(0x5u, 16);
    goto L_82AA87;
L_82AA87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA87u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA87u, 6u, 3u, cpu.address("abs", 0xAB2Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AA87 JSR -> $82AB2E stack real
    { cpu.push16Value(hw,0xAA89u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAA8Au,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAB2Eu), 0x82AA87u); }
    goto L_82AA8A;
L_82AA8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA8Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAA8Au,0x82AA8Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA8Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA8Au, 5u, 3u, cpu.address("abs", 0x017Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA8A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x17Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AA8D;
L_82AA8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA8Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA8Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA8D BEQ -> $82AAAB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82AAAB; }
    goto L_82AA8F;
L_82AA8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA8Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA8Fu, 5u, 3u, cpu.address("abs", 0x0156u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA8F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x156u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AA92;
L_82AA92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA92u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA92u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA92 STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_82AA94;
L_82AA94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA94u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA94u, 5u, 3u, cpu.address("abs", 0x0158u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA94 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x158u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AA97;
L_82AA97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA97u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA97u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA97 STA
    hw.write(cpu.address("dp", 0x38u), cpu.a, cpu.m8?8:16);
    goto L_82AA99;
L_82AA99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA99u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA99u, 8u, 4u, 0x80935Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AA99 JSL -> $80935E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAA9Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAA9Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80935Eu, 0x82AA99u); }
    goto L_82AA9D;
L_82AA9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA9Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAA9Du,0x82AA9Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA9Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA9Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AA9D LDA
    cpu.setA(0xC4u, 16);
    goto L_82AAA0;
L_82AAA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA0u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAA0 CLC
    cpu.setFlag('C', false);
    goto L_82AAA1;
L_82AAA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA1u,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA1u, 5u, 3u, cpu.address("abs", 0x013Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAA1 ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x13Fu), cpu.m8?8:16));
    goto L_82AAA4;
L_82AAA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA4u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAA4 TAY
    cpu.transfer("TAY");
    goto L_82AAA5;
L_82AAA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA5u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAA5 LDX
    cpu.setX(0x5u, 16);
    goto L_82AAA8;
L_82AAA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAA8u, 6u, 3u, cpu.address("abs", 0xAB2Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AAA8 JSR -> $82AB2E stack real
    { cpu.push16Value(hw,0xAAAAu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAAABu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAB2Eu), 0x82AAA8u); }
    goto L_82AAAB;
L_82AAAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAABu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAAABu,0x82AAABu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAABu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAABu, 5u, 3u, cpu.address("abs", 0x02CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAAB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2CEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AAAE;
L_82AAAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAAEu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAAEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAAE INC
    cpu.inc('A');
    goto L_82AAAF;
L_82AAAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAAFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAAFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAAF STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_82AAB1;
L_82AAB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB1u, 8u, 4u, 0x809315u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AAB1 JSL -> $809315 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAAB4u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAAB5u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809315u, 0x82AAB1u); }
    goto L_82AAB5;
L_82AAB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAB5u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAAB5u,0x82AAB5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAB5 LDA
    cpu.setA(0x2F4u, 16);
    goto L_82AAB8;
L_82AAB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB8u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAB8 CLC
    cpu.setFlag('C', false);
    goto L_82AAB9;
L_82AAB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB9u,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAB9u, 5u, 3u, cpu.address("abs", 0x013Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAB9 ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x13Fu), cpu.m8?8:16));
    goto L_82AABC;
L_82AABC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAABCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAABCu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAABCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AABC TAY
    cpu.transfer("TAY");
    goto L_82AABD;
L_82AABD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAABDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAABDu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAABDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AABD LDX
    cpu.setX(0x1u, 16);
    goto L_82AAC0;
L_82AAC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC0u, 6u, 3u, cpu.address("abs", 0xAB2Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AAC0 JSR -> $82AB2E stack real
    { cpu.push16Value(hw,0xAAC2u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAAC3u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAB2Eu), 0x82AAC0u); }
    goto L_82AAC3;
L_82AAC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAC3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAAC3u,0x82AAC3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC3u, 5u, 3u, cpu.address("abs", 0x02A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAC3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2A2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AAC6;
L_82AAC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAC6 ASL
    cpu.aslA();
    goto L_82AAC7;
L_82AAC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAC7 ASL
    cpu.aslA();
    goto L_82AAC8;
L_82AAC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC8u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAC8 ASL
    cpu.aslA();
    goto L_82AAC9;
L_82AAC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC9u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAC9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAC9 TAY
    cpu.transfer("TAY");
    goto L_82AACA;
L_82AACA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAACAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAACAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAACAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AACA LDA
    cpu.setA(0x3F0u, 16);
    goto L_82AACD;
L_82AACD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAACDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAACDu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAACDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AACD CLC
    cpu.setFlag('C', false);
    goto L_82AACE;
L_82AACE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAACEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAACEu,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAACEu, 5u, 3u, cpu.address("abs", 0x013Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AACE ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x13Fu), cpu.m8?8:16));
    goto L_82AAD1;
L_82AAD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD1u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAD1 TAX
    cpu.transfer("TAX");
    goto L_82AAD2;
L_82AAD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAD2 LDA
    cpu.setA(0xAB16u, 16);
    goto L_82AAD5;
L_82AAD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAD5 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82AAD7;
L_82AAD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAD7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAD7 LDA
    cpu.setA(0x82u, 16);
    goto L_82AADA;
L_82AADA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAADAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAADAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAADAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AADA STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82AADC;
L_82AADC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAADCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAADCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAADCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AADC LDA
    cpu.setA(0x3400u, 16);
    goto L_82AADF;
L_82AADF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAADFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAADFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAADFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AADF STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_82AAE1;
L_82AAE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE1u, 8u, 4u, 0x809BD0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AAE1 JSL -> $809BD0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAAE4u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAAE5u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809BD0u, 0x82AAE1u); }
    goto L_82AAE5;
L_82AAE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAE5u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAAE5u,0x82AAE5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE5u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE5u, 5u, 3u, cpu.address("abs", 0x02A4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAE5 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2A4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AAE8;
L_82AAE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAE8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAE8 STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_82AAEA;
L_82AAEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAEAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAEAu, 8u, 4u, 0x809315u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AAEA JSL -> $809315 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAAEDu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAAEEu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809315u, 0x82AAEAu); }
    goto L_82AAEE;
L_82AAEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAEEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAAEEu,0x82AAEEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAEEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAEEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAEE LDA
    cpu.setA(0x3F6u, 16);
    goto L_82AAF1;
L_82AAF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF1u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAF1 CLC
    cpu.setFlag('C', false);
    goto L_82AAF2;
L_82AAF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF2u,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF2u, 5u, 3u, cpu.address("abs", 0x013Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAF2 ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x13Fu), cpu.m8?8:16));
    goto L_82AAF5;
L_82AAF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF5u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAF5 TAY
    cpu.transfer("TAY");
    goto L_82AAF6;
L_82AAF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF6u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAF6 LDX
    cpu.setX(0x1u, 16);
    goto L_82AAF9;
L_82AAF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAF9u, 6u, 3u, cpu.address("abs", 0xAB2Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AAF9 JSR -> $82AB2E stack real
    { cpu.push16Value(hw,0xAAFBu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAAFCu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAB2Eu), 0x82AAF9u); }
    goto L_82AAFC;
L_82AAFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAFCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAAFCu,0x82AAFCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAFCu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAFCu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82AAFC PLB
    cpu.pop("PLB", hw);
    goto L_82AAFD;
L_82AAFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAAFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAAFDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAAFDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AAFD LDA
    cpu.setA(0x2800u, 16);
    goto L_82AB00;
L_82AB00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB00u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB00u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AB00 CLC
    cpu.setFlag('C', false);
    goto L_82AB01;
L_82AB01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB01u,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB01u, 5u, 3u, cpu.address("abs", 0x013Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AB01 ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x13Fu), cpu.m8?8:16));
    goto L_82AB04;
L_82AB04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB04u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB04u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AB04 TAX
    cpu.transfer("TAX");
    goto L_82AB05;
L_82AB05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB05u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB05u, 5u, 3u, cpu.address("abs", 0x013Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AB05 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AB08;
L_82AB08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB08u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB08u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AB08 LSR
    cpu.lsrA();
    goto L_82AB09;
L_82AB09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB09u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB09u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AB09 CLC
    cpu.setFlag('C', false);
    goto L_82AB0A;
L_82AB0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB0Au,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB0Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AB0A ADC
    cpu.adc(0x5000u);
    goto L_82AB0D;
L_82AB0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB0Du,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB0Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AB0D TAY
    cpu.transfer("TAY");
    goto L_82AB0E;
L_82AB0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB0Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB0Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AB0E LDA
    cpu.setA(0x800u, 16);
    goto L_82AB11;
L_82AB11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB11u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB11u, 8u, 4u, 0x808EBFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AB11 JSL -> $808EBF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAB14u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAB15u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808EBFu, 0x82AB11u); }
    goto L_82AB15;
L_82AB15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB15u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAB15u,0x82AB15u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB15u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB15u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AB15 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82AB15u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82AB15u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B969_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B969u: goto L_82B969;
    case 0x82B96Cu: goto L_82B96C;
    case 0x82B96Eu: goto L_82B96E;
    case 0x82B971u: goto L_82B971;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B969:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB969u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB969u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB969u, 6u, 3u, cpu.address("abs", 0xB98Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B969 JSR -> $82B98E stack real
    { cpu.push16Value(hw,0xB96Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB96Cu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB98Eu), 0x82B969u); }
    goto L_82B96C;
L_82B96C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB96Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB96Cu,0x82B96Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Cu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B96C LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B96E;
L_82B96E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB96Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Eu, 6u, 3u, cpu.address("abs", 0xB9B0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B96E JSR -> $82B9B0 stack real
    { cpu.push16Value(hw,0xB970u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB971u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB9B0u), 0x82B96Eu); }
    goto L_82B971;
L_82B971:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB971u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB971u,0x82B971u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB971u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB971u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B971 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B971u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B971u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82BA5D_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82BA5Du: goto L_82BA5D;
    case 0x82BA60u: goto L_82BA60;
    case 0x82BA62u: goto L_82BA62;
    case 0x82BA64u: goto L_82BA64;
    case 0x82BA65u: goto L_82BA65;
    case 0x82BA66u: goto L_82BA66;
    case 0x82BA67u: goto L_82BA67;
    case 0x82BA68u: goto L_82BA68;
    case 0x82BA6Au: goto L_82BA6A;
    case 0x82BA6Du: goto L_82BA6D;
    case 0x82BA6Fu: goto L_82BA6F;
    case 0x82BA70u: goto L_82BA70;
    case 0x82BA71u: goto L_82BA71;
    case 0x82BA72u: goto L_82BA72;
    case 0x82BA73u: goto L_82BA73;
    case 0x82BA75u: goto L_82BA75;
    case 0x82BA78u: goto L_82BA78;
    case 0x82BA7Au: goto L_82BA7A;
    case 0x82BA7Du: goto L_82BA7D;
    case 0x82BA81u: goto L_82BA81;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82BA5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA5Du,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA5Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA5D LDY
    cpu.setY(0x0u, 16);
    goto L_82BA60;
L_82BA60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA60u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA60u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA60u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82BA60 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BA62;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA60u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA60u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82BA60 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BA62;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA60u,0x82BA60u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82BA62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA62u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA62u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA62u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA62 BMI -> $82BA7A
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82BA7A; }
    goto L_82BA64;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA62u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA62u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA62 BMI -> $82BA7A
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82BA7A; }
    goto L_82BA64;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA62u,0x82BA62u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82BA64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA64u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA64u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA64u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA64 INY
    cpu.inc('Y');
    goto L_82BA65;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA64u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA64u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA64 INY
    cpu.inc('Y');
    goto L_82BA65;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA64u,0x82BA64u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82BA65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA65u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA65u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA65u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA65 INY
    cpu.inc('Y');
    goto L_82BA66;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA65u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA65u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA65 INY
    cpu.inc('Y');
    goto L_82BA66;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA65u,0x82BA65u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82BA66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA66u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA66u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA66u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA66 INY
    cpu.inc('Y');
    goto L_82BA67;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA66u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA66u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA66 INY
    cpu.inc('Y');
    goto L_82BA67;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA66u,0x82BA66u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82BA67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA67u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA67u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA67u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA67 INY
    cpu.inc('Y');
    goto L_82BA68;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA67u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA67u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA67 INY
    cpu.inc('Y');
    goto L_82BA68;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA67u,0x82BA67u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82BA68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA68u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA68u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA68u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82BA68 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BA6A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA68u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA68u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82BA68 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BA6A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA68u,0x82BA68u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82BA6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA6Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA6Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA6Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA6A CMP
    cpu.compareA(0x5u);
    goto L_82BA6D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA6Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA6Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA6A CMP
    cpu.compareA(0x5u);
    goto L_82BA6D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA6Au,0x82BA6Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82BA6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA6Du,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA6Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA6D BCS -> $82BA75
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82BA75; }
    goto L_82BA6F;
L_82BA6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA6Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA6Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA6F INY
    cpu.inc('Y');
    goto L_82BA70;
L_82BA70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA70u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA70u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA70 INY
    cpu.inc('Y');
    goto L_82BA71;
L_82BA71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA71u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA71u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA71 INY
    cpu.inc('Y');
    goto L_82BA72;
L_82BA72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA72u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA72u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA72 INY
    cpu.inc('Y');
    goto L_82BA73;
L_82BA73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA73u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA73u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA73 BRA -> $82BA60
    goto L_82BA60;
L_82BA75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA75u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA75u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA75 LDA
    cpu.setA(0x3Au, 16);
    goto L_82BA78;
L_82BA78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA78u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA78u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA78 BRA -> $82BA7D
    goto L_82BA7D;
L_82BA7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA7Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA7A LDA
    cpu.setA(0x3Fu, 16);
    goto L_82BA7D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA7A LDA
    cpu.setA(0x3Fu, 16);
    goto L_82BA7D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA7Au,0x82BA7Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82BA7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA7Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Du, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82BA7D JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBA80u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBA81u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x82BA7Du); }
    goto L_82BA81;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Du, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82BA7D JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBA80u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBA81u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x82BA7Du); }
    goto L_82BA81;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA7Du,0x82BA7Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82BA81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA81u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA81u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA81u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82BA81 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82BA81u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82BA81u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA81u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA81u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82BA81 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82BA81u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82BA81u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA81u,0x82BA81u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82BA5D_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82BA5Du: goto L_82BA5D;
    case 0x82BA60u: goto L_82BA60;
    case 0x82BA62u: goto L_82BA62;
    case 0x82BA64u: goto L_82BA64;
    case 0x82BA65u: goto L_82BA65;
    case 0x82BA66u: goto L_82BA66;
    case 0x82BA67u: goto L_82BA67;
    case 0x82BA68u: goto L_82BA68;
    case 0x82BA6Au: goto L_82BA6A;
    case 0x82BA6Du: goto L_82BA6D;
    case 0x82BA6Fu: goto L_82BA6F;
    case 0x82BA70u: goto L_82BA70;
    case 0x82BA71u: goto L_82BA71;
    case 0x82BA72u: goto L_82BA72;
    case 0x82BA73u: goto L_82BA73;
    case 0x82BA75u: goto L_82BA75;
    case 0x82BA78u: goto L_82BA78;
    case 0x82BA7Au: goto L_82BA7A;
    case 0x82BA7Du: goto L_82BA7D;
    case 0x82BA81u: goto L_82BA81;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82BA5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA5Du,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA5Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA5D LDY
    cpu.setY(0x0u, 16);
    goto L_82BA60;
L_82BA60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA60u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA60u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82BA60 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BA62;
L_82BA62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA62u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA62u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA62 BMI -> $82BA7A
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82BA7A; }
    goto L_82BA64;
L_82BA64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA64u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA64u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA64 INY
    cpu.inc('Y');
    goto L_82BA65;
L_82BA65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA65u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA65u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA65 INY
    cpu.inc('Y');
    goto L_82BA66;
L_82BA66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA66u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA66u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA66 INY
    cpu.inc('Y');
    goto L_82BA67;
L_82BA67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA67u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA67u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA67 INY
    cpu.inc('Y');
    goto L_82BA68;
L_82BA68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA68u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA68u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82BA68 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BA6A;
L_82BA6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA6Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA6Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA6A CMP
    cpu.compareA(0x5u);
    goto L_82BA6D;
L_82BA6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA6Du,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA6Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA6D BCS -> $82BA75
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82BA75; }
    goto L_82BA6F;
L_82BA6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA6Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA6Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA6F INY
    cpu.inc('Y');
    goto L_82BA70;
L_82BA70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA70u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA70u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA70 INY
    cpu.inc('Y');
    goto L_82BA71;
L_82BA71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA71u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA71u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA71 INY
    cpu.inc('Y');
    goto L_82BA72;
L_82BA72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA72u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA72u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA72 INY
    cpu.inc('Y');
    goto L_82BA73;
L_82BA73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA73u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA73u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA73 BRA -> $82BA60
    goto L_82BA60;
L_82BA75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA75u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA75u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA75 LDA
    cpu.setA(0x3Au, 16);
    goto L_82BA78;
L_82BA78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA78u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA78u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA78 BRA -> $82BA7D
    goto L_82BA7D;
L_82BA7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA7A LDA
    cpu.setA(0x3Fu, 16);
    goto L_82BA7D;
L_82BA7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Du, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82BA7D JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBA80u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBA81u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x82BA7Du); }
    goto L_82BA81;
L_82BA81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA81u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA81u,0x82BA81u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA81u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA81u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82BA81 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82BA81u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82BA81u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82BB9A_E0M1X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82BB9Au: goto L_82BB9A;
    case 0x82BB9Cu: goto L_82BB9C;
    case 0x82BB9Fu: goto L_82BB9F;
    case 0x82BBA2u: goto L_82BBA2;
    case 0x82BBA5u: goto L_82BBA5;
    case 0x82BBA8u: goto L_82BBA8;
    case 0x82BBABu: goto L_82BBAB;
    case 0x82BBAEu: goto L_82BBAE;
    case 0x82BBB2u: goto L_82BBB2;
    case 0x82BBB5u: goto L_82BBB5;
    case 0x82BBB7u: goto L_82BBB7;
    case 0x82BBBAu: goto L_82BBBA;
    case 0x82BBBDu: goto L_82BBBD;
    case 0x82BBC0u: goto L_82BBC0;
    case 0x82BBC2u: goto L_82BBC2;
    case 0x82BBC5u: goto L_82BBC5;
    case 0x82BBC7u: goto L_82BBC7;
    case 0x82BBCAu: goto L_82BBCA;
    case 0x82BBCCu: goto L_82BBCC;
    case 0x82BBCFu: goto L_82BBCF;
    case 0x82BBD1u: goto L_82BBD1;
    case 0x82BBD4u: goto L_82BBD4;
    case 0x82BBD7u: goto L_82BBD7;
    case 0x82BBDAu: goto L_82BBDA;
    case 0x82BBDEu: goto L_82BBDE;
    case 0x82BBE0u: goto L_82BBE0;
    case 0x82BBE1u: goto L_82BBE1;
    case 0x82BBE2u: goto L_82BBE2;
    case 0x82BBE3u: goto L_82BBE3;
    case 0x82BBE4u: goto L_82BBE4;
    case 0x82BBE6u: goto L_82BBE6;
    case 0x82BBE8u: goto L_82BBE8;
    case 0x82BBEAu: goto L_82BBEA;
    case 0x82BBEDu: goto L_82BBED;
    case 0x82BBEFu: goto L_82BBEF;
    case 0x82BBF2u: goto L_82BBF2;
    case 0x82BBF5u: goto L_82BBF5;
    case 0x82BBF6u: goto L_82BBF6;
    case 0x82BBF8u: goto L_82BBF8;
    case 0x82BBFAu: goto L_82BBFA;
    case 0x82BBFBu: goto L_82BBFB;
    case 0x82BBFDu: goto L_82BBFD;
    case 0x82BC00u: goto L_82BC00;
    case 0x82BC02u: goto L_82BC02;
    case 0x82BC05u: goto L_82BC05;
    case 0x82BC08u: goto L_82BC08;
    case 0x82BC0Bu: goto L_82BC0B;
    case 0x82BC0Du: goto L_82BC0D;
    case 0x82BC0Eu: goto L_82BC0E;
    case 0x82BC0Fu: goto L_82BC0F;
    case 0x82BC11u: goto L_82BC11;
    case 0x82BC13u: goto L_82BC13;
    case 0x82BC16u: goto L_82BC16;
    case 0x82BC18u: goto L_82BC18;
    case 0x82BC1Bu: goto L_82BC1B;
    case 0x82BC1Eu: goto L_82BC1E;
    case 0x82BC1Fu: goto L_82BC1F;
    case 0x82BC20u: goto L_82BC20;
    case 0x82BC22u: goto L_82BC22;
    case 0x82BC26u: goto L_82BC26;
    case 0x82BC2Au: goto L_82BC2A;
    case 0x82BC2Cu: goto L_82BC2C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82BB9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB9Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB9Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB9A REP
    cpu.rep(0x20u);
    goto L_82BB9C;
L_82BB9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB9Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB9Cu, 5u, 3u, cpu.address("abs", 0x014Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB9C STZ
    hw.write(cpu.address("abs", 0x14Cu), 0, cpu.m8?8:16);
    goto L_82BB9F;
L_82BB9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB9Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB9Fu, 5u, 3u, cpu.address("abs", 0x0800u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB9F STZ
    hw.write(cpu.address("abs", 0x800u), 0, cpu.m8?8:16);
    goto L_82BBA2;
L_82BBA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBA2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBA2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBA2 LDA
    cpu.setA(0x7u, 16);
    goto L_82BBA5;
L_82BBA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBA5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBA5u, 5u, 3u, cpu.address("abs", 0x01D2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBA5 STA
    hw.write(cpu.address("abs", 0x1D2u), cpu.a, cpu.m8?8:16);
    goto L_82BBA8;
L_82BBA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBA8u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBA8u, 5u, 3u, cpu.address("abs", 0x018Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBA8 STZ
    hw.write(cpu.address("abs", 0x18Du), 0, cpu.m8?8:16);
    goto L_82BBAB;
L_82BBAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBABu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBABu, 5u, 3u, cpu.address("abs", 0x0193u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBAB STZ
    hw.write(cpu.address("abs", 0x193u), 0, cpu.m8?8:16);
    goto L_82BBAE;
L_82BBAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBAEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBAEu, 8u, 4u, 0x82DF3Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82BBAE JSL -> $82DF3C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBBB1u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBBB2u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82DF3Cu, 0x82BBAEu); }
    goto L_82BBB2;
L_82BBB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBB2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBBB2u,0x82BBB2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBB2u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBB2u, 5u, 3u, cpu.address("abs", 0x0665u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBB2 STZ
    hw.write(cpu.address("abs", 0x665u), 0, cpu.m8?8:16);
    goto L_82BBB5;
L_82BBB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBB5u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBB5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBB5 SEP
    cpu.sep(0x20u);
    goto L_82BBB7;
L_82BBB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBB7u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBB7u, 4u, 3u, cpu.address("abs", 0x01D7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBB7 STZ
    hw.write(cpu.address("abs", 0x1D7u), 0, cpu.m8?8:16);
    goto L_82BBBA;
L_82BBBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBBAu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBBAu, 4u, 3u, cpu.address("abs", 0x01D1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBBA STZ
    hw.write(cpu.address("abs", 0x1D1u), 0, cpu.m8?8:16);
    goto L_82BBBD;
L_82BBBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBBDu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBBDu, 4u, 3u, cpu.address("abs", 0x01CEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBBD STZ
    hw.write(cpu.address("abs", 0x1CEu), 0, cpu.m8?8:16);
    goto L_82BBC0;
L_82BBC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBC0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBC0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBC0 LDA
    cpu.setA(0x3Cu, 8);
    goto L_82BBC2;
L_82BBC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBC2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBC2u, 4u, 3u, cpu.address("abs", 0x01CFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBC2 STA
    hw.write(cpu.address("abs", 0x1CFu), cpu.a, cpu.m8?8:16);
    goto L_82BBC5;
L_82BBC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBC5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBC5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBC5 LDA
    cpu.setA(0x4u, 8);
    goto L_82BBC7;
L_82BBC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBC7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBC7u, 4u, 3u, cpu.address("abs", 0x01D0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBC7 STA
    hw.write(cpu.address("abs", 0x1D0u), cpu.a, cpu.m8?8:16);
    goto L_82BBCA;
L_82BBCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBCAu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBCAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBCA REP
    cpu.rep(0x20u);
    goto L_82BBCC;
L_82BBCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBCCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBCCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBCCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBCC LDA
    cpu.setA(0x4u, 16);
    goto L_82BBCF;
L_82BBCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBCFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBCFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBCF STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82BBD1;
L_82BBD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD1u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBD1 LDX
    cpu.setX(0x0u, 16);
    goto L_82BBD4;
L_82BBD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD4u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBD4 LDY
    cpu.setY(0x0u, 16);
    goto L_82BBD7;
L_82BBD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBD7u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD7u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD7u, 5u + 1u, 3u, cpu.address("absy", 0x1700u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBD7 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1700u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BBDA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD7u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD7u, 5u + 1u, 3u, cpu.address("absy", 0x1700u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBD7 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1700u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BBDA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBBD7u,0x82BBD7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82BBDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBDAu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBDAu,cpu,0xDFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBDAu, 6u, 4u, ((0x82BC2Du + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBDA CMP
    cpu.compareA(hw.readW(((0x82BC2Du + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_82BBDE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBDAu,cpu,0xDFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBDAu, 6u, 4u, ((0x82BC2Du + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBDA CMP
    cpu.compareA(hw.readW(((0x82BC2Du + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_82BBDE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBBDAu,0x82BBDAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82BBDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBDEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBDEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBDE BNE -> $82BC18
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82BC18; }
    goto L_82BBE0;
L_82BBE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE0u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBE0 INX
    cpu.inc('X');
    goto L_82BBE1;
L_82BBE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE1u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBE1 INX
    cpu.inc('X');
    goto L_82BBE2;
L_82BBE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE2u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBE2 INY
    cpu.inc('Y');
    goto L_82BBE3;
L_82BBE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE3u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBE3 INY
    cpu.inc('Y');
    goto L_82BBE4;
L_82BBE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE4u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE4u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBE4 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_82BBE6;
L_82BBE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBE6 BNE -> $82BBD7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82BBD7; }
    goto L_82BBE8;
L_82BBE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE8u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBE8 STY
    hw.write(cpu.address("dp", 0x63u), cpu.y, cpu.x8?8:16);
    goto L_82BBEA;
L_82BBEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBEAu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBEAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBEA LDY
    cpu.setY(0x7Du, 16);
    goto L_82BBED;
L_82BBED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBEDu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBEDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBED STZ
    hw.write(cpu.address("dp", 0x36u), 0, cpu.m8?8:16);
    goto L_82BBEF;
L_82BBEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBEFu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBEFu, 5u + 1u, 3u, cpu.address("absy", 0x1700u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBEF LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1700u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BBF2;
L_82BBF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF2u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBF2 AND
    cpu.logicAnd(0xFFu);
    goto L_82BBF5;
L_82BBF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF5u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBF5 CLC
    cpu.setFlag('C', false);
    goto L_82BBF6;
L_82BBF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF6u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBF6 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16));
    goto L_82BBF8;
L_82BBF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBF8 STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_82BBFA;
L_82BBFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBFAu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBFAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBFA DEY
    cpu.decReg('Y');
    goto L_82BBFB;
L_82BBFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBFBu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBFBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBFB BPL -> $82BBEF
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82BBEF; }
    goto L_82BBFD;
L_82BBFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBFDu,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBFDu, 5u, 3u, cpu.address("abs", 0x177Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBFD CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x177Eu), cpu.m8?8:16));
    goto L_82BC00;
L_82BC00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC00u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC00u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BC00 BNE -> $82BC18
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82BC18; }
    goto L_82BC02;
L_82BC02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC02u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC02u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BC02 LDY
    cpu.setY(0x7Eu, 16);
    goto L_82BC05;
L_82BC05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC05u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC05u, 5u + 1u, 3u, cpu.address("absy", 0x1700u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BC05 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1700u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BC08;
L_82BC08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC08u,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC08u, 5u + 1u, 3u, cpu.address("absy", 0x1780u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BC08 CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0x1780u), cpu.m8?8:16));
    goto L_82BC0B;
L_82BC0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BC0B BNE -> $82BC18
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82BC18; }
    goto L_82BC0D;
L_82BC0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Du,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BC0D DEY
    cpu.decReg('Y');
    goto L_82BC0E;
L_82BC0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Eu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BC0E DEY
    cpu.decReg('Y');
    goto L_82BC0F;
L_82BC0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BC0F BPL -> $82BC05
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82BC05; }
    goto L_82BC11;
L_82BC11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC11u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC11u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BC11 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82BC13;
L_82BC13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC13u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC13u, 6u, 3u, cpu.address("abs", 0xBCD0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82BC13 JSR -> $82BCD0 stack real
    { cpu.push16Value(hw,0xBC15u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC16u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBCD0u), 0x82BC13u); }
    goto L_82BC16;
L_82BC16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC16u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC16u,0x82BC16u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC16u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC16u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BC16 BRA -> $82BC2A
    goto L_82BC2A;
L_82BC18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC18u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC18u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BC18 LDX
    cpu.setX(0xFEu, 16);
    goto L_82BC1B;
L_82BC1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Bu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Bu, 6u, 3u, cpu.address("absx", 0x1700u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BC1B STZ
    hw.write(cpu.address("absx", 0x1700u), 0, cpu.m8?8:16);
    goto L_82BC1E;
L_82BC1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Eu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BC1E DEX
    cpu.decReg('X');
    goto L_82BC1F;
L_82BC1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Fu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BC1F DEX
    cpu.decReg('X');
    goto L_82BC20;
L_82BC20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC20u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BC20 BPL -> $82BC1B
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82BC1B; }
    goto L_82BC22;
L_82BC22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC22u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC22u, 8u, 4u, 0x82DEAEu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82BC22 JSL -> $82DEAE stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC25u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC26u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82DEAEu, 0x82BC22u); }
    goto L_82BC26;
L_82BC26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC26u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC26u,0x82BC26u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC26u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC26u, 8u, 4u, 0x82BC35u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82BC26 JSL -> $82BC35 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC29u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC2Au,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82BC35u, 0x82BC26u); }
    goto L_82BC2A;
L_82BC2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC2Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC2Au,0x82BC2Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Au,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BC2A SEP
    cpu.sep(0x20u);
    goto L_82BC2C;
L_82BC2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Cu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82BC2C RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82BC2Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82BC2Cu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82BB9A_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82BB9Au: goto L_82BB9A;
    case 0x82BB9Cu: goto L_82BB9C;
    case 0x82BB9Fu: goto L_82BB9F;
    case 0x82BBA2u: goto L_82BBA2;
    case 0x82BBA5u: goto L_82BBA5;
    case 0x82BBA8u: goto L_82BBA8;
    case 0x82BBABu: goto L_82BBAB;
    case 0x82BBAEu: goto L_82BBAE;
    case 0x82BBB2u: goto L_82BBB2;
    case 0x82BBB5u: goto L_82BBB5;
    case 0x82BBB7u: goto L_82BBB7;
    case 0x82BBBAu: goto L_82BBBA;
    case 0x82BBBDu: goto L_82BBBD;
    case 0x82BBC0u: goto L_82BBC0;
    case 0x82BBC2u: goto L_82BBC2;
    case 0x82BBC5u: goto L_82BBC5;
    case 0x82BBC7u: goto L_82BBC7;
    case 0x82BBCAu: goto L_82BBCA;
    case 0x82BBCCu: goto L_82BBCC;
    case 0x82BBCFu: goto L_82BBCF;
    case 0x82BBD1u: goto L_82BBD1;
    case 0x82BBD4u: goto L_82BBD4;
    case 0x82BBD7u: goto L_82BBD7;
    case 0x82BBDAu: goto L_82BBDA;
    case 0x82BBDEu: goto L_82BBDE;
    case 0x82BBE0u: goto L_82BBE0;
    case 0x82BBE1u: goto L_82BBE1;
    case 0x82BBE2u: goto L_82BBE2;
    case 0x82BBE3u: goto L_82BBE3;
    case 0x82BBE4u: goto L_82BBE4;
    case 0x82BBE6u: goto L_82BBE6;
    case 0x82BBE8u: goto L_82BBE8;
    case 0x82BBEAu: goto L_82BBEA;
    case 0x82BBEDu: goto L_82BBED;
    case 0x82BBEFu: goto L_82BBEF;
    case 0x82BBF2u: goto L_82BBF2;
    case 0x82BBF5u: goto L_82BBF5;
    case 0x82BBF6u: goto L_82BBF6;
    case 0x82BBF8u: goto L_82BBF8;
    case 0x82BBFAu: goto L_82BBFA;
    case 0x82BBFBu: goto L_82BBFB;
    case 0x82BBFDu: goto L_82BBFD;
    case 0x82BC00u: goto L_82BC00;
    case 0x82BC02u: goto L_82BC02;
    case 0x82BC05u: goto L_82BC05;
    case 0x82BC08u: goto L_82BC08;
    case 0x82BC0Bu: goto L_82BC0B;
    case 0x82BC0Du: goto L_82BC0D;
    case 0x82BC0Eu: goto L_82BC0E;
    case 0x82BC0Fu: goto L_82BC0F;
    case 0x82BC11u: goto L_82BC11;
    case 0x82BC13u: goto L_82BC13;
    case 0x82BC16u: goto L_82BC16;
    case 0x82BC18u: goto L_82BC18;
    case 0x82BC1Bu: goto L_82BC1B;
    case 0x82BC1Eu: goto L_82BC1E;
    case 0x82BC1Fu: goto L_82BC1F;
    case 0x82BC20u: goto L_82BC20;
    case 0x82BC22u: goto L_82BC22;
    case 0x82BC26u: goto L_82BC26;
    case 0x82BC2Au: goto L_82BC2A;
    case 0x82BC2Cu: goto L_82BC2C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82BB9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB9Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB9Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB9A REP
    cpu.rep(0x20u);
    goto L_82BB9C;
L_82BB9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB9Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB9Cu, 5u, 3u, cpu.address("abs", 0x014Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB9C STZ
    hw.write(cpu.address("abs", 0x14Cu), 0, cpu.m8?8:16);
    goto L_82BB9F;
L_82BB9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB9Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB9Fu, 5u, 3u, cpu.address("abs", 0x0800u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB9F STZ
    hw.write(cpu.address("abs", 0x800u), 0, cpu.m8?8:16);
    goto L_82BBA2;
L_82BBA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBA2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBA2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBA2 LDA
    cpu.setA(0x7u, 16);
    goto L_82BBA5;
L_82BBA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBA5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBA5u, 5u, 3u, cpu.address("abs", 0x01D2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBA5 STA
    hw.write(cpu.address("abs", 0x1D2u), cpu.a, cpu.m8?8:16);
    goto L_82BBA8;
L_82BBA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBA8u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBA8u, 5u, 3u, cpu.address("abs", 0x018Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBA8 STZ
    hw.write(cpu.address("abs", 0x18Du), 0, cpu.m8?8:16);
    goto L_82BBAB;
L_82BBAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBABu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBABu, 5u, 3u, cpu.address("abs", 0x0193u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBAB STZ
    hw.write(cpu.address("abs", 0x193u), 0, cpu.m8?8:16);
    goto L_82BBAE;
L_82BBAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBAEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBAEu, 8u, 4u, 0x82DF3Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82BBAE JSL -> $82DF3C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBBB1u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBBB2u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82DF3Cu, 0x82BBAEu); }
    goto L_82BBB2;
L_82BBB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBB2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBBB2u,0x82BBB2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBB2u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBB2u, 5u, 3u, cpu.address("abs", 0x0665u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBB2 STZ
    hw.write(cpu.address("abs", 0x665u), 0, cpu.m8?8:16);
    goto L_82BBB5;
L_82BBB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBB5u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBB5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBB5 SEP
    cpu.sep(0x20u);
    goto L_82BBB7;
L_82BBB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBB7u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBB7u, 4u, 3u, cpu.address("abs", 0x01D7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBB7 STZ
    hw.write(cpu.address("abs", 0x1D7u), 0, cpu.m8?8:16);
    goto L_82BBBA;
L_82BBBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBBAu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBBAu, 4u, 3u, cpu.address("abs", 0x01D1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBBA STZ
    hw.write(cpu.address("abs", 0x1D1u), 0, cpu.m8?8:16);
    goto L_82BBBD;
L_82BBBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBBDu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBBDu, 4u, 3u, cpu.address("abs", 0x01CEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBBD STZ
    hw.write(cpu.address("abs", 0x1CEu), 0, cpu.m8?8:16);
    goto L_82BBC0;
L_82BBC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBC0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBC0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBC0 LDA
    cpu.setA(0x3Cu, 8);
    goto L_82BBC2;
L_82BBC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBC2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBC2u, 4u, 3u, cpu.address("abs", 0x01CFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBC2 STA
    hw.write(cpu.address("abs", 0x1CFu), cpu.a, cpu.m8?8:16);
    goto L_82BBC5;
L_82BBC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBC5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBC5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBC5 LDA
    cpu.setA(0x4u, 8);
    goto L_82BBC7;
L_82BBC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBC7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBC7u, 4u, 3u, cpu.address("abs", 0x01D0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBC7 STA
    hw.write(cpu.address("abs", 0x1D0u), cpu.a, cpu.m8?8:16);
    goto L_82BBCA;
L_82BBCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBCAu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBCAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBCA REP
    cpu.rep(0x20u);
    goto L_82BBCC;
L_82BBCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBCCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBCCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBCCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBCC LDA
    cpu.setA(0x4u, 16);
    goto L_82BBCF;
L_82BBCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBCFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBCFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBCF STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82BBD1;
L_82BBD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD1u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBD1 LDX
    cpu.setX(0x0u, 16);
    goto L_82BBD4;
L_82BBD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD4u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBD4 LDY
    cpu.setY(0x0u, 16);
    goto L_82BBD7;
L_82BBD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD7u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD7u, 5u + 1u, 3u, cpu.address("absy", 0x1700u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBD7 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1700u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BBDA;
L_82BBDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBDAu,cpu,0xDFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBDAu, 6u, 4u, ((0x82BC2Du + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBDA CMP
    cpu.compareA(hw.readW(((0x82BC2Du + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_82BBDE;
L_82BBDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBDEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBDEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBDE BNE -> $82BC18
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82BC18; }
    goto L_82BBE0;
L_82BBE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE0u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBE0 INX
    cpu.inc('X');
    goto L_82BBE1;
L_82BBE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE1u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBE1 INX
    cpu.inc('X');
    goto L_82BBE2;
L_82BBE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE2u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBE2 INY
    cpu.inc('Y');
    goto L_82BBE3;
L_82BBE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE3u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBE3 INY
    cpu.inc('Y');
    goto L_82BBE4;
L_82BBE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE4u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE4u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBE4 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_82BBE6;
L_82BBE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBE6 BNE -> $82BBD7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82BBD7; }
    goto L_82BBE8;
L_82BBE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE8u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBE8 STY
    hw.write(cpu.address("dp", 0x63u), cpu.y, cpu.x8?8:16);
    goto L_82BBEA;
L_82BBEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBEAu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBEAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBEA LDY
    cpu.setY(0x7Du, 16);
    goto L_82BBED;
L_82BBED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBEDu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBEDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBED STZ
    hw.write(cpu.address("dp", 0x36u), 0, cpu.m8?8:16);
    goto L_82BBEF;
L_82BBEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBEFu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBEFu, 5u + 1u, 3u, cpu.address("absy", 0x1700u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBEF LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1700u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BBF2;
L_82BBF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF2u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBF2 AND
    cpu.logicAnd(0xFFu);
    goto L_82BBF5;
L_82BBF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF5u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBF5 CLC
    cpu.setFlag('C', false);
    goto L_82BBF6;
L_82BBF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF6u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBF6 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16));
    goto L_82BBF8;
L_82BBF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBF8 STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_82BBFA;
L_82BBFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBFAu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBFAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBFA DEY
    cpu.decReg('Y');
    goto L_82BBFB;
L_82BBFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBFBu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBFBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBFB BPL -> $82BBEF
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82BBEF; }
    goto L_82BBFD;
L_82BBFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBFDu,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBFDu, 5u, 3u, cpu.address("abs", 0x177Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BBFD CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x177Eu), cpu.m8?8:16));
    goto L_82BC00;
L_82BC00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC00u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC00u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BC00 BNE -> $82BC18
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82BC18; }
    goto L_82BC02;
L_82BC02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC02u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC02u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BC02 LDY
    cpu.setY(0x7Eu, 16);
    goto L_82BC05;
L_82BC05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC05u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC05u, 5u + 1u, 3u, cpu.address("absy", 0x1700u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BC05 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1700u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BC08;
L_82BC08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC08u,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC08u, 5u + 1u, 3u, cpu.address("absy", 0x1780u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BC08 CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0x1780u), cpu.m8?8:16));
    goto L_82BC0B;
L_82BC0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BC0B BNE -> $82BC18
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82BC18; }
    goto L_82BC0D;
L_82BC0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Du,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BC0D DEY
    cpu.decReg('Y');
    goto L_82BC0E;
L_82BC0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Eu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BC0E DEY
    cpu.decReg('Y');
    goto L_82BC0F;
L_82BC0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BC0F BPL -> $82BC05
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82BC05; }
    goto L_82BC11;
L_82BC11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC11u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC11u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BC11 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82BC13;
L_82BC13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC13u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC13u, 6u, 3u, cpu.address("abs", 0xBCD0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82BC13 JSR -> $82BCD0 stack real
    { cpu.push16Value(hw,0xBC15u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC16u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBCD0u), 0x82BC13u); }
    goto L_82BC16;
L_82BC16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC16u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC16u,0x82BC16u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC16u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC16u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BC16 BRA -> $82BC2A
    goto L_82BC2A;
L_82BC18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC18u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC18u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BC18 LDX
    cpu.setX(0xFEu, 16);
    goto L_82BC1B;
L_82BC1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Bu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Bu, 6u, 3u, cpu.address("absx", 0x1700u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BC1B STZ
    hw.write(cpu.address("absx", 0x1700u), 0, cpu.m8?8:16);
    goto L_82BC1E;
L_82BC1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Eu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BC1E DEX
    cpu.decReg('X');
    goto L_82BC1F;
L_82BC1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Fu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BC1F DEX
    cpu.decReg('X');
    goto L_82BC20;
L_82BC20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC20u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BC20 BPL -> $82BC1B
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82BC1B; }
    goto L_82BC22;
L_82BC22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC22u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC22u, 8u, 4u, 0x82DEAEu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82BC22 JSL -> $82DEAE stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC25u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC26u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82DEAEu, 0x82BC22u); }
    goto L_82BC26;
L_82BC26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC26u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC26u,0x82BC26u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC26u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC26u, 8u, 4u, 0x82BC35u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82BC26 JSL -> $82BC35 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBC29u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBC2Au,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82BC35u, 0x82BC26u); }
    goto L_82BC2A;
L_82BC2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC2Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBC2Au,0x82BC2Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Au,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BC2A SEP
    cpu.sep(0x20u);
    goto L_82BC2C;
L_82BC2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Cu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82BC2C RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82BC2Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82BC2Cu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82C078_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82C078u: goto L_82C078;
    case 0x82C07Bu: goto L_82C07B;
    case 0x82C07Du: goto L_82C07D;
    case 0x82C080u: goto L_82C080;
    case 0x82C081u: goto L_82C081;
    case 0x82C084u: goto L_82C084;
    case 0x82C087u: goto L_82C087;
    case 0x82C089u: goto L_82C089;
    case 0x82C08Cu: goto L_82C08C;
    case 0x82C08Fu: goto L_82C08F;
    case 0x82C092u: goto L_82C092;
    case 0x82C095u: goto L_82C095;
    case 0x82C098u: goto L_82C098;
    case 0x82C09Au: goto L_82C09A;
    case 0x82C09Du: goto L_82C09D;
    case 0x82C0A0u: goto L_82C0A0;
    case 0x82C0A1u: goto L_82C0A1;
    case 0x82C0A4u: goto L_82C0A4;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82C078:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC078u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC078u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC078u, 5u, 3u, cpu.address("abs", 0x013Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C078 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C07B;
L_82C07B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC07Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC07Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC07Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C07B BEQ -> $82C081
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C081; }
    goto L_82C07D;
L_82C07D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC07Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC07Du,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC07Du, 8u, 3u, cpu.address("abs", 0x013Du), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C07D DEC
    cpu.decMem(hw, cpu.address("abs", 0x13Du), cpu.m8?8:16);
    goto L_82C080;
L_82C080:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC080u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC080u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC080u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C080 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C080u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C080u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82C081:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC081u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC081u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC081u, 5u, 3u, cpu.address("abs", 0x017Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C081 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x17Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C084;
L_82C084:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC084u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC084u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC084u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C084 CMP
    cpu.compareA(0x3u);
    goto L_82C087;
L_82C087:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC087u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC087u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC087u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C087 BCS -> $82C0A1
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82C0A1; }
    goto L_82C089;
L_82C089:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC089u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC089u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC089u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C089 LDA
    cpu.setA(0xAu, 16);
    goto L_82C08C;
L_82C08C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC08Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC08Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC08Cu, 5u, 3u, cpu.address("abs", 0x013Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C08C STA
    hw.write(cpu.address("abs", 0x13Du), cpu.a, cpu.m8?8:16);
    goto L_82C08F;
L_82C08F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC08Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC08Fu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC08Fu, 8u, 3u, cpu.address("abs", 0x017Du), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C08F INC
    cpu.incMem(hw, cpu.address("abs", 0x17Du), cpu.m8?8:16);
    goto L_82C092;
L_82C092:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC092u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC092u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC092u, 5u, 3u, cpu.address("abs", 0x0156u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C092 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x156u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C095;
L_82C095:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC095u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC095u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC095u, 5u, 3u, cpu.address("abs", 0x0158u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C095 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x158u), cpu.m8?8:16));
    goto L_82C098;
L_82C098:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC098u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC098u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC098u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C098 BEQ -> $82C09D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C09D; }
    goto L_82C09A;
L_82C09A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC09Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC09Au,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC09Au, 8u, 3u, cpu.address("abs", 0x017Fu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C09A INC
    cpu.incMem(hw, cpu.address("abs", 0x17Fu), cpu.m8?8:16);
    goto L_82C09D;
L_82C09D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC09Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC09Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC09Du, 6u, 3u, cpu.address("abs", 0xD05Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C09D JSR -> $82D05B stack real
    { cpu.push16Value(hw,0xC09Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC0A0u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD05Bu), 0x82C09Du); }
    goto L_82C0A0;
L_82C0A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0A0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC0A0u,0x82C0A0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0A0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0A0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C0A0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C0A0u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C0A0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82C0A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0A1u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0A1u, 8u, 3u, cpu.address("abs", 0x013Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C0A1 INC
    cpu.incMem(hw, cpu.address("abs", 0x13Bu), cpu.m8?8:16);
    goto L_82C0A4;
L_82C0A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0A4u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0A4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C0A4 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C0A4u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C0A4u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82C9E8_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82C9E8u: goto L_82C9E8;
    case 0x82C9EAu: goto L_82C9EA;
    case 0x82C9EDu: goto L_82C9ED;
    case 0x82C9F0u: goto L_82C9F0;
    case 0x82C9F2u: goto L_82C9F2;
    case 0x82C9F5u: goto L_82C9F5;
    case 0x82C9F7u: goto L_82C9F7;
    case 0x82C9FAu: goto L_82C9FA;
    case 0x82C9FCu: goto L_82C9FC;
    case 0x82C9FFu: goto L_82C9FF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82C9E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9E8u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9E8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C9E8 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82C9EA;
L_82C9EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9EAu,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9EAu, 9u, 3u, cpu.address("absx", 0x0414u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C9EA INC
    cpu.incMem(hw, cpu.address("absx", 0x414u), cpu.m8?8:16);
    goto L_82C9ED;
L_82C9ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9EDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9EDu, 5u + 1u, 3u, cpu.address("absx", 0x0410u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C9ED LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x410u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C9F0;
L_82C9F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9F0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9F0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C9F0 BNE -> $82C9F7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C9F7; }
    goto L_82C9F2;
L_82C9F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9F2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9F2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C9F2 LDA
    cpu.setA(0xCA4Au, 16);
    goto L_82C9F5;
L_82C9F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9F5u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9F5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C9F5 BRA -> $82C9FA
    goto L_82C9FA;
L_82C9F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9F7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9F7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C9F7 LDA
    cpu.setA(0xCA42u, 16);
    goto L_82C9FA;
L_82C9FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9FAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9FAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C9FA STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_82C9FC;
L_82C9FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9FCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9FCu, 6u, 3u, cpu.address("abs", 0xCA1Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C9FC JSR -> $82CA1E stack real
    { cpu.push16Value(hw,0xC9FEu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC9FFu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCA1Eu), 0x82C9FCu); }
    goto L_82C9FF;
L_82C9FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9FFu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC9FFu,0x82C9FFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9FFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9FFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C9FF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C9FFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C9FFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82C9E8_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82C9E8u: goto L_82C9E8;
    case 0x82C9EAu: goto L_82C9EA;
    case 0x82C9EDu: goto L_82C9ED;
    case 0x82C9F0u: goto L_82C9F0;
    case 0x82C9F2u: goto L_82C9F2;
    case 0x82C9F5u: goto L_82C9F5;
    case 0x82C9F7u: goto L_82C9F7;
    case 0x82C9FAu: goto L_82C9FA;
    case 0x82C9FCu: goto L_82C9FC;
    case 0x82C9FFu: goto L_82C9FF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82C9E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9E8u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9E8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C9E8 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82C9EA;
L_82C9EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9EAu,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9EAu, 9u, 3u, cpu.address("absx", 0x0414u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C9EA INC
    cpu.incMem(hw, cpu.address("absx", 0x414u), cpu.m8?8:16);
    goto L_82C9ED;
L_82C9ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9EDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9EDu, 5u + 1u, 3u, cpu.address("absx", 0x0410u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C9ED LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x410u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C9F0;
L_82C9F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9F0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9F0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C9F0 BNE -> $82C9F7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C9F7; }
    goto L_82C9F2;
L_82C9F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9F2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9F2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C9F2 LDA
    cpu.setA(0xCA4Au, 16);
    goto L_82C9F5;
L_82C9F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9F5u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9F5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C9F5 BRA -> $82C9FA
    goto L_82C9FA;
L_82C9F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9F7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9F7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C9F7 LDA
    cpu.setA(0xCA42u, 16);
    goto L_82C9FA;
L_82C9FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9FAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9FAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C9FA STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_82C9FC;
L_82C9FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9FCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9FCu, 6u, 3u, cpu.address("abs", 0xCA1Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C9FC JSR -> $82CA1E stack real
    { cpu.push16Value(hw,0xC9FEu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC9FFu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCA1Eu), 0x82C9FCu); }
    goto L_82C9FF;
L_82C9FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9FFu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC9FFu,0x82C9FFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9FFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9FFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C9FF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C9FFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C9FFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82CD0D_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82CD0Du: goto L_82CD0D;
    case 0x82CD10u: goto L_82CD10;
    case 0x82CD11u: goto L_82CD11;
    case 0x82CD12u: goto L_82CD12;
    case 0x82CD16u: goto L_82CD16;
    case 0x82CD18u: goto L_82CD18;
    case 0x82CD19u: goto L_82CD19;
    case 0x82CD1Cu: goto L_82CD1C;
    case 0x82CD1Du: goto L_82CD1D;
    case 0x82CD20u: goto L_82CD20;
    case 0x82CD23u: goto L_82CD23;
    case 0x82CD27u: goto L_82CD27;
    case 0x82CD29u: goto L_82CD29;
    case 0x82CD2Au: goto L_82CD2A;
    case 0x82CD2Du: goto L_82CD2D;
    case 0x82CD2Eu: goto L_82CD2E;
    case 0x82CD31u: goto L_82CD31;
    case 0x82CD34u: goto L_82CD34;
    case 0x82CD38u: goto L_82CD38;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82CD0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD0Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD0Du, 5u, 3u, cpu.address("abs", 0x01D2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD0D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1D2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CD10;
L_82CD10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD10u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD10u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD10 ASL
    cpu.aslA();
    goto L_82CD11;
L_82CD11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD11u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD11u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD11 TAX
    cpu.transfer("TAX");
    goto L_82CD12;
L_82CD12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD12u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD12u, 6u, 4u, ((0x82CD39u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD12 LDA
    cpu.loadA(hw.readW(((0x82CD39u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CD16;
L_82CD16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD16u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD16u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD16 STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_82CD18;
L_82CD18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD18u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD18u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD18 CLC
    cpu.setFlag('C', false);
    goto L_82CD19;
L_82CD19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD19u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD19u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD19 ADC
    cpu.adc(0x1000u);
    goto L_82CD1C;
L_82CD1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD1Cu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD1Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD1C TAX
    cpu.transfer("TAX");
    goto L_82CD1D;
L_82CD1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD1Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD1Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD1D LDA
    cpu.setA(0x400u, 16);
    goto L_82CD20;
L_82CD20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD20u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD20u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD20 LDY
    cpu.setY(0x0u, 16);
    goto L_82CD23;
L_82CD23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD23u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD23u, 8u, 4u, 0x808EE1u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82CD23 JSL -> $808EE1 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCD26u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCD27u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808EE1u, 0x82CD23u); }
    goto L_82CD27;
L_82CD27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD27u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD27u,0x82CD27u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD27u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD27u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD27 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CD29;
L_82CD29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD29u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD29u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD29 CLC
    cpu.setFlag('C', false);
    goto L_82CD2A;
L_82CD2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD2Au,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD2Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD2A ADC
    cpu.adc(0x3000u);
    goto L_82CD2D;
L_82CD2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD2Du,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD2Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD2D TAX
    cpu.transfer("TAX");
    goto L_82CD2E;
L_82CD2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD2Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD2Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD2E LDA
    cpu.setA(0x400u, 16);
    goto L_82CD31;
L_82CD31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD31u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD31u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD31 LDY
    cpu.setY(0x6000u, 16);
    goto L_82CD34;
L_82CD34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD34u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD34u, 8u, 4u, 0x808EE1u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82CD34 JSL -> $808EE1 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCD37u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCD38u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808EE1u, 0x82CD34u); }
    goto L_82CD38;
L_82CD38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD38u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD38u,0x82CD38u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD38u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD38u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CD38 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82CD38u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82CD38u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82D495_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82D495u: goto L_82D495;
    case 0x82D498u: goto L_82D498;
    case 0x82D49Bu: goto L_82D49B;
    case 0x82D49Du: goto L_82D49D;
    case 0x82D4A0u: goto L_82D4A0;
    case 0x82D4A1u: goto L_82D4A1;
    case 0x82D4A3u: goto L_82D4A3;
    case 0x82D4A4u: goto L_82D4A4;
    case 0x82D4A5u: goto L_82D4A5;
    case 0x82D4A8u: goto L_82D4A8;
    case 0x82D4ABu: goto L_82D4AB;
    case 0x82D4AEu: goto L_82D4AE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82D495:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD495u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD495u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD495u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D495 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D498;
L_82D498:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD498u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD498u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD498u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D498 CMP
    cpu.compareA(0x1u);
    goto L_82D49B;
L_82D49B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD49Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD49Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD49Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D49B BNE -> $82D4AE
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D4AE; }
    goto L_82D49D;
L_82D49D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD49Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD49Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD49Du, 5u, 3u, cpu.address("abs", 0x02E6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D49D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2E6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D4A0;
L_82D4A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4A0u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4A0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4A0 DEC
    cpu.decReg('A');
    goto L_82D4A1;
L_82D4A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4A1u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4A1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4A1 BMI -> $82D4AE
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82D4AE; }
    goto L_82D4A3;
L_82D4A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4A3u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4A3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4A3 ASL
    cpu.aslA();
    goto L_82D4A4;
L_82D4A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4A4u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4A4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4A4 TAX
    cpu.transfer("TAX");
    goto L_82D4A5;
L_82D4A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4A5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4A5u, 5u + 1u, 3u, cpu.address("absx", 0x0884u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4A5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x884u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D4A8;
L_82D4A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4A8u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4A8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4A8 ORA
    cpu.logicOr(0xFF00u);
    goto L_82D4AB;
L_82D4AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4ABu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4ABu, 6u, 3u, cpu.address("absx", 0x0884u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4AB STA
    hw.write(cpu.address("absx", 0x884u), cpu.a, cpu.m8?8:16);
    goto L_82D4AE;
L_82D4AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4AEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4AEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D4AE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D4AEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D4AEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82E1AA_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82E1AAu: goto L_82E1AA;
    case 0x82E1ADu: goto L_82E1AD;
    case 0x82E1B0u: goto L_82E1B0;
    case 0x82E1B2u: goto L_82E1B2;
    case 0x82E1B5u: goto L_82E1B5;
    case 0x82E1B7u: goto L_82E1B7;
    case 0x82E1B9u: goto L_82E1B9;
    case 0x82E1BCu: goto L_82E1BC;
    case 0x82E1BFu: goto L_82E1BF;
    case 0x82E1C0u: goto L_82E1C0;
    case 0x82E1C2u: goto L_82E1C2;
    case 0x82E1C5u: goto L_82E1C5;
    case 0x82E1C8u: goto L_82E1C8;
    case 0x82E1CBu: goto L_82E1CB;
    case 0x82E1CEu: goto L_82E1CE;
    case 0x82E1CFu: goto L_82E1CF;
    case 0x82E1D1u: goto L_82E1D1;
    case 0x82E1D4u: goto L_82E1D4;
    case 0x82E1D7u: goto L_82E1D7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82E1AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1AAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1AAu, 6u, 3u, cpu.address("abs", 0xE27Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E1AA JSR -> $82E27E stack real
    { cpu.push16Value(hw,0xE1ACu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE1ADu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE27Eu), 0x82E1AAu); }
    goto L_82E1AD;
L_82E1AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1ADu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE1ADu,0x82E1ADu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1ADu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1ADu, 6u, 3u, cpu.address("abs", 0xA53Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E1AD JSR -> $82A53C stack real
    { cpu.push16Value(hw,0xE1AFu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE1B0u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA53Cu), 0x82E1ADu); }
    goto L_82E1B0;
L_82E1B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1B0u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1B0u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1B0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E1B0 BCS -> $82E1CF
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82E1CF; }
    goto L_82E1B2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1B0u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1B0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E1B0 BCS -> $82E1CF
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82E1CF; }
    goto L_82E1B2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE1B0u,0x82E1B0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E1B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1B2u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1B2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1B2u, 6u, 3u, cpu.address("abs", 0xA58Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E1B2 JSR -> $82A58A stack real
    { cpu.push16Value(hw,0xE1B4u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE1B5u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA58Au), 0x82E1B2u); }
    goto L_82E1B5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1B2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1B2u, 6u, 3u, cpu.address("abs", 0xA58Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E1B2 JSR -> $82A58A stack real
    { cpu.push16Value(hw,0xE1B4u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE1B5u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA58Au), 0x82E1B2u); }
    goto L_82E1B5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE1B2u,0x82E1B2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E1B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1B5u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1B5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1B5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E1B5 BNE -> $82E1C0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E1C0; }
    goto L_82E1B7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1B5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1B5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E1B5 BNE -> $82E1C0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E1C0; }
    goto L_82E1B7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1B5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1B5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E1B5 BNE -> $82E1C0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E1C0; }
    goto L_82E1B7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE1B5u,0x82E1B5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E1B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1B7u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1B7u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1B7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E1B7 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82E1B9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1B7u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1B7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E1B7 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82E1B9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1B7u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1B7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E1B7 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82E1B9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE1B7u,0x82E1B7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E1B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1B9u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1B9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1B9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E1B9 LDA
    cpu.setA(0xCu, 16);
    goto L_82E1BC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1B9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1B9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E1B9 LDA
    cpu.setA(0xCu, 16);
    goto L_82E1BC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1B9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1B9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E1B9 LDA
    cpu.setA(0xCu, 16);
    goto L_82E1BC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE1B9u,0x82E1B9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E1BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1BCu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1BCu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1BCu, 6u, 3u, cpu.address("absx", 0x0200u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E1BC STA
    hw.write(cpu.address("absx", 0x200u), cpu.a, cpu.m8?8:16);
    goto L_82E1BF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1BCu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1BCu, 6u, 3u, cpu.address("absx", 0x0200u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E1BC STA
    hw.write(cpu.address("absx", 0x200u), cpu.a, cpu.m8?8:16);
    goto L_82E1BF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1BCu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1BCu, 6u, 3u, cpu.address("absx", 0x0200u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E1BC STA
    hw.write(cpu.address("absx", 0x200u), cpu.a, cpu.m8?8:16);
    goto L_82E1BF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE1BCu,0x82E1BCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E1BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1BFu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1BFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1BFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E1BF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82E1BFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82E1BFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1BFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1BFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E1BF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82E1BFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82E1BFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1BFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1BFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E1BF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82E1BFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82E1BFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE1BFu,0x82E1BFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E1C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1C0u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1C0u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1C0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E1C0 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82E1C2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1C0u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1C0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E1C0 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82E1C2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1C0u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1C0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E1C0 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82E1C2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE1C0u,0x82E1C0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E1C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1C2u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1C2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1C2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E1C2 LDA
    cpu.setA(0xDu, 16);
    goto L_82E1C5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1C2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1C2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E1C2 LDA
    cpu.setA(0xDu, 16);
    goto L_82E1C5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1C2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1C2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E1C2 LDA
    cpu.setA(0xDu, 16);
    goto L_82E1C5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE1C2u,0x82E1C2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E1C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1C5u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1C5u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1C5u, 6u, 3u, cpu.address("absx", 0x0200u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E1C5 STA
    hw.write(cpu.address("absx", 0x200u), cpu.a, cpu.m8?8:16);
    goto L_82E1C8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1C5u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1C5u, 6u, 3u, cpu.address("absx", 0x0200u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E1C5 STA
    hw.write(cpu.address("absx", 0x200u), cpu.a, cpu.m8?8:16);
    goto L_82E1C8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1C5u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1C5u, 6u, 3u, cpu.address("absx", 0x0200u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E1C5 STA
    hw.write(cpu.address("absx", 0x200u), cpu.a, cpu.m8?8:16);
    goto L_82E1C8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE1C5u,0x82E1C5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E1C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1C8u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1C8u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1C8u, 9u, 3u, cpu.address("absx", 0x0422u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E1C8 INC
    cpu.incMem(hw, cpu.address("absx", 0x422u), cpu.m8?8:16);
    goto L_82E1CB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1C8u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1C8u, 9u, 3u, cpu.address("absx", 0x0422u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E1C8 INC
    cpu.incMem(hw, cpu.address("absx", 0x422u), cpu.m8?8:16);
    goto L_82E1CB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1C8u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1C8u, 9u, 3u, cpu.address("absx", 0x0422u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E1C8 INC
    cpu.incMem(hw, cpu.address("absx", 0x422u), cpu.m8?8:16);
    goto L_82E1CB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE1C8u,0x82E1C8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E1CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1CBu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1CBu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1CBu, 8u, 3u, cpu.address("abs", 0x01B1u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E1CB INC
    cpu.incMem(hw, cpu.address("abs", 0x1B1u), cpu.m8?8:16);
    goto L_82E1CE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1CBu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1CBu, 8u, 3u, cpu.address("abs", 0x01B1u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E1CB INC
    cpu.incMem(hw, cpu.address("abs", 0x1B1u), cpu.m8?8:16);
    goto L_82E1CE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1CBu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1CBu, 8u, 3u, cpu.address("abs", 0x01B1u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E1CB INC
    cpu.incMem(hw, cpu.address("abs", 0x1B1u), cpu.m8?8:16);
    goto L_82E1CE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE1CBu,0x82E1CBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E1CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1CEu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1CEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1CEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E1CE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82E1CEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82E1CEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1CEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1CEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E1CE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82E1CEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82E1CEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1CEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1CEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E1CE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82E1CEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82E1CEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE1CEu,0x82E1CEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E1CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1CFu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1CFu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1CFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E1CF LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82E1D1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1CFu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1CFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E1CF LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82E1D1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE1CFu,0x82E1CFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E1D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1D1u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1D1u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1D1u, 9u, 3u, cpu.address("absx", 0x0200u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E1D1 INC
    cpu.incMem(hw, cpu.address("absx", 0x200u), cpu.m8?8:16);
    goto L_82E1D4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1D1u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1D1u, 9u, 3u, cpu.address("absx", 0x0200u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E1D1 INC
    cpu.incMem(hw, cpu.address("absx", 0x200u), cpu.m8?8:16);
    goto L_82E1D4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE1D1u,0x82E1D1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E1D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1D4u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1D4u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1D4u, 6u, 3u, cpu.address("absx", 0x02CCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E1D4 STZ
    hw.write(cpu.address("absx", 0x2CCu), 0, cpu.m8?8:16);
    goto L_82E1D7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1D4u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1D4u, 6u, 3u, cpu.address("absx", 0x02CCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E1D4 STZ
    hw.write(cpu.address("absx", 0x2CCu), 0, cpu.m8?8:16);
    goto L_82E1D7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE1D4u,0x82E1D4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E1D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE1D7u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1D7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1D7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E1D7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82E1D7u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82E1D7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE1D7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE1D7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E1D7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82E1D7u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82E1D7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE1D7u,0x82E1D7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_8481B0_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8481B0u: goto L_8481B0;
    case 0x8481B3u: goto L_8481B3;
    case 0x8481B5u: goto L_8481B5;
    case 0x8481B7u: goto L_8481B7;
    case 0x8481B9u: goto L_8481B9;
    case 0x8481BAu: goto L_8481BA;
    case 0x8481BBu: goto L_8481BB;
    case 0x8481BDu: goto L_8481BD;
    case 0x8481C1u: goto L_8481C1;
    case 0x8481C3u: goto L_8481C3;
    case 0x8481C5u: goto L_8481C5;
    case 0x8481C7u: goto L_8481C7;
    case 0x8481C9u: goto L_8481C9;
    case 0x8481CBu: goto L_8481CB;
    case 0x8481CCu: goto L_8481CC;
    case 0x8481CDu: goto L_8481CD;
    case 0x8481CFu: goto L_8481CF;
    case 0x8481D3u: goto L_8481D3;
    case 0x8481D5u: goto L_8481D5;
    case 0x8481D7u: goto L_8481D7;
    case 0x8481D9u: goto L_8481D9;
    case 0x8481DBu: goto L_8481DB;
    case 0x8481DEu: goto L_8481DE;
    case 0x8481E1u: goto L_8481E1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8481B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81B0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81B0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8481B0 LDA
    cpu.setA(0x1u, 16);
    goto L_8481B3;
L_8481B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81B3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81B3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8481B3 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_8481B5;
L_8481B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81B5u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81B5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8481B5 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8481B7;
L_8481B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81B7u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81B7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8481B7 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8481B9;
L_8481B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81B9u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81B9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8481B9 INY
    cpu.inc('Y');
    goto L_8481BA;
L_8481BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81BAu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81BAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8481BA INY
    cpu.inc('Y');
    goto L_8481BB;
L_8481BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81BBu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81BBu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $8481BB LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8481BD;
L_8481BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81BDu,cpu,0xDFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81BDu, 6u, 4u, ((0x848087u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8481BD CMP
    cpu.compareA(hw.readW(((0x848087u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_8481C1;
L_8481C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81C1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8481C1 BNE -> $8481C9
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8481C9; }
    goto L_8481C3;
L_8481C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81C3u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81C3u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8481C3 DEC
    cpu.decMem(hw, cpu.address("dp", 0x10u), cpu.m8?8:16);
    goto L_8481C5;
L_8481C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81C5u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8481C5 BMI -> $8481E1
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_8481E1; }
    goto L_8481C7;
L_8481C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81C7u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81C7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8481C7 BRA -> $8481B9
    goto L_8481B9;
L_8481C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81C9u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81C9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8481C9 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8481CB;
L_8481CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81CBu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81CBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8481CB DEY
    cpu.decReg('Y');
    goto L_8481CC;
L_8481CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81CCu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81CCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8481CC DEY
    cpu.decReg('Y');
    goto L_8481CD;
L_8481CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81CDu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81CDu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $8481CD LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8481CF;
L_8481CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81CFu,cpu,0xDFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81CFu, 6u, 4u, ((0x848087u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8481CF CMP
    cpu.compareA(hw.readW(((0x848087u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_8481D3;
L_8481D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81D3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81D3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8481D3 BNE -> $8481DB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8481DB; }
    goto L_8481D5;
L_8481D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81D5u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81D5u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8481D5 DEC
    cpu.decMem(hw, cpu.address("dp", 0x10u), cpu.m8?8:16);
    goto L_8481D7;
L_8481D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81D7u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81D7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8481D7 BPL -> $8481CB
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_8481CB; }
    goto L_8481D9;
L_8481D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81D9u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81D9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8481D9 BRA -> $8481E1
    goto L_8481E1;
L_8481DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81DBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81DBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8481DB LDA
    cpu.setA(0x1u, 16);
    goto L_8481DE;
L_8481DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81DEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81DEu, 5u, 3u, cpu.address("abs", 0x0606u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8481DE STA
    hw.write(cpu.address("abs", 0x606u), cpu.a, cpu.m8?8:16);
    goto L_8481E1;
L_8481E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81E1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81E1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8481E1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8481E1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8481E1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8485DD_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8485DDu: goto L_8485DD;
    case 0x8485DFu: goto L_8485DF;
    case 0x8485E2u: goto L_8485E2;
    case 0x8485E4u: goto L_8485E4;
    case 0x8485E6u: goto L_8485E6;
    case 0x8485E9u: goto L_8485E9;
    case 0x8485ECu: goto L_8485EC;
    case 0x8485EEu: goto L_8485EE;
    case 0x8485F1u: goto L_8485F1;
    case 0x8485F4u: goto L_8485F4;
    case 0x8485F7u: goto L_8485F7;
    case 0x8485FAu: goto L_8485FA;
    case 0x8485FEu: goto L_8485FE;
    case 0x8485FFu: goto L_8485FF;
    case 0x848602u: goto L_848602;
    case 0x848605u: goto L_848605;
    case 0x848607u: goto L_848607;
    case 0x848608u: goto L_848608;
    case 0x84860Bu: goto L_84860B;
    case 0x84860Cu: goto L_84860C;
    case 0x84860Fu: goto L_84860F;
    case 0x848612u: goto L_848612;
    case 0x848615u: goto L_848615;
    case 0x848618u: goto L_848618;
    case 0x84861Cu: goto L_84861C;
    case 0x84861Du: goto L_84861D;
    case 0x848620u: goto L_848620;
    case 0x848623u: goto L_848623;
    case 0x848625u: goto L_848625;
    case 0x848626u: goto L_848626;
    case 0x848629u: goto L_848629;
    case 0x84862Au: goto L_84862A;
    case 0x84862Du: goto L_84862D;
    case 0x848630u: goto L_848630;
    case 0x848633u: goto L_848633;
    case 0x848635u: goto L_848635;
    case 0x848638u: goto L_848638;
    case 0x84863Au: goto L_84863A;
    case 0x84863Du: goto L_84863D;
    case 0x84863Fu: goto L_84863F;
    case 0x848643u: goto L_848643;
    case 0x848646u: goto L_848646;
    case 0x848648u: goto L_848648;
    case 0x84864Au: goto L_84864A;
    case 0x84864Bu: goto L_84864B;
    case 0x84864Du: goto L_84864D;
    case 0x848651u: goto L_848651;
    case 0x848653u: goto L_848653;
    case 0x848655u: goto L_848655;
    case 0x848658u: goto L_848658;
    case 0x84865Bu: goto L_84865B;
    case 0x84865Du: goto L_84865D;
    case 0x848660u: goto L_848660;
    case 0x848662u: goto L_848662;
    case 0x848664u: goto L_848664;
    case 0x848666u: goto L_848666;
    case 0x848668u: goto L_848668;
    case 0x84866Au: goto L_84866A;
    case 0x84866Cu: goto L_84866C;
    case 0x84866Eu: goto L_84866E;
    case 0x848670u: goto L_848670;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8485DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85DDu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85DDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8485DD SEP
    cpu.sep(0x20u);
    goto L_8485DF;
L_8485DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85DFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85DFu, 4u, 3u, cpu.address("abs", 0x0657u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8485DF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x657u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8485E2;
L_8485E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8485E2 BEQ -> $848653
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848653; }
    goto L_8485E4;
L_8485E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E4u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8485E4 STZ
    hw.write(cpu.address("dp", 0x49u), 0, cpu.m8?8:16);
    goto L_8485E6;
L_8485E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E6u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E6u, 4u, 3u, cpu.address("abs", 0x062Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8485E6 STZ
    hw.write(cpu.address("abs", 0x62Fu), 0, cpu.m8?8:16);
    goto L_8485E9;
L_8485E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E9u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E9u, 4u, 3u, cpu.address("abs", 0x0657u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8485E9 STZ
    hw.write(cpu.address("abs", 0x657u), 0, cpu.m8?8:16);
    goto L_8485EC;
L_8485EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85ECu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85ECu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8485EC REP
    cpu.rep(0x20u);
    goto L_8485EE;
L_8485EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85EEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85EEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8485EE LDA
    cpu.setA(0xBF00u, 16);
    goto L_8485F1;
L_8485F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F1u, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8485F1 STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_8485F4;
L_8485F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8485F4 LDA
    cpu.setA(0x8Bu, 16);
    goto L_8485F7;
L_8485F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F7u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8485F7 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_8485FA;
L_8485FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85FAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85FAu, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8485FA JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x85FDu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x85FEu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x8485FAu); }
    goto L_8485FE;
L_8485FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85FEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x85FEu,0x8485FEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85FEu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85FEu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8485FE PHB
    cpu.push("PHB", hw);
    goto L_8485FF;
L_8485FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85FFu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85FFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8485FF LDX
    cpu.setX(0x8000u, 16);
    goto L_848602;
L_848602:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8602u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8602u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8602u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848602 LDY
    cpu.setY(0x2800u, 16);
    goto L_848605;
L_848605:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8605u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8605u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8605u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848605 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848607;
L_848607:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8607u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8607u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8607u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848607 DEC
    cpu.decReg('A');
    goto L_848608;
L_848608:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8608u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8608u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0x8608u, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $848608 MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_84860B;
L_84860B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x860Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x860Bu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x860Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $84860B PLB
    cpu.pop("PLB", hw);
    goto L_84860C;
L_84860C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x860Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x860Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x860Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84860C LDA
    cpu.setA(0x8F64u, 16);
    goto L_84860F;
L_84860F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x860Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x860Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x860Fu, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84860F STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_848612;
L_848612:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8612u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8612u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8612u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848612 LDA
    cpu.setA(0x89u, 16);
    goto L_848615;
L_848615:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8615u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8615u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8615u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848615 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_848618;
L_848618:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8618u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8618u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8618u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848618 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x861Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x861Cu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x848618u); }
    goto L_84861C;
L_84861C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x861Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x861Cu,0x84861Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x861Cu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x861Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $84861C PHB
    cpu.push("PHB", hw);
    goto L_84861D;
L_84861D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x861Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x861Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x861Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84861D LDX
    cpu.setX(0x8000u, 16);
    goto L_848620;
L_848620:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8620u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8620u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8620u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848620 LDY
    cpu.setY(0x6000u, 16);
    goto L_848623;
L_848623:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8623u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8623u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8623u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848623 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848625;
L_848625:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8625u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8625u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8625u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848625 DEC
    cpu.decReg('A');
    goto L_848626;
L_848626:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8626u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8626u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0x8626u, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $848626 MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_848629;
L_848629:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8629u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8629u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8629u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $848629 PLB
    cpu.pop("PLB", hw);
    goto L_84862A;
L_84862A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x862Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x862Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x862Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84862A LDX
    cpu.setX(0x6u, 16);
    goto L_84862D;
L_84862D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x862Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x862Du,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x862Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84862D LDY
    cpu.setY(0x1Cu, 16);
    goto L_848630;
L_848630:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8630u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8630u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8630u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848630 LDA
    cpu.setA(0x6504u, 16);
    goto L_848633;
L_848633:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8633u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8633u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8633u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848633 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_848635;
L_848635:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8635u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8635u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8635u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848635 LDA
    cpu.setA(0x7Eu, 16);
    goto L_848638;
L_848638:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8638u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8638u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8638u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848638 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_84863A;
L_84863A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x863Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x863Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x863Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84863A LDA
    cpu.setA(0x408u, 16);
    goto L_84863D;
L_84863D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x863Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x863Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x863Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84863D STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_84863F;
L_84863F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x863Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x863Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x863Fu, 8u, 4u, 0x80A85Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84863F JSL -> $80A85F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8642u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8643u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A85Fu, 0x84863Fu); }
    goto L_848643;
L_848643:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8643u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8643u,0x848643u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8643u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8643u, 6u, 3u, cpu.address("abs", 0x8C34u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848643 JSR -> $848C34 stack real
    { cpu.push16Value(hw,0x8645u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8646u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8C34u), 0x848643u); }
    goto L_848646;
L_848646:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8646u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8646u,0x848646u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8646u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8646u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848646 SEP
    cpu.sep(0x20u);
    goto L_848648;
L_848648:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8648u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8648u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8648u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848648 LDA
    cpu.setA(0xC1u, 8);
    goto L_84864A;
L_84864A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x864Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x864Au,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x864Au, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84864A XBA
    cpu.xba();
    goto L_84864B;
L_84864B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x864Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x864Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x864Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84864B LDA
    cpu.setA(0xF5u, 8);
    goto L_84864D;
L_84864D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x864Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x864Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x864Du, 8u, 4u, 0x808700u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84864D JSL -> $808700 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8650u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8651u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808700u, 0x84864Du); }
    goto L_848651;
L_848651:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8651u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8651u,0x848651u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8651u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8651u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848651 BRA -> $84866E
    goto L_84866E;
L_848653:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8653u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8653u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8653u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848653 REP
    cpu.rep(0x20u);
    goto L_848655;
L_848655:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8655u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8655u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8655u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848655 LDA
    cpu.setA(0x1u, 16);
    goto L_848658;
L_848658:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8658u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8658u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8658u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848658 STA
    hw.write(cpu.address("abs", 0x135u), cpu.a, cpu.m8?8:16);
    goto L_84865B;
L_84865B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x865Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x865Bu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x865Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84865B SEP
    cpu.sep(0x20u);
    goto L_84865D;
L_84865D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x865Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x865Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x865Du, 4u, 3u, cpu.address("abs", 0x06FDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84865D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6FDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848660;
L_848660:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8660u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8660u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8660u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848660 BIT
    cpu.bit(0x1u, true);
    goto L_848662;
L_848662:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8662u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8662u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8662u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848662 BNE -> $84866A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84866A; }
    goto L_848664;
L_848664:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8664u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8664u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8664u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848664 LDA
    cpu.setA(0x8Bu, 8);
    goto L_848666;
L_848666:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8666u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8666u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8666u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848666 STA
    hw.write(cpu.address("dp", 0x46u), cpu.a, cpu.m8?8:16);
    goto L_848668;
L_848668:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8668u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8668u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8668u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848668 BRA -> $84866E
    goto L_84866E;
L_84866A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x866Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x866Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x866Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84866A LDA
    cpu.setA(0x96u, 8);
    goto L_84866C;
L_84866C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x866Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x866Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x866Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84866C STA
    hw.write(cpu.address("dp", 0x46u), cpu.a, cpu.m8?8:16);
    goto L_84866E;
L_84866E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x866Eu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x866Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x866Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84866E REP
    cpu.rep(0x20u);
    goto L_848670;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x866Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x866Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84866E REP
    cpu.rep(0x20u);
    goto L_848670;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x866Eu,0x84866Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848670:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8670u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8670u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8670u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848670 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848670u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848670u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8670u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8670u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848670 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848670u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848670u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8670u,0x848670u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_849691_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849691u: goto L_849691;
    case 0x849693u: goto L_849693;
    case 0x849694u: goto L_849694;
    case 0x849695u: goto L_849695;
    case 0x849696u: goto L_849696;
    case 0x849699u: goto L_849699;
    case 0x84969Au: goto L_84969A;
    case 0x84969Du: goto L_84969D;
    case 0x84969Fu: goto L_84969F;
    case 0x8496A2u: goto L_8496A2;
    case 0x8496A4u: goto L_8496A4;
    case 0x8496A7u: goto L_8496A7;
    case 0x8496AAu: goto L_8496AA;
    case 0x8496AEu: goto L_8496AE;
    case 0x8496B1u: goto L_8496B1;
    case 0x8496B3u: goto L_8496B3;
    case 0x8496B5u: goto L_8496B5;
    case 0x8496B7u: goto L_8496B7;
    case 0x8496B9u: goto L_8496B9;
    case 0x8496BAu: goto L_8496BA;
    case 0x8496BDu: goto L_8496BD;
    case 0x8496BFu: goto L_8496BF;
    case 0x8496C1u: goto L_8496C1;
    case 0x8496C2u: goto L_8496C2;
    case 0x8496C5u: goto L_8496C5;
    case 0x8496C7u: goto L_8496C7;
    case 0x8496C8u: goto L_8496C8;
    case 0x8496C9u: goto L_8496C9;
    case 0x8496CAu: goto L_8496CA;
    case 0x8496CBu: goto L_8496CB;
    case 0x8496CDu: goto L_8496CD;
    case 0x8496CEu: goto L_8496CE;
    case 0x8496D1u: goto L_8496D1;
    case 0x8496D3u: goto L_8496D3;
    case 0x8496D5u: goto L_8496D5;
    case 0x8496D6u: goto L_8496D6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849691:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9691u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9691u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9691u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849691 REP
    cpu.rep(0x20u);
    goto L_849693;
L_849693:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9693u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9693u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9693u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $849693 PHB
    cpu.push("PHB", hw);
    goto L_849694;
L_849694:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9694u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9694u,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9694u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $849694 PHK
    cpu.push("PHK", hw);
    goto L_849695;
L_849695:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9695u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9695u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9695u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $849695 PLB
    cpu.pop("PLB", hw);
    goto L_849696;
L_849696:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9696u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9696u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9696u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849696 LDA
    cpu.setA(0x2800u, 16);
    goto L_849699;
L_849699:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9699u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9699u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9699u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849699 CLC
    cpu.setFlag('C', false);
    goto L_84969A;
L_84969A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x969Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x969Au,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x969Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84969A ADC
    cpu.adc(0x45Au);
    goto L_84969D;
L_84969D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x969Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x969Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x969Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84969D STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84969F;
L_84969F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x969Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x969Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x969Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84969F LDA
    cpu.setA(0x7Eu, 16);
    goto L_8496A2;
L_8496A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8496A2 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_8496A4;
L_8496A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A4u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8496A4 LDX
    cpu.setX(0x0u, 16);
    goto L_8496A7;
L_8496A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A7u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8496A7 LDY
    cpu.setY(0x0u, 16);
    goto L_8496AA;
L_8496AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96AAu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96AAu, 6u, 4u, ((0x8496D7u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8496AA LDA
    cpu.loadA(hw.readW(((0x8496D7u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8496AE;
L_8496AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96AEu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96AEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8496AE CMP
    cpu.compareA(0xFFFFu);
    goto L_8496B1;
L_8496B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8496B1 BEQ -> $8496D5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8496D5; }
    goto L_8496B3;
L_8496B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B3u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B3u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $8496B3 STA
    hw.write(cpu.addressDpLongY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_8496B5;
L_8496B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8496B5 STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_8496B7;
L_8496B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8496B7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8496B9;
L_8496B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B9u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8496B9 CLC
    cpu.setFlag('C', false);
    goto L_8496BA;
L_8496BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96BAu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96BAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8496BA ADC
    cpu.adc(0x40u);
    goto L_8496BD;
L_8496BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96BDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96BDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8496BD STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_8496BF;
L_8496BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96BFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96BFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8496BF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8496C1;
L_8496C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96C1u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96C1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8496C1 CLC
    cpu.setFlag('C', false);
    goto L_8496C2;
L_8496C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96C2u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96C2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8496C2 ADC
    cpu.adc(0x10u);
    goto L_8496C5;
L_8496C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96C5u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96C5u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $8496C5 STA
    hw.write(cpu.addressDpLongY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_8496C7;
L_8496C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96C7u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96C7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8496C7 INY
    cpu.inc('Y');
    goto L_8496C8;
L_8496C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96C8u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96C8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8496C8 INY
    cpu.inc('Y');
    goto L_8496C9;
L_8496C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96C9u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96C9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8496C9 INX
    cpu.inc('X');
    goto L_8496CA;
L_8496CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96CAu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96CAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8496CA INX
    cpu.inc('X');
    goto L_8496CB;
L_8496CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96CBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96CBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8496CB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8496CD;
L_8496CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96CDu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96CDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8496CD SEC
    cpu.setFlag('C', true);
    goto L_8496CE;
L_8496CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96CEu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96CEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8496CE SBC
    cpu.sbc(0x40u);
    goto L_8496D1;
L_8496D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96D1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96D1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8496D1 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_8496D3;
L_8496D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96D3u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96D3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8496D3 BRA -> $8496AA
    goto L_8496AA;
L_8496D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96D5u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96D5u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8496D5 PLB
    cpu.pop("PLB", hw);
    goto L_8496D6;
L_8496D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96D6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96D6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8496D6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8496D6u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8496D6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_849800_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849800u: goto L_849800;
    case 0x849802u: goto L_849802;
    case 0x849805u: goto L_849805;
    case 0x849808u: goto L_849808;
    case 0x84980Bu: goto L_84980B;
    case 0x84980Du: goto L_84980D;
    case 0x849810u: goto L_849810;
    case 0x849812u: goto L_849812;
    case 0x849815u: goto L_849815;
    case 0x849817u: goto L_849817;
    case 0x84981Bu: goto L_84981B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849800:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9800u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9800u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9800u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849800 REP
    cpu.rep(0x20u);
    goto L_849802;
L_849802:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9802u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9802u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9802u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849802 LDX
    cpu.setX(0x2u, 16);
    goto L_849805;
L_849805:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9805u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9805u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9805u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849805 LDY
    cpu.setY(0x5u, 16);
    goto L_849808;
L_849808:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9808u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9808u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9808u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849808 LDA
    cpu.setA(0x2C48u, 16);
    goto L_84980B;
L_84980B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x980Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x980Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x980Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84980B STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84980D;
L_84980D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x980Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x980Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x980Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84980D LDA
    cpu.setA(0x7Eu, 16);
    goto L_849810;
L_849810:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9810u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9810u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9810u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849810 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_849812;
L_849812:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9812u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9812u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9812u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849812 LDA
    cpu.setA(0x1C00u, 16);
    goto L_849815;
L_849815:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9815u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9815u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9815u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849815 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_849817;
L_849817:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9817u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9817u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9817u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849817 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x981Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x981Bu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x849817u); }
    goto L_84981B;
L_84981B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x981Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x981Bu,0x84981Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x981Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x981Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84981B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84981Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84981Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_849800_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849800u: goto L_849800;
    case 0x849802u: goto L_849802;
    case 0x849805u: goto L_849805;
    case 0x849808u: goto L_849808;
    case 0x84980Bu: goto L_84980B;
    case 0x84980Du: goto L_84980D;
    case 0x849810u: goto L_849810;
    case 0x849812u: goto L_849812;
    case 0x849815u: goto L_849815;
    case 0x849817u: goto L_849817;
    case 0x84981Bu: goto L_84981B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849800:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9800u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9800u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9800u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849800 REP
    cpu.rep(0x20u);
    goto L_849802;
L_849802:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9802u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9802u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9802u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849802 LDX
    cpu.setX(0x2u, 16);
    goto L_849805;
L_849805:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9805u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9805u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9805u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849805 LDY
    cpu.setY(0x5u, 16);
    goto L_849808;
L_849808:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9808u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9808u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9808u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849808 LDA
    cpu.setA(0x2C48u, 16);
    goto L_84980B;
L_84980B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x980Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x980Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x980Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84980B STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84980D;
L_84980D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x980Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x980Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x980Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84980D LDA
    cpu.setA(0x7Eu, 16);
    goto L_849810;
L_849810:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9810u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9810u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9810u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849810 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_849812;
L_849812:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9812u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9812u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9812u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849812 LDA
    cpu.setA(0x1C00u, 16);
    goto L_849815;
L_849815:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9815u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9815u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9815u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849815 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_849817;
L_849817:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9817u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9817u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9817u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849817 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x981Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x981Bu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x849817u); }
    goto L_84981B;
L_84981B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x981Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x981Bu,0x84981Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x981Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x981Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84981B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84981Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84981Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_849CB4_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849CB4u: goto L_849CB4;
    case 0x849CB6u: goto L_849CB6;
    case 0x849CB9u: goto L_849CB9;
    case 0x849CBBu: goto L_849CBB;
    case 0x849CBDu: goto L_849CBD;
    case 0x849CC0u: goto L_849CC0;
    case 0x849CC1u: goto L_849CC1;
    case 0x849CC2u: goto L_849CC2;
    case 0x849CC5u: goto L_849CC5;
    case 0x849CC8u: goto L_849CC8;
    case 0x849CCAu: goto L_849CCA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849CB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB4u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CB4 SEP
    cpu.sep(0x20u);
    goto L_849CB6;
L_849CB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB6u, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CB6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849CB9;
L_849CB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CB9 AND
    cpu.logicAnd(0x1u);
    goto L_849CBB;
L_849CBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBBu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CBB REP
    cpu.rep(0x20u);
    goto L_849CBD;
L_849CBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBDu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CBD AND
    cpu.logicAnd(0xFFu);
    goto L_849CC0;
L_849CC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CC0 ASL
    cpu.aslA();
    goto L_849CC1;
L_849CC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC1u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CC1 TAX
    cpu.transfer("TAX");
    goto L_849CC2;
L_849CC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC2u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC2u, 5u, 3u, cpu.address("abs", 0x9CC7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849CC2 PEA
    cpu.push16Value(hw, 0x9CC7u);
    goto L_849CC5;
L_849CC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC5u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC5u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x9CCBu + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $849CC5 JMP (9CCB,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x9CCBu+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x849CC5u); return; }
L_849CC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC8u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CC8u,0x849CC8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CC8 REP
    cpu.rep(0x20u);
    goto L_849CCA;
L_849CCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCAu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849CCA RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849CCAu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849CCAu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_849CB4_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849CB4u: goto L_849CB4;
    case 0x849CB6u: goto L_849CB6;
    case 0x849CB9u: goto L_849CB9;
    case 0x849CBBu: goto L_849CBB;
    case 0x849CBDu: goto L_849CBD;
    case 0x849CC0u: goto L_849CC0;
    case 0x849CC1u: goto L_849CC1;
    case 0x849CC2u: goto L_849CC2;
    case 0x849CC5u: goto L_849CC5;
    case 0x849CC8u: goto L_849CC8;
    case 0x849CCAu: goto L_849CCA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849CB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB4u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CB4 SEP
    cpu.sep(0x20u);
    goto L_849CB6;
L_849CB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB6u, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CB6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849CB9;
L_849CB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CB9 AND
    cpu.logicAnd(0x1u);
    goto L_849CBB;
L_849CBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBBu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CBB REP
    cpu.rep(0x20u);
    goto L_849CBD;
L_849CBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBDu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CBD AND
    cpu.logicAnd(0xFFu);
    goto L_849CC0;
L_849CC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CC0 ASL
    cpu.aslA();
    goto L_849CC1;
L_849CC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC1u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CC1 TAX
    cpu.transfer("TAX");
    goto L_849CC2;
L_849CC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC2u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC2u, 5u, 3u, cpu.address("abs", 0x9CC7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849CC2 PEA
    cpu.push16Value(hw, 0x9CC7u);
    goto L_849CC5;
L_849CC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC5u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC5u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x9CCBu + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $849CC5 JMP (9CCB,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x9CCBu+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x849CC5u); return; }
L_849CC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC8u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CC8u,0x849CC8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CC8 REP
    cpu.rep(0x20u);
    goto L_849CCA;
L_849CCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCAu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849CCA RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849CCAu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849CCAu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_849CB4_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849CB4u: goto L_849CB4;
    case 0x849CB6u: goto L_849CB6;
    case 0x849CB9u: goto L_849CB9;
    case 0x849CBBu: goto L_849CBB;
    case 0x849CBDu: goto L_849CBD;
    case 0x849CC0u: goto L_849CC0;
    case 0x849CC1u: goto L_849CC1;
    case 0x849CC2u: goto L_849CC2;
    case 0x849CC5u: goto L_849CC5;
    case 0x849CC8u: goto L_849CC8;
    case 0x849CCAu: goto L_849CCA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849CB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB4u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CB4 SEP
    cpu.sep(0x20u);
    goto L_849CB6;
L_849CB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB6u, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CB6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849CB9;
L_849CB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CB9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CB9 AND
    cpu.logicAnd(0x1u);
    goto L_849CBB;
L_849CBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBBu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CBB REP
    cpu.rep(0x20u);
    goto L_849CBD;
L_849CBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBDu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CBDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CBD AND
    cpu.logicAnd(0xFFu);
    goto L_849CC0;
L_849CC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CC0 ASL
    cpu.aslA();
    goto L_849CC1;
L_849CC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC1u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CC1 TAX
    cpu.transfer("TAX");
    goto L_849CC2;
L_849CC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC2u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC2u, 5u, 3u, cpu.address("abs", 0x9CC7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849CC2 PEA
    cpu.push16Value(hw, 0x9CC7u);
    goto L_849CC5;
L_849CC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC5u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC5u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x9CCBu + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $849CC5 JMP (9CCB,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x9CCBu+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x849CC5u); return; }
L_849CC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC8u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CC8u,0x849CC8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CC8 REP
    cpu.rep(0x20u);
    goto L_849CCA;
L_849CCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCAu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849CCA RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849CCAu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849CCAu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_DC8189_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xDC8189u: goto L_DC8189;
    case 0xDC818Cu: goto L_DC818C;
    case 0xDC818Fu: goto L_DC818F;
    case 0xDC8191u: goto L_DC8191;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_DC8189:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8189u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8189u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8189u, 9u, 3u, cpu.address("absx", 0x1040u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $DC8189 INC
    cpu.incMem(hw, cpu.address("absx", 0x1040u), cpu.m8?8:16);
    goto L_DC818C;
L_DC818C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x818Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x818Cu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x818Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $DC818C CPX
    cpu.compareX(0x66u);
    goto L_DC818F;
L_DC818F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x818Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x818Fu,cpu,0x03u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x818Fu, 5u, 2u, cpu.addressStack(0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $DC818F ORA
    cpu.logicOr(hw.readW(cpu.addressStack(0x1u), cpu.m8?8:16));
    goto L_DC8191;
L_DC8191:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8191u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8191u,cpu,0x02u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8191u, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $DC8191 COP
    hw.partial(0xDC8191u, "COP"); return;
}

