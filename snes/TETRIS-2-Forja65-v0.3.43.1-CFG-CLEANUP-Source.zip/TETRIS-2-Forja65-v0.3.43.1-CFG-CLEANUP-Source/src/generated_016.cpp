#include "generated.hpp"
void sub_6083A4_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x6083A4u: goto L_6083A4;
    case 0x6083A5u: goto L_6083A5;
    case 0x6083A7u: goto L_6083A7;
    case 0x6083A9u: goto L_6083A9;
    case 0x6083AAu: goto L_6083AA;
    case 0x6083ADu: goto L_6083AD;
    case 0x6083AFu: goto L_6083AF;
    case 0x6083B2u: goto L_6083B2;
    case 0x6083B3u: goto L_6083B3;
    case 0x6083B4u: goto L_6083B4;
    case 0x6083B6u: goto L_6083B6;
    case 0x6083B7u: goto L_6083B7;
    case 0x6083B8u: goto L_6083B8;
    case 0x6083BAu: goto L_6083BA;
    case 0x6083BEu: goto L_6083BE;
    case 0x6083BFu: goto L_6083BF;
    case 0x6083C1u: goto L_6083C1;
    case 0x6083C5u: goto L_6083C5;
    case 0x6083C6u: goto L_6083C6;
    case 0x6083C7u: goto L_6083C7;
    case 0x6083C8u: goto L_6083C8;
    case 0x6083C9u: goto L_6083C9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_6083A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A4u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A4u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $6083A4 PHP
    cpu.push("PHP", hw);
    goto L_6083A5;
L_6083A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6083A5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x46u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_6083A7;
L_6083A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A7u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6083A7 BMI -> $6083C8
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_6083C8; }
    goto L_6083A9;
L_6083A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A9u,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A9u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $6083A9 PHK
    cpu.push("PHK", hw);
    goto L_6083AA;
L_6083AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83AAu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83AAu, 5u, 3u, cpu.address("abs", 0x83C7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $6083AA PEA
    cpu.push16Value(hw, 0x83C7u);
    goto L_6083AD;
L_6083AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83ADu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83ADu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6083AD REP
    cpu.rep(0x20u);
    goto L_6083AF;
L_6083AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83AFu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83AFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6083AF AND
    cpu.logicAnd(0xFFu);
    goto L_6083B2;
L_6083B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B2u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B2u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $6083B2 PHA
    cpu.push("PHA", hw);
    goto L_6083B3;
L_6083B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B3u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6083B3 ASL
    cpu.aslA();
    goto L_6083B4;
L_6083B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B4u,cpu,0x63u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B4u, 5u, 2u, cpu.addressStack(0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6083B4 ADC
    cpu.adc(hw.readW(cpu.addressStack(0x1u), cpu.m8?8:16));
    goto L_6083B6;
L_6083B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B6u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6083B6 TAX
    cpu.transfer("TAX");
    goto L_6083B7;
L_6083B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B7u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B7u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $6083B7 PLA
    cpu.pop("PLA", hw);
    goto L_6083B8;
L_6083B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B8u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6083B8 SEP
    cpu.sep(0x20u);
    goto L_6083BA;
L_6083BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83BAu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83BAu, 5u, 4u, ((0x8083CCu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6083BA LDA
    cpu.loadA(hw.readW(((0x8083CCu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_6083BE;
L_6083BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83BEu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83BEu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $6083BE PHA
    cpu.push("PHA", hw);
    goto L_6083BF;
L_6083BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83BFu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83BFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6083BF REP
    cpu.rep(0x20u);
    goto L_6083C1;
L_6083C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C1u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C1u, 6u, 4u, ((0x8083CAu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6083C1 LDA
    cpu.loadA(hw.readW(((0x8083CAu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_6083C5;
L_6083C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C5u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6083C5 DEC
    cpu.decReg('A');
    goto L_6083C6;
L_6083C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C6u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C6u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $6083C6 PHA
    cpu.push("PHA", hw);
    goto L_6083C7;
L_6083C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C7u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $6083C7 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x6083C7u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x6083C7u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_6083C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C8u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C8u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $6083C8 PLP
    cpu.pop("PLP", hw);
    goto L_6083C9;
L_6083C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C9u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83C9u,0x6083C9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $6083C9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x6083C9u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x6083C9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8083CA_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8083CAu: goto L_8083CA;
    case 0x8083CEu: goto L_8083CE;
    case 0x8083D0u: goto L_8083D0;
    case 0x8083D3u: goto L_8083D3;
    case 0x8083D6u: goto L_8083D6;
    case 0x8083DAu: goto L_8083DA;
    case 0x8083DCu: goto L_8083DC;
    case 0x8083DFu: goto L_8083DF;
    case 0x8083E2u: goto L_8083E2;
    case 0x8083E4u: goto L_8083E4;
    case 0x808410u: goto L_808410;
    case 0x808412u: goto L_808412;
    case 0x808445u: goto L_808445;
    case 0x808449u: goto L_808449;
    case 0x80844Bu: goto L_80844B;
    case 0x80844Du: goto L_80844D;
    case 0x80844Eu: goto L_80844E;
    case 0x808451u: goto L_808451;
    case 0x808453u: goto L_808453;
    case 0x808456u: goto L_808456;
    case 0x808457u: goto L_808457;
    case 0x808458u: goto L_808458;
    case 0x80845Au: goto L_80845A;
    case 0x80845Bu: goto L_80845B;
    case 0x80845Cu: goto L_80845C;
    case 0x80845Eu: goto L_80845E;
    case 0x808462u: goto L_808462;
    case 0x808463u: goto L_808463;
    case 0x808465u: goto L_808465;
    case 0x808469u: goto L_808469;
    case 0x80846Au: goto L_80846A;
    case 0x80846Bu: goto L_80846B;
    case 0x80847Fu: goto L_80847F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8083CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83CAu,cpu,0x0Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83CAu, 5u, 4u, 0x148084u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083CA ORA
    cpu.logicOr(hw.readW(0x148084u, cpu.m8?8:16));
    goto L_8083CE;
L_8083CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83CEu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83CEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083CE STY
    hw.write(cpu.address("dp", 0x80u), cpu.y, cpu.x8?8:16);
    goto L_8083D0;
L_8083D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83D0u,cpu,0x19u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83D0u, 4u + 1u, 3u, cpu.address("absy", 0x8084u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083D0 ORA
    cpu.logicOr(hw.readW(cpu.address("absy", 0x8084u), cpu.m8?8:16));
    goto L_8083D3;
L_8083D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83D3u,cpu,0x1Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83D3u, 7u, 3u, cpu.address("absx", 0x8084u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083D3 ASL
    cpu.aslMem(hw, cpu.address("absx", 0x8084u), cpu.m8?8:16);
    goto L_8083D6;
L_8083D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83D6u,cpu,0x1Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83D6u, 5u, 4u, ((0x208084u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083D6 ORA
    cpu.logicOr(hw.readW(((0x208084u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_8083DA;
L_8083DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83DAu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83DAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083DA STY
    hw.write(cpu.address("dp", 0x80u), cpu.y, cpu.x8?8:16);
    goto L_8083DC;
L_8083DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83DCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83DCu, 6u, 3u, cpu.address("abs", 0x8084u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8083DC JSR -> $808084 stack real
    { cpu.push16Value(hw,0x83DEu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x83DFu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8084u), 0x8083DCu); }
    goto L_8083DF;
L_8083DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83DFu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83DFu,0x8083DFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83DFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83DFu, 6u, 3u, cpu.address("abs", 0x8084u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8083DF JSR -> $808084 stack real
    { cpu.push16Value(hw,0x83E1u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x83E2u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8084u), 0x8083DFu); }
    goto L_8083E2;
L_8083E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83E2u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83E2u,0x8083E2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83E2u,cpu,0x25u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83E2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x84u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083E2 AND
    cpu.logicAnd(hw.readW(cpu.address("dp", 0x84u), cpu.m8?8:16));
    goto L_8083E4;
L_8083E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83E4u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83E4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083E4 BRA -> $808410
    goto L_808410;
L_808410:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8410u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8410u,cpu,0x15u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8410u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xABu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808410 ORA
    cpu.logicOr(hw.readW(cpu.address("dpx", 0xABu), cpu.m8?8:16));
    goto L_808412;
L_808412:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8412u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8412u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8412u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808412 BRA -> $80847F
    goto L_80847F;
L_808445:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8445u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8445u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8445u, 8u, 4u, 0x80870Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808445 JSL -> $80870C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8448u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8449u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80870Cu, 0x808445u); }
    goto L_808449;
L_808449:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8449u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8449u,0x808449u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8449u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8449u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x48u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808449 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x48u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80844B;
L_80844B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x844Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x844Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x844Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80844B AND
    cpu.logicAnd(0x7Fu);
    goto L_80844D;
L_80844D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x844Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x844Du,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x844Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80844D PHK
    cpu.push("PHK", hw);
    goto L_80844E;
L_80844E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x844Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x844Eu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x844Eu, 5u, 3u, cpu.address("abs", 0x846Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80844E PEA
    cpu.push16Value(hw, 0x846Bu);
    goto L_808451;
L_808451:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8451u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8451u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8451u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808451 REP
    cpu.rep(0x20u);
    goto L_808453;
L_808453:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8453u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8453u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8453u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808453 AND
    cpu.logicAnd(0xFFu);
    goto L_808456;
L_808456:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8456u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8456u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8456u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808456 PHA
    cpu.push("PHA", hw);
    goto L_808457;
L_808457:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8457u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8457u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8457u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808457 ASL
    cpu.aslA();
    goto L_808458;
L_808458:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8458u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8458u,cpu,0x63u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8458u, 5u, 2u, cpu.addressStack(0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808458 ADC
    cpu.adc(hw.readW(cpu.addressStack(0x1u), cpu.m8?8:16));
    goto L_80845A;
L_80845A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x845Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x845Au,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x845Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80845A TAX
    cpu.transfer("TAX");
    goto L_80845B;
L_80845B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x845Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x845Bu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x845Bu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80845B PLA
    cpu.pop("PLA", hw);
    goto L_80845C;
L_80845C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x845Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x845Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x845Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80845C SEP
    cpu.sep(0x20u);
    goto L_80845E;
L_80845E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x845Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x845Eu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x845Eu, 5u, 4u, ((0x808470u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80845E LDA
    cpu.loadA(hw.readW(((0x808470u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808462;
L_808462:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8462u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8462u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8462u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808462 PHA
    cpu.push("PHA", hw);
    goto L_808463;
L_808463:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8463u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8463u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8463u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808463 REP
    cpu.rep(0x20u);
    goto L_808465;
L_808465:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8465u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8465u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8465u, 6u, 4u, ((0x80846Eu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808465 LDA
    cpu.loadA(hw.readW(((0x80846Eu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808469;
L_808469:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8469u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8469u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8469u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808469 DEC
    cpu.decReg('A');
    goto L_80846A;
L_80846A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x846Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Au,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80846A PHA
    cpu.push("PHA", hw);
    goto L_80846B;
L_80846B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x846Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Bu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80846B RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80846Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80846Bu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80847F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x847Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x847Fu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x847Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80847F BRA -> $808445
    goto L_808445;
}

void sub_808444_E0M1X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808444u: goto L_808444;
    case 0x808445u: goto L_808445;
    case 0x808449u: goto L_808449;
    case 0x80844Bu: goto L_80844B;
    case 0x80844Du: goto L_80844D;
    case 0x80844Eu: goto L_80844E;
    case 0x808451u: goto L_808451;
    case 0x808453u: goto L_808453;
    case 0x808456u: goto L_808456;
    case 0x808457u: goto L_808457;
    case 0x808458u: goto L_808458;
    case 0x80845Au: goto L_80845A;
    case 0x80845Bu: goto L_80845B;
    case 0x80845Cu: goto L_80845C;
    case 0x80845Eu: goto L_80845E;
    case 0x808462u: goto L_808462;
    case 0x808463u: goto L_808463;
    case 0x808465u: goto L_808465;
    case 0x808469u: goto L_808469;
    case 0x80846Au: goto L_80846A;
    case 0x80846Bu: goto L_80846B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808444:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8444u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8444u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8444u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808444 PHP
    cpu.push("PHP", hw);
    goto L_808445;
L_808445:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8445u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8445u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8445u, 8u, 4u, 0x80870Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808445 JSL -> $80870C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8448u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8449u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80870Cu, 0x808445u); }
    goto L_808449;
L_808449:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8449u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8449u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8449u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x48u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808449 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x48u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80844B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8449u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8449u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x48u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808449 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x48u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80844B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8449u,0x808449u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80844B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x844Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x844Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x844Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80844B AND
    cpu.logicAnd(0x7Fu);
    goto L_80844D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x844Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x844Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80844B AND
    cpu.logicAnd(0x7Fu);
    goto L_80844D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x844Bu,0x80844Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80844D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x844Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x844Du,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x844Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80844D PHK
    cpu.push("PHK", hw);
    goto L_80844E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x844Du,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x844Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80844D PHK
    cpu.push("PHK", hw);
    goto L_80844E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x844Du,0x80844Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80844E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x844Eu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x844Eu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x844Eu, 5u, 3u, cpu.address("abs", 0x846Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80844E PEA
    cpu.push16Value(hw, 0x846Bu);
    goto L_808451;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x844Eu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x844Eu, 5u, 3u, cpu.address("abs", 0x846Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80844E PEA
    cpu.push16Value(hw, 0x846Bu);
    goto L_808451;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x844Eu,0x80844Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_808451:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8451u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8451u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8451u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808451 REP
    cpu.rep(0x20u);
    goto L_808453;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8451u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8451u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808451 REP
    cpu.rep(0x20u);
    goto L_808453;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8451u,0x808451u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_808453:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8453u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8453u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8453u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808453 AND
    cpu.logicAnd(0xFFu);
    goto L_808456;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8453u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8453u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808453 AND
    cpu.logicAnd(0xFFu);
    goto L_808456;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8453u,0x808453u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_808456:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8456u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8456u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8456u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808456 PHA
    cpu.push("PHA", hw);
    goto L_808457;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8456u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8456u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808456 PHA
    cpu.push("PHA", hw);
    goto L_808457;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8456u,0x808456u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_808457:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8457u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8457u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8457u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808457 ASL
    cpu.aslA();
    goto L_808458;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8457u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8457u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808457 ASL
    cpu.aslA();
    goto L_808458;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8457u,0x808457u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_808458:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8458u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8458u,cpu,0x63u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8458u, 5u, 2u, cpu.addressStack(0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808458 ADC
    cpu.adc(hw.readW(cpu.addressStack(0x1u), cpu.m8?8:16));
    goto L_80845A;
L_80845A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x845Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x845Au,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x845Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80845A TAX
    cpu.transfer("TAX");
    goto L_80845B;
L_80845B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x845Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x845Bu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x845Bu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80845B PLA
    cpu.pop("PLA", hw);
    goto L_80845C;
L_80845C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x845Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x845Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x845Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80845C SEP
    cpu.sep(0x20u);
    goto L_80845E;
L_80845E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x845Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x845Eu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x845Eu, 5u, 4u, ((0x808470u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80845E LDA
    cpu.loadA(hw.readW(((0x808470u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808462;
L_808462:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8462u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8462u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8462u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808462 PHA
    cpu.push("PHA", hw);
    goto L_808463;
L_808463:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8463u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8463u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8463u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808463 REP
    cpu.rep(0x20u);
    goto L_808465;
L_808465:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8465u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8465u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8465u, 6u, 4u, ((0x80846Eu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808465 LDA
    cpu.loadA(hw.readW(((0x80846Eu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808469;
L_808469:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8469u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8469u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8469u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808469 DEC
    cpu.decReg('A');
    goto L_80846A;
L_80846A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x846Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Au,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80846A PHA
    cpu.push("PHA", hw);
    goto L_80846B;
L_80846B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x846Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Bu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80846B RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80846Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80846Bu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808444_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808444u: goto L_808444;
    case 0x808445u: goto L_808445;
    case 0x808449u: goto L_808449;
    case 0x80844Bu: goto L_80844B;
    case 0x80844Du: goto L_80844D;
    case 0x80844Eu: goto L_80844E;
    case 0x808451u: goto L_808451;
    case 0x808453u: goto L_808453;
    case 0x808456u: goto L_808456;
    case 0x808457u: goto L_808457;
    case 0x808458u: goto L_808458;
    case 0x80845Au: goto L_80845A;
    case 0x80845Bu: goto L_80845B;
    case 0x80845Cu: goto L_80845C;
    case 0x80845Eu: goto L_80845E;
    case 0x808462u: goto L_808462;
    case 0x808463u: goto L_808463;
    case 0x808465u: goto L_808465;
    case 0x808469u: goto L_808469;
    case 0x80846Au: goto L_80846A;
    case 0x80846Bu: goto L_80846B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808444:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8444u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8444u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8444u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808444 PHP
    cpu.push("PHP", hw);
    goto L_808445;
L_808445:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8445u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8445u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8445u, 8u, 4u, 0x80870Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808445 JSL -> $80870C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8448u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8449u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80870Cu, 0x808445u); }
    goto L_808449;
L_808449:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8449u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8449u,0x808449u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8449u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8449u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x48u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808449 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x48u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80844B;
L_80844B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x844Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x844Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x844Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80844B AND
    cpu.logicAnd(0x7Fu);
    goto L_80844D;
L_80844D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x844Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x844Du,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x844Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80844D PHK
    cpu.push("PHK", hw);
    goto L_80844E;
L_80844E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x844Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x844Eu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x844Eu, 5u, 3u, cpu.address("abs", 0x846Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80844E PEA
    cpu.push16Value(hw, 0x846Bu);
    goto L_808451;
L_808451:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8451u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8451u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8451u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808451 REP
    cpu.rep(0x20u);
    goto L_808453;
L_808453:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8453u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8453u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8453u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808453 AND
    cpu.logicAnd(0xFFu);
    goto L_808456;
L_808456:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8456u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8456u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8456u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808456 PHA
    cpu.push("PHA", hw);
    goto L_808457;
L_808457:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8457u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8457u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8457u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808457 ASL
    cpu.aslA();
    goto L_808458;
L_808458:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8458u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8458u,cpu,0x63u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8458u, 5u, 2u, cpu.addressStack(0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808458 ADC
    cpu.adc(hw.readW(cpu.addressStack(0x1u), cpu.m8?8:16));
    goto L_80845A;
L_80845A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x845Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x845Au,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x845Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80845A TAX
    cpu.transfer("TAX");
    goto L_80845B;
L_80845B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x845Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x845Bu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x845Bu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80845B PLA
    cpu.pop("PLA", hw);
    goto L_80845C;
L_80845C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x845Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x845Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x845Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80845C SEP
    cpu.sep(0x20u);
    goto L_80845E;
L_80845E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x845Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x845Eu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x845Eu, 5u, 4u, ((0x808470u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80845E LDA
    cpu.loadA(hw.readW(((0x808470u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808462;
L_808462:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8462u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8462u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8462u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808462 PHA
    cpu.push("PHA", hw);
    goto L_808463;
L_808463:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8463u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8463u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8463u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808463 REP
    cpu.rep(0x20u);
    goto L_808465;
L_808465:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8465u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8465u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8465u, 6u, 4u, ((0x80846Eu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808465 LDA
    cpu.loadA(hw.readW(((0x80846Eu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808469;
L_808469:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8469u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8469u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8469u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808469 DEC
    cpu.decReg('A');
    goto L_80846A;
L_80846A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x846Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Au,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80846A PHA
    cpu.push("PHA", hw);
    goto L_80846B;
L_80846B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x846Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Bu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80846B RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80846Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80846Bu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_809D16_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809D16u: goto L_809D16;
    case 0x809D19u: goto L_809D19;
    case 0x809D1Bu: goto L_809D1B;
    case 0x809D1Du: goto L_809D1D;
    case 0x809D20u: goto L_809D20;
    case 0x809D21u: goto L_809D21;
    case 0x809D23u: goto L_809D23;
    case 0x809D25u: goto L_809D25;
    case 0x809D26u: goto L_809D26;
    case 0x809D27u: goto L_809D27;
    case 0x809D29u: goto L_809D29;
    case 0x809D2Cu: goto L_809D2C;
    case 0x809D2Eu: goto L_809D2E;
    case 0x809D31u: goto L_809D31;
    case 0x809D34u: goto L_809D34;
    case 0x809D37u: goto L_809D37;
    case 0x809D3Au: goto L_809D3A;
    case 0x809D3Cu: goto L_809D3C;
    case 0x809D3Fu: goto L_809D3F;
    case 0x809D41u: goto L_809D41;
    case 0x809D44u: goto L_809D44;
    case 0x809D47u: goto L_809D47;
    case 0x809D4Au: goto L_809D4A;
    case 0x809D4Du: goto L_809D4D;
    case 0x809D50u: goto L_809D50;
    case 0x809D52u: goto L_809D52;
    case 0x809D54u: goto L_809D54;
    case 0x809D57u: goto L_809D57;
    case 0x809D59u: goto L_809D59;
    case 0x809D5Cu: goto L_809D5C;
    case 0x809D5Fu: goto L_809D5F;
    case 0x809D62u: goto L_809D62;
    case 0x809D65u: goto L_809D65;
    case 0x809D67u: goto L_809D67;
    case 0x809D6Au: goto L_809D6A;
    case 0x809D6Du: goto L_809D6D;
    case 0x809D70u: goto L_809D70;
    case 0x809D73u: goto L_809D73;
    case 0x809D74u: goto L_809D74;
    case 0x809D77u: goto L_809D77;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809D16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D16u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D16u, 5u, 3u, cpu.address("abs", 0x014Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D16 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x14Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809D19;
L_809D19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D19u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D19u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D19 BEQ -> $809D20
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_809D20; }
    goto L_809D1B;
L_809D1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Bu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D1B BMI -> $809D20
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_809D20; }
    goto L_809D1D;
L_809D1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Du,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Du, 3u, 3u, cpu.address("abs", 0x9D74u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D1D JMP -> $809D74
    goto L_809D74;
L_809D20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D20u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D20u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809D20 PHB
    cpu.push("PHB", hw);
    goto L_809D21;
L_809D21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D21u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D21u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D21 SEP
    cpu.sep(0x20u);
    goto L_809D23;
L_809D23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D23u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D23u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D23 LDA
    cpu.setA(0x7Eu, 8);
    goto L_809D25;
L_809D25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D25u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D25u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809D25 PHA
    cpu.push("PHA", hw);
    goto L_809D26;
L_809D26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D26u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D26u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809D26 PLB
    cpu.pop("PLB", hw);
    goto L_809D27;
L_809D27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D27u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D27u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D27 REP
    cpu.rep(0x20u);
    goto L_809D29;
L_809D29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D29u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D29u, 5u, 3u, cpu.address("abs", 0x0139u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D29 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x139u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809D2C;
L_809D2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D2C BEQ -> $809D34
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_809D34; }
    goto L_809D2E;
L_809D2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Eu, 6u, 3u, cpu.address("abs", 0x9E11u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809D2E JSR -> $809E11 stack real
    { cpu.push16Value(hw,0x9D30u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9D31u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9E11u), 0x809D2Eu); }
    goto L_809D31;
L_809D31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D31u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D31u,0x809D31u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D31u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D31u, 3u, 3u, cpu.address("abs", 0x9D73u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D31 JMP -> $809D73
    goto L_809D73;
L_809D34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D34u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D34u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D34 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809D37;
L_809D37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D37u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D37u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D37 CMP
    cpu.compareA(0x2u);
    goto L_809D3A;
L_809D3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D3Au,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D3Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D3A BCS -> $809D52
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_809D52; }
    goto L_809D3C;
L_809D3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D3Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D3Cu, 5u, 3u, cpu.address("abs", 0x01B1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D3C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1B1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809D3F;
L_809D3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D3Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D3Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D3F BEQ -> $809D44
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_809D44; }
    goto L_809D41;
L_809D41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D41u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D41u, 6u, 3u, cpu.address("abs", 0x9E59u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809D41 JSR -> $809E59 stack real
    { cpu.push16Value(hw,0x9D43u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9D44u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9E59u), 0x809D41u); }
    goto L_809D44;
L_809D44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D44u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D44u,0x809D44u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D44u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D44u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D44 LDY
    cpu.setY(0x1F8u, 16);
    goto L_809D47;
L_809D47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D47u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D47u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D47 LDX
    cpu.setX(0x668u, 16);
    goto L_809D4A;
L_809D4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D4A LDA
    cpu.setA(0x13u, 16);
    goto L_809D4D;
L_809D4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Du, 6u, 3u, cpu.address("abs", 0x9D78u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809D4D JSR -> $809D78 stack real
    { cpu.push16Value(hw,0x9D4Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9D50u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9D78u), 0x809D4Du); }
    goto L_809D50;
L_809D50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D50u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D50u,0x809D50u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D50u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D50u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D50 BRA -> $809D73
    goto L_809D73;
L_809D52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D52u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D52u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D52 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809D54;
L_809D54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D54u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D54u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D54 BIT
    cpu.bit(0x1u, true);
    goto L_809D57;
L_809D57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D57u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D57u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D57 BNE -> $809D67
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_809D67; }
    goto L_809D59;
L_809D59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D59u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D59u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D59 LDY
    cpu.setY(0x1F8u, 16);
    goto L_809D5C;
L_809D5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D5Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D5Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D5C LDX
    cpu.setX(0x656u, 16);
    goto L_809D5F;
L_809D5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D5Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D5Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D5F LDA
    cpu.setA(0x15u, 16);
    goto L_809D62;
L_809D62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D62u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D62u, 6u, 3u, cpu.address("abs", 0x9D78u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809D62 JSR -> $809D78 stack real
    { cpu.push16Value(hw,0x9D64u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9D65u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9D78u), 0x809D62u); }
    goto L_809D65;
L_809D65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D65u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D65u,0x809D65u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D65u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D65u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D65 BRA -> $809D73
    goto L_809D73;
L_809D67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D67u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D67u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D67 LDY
    cpu.setY(0x418u, 16);
    goto L_809D6A;
L_809D6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D6Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D6Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D6A LDX
    cpu.setX(0x67Au, 16);
    goto L_809D6D;
L_809D6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D6Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D6Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D6D LDA
    cpu.setA(0x15u, 16);
    goto L_809D70;
L_809D70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D70u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D70u, 6u, 3u, cpu.address("abs", 0x9D78u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809D70 JSR -> $809D78 stack real
    { cpu.push16Value(hw,0x9D72u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9D73u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9D78u), 0x809D70u); }
    goto L_809D73;
L_809D73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D73u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D73u,0x809D73u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D73u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D73u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809D73 PLB
    cpu.pop("PLB", hw);
    goto L_809D74;
L_809D74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D74u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D74u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D74u, 5u, 3u, cpu.address("abs", 0x014Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D74 STZ
    hw.write(cpu.address("abs", 0x14Au), 0, cpu.m8?8:16);
    goto L_809D77;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D74u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D74u, 5u, 3u, cpu.address("abs", 0x014Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D74 STZ
    hw.write(cpu.address("abs", 0x14Au), 0, cpu.m8?8:16);
    goto L_809D77;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D74u,0x809D74u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809D77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D77u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D77u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D77u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809D77 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x809D77u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x809D77u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D77u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D77u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809D77 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x809D77u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x809D77u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D77u,0x809D77u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_809D16_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809D16u: goto L_809D16;
    case 0x809D19u: goto L_809D19;
    case 0x809D1Bu: goto L_809D1B;
    case 0x809D1Du: goto L_809D1D;
    case 0x809D20u: goto L_809D20;
    case 0x809D21u: goto L_809D21;
    case 0x809D23u: goto L_809D23;
    case 0x809D25u: goto L_809D25;
    case 0x809D26u: goto L_809D26;
    case 0x809D27u: goto L_809D27;
    case 0x809D29u: goto L_809D29;
    case 0x809D2Cu: goto L_809D2C;
    case 0x809D2Eu: goto L_809D2E;
    case 0x809D31u: goto L_809D31;
    case 0x809D34u: goto L_809D34;
    case 0x809D37u: goto L_809D37;
    case 0x809D3Au: goto L_809D3A;
    case 0x809D3Cu: goto L_809D3C;
    case 0x809D3Fu: goto L_809D3F;
    case 0x809D41u: goto L_809D41;
    case 0x809D44u: goto L_809D44;
    case 0x809D47u: goto L_809D47;
    case 0x809D4Au: goto L_809D4A;
    case 0x809D4Du: goto L_809D4D;
    case 0x809D50u: goto L_809D50;
    case 0x809D52u: goto L_809D52;
    case 0x809D54u: goto L_809D54;
    case 0x809D57u: goto L_809D57;
    case 0x809D59u: goto L_809D59;
    case 0x809D5Cu: goto L_809D5C;
    case 0x809D5Fu: goto L_809D5F;
    case 0x809D62u: goto L_809D62;
    case 0x809D65u: goto L_809D65;
    case 0x809D67u: goto L_809D67;
    case 0x809D6Au: goto L_809D6A;
    case 0x809D6Du: goto L_809D6D;
    case 0x809D70u: goto L_809D70;
    case 0x809D73u: goto L_809D73;
    case 0x809D74u: goto L_809D74;
    case 0x809D77u: goto L_809D77;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809D16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D16u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D16u, 5u, 3u, cpu.address("abs", 0x014Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D16 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x14Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809D19;
L_809D19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D19u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D19u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D19 BEQ -> $809D20
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_809D20; }
    goto L_809D1B;
L_809D1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Bu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D1B BMI -> $809D20
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_809D20; }
    goto L_809D1D;
L_809D1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Du,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Du, 3u, 3u, cpu.address("abs", 0x9D74u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D1D JMP -> $809D74
    goto L_809D74;
L_809D20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D20u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D20u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809D20 PHB
    cpu.push("PHB", hw);
    goto L_809D21;
L_809D21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D21u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D21u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D21 SEP
    cpu.sep(0x20u);
    goto L_809D23;
L_809D23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D23u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D23u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D23 LDA
    cpu.setA(0x7Eu, 8);
    goto L_809D25;
L_809D25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D25u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D25u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809D25 PHA
    cpu.push("PHA", hw);
    goto L_809D26;
L_809D26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D26u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D26u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809D26 PLB
    cpu.pop("PLB", hw);
    goto L_809D27;
L_809D27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D27u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D27u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D27 REP
    cpu.rep(0x20u);
    goto L_809D29;
L_809D29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D29u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D29u, 5u, 3u, cpu.address("abs", 0x0139u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D29 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x139u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809D2C;
L_809D2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D2C BEQ -> $809D34
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_809D34; }
    goto L_809D2E;
L_809D2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Eu, 6u, 3u, cpu.address("abs", 0x9E11u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809D2E JSR -> $809E11 stack real
    { cpu.push16Value(hw,0x9D30u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9D31u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9E11u), 0x809D2Eu); }
    goto L_809D31;
L_809D31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D31u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D31u,0x809D31u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D31u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D31u, 3u, 3u, cpu.address("abs", 0x9D73u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D31 JMP -> $809D73
    goto L_809D73;
L_809D34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D34u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D34u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D34 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809D37;
L_809D37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D37u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D37u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D37 CMP
    cpu.compareA(0x2u);
    goto L_809D3A;
L_809D3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D3Au,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D3Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D3A BCS -> $809D52
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_809D52; }
    goto L_809D3C;
L_809D3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D3Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D3Cu, 5u, 3u, cpu.address("abs", 0x01B1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D3C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1B1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809D3F;
L_809D3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D3Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D3Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D3F BEQ -> $809D44
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_809D44; }
    goto L_809D41;
L_809D41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D41u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D41u, 6u, 3u, cpu.address("abs", 0x9E59u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809D41 JSR -> $809E59 stack real
    { cpu.push16Value(hw,0x9D43u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9D44u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9E59u), 0x809D41u); }
    goto L_809D44;
L_809D44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D44u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D44u,0x809D44u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D44u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D44u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D44 LDY
    cpu.setY(0x1F8u, 16);
    goto L_809D47;
L_809D47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D47u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D47u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D47 LDX
    cpu.setX(0x668u, 16);
    goto L_809D4A;
L_809D4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D4A LDA
    cpu.setA(0x13u, 16);
    goto L_809D4D;
L_809D4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Du, 6u, 3u, cpu.address("abs", 0x9D78u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809D4D JSR -> $809D78 stack real
    { cpu.push16Value(hw,0x9D4Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9D50u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9D78u), 0x809D4Du); }
    goto L_809D50;
L_809D50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D50u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D50u,0x809D50u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D50u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D50u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D50 BRA -> $809D73
    goto L_809D73;
L_809D52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D52u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D52u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D52 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809D54;
L_809D54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D54u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D54u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D54 BIT
    cpu.bit(0x1u, true);
    goto L_809D57;
L_809D57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D57u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D57u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D57 BNE -> $809D67
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_809D67; }
    goto L_809D59;
L_809D59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D59u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D59u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D59 LDY
    cpu.setY(0x1F8u, 16);
    goto L_809D5C;
L_809D5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D5Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D5Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D5C LDX
    cpu.setX(0x656u, 16);
    goto L_809D5F;
L_809D5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D5Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D5Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D5F LDA
    cpu.setA(0x15u, 16);
    goto L_809D62;
L_809D62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D62u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D62u, 6u, 3u, cpu.address("abs", 0x9D78u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809D62 JSR -> $809D78 stack real
    { cpu.push16Value(hw,0x9D64u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9D65u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9D78u), 0x809D62u); }
    goto L_809D65;
L_809D65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D65u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D65u,0x809D65u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D65u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D65u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D65 BRA -> $809D73
    goto L_809D73;
L_809D67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D67u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D67u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D67 LDY
    cpu.setY(0x418u, 16);
    goto L_809D6A;
L_809D6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D6Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D6Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D6A LDX
    cpu.setX(0x67Au, 16);
    goto L_809D6D;
L_809D6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D6Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D6Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D6D LDA
    cpu.setA(0x15u, 16);
    goto L_809D70;
L_809D70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D70u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D70u, 6u, 3u, cpu.address("abs", 0x9D78u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809D70 JSR -> $809D78 stack real
    { cpu.push16Value(hw,0x9D72u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9D73u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9D78u), 0x809D70u); }
    goto L_809D73;
L_809D73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D73u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D73u,0x809D73u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D73u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D73u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809D73 PLB
    cpu.pop("PLB", hw);
    goto L_809D74;
L_809D74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D74u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D74u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D74u, 5u, 3u, cpu.address("abs", 0x014Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D74 STZ
    hw.write(cpu.address("abs", 0x14Au), 0, cpu.m8?8:16);
    goto L_809D77;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D74u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D74u, 5u, 3u, cpu.address("abs", 0x014Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D74 STZ
    hw.write(cpu.address("abs", 0x14Au), 0, cpu.m8?8:16);
    goto L_809D77;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D74u,0x809D74u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809D77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D77u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D77u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D77u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809D77 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x809D77u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x809D77u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D77u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D77u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809D77 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x809D77u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x809D77u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D77u,0x809D77u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_809D16_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809D16u: goto L_809D16;
    case 0x809D19u: goto L_809D19;
    case 0x809D1Bu: goto L_809D1B;
    case 0x809D1Du: goto L_809D1D;
    case 0x809D20u: goto L_809D20;
    case 0x809D21u: goto L_809D21;
    case 0x809D23u: goto L_809D23;
    case 0x809D25u: goto L_809D25;
    case 0x809D26u: goto L_809D26;
    case 0x809D27u: goto L_809D27;
    case 0x809D29u: goto L_809D29;
    case 0x809D2Cu: goto L_809D2C;
    case 0x809D2Eu: goto L_809D2E;
    case 0x809D31u: goto L_809D31;
    case 0x809D34u: goto L_809D34;
    case 0x809D37u: goto L_809D37;
    case 0x809D3Au: goto L_809D3A;
    case 0x809D3Cu: goto L_809D3C;
    case 0x809D3Fu: goto L_809D3F;
    case 0x809D41u: goto L_809D41;
    case 0x809D44u: goto L_809D44;
    case 0x809D47u: goto L_809D47;
    case 0x809D4Au: goto L_809D4A;
    case 0x809D4Du: goto L_809D4D;
    case 0x809D50u: goto L_809D50;
    case 0x809D52u: goto L_809D52;
    case 0x809D54u: goto L_809D54;
    case 0x809D57u: goto L_809D57;
    case 0x809D59u: goto L_809D59;
    case 0x809D5Cu: goto L_809D5C;
    case 0x809D5Fu: goto L_809D5F;
    case 0x809D62u: goto L_809D62;
    case 0x809D65u: goto L_809D65;
    case 0x809D67u: goto L_809D67;
    case 0x809D6Au: goto L_809D6A;
    case 0x809D6Du: goto L_809D6D;
    case 0x809D70u: goto L_809D70;
    case 0x809D73u: goto L_809D73;
    case 0x809D74u: goto L_809D74;
    case 0x809D77u: goto L_809D77;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809D16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D16u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D16u, 5u, 3u, cpu.address("abs", 0x014Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D16 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x14Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809D19;
L_809D19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D19u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D19u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D19 BEQ -> $809D20
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_809D20; }
    goto L_809D1B;
L_809D1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Bu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D1B BMI -> $809D20
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_809D20; }
    goto L_809D1D;
L_809D1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Du,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Du, 3u, 3u, cpu.address("abs", 0x9D74u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D1D JMP -> $809D74
    goto L_809D74;
L_809D20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D20u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D20u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809D20 PHB
    cpu.push("PHB", hw);
    goto L_809D21;
L_809D21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D21u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D21u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D21 SEP
    cpu.sep(0x20u);
    goto L_809D23;
L_809D23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D23u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D23u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D23 LDA
    cpu.setA(0x7Eu, 8);
    goto L_809D25;
L_809D25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D25u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D25u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809D25 PHA
    cpu.push("PHA", hw);
    goto L_809D26;
L_809D26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D26u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D26u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809D26 PLB
    cpu.pop("PLB", hw);
    goto L_809D27;
L_809D27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D27u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D27u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D27 REP
    cpu.rep(0x20u);
    goto L_809D29;
L_809D29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D29u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D29u, 5u, 3u, cpu.address("abs", 0x0139u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D29 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x139u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809D2C;
L_809D2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D2C BEQ -> $809D34
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_809D34; }
    goto L_809D2E;
L_809D2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Eu, 6u, 3u, cpu.address("abs", 0x9E11u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809D2E JSR -> $809E11 stack real
    { cpu.push16Value(hw,0x9D30u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9D31u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9E11u), 0x809D2Eu); }
    goto L_809D31;
L_809D31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D31u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D31u,0x809D31u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D31u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D31u, 3u, 3u, cpu.address("abs", 0x9D73u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D31 JMP -> $809D73
    goto L_809D73;
L_809D34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D34u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D34u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D34 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809D37;
L_809D37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D37u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D37u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D37 CMP
    cpu.compareA(0x2u);
    goto L_809D3A;
L_809D3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D3Au,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D3Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D3A BCS -> $809D52
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_809D52; }
    goto L_809D3C;
L_809D3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D3Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D3Cu, 5u, 3u, cpu.address("abs", 0x01B1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D3C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1B1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809D3F;
L_809D3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D3Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D3Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D3F BEQ -> $809D44
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_809D44; }
    goto L_809D41;
L_809D41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D41u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D41u, 6u, 3u, cpu.address("abs", 0x9E59u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809D41 JSR -> $809E59 stack real
    { cpu.push16Value(hw,0x9D43u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9D44u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9E59u), 0x809D41u); }
    goto L_809D44;
L_809D44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D44u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D44u,0x809D44u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D44u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D44u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D44 LDY
    cpu.setY(0x1F8u, 16);
    goto L_809D47;
L_809D47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D47u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D47u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D47 LDX
    cpu.setX(0x668u, 16);
    goto L_809D4A;
L_809D4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D4A LDA
    cpu.setA(0x13u, 16);
    goto L_809D4D;
L_809D4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Du, 6u, 3u, cpu.address("abs", 0x9D78u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809D4D JSR -> $809D78 stack real
    { cpu.push16Value(hw,0x9D4Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9D50u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9D78u), 0x809D4Du); }
    goto L_809D50;
L_809D50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D50u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D50u,0x809D50u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D50u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D50u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D50 BRA -> $809D73
    goto L_809D73;
L_809D52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D52u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D52u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D52 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809D54;
L_809D54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D54u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D54u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D54 BIT
    cpu.bit(0x1u, true);
    goto L_809D57;
L_809D57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D57u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D57u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D57 BNE -> $809D67
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_809D67; }
    goto L_809D59;
L_809D59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D59u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D59u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D59 LDY
    cpu.setY(0x1F8u, 16);
    goto L_809D5C;
L_809D5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D5Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D5Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D5C LDX
    cpu.setX(0x656u, 16);
    goto L_809D5F;
L_809D5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D5Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D5Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D5F LDA
    cpu.setA(0x15u, 16);
    goto L_809D62;
L_809D62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D62u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D62u, 6u, 3u, cpu.address("abs", 0x9D78u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809D62 JSR -> $809D78 stack real
    { cpu.push16Value(hw,0x9D64u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9D65u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9D78u), 0x809D62u); }
    goto L_809D65;
L_809D65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D65u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D65u,0x809D65u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D65u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D65u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D65 BRA -> $809D73
    goto L_809D73;
L_809D67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D67u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D67u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D67 LDY
    cpu.setY(0x418u, 16);
    goto L_809D6A;
L_809D6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D6Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D6Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D6A LDX
    cpu.setX(0x67Au, 16);
    goto L_809D6D;
L_809D6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D6Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D6Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D6D LDA
    cpu.setA(0x15u, 16);
    goto L_809D70;
L_809D70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D70u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D70u, 6u, 3u, cpu.address("abs", 0x9D78u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809D70 JSR -> $809D78 stack real
    { cpu.push16Value(hw,0x9D72u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9D73u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9D78u), 0x809D70u); }
    goto L_809D73;
L_809D73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D73u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D73u,0x809D73u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D73u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D73u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809D73 PLB
    cpu.pop("PLB", hw);
    goto L_809D74;
L_809D74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D74u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D74u, 5u, 3u, cpu.address("abs", 0x014Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D74 STZ
    hw.write(cpu.address("abs", 0x14Au), 0, cpu.m8?8:16);
    goto L_809D77;
L_809D77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D77u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D77u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809D77 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x809D77u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x809D77u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80A5E0_E0M1X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80A5E0u: goto L_80A5E0;
    case 0x80A5E3u: goto L_80A5E3;
    case 0x80A5E5u: goto L_80A5E5;
    case 0x80A5E8u: goto L_80A5E8;
    case 0x80A5EAu: goto L_80A5EA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80A5E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E0u,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E0u, 4u, 3u, cpu.address("abs", 0x4212u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5E0 BIT
    cpu.bit(hw.readW(cpu.address("abs", 0x4212u), cpu.m8?8:16), false);
    goto L_80A5E3;
L_80A5E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E3u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5E3 BMI -> $80A5E0
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80A5E0; }
    goto L_80A5E5;
L_80A5E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E5u,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E5u, 4u, 3u, cpu.address("abs", 0x4212u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5E5 BIT
    cpu.bit(hw.readW(cpu.address("abs", 0x4212u), cpu.m8?8:16), false);
    goto L_80A5E8;
L_80A5E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E8u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5E8 BPL -> $80A5E5
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80A5E5; }
    goto L_80A5EA;
L_80A5EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5EAu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5EAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A5EA RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80A5EAu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80A5EAu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80A5E0_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80A5E0u: goto L_80A5E0;
    case 0x80A5E3u: goto L_80A5E3;
    case 0x80A5E5u: goto L_80A5E5;
    case 0x80A5E8u: goto L_80A5E8;
    case 0x80A5EAu: goto L_80A5EA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80A5E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E0u,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E0u, 4u, 3u, cpu.address("abs", 0x4212u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5E0 BIT
    cpu.bit(hw.readW(cpu.address("abs", 0x4212u), cpu.m8?8:16), false);
    goto L_80A5E3;
L_80A5E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E3u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5E3 BMI -> $80A5E0
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80A5E0; }
    goto L_80A5E5;
L_80A5E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E5u,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E5u, 4u, 3u, cpu.address("abs", 0x4212u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5E5 BIT
    cpu.bit(hw.readW(cpu.address("abs", 0x4212u), cpu.m8?8:16), false);
    goto L_80A5E8;
L_80A5E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E8u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5E8 BPL -> $80A5E5
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80A5E5; }
    goto L_80A5EA;
L_80A5EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5EAu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5EAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A5EA RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80A5EAu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80A5EAu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80A9F5_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80A9F5u: goto L_80A9F5;
    case 0x80A9F7u: goto L_80A9F7;
    case 0x80A9F9u: goto L_80A9F9;
    case 0x80A9FBu: goto L_80A9FB;
    case 0x80A9FCu: goto L_80A9FC;
    case 0x80A9FFu: goto L_80A9FF;
    case 0x80AA02u: goto L_80AA02;
    case 0x80AA03u: goto L_80AA03;
    case 0x80AA04u: goto L_80AA04;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80A9F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F5u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9F5 REP
    cpu.rep(0x20u);
    goto L_80A9F7;
L_80A9F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F7u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F7u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9F7 DEC
    cpu.decMem(hw, cpu.address("dp", 0x10u), cpu.m8?8:16);
    goto L_80A9F9;
L_80A9F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F9u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9F9 BPL -> $80A9FC
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80A9FC; }
    goto L_80A9FB;
L_80A9FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FBu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A9FB RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80A9FBu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80A9FBu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80A9FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FCu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FCu, 5u + 1u, 3u, cpu.address("absy", 0x1B00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9FC LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1B00u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A9FF;
L_80A9FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FFu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FFu, 6u, 3u, cpu.address("absy", 0x1900u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9FF STA
    hw.write(cpu.address("absy", 0x1900u), cpu.a, cpu.m8?8:16);
    goto L_80AA02;
L_80AA02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA02u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA02u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA02 INY
    cpu.inc('Y');
    goto L_80AA03;
L_80AA03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA03u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA03u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA03 INY
    cpu.inc('Y');
    goto L_80AA04;
L_80AA04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA04u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA04u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA04 BRA -> $80A9F7
    goto L_80A9F7;
}

void sub_80AEDE_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AEDEu: goto L_80AEDE;
    case 0x80AEE1u: goto L_80AEE1;
    case 0x80AEE3u: goto L_80AEE3;
    case 0x80AEE6u: goto L_80AEE6;
    case 0x80AEE9u: goto L_80AEE9;
    case 0x80AEEBu: goto L_80AEEB;
    case 0x80AEEEu: goto L_80AEEE;
    case 0x80AEF1u: goto L_80AEF1;
    case 0x80AEF4u: goto L_80AEF4;
    case 0x80AEF7u: goto L_80AEF7;
    case 0x80AEFAu: goto L_80AEFA;
    case 0x80AEFDu: goto L_80AEFD;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AEDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEDEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEDEu, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEDE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AEE1;
L_80AEE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEE1 BEQ -> $80AEF7
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AEF7; }
    goto L_80AEE3;
L_80AEE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE3u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEE3 LDX
    cpu.setX(0x41Au, 16);
    goto L_80AEE6;
L_80AEE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEE6 LDA
    cpu.setA(0x3u, 16);
    goto L_80AEE9;
L_80AEE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEE9 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80AEEB;
L_80AEEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEEBu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEEBu, 5u, 3u, cpu.address("abs", 0x0914u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEEB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x914u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AEEE;
L_80AEEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEEEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEEEu, 5u, 3u, cpu.address("abs", 0x097Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEEE STA
    hw.write(cpu.address("abs", 0x97Au), cpu.a, cpu.m8?8:16);
    goto L_80AEF1;
L_80AEF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF1u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF1u, 8u, 3u, cpu.address("abs", 0x0986u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEF1 INC
    cpu.incMem(hw, cpu.address("abs", 0x986u), cpu.m8?8:16);
    goto L_80AEF4;
L_80AEF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF4u, 6u, 3u, cpu.address("abs", 0xC85Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AEF4 JSR -> $80C85C stack real
    { cpu.push16Value(hw,0xAEF6u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAEF7u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC85Cu), 0x80AEF4u); }
    goto L_80AEF7;
L_80AEF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEF7u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF7u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF7u, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEF7 STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80AEFA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF7u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF7u, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEF7 STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80AEFA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF7u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF7u, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEF7 STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80AEFA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAEF7u,0x80AEF7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AEFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEFAu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFAu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFAu, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEFA INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AEFD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFAu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFAu, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEFA INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AEFD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFAu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFAu, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEFA INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AEFD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAEFAu,0x80AEFAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AEFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEFDu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFDu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AEFD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AEFDu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AEFDu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFDu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AEFD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AEFDu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AEFDu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFDu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AEFD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AEFDu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AEFDu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAEFDu,0x80AEFDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80B2D3_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B2D3u: goto L_80B2D3;
    case 0x80B2D6u: goto L_80B2D6;
    case 0x80B2D8u: goto L_80B2D8;
    case 0x80B2DBu: goto L_80B2DB;
    case 0x80B2DDu: goto L_80B2DD;
    case 0x80B2E0u: goto L_80B2E0;
    case 0x80B2E3u: goto L_80B2E3;
    case 0x80B2E5u: goto L_80B2E5;
    case 0x80B2E8u: goto L_80B2E8;
    case 0x80B2EBu: goto L_80B2EB;
    case 0x80B2EEu: goto L_80B2EE;
    case 0x80B2F1u: goto L_80B2F1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B2D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D3u, 5u, 3u, cpu.address("abs", 0x0137u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2D3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x137u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B2D6;
L_80B2D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2D6 BEQ -> $80B2EB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B2EB; }
    goto L_80B2D8;
L_80B2D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D8u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2D8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B2DB;
L_80B2DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2DB BEQ -> $80B2EB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B2EB; }
    goto L_80B2DD;
L_80B2DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DDu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DDu, 8u, 3u, cpu.address("abs", 0x0986u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2DD INC
    cpu.incMem(hw, cpu.address("abs", 0x986u), cpu.m8?8:16);
    goto L_80B2E0;
L_80B2E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E0u, 5u, 3u, cpu.address("abs", 0x0916u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2E0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x916u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B2E3;
L_80B2E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2E3 BEQ -> $80B2EB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B2EB; }
    goto L_80B2E5;
L_80B2E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E5u, 5u, 3u, cpu.address("abs", 0x097Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2E5 STA
    hw.write(cpu.address("abs", 0x97Au), cpu.a, cpu.m8?8:16);
    goto L_80B2E8;
L_80B2E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E8u, 6u, 3u, cpu.address("abs", 0xCE62u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B2E8 JSR -> $80CE62 stack real
    { cpu.push16Value(hw,0xB2EAu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB2EBu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCE62u), 0x80B2E8u); }
    goto L_80B2EB;
L_80B2EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2EBu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EBu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EBu, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2EB STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B2EE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EBu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EBu, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2EB STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B2EE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EBu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EBu, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2EB STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B2EE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2EBu,0x80B2EBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2EEu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EEu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EEu, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2EE INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B2F1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EEu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EEu, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2EE INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B2F1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EEu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EEu, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2EE INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B2F1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2EEu,0x80B2EEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F1u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B2F1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B2F1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B2F1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B2F1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B2F1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B2F1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B2F1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B2F1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B2F1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2F1u,0x80B2F1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80C8FE_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80C8FEu: goto L_80C8FE;
    case 0x80C901u: goto L_80C901;
    case 0x80C903u: goto L_80C903;
    case 0x80C905u: goto L_80C905;
    case 0x80C907u: goto L_80C907;
    case 0x80C909u: goto L_80C909;
    case 0x80C90Bu: goto L_80C90B;
    case 0x80C90Fu: goto L_80C90F;
    case 0x80C912u: goto L_80C912;
    case 0x80C914u: goto L_80C914;
    case 0x80C918u: goto L_80C918;
    case 0x80C91Au: goto L_80C91A;
    case 0x80C91Du: goto L_80C91D;
    case 0x80C91Fu: goto L_80C91F;
    case 0x80C922u: goto L_80C922;
    case 0x80C924u: goto L_80C924;
    case 0x80C925u: goto L_80C925;
    case 0x80C927u: goto L_80C927;
    case 0x80C92Bu: goto L_80C92B;
    case 0x80C92Du: goto L_80C92D;
    case 0x80C931u: goto L_80C931;
    case 0x80C934u: goto L_80C934;
    case 0x80C938u: goto L_80C938;
    case 0x80C93Au: goto L_80C93A;
    case 0x80C93Cu: goto L_80C93C;
    case 0x80C93Eu: goto L_80C93E;
    case 0x80C940u: goto L_80C940;
    case 0x80C942u: goto L_80C942;
    case 0x80C944u: goto L_80C944;
    case 0x80C946u: goto L_80C946;
    case 0x80C947u: goto L_80C947;
    case 0x80C948u: goto L_80C948;
    case 0x80C94Bu: goto L_80C94B;
    case 0x80C94Cu: goto L_80C94C;
    case 0x80C94Eu: goto L_80C94E;
    case 0x80C951u: goto L_80C951;
    case 0x80C953u: goto L_80C953;
    case 0x80C955u: goto L_80C955;
    case 0x80C958u: goto L_80C958;
    case 0x80C95Cu: goto L_80C95C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80C8FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8FEu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8FEu, 5u, 3u, cpu.address("abs", 0x096Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8FE LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x96Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C901;
L_80C901:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC901u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC901u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC901u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C901 STX
    hw.write(cpu.address("dp", 0x61u), cpu.x, cpu.x8?8:16);
    goto L_80C903;
L_80C903:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC903u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC903u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC903u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C903 STZ
    hw.write(cpu.address("dp", 0x63u), 0, cpu.m8?8:16);
    goto L_80C905;
L_80C905:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC905u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC905u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC905u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C905 INC
    cpu.incMem(hw, cpu.address("dp", 0x61u), cpu.m8?8:16);
    goto L_80C907;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC905u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC905u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C905 INC
    cpu.incMem(hw, cpu.address("dp", 0x61u), cpu.m8?8:16);
    goto L_80C907;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC905u,0x80C905u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C907:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC907u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC907u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC907u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C907 INC
    cpu.incMem(hw, cpu.address("dp", 0x61u), cpu.m8?8:16);
    goto L_80C909;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC907u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC907u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C907 INC
    cpu.incMem(hw, cpu.address("dp", 0x61u), cpu.m8?8:16);
    goto L_80C909;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC907u,0x80C907u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C909:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC909u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC909u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC909u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C909 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C90B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC909u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC909u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C909 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C90B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC909u,0x80C909u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C90B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC90Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC90Bu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC90Bu, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C90B LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C90F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC90Bu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC90Bu, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C90B LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C90F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC90Bu,0x80C90Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C90F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC90Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC90Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC90Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C90F CMP
    cpu.compareA(0xFFFFu);
    goto L_80C912;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC90Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC90Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C90F CMP
    cpu.compareA(0xFFFFu);
    goto L_80C912;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC90Fu,0x80C90Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C912:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC912u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC912u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC912u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C912 BEQ -> $80C953
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C953; }
    goto L_80C914;
L_80C914:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC914u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC914u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC914u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C914 LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C918;
L_80C918:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC918u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC918u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC918u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C918 BEQ -> $80C946
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C946; }
    goto L_80C91A;
L_80C91A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC91Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC91Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC91Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C91A CMP
    cpu.compareA(0xFFFFu);
    goto L_80C91D;
L_80C91D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC91Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC91Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC91Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C91D BEQ -> $80C94E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C94E; }
    goto L_80C91F;
L_80C91F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC91Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC91Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC91Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C91F AND
    cpu.logicAnd(0x300u);
    goto L_80C922;
L_80C922:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC922u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC922u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC922u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C922 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80C924;
L_80C924:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC924u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC924u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC924u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C924 TXA
    cpu.transfer("TXA");
    goto L_80C925;
L_80C925:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC925u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC925u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC925u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C925 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C927;
L_80C927:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC927u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC927u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC927u, 6u, 4u, ((0x7E2444u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C927 STA
    hw.write(((0x7E2444u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80C92B;
L_80C92B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC92Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC92Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC92Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C92B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C92D;
L_80C92D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC92Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC92Du,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC92Du, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C92D STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80C931;
L_80C931:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC931u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC931u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC931u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C931 LDA
    cpu.setA(0x4u, 16);
    goto L_80C934;
L_80C934:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC934u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC934u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC934u, 6u, 4u, ((0x7E2442u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C934 STA
    hw.write(((0x7E2442u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80C938;
L_80C938:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC938u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC938u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC938u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C938 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C93A;
L_80C93A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC93Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC93Au,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC93Au, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C93A INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C93C;
L_80C93C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC93Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC93Cu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC93Cu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C93C INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C93E;
L_80C93E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC93Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC93Eu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC93Eu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C93E INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C940;
L_80C940:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC940u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC940u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC940u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C940 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C942;
L_80C942:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC942u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC942u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC942u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C942 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C944;
L_80C944:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC944u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC944u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC944u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C944 BRA -> $80C905
    goto L_80C905;
L_80C946:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC946u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC946u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC946u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C946 TXA
    cpu.transfer("TXA");
    goto L_80C947;
L_80C947:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC947u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC947u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC947u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C947 CLC
    cpu.setFlag('C', false);
    goto L_80C948;
L_80C948:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC948u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC948u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC948u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C948 ADC
    cpu.adc(0x16u);
    goto L_80C94B;
L_80C94B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC94Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC94Bu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC94Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C94B TAX
    cpu.transfer("TAX");
    goto L_80C94C;
L_80C94C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC94Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC94Cu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC94Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C94C BRA -> $80C914
    goto L_80C914;
L_80C94E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC94Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC94Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC94Eu, 6u, 3u, cpu.address("abs", 0xC95Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C94E JSR -> $80C95D stack real
    { cpu.push16Value(hw,0xC950u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC951u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC95Du), 0x80C94Eu); }
    goto L_80C951;
L_80C951:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC951u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC951u,0x80C951u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC951u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC951u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C951 BRA -> $80C905
    goto L_80C905;
L_80C953:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC953u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC953u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC953u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C953 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C955;
L_80C955:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC955u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC955u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC955u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C955 LDA
    cpu.setA(0xFFFFu, 16);
    goto L_80C958;
L_80C958:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC958u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC958u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC958u, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C958 STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80C95C;
L_80C95C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC95Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC95Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC95Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C95C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80C95Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80C95Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8292FC_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8292FCu: goto L_8292FC;
    case 0x8292FFu: goto L_8292FF;
    case 0x829301u: goto L_829301;
    case 0x829303u: goto L_829303;
    case 0x829305u: goto L_829305;
    case 0x829308u: goto L_829308;
    case 0x82930Au: goto L_82930A;
    case 0x82930Cu: goto L_82930C;
    case 0x82930Eu: goto L_82930E;
    case 0x829310u: goto L_829310;
    case 0x829312u: goto L_829312;
    case 0x829313u: goto L_829313;
    case 0x829315u: goto L_829315;
    case 0x829319u: goto L_829319;
    case 0x82931Bu: goto L_82931B;
    case 0x82931Cu: goto L_82931C;
    case 0x82931Fu: goto L_82931F;
    case 0x829323u: goto L_829323;
    case 0x829326u: goto L_829326;
    case 0x829328u: goto L_829328;
    case 0x82932Au: goto L_82932A;
    case 0x82932Cu: goto L_82932C;
    case 0x82932Eu: goto L_82932E;
    case 0x829330u: goto L_829330;
    case 0x829333u: goto L_829333;
    case 0x829335u: goto L_829335;
    case 0x829338u: goto L_829338;
    case 0x82933Au: goto L_82933A;
    case 0x82933Du: goto L_82933D;
    case 0x829340u: goto L_829340;
    case 0x829343u: goto L_829343;
    case 0x829346u: goto L_829346;
    case 0x829349u: goto L_829349;
    case 0x82934Bu: goto L_82934B;
    case 0x82934Eu: goto L_82934E;
    case 0x829351u: goto L_829351;
    case 0x829354u: goto L_829354;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8292FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92FCu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92FCu, 5u, 3u, cpu.address("abs", 0x0193u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292FC LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x193u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8292FF;
L_8292FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92FFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92FFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292FF BEQ -> $829323
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_829323; }
    goto L_829301;
L_829301:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9301u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9301u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9301u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829301 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829303;
L_829303:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9303u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9303u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9303u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829303 BNE -> $82930A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82930A; }
    goto L_829305;
L_829305:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9305u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9305u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9305u, 5u, 3u, cpu.address("abs", 0x0195u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829305 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x195u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829308;
L_829308:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9308u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9308u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9308u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829308 BNE -> $82931C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82931C; }
    goto L_82930A;
L_82930A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x930Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x930Au,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x930Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82930A SEP
    cpu.sep(0x20u);
    goto L_82930C;
L_82930C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x930Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x930Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x930Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82930C LDA
    cpu.setA(0xCu, 8);
    goto L_82930E;
L_82930E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x930Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x930Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x930Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82930E STA
    hw.write(cpu.address("dp", 0x49u), cpu.a, cpu.m8?8:16);
    goto L_829310;
L_829310:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9310u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9310u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9310u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829310 LDA
    cpu.setA(0x81u, 8);
    goto L_829312;
L_829312:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9312u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9312u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9312u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829312 XBA
    cpu.xba();
    goto L_829313;
L_829313:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9313u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9313u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9313u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829313 LDA
    cpu.setA(0xFu, 8);
    goto L_829315;
L_829315:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9315u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9315u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9315u, 8u, 4u, 0x8086F4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829315 JSL -> $8086F4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9318u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9319u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8086F4u, 0x829315u); }
    goto L_829319;
L_829319:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9319u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9319u,0x829319u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9319u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9319u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829319 REP
    cpu.rep(0x20u);
    goto L_82931B;
L_82931B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x931Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x931Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x931Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82931B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82931Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82931Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82931C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x931Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x931Cu,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x931Cu, 8u, 3u, cpu.address("abs", 0x0195u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82931C DEC
    cpu.decMem(hw, cpu.address("abs", 0x195u), cpu.m8?8:16);
    goto L_82931F;
L_82931F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x931Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x931Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x931Fu, 8u, 4u, 0x80D814u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82931F JSL -> $80D814 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9322u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9323u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80D814u, 0x82931Fu); }
    goto L_829323;
L_829323:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9323u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9323u,0x829323u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9323u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9323u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829323 LDX
    cpu.setX(0x0u, 16);
    goto L_829326;
L_829326:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9326u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9326u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9326u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829326 STX
    hw.write(cpu.address("dp", 0x5Bu), cpu.x, cpu.x8?8:16);
    goto L_829328;
L_829328:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9328u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9328u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9328u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829328 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82932A;
L_82932A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x932Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x932Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x932Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xAAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82932A STA
    hw.write(cpu.address("dp", 0xAAu), cpu.a, cpu.m8?8:16);
    goto L_82932C;
L_82932C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x932Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x932Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x932Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82932C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82932E;
L_82932E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x932Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x932Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x932Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82932E STA
    hw.write(cpu.address("dp", 0xA8u), cpu.a, cpu.m8?8:16);
    goto L_829330;
L_829330:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9330u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9330u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9330u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829330 LDA
    cpu.setA(0x2000u, 16);
    goto L_829333;
L_829333:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9333u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9333u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9333u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x67u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829333 STA
    hw.write(cpu.address("dp", 0x67u), cpu.a, cpu.m8?8:16);
    goto L_829335;
L_829335:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9335u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9335u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9335u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829335 LDA
    cpu.setA(0x7Eu, 16);
    goto L_829338;
L_829338:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9338u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9338u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9338u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x69u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829338 STA
    hw.write(cpu.address("dp", 0x69u), cpu.a, cpu.m8?8:16);
    goto L_82933A;
L_82933A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x933Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x933Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x933Au, 6u, 3u, cpu.address("abs", 0x9B53u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82933A JSR -> $829B53 stack real
    { cpu.push16Value(hw,0x933Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x933Du,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9B53u), 0x82933Au); }
    goto L_82933D;
L_82933D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x933Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x933Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x933Du, 5u, 3u, cpu.address("abs", 0x0420u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82933D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x420u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829340;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x933Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x933Du, 5u, 3u, cpu.address("abs", 0x0420u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82933D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x420u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829340;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x933Du,0x82933Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829340:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9340u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9340u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9340u, 5u, 3u, cpu.address("abs", 0x02E8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829340 STA
    hw.write(cpu.address("abs", 0x2E8u), cpu.a, cpu.m8?8:16);
    goto L_829343;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9340u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9340u, 5u, 3u, cpu.address("abs", 0x02E8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829340 STA
    hw.write(cpu.address("abs", 0x2E8u), cpu.a, cpu.m8?8:16);
    goto L_829343;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9340u,0x829340u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829343:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9343u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9343u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9343u, 5u, 3u, cpu.address("abs", 0x013Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829343 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829346;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9343u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9343u, 5u, 3u, cpu.address("abs", 0x013Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829343 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829346;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9343u,0x829343u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829346:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9346u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9346u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9346u, 5u, 3u, cpu.address("abs", 0x0139u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829346 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x139u), cpu.m8?8:16));
    goto L_829349;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9346u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9346u, 5u, 3u, cpu.address("abs", 0x0139u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829346 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x139u), cpu.m8?8:16));
    goto L_829349;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9346u,0x829346u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829349:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9349u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9349u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9349u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829349 BNE -> $829354
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829354; }
    goto L_82934B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9349u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9349u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829349 BNE -> $829354
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829354; }
    goto L_82934B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9349u,0x829349u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82934B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x934Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x934Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x934Bu, 6u, 3u, cpu.address("abs", 0x9483u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82934B JSR -> $829483 stack real
    { cpu.push16Value(hw,0x934Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x934Eu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9483u), 0x82934Bu); }
    goto L_82934E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x934Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x934Bu, 6u, 3u, cpu.address("abs", 0x9483u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82934B JSR -> $829483 stack real
    { cpu.push16Value(hw,0x934Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x934Eu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9483u), 0x82934Bu); }
    goto L_82934E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x934Bu,0x82934Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82934E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x934Eu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x934Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x934Eu, 6u, 3u, cpu.address("abs", 0x94CFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82934E JSR -> $8294CF stack real
    { cpu.push16Value(hw,0x9350u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9351u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x94CFu), 0x82934Eu); }
    goto L_829351;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x934Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x934Eu, 6u, 3u, cpu.address("abs", 0x94CFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82934E JSR -> $8294CF stack real
    { cpu.push16Value(hw,0x9350u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9351u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x94CFu), 0x82934Eu); }
    goto L_829351;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x934Eu,0x82934Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829351:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9351u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9351u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9351u, 6u, 3u, cpu.address("abs", 0xD399u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829351 JSR -> $82D399 stack real
    { cpu.push16Value(hw,0x9353u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9354u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD399u), 0x829351u); }
    goto L_829354;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9351u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9351u, 6u, 3u, cpu.address("abs", 0xD399u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829351 JSR -> $82D399 stack real
    { cpu.push16Value(hw,0x9353u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9354u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD399u), 0x829351u); }
    goto L_829354;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9351u,0x829351u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829354:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9354u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9354u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9354u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829354 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829354u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829354u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9354u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9354u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829354 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829354u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829354u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9354u,0x829354u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82ABE3_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82ABE3u: goto L_82ABE3;
    case 0x82ABE6u: goto L_82ABE6;
    case 0x82ABE8u: goto L_82ABE8;
    case 0x82ABEBu: goto L_82ABEB;
    case 0x82ABEEu: goto L_82ABEE;
    case 0x82ABF0u: goto L_82ABF0;
    case 0x82ABF3u: goto L_82ABF3;
    case 0x82ABF5u: goto L_82ABF5;
    case 0x82ABF8u: goto L_82ABF8;
    case 0x82ABFAu: goto L_82ABFA;
    case 0x82ABFDu: goto L_82ABFD;
    case 0x82ABFFu: goto L_82ABFF;
    case 0x82AC02u: goto L_82AC02;
    case 0x82AC05u: goto L_82AC05;
    case 0x82AC07u: goto L_82AC07;
    case 0x82AC0Au: goto L_82AC0A;
    case 0x82AC0Cu: goto L_82AC0C;
    case 0x82AC0Fu: goto L_82AC0F;
    case 0x82AC11u: goto L_82AC11;
    case 0x82AC14u: goto L_82AC14;
    case 0x82AC16u: goto L_82AC16;
    case 0x82AC19u: goto L_82AC19;
    case 0x82AC1Cu: goto L_82AC1C;
    case 0x82AC1Eu: goto L_82AC1E;
    case 0x82AC21u: goto L_82AC21;
    case 0x82AC23u: goto L_82AC23;
    case 0x82AC26u: goto L_82AC26;
    case 0x82AC29u: goto L_82AC29;
    case 0x82AC2Cu: goto L_82AC2C;
    case 0x82AC2Eu: goto L_82AC2E;
    case 0x82AC30u: goto L_82AC30;
    case 0x82AC33u: goto L_82AC33;
    case 0x82AC36u: goto L_82AC36;
    case 0x82AC38u: goto L_82AC38;
    case 0x82AC3Bu: goto L_82AC3B;
    case 0x82AC3Eu: goto L_82AC3E;
    case 0x82AC40u: goto L_82AC40;
    case 0x82AC42u: goto L_82AC42;
    case 0x82AC45u: goto L_82AC45;
    case 0x82AC48u: goto L_82AC48;
    case 0x82AC4Bu: goto L_82AC4B;
    case 0x82AC4Du: goto L_82AC4D;
    case 0x82AC50u: goto L_82AC50;
    case 0x82AC52u: goto L_82AC52;
    case 0x82AC55u: goto L_82AC55;
    case 0x82AC58u: goto L_82AC58;
    case 0x82AC5Au: goto L_82AC5A;
    case 0x82AC5Du: goto L_82AC5D;
    case 0x82AC60u: goto L_82AC60;
    case 0x82AC63u: goto L_82AC63;
    case 0x82AC66u: goto L_82AC66;
    case 0x82AC68u: goto L_82AC68;
    case 0x82AC69u: goto L_82AC69;
    case 0x82AC6Au: goto L_82AC6A;
    case 0x82AC6Bu: goto L_82AC6B;
    case 0x82AC6Cu: goto L_82AC6C;
    case 0x82AC6Du: goto L_82AC6D;
    case 0x82AC70u: goto L_82AC70;
    case 0x82AC71u: goto L_82AC71;
    case 0x82AC74u: goto L_82AC74;
    case 0x82AC75u: goto L_82AC75;
    case 0x82AC78u: goto L_82AC78;
    case 0x82AC7Bu: goto L_82AC7B;
    case 0x82AC7Cu: goto L_82AC7C;
    case 0x82AC7Fu: goto L_82AC7F;
    case 0x82AC80u: goto L_82AC80;
    case 0x82AC83u: goto L_82AC83;
    case 0x82AC86u: goto L_82AC86;
    case 0x82AC89u: goto L_82AC89;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82ABE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABE3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABE3u, 5u, 3u, cpu.address("abs", 0x03E8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ABE3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x3E8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82ABE6;
L_82ABE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABE6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABE6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ABE6 BEQ -> $82ABFA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82ABFA; }
    goto L_82ABE8;
L_82ABE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABE8u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABE8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ABE8 LDX
    cpu.setX(0x1F8u, 16);
    goto L_82ABEB;
L_82ABEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABEBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABEBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ABEB LDA
    cpu.setA(0xF8FFu, 16);
    goto L_82ABEE;
L_82ABEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABEEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABEEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ABEE STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_82ABF0;
L_82ABF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABF0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABF0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ABF0 LDA
    cpu.setA(0x800u, 16);
    goto L_82ABF3;
L_82ABF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABF3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABF3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ABF3 STA
    hw.write(cpu.address("dp", 0x65u), cpu.a, cpu.m8?8:16);
    goto L_82ABF5;
L_82ABF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABF5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABF5u, 6u, 3u, cpu.address("abs", 0xAC8Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82ABF5 JSR -> $82AC8A stack real
    { cpu.push16Value(hw,0xABF7u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xABF8u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAC8Au), 0x82ABF5u); }
    goto L_82ABF8;
L_82ABF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABF8u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xABF8u,0x82ABF8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABF8u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABF8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ABF8 BRA -> $82AC55
    goto L_82AC55;
L_82ABFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABFAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABFAu, 5u, 3u, cpu.address("abs", 0x02E8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ABFA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2E8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82ABFD;
L_82ABFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABFDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABFDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ABFD BEQ -> $82AC11
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82AC11; }
    goto L_82ABFF;
L_82ABFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABFFu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABFFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ABFF LDX
    cpu.setX(0x418u, 16);
    goto L_82AC02;
L_82AC02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC02u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC02u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC02 LDA
    cpu.setA(0xF8FFu, 16);
    goto L_82AC05;
L_82AC05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC05u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC05u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC05 STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_82AC07;
L_82AC07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC07u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC07u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC07 LDA
    cpu.setA(0x800u, 16);
    goto L_82AC0A;
L_82AC0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC0A STA
    hw.write(cpu.address("dp", 0x65u), cpu.a, cpu.m8?8:16);
    goto L_82AC0C;
L_82AC0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Cu, 6u, 3u, cpu.address("abs", 0xAC8Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AC0C JSR -> $82AC8A stack real
    { cpu.push16Value(hw,0xAC0Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAC0Fu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAC8Au), 0x82AC0Cu); }
    goto L_82AC0F;
L_82AC0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC0Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAC0Fu,0x82AC0Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Fu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC0F BRA -> $82AC55
    goto L_82AC55;
L_82AC11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC11u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC11u, 5u, 3u, cpu.address("abs", 0x02EAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC11 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2EAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AC14;
L_82AC14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC14u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC14u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC14 BEQ -> $82AC33
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82AC33; }
    goto L_82AC16;
L_82AC16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC16u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC16u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC16 LDX
    cpu.setX(0x1F8u, 16);
    goto L_82AC19;
L_82AC19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC19u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC19u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC19 LDA
    cpu.setA(0xF8FFu, 16);
    goto L_82AC1C;
L_82AC1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC1Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC1Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC1C STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_82AC1E;
L_82AC1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC1Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC1Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC1E LDA
    cpu.setA(0x800u, 16);
    goto L_82AC21;
L_82AC21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC21u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC21u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC21 STA
    hw.write(cpu.address("dp", 0x65u), cpu.a, cpu.m8?8:16);
    goto L_82AC23;
L_82AC23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC23u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC23u, 6u, 3u, cpu.address("abs", 0xAC8Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AC23 JSR -> $82AC8A stack real
    { cpu.push16Value(hw,0xAC25u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAC26u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAC8Au), 0x82AC23u); }
    goto L_82AC26;
L_82AC26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC26u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAC26u,0x82AC26u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC26u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC26u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC26 LDX
    cpu.setX(0x418u, 16);
    goto L_82AC29;
L_82AC29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC29u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC29u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC29 LDA
    cpu.setA(0xFBFFu, 16);
    goto L_82AC2C;
L_82AC2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC2Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC2Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC2C STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_82AC2E;
L_82AC2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC2Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC2Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC2E STZ
    hw.write(cpu.address("dp", 0x65u), 0, cpu.m8?8:16);
    goto L_82AC30;
L_82AC30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC30u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC30u, 6u, 3u, cpu.address("abs", 0xAC8Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AC30 JSR -> $82AC8A stack real
    { cpu.push16Value(hw,0xAC32u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAC33u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAC8Au), 0x82AC30u); }
    goto L_82AC33;
L_82AC33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC33u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAC33u,0x82AC33u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC33u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC33u, 5u, 3u, cpu.address("abs", 0x03EAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC33 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x3EAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AC36;
L_82AC36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC36u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC36u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC36 BEQ -> $82AC55
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82AC55; }
    goto L_82AC38;
L_82AC38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC38u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC38u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC38 LDX
    cpu.setX(0x1F8u, 16);
    goto L_82AC3B;
L_82AC3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC3Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC3Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC3B LDA
    cpu.setA(0xFBFFu, 16);
    goto L_82AC3E;
L_82AC3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC3Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC3Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC3E STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_82AC40;
L_82AC40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC40u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC40u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC40 STZ
    hw.write(cpu.address("dp", 0x65u), 0, cpu.m8?8:16);
    goto L_82AC42;
L_82AC42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC42u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC42u, 6u, 3u, cpu.address("abs", 0xAC8Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AC42 JSR -> $82AC8A stack real
    { cpu.push16Value(hw,0xAC44u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAC45u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAC8Au), 0x82AC42u); }
    goto L_82AC45;
L_82AC45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC45u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAC45u,0x82AC45u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC45u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC45u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC45 LDX
    cpu.setX(0x418u, 16);
    goto L_82AC48;
L_82AC48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC48u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC48u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC48 LDA
    cpu.setA(0xF8FFu, 16);
    goto L_82AC4B;
L_82AC4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC4Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC4Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC4B STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_82AC4D;
L_82AC4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC4Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC4Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC4D LDA
    cpu.setA(0x800u, 16);
    goto L_82AC50;
L_82AC50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC50u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC50u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC50 STA
    hw.write(cpu.address("dp", 0x65u), cpu.a, cpu.m8?8:16);
    goto L_82AC52;
L_82AC52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC52u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC52u, 6u, 3u, cpu.address("abs", 0xAC8Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AC52 JSR -> $82AC8A stack real
    { cpu.push16Value(hw,0xAC54u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAC55u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAC8Au), 0x82AC52u); }
    goto L_82AC55;
L_82AC55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC55u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAC55u,0x82AC55u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC55u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC55u, 5u, 3u, cpu.address("abs", 0x018Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC55 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AC58;
L_82AC58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC58u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC58u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC58 BNE -> $82AC86
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82AC86; }
    goto L_82AC5A;
L_82AC5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC5Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC5Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC5A LDA
    cpu.setA(0x4u, 16);
    goto L_82AC5D;
L_82AC5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC5Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC5Du, 5u, 3u, cpu.address("abs", 0x018Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC5D STA
    hw.write(cpu.address("abs", 0x18Fu), cpu.a, cpu.m8?8:16);
    goto L_82AC60;
L_82AC60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC60u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC60u, 5u, 3u, cpu.address("abs", 0x0191u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC60 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x191u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AC63;
L_82AC63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC63u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC63u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC63 CMP
    cpu.compareA(0x8u);
    goto L_82AC66;
L_82AC66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC66u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC66u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC66 BCS -> $82AC89
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82AC89; }
    goto L_82AC68;
L_82AC68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC68u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC68u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC68 ASL
    cpu.aslA();
    goto L_82AC69;
L_82AC69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC69u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC69u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC69 ASL
    cpu.aslA();
    goto L_82AC6A;
L_82AC6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC6Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC6Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC6A ASL
    cpu.aslA();
    goto L_82AC6B;
L_82AC6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC6Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC6Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC6B ASL
    cpu.aslA();
    goto L_82AC6C;
L_82AC6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC6Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC6Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC6C ASL
    cpu.aslA();
    goto L_82AC6D;
L_82AC6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC6Du,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC6Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC6D ORA
    cpu.logicOr(0x100u);
    goto L_82AC70;
L_82AC70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC70u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC70u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC70 CLC
    cpu.setFlag('C', false);
    goto L_82AC71;
L_82AC71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC71u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC71u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC71 ADC
    cpu.adc(0x8A6Cu);
    goto L_82AC74;
L_82AC74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC74u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC74u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC74 TAX
    cpu.transfer("TAX");
    goto L_82AC75;
L_82AC75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC75u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC75u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC75 LDY
    cpu.setY(0x1920u, 16);
    goto L_82AC78;
L_82AC78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC78u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC78u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC78 LDA
    cpu.setA(0x1Fu, 16);
    goto L_82AC7B;
L_82AC7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC7Bu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC7Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82AC7B PHB
    cpu.push("PHB", hw);
    goto L_82AC7C;
L_82AC7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC7Cu,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xAC7Cu, (std::uint32_t(cpu.a)+1u), 0x8Au, 0x82u);
    // $82AC7C MVN
    cpu.blockMove(hw, 0x82u, 0x8Au, false);
    goto L_82AC7F;
L_82AC7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC7Fu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC7Fu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82AC7F PLP
    cpu.pop("PLP", hw);
    goto L_82AC80;
L_82AC80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC80u))return;
  // 4 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC80u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC80u, 8u, 3u, cpu.address("abs", 0x0191u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC80 INC
    cpu.incMem(hw, cpu.address("abs", 0x191u), cpu.m8?8:16);
    goto L_82AC83;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC80u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC80u, 8u, 3u, cpu.address("abs", 0x0191u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC80 INC
    cpu.incMem(hw, cpu.address("abs", 0x191u), cpu.m8?8:16);
    goto L_82AC83;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC80u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC80u, 6u, 3u, cpu.address("abs", 0x0191u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC80 INC
    cpu.incMem(hw, cpu.address("abs", 0x191u), cpu.m8?8:16);
    goto L_82AC83;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC80u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC80u, 6u, 3u, cpu.address("abs", 0x0191u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC80 INC
    cpu.incMem(hw, cpu.address("abs", 0x191u), cpu.m8?8:16);
    goto L_82AC83;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAC80u,0x82AC80u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82AC83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC83u))return;
  // 4 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC83u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC83u, 8u, 3u, cpu.address("abs", 0x0122u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC83 INC
    cpu.incMem(hw, cpu.address("abs", 0x122u), cpu.m8?8:16);
    goto L_82AC86;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC83u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC83u, 8u, 3u, cpu.address("abs", 0x0122u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC83 INC
    cpu.incMem(hw, cpu.address("abs", 0x122u), cpu.m8?8:16);
    goto L_82AC86;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC83u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC83u, 6u, 3u, cpu.address("abs", 0x0122u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC83 INC
    cpu.incMem(hw, cpu.address("abs", 0x122u), cpu.m8?8:16);
    goto L_82AC86;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC83u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC83u, 6u, 3u, cpu.address("abs", 0x0122u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC83 INC
    cpu.incMem(hw, cpu.address("abs", 0x122u), cpu.m8?8:16);
    goto L_82AC86;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAC83u,0x82AC83u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82AC86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC86u))return;
  // 4 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC86u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC86u, 8u, 3u, cpu.address("abs", 0x018Fu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC86 DEC
    cpu.decMem(hw, cpu.address("abs", 0x18Fu), cpu.m8?8:16);
    goto L_82AC89;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC86u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC86u, 8u, 3u, cpu.address("abs", 0x018Fu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC86 DEC
    cpu.decMem(hw, cpu.address("abs", 0x18Fu), cpu.m8?8:16);
    goto L_82AC89;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC86u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC86u, 6u, 3u, cpu.address("abs", 0x018Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC86 DEC
    cpu.decMem(hw, cpu.address("abs", 0x18Fu), cpu.m8?8:16);
    goto L_82AC89;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC86u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC86u, 6u, 3u, cpu.address("abs", 0x018Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC86 DEC
    cpu.decMem(hw, cpu.address("abs", 0x18Fu), cpu.m8?8:16);
    goto L_82AC89;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAC86u,0x82AC86u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82AC89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC89u))return;
  // 4 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC89u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC89u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AC89 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82AC89u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82AC89u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC89u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC89u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AC89 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82AC89u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82AC89u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC89u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC89u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AC89 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82AC89u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82AC89u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC89u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC89u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AC89 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82AC89u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82AC89u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAC89u,0x82AC89u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82B914_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B914u: goto L_82B914;
    case 0x82B917u: goto L_82B917;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B914:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB914u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB914u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB914u, 6u, 3u, cpu.address("abs", 0xB998u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B914 JSR -> $82B998 stack real
    { cpu.push16Value(hw,0xB916u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB917u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB998u), 0x82B914u); }
    goto L_82B917;
L_82B917:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB917u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB917u,0x82B917u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB917u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB917u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B917 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B917u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B917u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82C1D9_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82C1D9u: goto L_82C1D9;
    case 0x82C1DCu: goto L_82C1DC;
    case 0x82C1DFu: goto L_82C1DF;
    case 0x82C1E2u: goto L_82C1E2;
    case 0x82C1E4u: goto L_82C1E4;
    case 0x82C1E6u: goto L_82C1E6;
    case 0x82C1E9u: goto L_82C1E9;
    case 0x82C1EBu: goto L_82C1EB;
    case 0x82C1EEu: goto L_82C1EE;
    case 0x82C1F2u: goto L_82C1F2;
    case 0x82C1F5u: goto L_82C1F5;
    case 0x82C1F7u: goto L_82C1F7;
    case 0x82C1FAu: goto L_82C1FA;
    case 0x82C1FCu: goto L_82C1FC;
    case 0x82C1FEu: goto L_82C1FE;
    case 0x82C200u: goto L_82C200;
    case 0x82C202u: goto L_82C202;
    case 0x82C204u: goto L_82C204;
    case 0x82C206u: goto L_82C206;
    case 0x82C209u: goto L_82C209;
    case 0x82C20Bu: goto L_82C20B;
    case 0x82C20Eu: goto L_82C20E;
    case 0x82C210u: goto L_82C210;
    case 0x82C213u: goto L_82C213;
    case 0x82C215u: goto L_82C215;
    case 0x82C218u: goto L_82C218;
    case 0x82C21Au: goto L_82C21A;
    case 0x82C21Du: goto L_82C21D;
    case 0x82C21Fu: goto L_82C21F;
    case 0x82C222u: goto L_82C222;
    case 0x82C225u: goto L_82C225;
    case 0x82C229u: goto L_82C229;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82C1D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1D9u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1D9u, 8u, 3u, cpu.address("abs", 0x014Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C1D9 INC
    cpu.incMem(hw, cpu.address("abs", 0x14Au), cpu.m8?8:16);
    goto L_82C1DC;
L_82C1DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1DCu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1DCu, 5u, 3u, cpu.address("abs", 0x2140u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C1DC LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2140u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C1DF;
L_82C1DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1DFu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1DFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C1DF AND
    cpu.logicAnd(0xFFu);
    goto L_82C1E2;
L_82C1E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1E2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1E2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C1E2 BNE -> $82C229
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C229; }
    goto L_82C1E4;
L_82C1E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1E4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1E4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C1E4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C1E6;
L_82C1E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1E6u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1E6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C1E6 BIT
    cpu.bit(0x1080u, true);
    goto L_82C1E9;
L_82C1E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1E9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1E9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C1E9 BEQ -> $82C206
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C206; }
    goto L_82C1EB;
L_82C1EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1EBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1EBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C1EB LDA
    cpu.setA(0x4u, 16);
    goto L_82C1EE;
L_82C1EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1EEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1EEu, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82C1EE JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC1F1u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC1F2u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x82C1EEu); }
    goto L_82C1F2;
L_82C1F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1F2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC1F2u,0x82C1F2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1F2u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1F2u, 5u, 3u, cpu.address("abs", 0x0177u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C1F2 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x177u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C1F5;
L_82C1F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1F5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1F5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C1F5 BNE -> $82C1FC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C1FC; }
    goto L_82C1F7;
L_82C1F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1F7u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1F7u, 8u, 3u, cpu.address("abs", 0x0176u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C1F7 INC
    cpu.incMem(hw, cpu.address("abs", 0x176u), cpu.m8?8:16);
    goto L_82C1FA;
L_82C1FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1FAu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1FAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C1FA BRA -> $82C229
    goto L_82C229;
L_82C1FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1FCu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1FCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C1FC SEP
    cpu.sep(0x20u);
    goto L_82C1FE;
L_82C1FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1FEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1FEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C1FE LDA
    cpu.setA(0x9u, 8);
    goto L_82C200;
L_82C200:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC200u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC200u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC200u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C200 STA
    hw.write(cpu.address("dp", 0x49u), cpu.a, cpu.m8?8:16);
    goto L_82C202;
L_82C202:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC202u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC202u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC202u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C202 REP
    cpu.rep(0x20u);
    goto L_82C204;
L_82C204:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC204u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC204u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC204u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C204 BRA -> $82C229
    goto L_82C229;
L_82C206:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC206u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC206u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC206u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C206 BIT
    cpu.bit(0x300u, true);
    goto L_82C209;
L_82C209:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC209u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC209u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC209u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C209 BEQ -> $82C229
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C229; }
    goto L_82C20B;
L_82C20B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC20Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC20Bu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC20Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C20B BIT
    cpu.bit(0x100u, true);
    goto L_82C20E;
L_82C20E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC20Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC20Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC20Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C20E BEQ -> $82C21A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C21A; }
    goto L_82C210;
L_82C210:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC210u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC210u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC210u, 5u, 3u, cpu.address("abs", 0x0177u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C210 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x177u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C213;
L_82C213:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC213u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC213u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC213u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C213 BNE -> $82C229
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C229; }
    goto L_82C215;
L_82C215:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC215u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC215u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC215u, 8u, 3u, cpu.address("abs", 0x0177u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C215 INC
    cpu.incMem(hw, cpu.address("abs", 0x177u), cpu.m8?8:16);
    goto L_82C218;
L_82C218:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC218u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC218u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC218u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C218 BRA -> $82C222
    goto L_82C222;
L_82C21A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC21Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC21Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC21Au, 5u, 3u, cpu.address("abs", 0x0177u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C21A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x177u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C21D;
L_82C21D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC21Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC21Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC21Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C21D BEQ -> $82C229
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C229; }
    goto L_82C21F;
L_82C21F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC21Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC21Fu,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC21Fu, 8u, 3u, cpu.address("abs", 0x0177u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C21F DEC
    cpu.decMem(hw, cpu.address("abs", 0x177u), cpu.m8?8:16);
    goto L_82C222;
L_82C222:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC222u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC222u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC222u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C222 LDA
    cpu.setA(0x6u, 16);
    goto L_82C225;
L_82C225:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC225u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC225u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC225u, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82C225 JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC228u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC229u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x82C225u); }
    goto L_82C229;
L_82C229:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC229u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC229u,0x82C229u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC229u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC229u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C229 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C229u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C229u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82CA5A_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82CA5Au: goto L_82CA5A;
    case 0x82CA5Du: goto L_82CA5D;
    case 0x82CA61u: goto L_82CA61;
    case 0x82CA63u: goto L_82CA63;
    case 0x82CA66u: goto L_82CA66;
    case 0x82CA68u: goto L_82CA68;
    case 0x82CA6Bu: goto L_82CA6B;
    case 0x82CA6Du: goto L_82CA6D;
    case 0x82CA70u: goto L_82CA70;
    case 0x82CA72u: goto L_82CA72;
    case 0x82CA76u: goto L_82CA76;
    case 0x82CA79u: goto L_82CA79;
    case 0x82CA7Bu: goto L_82CA7B;
    case 0x82CA7Fu: goto L_82CA7F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82CA5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA5Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA5Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA5A LDX
    cpu.setX(0x4u, 16);
    goto L_82CA5D;
L_82CA5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA5Du,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA5Du, 6u, 4u, ((0x9E8232u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA5D LDA
    cpu.loadA(hw.readW(((0x9E8232u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CA61;
L_82CA61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA61u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA61u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA61 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82CA63;
L_82CA63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA63u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA63u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA63 LDA
    cpu.setA(0x9Eu, 16);
    goto L_82CA66;
L_82CA66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA66u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA66u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA66 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82CA68;
L_82CA68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA68u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA68u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA68 LDA
    cpu.setA(0x58u, 16);
    goto L_82CA6B;
L_82CA6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA6Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA6Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA6B STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82CA6D;
L_82CA6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA6Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA6Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA6D LDA
    cpu.setA(0x38u, 16);
    goto L_82CA70;
L_82CA70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA70u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA70u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA70 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82CA72;
L_82CA72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA72u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA72u, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82CA72 JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCA75u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCA76u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x82CA72u); }
    goto L_82CA76;
L_82CA76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA76u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCA76u,0x82CA76u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA76u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA76u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA76 LDA
    cpu.setA(0xC8u, 16);
    goto L_82CA79;
L_82CA79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA79u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA79u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CA79 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82CA7B;
L_82CA7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Bu, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82CA7B JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCA7Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCA7Fu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x82CA7Bu); }
    goto L_82CA7F;
L_82CA7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA7Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCA7Fu,0x82CA7Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CA7F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82CA7Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82CA7Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_848F05_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848F05u: goto L_848F05;
    case 0x848F07u: goto L_848F07;
    case 0x848F09u: goto L_848F09;
    case 0x848F0Bu: goto L_848F0B;
    case 0x848F0Du: goto L_848F0D;
    case 0x848F0Eu: goto L_848F0E;
    case 0x848F10u: goto L_848F10;
    case 0x848F12u: goto L_848F12;
    case 0x848F14u: goto L_848F14;
    case 0x848F17u: goto L_848F17;
    case 0x848F19u: goto L_848F19;
    case 0x848F1Bu: goto L_848F1B;
    case 0x848F1Eu: goto L_848F1E;
    case 0x848F20u: goto L_848F20;
    case 0x848F22u: goto L_848F22;
    case 0x848F25u: goto L_848F25;
    case 0x848F27u: goto L_848F27;
    case 0x848F2Au: goto L_848F2A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848F05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F05u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F05u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F05 SEP
    cpu.sep(0x20u);
    goto L_848F07;
L_848F07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F07u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F07u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F07 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848F09;
L_848F09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F09u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F09u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F09 BNE -> $848F0E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848F0E; }
    goto L_848F0B;
L_848F0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Bu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F0B INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_848F0D;
L_848F0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848F0D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848F0Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848F0Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_848F0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F0E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848F10;
L_848F10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F10u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F10u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F10 CMP
    cpu.compareA(0x3u);
    goto L_848F12;
L_848F12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F12u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F12u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F12 BCS -> $848F2A
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_848F2A; }
    goto L_848F14;
L_848F14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F14u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F14u, 4u, 3u, cpu.address("abs", 0x062Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F14 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848F17;
L_848F17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F17u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F17u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F17 BIT
    cpu.bit(0x1u, true);
    goto L_848F19;
L_848F19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F19u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F19u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F19 BEQ -> $848F27
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848F27; }
    goto L_848F1B;
L_848F1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Bu, 4u, 3u, cpu.address("abs", 0x06FDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F1B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6FDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848F1E;
L_848F1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Eu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F1E BIT
    cpu.bit(0x1u, true);
    goto L_848F20;
L_848F20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F20u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F20 BEQ -> $848F27
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848F27; }
    goto L_848F22;
L_848F22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F22u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F22u, 6u, 3u, cpu.address("abs", 0x9C6Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848F22 JSR -> $849C6F stack real
    { cpu.push16Value(hw,0x8F24u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8F25u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9C6Fu), 0x848F22u); }
    goto L_848F25;
L_848F25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F25u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F25u,0x848F25u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F25u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F25u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F25 BRA -> $848F2A
    goto L_848F2A;
L_848F27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F27u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F27u, 6u, 3u, cpu.address("abs", 0x9CB4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848F27 JSR -> $849CB4 stack real
    { cpu.push16Value(hw,0x8F29u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8F2Au,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9CB4u), 0x848F27u); }
    goto L_848F2A;
L_848F2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F2Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848F2A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848F2Au);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848F2Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848F2A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848F2Au);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848F2Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F2Au,0x848F2Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_848F05_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848F05u: goto L_848F05;
    case 0x848F07u: goto L_848F07;
    case 0x848F09u: goto L_848F09;
    case 0x848F0Bu: goto L_848F0B;
    case 0x848F0Du: goto L_848F0D;
    case 0x848F0Eu: goto L_848F0E;
    case 0x848F10u: goto L_848F10;
    case 0x848F12u: goto L_848F12;
    case 0x848F14u: goto L_848F14;
    case 0x848F17u: goto L_848F17;
    case 0x848F19u: goto L_848F19;
    case 0x848F1Bu: goto L_848F1B;
    case 0x848F1Eu: goto L_848F1E;
    case 0x848F20u: goto L_848F20;
    case 0x848F22u: goto L_848F22;
    case 0x848F25u: goto L_848F25;
    case 0x848F27u: goto L_848F27;
    case 0x848F2Au: goto L_848F2A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848F05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F05u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F05u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F05 SEP
    cpu.sep(0x20u);
    goto L_848F07;
L_848F07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F07u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F07u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F07 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848F09;
L_848F09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F09u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F09u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F09 BNE -> $848F0E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848F0E; }
    goto L_848F0B;
L_848F0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Bu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F0B INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_848F0D;
L_848F0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848F0D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848F0Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848F0Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_848F0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F0E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848F10;
L_848F10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F10u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F10u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F10 CMP
    cpu.compareA(0x3u);
    goto L_848F12;
L_848F12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F12u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F12u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F12 BCS -> $848F2A
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_848F2A; }
    goto L_848F14;
L_848F14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F14u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F14u, 4u, 3u, cpu.address("abs", 0x062Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F14 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848F17;
L_848F17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F17u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F17u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F17 BIT
    cpu.bit(0x1u, true);
    goto L_848F19;
L_848F19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F19u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F19u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F19 BEQ -> $848F27
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848F27; }
    goto L_848F1B;
L_848F1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Bu, 4u, 3u, cpu.address("abs", 0x06FDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F1B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6FDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848F1E;
L_848F1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Eu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F1E BIT
    cpu.bit(0x1u, true);
    goto L_848F20;
L_848F20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F20u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F20 BEQ -> $848F27
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848F27; }
    goto L_848F22;
L_848F22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F22u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F22u, 6u, 3u, cpu.address("abs", 0x9C6Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848F22 JSR -> $849C6F stack real
    { cpu.push16Value(hw,0x8F24u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8F25u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9C6Fu), 0x848F22u); }
    goto L_848F25;
L_848F25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F25u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F25u,0x848F25u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F25u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F25u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F25 BRA -> $848F2A
    goto L_848F2A;
L_848F27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F27u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F27u, 6u, 3u, cpu.address("abs", 0x9CB4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848F27 JSR -> $849CB4 stack real
    { cpu.push16Value(hw,0x8F29u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8F2Au,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9CB4u), 0x848F27u); }
    goto L_848F2A;
L_848F2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F2Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848F2A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848F2Au);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848F2Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848F2A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848F2Au);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848F2Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F2Au,0x848F2Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_849022_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849022u: goto L_849022;
    case 0x849024u: goto L_849024;
    case 0x849027u: goto L_849027;
    case 0x84902Au: goto L_84902A;
    case 0x84902Du: goto L_84902D;
    case 0x849030u: goto L_849030;
    case 0x849033u: goto L_849033;
    case 0x849036u: goto L_849036;
    case 0x849039u: goto L_849039;
    case 0x84903Cu: goto L_84903C;
    case 0x84903Fu: goto L_84903F;
    case 0x849042u: goto L_849042;
    case 0x849045u: goto L_849045;
    case 0x849046u: goto L_849046;
    case 0x849048u: goto L_849048;
    case 0x84904Cu: goto L_84904C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849022:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9022u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9022u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9022u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849022 REP
    cpu.rep(0x20u);
    goto L_849024;
L_849024:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9024u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9024u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9024u, 5u, 3u, cpu.address("abs", 0x041Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849024 STZ
    hw.write(cpu.address("abs", 0x41Eu), 0, cpu.m8?8:16);
    goto L_849027;
L_849027:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9027u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9027u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9027u, 5u, 3u, cpu.address("abs", 0x051Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849027 STZ
    hw.write(cpu.address("abs", 0x51Eu), 0, cpu.m8?8:16);
    goto L_84902A;
L_84902A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x902Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x902Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x902Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84902A LDA
    cpu.setA(0x8000u, 16);
    goto L_84902D;
L_84902D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x902Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x902Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x902Du, 5u, 3u, cpu.address("abs", 0x0424u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84902D STA
    hw.write(cpu.address("abs", 0x424u), cpu.a, cpu.m8?8:16);
    goto L_849030;
L_849030:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9030u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9030u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9030u, 5u, 3u, cpu.address("abs", 0x042Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849030 STA
    hw.write(cpu.address("abs", 0x42Cu), cpu.a, cpu.m8?8:16);
    goto L_849033;
L_849033:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9033u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9033u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9033u, 5u, 3u, cpu.address("abs", 0x0434u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849033 STA
    hw.write(cpu.address("abs", 0x434u), cpu.a, cpu.m8?8:16);
    goto L_849036;
L_849036:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9036u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9036u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9036u, 5u, 3u, cpu.address("abs", 0x0524u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849036 STA
    hw.write(cpu.address("abs", 0x524u), cpu.a, cpu.m8?8:16);
    goto L_849039;
L_849039:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9039u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9039u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9039u, 5u, 3u, cpu.address("abs", 0x052Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849039 STA
    hw.write(cpu.address("abs", 0x52Cu), cpu.a, cpu.m8?8:16);
    goto L_84903C;
L_84903C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x903Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x903Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x903Cu, 5u, 3u, cpu.address("abs", 0x0534u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84903C STA
    hw.write(cpu.address("abs", 0x534u), cpu.a, cpu.m8?8:16);
    goto L_84903F;
L_84903F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x903Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x903Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x903Fu, 5u, 3u, cpu.address("abs", 0x062Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84903F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849042;
L_849042:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9042u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9042u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9042u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849042 AND
    cpu.logicAnd(0x1u);
    goto L_849045;
L_849045:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9045u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9045u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9045u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849045 TAX
    cpu.transfer("TAX");
    goto L_849046;
L_849046:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9046u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9046u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9046u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849046 SEP
    cpu.sep(0x20u);
    goto L_849048;
L_849048:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9048u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9048u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9048u, 5u, 4u, ((0x84904Du + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849048 LDA
    cpu.loadA(hw.readW(((0x84904Du + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84904C;
L_84904C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x904Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x904Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x904Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84904C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84904Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84904Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_849022_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849022u: goto L_849022;
    case 0x849024u: goto L_849024;
    case 0x849027u: goto L_849027;
    case 0x84902Au: goto L_84902A;
    case 0x84902Du: goto L_84902D;
    case 0x849030u: goto L_849030;
    case 0x849033u: goto L_849033;
    case 0x849036u: goto L_849036;
    case 0x849039u: goto L_849039;
    case 0x84903Cu: goto L_84903C;
    case 0x84903Fu: goto L_84903F;
    case 0x849042u: goto L_849042;
    case 0x849045u: goto L_849045;
    case 0x849046u: goto L_849046;
    case 0x849048u: goto L_849048;
    case 0x84904Cu: goto L_84904C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849022:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9022u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9022u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9022u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849022 REP
    cpu.rep(0x20u);
    goto L_849024;
L_849024:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9024u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9024u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9024u, 5u, 3u, cpu.address("abs", 0x041Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849024 STZ
    hw.write(cpu.address("abs", 0x41Eu), 0, cpu.m8?8:16);
    goto L_849027;
L_849027:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9027u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9027u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9027u, 5u, 3u, cpu.address("abs", 0x051Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849027 STZ
    hw.write(cpu.address("abs", 0x51Eu), 0, cpu.m8?8:16);
    goto L_84902A;
L_84902A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x902Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x902Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x902Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84902A LDA
    cpu.setA(0x8000u, 16);
    goto L_84902D;
L_84902D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x902Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x902Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x902Du, 5u, 3u, cpu.address("abs", 0x0424u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84902D STA
    hw.write(cpu.address("abs", 0x424u), cpu.a, cpu.m8?8:16);
    goto L_849030;
L_849030:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9030u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9030u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9030u, 5u, 3u, cpu.address("abs", 0x042Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849030 STA
    hw.write(cpu.address("abs", 0x42Cu), cpu.a, cpu.m8?8:16);
    goto L_849033;
L_849033:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9033u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9033u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9033u, 5u, 3u, cpu.address("abs", 0x0434u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849033 STA
    hw.write(cpu.address("abs", 0x434u), cpu.a, cpu.m8?8:16);
    goto L_849036;
L_849036:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9036u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9036u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9036u, 5u, 3u, cpu.address("abs", 0x0524u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849036 STA
    hw.write(cpu.address("abs", 0x524u), cpu.a, cpu.m8?8:16);
    goto L_849039;
L_849039:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9039u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9039u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9039u, 5u, 3u, cpu.address("abs", 0x052Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849039 STA
    hw.write(cpu.address("abs", 0x52Cu), cpu.a, cpu.m8?8:16);
    goto L_84903C;
L_84903C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x903Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x903Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x903Cu, 5u, 3u, cpu.address("abs", 0x0534u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84903C STA
    hw.write(cpu.address("abs", 0x534u), cpu.a, cpu.m8?8:16);
    goto L_84903F;
L_84903F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x903Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x903Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x903Fu, 5u, 3u, cpu.address("abs", 0x062Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84903F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849042;
L_849042:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9042u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9042u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9042u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849042 AND
    cpu.logicAnd(0x1u);
    goto L_849045;
L_849045:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9045u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9045u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9045u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849045 TAX
    cpu.transfer("TAX");
    goto L_849046;
L_849046:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9046u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9046u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9046u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849046 SEP
    cpu.sep(0x20u);
    goto L_849048;
L_849048:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9048u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9048u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9048u, 5u, 4u, ((0x84904Du + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849048 LDA
    cpu.loadA(hw.readW(((0x84904Du + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84904C;
L_84904C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x904Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x904Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x904Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84904C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84904Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84904Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84BEA5_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84BEA5u: goto L_84BEA5;
    case 0x84BEA7u: goto L_84BEA7;
    case 0x84BEA9u: goto L_84BEA9;
    case 0x84BEABu: goto L_84BEAB;
    case 0x84BEAEu: goto L_84BEAE;
    case 0x84BEAFu: goto L_84BEAF;
    case 0x84BEB0u: goto L_84BEB0;
    case 0x84BEB3u: goto L_84BEB3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84BEA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA5u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEA5 SEP
    cpu.sep(0x20u);
    goto L_84BEA7;
L_84BEA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEA7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x49u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BEA9;
L_84BEA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA9u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEA9 REP
    cpu.rep(0x20u);
    goto L_84BEAB;
L_84BEAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEABu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEABu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEAB AND
    cpu.logicAnd(0xFFu);
    goto L_84BEAE;
L_84BEAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEAEu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEAEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEAE ASL
    cpu.aslA();
    goto L_84BEAF;
L_84BEAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEAFu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEAFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEAF TAX
    cpu.transfer("TAX");
    goto L_84BEB0;
L_84BEB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB0u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB0u, 5u, 3u, cpu.address("abs", 0xBEB5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84BEB0 PEA
    cpu.push16Value(hw, 0xBEB5u);
    goto L_84BEB3;
L_84BEB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB3u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB3u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xBEB7u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $84BEB3 JMP (BEB7,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xBEB7u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x84BEB3u); return; }
}

void sub_84BEA5_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84BEA5u: goto L_84BEA5;
    case 0x84BEA7u: goto L_84BEA7;
    case 0x84BEA9u: goto L_84BEA9;
    case 0x84BEABu: goto L_84BEAB;
    case 0x84BEAEu: goto L_84BEAE;
    case 0x84BEAFu: goto L_84BEAF;
    case 0x84BEB0u: goto L_84BEB0;
    case 0x84BEB3u: goto L_84BEB3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84BEA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA5u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEA5 SEP
    cpu.sep(0x20u);
    goto L_84BEA7;
L_84BEA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEA7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x49u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BEA9;
L_84BEA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA9u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEA9 REP
    cpu.rep(0x20u);
    goto L_84BEAB;
L_84BEAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEABu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEABu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEAB AND
    cpu.logicAnd(0xFFu);
    goto L_84BEAE;
L_84BEAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEAEu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEAEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEAE ASL
    cpu.aslA();
    goto L_84BEAF;
L_84BEAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEAFu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEAFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEAF TAX
    cpu.transfer("TAX");
    goto L_84BEB0;
L_84BEB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB0u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB0u, 5u, 3u, cpu.address("abs", 0xBEB5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84BEB0 PEA
    cpu.push16Value(hw, 0xBEB5u);
    goto L_84BEB3;
L_84BEB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB3u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB3u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xBEB7u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $84BEB3 JMP (BEB7,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xBEB7u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x84BEB3u); return; }
}

void sub_84C2C3_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84C2C3u: goto L_84C2C3;
    case 0x84C2C5u: goto L_84C2C5;
    case 0x84C2C8u: goto L_84C2C8;
    case 0x84C2C9u: goto L_84C2C9;
    case 0x84C2CAu: goto L_84C2CA;
    case 0x84C2CEu: goto L_84C2CE;
    case 0x84C2CFu: goto L_84C2CF;
    case 0x84C2D3u: goto L_84C2D3;
    case 0x84C2D4u: goto L_84C2D4;
    case 0x84C2D7u: goto L_84C2D7;
    case 0x84C2DBu: goto L_84C2DB;
    case 0x84C2DEu: goto L_84C2DE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84C2C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2C3u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2C3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2C3 REP
    cpu.rep(0x20u);
    goto L_84C2C5;
L_84C2C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2C5u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2C5u, 5u, 3u, cpu.address("abs", 0x060Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2C5 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x60Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84C2C8;
L_84C2C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2C8u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2C8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2C8 ASL
    cpu.aslA();
    goto L_84C2C9;
L_84C2C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2C9u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2C9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2C9 TAX
    cpu.transfer("TAX");
    goto L_84C2CA;
L_84C2CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2CAu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2CAu, 6u, 4u, ((0x84C2E7u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2CA LDA
    cpu.loadA(hw.readW(((0x84C2E7u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84C2CE;
L_84C2CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2CEu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2CEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2CE TAY
    cpu.transfer("TAY");
    goto L_84C2CF;
L_84C2CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2CFu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2CFu, 6u, 4u, ((0x84C2F3u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2CF LDA
    cpu.loadA(hw.readW(((0x84C2F3u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84C2D3;
L_84C2D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2D3u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2D3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2D3 TAX
    cpu.transfer("TAX");
    goto L_84C2D4;
L_84C2D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2D4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2D4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2D4 LDA
    cpu.setA(0x1000u, 16);
    goto L_84C2D7;
L_84C2D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2D7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2D7u, 8u, 4u, 0x808EBFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84C2D7 JSL -> $808EBF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC2DAu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC2DBu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808EBFu, 0x84C2D7u); }
    goto L_84C2DB;
L_84C2DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2DBu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC2DBu,0x84C2DBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2DBu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2DBu, 8u, 3u, cpu.address("abs", 0x060Fu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2DB INC
    cpu.incMem(hw, cpu.address("abs", 0x60Fu), cpu.m8?8:16);
    goto L_84C2DE;
L_84C2DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2DEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2DEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84C2DE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84C2DEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84C2DEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

