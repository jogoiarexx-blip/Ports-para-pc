#pragma once
#include "runtime.hpp"
void forja65_register_native_hooks(SnesRuntime&);
void forja65_dispatch(CpuState&, SnesRuntime&, std::uint32_t, std::uint32_t);
bool forja65_is_stack_return_target(std::uint32_t, SnesRuntime&);
void forja65_wait(CpuState&, SnesRuntime&, std::uint32_t);
