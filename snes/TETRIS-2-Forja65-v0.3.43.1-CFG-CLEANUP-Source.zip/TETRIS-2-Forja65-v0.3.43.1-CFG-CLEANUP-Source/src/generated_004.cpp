#include "generated.hpp"
void sub_00850F_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00850Fu: goto L_00850F;
    case 0x008511u: goto L_008511;
    case 0x008512u: goto L_008512;
    case 0x008513u: goto L_008513;
    case 0x008514u: goto L_008514;
    case 0x008515u: goto L_008515;
    case 0x008516u: goto L_008516;
    case 0x008519u: goto L_008519;
    case 0x00851Bu: goto L_00851B;
    case 0x00851Du: goto L_00851D;
    case 0x00851Fu: goto L_00851F;
    case 0x008520u: goto L_008520;
    case 0x008521u: goto L_008521;
    case 0x008524u: goto L_008524;
    case 0x008527u: goto L_008527;
    case 0x008529u: goto L_008529;
    case 0x00852Au: goto L_00852A;
    case 0x00852Bu: goto L_00852B;
    case 0x00852Cu: goto L_00852C;
    case 0x00852Du: goto L_00852D;
    case 0x00852Eu: goto L_00852E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00850F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x850Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x850Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x850Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00850F REP
    cpu.rep(0x20u);
    goto L_008511;
L_008511:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8511u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8511u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8511u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008511 PHA
    cpu.push("PHA", hw);
    goto L_008512;
L_008512:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8512u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8512u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8512u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $008512 PHX
    cpu.push("PHX", hw);
    goto L_008513;
L_008513:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8513u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8513u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8513u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $008513 PHY
    cpu.push("PHY", hw);
    goto L_008514;
L_008514:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8514u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8514u,cpu,0x0Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8514u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008514 PHD
    cpu.push("PHD", hw);
    goto L_008515;
L_008515:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8515u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8515u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8515u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $008515 PHB
    cpu.push("PHB", hw);
    goto L_008516;
L_008516:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8516u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8516u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8516u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008516 LDA
    cpu.setA(0x0u, 16);
    goto L_008519;
L_008519:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8519u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8519u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8519u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008519 SEP
    cpu.sep(0x20u);
    goto L_00851B;
L_00851B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x851Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x851Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x851Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00851B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00851D;
L_00851D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x851Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x851Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x851Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00851D AND
    cpu.logicAnd(0x7Fu);
    goto L_00851F;
L_00851F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x851Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x851Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x851Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00851F ASL
    cpu.aslA();
    goto L_008520;
L_008520:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8520u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8520u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8520u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008520 TAX
    cpu.transfer("TAX");
    goto L_008521;
L_008521:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8521u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8521u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8521u, 4u, 3u, cpu.address("abs", 0x4211u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008521 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x4211u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008524;
L_008524:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8524u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8524u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8524u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x852Fu + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $008524 JSR (852F,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x852Fu+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8526u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8527u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x008524u); }
    goto L_008527;
L_008527:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8527u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8527u,0x008527u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8527u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8527u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008527 REP
    cpu.rep(0x20u);
    goto L_008529;
L_008529:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8529u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8529u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8529u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $008529 PLB
    cpu.pop("PLB", hw);
    goto L_00852A;
L_00852A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x852Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x852Au,cpu,0x2Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x852Au, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00852A PLD
    cpu.pop("PLD", hw);
    goto L_00852B;
L_00852B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x852Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x852Bu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x852Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00852B PLY
    cpu.pop("PLY", hw);
    goto L_00852C;
L_00852C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x852Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x852Cu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x852Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $00852C PLX
    cpu.pop("PLX", hw);
    goto L_00852D;
L_00852D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x852Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x852Du,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x852Du, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00852D PLA
    cpu.pop("PLA", hw);
    goto L_00852E;
L_00852E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x852Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x852Eu,cpu,0x40u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x852Eu, 7u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $00852E RTI stack real
    {auto dst=cpu.returnInterrupt(hw);hw.requestDispatch(dst,0x00852Eu);return;}
}

void sub_8084CA_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8084CAu: goto L_8084CA;
    case 0x8084CBu: goto L_8084CB;
    case 0x8084CFu: goto L_8084CF;
    case 0x8084D1u: goto L_8084D1;
    case 0x8084D3u: goto L_8084D3;
    case 0x8084D7u: goto L_8084D7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8084CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84CAu,cpu,0x5Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84CAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8084CA TCD
    cpu.tcd();
    goto L_8084CB;
L_8084CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84CBu,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84CBu, 6u, 4u, 0x226B82u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8084CB LDA
    cpu.loadA(hw.readW(0x226B82u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_8084CF;
L_8084CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84CFu,cpu,0x53u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84CFu, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0x84u) & 0xFFFFu), 2u, 0u);
    // $8084CF EOR
    cpu.logicXor(hw.readW(cpu.addressStackIndirectY(hw, 0x84u), cpu.m8?8:16));
    goto L_8084D1;
L_8084D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84D1u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84D1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8084D1 STY
    hw.write(cpu.address("dp", 0x6Bu), cpu.y, cpu.x8?8:16);
    goto L_8084D3;
L_8084D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84D3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84D3u, 8u, 4u, 0x848EC7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8084D3 JSL -> $848EC7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x84D6u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x84D7u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848EC7u, 0x8084D3u); }
    goto L_8084D7;
L_8084D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84D7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84D7u,0x8084D7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84D7u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84D7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8084D7 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8084D7u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8084D7u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8086F4_E0M1X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8086F4u: goto L_8086F4;
    case 0x8086F5u: goto L_8086F5;
    case 0x8086F7u: goto L_8086F7;
    case 0x8086F9u: goto L_8086F9;
    case 0x8086FAu: goto L_8086FA;
    case 0x8086FCu: goto L_8086FC;
    case 0x8086FEu: goto L_8086FE;
    case 0x8086FFu: goto L_8086FF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8086F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F4u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F4u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8086F4 PHP
    cpu.push("PHP", hw);
    goto L_8086F5;
L_8086F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F5u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086F5 SEP
    cpu.sep(0x20u);
    goto L_8086F7;
L_8086F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086F7 STA
    hw.write(cpu.address("dp", 0x74u), cpu.a, cpu.m8?8:16);
    goto L_8086F9;
L_8086F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F9u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F9u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086F9 XBA
    cpu.xba();
    goto L_8086FA;
L_8086FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86FAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86FAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086FA STA
    hw.write(cpu.address("dp", 0x75u), cpu.a, cpu.m8?8:16);
    goto L_8086FC;
L_8086FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86FCu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86FCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086FC STZ
    hw.write(cpu.address("dp", 0x76u), 0, cpu.m8?8:16);
    goto L_8086FE;
L_8086FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86FEu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86FEu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8086FE PLP
    cpu.pop("PLP", hw);
    goto L_8086FF;
L_8086FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86FFu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86FFu,0x8086FFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86FFu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86FFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8086FF RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8086FFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8086FFu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8086F4_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8086F4u: goto L_8086F4;
    case 0x8086F5u: goto L_8086F5;
    case 0x8086F7u: goto L_8086F7;
    case 0x8086F9u: goto L_8086F9;
    case 0x8086FAu: goto L_8086FA;
    case 0x8086FCu: goto L_8086FC;
    case 0x8086FEu: goto L_8086FE;
    case 0x8086FFu: goto L_8086FF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8086F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F4u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F4u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8086F4 PHP
    cpu.push("PHP", hw);
    goto L_8086F5;
L_8086F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F5u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086F5 SEP
    cpu.sep(0x20u);
    goto L_8086F7;
L_8086F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086F7 STA
    hw.write(cpu.address("dp", 0x74u), cpu.a, cpu.m8?8:16);
    goto L_8086F9;
L_8086F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F9u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F9u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086F9 XBA
    cpu.xba();
    goto L_8086FA;
L_8086FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86FAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86FAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086FA STA
    hw.write(cpu.address("dp", 0x75u), cpu.a, cpu.m8?8:16);
    goto L_8086FC;
L_8086FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86FCu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86FCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086FC STZ
    hw.write(cpu.address("dp", 0x76u), 0, cpu.m8?8:16);
    goto L_8086FE;
L_8086FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86FEu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86FEu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8086FE PLP
    cpu.pop("PLP", hw);
    goto L_8086FF;
L_8086FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86FFu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86FFu,0x8086FFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86FFu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86FFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8086FF RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8086FFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8086FFu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80AEFE_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AEFEu: goto L_80AEFE;
    case 0x80AF01u: goto L_80AF01;
    case 0x80AF03u: goto L_80AF03;
    case 0x80AF06u: goto L_80AF06;
    case 0x80AF08u: goto L_80AF08;
    case 0x80AF0Bu: goto L_80AF0B;
    case 0x80AF0Eu: goto L_80AF0E;
    case 0x80AF11u: goto L_80AF11;
    case 0x80AF13u: goto L_80AF13;
    case 0x80AF16u: goto L_80AF16;
    case 0x80AF19u: goto L_80AF19;
    case 0x80AF1Cu: goto L_80AF1C;
    case 0x80AF1Fu: goto L_80AF1F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AEFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFEu, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEFE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AF01;
L_80AF01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF01u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF01u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF01 BEQ -> $80AF19
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AF19; }
    goto L_80AF03;
L_80AF03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF03u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF03u, 5u, 3u, cpu.address("abs", 0x0916u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF03 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x916u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AF06;
L_80AF06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF06u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF06u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF06 BEQ -> $80AF19
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AF19; }
    goto L_80AF08;
L_80AF08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF08u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF08u, 5u, 3u, cpu.address("abs", 0x097Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF08 STA
    hw.write(cpu.address("abs", 0x97Au), cpu.a, cpu.m8?8:16);
    goto L_80AF0B;
L_80AF0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF0Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF0Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF0B LDX
    cpu.setX(0x328u, 16);
    goto L_80AF0E;
L_80AF0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF0Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF0Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF0E LDA
    cpu.setA(0x3u, 16);
    goto L_80AF11;
L_80AF11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF11u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF11u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF11 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80AF13;
L_80AF13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF13u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF13u, 8u, 3u, cpu.address("abs", 0x0986u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF13 INC
    cpu.incMem(hw, cpu.address("abs", 0x986u), cpu.m8?8:16);
    goto L_80AF16;
L_80AF16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF16u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF16u, 6u, 3u, cpu.address("abs", 0xC85Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AF16 JSR -> $80C85C stack real
    { cpu.push16Value(hw,0xAF18u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF19u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC85Cu), 0x80AF16u); }
    goto L_80AF19;
L_80AF19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF19u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF19u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF19u, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF19 STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80AF1C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF19u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF19u, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF19 STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80AF1C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF19u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF19u, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF19 STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80AF1C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF19u,0x80AF19u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AF1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF1Cu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Cu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Cu, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF1C INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AF1F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Cu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Cu, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF1C INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AF1F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Cu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Cu, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF1C INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AF1F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF1Cu,0x80AF1Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AF1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF1Fu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AF1F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AF1Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AF1Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AF1F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AF1Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AF1Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AF1F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AF1Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AF1Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF1Fu,0x80AF1Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80B09A_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B09Au: goto L_80B09A;
    case 0x80B09Du: goto L_80B09D;
    case 0x80B09Fu: goto L_80B09F;
    case 0x80B0A2u: goto L_80B0A2;
    case 0x80B0A5u: goto L_80B0A5;
    case 0x80B0A7u: goto L_80B0A7;
    case 0x80B0AAu: goto L_80B0AA;
    case 0x80B0ADu: goto L_80B0AD;
    case 0x80B0B0u: goto L_80B0B0;
    case 0x80B0B3u: goto L_80B0B3;
    case 0x80B0B6u: goto L_80B0B6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B09A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB09Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB09Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB09Au, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B09A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B09D;
L_80B09D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB09Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB09Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB09Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B09D BEQ -> $80B0B0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B0B0; }
    goto L_80B09F;
L_80B09F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB09Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB09Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB09Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B09F LDX
    cpu.setX(0x3D8u, 16);
    goto L_80B0A2;
L_80B0A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0A2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0A2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0A2 LDA
    cpu.setA(0x2u, 16);
    goto L_80B0A5;
L_80B0A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0A5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0A5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0A5 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80B0A7;
L_80B0A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0A7u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0A7u, 8u, 3u, cpu.address("abs", 0x0986u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0A7 INC
    cpu.incMem(hw, cpu.address("abs", 0x986u), cpu.m8?8:16);
    goto L_80B0AA;
L_80B0AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0AAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0AAu, 6u, 3u, cpu.address("abs", 0xC7F6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B0AA JSR -> $80C7F6 stack real
    { cpu.push16Value(hw,0xB0ACu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0ADu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC7F6u), 0x80B0AAu); }
    goto L_80B0AD;
L_80B0AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0ADu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0ADu,0x80B0ADu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0ADu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0ADu, 6u, 3u, cpu.address("abs", 0xC404u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B0AD JSR -> $80C404 stack real
    { cpu.push16Value(hw,0xB0AFu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0B0u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC404u), 0x80B0ADu); }
    goto L_80B0B0;
L_80B0B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0B0u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B0u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B0u, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0B0 STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B0B3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B0u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B0u, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0B0 STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B0B3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B0u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B0u, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0B0 STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B0B3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0B0u,0x80B0B0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B0B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0B3u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B3u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B3u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0B3 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B0B6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B3u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B3u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0B3 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B0B6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B3u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B3u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0B3 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B0B6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0B3u,0x80B0B3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B0B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0B6u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B0B6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B0B6u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B0B6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B0B6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B0B6u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B0B6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B0B6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B0B6u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B0B6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0B6u,0x80B0B6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80B09A_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B09Au: goto L_80B09A;
    case 0x80B09Du: goto L_80B09D;
    case 0x80B09Fu: goto L_80B09F;
    case 0x80B0A2u: goto L_80B0A2;
    case 0x80B0A5u: goto L_80B0A5;
    case 0x80B0A7u: goto L_80B0A7;
    case 0x80B0AAu: goto L_80B0AA;
    case 0x80B0ADu: goto L_80B0AD;
    case 0x80B0B0u: goto L_80B0B0;
    case 0x80B0B3u: goto L_80B0B3;
    case 0x80B0B6u: goto L_80B0B6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B09A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB09Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB09Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB09Au, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B09A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B09D;
L_80B09D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB09Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB09Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB09Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B09D BEQ -> $80B0B0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B0B0; }
    goto L_80B09F;
L_80B09F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB09Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB09Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB09Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B09F LDX
    cpu.setX(0x3D8u, 16);
    goto L_80B0A2;
L_80B0A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0A2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0A2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0A2 LDA
    cpu.setA(0x2u, 16);
    goto L_80B0A5;
L_80B0A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0A5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0A5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0A5 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80B0A7;
L_80B0A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0A7u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0A7u, 8u, 3u, cpu.address("abs", 0x0986u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0A7 INC
    cpu.incMem(hw, cpu.address("abs", 0x986u), cpu.m8?8:16);
    goto L_80B0AA;
L_80B0AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0AAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0AAu, 6u, 3u, cpu.address("abs", 0xC7F6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B0AA JSR -> $80C7F6 stack real
    { cpu.push16Value(hw,0xB0ACu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0ADu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC7F6u), 0x80B0AAu); }
    goto L_80B0AD;
L_80B0AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0ADu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0ADu,0x80B0ADu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0ADu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0ADu, 6u, 3u, cpu.address("abs", 0xC404u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B0AD JSR -> $80C404 stack real
    { cpu.push16Value(hw,0xB0AFu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0B0u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC404u), 0x80B0ADu); }
    goto L_80B0B0;
L_80B0B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0B0u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B0u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B0u, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0B0 STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B0B3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B0u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B0u, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0B0 STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B0B3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B0u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B0u, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0B0 STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B0B3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0B0u,0x80B0B0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B0B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0B3u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B3u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B3u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0B3 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B0B6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B3u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B3u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0B3 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B0B6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B3u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B3u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0B3 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B0B6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0B3u,0x80B0B3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B0B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0B6u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B0B6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B0B6u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B0B6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B0B6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B0B6u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B0B6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B0B6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B0B6u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B0B6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0B6u,0x80B0B6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80B2B6_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B2B6u: goto L_80B2B6;
    case 0x80B2B9u: goto L_80B2B9;
    case 0x80B2BBu: goto L_80B2BB;
    case 0x80B2BEu: goto L_80B2BE;
    case 0x80B2C0u: goto L_80B2C0;
    case 0x80B2C3u: goto L_80B2C3;
    case 0x80B2C6u: goto L_80B2C6;
    case 0x80B2C9u: goto L_80B2C9;
    case 0x80B2CCu: goto L_80B2CC;
    case 0x80B2CFu: goto L_80B2CF;
    case 0x80B2D2u: goto L_80B2D2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B2B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2B6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2B6u, 5u, 3u, cpu.address("abs", 0x0137u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2B6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x137u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B2B9;
L_80B2B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2B9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2B9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2B9 BEQ -> $80B2CC
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B2CC; }
    goto L_80B2BB;
L_80B2BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BBu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BBu, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2BB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B2BE;
L_80B2BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2BEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2BE BEQ -> $80B2CC
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B2CC; }
    goto L_80B2C0;
L_80B2C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C0u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C0u, 8u, 3u, cpu.address("abs", 0x0986u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C0 INC
    cpu.incMem(hw, cpu.address("abs", 0x986u), cpu.m8?8:16);
    goto L_80B2C3;
L_80B2C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C3u, 5u, 3u, cpu.address("abs", 0x0914u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x914u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B2C6;
L_80B2C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C6u, 5u, 3u, cpu.address("abs", 0x097Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2C6 STA
    hw.write(cpu.address("abs", 0x97Au), cpu.a, cpu.m8?8:16);
    goto L_80B2C9;
L_80B2C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2C9u, 6u, 3u, cpu.address("abs", 0xCE62u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B2C9 JSR -> $80CE62 stack real
    { cpu.push16Value(hw,0xB2CBu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB2CCu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCE62u), 0x80B2C9u); }
    goto L_80B2CC;
L_80B2CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2CCu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CCu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CCu, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2CC STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B2CF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CCu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CCu, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2CC STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B2CF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CCu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CCu, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2CC STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B2CF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2CCu,0x80B2CCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2CFu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CFu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CFu, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2CF INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B2D2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CFu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CFu, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2CF INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B2D2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CFu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CFu, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2CF INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B2D2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2CFu,0x80B2CFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D2u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B2D2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B2D2u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B2D2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B2D2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B2D2u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B2D2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B2D2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B2D2u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B2D2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2D2u,0x80B2D2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80B53A_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B53Au: goto L_80B53A;
    case 0x80B53Cu: goto L_80B53C;
    case 0x80B53Fu: goto L_80B53F;
    case 0x80B541u: goto L_80B541;
    case 0x80B543u: goto L_80B543;
    case 0x80B546u: goto L_80B546;
    case 0x80B548u: goto L_80B548;
    case 0x80B54Au: goto L_80B54A;
    case 0x80B54Du: goto L_80B54D;
    case 0x80B54Fu: goto L_80B54F;
    case 0x80B551u: goto L_80B551;
    case 0x80B554u: goto L_80B554;
    case 0x80B556u: goto L_80B556;
    case 0x80B558u: goto L_80B558;
    case 0x80B559u: goto L_80B559;
    case 0x80B55Au: goto L_80B55A;
    case 0x80B55Cu: goto L_80B55C;
    case 0x80B55Eu: goto L_80B55E;
    case 0x80B560u: goto L_80B560;
    case 0x80B561u: goto L_80B561;
    case 0x80B562u: goto L_80B562;
    case 0x80B564u: goto L_80B564;
    case 0x80B566u: goto L_80B566;
    case 0x80B568u: goto L_80B568;
    case 0x80B56Au: goto L_80B56A;
    case 0x80B56Cu: goto L_80B56C;
    case 0x80B56Fu: goto L_80B56F;
    case 0x80B572u: goto L_80B572;
    case 0x80B575u: goto L_80B575;
    case 0x80B577u: goto L_80B577;
    case 0x80B579u: goto L_80B579;
    case 0x80B57Bu: goto L_80B57B;
    case 0x80B57Du: goto L_80B57D;
    case 0x80B57Fu: goto L_80B57F;
    case 0x80B582u: goto L_80B582;
    case 0x80B584u: goto L_80B584;
    case 0x80B586u: goto L_80B586;
    case 0x80B588u: goto L_80B588;
    case 0x80B58Bu: goto L_80B58B;
    case 0x80B58Du: goto L_80B58D;
    case 0x80B590u: goto L_80B590;
    case 0x80B593u: goto L_80B593;
    case 0x80B595u: goto L_80B595;
    case 0x80B598u: goto L_80B598;
    case 0x80B59Au: goto L_80B59A;
    case 0x80B59Du: goto L_80B59D;
    case 0x80B5A0u: goto L_80B5A0;
    case 0x80B5A1u: goto L_80B5A1;
    case 0x80B5A3u: goto L_80B5A3;
    case 0x80B5A5u: goto L_80B5A5;
    case 0x80B5A7u: goto L_80B5A7;
    case 0x80B5AAu: goto L_80B5AA;
    case 0x80B5ADu: goto L_80B5AD;
    case 0x80B5B0u: goto L_80B5B0;
    case 0x80B5B3u: goto L_80B5B3;
    case 0x80B5B5u: goto L_80B5B5;
    case 0x80B5B8u: goto L_80B5B8;
    case 0x80B5BAu: goto L_80B5BA;
    case 0x80B5BCu: goto L_80B5BC;
    case 0x80B5BEu: goto L_80B5BE;
    case 0x80B5C0u: goto L_80B5C0;
    case 0x80B5C2u: goto L_80B5C2;
    case 0x80B5C5u: goto L_80B5C5;
    case 0x80B5C7u: goto L_80B5C7;
    case 0x80B5C9u: goto L_80B5C9;
    case 0x80B5CBu: goto L_80B5CB;
    case 0x80B5CDu: goto L_80B5CD;
    case 0x80B5CFu: goto L_80B5CF;
    case 0x80B5D1u: goto L_80B5D1;
    case 0x80B5D3u: goto L_80B5D3;
    case 0x80B5D5u: goto L_80B5D5;
    case 0x80B5D7u: goto L_80B5D7;
    case 0x80B5D9u: goto L_80B5D9;
    case 0x80B5DBu: goto L_80B5DB;
    case 0x80B5DDu: goto L_80B5DD;
    case 0x80B5DFu: goto L_80B5DF;
    case 0x80B5E2u: goto L_80B5E2;
    case 0x80B5E5u: goto L_80B5E5;
    case 0x80B5E7u: goto L_80B5E7;
    case 0x80B5E9u: goto L_80B5E9;
    case 0x80B5EBu: goto L_80B5EB;
    case 0x80B5EDu: goto L_80B5ED;
    case 0x80B5EFu: goto L_80B5EF;
    case 0x80B5F1u: goto L_80B5F1;
    case 0x80B5F3u: goto L_80B5F3;
    case 0x80B5F6u: goto L_80B5F6;
    case 0x80B5F9u: goto L_80B5F9;
    case 0x80B5FCu: goto L_80B5FC;
    case 0x80B5FFu: goto L_80B5FF;
    case 0x80B601u: goto L_80B601;
    case 0x80B603u: goto L_80B603;
    case 0x80B605u: goto L_80B605;
    case 0x80B607u: goto L_80B607;
    case 0x80B609u: goto L_80B609;
    case 0x80B60Bu: goto L_80B60B;
    case 0x80B60Du: goto L_80B60D;
    case 0x80B60Fu: goto L_80B60F;
    case 0x80B611u: goto L_80B611;
    case 0x80B613u: goto L_80B613;
    case 0x80B615u: goto L_80B615;
    case 0x80B617u: goto L_80B617;
    case 0x80B619u: goto L_80B619;
    case 0x80B61Bu: goto L_80B61B;
    case 0x80B61Du: goto L_80B61D;
    case 0x80B61Fu: goto L_80B61F;
    case 0x80B621u: goto L_80B621;
    case 0x80B624u: goto L_80B624;
    case 0x80B626u: goto L_80B626;
    case 0x80B629u: goto L_80B629;
    case 0x80B62Cu: goto L_80B62C;
    case 0x80B62Eu: goto L_80B62E;
    case 0x80B631u: goto L_80B631;
    case 0x80B633u: goto L_80B633;
    case 0x80B636u: goto L_80B636;
    case 0x80B639u: goto L_80B639;
    case 0x80B63Bu: goto L_80B63B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B53A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB53Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB53Au,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB53Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B53A LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B53C;
L_80B53C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB53Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB53Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB53Cu, 5u + 1u, 3u, cpu.address("absx", 0x093Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B53C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x93Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B53F;
L_80B53F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB53Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB53Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB53Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B53F STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80B541;
L_80B541:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB541u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB541u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB541u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B541 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B543;
L_80B543:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB543u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB543u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB543u, 5u + 1u, 3u, cpu.address("absx", 0x093Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B543 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x93Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B546;
L_80B546:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB546u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB546u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB546u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B546 STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_80B548;
L_80B548:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB548u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB548u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB548u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B548 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B54A;
L_80B54A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB54Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB54Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB54Au, 5u + 1u, 3u, cpu.address("absx", 0x0906u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B54A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x906u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B54D;
L_80B54D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB54Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB54Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB54Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B54D STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_80B54F;
L_80B54F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB54Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB54Fu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB54Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B54F LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B551;
L_80B551:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB551u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB551u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB551u, 5u + 1u, 3u, cpu.address("absx", 0x0906u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B551 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x906u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B554;
L_80B554:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB554u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB554u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB554u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B554 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80B556;
L_80B556:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB556u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB556u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB556u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B556 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B558;
L_80B558:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB558u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB558u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB558u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B558 DEC
    cpu.decReg('A');
    goto L_80B559;
L_80B559:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB559u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB559u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB559u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B559 DEC
    cpu.decReg('A');
    goto L_80B55A;
L_80B55A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB55Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB55Au,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB55Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B55A CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16));
    goto L_80B55C;
L_80B55C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB55Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB55Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB55Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B55C BEQ -> $80B5A1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B5A1; }
    goto L_80B55E;
L_80B55E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB55Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB55Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB55Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B55E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B560;
L_80B560:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB560u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB560u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB560u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B560 INC
    cpu.inc('A');
    goto L_80B561;
L_80B561:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB561u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB561u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB561u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B561 INC
    cpu.inc('A');
    goto L_80B562;
L_80B562:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB562u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB562u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB562u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B562 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16));
    goto L_80B564;
L_80B564:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB564u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB564u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB564u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B564 BEQ -> $80B5A1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B5A1; }
    goto L_80B566;
L_80B566:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB566u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB566u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB566u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B566 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B568;
L_80B568:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB568u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB568u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB568u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B568 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80B56A;
L_80B56A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB56Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB56Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB56Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B56A BEQ -> $80B577
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B577; }
    goto L_80B56C;
L_80B56C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB56Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB56Cu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB56Cu, 8u, 3u, cpu.address("abs", 0x0926u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B56C INC
    cpu.incMem(hw, cpu.address("abs", 0x926u), cpu.m8?8:16);
    goto L_80B56F;
L_80B56F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB56Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB56Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB56Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B56F LDA
    cpu.setA(0xFFFCu, 16);
    goto L_80B572;
L_80B572:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB572u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB572u,cpu,0x1Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB572u, 8u, 3u, cpu.address("abs", 0x0926u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B572 TRB
    cpu.trb(hw, cpu.address("abs", 0x926u), cpu.m8?8:16);
    goto L_80B575;
L_80B575:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB575u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB575u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB575u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B575 BRA -> $80B5A0
    goto L_80B5A0;
L_80B577:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB577u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB577u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB577u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B577 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x10u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B579;
L_80B579:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB579u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB579u,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB579u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B579 CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0x12u), cpu.x8?8:16));
    goto L_80B57B;
L_80B57B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB57Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Bu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B57B BCS -> $80B57F
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B57F; }
    goto L_80B57D;
L_80B57D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB57Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Du,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B57D LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x12u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B57F;
L_80B57F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB57Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Fu, 6u, 3u, cpu.address("abs", 0xB64Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B57F JSR -> $80B64B stack real
    { cpu.push16Value(hw,0xB581u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB582u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB64Bu), 0x80B57Fu); }
    goto L_80B582;
L_80B582:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB582u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB582u,0x80B582u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB582u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB582u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B582 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B584;
L_80B584:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB584u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB584u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB584u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B584 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x6u), cpu.m8?8:16));
    goto L_80B586;
L_80B586:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB586u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB586u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB586u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B586 BEQ -> $80B5A0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B5A0; }
    goto L_80B588;
L_80B588:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB588u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB588u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB588u, 5u, 3u, cpu.address("abs", 0x0942u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B588 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x942u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B58B;
L_80B58B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB58Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B58B BNE -> $80B595
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B595; }
    goto L_80B58D;
L_80B58D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB58Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B58D LDA
    cpu.setA(0x100u, 16);
    goto L_80B590;
L_80B590:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB590u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB590u,cpu,0x0Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB590u, 8u, 3u, cpu.address("abs", 0x0922u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B590 TSB
    cpu.tsb(hw, cpu.address("abs", 0x922u), cpu.m8?8:16);
    goto L_80B593;
L_80B593:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB593u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB593u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB593u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B593 BRA -> $80B5A0
    goto L_80B5A0;
L_80B595:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB595u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB595u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB595u, 5u, 3u, cpu.address("abs", 0x0944u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B595 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x944u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B598;
L_80B598:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB598u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB598u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB598u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B598 BNE -> $80B5A0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B5A0; }
    goto L_80B59A;
L_80B59A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB59Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB59Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB59Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B59A LDA
    cpu.setA(0x200u, 16);
    goto L_80B59D;
L_80B59D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB59Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB59Du,cpu,0x0Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB59Du, 8u, 3u, cpu.address("abs", 0x0922u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B59D TSB
    cpu.tsb(hw, cpu.address("abs", 0x922u), cpu.m8?8:16);
    goto L_80B5A0;
L_80B5A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B5A0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B5A0u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B5A0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80B5A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5A1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B5A3;
L_80B5A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A3u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5A3 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80B5A5;
L_80B5A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5A5 BNE -> $80B5B3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B5B3; }
    goto L_80B5A7;
L_80B5A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A7u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A7u, 8u, 3u, cpu.address("abs", 0x0926u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5A7 INC
    cpu.incMem(hw, cpu.address("abs", 0x926u), cpu.m8?8:16);
    goto L_80B5AA;
L_80B5AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5AAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5AAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5AA LDA
    cpu.setA(0xFFFCu, 16);
    goto L_80B5AD;
L_80B5AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5ADu,cpu,0x1Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5ADu, 8u, 3u, cpu.address("abs", 0x0926u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5AD TRB
    cpu.trb(hw, cpu.address("abs", 0x926u), cpu.m8?8:16);
    goto L_80B5B0;
L_80B5B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B0u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B0u, 3u, 3u, cpu.address("abs", 0xB63Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5B0 JMP -> $80B63B
    goto L_80B63B;
L_80B5B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B3u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5B3 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x10u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B5B5;
L_80B5B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B5u, 6u, 3u, cpu.address("abs", 0xB64Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B5B5 JSR -> $80B64B stack real
    { cpu.push16Value(hw,0xB5B7u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB5B8u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB64Bu), 0x80B5B5u); }
    goto L_80B5B8;
L_80B5B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5B8u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB5B8u,0x80B5B8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5B8 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80B5BA;
L_80B5BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BAu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5BA STY
    hw.write(cpu.address("dp", 0x14u), cpu.y, cpu.x8?8:16);
    goto L_80B5BC;
L_80B5BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5BC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B5BE;
L_80B5BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5BE STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_80B5C0;
L_80B5C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C0u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5C0 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x12u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B5C2;
L_80B5C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C2u, 6u, 3u, cpu.address("abs", 0xB64Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B5C2 JSR -> $80B64B stack real
    { cpu.push16Value(hw,0xB5C4u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB5C5u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB64Bu), 0x80B5C2u); }
    goto L_80B5C5;
L_80B5C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C5u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB5C5u,0x80B5C5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5C5 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_80B5C7;
L_80B5C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C7u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5C7 STY
    hw.write(cpu.address("dp", 0x16u), cpu.y, cpu.x8?8:16);
    goto L_80B5C9;
L_80B5C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5C9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B5CB;
L_80B5CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5CB STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_80B5CD;
L_80B5CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5CD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B5CF;
L_80B5CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CFu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5CF CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16));
    goto L_80B5D1;
L_80B5D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5D1 BNE -> $80B601
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B601; }
    goto L_80B5D3;
L_80B5D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5D3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B5D5;
L_80B5D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D5u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5D5 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16));
    goto L_80B5D7;
L_80B5D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5D7 BNE -> $80B5E7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B5E7; }
    goto L_80B5D9;
L_80B5D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5D9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B5DB;
L_80B5DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DBu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5DB CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_80B5DD;
L_80B5DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5DD BNE -> $80B5E7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B5E7; }
    goto L_80B5DF;
L_80B5DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5DF LDA
    cpu.setA(0x400u, 16);
    goto L_80B5E2;
L_80B5E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E2u,cpu,0x0Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E2u, 8u, 3u, cpu.address("abs", 0x0922u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5E2 TSB
    cpu.tsb(hw, cpu.address("abs", 0x922u), cpu.m8?8:16);
    goto L_80B5E5;
L_80B5E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E5u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5E5 BRA -> $80B63B
    goto L_80B63B;
L_80B5E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5E7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B5E9;
L_80B5E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E9u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5E9 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_80B5EB;
L_80B5EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EBu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5EB BNE -> $80B601
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B601; }
    goto L_80B5ED;
L_80B5ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5ED LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B5EF;
L_80B5EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EFu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5EF CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16));
    goto L_80B5F1;
L_80B5F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5F1 BNE -> $80B601
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B601; }
    goto L_80B5F3;
L_80B5F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F3u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F3u, 8u, 3u, cpu.address("abs", 0x0926u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5F3 INC
    cpu.incMem(hw, cpu.address("abs", 0x926u), cpu.m8?8:16);
    goto L_80B5F6;
L_80B5F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F6u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F6u, 8u, 3u, cpu.address("abs", 0x0926u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5F6 INC
    cpu.incMem(hw, cpu.address("abs", 0x926u), cpu.m8?8:16);
    goto L_80B5F9;
L_80B5F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5F9 LDA
    cpu.setA(0xFFFCu, 16);
    goto L_80B5FC;
L_80B5FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5FCu,cpu,0x1Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5FCu, 8u, 3u, cpu.address("abs", 0x0926u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5FC TRB
    cpu.trb(hw, cpu.address("abs", 0x926u), cpu.m8?8:16);
    goto L_80B5FF;
L_80B5FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5FFu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5FFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5FF BRA -> $80B63B
    goto L_80B63B;
L_80B601:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB601u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB601u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB601u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B601 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B603;
L_80B603:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB603u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB603u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB603u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B603 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16));
    goto L_80B605;
L_80B605:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB605u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB605u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB605u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B605 BCS -> $80B615
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B615; }
    goto L_80B607;
L_80B607:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB607u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB607u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB607u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B607 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B609;
L_80B609:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB609u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB609u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB609u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B609 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_80B60B;
L_80B60B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB60Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB60Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB60Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B60B BEQ -> $80B63B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B63B; }
    goto L_80B60D;
L_80B60D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB60Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB60Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB60Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B60D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B60F;
L_80B60F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB60Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB60Fu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB60Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B60F CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16));
    goto L_80B611;
L_80B611:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB611u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB611u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB611u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B611 BEQ -> $80B5F3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B5F3; }
    goto L_80B613;
L_80B613:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB613u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB613u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB613u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B613 BRA -> $80B621
    goto L_80B621;
L_80B615:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB615u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB615u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB615u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B615 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B617;
L_80B617:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB617u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB617u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB617u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B617 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16));
    goto L_80B619;
L_80B619:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB619u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB619u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB619u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B619 BEQ -> $80B63B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B63B; }
    goto L_80B61B;
L_80B61B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB61Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB61Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB61Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B61B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B61D;
L_80B61D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB61Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB61Du,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB61Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B61D CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_80B61F;
L_80B61F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB61Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB61Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB61Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B61F BEQ -> $80B5F3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B5F3; }
    goto L_80B621;
L_80B621:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB621u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB621u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB621u, 5u, 3u, cpu.address("abs", 0x0942u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B621 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x942u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B624;
L_80B624:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB624u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB624u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB624u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B624 BNE -> $80B62E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B62E; }
    goto L_80B626;
L_80B626:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB626u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB626u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB626u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B626 LDA
    cpu.setA(0x100u, 16);
    goto L_80B629;
L_80B629:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB629u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB629u,cpu,0x0Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB629u, 8u, 3u, cpu.address("abs", 0x0922u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B629 TSB
    cpu.tsb(hw, cpu.address("abs", 0x922u), cpu.m8?8:16);
    goto L_80B62C;
L_80B62C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB62Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Cu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B62C BRA -> $80B63B
    goto L_80B63B;
L_80B62E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB62Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Eu, 5u, 3u, cpu.address("abs", 0x0944u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B62E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x944u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B631;
L_80B631:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB631u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB631u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB631u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B631 BNE -> $80B63B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B63B; }
    goto L_80B633;
L_80B633:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB633u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB633u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB633u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B633 LDA
    cpu.setA(0x200u, 16);
    goto L_80B636;
L_80B636:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB636u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB636u,cpu,0x0Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB636u, 8u, 3u, cpu.address("abs", 0x0922u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B636 TSB
    cpu.tsb(hw, cpu.address("abs", 0x922u), cpu.m8?8:16);
    goto L_80B639;
L_80B639:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB639u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB639u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB639u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B639 BRA -> $80B63B
    goto L_80B63B;
L_80B63B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB63Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB63Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB63Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B63B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B63Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B63Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80BCC2_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80BCC2u: goto L_80BCC2;
    case 0x80BCC3u: goto L_80BCC3;
    case 0x80BCC4u: goto L_80BCC4;
    case 0x80BCC5u: goto L_80BCC5;
    case 0x80BCC7u: goto L_80BCC7;
    case 0x80BCC9u: goto L_80BCC9;
    case 0x80BCCCu: goto L_80BCCC;
    case 0x80BCCEu: goto L_80BCCE;
    case 0x80BCD2u: goto L_80BCD2;
    case 0x80BCD5u: goto L_80BCD5;
    case 0x80BCD7u: goto L_80BCD7;
    case 0x80BCDAu: goto L_80BCDA;
    case 0x80BCDCu: goto L_80BCDC;
    case 0x80BCE0u: goto L_80BCE0;
    case 0x80BCE2u: goto L_80BCE2;
    case 0x80BCE6u: goto L_80BCE6;
    case 0x80BCE8u: goto L_80BCE8;
    case 0x80BCEAu: goto L_80BCEA;
    case 0x80BCECu: goto L_80BCEC;
    case 0x80BCEEu: goto L_80BCEE;
    case 0x80BCF0u: goto L_80BCF0;
    case 0x80BCF2u: goto L_80BCF2;
    case 0x80BCF4u: goto L_80BCF4;
    case 0x80BCF6u: goto L_80BCF6;
    case 0x80BCF9u: goto L_80BCF9;
    case 0x80BCFAu: goto L_80BCFA;
    case 0x80BCFCu: goto L_80BCFC;
    case 0x80BCFDu: goto L_80BCFD;
    case 0x80BD01u: goto L_80BD01;
    case 0x80BD03u: goto L_80BD03;
    case 0x80BD06u: goto L_80BD06;
    case 0x80BD09u: goto L_80BD09;
    case 0x80BD0Bu: goto L_80BD0B;
    case 0x80BD0Eu: goto L_80BD0E;
    case 0x80BD11u: goto L_80BD11;
    case 0x80BD13u: goto L_80BD13;
    case 0x80BD16u: goto L_80BD16;
    case 0x80BD18u: goto L_80BD18;
    case 0x80BD19u: goto L_80BD19;
    case 0x80BD1Au: goto L_80BD1A;
    case 0x80BD1Cu: goto L_80BD1C;
    case 0x80BD1Eu: goto L_80BD1E;
    case 0x80BD21u: goto L_80BD21;
    case 0x80BD24u: goto L_80BD24;
    case 0x80BD27u: goto L_80BD27;
    case 0x80BD2Au: goto L_80BD2A;
    case 0x80BD2Bu: goto L_80BD2B;
    case 0x80BD2Cu: goto L_80BD2C;
    case 0x80BD2Du: goto L_80BD2D;
    case 0x80BD2Fu: goto L_80BD2F;
    case 0x80BD32u: goto L_80BD32;
    case 0x80BD33u: goto L_80BD33;
    case 0x80BD34u: goto L_80BD34;
    case 0x80BD35u: goto L_80BD35;
    case 0x80BD36u: goto L_80BD36;
    case 0x80BD37u: goto L_80BD37;
    case 0x80BD38u: goto L_80BD38;
    case 0x80BD3Au: goto L_80BD3A;
    case 0x80BD3Bu: goto L_80BD3B;
    case 0x80BD3Eu: goto L_80BD3E;
    case 0x80BD3Fu: goto L_80BD3F;
    case 0x80BD42u: goto L_80BD42;
    case 0x80BD44u: goto L_80BD44;
    case 0x80BD46u: goto L_80BD46;
    case 0x80BD47u: goto L_80BD47;
    case 0x80BD48u: goto L_80BD48;
    case 0x80BD4Bu: goto L_80BD4B;
    case 0x80BD4Du: goto L_80BD4D;
    case 0x80BD4Fu: goto L_80BD4F;
    case 0x80BD52u: goto L_80BD52;
    case 0x80BD53u: goto L_80BD53;
    case 0x80BD55u: goto L_80BD55;
    case 0x80BD58u: goto L_80BD58;
    case 0x80BD59u: goto L_80BD59;
    case 0x80BD5Au: goto L_80BD5A;
    case 0x80BD5Bu: goto L_80BD5B;
    case 0x80BD5Cu: goto L_80BD5C;
    case 0x80BD5Eu: goto L_80BD5E;
    case 0x80BD60u: goto L_80BD60;
    case 0x80BD63u: goto L_80BD63;
    case 0x80BD65u: goto L_80BD65;
    case 0x80BD68u: goto L_80BD68;
    case 0x80BD6Au: goto L_80BD6A;
    case 0x80BD6Du: goto L_80BD6D;
    case 0x80BD6Fu: goto L_80BD6F;
    case 0x80BD72u: goto L_80BD72;
    case 0x80BD75u: goto L_80BD75;
    case 0x80BD76u: goto L_80BD76;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80BCC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC2u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC2u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BCC2 PHB
    cpu.push("PHB", hw);
    goto L_80BCC3;
L_80BCC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC3u,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC3u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BCC3 PHK
    cpu.push("PHK", hw);
    goto L_80BCC4;
L_80BCC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC4u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC4u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BCC4 PLB
    cpu.pop("PLB", hw);
    goto L_80BCC5;
L_80BCC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC5u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCC5 STZ
    hw.write(cpu.address("dp", 0x61u), 0, cpu.m8?8:16);
    goto L_80BCC7;
L_80BCC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC7u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCC7 STZ
    hw.write(cpu.address("dp", 0x63u), 0, cpu.m8?8:16);
    goto L_80BCC9;
L_80BCC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCC9u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC9u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC9u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCC9 STZ
    hw.write(cpu.address("abs", 0x958u), 0, cpu.m8?8:16);
    goto L_80BCCC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC9u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC9u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCC9 STZ
    hw.write(cpu.address("abs", 0x958u), 0, cpu.m8?8:16);
    goto L_80BCCC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC9u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC9u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCC9 STZ
    hw.write(cpu.address("abs", 0x958u), 0, cpu.m8?8:16);
    goto L_80BCCC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBCC9u,0x80BCC9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BCCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCCCu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCCCu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCCCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCCC LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BCCE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCCCu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCCCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCCC LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BCCE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCCCu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCCCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCCC LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BCCE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBCCCu,0x80BCCCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BCCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCCEu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCCEu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCCEu, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCCE LDA
    cpu.loadA(hw.readW(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BCD2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCCEu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCCEu, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCCE LDA
    cpu.loadA(hw.readW(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BCD2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCCEu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCCEu, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCCE LDA
    cpu.loadA(hw.readW(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BCD2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBCCEu,0x80BCCEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BCD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCD2u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCD2u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCD2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCD2 CMP
    cpu.compareA(0xFFFFu);
    goto L_80BCD5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCD2u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCD2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCD2 CMP
    cpu.compareA(0xFFFFu);
    goto L_80BCD5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCD2u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCD2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCD2 CMP
    cpu.compareA(0xFFFFu);
    goto L_80BCD5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBCD2u,0x80BCD2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BCD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCD5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCD5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCD5 BNE -> $80BCDA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BCDA; }
    goto L_80BCD7;
L_80BCD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCD7u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCD7u, 3u, 3u, cpu.address("abs", 0xBD6Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCD7 JMP -> $80BD6F
    goto L_80BD6F;
L_80BCDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCDAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCDAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCDA STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_80BCDC;
L_80BCDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCDCu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCDCu, 6u, 4u, ((0x7E2442u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCDC LDA
    cpu.loadA(hw.readW(((0x7E2442u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BCE0;
L_80BCE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCE0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCE0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCE0 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80BCE2;
L_80BCE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCE2u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCE2u, 6u, 4u, ((0x7E2444u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCE2 LDA
    cpu.loadA(hw.readW(((0x7E2444u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BCE6;
L_80BCE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCE6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCE6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCE6 STA
    hw.write(cpu.address("dp", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_80BCE8;
L_80BCE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCE8u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCE8u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCE8 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80BCEA;
L_80BCEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCEAu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCEAu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCEA INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80BCEC;
L_80BCEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCECu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCECu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCEC INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80BCEE;
L_80BCEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCEEu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCEEu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCEE INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80BCF0;
L_80BCF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF0u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF0u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCF0 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80BCF2;
L_80BCF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF2u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF2u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCF2 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80BCF4;
L_80BCF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF4u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCF4 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x10u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BCF6;
L_80BCF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF6u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF6u, 5u + 1u, 3u, cpu.address("absy", 0xBDEBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCF6 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xBDEBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BCF9;
L_80BCF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF9u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCF9 CLC
    cpu.setFlag('C', false);
    goto L_80BCFA;
L_80BCFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCFAu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCFAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCFA ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16));
    goto L_80BCFC;
L_80BCFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCFCu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCFCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCFC TAX
    cpu.transfer("TAX");
    goto L_80BCFD;
L_80BCFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCFDu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCFDu, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BCFD LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BD01;
L_80BD01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD01u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD01u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD01 BNE -> $80BD6F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BD6F; }
    goto L_80BD03;
L_80BD03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD03u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD03u, 5u, 3u, cpu.address("abs", 0x0918u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD03 STX
    hw.write(cpu.address("abs", 0x918u), cpu.x, cpu.x8?8:16);
    goto L_80BD06;
L_80BD06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD06u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD06u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD06 LDX
    cpu.setX(0x6u, 16);
    goto L_80BD09;
L_80BD09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD09u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD09u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD09 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x10u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BD0B;
L_80BD0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD0Bu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD0Bu, 5u + 1u, 3u, cpu.address("absy", 0xBDF3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD0B LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xBDF3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BD0E;
L_80BD0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD0Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD0Eu, 5u, 3u, cpu.address("abs", 0x0920u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD0E STA
    hw.write(cpu.address("abs", 0x920u), cpu.a, cpu.m8?8:16);
    goto L_80BD11;
L_80BD11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD11u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD11u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD11u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD11 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BD13;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD11u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD11u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD11 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BD13;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD11u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD11u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD11 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BD13;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBD11u,0x80BD11u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BD13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD13u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD13u,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD13u, 5u + 1u, 3u, cpu.address("absx", 0x0906u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD13 CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0x906u), cpu.m8?8:16));
    goto L_80BD16;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD13u,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD13u, 5u + 1u, 3u, cpu.address("absx", 0x0906u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD13 CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0x906u), cpu.m8?8:16));
    goto L_80BD16;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD13u,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD13u, 5u + 1u, 3u, cpu.address("absx", 0x0906u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD13 CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0x906u), cpu.m8?8:16));
    goto L_80BD16;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBD13u,0x80BD13u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BD16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD16u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD16u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD16 BEQ -> $80BD1E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BD1E; }
    goto L_80BD18;
L_80BD18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD18u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD18u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD18u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD18 DEX
    cpu.decReg('X');
    goto L_80BD19;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD18u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD18u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD18 DEX
    cpu.decReg('X');
    goto L_80BD19;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD18u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD18u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD18 DEX
    cpu.decReg('X');
    goto L_80BD19;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBD18u,0x80BD18u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BD19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD19u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD19u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD19u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD19 DEX
    cpu.decReg('X');
    goto L_80BD1A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD19u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD19u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD19 DEX
    cpu.decReg('X');
    goto L_80BD1A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD19u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD19u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD19 DEX
    cpu.decReg('X');
    goto L_80BD1A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBD19u,0x80BD19u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BD1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD1Au))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD1Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD1Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD1A BPL -> $80BD11
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BD11; }
    goto L_80BD1C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD1Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD1Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD1A BPL -> $80BD11
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BD11; }
    goto L_80BD1C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD1Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD1Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD1A BPL -> $80BD11
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BD11; }
    goto L_80BD1C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBD1Au,0x80BD1Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BD1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD1Cu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD1Cu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD1Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD1C BRA -> $80BCC9
    goto L_80BCC9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD1Cu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD1Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD1C BRA -> $80BCC9
    goto L_80BCC9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD1Cu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD1Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD1C BRA -> $80BCC9
    goto L_80BCC9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBD1Cu,0x80BD1Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BD1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD1Eu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD1Eu, 5u, 3u, cpu.address("abs", 0x091Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD1E STX
    hw.write(cpu.address("abs", 0x91Eu), cpu.x, cpu.x8?8:16);
    goto L_80BD21;
L_80BD21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD21u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD21u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD21 LDA
    cpu.setA(0x3u, 16);
    goto L_80BD24;
L_80BD24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD24u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD24u, 5u, 3u, cpu.address("abs", 0x0926u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD24 STA
    hw.write(cpu.address("abs", 0x926u), cpu.a, cpu.m8?8:16);
    goto L_80BD27;
L_80BD27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD27u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD27u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD27u, 5u, 3u, cpu.address("abs", 0x0926u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD27 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x926u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BD2A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD27u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD27u, 5u, 3u, cpu.address("abs", 0x0926u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD27 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x926u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BD2A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD27u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD27u, 5u, 3u, cpu.address("abs", 0x0926u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD27 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x926u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BD2A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBD27u,0x80BD27u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BD2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD2Au))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD2Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD2Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD2A ASL
    cpu.aslA();
    goto L_80BD2B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD2Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD2Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD2A ASL
    cpu.aslA();
    goto L_80BD2B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD2Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD2Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD2A ASL
    cpu.aslA();
    goto L_80BD2B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBD2Au,0x80BD2Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BD2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD2Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD2Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD2B ASL
    cpu.aslA();
    goto L_80BD2C;
L_80BD2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD2Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD2Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD2C ASL
    cpu.aslA();
    goto L_80BD2D;
L_80BD2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD2Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD2Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD2D STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_80BD2F;
L_80BD2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD2Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD2Fu, 5u, 3u, cpu.address("abs", 0x0904u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD2F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x904u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BD32;
L_80BD32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD32u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD32u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD32 ASL
    cpu.aslA();
    goto L_80BD33;
L_80BD33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD33u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD33u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD33 ASL
    cpu.aslA();
    goto L_80BD34;
L_80BD34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD34u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD34u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD34 ASL
    cpu.aslA();
    goto L_80BD35;
L_80BD35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD35u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD35u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD35 ASL
    cpu.aslA();
    goto L_80BD36;
L_80BD36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD36u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD36u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD36 ASL
    cpu.aslA();
    goto L_80BD37;
L_80BD37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD37u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD37u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD37 CLC
    cpu.setFlag('C', false);
    goto L_80BD38;
L_80BD38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD38u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD38u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD38 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16));
    goto L_80BD3A;
L_80BD3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD3Au,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD3Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD3A CLC
    cpu.setFlag('C', false);
    goto L_80BD3B;
L_80BD3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD3Bu,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD3Bu, 5u, 3u, cpu.address("abs", 0x091Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD3B ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x91Eu), cpu.m8?8:16));
    goto L_80BD3E;
L_80BD3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD3Eu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD3Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD3E TAX
    cpu.transfer("TAX");
    goto L_80BD3F;
L_80BD3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD3Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD3Fu, 5u + 1u, 3u, cpu.address("absx", 0xE94Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD3F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0xE94Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BD42;
L_80BD42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD42u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD42u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD42 BMI -> $80BD65
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BD65; }
    goto L_80BD44;
L_80BD44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD44u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD44u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD44 BEQ -> $80BD4F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BD4F; }
    goto L_80BD46;
L_80BD46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD46u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD46u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD46 DEC
    cpu.decReg('A');
    goto L_80BD47;
L_80BD47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD47u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD47u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD47 TAX
    cpu.transfer("TAX");
    goto L_80BD48;
L_80BD48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD48u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD48u, 5u + 1u, 3u, cpu.address("absx", 0x0906u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD48 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x906u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BD4B;
L_80BD4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD4Bu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD4Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD4B CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16));
    goto L_80BD4D;
L_80BD4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD4Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD4Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD4D BNE -> $80BD65
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BD65; }
    goto L_80BD4F;
L_80BD4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD4Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD4Fu, 5u, 3u, cpu.address("abs", 0x0926u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD4F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x926u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BD52;
L_80BD52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD52u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD52u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD52 ASL
    cpu.aslA();
    goto L_80BD53;
L_80BD53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD53u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD53u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD53 STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_80BD55;
L_80BD55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD55u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD55u, 5u, 3u, cpu.address("abs", 0x0904u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD55 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x904u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BD58;
L_80BD58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD58u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD58u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD58 ASL
    cpu.aslA();
    goto L_80BD59;
L_80BD59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD59u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD59u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD59 ASL
    cpu.aslA();
    goto L_80BD5A;
L_80BD5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD5Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD5Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD5A ASL
    cpu.aslA();
    goto L_80BD5B;
L_80BD5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD5Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD5Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD5B CLC
    cpu.setFlag('C', false);
    goto L_80BD5C;
L_80BD5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD5Cu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD5Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD5C ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16));
    goto L_80BD5E;
L_80BD5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD5Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD5Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD5E STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_80BD60;
L_80BD60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD60u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD60u, 6u, 3u, cpu.address("abs", 0xBECBu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BD60 JSR -> $80BECB stack real
    { cpu.push16Value(hw,0xBD62u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBD63u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBECBu), 0x80BD60u); }
    goto L_80BD63;
L_80BD63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD63u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD63u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD63u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD63 BCC -> $80BD75
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80BD75; }
    goto L_80BD65;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD63u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD63u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD63 BCC -> $80BD75
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80BD75; }
    goto L_80BD65;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBD63u,0x80BD63u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BD65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD65u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD65u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD65u, 8u, 3u, cpu.address("abs", 0x0926u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD65 DEC
    cpu.decMem(hw, cpu.address("abs", 0x926u), cpu.m8?8:16);
    goto L_80BD68;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD65u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD65u, 8u, 3u, cpu.address("abs", 0x0926u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD65 DEC
    cpu.decMem(hw, cpu.address("abs", 0x926u), cpu.m8?8:16);
    goto L_80BD68;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD65u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD65u, 8u, 3u, cpu.address("abs", 0x0926u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD65 DEC
    cpu.decMem(hw, cpu.address("abs", 0x926u), cpu.m8?8:16);
    goto L_80BD68;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBD65u,0x80BD65u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BD68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD68u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD68u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD68u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD68 BPL -> $80BD27
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BD27; }
    goto L_80BD6A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD68u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD68u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD68 BPL -> $80BD27
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BD27; }
    goto L_80BD6A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD68u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD68u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD68 BPL -> $80BD27
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BD27; }
    goto L_80BD6A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBD68u,0x80BD68u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BD6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD6Au))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD6Au,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD6Au, 5u, 3u, cpu.address("abs", 0x091Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD6A LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x91Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BD6D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD6Au,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD6Au, 5u, 3u, cpu.address("abs", 0x091Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD6A LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x91Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BD6D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD6Au,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD6Au, 5u, 3u, cpu.address("abs", 0x091Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD6A LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x91Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BD6D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBD6Au,0x80BD6Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BD6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD6Du))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD6Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD6Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD6D BRA -> $80BD18
    goto L_80BD18;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD6Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD6Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD6D BRA -> $80BD18
    goto L_80BD18;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD6Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD6Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD6D BRA -> $80BD18
    goto L_80BD18;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBD6Du,0x80BD6Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BD6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD6Fu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD6Fu, 8u, 3u, cpu.address("abs", 0x0958u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD6F INC
    cpu.incMem(hw, cpu.address("abs", 0x958u), cpu.m8?8:16);
    goto L_80BD72;
L_80BD72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD72u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD72u, 5u, 3u, cpu.address("abs", 0x0926u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD72 STZ
    hw.write(cpu.address("abs", 0x926u), 0, cpu.m8?8:16);
    goto L_80BD75;
L_80BD75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD75u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD75u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD75u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BD75 PLB
    cpu.pop("PLB", hw);
    goto L_80BD76;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD75u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD75u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BD75 PLB
    cpu.pop("PLB", hw);
    goto L_80BD76;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD75u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD75u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BD75 PLB
    cpu.pop("PLB", hw);
    goto L_80BD76;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBD75u,0x80BD75u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BD76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD76u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD76u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD76u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BD76 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80BD76u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80BD76u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD76u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD76u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BD76 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80BD76u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80BD76u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD76u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD76u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BD76 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80BD76u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80BD76u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBD76u,0x80BD76u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80D790_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80D790u: goto L_80D790;
    case 0x80D794u: goto L_80D794;
    case 0x80D796u: goto L_80D796;
    case 0x80D799u: goto L_80D799;
    case 0x80D79Bu: goto L_80D79B;
    case 0x80D79Eu: goto L_80D79E;
    case 0x80D7A0u: goto L_80D7A0;
    case 0x80D7A4u: goto L_80D7A4;
    case 0x80D7A6u: goto L_80D7A6;
    case 0x80D7A9u: goto L_80D7A9;
    case 0x80D7ABu: goto L_80D7AB;
    case 0x80D7AEu: goto L_80D7AE;
    case 0x80D7B0u: goto L_80D7B0;
    case 0x80D7B2u: goto L_80D7B2;
    case 0x80D7B4u: goto L_80D7B4;
    case 0x80D7B5u: goto L_80D7B5;
    case 0x80D7B6u: goto L_80D7B6;
    case 0x80D7B7u: goto L_80D7B7;
    case 0x80D7B8u: goto L_80D7B8;
    case 0x80D7B9u: goto L_80D7B9;
    case 0x80D7BAu: goto L_80D7BA;
    case 0x80D7BCu: goto L_80D7BC;
    case 0x80D7C0u: goto L_80D7C0;
    case 0x80D7C2u: goto L_80D7C2;
    case 0x80D7C6u: goto L_80D7C6;
    case 0x80D7C9u: goto L_80D7C9;
    case 0x80D7CDu: goto L_80D7CD;
    case 0x80D7CFu: goto L_80D7CF;
    case 0x80D7D1u: goto L_80D7D1;
    case 0x80D7D3u: goto L_80D7D3;
    case 0x80D7D5u: goto L_80D7D5;
    case 0x80D7D7u: goto L_80D7D7;
    case 0x80D7D9u: goto L_80D7D9;
    case 0x80D7DBu: goto L_80D7DB;
    case 0x80D7DFu: goto L_80D7DF;
    case 0x80D7E1u: goto L_80D7E1;
    case 0x80D7E4u: goto L_80D7E4;
    case 0x80D7E6u: goto L_80D7E6;
    case 0x80D7E8u: goto L_80D7E8;
    case 0x80D7ECu: goto L_80D7EC;
    case 0x80D7EEu: goto L_80D7EE;
    case 0x80D7EFu: goto L_80D7EF;
    case 0x80D7F0u: goto L_80D7F0;
    case 0x80D7F3u: goto L_80D7F3;
    case 0x80D7F5u: goto L_80D7F5;
    case 0x80D7F9u: goto L_80D7F9;
    case 0x80D7FBu: goto L_80D7FB;
    case 0x80D7FFu: goto L_80D7FF;
    case 0x80D802u: goto L_80D802;
    case 0x80D806u: goto L_80D806;
    case 0x80D808u: goto L_80D808;
    case 0x80D80Au: goto L_80D80A;
    case 0x80D80Cu: goto L_80D80C;
    case 0x80D80Eu: goto L_80D80E;
    case 0x80D810u: goto L_80D810;
    case 0x80D812u: goto L_80D812;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80D790:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD790u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD790u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD790u, 6u, 4u, ((0x7E1FFEu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D790 LDA
    cpu.loadA(hw.readW(((0x7E1FFEu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D794;
L_80D794:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD794u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD794u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD794u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D794 BEQ -> $80D7B4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D7B4; }
    goto L_80D796;
L_80D796:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD796u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD796u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD796u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D796 CMP
    cpu.compareA(0xFFFFu);
    goto L_80D799;
L_80D799:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD799u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD799u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD799u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D799 BEQ -> $80D7B4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D7B4; }
    goto L_80D79B;
L_80D79B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD79Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD79Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD79Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D79B AND
    cpu.logicAnd(0x300u);
    goto L_80D79E;
L_80D79E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD79Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD79Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD79Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D79E STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80D7A0;
L_80D7A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A0u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A0u, 6u, 4u, ((0x7E1FFCu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7A0 LDA
    cpu.loadA(hw.readW(((0x7E1FFCu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D7A4;
L_80D7A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7A4 BEQ -> $80D7D9
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D7D9; }
    goto L_80D7A6;
L_80D7A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7A6 CMP
    cpu.compareA(0xFFFFu);
    goto L_80D7A9;
L_80D7A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7A9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7A9 BEQ -> $80D7D9
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D7D9; }
    goto L_80D7AB;
L_80D7AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7ABu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7ABu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7AB AND
    cpu.logicAnd(0x300u);
    goto L_80D7AE;
L_80D7AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7AEu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7AEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7AE CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_80D7B0;
L_80D7B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7B0 BNE -> $80D7D9
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D7D9; }
    goto L_80D7B2;
L_80D7B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B2u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7B2 BRA -> $80D7B5
    goto L_80D7B5;
L_80D7B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B4u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D7B4 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80D7B4u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80D7B4u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80D7B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B5u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7B5 TXA
    cpu.transfer("TXA");
    goto L_80D7B6;
L_80D7B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B6u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7B6 DEC
    cpu.decReg('A');
    goto L_80D7B7;
L_80D7B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B7u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7B7 DEC
    cpu.decReg('A');
    goto L_80D7B8;
L_80D7B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B8u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7B8 DEC
    cpu.decReg('A');
    goto L_80D7B9;
L_80D7B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B9u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7B9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7B9 DEC
    cpu.decReg('A');
    goto L_80D7BA;
L_80D7BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7BAu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7BAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7BA LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D7BC;
L_80D7BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7BCu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7BCu, 6u, 4u, ((0x7E2444u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7BC STA
    hw.write(((0x7E2444u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D7C0;
L_80D7C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7C0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D7C2;
L_80D7C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C2u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C2u, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7C2 STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D7C6;
L_80D7C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7C6 LDA
    cpu.setA(0x0u, 16);
    goto L_80D7C9;
L_80D7C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C9u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C9u, 6u, 4u, ((0x7E2442u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7C9 STA
    hw.write(((0x7E2442u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D7CD;
L_80D7CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CDu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CDu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7CD INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D7CF;
L_80D7CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CFu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CFu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7CF INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D7D1;
L_80D7D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D1u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D1u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7D1 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D7D3;
L_80D7D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D3u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D3u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7D3 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D7D5;
L_80D7D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D5u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D5u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7D5 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D7D7;
L_80D7D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D7u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D7u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7D7 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D7D9;
L_80D7D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D9u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7D9 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x65u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D7DB;
L_80D7DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7DBu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7DBu, 6u, 4u, ((0x7E1FE8u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7DB LDA
    cpu.loadA(hw.readW(((0x7E1FE8u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D7DF;
L_80D7DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7DFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7DFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7DF BEQ -> $80D7B4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D7B4; }
    goto L_80D7E1;
L_80D7E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E1u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7E1 AND
    cpu.logicAnd(0x300u);
    goto L_80D7E4;
L_80D7E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E4u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7E4 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_80D7E6;
L_80D7E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7E6 BNE -> $80D7B4
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D7B4; }
    goto L_80D7E8;
L_80D7E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E8u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E8u, 6u, 4u, ((0x7E1FD6u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7E8 LDA
    cpu.loadA(hw.readW(((0x7E1FD6u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D7EC;
L_80D7EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7ECu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7ECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7EC BNE -> $80D7B4
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D7B4; }
    goto L_80D7EE;
L_80D7EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7EEu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7EEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7EE TXA
    cpu.transfer("TXA");
    goto L_80D7EF;
L_80D7EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7EFu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7EFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7EF SEC
    cpu.setFlag('C', true);
    goto L_80D7F0;
L_80D7F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F0u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7F0 SBC
    cpu.sbc(0x18u);
    goto L_80D7F3;
L_80D7F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F3u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7F3 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D7F5;
L_80D7F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F5u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F5u, 6u, 4u, ((0x7E2444u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7F5 STA
    hw.write(((0x7E2444u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D7F9;
L_80D7F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7F9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7F9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D7FB;
L_80D7FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7FBu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7FBu, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7FB STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D7FF;
L_80D7FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7FFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7FFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D7FF LDA
    cpu.setA(0x4u, 16);
    goto L_80D802;
L_80D802:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD802u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD802u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD802u, 6u, 4u, ((0x7E2442u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D802 STA
    hw.write(((0x7E2442u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D806;
L_80D806:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD806u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD806u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD806u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D806 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D808;
L_80D808:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD808u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD808u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD808u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D808 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D80A;
L_80D80A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD80Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD80Au,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD80Au, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D80A INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D80C;
L_80D80C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD80Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD80Cu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD80Cu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D80C INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D80E;
L_80D80E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD80Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD80Eu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD80Eu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D80E INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D810;
L_80D810:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD810u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD810u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD810u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D810 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D812;
L_80D812:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD812u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD812u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD812u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D812 BRA -> $80D7B4
    goto L_80D7B4;
}

void sub_829000_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829000u: goto L_829000;
    case 0x829002u: goto L_829002;
    case 0x829005u: goto L_829005;
    case 0x829008u: goto L_829008;
    case 0x82900Au: goto L_82900A;
    case 0x82900Du: goto L_82900D;
    case 0x82900Fu: goto L_82900F;
    case 0x829012u: goto L_829012;
    case 0x829014u: goto L_829014;
    case 0x829017u: goto L_829017;
    case 0x82901Au: goto L_82901A;
    case 0x82901Du: goto L_82901D;
    case 0x82901Fu: goto L_82901F;
    case 0x829022u: goto L_829022;
    case 0x829025u: goto L_829025;
    case 0x829028u: goto L_829028;
    case 0x82902Au: goto L_82902A;
    case 0x82902Du: goto L_82902D;
    case 0x829030u: goto L_829030;
    case 0x829033u: goto L_829033;
    case 0x829035u: goto L_829035;
    case 0x829038u: goto L_829038;
    case 0x82903Au: goto L_82903A;
    case 0x82903Du: goto L_82903D;
    case 0x82903Fu: goto L_82903F;
    case 0x829042u: goto L_829042;
    case 0x829045u: goto L_829045;
    case 0x829048u: goto L_829048;
    case 0x82904Au: goto L_82904A;
    case 0x82904Du: goto L_82904D;
    case 0x829050u: goto L_829050;
    case 0x829053u: goto L_829053;
    case 0x829055u: goto L_829055;
    case 0x829058u: goto L_829058;
    case 0x82905Au: goto L_82905A;
    case 0x82905Du: goto L_82905D;
    case 0x82905Fu: goto L_82905F;
    case 0x829062u: goto L_829062;
    case 0x829065u: goto L_829065;
    case 0x829069u: goto L_829069;
    case 0x82906Du: goto L_82906D;
    case 0x82906Fu: goto L_82906F;
    case 0x829071u: goto L_829071;
    case 0x829072u: goto L_829072;
    case 0x829075u: goto L_829075;
    case 0x829078u: goto L_829078;
    case 0x82907Bu: goto L_82907B;
    case 0x82907Fu: goto L_82907F;
    case 0x829081u: goto L_829081;
    case 0x829083u: goto L_829083;
    case 0x829084u: goto L_829084;
    case 0x829087u: goto L_829087;
    case 0x82908Au: goto L_82908A;
    case 0x82908Du: goto L_82908D;
    case 0x829091u: goto L_829091;
    case 0x829093u: goto L_829093;
    case 0x829095u: goto L_829095;
    case 0x829096u: goto L_829096;
    case 0x829099u: goto L_829099;
    case 0x82909Cu: goto L_82909C;
    case 0x82909Fu: goto L_82909F;
    case 0x8290A3u: goto L_8290A3;
    case 0x8290A6u: goto L_8290A6;
    case 0x8290A9u: goto L_8290A9;
    case 0x8290ACu: goto L_8290AC;
    case 0x8290AEu: goto L_8290AE;
    case 0x8290B1u: goto L_8290B1;
    case 0x8290B4u: goto L_8290B4;
    case 0x8290B6u: goto L_8290B6;
    case 0x8290B9u: goto L_8290B9;
    case 0x8290BCu: goto L_8290BC;
    case 0x8290BEu: goto L_8290BE;
    case 0x8290C0u: goto L_8290C0;
    case 0x8290C3u: goto L_8290C3;
    case 0x8290C6u: goto L_8290C6;
    case 0x8290C8u: goto L_8290C8;
    case 0x8290CBu: goto L_8290CB;
    case 0x8290CEu: goto L_8290CE;
    case 0x8290D0u: goto L_8290D0;
    case 0x8290D2u: goto L_8290D2;
    case 0x8290D4u: goto L_8290D4;
    case 0x8290D6u: goto L_8290D6;
    case 0x8290D8u: goto L_8290D8;
    case 0x8290D9u: goto L_8290D9;
    case 0x8290DBu: goto L_8290DB;
    case 0x8290DFu: goto L_8290DF;
    case 0x8290E1u: goto L_8290E1;
    case 0x8290E2u: goto L_8290E2;
    case 0x8290E4u: goto L_8290E4;
    case 0x8290E8u: goto L_8290E8;
    case 0x8290EAu: goto L_8290EA;
    case 0x8290ECu: goto L_8290EC;
    case 0x8290F0u: goto L_8290F0;
    case 0x8290F4u: goto L_8290F4;
    case 0x8290F6u: goto L_8290F6;
    case 0x8290F8u: goto L_8290F8;
    case 0x8290FCu: goto L_8290FC;
    case 0x829100u: goto L_829100;
    case 0x829102u: goto L_829102;
    case 0x829104u: goto L_829104;
    case 0x829106u: goto L_829106;
    case 0x829108u: goto L_829108;
    case 0x82910Bu: goto L_82910B;
    case 0x82910Du: goto L_82910D;
    case 0x82910Fu: goto L_82910F;
    case 0x829111u: goto L_829111;
    case 0x829115u: goto L_829115;
    case 0x829119u: goto L_829119;
    case 0x82911Bu: goto L_82911B;
    case 0x82911Du: goto L_82911D;
    case 0x829121u: goto L_829121;
    case 0x829125u: goto L_829125;
    case 0x829127u: goto L_829127;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829000:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9000u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9000u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9000u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829000 SEP
    cpu.sep(0x20u);
    goto L_829002;
L_829002:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9002u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9002u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9002u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829002 LDX
    cpu.setX(0x2000u, 16);
    goto L_829005;
L_829005:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9005u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9005u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9005u, 5u, 3u, cpu.address("abs", 0x2181u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829005 STX
    hw.write(cpu.address("abs", 0x2181u), cpu.x, cpu.x8?8:16);
    goto L_829008;
L_829008:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9008u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9008u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9008u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829008 LDA
    cpu.setA(0x0u, 8);
    goto L_82900A;
L_82900A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x900Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x900Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x900Au, 4u, 3u, cpu.address("abs", 0x2183u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82900A STA
    hw.write(cpu.address("abs", 0x2183u), cpu.a, cpu.m8?8:16);
    goto L_82900D;
L_82900D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x900Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x900Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x900Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82900D LDA
    cpu.setA(0x8u, 8);
    goto L_82900F;
L_82900F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x900Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x900Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x900Fu, 4u, 3u, cpu.address("abs", 0x4370u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82900F STA
    hw.write(cpu.address("abs", 0x4370u), cpu.a, cpu.m8?8:16);
    goto L_829012;
L_829012:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9012u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9012u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9012u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829012 LDA
    cpu.setA(0x80u, 8);
    goto L_829014;
L_829014:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9014u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9014u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9014u, 4u, 3u, cpu.address("abs", 0x4371u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829014 STA
    hw.write(cpu.address("abs", 0x4371u), cpu.a, cpu.m8?8:16);
    goto L_829017;
L_829017:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9017u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9017u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9017u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829017 LDX
    cpu.setX(0x8D46u, 16);
    goto L_82901A;
L_82901A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x901Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x901Au,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x901Au, 5u, 3u, cpu.address("abs", 0x4372u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82901A STX
    hw.write(cpu.address("abs", 0x4372u), cpu.x, cpu.x8?8:16);
    goto L_82901D;
L_82901D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x901Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x901Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x901Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82901D LDA
    cpu.setA(0x80u, 8);
    goto L_82901F;
L_82901F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x901Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x901Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x901Fu, 4u, 3u, cpu.address("abs", 0x4374u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82901F STA
    hw.write(cpu.address("abs", 0x4374u), cpu.a, cpu.m8?8:16);
    goto L_829022;
L_829022:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9022u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9022u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9022u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829022 LDX
    cpu.setX(0x800u, 16);
    goto L_829025;
L_829025:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9025u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9025u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9025u, 5u, 3u, cpu.address("abs", 0x4375u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829025 STX
    hw.write(cpu.address("abs", 0x4375u), cpu.x, cpu.x8?8:16);
    goto L_829028;
L_829028:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9028u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9028u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9028u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829028 LDA
    cpu.setA(0x80u, 8);
    goto L_82902A;
L_82902A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x902Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x902Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x902Au, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82902A STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_82902D;
L_82902D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x902Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x902Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x902Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82902D LDX
    cpu.setX(0x3000u, 16);
    goto L_829030;
L_829030:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9030u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9030u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9030u, 5u, 3u, cpu.address("abs", 0x2181u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829030 STX
    hw.write(cpu.address("abs", 0x2181u), cpu.x, cpu.x8?8:16);
    goto L_829033;
L_829033:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9033u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9033u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9033u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829033 LDA
    cpu.setA(0x0u, 8);
    goto L_829035;
L_829035:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9035u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9035u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9035u, 4u, 3u, cpu.address("abs", 0x2183u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829035 STA
    hw.write(cpu.address("abs", 0x2183u), cpu.a, cpu.m8?8:16);
    goto L_829038;
L_829038:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9038u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9038u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9038u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829038 LDA
    cpu.setA(0x8u, 8);
    goto L_82903A;
L_82903A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x903Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x903Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x903Au, 4u, 3u, cpu.address("abs", 0x4370u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82903A STA
    hw.write(cpu.address("abs", 0x4370u), cpu.a, cpu.m8?8:16);
    goto L_82903D;
L_82903D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x903Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x903Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x903Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82903D LDA
    cpu.setA(0x80u, 8);
    goto L_82903F;
L_82903F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x903Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x903Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x903Fu, 4u, 3u, cpu.address("abs", 0x4371u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82903F STA
    hw.write(cpu.address("abs", 0x4371u), cpu.a, cpu.m8?8:16);
    goto L_829042;
L_829042:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9042u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9042u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9042u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829042 LDX
    cpu.setX(0x8D46u, 16);
    goto L_829045;
L_829045:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9045u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9045u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9045u, 5u, 3u, cpu.address("abs", 0x4372u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829045 STX
    hw.write(cpu.address("abs", 0x4372u), cpu.x, cpu.x8?8:16);
    goto L_829048;
L_829048:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9048u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9048u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9048u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829048 LDA
    cpu.setA(0x80u, 8);
    goto L_82904A;
L_82904A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x904Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x904Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x904Au, 4u, 3u, cpu.address("abs", 0x4374u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82904A STA
    hw.write(cpu.address("abs", 0x4374u), cpu.a, cpu.m8?8:16);
    goto L_82904D;
L_82904D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x904Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x904Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x904Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82904D LDX
    cpu.setX(0x800u, 16);
    goto L_829050;
L_829050:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9050u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9050u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9050u, 5u, 3u, cpu.address("abs", 0x4375u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829050 STX
    hw.write(cpu.address("abs", 0x4375u), cpu.x, cpu.x8?8:16);
    goto L_829053;
L_829053:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9053u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9053u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9053u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829053 LDA
    cpu.setA(0x80u, 8);
    goto L_829055;
L_829055:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9055u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9055u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9055u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829055 STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_829058;
L_829058:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9058u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9058u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9058u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829058 REP
    cpu.rep(0x20u);
    goto L_82905A;
L_82905A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x905Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x905Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x905Au, 5u, 3u, cpu.address("abs", 0x0193u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82905A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x193u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82905D;
L_82905D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x905Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x905Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x905Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82905D BEQ -> $829062
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_829062; }
    goto L_82905F;
L_82905F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x905Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x905Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x905Fu, 6u, 3u, cpu.address("abs", 0xC0E7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82905F JSR -> $82C0E7 stack real
    { cpu.push16Value(hw,0x9061u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9062u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC0E7u), 0x82905Fu); }
    goto L_829062;
L_829062:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9062u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9062u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9062u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829062 LDA
    cpu.setA(0x0u, 16);
    goto L_829065;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9062u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9062u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829062 LDA
    cpu.setA(0x0u, 16);
    goto L_829065;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9062u,0x829062u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829065:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9065u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9065u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9065u, 8u, 4u, 0x808D4Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829065 JSL -> $808D4A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9068u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9069u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D4Au, 0x829065u); }
    goto L_829069;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9065u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9065u, 8u, 4u, 0x808D4Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829065 JSL -> $808D4A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9068u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9069u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D4Au, 0x829065u); }
    goto L_829069;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9065u,0x829065u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829069:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9069u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9069u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9069u, 8u, 4u, 0x809E97u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829069 JSL -> $809E97 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x906Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x906Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809E97u, 0x829069u); }
    goto L_82906D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9069u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9069u, 8u, 4u, 0x809E97u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829069 JSL -> $809E97 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x906Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x906Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809E97u, 0x829069u); }
    goto L_82906D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9069u,0x829069u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82906D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x906Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x906Du,0x82906Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82906D SEP
    cpu.sep(0x20u);
    goto L_82906F;
L_82906F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x906Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82906F LDA
    cpu.setA(0x7Eu, 8);
    goto L_829071;
L_829071:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9071u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9071u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9071u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $829071 PHA
    cpu.push("PHA", hw);
    goto L_829072;
L_829072:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9072u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9072u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9072u, 5u, 3u, cpu.address("abs", 0x2800u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829072 PEA
    cpu.push16Value(hw, 0x2800u);
    goto L_829075;
L_829075:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9075u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9075u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9075u, 5u, 3u, cpu.address("abs", 0x5000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829075 PEA
    cpu.push16Value(hw, 0x5000u);
    goto L_829078;
L_829078:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9078u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9078u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9078u, 5u, 3u, cpu.address("abs", 0x1000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829078 PEA
    cpu.push16Value(hw, 0x1000u);
    goto L_82907B;
L_82907B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x907Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Bu, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82907B JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x907Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x907Fu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x82907Bu); }
    goto L_82907F;
L_82907F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x907Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x907Fu,0x82907Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82907F SEP
    cpu.sep(0x20u);
    goto L_829081;
L_829081:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9081u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9081u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9081u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829081 LDA
    cpu.setA(0x7Eu, 8);
    goto L_829083;
L_829083:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9083u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9083u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9083u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $829083 PHA
    cpu.push("PHA", hw);
    goto L_829084;
L_829084:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9084u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9084u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9084u, 5u, 3u, cpu.address("abs", 0x4000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829084 PEA
    cpu.push16Value(hw, 0x4000u);
    goto L_829087;
L_829087:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9087u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9087u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9087u, 5u, 3u, cpu.address("abs", 0x5800u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829087 PEA
    cpu.push16Value(hw, 0x5800u);
    goto L_82908A;
L_82908A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x908Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x908Au,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x908Au, 5u, 3u, cpu.address("abs", 0x0800u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82908A PEA
    cpu.push16Value(hw, 0x800u);
    goto L_82908D;
L_82908D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x908Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x908Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x908Du, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82908D JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9090u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9091u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x82908Du); }
    goto L_829091;
L_829091:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9091u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9091u,0x829091u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9091u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9091u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829091 SEP
    cpu.sep(0x20u);
    goto L_829093;
L_829093:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9093u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9093u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9093u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829093 LDA
    cpu.setA(0x7Eu, 8);
    goto L_829095;
L_829095:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9095u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9095u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9095u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $829095 PHA
    cpu.push("PHA", hw);
    goto L_829096;
L_829096:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9096u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9096u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9096u, 5u, 3u, cpu.address("abs", 0x6000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829096 PEA
    cpu.push16Value(hw, 0x6000u);
    goto L_829099;
L_829099:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9099u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9099u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9099u, 5u, 3u, cpu.address("abs", 0x5C00u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829099 PEA
    cpu.push16Value(hw, 0x5C00u);
    goto L_82909C;
L_82909C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x909Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x909Cu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x909Cu, 5u, 3u, cpu.address("abs", 0x0800u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82909C PEA
    cpu.push16Value(hw, 0x800u);
    goto L_82909F;
L_82909F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x909Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x909Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x909Fu, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82909F JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x90A2u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x90A3u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x82909Fu); }
    goto L_8290A3;
L_8290A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x90A3u,0x8290A3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A3u, 6u, 3u, cpu.address("abs", 0xCD0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8290A3 JSR -> $82CD0D stack real
    { cpu.push16Value(hw,0x90A5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x90A6u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCD0Du), 0x8290A3u); }
    goto L_8290A6;
L_8290A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x90A6u,0x8290A6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A6u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290A6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8290A9;
L_8290A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290A9 CMP
    cpu.compareA(0x1u);
    goto L_8290AC;
L_8290AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90ACu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90ACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290AC BNE -> $8290C0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8290C0; }
    goto L_8290AE;
L_8290AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90AEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90AEu, 5u, 3u, cpu.address("abs", 0x01D7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290AE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1D7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8290B1;
L_8290B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B1u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290B1 AND
    cpu.logicAnd(0xFFu);
    goto L_8290B4;
L_8290B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290B4 BNE -> $8290C8
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8290C8; }
    goto L_8290B6;
L_8290B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B6u, 5u, 3u, cpu.address("abs", 0x02CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290B6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2CEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8290B9;
L_8290B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290B9 CMP
    cpu.compareA(0x64u);
    goto L_8290BC;
L_8290BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90BCu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90BCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290BC BCS -> $8290C8
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_8290C8; }
    goto L_8290BE;
L_8290BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90BEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90BEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290BE BRA -> $8290CB
    goto L_8290CB;
L_8290C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90C0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90C0u, 5u, 3u, cpu.address("abs", 0x02CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290C0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2CEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8290C3;
L_8290C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90C3u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90C3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290C3 CMP
    cpu.compareA(0x50u);
    goto L_8290C6;
L_8290C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90C6u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290C6 BCC -> $8290CB
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8290CB; }
    goto L_8290C8;
L_8290C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90C8u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90C8u, 8u, 3u, cpu.address("abs", 0x02CEu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290C8 DEC
    cpu.decMem(hw, cpu.address("abs", 0x2CEu), cpu.m8?8:16);
    goto L_8290CB;
L_8290CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90CBu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90CBu, 5u, 3u, cpu.address("abs", 0x01AFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290CB STZ
    hw.write(cpu.address("abs", 0x1AFu), 0, cpu.m8?8:16);
    goto L_8290CE;
L_8290CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90CEu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90CEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290CE SEP
    cpu.sep(0x20u);
    goto L_8290D0;
L_8290D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90D0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90D0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290D0 LDA
    cpu.setA(0x81u, 8);
    goto L_8290D2;
L_8290D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90D2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90D2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290D2 STA
    hw.write(cpu.address("dp", 0x47u), cpu.a, cpu.m8?8:16);
    goto L_8290D4;
L_8290D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90D4u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90D4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290D4 STZ
    hw.write(cpu.address("dp", 0x49u), 0, cpu.m8?8:16);
    goto L_8290D6;
L_8290D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90D6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290D6 LDA
    cpu.setA(0xC3u, 8);
    goto L_8290D8;
L_8290D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90D8u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90D8u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290D8 XBA
    cpu.xba();
    goto L_8290D9;
L_8290D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90D9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90D9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290D9 LDA
    cpu.setA(0x0u, 8);
    goto L_8290DB;
L_8290DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90DBu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90DBu, 8u, 4u, 0x8086F4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8290DB JSL -> $8086F4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x90DEu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x90DFu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8086F4u, 0x8290DBu); }
    goto L_8290DF;
L_8290DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90DFu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x90DFu,0x8290DFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90DFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90DFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290DF LDA
    cpu.setA(0xC3u, 8);
    goto L_8290E1;
L_8290E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90E1u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90E1u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290E1 XBA
    cpu.xba();
    goto L_8290E2;
L_8290E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90E2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90E2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290E2 LDA
    cpu.setA(0xF1u, 8);
    goto L_8290E4;
L_8290E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90E4u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90E4u, 8u, 4u, 0x808700u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8290E4 JSL -> $808700 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x90E7u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x90E8u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808700u, 0x8290E4u); }
    goto L_8290E8;
L_8290E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90E8u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x90E8u,0x8290E8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90E8u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90E8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290E8 BRA -> $8290EA
    goto L_8290EA;
L_8290EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90EAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90EAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290EA LDA
    cpu.setA(0xAAu, 8);
    goto L_8290EC;
L_8290EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90ECu,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90ECu, 5u, 4u, 0x700000u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290EC STA
    hw.write(0x700000u, cpu.a, cpu.m8?8:16);
    goto L_8290F0;
L_8290F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90F0u,cpu,0xCFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90F0u, 5u, 4u, 0x700000u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290F0 CMP
    cpu.compareA(hw.readW(0x700000u, cpu.m8?8:16));
    goto L_8290F4;
L_8290F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90F4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90F4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290F4 BNE -> $829108
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829108; }
    goto L_8290F6;
L_8290F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90F6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90F6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290F6 LDA
    cpu.setA(0x55u, 8);
    goto L_8290F8;
L_8290F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90F8u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90F8u, 5u, 4u, 0x700000u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290F8 STA
    hw.write(0x700000u, cpu.a, cpu.m8?8:16);
    goto L_8290FC;
L_8290FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90FCu,cpu,0xCFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90FCu, 5u, 4u, 0x700000u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290FC CMP
    cpu.compareA(hw.readW(0x700000u, cpu.m8?8:16));
    goto L_829100;
L_829100:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9100u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9100u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9100u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829100 BNE -> $829108
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829108; }
    goto L_829102;
L_829102:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9102u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9102u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9102u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829102 LDA
    cpu.setA(0x84u, 8);
    goto L_829104;
L_829104:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9104u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9104u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9104u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829104 STA
    hw.write(cpu.address("dp", 0x46u), cpu.a, cpu.m8?8:16);
    goto L_829106;
L_829106:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9106u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9106u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9106u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829106 BRA -> $829127
    goto L_829127;
L_829108:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9108u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9108u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9108u, 4u, 3u, cpu.address("abs", 0x213Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829108 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x213Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82910B;
L_82910B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x910Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x910Bu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x910Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82910B BIT
    cpu.bit(0x10u, true);
    goto L_82910D;
L_82910D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x910Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x910Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x910Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82910D BNE -> $829102
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829102; }
    goto L_82910F;
L_82910F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x910Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x910Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x910Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82910F LDA
    cpu.setA(0xAAu, 8);
    goto L_829111;
L_829111:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9111u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9111u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9111u, 5u, 4u, 0x80FFC0u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829111 STA
    hw.write(0x80FFC0u, cpu.a, cpu.m8?8:16);
    goto L_829115;
L_829115:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9115u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9115u,cpu,0xCFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9115u, 5u, 4u, 0x80FFC0u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829115 CMP
    cpu.compareA(hw.readW(0x80FFC0u, cpu.m8?8:16));
    goto L_829119;
L_829119:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9119u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9119u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9119u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829119 BNE -> $829127
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829127; }
    goto L_82911B;
L_82911B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x911Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x911Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x911Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82911B LDA
    cpu.setA(0x55u, 8);
    goto L_82911D;
L_82911D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x911Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x911Du,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x911Du, 5u, 4u, 0x80FFC0u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82911D STA
    hw.write(0x80FFC0u, cpu.a, cpu.m8?8:16);
    goto L_829121;
L_829121:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9121u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9121u,cpu,0xCFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9121u, 5u, 4u, 0x80FFC0u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829121 CMP
    cpu.compareA(hw.readW(0x80FFC0u, cpu.m8?8:16));
    goto L_829125;
L_829125:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9125u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9125u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9125u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829125 BEQ -> $829102
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_829102; }
    goto L_829127;
L_829127:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9127u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9127u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9127u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829127 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x829127u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829127u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_829000_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829000u: goto L_829000;
    case 0x829002u: goto L_829002;
    case 0x829005u: goto L_829005;
    case 0x829008u: goto L_829008;
    case 0x82900Au: goto L_82900A;
    case 0x82900Du: goto L_82900D;
    case 0x82900Fu: goto L_82900F;
    case 0x829012u: goto L_829012;
    case 0x829014u: goto L_829014;
    case 0x829017u: goto L_829017;
    case 0x82901Au: goto L_82901A;
    case 0x82901Du: goto L_82901D;
    case 0x82901Fu: goto L_82901F;
    case 0x829022u: goto L_829022;
    case 0x829025u: goto L_829025;
    case 0x829028u: goto L_829028;
    case 0x82902Au: goto L_82902A;
    case 0x82902Du: goto L_82902D;
    case 0x829030u: goto L_829030;
    case 0x829033u: goto L_829033;
    case 0x829035u: goto L_829035;
    case 0x829038u: goto L_829038;
    case 0x82903Au: goto L_82903A;
    case 0x82903Du: goto L_82903D;
    case 0x82903Fu: goto L_82903F;
    case 0x829042u: goto L_829042;
    case 0x829045u: goto L_829045;
    case 0x829048u: goto L_829048;
    case 0x82904Au: goto L_82904A;
    case 0x82904Du: goto L_82904D;
    case 0x829050u: goto L_829050;
    case 0x829053u: goto L_829053;
    case 0x829055u: goto L_829055;
    case 0x829058u: goto L_829058;
    case 0x82905Au: goto L_82905A;
    case 0x82905Du: goto L_82905D;
    case 0x82905Fu: goto L_82905F;
    case 0x829062u: goto L_829062;
    case 0x829065u: goto L_829065;
    case 0x829069u: goto L_829069;
    case 0x82906Du: goto L_82906D;
    case 0x82906Fu: goto L_82906F;
    case 0x829071u: goto L_829071;
    case 0x829072u: goto L_829072;
    case 0x829075u: goto L_829075;
    case 0x829078u: goto L_829078;
    case 0x82907Bu: goto L_82907B;
    case 0x82907Fu: goto L_82907F;
    case 0x829081u: goto L_829081;
    case 0x829083u: goto L_829083;
    case 0x829084u: goto L_829084;
    case 0x829087u: goto L_829087;
    case 0x82908Au: goto L_82908A;
    case 0x82908Du: goto L_82908D;
    case 0x829091u: goto L_829091;
    case 0x829093u: goto L_829093;
    case 0x829095u: goto L_829095;
    case 0x829096u: goto L_829096;
    case 0x829099u: goto L_829099;
    case 0x82909Cu: goto L_82909C;
    case 0x82909Fu: goto L_82909F;
    case 0x8290A3u: goto L_8290A3;
    case 0x8290A6u: goto L_8290A6;
    case 0x8290A9u: goto L_8290A9;
    case 0x8290ACu: goto L_8290AC;
    case 0x8290AEu: goto L_8290AE;
    case 0x8290B1u: goto L_8290B1;
    case 0x8290B4u: goto L_8290B4;
    case 0x8290B6u: goto L_8290B6;
    case 0x8290B9u: goto L_8290B9;
    case 0x8290BCu: goto L_8290BC;
    case 0x8290BEu: goto L_8290BE;
    case 0x8290C0u: goto L_8290C0;
    case 0x8290C3u: goto L_8290C3;
    case 0x8290C6u: goto L_8290C6;
    case 0x8290C8u: goto L_8290C8;
    case 0x8290CBu: goto L_8290CB;
    case 0x8290CEu: goto L_8290CE;
    case 0x8290D0u: goto L_8290D0;
    case 0x8290D2u: goto L_8290D2;
    case 0x8290D4u: goto L_8290D4;
    case 0x8290D6u: goto L_8290D6;
    case 0x8290D8u: goto L_8290D8;
    case 0x8290D9u: goto L_8290D9;
    case 0x8290DBu: goto L_8290DB;
    case 0x8290DFu: goto L_8290DF;
    case 0x8290E1u: goto L_8290E1;
    case 0x8290E2u: goto L_8290E2;
    case 0x8290E4u: goto L_8290E4;
    case 0x8290E8u: goto L_8290E8;
    case 0x8290EAu: goto L_8290EA;
    case 0x8290ECu: goto L_8290EC;
    case 0x8290F0u: goto L_8290F0;
    case 0x8290F4u: goto L_8290F4;
    case 0x8290F6u: goto L_8290F6;
    case 0x8290F8u: goto L_8290F8;
    case 0x8290FCu: goto L_8290FC;
    case 0x829100u: goto L_829100;
    case 0x829102u: goto L_829102;
    case 0x829104u: goto L_829104;
    case 0x829106u: goto L_829106;
    case 0x829108u: goto L_829108;
    case 0x82910Bu: goto L_82910B;
    case 0x82910Du: goto L_82910D;
    case 0x82910Fu: goto L_82910F;
    case 0x829111u: goto L_829111;
    case 0x829115u: goto L_829115;
    case 0x829119u: goto L_829119;
    case 0x82911Bu: goto L_82911B;
    case 0x82911Du: goto L_82911D;
    case 0x829121u: goto L_829121;
    case 0x829125u: goto L_829125;
    case 0x829127u: goto L_829127;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829000:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9000u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9000u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9000u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829000 SEP
    cpu.sep(0x20u);
    goto L_829002;
L_829002:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9002u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9002u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9002u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829002 LDX
    cpu.setX(0x2000u, 16);
    goto L_829005;
L_829005:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9005u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9005u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9005u, 5u, 3u, cpu.address("abs", 0x2181u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829005 STX
    hw.write(cpu.address("abs", 0x2181u), cpu.x, cpu.x8?8:16);
    goto L_829008;
L_829008:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9008u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9008u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9008u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829008 LDA
    cpu.setA(0x0u, 8);
    goto L_82900A;
L_82900A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x900Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x900Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x900Au, 4u, 3u, cpu.address("abs", 0x2183u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82900A STA
    hw.write(cpu.address("abs", 0x2183u), cpu.a, cpu.m8?8:16);
    goto L_82900D;
L_82900D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x900Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x900Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x900Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82900D LDA
    cpu.setA(0x8u, 8);
    goto L_82900F;
L_82900F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x900Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x900Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x900Fu, 4u, 3u, cpu.address("abs", 0x4370u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82900F STA
    hw.write(cpu.address("abs", 0x4370u), cpu.a, cpu.m8?8:16);
    goto L_829012;
L_829012:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9012u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9012u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9012u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829012 LDA
    cpu.setA(0x80u, 8);
    goto L_829014;
L_829014:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9014u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9014u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9014u, 4u, 3u, cpu.address("abs", 0x4371u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829014 STA
    hw.write(cpu.address("abs", 0x4371u), cpu.a, cpu.m8?8:16);
    goto L_829017;
L_829017:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9017u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9017u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9017u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829017 LDX
    cpu.setX(0x8D46u, 16);
    goto L_82901A;
L_82901A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x901Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x901Au,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x901Au, 5u, 3u, cpu.address("abs", 0x4372u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82901A STX
    hw.write(cpu.address("abs", 0x4372u), cpu.x, cpu.x8?8:16);
    goto L_82901D;
L_82901D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x901Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x901Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x901Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82901D LDA
    cpu.setA(0x80u, 8);
    goto L_82901F;
L_82901F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x901Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x901Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x901Fu, 4u, 3u, cpu.address("abs", 0x4374u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82901F STA
    hw.write(cpu.address("abs", 0x4374u), cpu.a, cpu.m8?8:16);
    goto L_829022;
L_829022:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9022u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9022u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9022u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829022 LDX
    cpu.setX(0x800u, 16);
    goto L_829025;
L_829025:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9025u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9025u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9025u, 5u, 3u, cpu.address("abs", 0x4375u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829025 STX
    hw.write(cpu.address("abs", 0x4375u), cpu.x, cpu.x8?8:16);
    goto L_829028;
L_829028:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9028u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9028u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9028u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829028 LDA
    cpu.setA(0x80u, 8);
    goto L_82902A;
L_82902A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x902Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x902Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x902Au, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82902A STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_82902D;
L_82902D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x902Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x902Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x902Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82902D LDX
    cpu.setX(0x3000u, 16);
    goto L_829030;
L_829030:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9030u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9030u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9030u, 5u, 3u, cpu.address("abs", 0x2181u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829030 STX
    hw.write(cpu.address("abs", 0x2181u), cpu.x, cpu.x8?8:16);
    goto L_829033;
L_829033:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9033u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9033u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9033u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829033 LDA
    cpu.setA(0x0u, 8);
    goto L_829035;
L_829035:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9035u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9035u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9035u, 4u, 3u, cpu.address("abs", 0x2183u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829035 STA
    hw.write(cpu.address("abs", 0x2183u), cpu.a, cpu.m8?8:16);
    goto L_829038;
L_829038:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9038u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9038u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9038u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829038 LDA
    cpu.setA(0x8u, 8);
    goto L_82903A;
L_82903A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x903Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x903Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x903Au, 4u, 3u, cpu.address("abs", 0x4370u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82903A STA
    hw.write(cpu.address("abs", 0x4370u), cpu.a, cpu.m8?8:16);
    goto L_82903D;
L_82903D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x903Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x903Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x903Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82903D LDA
    cpu.setA(0x80u, 8);
    goto L_82903F;
L_82903F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x903Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x903Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x903Fu, 4u, 3u, cpu.address("abs", 0x4371u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82903F STA
    hw.write(cpu.address("abs", 0x4371u), cpu.a, cpu.m8?8:16);
    goto L_829042;
L_829042:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9042u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9042u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9042u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829042 LDX
    cpu.setX(0x8D46u, 16);
    goto L_829045;
L_829045:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9045u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9045u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9045u, 5u, 3u, cpu.address("abs", 0x4372u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829045 STX
    hw.write(cpu.address("abs", 0x4372u), cpu.x, cpu.x8?8:16);
    goto L_829048;
L_829048:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9048u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9048u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9048u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829048 LDA
    cpu.setA(0x80u, 8);
    goto L_82904A;
L_82904A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x904Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x904Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x904Au, 4u, 3u, cpu.address("abs", 0x4374u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82904A STA
    hw.write(cpu.address("abs", 0x4374u), cpu.a, cpu.m8?8:16);
    goto L_82904D;
L_82904D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x904Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x904Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x904Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82904D LDX
    cpu.setX(0x800u, 16);
    goto L_829050;
L_829050:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9050u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9050u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9050u, 5u, 3u, cpu.address("abs", 0x4375u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829050 STX
    hw.write(cpu.address("abs", 0x4375u), cpu.x, cpu.x8?8:16);
    goto L_829053;
L_829053:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9053u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9053u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9053u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829053 LDA
    cpu.setA(0x80u, 8);
    goto L_829055;
L_829055:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9055u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9055u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9055u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829055 STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_829058;
L_829058:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9058u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9058u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9058u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829058 REP
    cpu.rep(0x20u);
    goto L_82905A;
L_82905A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x905Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x905Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x905Au, 5u, 3u, cpu.address("abs", 0x0193u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82905A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x193u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82905D;
L_82905D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x905Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x905Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x905Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82905D BEQ -> $829062
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_829062; }
    goto L_82905F;
L_82905F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x905Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x905Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x905Fu, 6u, 3u, cpu.address("abs", 0xC0E7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82905F JSR -> $82C0E7 stack real
    { cpu.push16Value(hw,0x9061u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9062u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC0E7u), 0x82905Fu); }
    goto L_829062;
L_829062:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9062u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9062u,0x829062u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9062u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9062u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829062 LDA
    cpu.setA(0x0u, 16);
    goto L_829065;
L_829065:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9065u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9065u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9065u, 8u, 4u, 0x808D4Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829065 JSL -> $808D4A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9068u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9069u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D4Au, 0x829065u); }
    goto L_829069;
L_829069:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9069u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9069u,0x829069u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9069u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9069u, 8u, 4u, 0x809E97u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829069 JSL -> $809E97 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x906Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x906Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809E97u, 0x829069u); }
    goto L_82906D;
L_82906D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x906Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x906Du,0x82906Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82906D SEP
    cpu.sep(0x20u);
    goto L_82906F;
L_82906F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x906Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82906F LDA
    cpu.setA(0x7Eu, 8);
    goto L_829071;
L_829071:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9071u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9071u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9071u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $829071 PHA
    cpu.push("PHA", hw);
    goto L_829072;
L_829072:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9072u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9072u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9072u, 5u, 3u, cpu.address("abs", 0x2800u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829072 PEA
    cpu.push16Value(hw, 0x2800u);
    goto L_829075;
L_829075:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9075u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9075u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9075u, 5u, 3u, cpu.address("abs", 0x5000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829075 PEA
    cpu.push16Value(hw, 0x5000u);
    goto L_829078;
L_829078:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9078u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9078u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9078u, 5u, 3u, cpu.address("abs", 0x1000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829078 PEA
    cpu.push16Value(hw, 0x1000u);
    goto L_82907B;
L_82907B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x907Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Bu, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82907B JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x907Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x907Fu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x82907Bu); }
    goto L_82907F;
L_82907F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x907Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x907Fu,0x82907Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82907F SEP
    cpu.sep(0x20u);
    goto L_829081;
L_829081:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9081u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9081u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9081u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829081 LDA
    cpu.setA(0x7Eu, 8);
    goto L_829083;
L_829083:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9083u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9083u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9083u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $829083 PHA
    cpu.push("PHA", hw);
    goto L_829084;
L_829084:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9084u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9084u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9084u, 5u, 3u, cpu.address("abs", 0x4000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829084 PEA
    cpu.push16Value(hw, 0x4000u);
    goto L_829087;
L_829087:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9087u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9087u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9087u, 5u, 3u, cpu.address("abs", 0x5800u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829087 PEA
    cpu.push16Value(hw, 0x5800u);
    goto L_82908A;
L_82908A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x908Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x908Au,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x908Au, 5u, 3u, cpu.address("abs", 0x0800u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82908A PEA
    cpu.push16Value(hw, 0x800u);
    goto L_82908D;
L_82908D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x908Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x908Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x908Du, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82908D JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9090u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9091u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x82908Du); }
    goto L_829091;
L_829091:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9091u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9091u,0x829091u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9091u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9091u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829091 SEP
    cpu.sep(0x20u);
    goto L_829093;
L_829093:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9093u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9093u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9093u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829093 LDA
    cpu.setA(0x7Eu, 8);
    goto L_829095;
L_829095:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9095u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9095u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9095u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $829095 PHA
    cpu.push("PHA", hw);
    goto L_829096;
L_829096:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9096u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9096u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9096u, 5u, 3u, cpu.address("abs", 0x6000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829096 PEA
    cpu.push16Value(hw, 0x6000u);
    goto L_829099;
L_829099:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9099u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9099u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9099u, 5u, 3u, cpu.address("abs", 0x5C00u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829099 PEA
    cpu.push16Value(hw, 0x5C00u);
    goto L_82909C;
L_82909C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x909Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x909Cu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x909Cu, 5u, 3u, cpu.address("abs", 0x0800u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82909C PEA
    cpu.push16Value(hw, 0x800u);
    goto L_82909F;
L_82909F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x909Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x909Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x909Fu, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82909F JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x90A2u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x90A3u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x82909Fu); }
    goto L_8290A3;
L_8290A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x90A3u,0x8290A3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A3u, 6u, 3u, cpu.address("abs", 0xCD0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8290A3 JSR -> $82CD0D stack real
    { cpu.push16Value(hw,0x90A5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x90A6u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCD0Du), 0x8290A3u); }
    goto L_8290A6;
L_8290A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x90A6u,0x8290A6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A6u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290A6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8290A9;
L_8290A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290A9 CMP
    cpu.compareA(0x1u);
    goto L_8290AC;
L_8290AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90ACu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90ACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290AC BNE -> $8290C0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8290C0; }
    goto L_8290AE;
L_8290AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90AEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90AEu, 5u, 3u, cpu.address("abs", 0x01D7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290AE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1D7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8290B1;
L_8290B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B1u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290B1 AND
    cpu.logicAnd(0xFFu);
    goto L_8290B4;
L_8290B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290B4 BNE -> $8290C8
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8290C8; }
    goto L_8290B6;
L_8290B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B6u, 5u, 3u, cpu.address("abs", 0x02CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290B6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2CEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8290B9;
L_8290B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290B9 CMP
    cpu.compareA(0x64u);
    goto L_8290BC;
L_8290BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90BCu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90BCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290BC BCS -> $8290C8
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_8290C8; }
    goto L_8290BE;
L_8290BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90BEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90BEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290BE BRA -> $8290CB
    goto L_8290CB;
L_8290C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90C0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90C0u, 5u, 3u, cpu.address("abs", 0x02CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290C0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2CEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8290C3;
L_8290C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90C3u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90C3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290C3 CMP
    cpu.compareA(0x50u);
    goto L_8290C6;
L_8290C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90C6u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290C6 BCC -> $8290CB
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8290CB; }
    goto L_8290C8;
L_8290C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90C8u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90C8u, 8u, 3u, cpu.address("abs", 0x02CEu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290C8 DEC
    cpu.decMem(hw, cpu.address("abs", 0x2CEu), cpu.m8?8:16);
    goto L_8290CB;
L_8290CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90CBu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90CBu, 5u, 3u, cpu.address("abs", 0x01AFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290CB STZ
    hw.write(cpu.address("abs", 0x1AFu), 0, cpu.m8?8:16);
    goto L_8290CE;
L_8290CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90CEu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90CEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290CE SEP
    cpu.sep(0x20u);
    goto L_8290D0;
L_8290D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90D0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90D0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290D0 LDA
    cpu.setA(0x81u, 8);
    goto L_8290D2;
L_8290D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90D2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90D2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290D2 STA
    hw.write(cpu.address("dp", 0x47u), cpu.a, cpu.m8?8:16);
    goto L_8290D4;
L_8290D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90D4u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90D4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290D4 STZ
    hw.write(cpu.address("dp", 0x49u), 0, cpu.m8?8:16);
    goto L_8290D6;
L_8290D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90D6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290D6 LDA
    cpu.setA(0xC3u, 8);
    goto L_8290D8;
L_8290D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90D8u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90D8u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290D8 XBA
    cpu.xba();
    goto L_8290D9;
L_8290D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90D9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90D9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290D9 LDA
    cpu.setA(0x0u, 8);
    goto L_8290DB;
L_8290DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90DBu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90DBu, 8u, 4u, 0x8086F4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8290DB JSL -> $8086F4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x90DEu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x90DFu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8086F4u, 0x8290DBu); }
    goto L_8290DF;
L_8290DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90DFu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x90DFu,0x8290DFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90DFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90DFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290DF LDA
    cpu.setA(0xC3u, 8);
    goto L_8290E1;
L_8290E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90E1u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90E1u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290E1 XBA
    cpu.xba();
    goto L_8290E2;
L_8290E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90E2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90E2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290E2 LDA
    cpu.setA(0xF1u, 8);
    goto L_8290E4;
L_8290E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90E4u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90E4u, 8u, 4u, 0x808700u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8290E4 JSL -> $808700 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x90E7u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x90E8u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808700u, 0x8290E4u); }
    goto L_8290E8;
L_8290E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90E8u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x90E8u,0x8290E8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90E8u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90E8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290E8 BRA -> $8290EA
    goto L_8290EA;
L_8290EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90EAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90EAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290EA LDA
    cpu.setA(0xAAu, 8);
    goto L_8290EC;
L_8290EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90ECu,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90ECu, 5u, 4u, 0x700000u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290EC STA
    hw.write(0x700000u, cpu.a, cpu.m8?8:16);
    goto L_8290F0;
L_8290F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90F0u,cpu,0xCFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90F0u, 5u, 4u, 0x700000u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290F0 CMP
    cpu.compareA(hw.readW(0x700000u, cpu.m8?8:16));
    goto L_8290F4;
L_8290F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90F4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90F4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290F4 BNE -> $829108
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829108; }
    goto L_8290F6;
L_8290F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90F6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90F6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290F6 LDA
    cpu.setA(0x55u, 8);
    goto L_8290F8;
L_8290F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90F8u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90F8u, 5u, 4u, 0x700000u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290F8 STA
    hw.write(0x700000u, cpu.a, cpu.m8?8:16);
    goto L_8290FC;
L_8290FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90FCu,cpu,0xCFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90FCu, 5u, 4u, 0x700000u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290FC CMP
    cpu.compareA(hw.readW(0x700000u, cpu.m8?8:16));
    goto L_829100;
L_829100:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9100u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9100u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9100u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829100 BNE -> $829108
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829108; }
    goto L_829102;
L_829102:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9102u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9102u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9102u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829102 LDA
    cpu.setA(0x84u, 8);
    goto L_829104;
L_829104:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9104u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9104u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9104u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829104 STA
    hw.write(cpu.address("dp", 0x46u), cpu.a, cpu.m8?8:16);
    goto L_829106;
L_829106:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9106u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9106u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9106u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829106 BRA -> $829127
    goto L_829127;
L_829108:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9108u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9108u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9108u, 4u, 3u, cpu.address("abs", 0x213Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829108 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x213Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82910B;
L_82910B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x910Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x910Bu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x910Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82910B BIT
    cpu.bit(0x10u, true);
    goto L_82910D;
L_82910D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x910Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x910Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x910Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82910D BNE -> $829102
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829102; }
    goto L_82910F;
L_82910F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x910Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x910Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x910Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82910F LDA
    cpu.setA(0xAAu, 8);
    goto L_829111;
L_829111:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9111u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9111u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9111u, 5u, 4u, 0x80FFC0u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829111 STA
    hw.write(0x80FFC0u, cpu.a, cpu.m8?8:16);
    goto L_829115;
L_829115:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9115u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9115u,cpu,0xCFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9115u, 5u, 4u, 0x80FFC0u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829115 CMP
    cpu.compareA(hw.readW(0x80FFC0u, cpu.m8?8:16));
    goto L_829119;
L_829119:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9119u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9119u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9119u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829119 BNE -> $829127
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829127; }
    goto L_82911B;
L_82911B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x911Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x911Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x911Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82911B LDA
    cpu.setA(0x55u, 8);
    goto L_82911D;
L_82911D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x911Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x911Du,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x911Du, 5u, 4u, 0x80FFC0u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82911D STA
    hw.write(0x80FFC0u, cpu.a, cpu.m8?8:16);
    goto L_829121;
L_829121:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9121u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9121u,cpu,0xCFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9121u, 5u, 4u, 0x80FFC0u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829121 CMP
    cpu.compareA(hw.readW(0x80FFC0u, cpu.m8?8:16));
    goto L_829125;
L_829125:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9125u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9125u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9125u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829125 BEQ -> $829102
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_829102; }
    goto L_829127;
L_829127:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9127u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9127u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9127u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829127 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x829127u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829127u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_829241_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829241u: goto L_829241;
    case 0x829243u: goto L_829243;
    case 0x829247u: goto L_829247;
    case 0x82924Au: goto L_82924A;
    case 0x82924Du: goto L_82924D;
    case 0x829250u: goto L_829250;
    case 0x829254u: goto L_829254;
    case 0x829257u: goto L_829257;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829241:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9241u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9241u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9241u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829241 REP
    cpu.rep(0x20u);
    goto L_829243;
L_829243:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9243u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9243u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9243u, 8u, 4u, 0x809D16u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829243 JSL -> $809D16 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9246u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9247u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809D16u, 0x829243u); }
    goto L_829247;
L_829247:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9247u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9247u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9247u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829247 LDA
    cpu.setA(0x800u, 16);
    goto L_82924A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9247u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9247u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829247 LDA
    cpu.setA(0x800u, 16);
    goto L_82924A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9247u,0x829247u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82924A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x924Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x924Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x924Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82924A LDX
    cpu.setX(0x2800u, 16);
    goto L_82924D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x924Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x924Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82924A LDX
    cpu.setX(0x2800u, 16);
    goto L_82924D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x924Au,0x82924Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82924D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x924Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x924Du,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x924Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82924D LDY
    cpu.setY(0x5000u, 16);
    goto L_829250;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x924Du,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x924Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82924D LDY
    cpu.setY(0x5000u, 16);
    goto L_829250;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x924Du,0x82924Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829250:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9250u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9250u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9250u, 8u, 4u, 0x808EBFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829250 JSL -> $808EBF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9253u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9254u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808EBFu, 0x829250u); }
    goto L_829254;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9250u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9250u, 8u, 4u, 0x808EBFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829250 JSL -> $808EBF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9253u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9254u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808EBFu, 0x829250u); }
    goto L_829254;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9250u,0x829250u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829254:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9254u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9254u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9254u, 6u, 3u, cpu.address("abs", 0xC326u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829254 JSR -> $82C326 stack real
    { cpu.push16Value(hw,0x9256u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9257u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC326u), 0x829254u); }
    goto L_829257;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9254u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9254u, 6u, 3u, cpu.address("abs", 0xC326u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829254 JSR -> $82C326 stack real
    { cpu.push16Value(hw,0x9256u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9257u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC326u), 0x829254u); }
    goto L_829257;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9254u,0x829254u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829257:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9257u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9257u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9257u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829257 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x829257u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829257u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9257u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9257u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829257 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x829257u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829257u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9257u,0x829257u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_829241_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829241u: goto L_829241;
    case 0x829243u: goto L_829243;
    case 0x829247u: goto L_829247;
    case 0x82924Au: goto L_82924A;
    case 0x82924Du: goto L_82924D;
    case 0x829250u: goto L_829250;
    case 0x829254u: goto L_829254;
    case 0x829257u: goto L_829257;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829241:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9241u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9241u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9241u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829241 REP
    cpu.rep(0x20u);
    goto L_829243;
L_829243:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9243u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9243u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9243u, 8u, 4u, 0x809D16u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829243 JSL -> $809D16 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9246u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9247u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809D16u, 0x829243u); }
    goto L_829247;
L_829247:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9247u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9247u,0x829247u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9247u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9247u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829247 LDA
    cpu.setA(0x800u, 16);
    goto L_82924A;
L_82924A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x924Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x924Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x924Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82924A LDX
    cpu.setX(0x2800u, 16);
    goto L_82924D;
L_82924D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x924Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x924Du,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x924Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82924D LDY
    cpu.setY(0x5000u, 16);
    goto L_829250;
L_829250:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9250u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9250u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9250u, 8u, 4u, 0x808EBFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829250 JSL -> $808EBF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9253u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9254u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808EBFu, 0x829250u); }
    goto L_829254;
L_829254:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9254u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9254u,0x829254u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9254u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9254u, 6u, 3u, cpu.address("abs", 0xC326u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829254 JSR -> $82C326 stack real
    { cpu.push16Value(hw,0x9256u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9257u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC326u), 0x829254u); }
    goto L_829257;
L_829257:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9257u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9257u,0x829257u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9257u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9257u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829257 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x829257u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829257u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_829E2C_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829E2Cu: goto L_829E2C;
    case 0x829E2Eu: goto L_829E2E;
    case 0x829E31u: goto L_829E31;
    case 0x829E33u: goto L_829E33;
    case 0x829E36u: goto L_829E36;
    case 0x829E39u: goto L_829E39;
    case 0x829E3Au: goto L_829E3A;
    case 0x829E3Du: goto L_829E3D;
    case 0x829E40u: goto L_829E40;
    case 0x829E43u: goto L_829E43;
    case 0x829E46u: goto L_829E46;
    case 0x829E49u: goto L_829E49;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829E2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Cu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E2C LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829E2E;
L_829E2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Eu, 5u + 1u, 3u, cpu.address("absx", 0x02CCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E2E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2CCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829E31;
L_829E31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E31u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E31u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E31 BNE -> $829E3A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829E3A; }
    goto L_829E33;
L_829E33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E33u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E33u, 6u, 3u, cpu.address("abs", 0xE02Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829E33 JSR -> $82E02E stack real
    { cpu.push16Value(hw,0x9E35u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9E36u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE02Eu), 0x829E33u); }
    goto L_829E36;
L_829E36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E36u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E36u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E36u, 9u, 3u, cpu.address("absx", 0x02CCu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E36 INC
    cpu.incMem(hw, cpu.address("absx", 0x2CCu), cpu.m8?8:16);
    goto L_829E39;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E36u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E36u, 9u, 3u, cpu.address("absx", 0x02CCu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E36 INC
    cpu.incMem(hw, cpu.address("absx", 0x2CCu), cpu.m8?8:16);
    goto L_829E39;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E36u,0x829E36u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829E39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E39u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E39u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E39u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829E39 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829E39u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829E39u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E39u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E39u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829E39 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829E39u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829E39u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E39u,0x829E39u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829E3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E3Au,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E3Au, 8u, 3u, cpu.address("abs", 0x014Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E3A INC
    cpu.incMem(hw, cpu.address("abs", 0x14Au), cpu.m8?8:16);
    goto L_829E3D;
L_829E3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E3Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E3Du, 6u, 3u, cpu.address("abs", 0xDF65u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829E3D JSR -> $82DF65 stack real
    { cpu.push16Value(hw,0x9E3Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9E40u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xDF65u), 0x829E3Du); }
    goto L_829E40;
L_829E40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E40u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E40u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E40u, 9u, 3u, cpu.address("absx", 0x0200u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E40 INC
    cpu.incMem(hw, cpu.address("absx", 0x200u), cpu.m8?8:16);
    goto L_829E43;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E40u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E40u, 9u, 3u, cpu.address("absx", 0x0200u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E40 INC
    cpu.incMem(hw, cpu.address("absx", 0x200u), cpu.m8?8:16);
    goto L_829E43;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E40u,0x829E40u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829E43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E43u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E43u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E43u, 6u, 3u, cpu.address("absx", 0x02C8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E43 STZ
    hw.write(cpu.address("absx", 0x2C8u), 0, cpu.m8?8:16);
    goto L_829E46;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E43u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E43u, 6u, 3u, cpu.address("absx", 0x02C8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E43 STZ
    hw.write(cpu.address("absx", 0x2C8u), 0, cpu.m8?8:16);
    goto L_829E46;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E43u,0x829E43u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829E46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E46u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E46u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E46u, 6u, 3u, cpu.address("absx", 0x02CCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E46 STZ
    hw.write(cpu.address("absx", 0x2CCu), 0, cpu.m8?8:16);
    goto L_829E49;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E46u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E46u, 6u, 3u, cpu.address("absx", 0x02CCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E46 STZ
    hw.write(cpu.address("absx", 0x2CCu), 0, cpu.m8?8:16);
    goto L_829E49;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E46u,0x829E46u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829E49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E49u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E49u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E49u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829E49 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829E49u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829E49u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E49u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E49u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829E49 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829E49u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829E49u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E49u,0x829E49u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82A4FE_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82A4FEu: goto L_82A4FE;
    case 0x82A4FFu: goto L_82A4FF;
    case 0x82A500u: goto L_82A500;
    case 0x82A502u: goto L_82A502;
    case 0x82A503u: goto L_82A503;
    case 0x82A504u: goto L_82A504;
    case 0x82A505u: goto L_82A505;
    case 0x82A509u: goto L_82A509;
    case 0x82A50Au: goto L_82A50A;
    case 0x82A50Eu: goto L_82A50E;
    case 0x82A510u: goto L_82A510;
    case 0x82A513u: goto L_82A513;
    case 0x82A515u: goto L_82A515;
    case 0x82A518u: goto L_82A518;
    case 0x82A51Au: goto L_82A51A;
    case 0x82A51Cu: goto L_82A51C;
    case 0x82A520u: goto L_82A520;
    case 0x82A522u: goto L_82A522;
    case 0x82A524u: goto L_82A524;
    case 0x82A526u: goto L_82A526;
    case 0x82A52Au: goto L_82A52A;
    case 0x82A52Cu: goto L_82A52C;
    case 0x82A52Fu: goto L_82A52F;
    case 0x82A530u: goto L_82A530;
    case 0x82A531u: goto L_82A531;
    case 0x82A534u: goto L_82A534;
    case 0x82A536u: goto L_82A536;
    case 0x82A537u: goto L_82A537;
    case 0x82A539u: goto L_82A539;
    case 0x82A53Au: goto L_82A53A;
    case 0x82A53Bu: goto L_82A53B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82A4FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4FEu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4FEu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A4FE PHY
    cpu.push("PHY", hw);
    goto L_82A4FF;
L_82A4FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4FFu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4FFu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A4FF PHX
    cpu.push("PHX", hw);
    goto L_82A500;
L_82A500:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA500u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA500u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA500u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A500 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A502;
L_82A502:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA502u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA502u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA502u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A502 PHA
    cpu.push("PHA", hw);
    goto L_82A503;
L_82A503:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA503u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA503u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA503u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A503 TYA
    cpu.transfer("TYA");
    goto L_82A504;
L_82A504:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA504u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA504u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA504u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A504 CLC
    cpu.setFlag('C', false);
    goto L_82A505;
L_82A505:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA505u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA505u,cpu,0x7Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA505u, 6u, 4u, ((0x82A471u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A505 ADC
    cpu.adc(hw.readW(((0x82A471u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_82A509;
L_82A509:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA509u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA509u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA509u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A509 TAY
    cpu.transfer("TAY");
    goto L_82A50A;
L_82A50A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA50Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Au,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Au, 6u, 4u, ((0x82A479u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A50A LDA
    cpu.loadA(hw.readW(((0x82A479u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A50E;
L_82A50E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA50Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A50E STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_82A510;
L_82A510:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA510u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA510u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA510u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A510 LDX
    cpu.setX(0x0u, 16);
    goto L_82A513;
L_82A513:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA513u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA513u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA513u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82A513 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A515;
L_82A515:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA515u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA515u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA515u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A515 AND
    cpu.logicAnd(0x3FFFu);
    goto L_82A518;
L_82A518:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA518u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA518u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA518u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A518 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_82A51A;
L_82A51A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA51Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA51Au,cpu,0x91u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA51Au, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82A51A STA
    hw.write(cpu.addressDpIndirectY(hw, 0x67u), cpu.a, cpu.m8?8:16);
    goto L_82A51C;
L_82A51C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA51Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA51Cu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA51Cu, 6u, 4u, ((0x82A469u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A51C LDA
    cpu.loadA(hw.readW(((0x82A469u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A520;
L_82A520:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA520u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA520u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA520u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A520 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), false);
    goto L_82A522;
L_82A522:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA522u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA522u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA522u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A522 BNE -> $82A52F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A52F; }
    goto L_82A524;
L_82A524:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA524u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA524u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA524u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82A524 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A526;
L_82A526:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA526u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA526u,cpu,0x3Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA526u, 6u, 4u, ((0x82A469u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A526 AND
    cpu.logicAnd(hw.readW(((0x82A469u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_82A52A;
L_82A52A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA52Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA52Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA52Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A52A BEQ -> $82A52F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A52F; }
    goto L_82A52C;
L_82A52C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA52Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA52Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA52Cu, 6u, 3u, cpu.address("abs", 0xA4FEu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A52C JSR -> $82A4FE stack real
    { cpu.push16Value(hw,0xA52Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA52Fu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA4FEu), 0x82A52Cu); }
    goto L_82A52F;
L_82A52F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA52Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA52Fu,0x82A52Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA52Fu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA52Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A52F INX
    cpu.inc('X');
    goto L_82A530;
L_82A530:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA530u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA530u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA530u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A530 INX
    cpu.inc('X');
    goto L_82A531;
L_82A531:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA531u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA531u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA531u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A531 CPX
    cpu.compareX(0x8u);
    goto L_82A534;
L_82A534:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA534u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA534u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA534u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A534 BCC -> $82A51C
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82A51C; }
    goto L_82A536;
L_82A536:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA536u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA536u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA536u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A536 PLA
    cpu.pop("PLA", hw);
    goto L_82A537;
L_82A537:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA537u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA537u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA537u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A537 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_82A539;
L_82A539:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA539u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA539u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA539u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A539 PLX
    cpu.pop("PLX", hw);
    goto L_82A53A;
L_82A53A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA53Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA53Au,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA53Au, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A53A PLY
    cpu.pop("PLY", hw);
    goto L_82A53B;
L_82A53B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA53Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA53Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA53Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A53B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A53Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A53Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82ABCF_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82ABCFu: goto L_82ABCF;
    case 0x82ABD0u: goto L_82ABD0;
    case 0x82ABD2u: goto L_82ABD2;
    case 0x82ABD3u: goto L_82ABD3;
    case 0x82ABD7u: goto L_82ABD7;
    case 0x82ABDBu: goto L_82ABDB;
    case 0x82ABDFu: goto L_82ABDF;
    case 0x82ABE0u: goto L_82ABE0;
    case 0x82ABE1u: goto L_82ABE1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82ABCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABCFu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABCFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ABCF DEY
    cpu.decReg('Y');
    goto L_82ABD0;
L_82ABD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABD0u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABD0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ABD0 BPL -> $82ABD3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82ABD3; }
    goto L_82ABD2;
L_82ABD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABD2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABD2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82ABD2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82ABD2u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82ABD2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82ABD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABD3u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABD3u, 6u, 4u, ((0x7E2800u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ABD3 STA
    hw.write(((0x7E2800u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82ABD7;
L_82ABD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABD7u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABD7u, 6u, 4u, ((0x7E2840u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ABD7 STA
    hw.write(((0x7E2840u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82ABDB;
L_82ABDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABDBu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABDBu, 6u, 4u, ((0x7E2880u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ABDB STA
    hw.write(((0x7E2880u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82ABDF;
L_82ABDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABDFu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABDFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ABDF INX
    cpu.inc('X');
    goto L_82ABE0;
L_82ABE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABE0u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABE0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ABE0 INX
    cpu.inc('X');
    goto L_82ABE1;
L_82ABE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABE1u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABE1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ABE1 BRA -> $82ABCF
    goto L_82ABCF;
}

void sub_82B2E4_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B2E4u: goto L_82B2E4;
    case 0x82B2E6u: goto L_82B2E6;
    case 0x82B2E8u: goto L_82B2E8;
    case 0x82B2EAu: goto L_82B2EA;
    case 0x82B2ECu: goto L_82B2EC;
    case 0x82B2EEu: goto L_82B2EE;
    case 0x82B2F1u: goto L_82B2F1;
    case 0x82B2F3u: goto L_82B2F3;
    case 0x82B2F5u: goto L_82B2F5;
    case 0x82B2F8u: goto L_82B2F8;
    case 0x82B2F9u: goto L_82B2F9;
    case 0x82B2FCu: goto L_82B2FC;
    case 0x82B2FDu: goto L_82B2FD;
    case 0x82B2FFu: goto L_82B2FF;
    case 0x82B302u: goto L_82B302;
    case 0x82B305u: goto L_82B305;
    case 0x82B306u: goto L_82B306;
    case 0x82B309u: goto L_82B309;
    case 0x82B30Au: goto L_82B30A;
    case 0x82B30Cu: goto L_82B30C;
    case 0x82B30Fu: goto L_82B30F;
    case 0x82B311u: goto L_82B311;
    case 0x82B314u: goto L_82B314;
    case 0x82B317u: goto L_82B317;
    case 0x82B31Au: goto L_82B31A;
    case 0x82B31Du: goto L_82B31D;
    case 0x82B31Eu: goto L_82B31E;
    case 0x82B31Fu: goto L_82B31F;
    case 0x82B320u: goto L_82B320;
    case 0x82B321u: goto L_82B321;
    case 0x82B322u: goto L_82B322;
    case 0x82B323u: goto L_82B323;
    case 0x82B324u: goto L_82B324;
    case 0x82B325u: goto L_82B325;
    case 0x82B327u: goto L_82B327;
    case 0x82B329u: goto L_82B329;
    case 0x82B32Bu: goto L_82B32B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B2E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E4u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2E4 SEP
    cpu.sep(0x20u);
    goto L_82B2E6;
L_82B2E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E6u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2E6 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B2E8;
L_82B2E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E8u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2E8 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B2EA;
L_82B2EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2EA LDA
    cpu.setA(0x3u, 8);
    goto L_82B2EC;
L_82B2EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2ECu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2ECu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2EC STA
    hw.write(cpu.address("dp", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_82B2EE;
L_82B2EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EEu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EEu, 4u + 1u, 3u, cpu.address("absy", 0x0208u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2EE LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x208u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B2F1;
L_82B2F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2F1 CMP
    cpu.compareA(0x1u);
    goto L_82B2F3;
L_82B2F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2F3 BNE -> $82B31D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B31D; }
    goto L_82B2F5;
L_82B2F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F5u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F5u, 4u + 1u, 3u, cpu.address("absy", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2F5 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x20Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B2F8;
L_82B2F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F8u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2F8 CLC
    cpu.setFlag('C', false);
    goto L_82B2F9;
L_82B2F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F9u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F9u, 4u + 1u, 3u, cpu.address("absx", 0x0276u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2F9 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x276u), cpu.m8?8:16));
    goto L_82B2FC;
L_82B2FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FCu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2FC CLC
    cpu.setFlag('C', false);
    goto L_82B2FD;
L_82B2FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FDu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2FD ADC
    cpu.adc(0x4u);
    goto L_82B2FF;
L_82B2FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FFu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FFu, 5u, 3u, cpu.address("absx", 0x0276u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2FF STA
    hw.write(cpu.address("absx", 0x276u), cpu.a, cpu.m8?8:16);
    goto L_82B302;
L_82B302:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB302u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB302u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB302u, 4u + 1u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B302 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x20Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B305;
L_82B305:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB305u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB305u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB305u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B305 CLC
    cpu.setFlag('C', false);
    goto L_82B306;
L_82B306:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB306u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB306u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB306u, 4u + 1u, 3u, cpu.address("absx", 0x027Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B306 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x27Eu), cpu.m8?8:16));
    goto L_82B309;
L_82B309:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB309u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB309u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB309u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B309 CLC
    cpu.setFlag('C', false);
    goto L_82B30A;
L_82B30A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB30Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Au,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B30A ADC
    cpu.adc(0x4u);
    goto L_82B30C;
L_82B30C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB30Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Cu, 5u, 3u, cpu.address("absx", 0x027Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B30C STA
    hw.write(cpu.address("absx", 0x27Eu), cpu.a, cpu.m8?8:16);
    goto L_82B30F;
L_82B30F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB30Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B30F LDA
    cpu.setA(0xFCu, 8);
    goto L_82B311;
L_82B311:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB311u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB311u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB311u, 5u, 3u, cpu.address("absy", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B311 STA
    hw.write(cpu.address("absy", 0x20Au), cpu.a, cpu.m8?8:16);
    goto L_82B314;
L_82B314:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB314u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB314u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB314u, 5u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B314 STA
    hw.write(cpu.address("absy", 0x20Bu), cpu.a, cpu.m8?8:16);
    goto L_82B317;
L_82B317:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB317u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB317u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB317u, 5u, 3u, cpu.address("absy", 0x0226u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B317 STA
    hw.write(cpu.address("absy", 0x226u), cpu.a, cpu.m8?8:16);
    goto L_82B31A;
L_82B31A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB31Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Au,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Au, 5u, 3u, cpu.address("absy", 0x0227u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B31A STA
    hw.write(cpu.address("absy", 0x227u), cpu.a, cpu.m8?8:16);
    goto L_82B31D;
L_82B31D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB31Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Du,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B31D INY
    cpu.inc('Y');
    goto L_82B31E;
L_82B31E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB31Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Eu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B31E INY
    cpu.inc('Y');
    goto L_82B31F;
L_82B31F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB31Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B31F INY
    cpu.inc('Y');
    goto L_82B320;
L_82B320:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB320u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB320u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB320u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B320 INY
    cpu.inc('Y');
    goto L_82B321;
L_82B321:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB321u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB321u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB321u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B321 INY
    cpu.inc('Y');
    goto L_82B322;
L_82B322:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB322u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB322u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB322u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B322 INY
    cpu.inc('Y');
    goto L_82B323;
L_82B323:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB323u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB323u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB323u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B323 INX
    cpu.inc('X');
    goto L_82B324;
L_82B324:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB324u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB324u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB324u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B324 INX
    cpu.inc('X');
    goto L_82B325;
L_82B325:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB325u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB325u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB325u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B325 DEC
    cpu.decMem(hw, cpu.address("dp", 0x1Au), cpu.m8?8:16);
    goto L_82B327;
L_82B327:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB327u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB327u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB327u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B327 BPL -> $82B2EE
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82B2EE; }
    goto L_82B329;
L_82B329:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB329u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB329u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB329u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B329 REP
    cpu.rep(0x20u);
    goto L_82B32B;
L_82B32B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB32Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB32Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB32Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B32B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B32Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B32Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82BCD0_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82BCD0u: goto L_82BCD0;
    case 0x82BCD2u: goto L_82BCD2;
    case 0x82BCD5u: goto L_82BCD5;
    case 0x82BCD7u: goto L_82BCD7;
    case 0x82BCDAu: goto L_82BCDA;
    case 0x82BCDDu: goto L_82BCDD;
    case 0x82BCE0u: goto L_82BCE0;
    case 0x82BCE1u: goto L_82BCE1;
    case 0x82BCE2u: goto L_82BCE2;
    case 0x82BCE3u: goto L_82BCE3;
    case 0x82BCE4u: goto L_82BCE4;
    case 0x82BCE6u: goto L_82BCE6;
    case 0x82BCE8u: goto L_82BCE8;
    case 0x82BCEBu: goto L_82BCEB;
    case 0x82BCEDu: goto L_82BCED;
    case 0x82BCF0u: goto L_82BCF0;
    case 0x82BCF3u: goto L_82BCF3;
    case 0x82BCF6u: goto L_82BCF6;
    case 0x82BCF7u: goto L_82BCF7;
    case 0x82BCF8u: goto L_82BCF8;
    case 0x82BCF9u: goto L_82BCF9;
    case 0x82BCFAu: goto L_82BCFA;
    case 0x82BCFCu: goto L_82BCFC;
    case 0x82BCFEu: goto L_82BCFE;
    case 0x82BD01u: goto L_82BD01;
    case 0x82BD03u: goto L_82BD03;
    case 0x82BD06u: goto L_82BD06;
    case 0x82BD09u: goto L_82BD09;
    case 0x82BD0Cu: goto L_82BD0C;
    case 0x82BD0Du: goto L_82BD0D;
    case 0x82BD0Eu: goto L_82BD0E;
    case 0x82BD0Fu: goto L_82BD0F;
    case 0x82BD10u: goto L_82BD10;
    case 0x82BD12u: goto L_82BD12;
    case 0x82BD14u: goto L_82BD14;
    case 0x82BD17u: goto L_82BD17;
    case 0x82BD19u: goto L_82BD19;
    case 0x82BD1Cu: goto L_82BD1C;
    case 0x82BD1Fu: goto L_82BD1F;
    case 0x82BD22u: goto L_82BD22;
    case 0x82BD23u: goto L_82BD23;
    case 0x82BD24u: goto L_82BD24;
    case 0x82BD25u: goto L_82BD25;
    case 0x82BD26u: goto L_82BD26;
    case 0x82BD28u: goto L_82BD28;
    case 0x82BD2Au: goto L_82BD2A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82BCD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCD0u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCD0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BCD0 REP
    cpu.rep(0x20u);
    goto L_82BCD2;
L_82BCD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCD2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCD2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BCD2 LDA
    cpu.setA(0x4u, 16);
    goto L_82BCD5;
L_82BCD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCD5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCD5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BCD5 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82BCD7;
L_82BCD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCD7u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCD7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BCD7 LDX
    cpu.setX(0x0u, 16);
    goto L_82BCDA;
L_82BCDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCDAu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCDAu, 5u + 1u, 3u, cpu.address("absy", 0x1700u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BCDA LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1700u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BCDD;
L_82BCDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCDDu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCDDu, 6u, 3u, cpu.address("absx", 0x0629u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BCDD STA
    hw.write(cpu.address("absx", 0x629u), cpu.a, cpu.m8?8:16);
    goto L_82BCE0;
L_82BCE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCE0u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCE0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BCE0 INX
    cpu.inc('X');
    goto L_82BCE1;
L_82BCE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCE1u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCE1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BCE1 INX
    cpu.inc('X');
    goto L_82BCE2;
L_82BCE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCE2u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCE2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BCE2 INY
    cpu.inc('Y');
    goto L_82BCE3;
L_82BCE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCE3u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCE3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BCE3 INY
    cpu.inc('Y');
    goto L_82BCE4;
L_82BCE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCE4u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCE4u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BCE4 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_82BCE6;
L_82BCE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCE6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCE6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BCE6 BNE -> $82BCDA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82BCDA; }
    goto L_82BCE8;
L_82BCE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCE8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCE8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BCE8 LDA
    cpu.setA(0x12u, 16);
    goto L_82BCEB;
L_82BCEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCEBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCEBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BCEB STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82BCED;
L_82BCED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCEDu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCEDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BCED LDX
    cpu.setX(0x0u, 16);
    goto L_82BCF0;
L_82BCF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF0u, 5u + 1u, 3u, cpu.address("absy", 0x1700u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BCF0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1700u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BCF3;
L_82BCF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF3u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF3u, 6u, 3u, cpu.address("absx", 0x0633u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BCF3 STA
    hw.write(cpu.address("absx", 0x633u), cpu.a, cpu.m8?8:16);
    goto L_82BCF6;
L_82BCF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF6u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BCF6 INX
    cpu.inc('X');
    goto L_82BCF7;
L_82BCF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF7u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BCF7 INX
    cpu.inc('X');
    goto L_82BCF8;
L_82BCF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF8u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BCF8 INY
    cpu.inc('Y');
    goto L_82BCF9;
L_82BCF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF9u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BCF9 INY
    cpu.inc('Y');
    goto L_82BCFA;
L_82BCFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCFAu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCFAu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BCFA DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_82BCFC;
L_82BCFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCFCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCFCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BCFC BNE -> $82BCF0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82BCF0; }
    goto L_82BCFE;
L_82BCFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCFEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCFEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BCFE LDA
    cpu.setA(0x1Eu, 16);
    goto L_82BD01;
L_82BD01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD01u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD01u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD01 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82BD03;
L_82BD03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD03u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD03u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD03 LDX
    cpu.setX(0x0u, 16);
    goto L_82BD06;
L_82BD06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD06u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD06u, 5u + 1u, 3u, cpu.address("absy", 0x1700u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD06 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1700u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BD09;
L_82BD09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD09u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD09u, 6u, 3u, cpu.address("absx", 0x0670u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD09 STA
    hw.write(cpu.address("absx", 0x670u), cpu.a, cpu.m8?8:16);
    goto L_82BD0C;
L_82BD0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD0Cu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD0Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD0C INX
    cpu.inc('X');
    goto L_82BD0D;
L_82BD0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD0Du,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD0Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD0D INX
    cpu.inc('X');
    goto L_82BD0E;
L_82BD0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD0Eu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD0Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD0E INY
    cpu.inc('Y');
    goto L_82BD0F;
L_82BD0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD0Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD0Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD0F INY
    cpu.inc('Y');
    goto L_82BD10;
L_82BD10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD10u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD10u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD10 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_82BD12;
L_82BD12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD12u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD12u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD12 BNE -> $82BD06
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82BD06; }
    goto L_82BD14;
L_82BD14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD14u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD14u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD14 LDA
    cpu.setA(0x7u, 16);
    goto L_82BD17;
L_82BD17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD17u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD17u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD17 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82BD19;
L_82BD19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD19u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD19u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD19 LDX
    cpu.setX(0x0u, 16);
    goto L_82BD1C;
L_82BD1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD1Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD1Cu, 5u + 1u, 3u, cpu.address("absy", 0x1700u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD1C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1700u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BD1F;
L_82BD1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD1Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD1Fu, 6u, 3u, cpu.address("absx", 0x06B0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD1F STA
    hw.write(cpu.address("absx", 0x6B0u), cpu.a, cpu.m8?8:16);
    goto L_82BD22;
L_82BD22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD22u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD22u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD22 INX
    cpu.inc('X');
    goto L_82BD23;
L_82BD23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD23u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD23u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD23 INX
    cpu.inc('X');
    goto L_82BD24;
L_82BD24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD24u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD24u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD24 INY
    cpu.inc('Y');
    goto L_82BD25;
L_82BD25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD25u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD25u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD25 INY
    cpu.inc('Y');
    goto L_82BD26;
L_82BD26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD26u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD26u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD26 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_82BD28;
L_82BD28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD28u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD28u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD28 BNE -> $82BD1C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82BD1C; }
    goto L_82BD2A;
L_82BD2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD2Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD2Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82BD2A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82BD2Au);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82BD2Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82C0BC_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82C0BCu: goto L_82C0BC;
    case 0x82C0BFu: goto L_82C0BF;
    case 0x82C0C1u: goto L_82C0C1;
    case 0x82C0C4u: goto L_82C0C4;
    case 0x82C0C5u: goto L_82C0C5;
    case 0x82C0C8u: goto L_82C0C8;
    case 0x82C0CAu: goto L_82C0CA;
    case 0x82C0CDu: goto L_82C0CD;
    case 0x82C0D0u: goto L_82C0D0;
    case 0x82C0D3u: goto L_82C0D3;
    case 0x82C0D6u: goto L_82C0D6;
    case 0x82C0D8u: goto L_82C0D8;
    case 0x82C0DBu: goto L_82C0DB;
    case 0x82C0DEu: goto L_82C0DE;
    case 0x82C0DFu: goto L_82C0DF;
    case 0x82C0E2u: goto L_82C0E2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82C0BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0BCu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0BCu, 5u, 3u, cpu.address("abs", 0x013Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C0BC LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C0BF;
L_82C0BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0BFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0BFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C0BF BEQ -> $82C0C5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C0C5; }
    goto L_82C0C1;
L_82C0C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0C1u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0C1u, 8u, 3u, cpu.address("abs", 0x013Du), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C0C1 DEC
    cpu.decMem(hw, cpu.address("abs", 0x13Du), cpu.m8?8:16);
    goto L_82C0C4;
L_82C0C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0C4u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0C4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C0C4 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C0C4u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C0C4u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82C0C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0C5u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0C5u, 5u, 3u, cpu.address("abs", 0x017Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C0C5 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x17Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C0C8;
L_82C0C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0C8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C0C8 BEQ -> $82C0DF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C0DF; }
    goto L_82C0CA;
L_82C0CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0CAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0CAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C0CA LDA
    cpu.setA(0x7u, 16);
    goto L_82C0CD;
L_82C0CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0CDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0CDu, 5u, 3u, cpu.address("abs", 0x013Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C0CD STA
    hw.write(cpu.address("abs", 0x13Du), cpu.a, cpu.m8?8:16);
    goto L_82C0D0;
L_82C0D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0D0u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0D0u, 8u, 3u, cpu.address("abs", 0x017Du), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C0D0 DEC
    cpu.decMem(hw, cpu.address("abs", 0x17Du), cpu.m8?8:16);
    goto L_82C0D3;
L_82C0D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0D3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0D3u, 5u, 3u, cpu.address("abs", 0x017Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C0D3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x17Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C0D6;
L_82C0D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0D6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C0D6 BEQ -> $82C0DB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C0DB; }
    goto L_82C0D8;
L_82C0D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0D8u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0D8u, 8u, 3u, cpu.address("abs", 0x017Fu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C0D8 DEC
    cpu.decMem(hw, cpu.address("abs", 0x17Fu), cpu.m8?8:16);
    goto L_82C0DB;
L_82C0DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0DBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0DBu, 6u, 3u, cpu.address("abs", 0xD05Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C0DB JSR -> $82D05B stack real
    { cpu.push16Value(hw,0xC0DDu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC0DEu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD05Bu), 0x82C0DBu); }
    goto L_82C0DE;
L_82C0DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0DEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC0DEu,0x82C0DEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0DEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0DEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C0DE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C0DEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C0DEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82C0DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0DFu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0DFu, 8u, 3u, cpu.address("abs", 0x013Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C0DF INC
    cpu.incMem(hw, cpu.address("abs", 0x13Bu), cpu.m8?8:16);
    goto L_82C0E2;
L_82C0E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0E2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0E2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C0E2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C0E2u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C0E2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82C781_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82C781u: goto L_82C781;
    case 0x82C784u: goto L_82C784;
    case 0x82C786u: goto L_82C786;
    case 0x82C788u: goto L_82C788;
    case 0x82C78Bu: goto L_82C78B;
    case 0x82C78Du: goto L_82C78D;
    case 0x82C790u: goto L_82C790;
    case 0x82C793u: goto L_82C793;
    case 0x82C796u: goto L_82C796;
    case 0x82C798u: goto L_82C798;
    case 0x82C79Bu: goto L_82C79B;
    case 0x82C79Eu: goto L_82C79E;
    case 0x82C7A1u: goto L_82C7A1;
    case 0x82C7A4u: goto L_82C7A4;
    case 0x82C7A6u: goto L_82C7A6;
    case 0x82C7A9u: goto L_82C7A9;
    case 0x82C7ACu: goto L_82C7AC;
    case 0x82C7AFu: goto L_82C7AF;
    case 0x82C7B2u: goto L_82C7B2;
    case 0x82C7B5u: goto L_82C7B5;
    case 0x82C7B8u: goto L_82C7B8;
    case 0x82C7BBu: goto L_82C7BB;
    case 0x82C7BFu: goto L_82C7BF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82C781:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC781u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC781u,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC781u, 5u, 3u, cpu.address("abs", 0x0148u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C781 BIT
    cpu.bit(hw.readW(cpu.address("abs", 0x148u), cpu.m8?8:16), false);
    goto L_82C784;
L_82C784:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC784u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC784u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC784u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C784 BMI -> $82C7A1
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82C7A1; }
    goto L_82C786;
L_82C786:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC786u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC786u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC786u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C786 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C788;
L_82C788:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC788u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC788u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC788u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C788 AND
    cpu.logicAnd(0x7u);
    goto L_82C78B;
L_82C78B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC78Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC78Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC78Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C78B BNE -> $82C7BF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C7BF; }
    goto L_82C78D;
L_82C78D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC78Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC78Du,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC78Du, 8u, 3u, cpu.address("abs", 0x0148u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C78D INC
    cpu.incMem(hw, cpu.address("abs", 0x148u), cpu.m8?8:16);
    goto L_82C790;
L_82C790:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC790u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC790u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC790u, 5u, 3u, cpu.address("abs", 0x0148u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C790 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x148u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C793;
L_82C793:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC793u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC793u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC793u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C793 CMP
    cpu.compareA(0xAu);
    goto L_82C796;
L_82C796:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC796u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC796u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC796u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C796 BCC -> $82C79B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82C79B; }
    goto L_82C798;
L_82C798:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC798u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC798u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC798u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C798 LDA
    cpu.setA(0x0u, 16);
    goto L_82C79B;
L_82C79B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC79Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC79Bu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC79Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C79B ORA
    cpu.logicOr(0x8000u);
    goto L_82C79E;
L_82C79E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC79Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC79Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC79Eu, 5u, 3u, cpu.address("abs", 0x0148u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C79E STA
    hw.write(cpu.address("abs", 0x148u), cpu.a, cpu.m8?8:16);
    goto L_82C7A1;
L_82C7A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7A1u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A1u, 5u, 3u, cpu.address("abs", 0x014Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C7A1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x14Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C7A4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A1u, 5u, 3u, cpu.address("abs", 0x014Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C7A1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x14Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C7A4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC7A1u,0x82C7A1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C7A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7A4u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C7A4 BNE -> $82C7BF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C7BF; }
    goto L_82C7A6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C7A4 BNE -> $82C7BF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C7BF; }
    goto L_82C7A6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC7A4u,0x82C7A4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C7A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7A6u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A6u, 6u, 3u, cpu.address("abs", 0xC7C0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C7A6 JSR -> $82C7C0 stack real
    { cpu.push16Value(hw,0xC7A8u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC7A9u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC7C0u), 0x82C7A6u); }
    goto L_82C7A9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A6u, 6u, 3u, cpu.address("abs", 0xC7C0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C7A6 JSR -> $82C7C0 stack real
    { cpu.push16Value(hw,0xC7A8u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC7A9u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC7C0u), 0x82C7A6u); }
    goto L_82C7A9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC7A6u,0x82C7A6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C7A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7A9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC7A9u,0x82C7A9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A9u, 6u, 3u, cpu.address("abs", 0xC98Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C7A9 JSR -> $82C98B stack real
    { cpu.push16Value(hw,0xC7ABu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC7ACu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC98Bu), 0x82C7A9u); }
    goto L_82C7AC;
L_82C7AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7ACu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC7ACu,0x82C7ACu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7ACu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7ACu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C7AC LDA
    cpu.setA(0x8000u, 16);
    goto L_82C7AF;
L_82C7AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7AFu,cpu,0x1Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7AFu, 8u, 3u, cpu.address("abs", 0x0148u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C7AF TRB
    cpu.trb(hw, cpu.address("abs", 0x148u), cpu.m8?8:16);
    goto L_82C7B2;
L_82C7B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C7B2 LDA
    cpu.setA(0x580u, 16);
    goto L_82C7B5;
L_82C7B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B5u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C7B5 LDX
    cpu.setX(0x6100u, 16);
    goto L_82C7B8;
L_82C7B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B8u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C7B8 LDY
    cpu.setY(0x5C80u, 16);
    goto L_82C7BB;
L_82C7BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7BBu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7BBu, 8u, 4u, 0x808EBFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82C7BB JSL -> $808EBF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC7BEu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC7BFu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808EBFu, 0x82C7BBu); }
    goto L_82C7BF;
L_82C7BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7BFu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7BFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7BFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C7BF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C7BFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C7BFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7BFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7BFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C7BF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C7BFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C7BFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC7BFu,0x82C7BFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82C781_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82C781u: goto L_82C781;
    case 0x82C784u: goto L_82C784;
    case 0x82C786u: goto L_82C786;
    case 0x82C788u: goto L_82C788;
    case 0x82C78Bu: goto L_82C78B;
    case 0x82C78Du: goto L_82C78D;
    case 0x82C790u: goto L_82C790;
    case 0x82C793u: goto L_82C793;
    case 0x82C796u: goto L_82C796;
    case 0x82C798u: goto L_82C798;
    case 0x82C79Bu: goto L_82C79B;
    case 0x82C79Eu: goto L_82C79E;
    case 0x82C7A1u: goto L_82C7A1;
    case 0x82C7A4u: goto L_82C7A4;
    case 0x82C7A6u: goto L_82C7A6;
    case 0x82C7A9u: goto L_82C7A9;
    case 0x82C7ACu: goto L_82C7AC;
    case 0x82C7AFu: goto L_82C7AF;
    case 0x82C7B2u: goto L_82C7B2;
    case 0x82C7B5u: goto L_82C7B5;
    case 0x82C7B8u: goto L_82C7B8;
    case 0x82C7BBu: goto L_82C7BB;
    case 0x82C7BFu: goto L_82C7BF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82C781:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC781u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC781u,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC781u, 5u, 3u, cpu.address("abs", 0x0148u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C781 BIT
    cpu.bit(hw.readW(cpu.address("abs", 0x148u), cpu.m8?8:16), false);
    goto L_82C784;
L_82C784:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC784u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC784u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC784u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C784 BMI -> $82C7A1
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82C7A1; }
    goto L_82C786;
L_82C786:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC786u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC786u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC786u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C786 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C788;
L_82C788:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC788u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC788u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC788u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C788 AND
    cpu.logicAnd(0x7u);
    goto L_82C78B;
L_82C78B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC78Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC78Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC78Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C78B BNE -> $82C7BF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C7BF; }
    goto L_82C78D;
L_82C78D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC78Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC78Du,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC78Du, 8u, 3u, cpu.address("abs", 0x0148u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C78D INC
    cpu.incMem(hw, cpu.address("abs", 0x148u), cpu.m8?8:16);
    goto L_82C790;
L_82C790:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC790u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC790u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC790u, 5u, 3u, cpu.address("abs", 0x0148u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C790 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x148u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C793;
L_82C793:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC793u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC793u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC793u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C793 CMP
    cpu.compareA(0xAu);
    goto L_82C796;
L_82C796:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC796u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC796u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC796u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C796 BCC -> $82C79B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82C79B; }
    goto L_82C798;
L_82C798:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC798u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC798u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC798u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C798 LDA
    cpu.setA(0x0u, 16);
    goto L_82C79B;
L_82C79B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC79Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC79Bu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC79Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C79B ORA
    cpu.logicOr(0x8000u);
    goto L_82C79E;
L_82C79E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC79Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC79Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC79Eu, 5u, 3u, cpu.address("abs", 0x0148u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C79E STA
    hw.write(cpu.address("abs", 0x148u), cpu.a, cpu.m8?8:16);
    goto L_82C7A1;
L_82C7A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7A1u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A1u, 5u, 3u, cpu.address("abs", 0x014Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C7A1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x14Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C7A4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A1u, 5u, 3u, cpu.address("abs", 0x014Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C7A1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x14Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C7A4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC7A1u,0x82C7A1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C7A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7A4u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C7A4 BNE -> $82C7BF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C7BF; }
    goto L_82C7A6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C7A4 BNE -> $82C7BF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C7BF; }
    goto L_82C7A6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC7A4u,0x82C7A4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C7A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7A6u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A6u, 6u, 3u, cpu.address("abs", 0xC7C0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C7A6 JSR -> $82C7C0 stack real
    { cpu.push16Value(hw,0xC7A8u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC7A9u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC7C0u), 0x82C7A6u); }
    goto L_82C7A9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A6u, 6u, 3u, cpu.address("abs", 0xC7C0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C7A6 JSR -> $82C7C0 stack real
    { cpu.push16Value(hw,0xC7A8u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC7A9u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC7C0u), 0x82C7A6u); }
    goto L_82C7A9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC7A6u,0x82C7A6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C7A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7A9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC7A9u,0x82C7A9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A9u, 6u, 3u, cpu.address("abs", 0xC98Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C7A9 JSR -> $82C98B stack real
    { cpu.push16Value(hw,0xC7ABu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC7ACu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC98Bu), 0x82C7A9u); }
    goto L_82C7AC;
L_82C7AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7ACu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC7ACu,0x82C7ACu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7ACu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7ACu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C7AC LDA
    cpu.setA(0x8000u, 16);
    goto L_82C7AF;
L_82C7AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7AFu,cpu,0x1Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7AFu, 8u, 3u, cpu.address("abs", 0x0148u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C7AF TRB
    cpu.trb(hw, cpu.address("abs", 0x148u), cpu.m8?8:16);
    goto L_82C7B2;
L_82C7B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C7B2 LDA
    cpu.setA(0x580u, 16);
    goto L_82C7B5;
L_82C7B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B5u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C7B5 LDX
    cpu.setX(0x6100u, 16);
    goto L_82C7B8;
L_82C7B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B8u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C7B8 LDY
    cpu.setY(0x5C80u, 16);
    goto L_82C7BB;
L_82C7BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7BBu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7BBu, 8u, 4u, 0x808EBFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82C7BB JSL -> $808EBF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC7BEu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC7BFu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808EBFu, 0x82C7BBu); }
    goto L_82C7BF;
L_82C7BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7BFu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7BFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7BFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C7BF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C7BFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C7BFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7BFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7BFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C7BF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C7BFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C7BFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC7BFu,0x82C7BFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82C781_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82C781u: goto L_82C781;
    case 0x82C784u: goto L_82C784;
    case 0x82C786u: goto L_82C786;
    case 0x82C788u: goto L_82C788;
    case 0x82C78Bu: goto L_82C78B;
    case 0x82C78Du: goto L_82C78D;
    case 0x82C790u: goto L_82C790;
    case 0x82C793u: goto L_82C793;
    case 0x82C796u: goto L_82C796;
    case 0x82C798u: goto L_82C798;
    case 0x82C79Bu: goto L_82C79B;
    case 0x82C79Eu: goto L_82C79E;
    case 0x82C7A1u: goto L_82C7A1;
    case 0x82C7A4u: goto L_82C7A4;
    case 0x82C7A6u: goto L_82C7A6;
    case 0x82C7A9u: goto L_82C7A9;
    case 0x82C7ACu: goto L_82C7AC;
    case 0x82C7AFu: goto L_82C7AF;
    case 0x82C7B2u: goto L_82C7B2;
    case 0x82C7B5u: goto L_82C7B5;
    case 0x82C7B8u: goto L_82C7B8;
    case 0x82C7BBu: goto L_82C7BB;
    case 0x82C7BFu: goto L_82C7BF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82C781:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC781u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC781u,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC781u, 5u, 3u, cpu.address("abs", 0x0148u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C781 BIT
    cpu.bit(hw.readW(cpu.address("abs", 0x148u), cpu.m8?8:16), false);
    goto L_82C784;
L_82C784:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC784u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC784u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC784u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C784 BMI -> $82C7A1
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82C7A1; }
    goto L_82C786;
L_82C786:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC786u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC786u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC786u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C786 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C788;
L_82C788:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC788u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC788u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC788u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C788 AND
    cpu.logicAnd(0x7u);
    goto L_82C78B;
L_82C78B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC78Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC78Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC78Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C78B BNE -> $82C7BF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C7BF; }
    goto L_82C78D;
L_82C78D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC78Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC78Du,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC78Du, 8u, 3u, cpu.address("abs", 0x0148u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C78D INC
    cpu.incMem(hw, cpu.address("abs", 0x148u), cpu.m8?8:16);
    goto L_82C790;
L_82C790:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC790u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC790u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC790u, 5u, 3u, cpu.address("abs", 0x0148u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C790 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x148u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C793;
L_82C793:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC793u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC793u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC793u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C793 CMP
    cpu.compareA(0xAu);
    goto L_82C796;
L_82C796:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC796u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC796u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC796u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C796 BCC -> $82C79B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82C79B; }
    goto L_82C798;
L_82C798:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC798u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC798u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC798u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C798 LDA
    cpu.setA(0x0u, 16);
    goto L_82C79B;
L_82C79B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC79Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC79Bu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC79Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C79B ORA
    cpu.logicOr(0x8000u);
    goto L_82C79E;
L_82C79E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC79Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC79Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC79Eu, 5u, 3u, cpu.address("abs", 0x0148u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C79E STA
    hw.write(cpu.address("abs", 0x148u), cpu.a, cpu.m8?8:16);
    goto L_82C7A1;
L_82C7A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A1u, 5u, 3u, cpu.address("abs", 0x014Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C7A1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x14Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C7A4;
L_82C7A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C7A4 BNE -> $82C7BF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C7BF; }
    goto L_82C7A6;
L_82C7A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A6u, 6u, 3u, cpu.address("abs", 0xC7C0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C7A6 JSR -> $82C7C0 stack real
    { cpu.push16Value(hw,0xC7A8u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC7A9u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC7C0u), 0x82C7A6u); }
    goto L_82C7A9;
L_82C7A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7A9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC7A9u,0x82C7A9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A9u, 6u, 3u, cpu.address("abs", 0xC98Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C7A9 JSR -> $82C98B stack real
    { cpu.push16Value(hw,0xC7ABu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC7ACu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC98Bu), 0x82C7A9u); }
    goto L_82C7AC;
L_82C7AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7ACu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC7ACu,0x82C7ACu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7ACu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7ACu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C7AC LDA
    cpu.setA(0x8000u, 16);
    goto L_82C7AF;
L_82C7AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7AFu,cpu,0x1Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7AFu, 8u, 3u, cpu.address("abs", 0x0148u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C7AF TRB
    cpu.trb(hw, cpu.address("abs", 0x148u), cpu.m8?8:16);
    goto L_82C7B2;
L_82C7B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C7B2 LDA
    cpu.setA(0x580u, 16);
    goto L_82C7B5;
L_82C7B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B5u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C7B5 LDX
    cpu.setX(0x6100u, 16);
    goto L_82C7B8;
L_82C7B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B8u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C7B8 LDY
    cpu.setY(0x5C80u, 16);
    goto L_82C7BB;
L_82C7BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7BBu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7BBu, 8u, 4u, 0x808EBFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82C7BB JSL -> $808EBF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC7BEu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC7BFu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808EBFu, 0x82C7BBu); }
    goto L_82C7BF;
L_82C7BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7BFu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC7BFu,0x82C7BFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7BFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7BFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C7BF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C7BFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C7BFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82CCB0_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82CCB0u: goto L_82CCB0;
    case 0x82CCB2u: goto L_82CCB2;
    case 0x82CCB6u: goto L_82CCB6;
    case 0x82CCB8u: goto L_82CCB8;
    case 0x82CCBBu: goto L_82CCBB;
    case 0x82CCBCu: goto L_82CCBC;
    case 0x82CCBDu: goto L_82CCBD;
    case 0x82CCC1u: goto L_82CCC1;
    case 0x82CCC2u: goto L_82CCC2;
    case 0x82CCC6u: goto L_82CCC6;
    case 0x82CCC8u: goto L_82CCC8;
    case 0x82CCCCu: goto L_82CCCC;
    case 0x82CCCEu: goto L_82CCCE;
    case 0x82CCD0u: goto L_82CCD0;
    case 0x82CCD3u: goto L_82CCD3;
    case 0x82CCD4u: goto L_82CCD4;
    case 0x82CCD5u: goto L_82CCD5;
    case 0x82CCD9u: goto L_82CCD9;
    case 0x82CCDAu: goto L_82CCDA;
    case 0x82CCDEu: goto L_82CCDE;
    case 0x82CCE0u: goto L_82CCE0;
    case 0x82CCE2u: goto L_82CCE2;
    case 0x82CCE3u: goto L_82CCE3;
    case 0x82CCE6u: goto L_82CCE6;
    case 0x82CCE8u: goto L_82CCE8;
    case 0x82CCECu: goto L_82CCEC;
    case 0x82CCEEu: goto L_82CCEE;
    case 0x82CCF0u: goto L_82CCF0;
    case 0x82CCF3u: goto L_82CCF3;
    case 0x82CCF4u: goto L_82CCF4;
    case 0x82CCF5u: goto L_82CCF5;
    case 0x82CCF9u: goto L_82CCF9;
    case 0x82CCFAu: goto L_82CCFA;
    case 0x82CCFEu: goto L_82CCFE;
    case 0x82CD00u: goto L_82CD00;
    case 0x82CD02u: goto L_82CD02;
    case 0x82CD03u: goto L_82CD03;
    case 0x82CD06u: goto L_82CD06;
    case 0x82CD08u: goto L_82CD08;
    case 0x82CD0Cu: goto L_82CD0C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82CCB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCB0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCB0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCB0 STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_82CCB2;
L_82CCB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCB2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCB2u, 8u, 4u, 0x809315u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82CCB2 JSL -> $809315 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCCB5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCCB6u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809315u, 0x82CCB2u); }
    goto L_82CCB6;
L_82CCB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCB6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCCB6u,0x82CCB6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCB6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCB6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCB6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CCB8;
L_82CCB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCB8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCB8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCB8 AND
    cpu.logicAnd(0xFFu);
    goto L_82CCBB;
L_82CCBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCBBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCBBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCBB ASL
    cpu.aslA();
    goto L_82CCBC;
L_82CCBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCBCu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCBCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCBC TAX
    cpu.transfer("TAX");
    goto L_82CCBD;
L_82CCBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCBDu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCBDu, 6u, 4u, ((0x9E95C2u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCBD LDA
    cpu.loadA(hw.readW(((0x9E95C2u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CCC1;
L_82CCC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCC1u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCC1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCC1 TAX
    cpu.transfer("TAX");
    goto L_82CCC2;
L_82CCC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCC2u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCC2u, 6u, 4u, ((0x9E8232u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCC2 LDA
    cpu.loadA(hw.readW(((0x9E8232u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CCC6;
L_82CCC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCC6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCC6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCC6 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82CCC8;
L_82CCC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCC8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCC8u, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82CCC8 JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCCCBu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCCCCu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x82CCC8u); }
    goto L_82CCCC;
L_82CCCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCCCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCCCCu,0x82CCCCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCCCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCCCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCCC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CCCE;
L_82CCCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCCEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCCEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCCE BEQ -> $82CD0C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CD0C; }
    goto L_82CCD0;
L_82CCD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCD0u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCD0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCD0 AND
    cpu.logicAnd(0xFFu);
    goto L_82CCD3;
L_82CCD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCD3u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCD3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCD3 ASL
    cpu.aslA();
    goto L_82CCD4;
L_82CCD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCD4u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCD4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCD4 TAX
    cpu.transfer("TAX");
    goto L_82CCD5;
L_82CCD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCD5u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCD5u, 6u, 4u, ((0x9E95C2u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCD5 LDA
    cpu.loadA(hw.readW(((0x9E95C2u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CCD9;
L_82CCD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCD9u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCD9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCD9 TAX
    cpu.transfer("TAX");
    goto L_82CCDA;
L_82CCDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCDAu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCDAu, 6u, 4u, ((0x9E8232u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCDA LDA
    cpu.loadA(hw.readW(((0x9E8232u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CCDE;
L_82CCDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCDEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCDEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCDE STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82CCE0;
L_82CCE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCE0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCE0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCE0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CCE2;
L_82CCE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCE2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCE2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCE2 SEC
    cpu.setFlag('C', true);
    goto L_82CCE3;
L_82CCE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCE3u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCE3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCE3 SBC
    cpu.sbc(0x8u);
    goto L_82CCE6;
L_82CCE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCE6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCE6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCE6 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82CCE8;
L_82CCE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCE8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCE8u, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82CCE8 JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCCEBu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCCECu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x82CCE8u); }
    goto L_82CCEC;
L_82CCEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCECu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCCECu,0x82CCECu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCECu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCECu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCEC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CCEE;
L_82CCEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCEEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCEEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCEE BEQ -> $82CD0C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CD0C; }
    goto L_82CCF0;
L_82CCF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF0u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCF0 AND
    cpu.logicAnd(0xFFu);
    goto L_82CCF3;
L_82CCF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF3u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCF3 ASL
    cpu.aslA();
    goto L_82CCF4;
L_82CCF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF4u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCF4 TAX
    cpu.transfer("TAX");
    goto L_82CCF5;
L_82CCF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF5u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF5u, 6u, 4u, ((0x9E95C2u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCF5 LDA
    cpu.loadA(hw.readW(((0x9E95C2u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CCF9;
L_82CCF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF9u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCF9 TAX
    cpu.transfer("TAX");
    goto L_82CCFA;
L_82CCFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCFAu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCFAu, 6u, 4u, ((0x9E8232u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCFA LDA
    cpu.loadA(hw.readW(((0x9E8232u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CCFE;
L_82CCFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCFEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCFEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCFE STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82CD00;
L_82CD00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD00u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD00u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD00 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CD02;
L_82CD02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD02u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD02u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD02 SEC
    cpu.setFlag('C', true);
    goto L_82CD03;
L_82CD03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD03u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD03u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD03 SBC
    cpu.sbc(0x8u);
    goto L_82CD06;
L_82CD06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD06u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD06u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD06 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82CD08;
L_82CD08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD08u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD08u, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82CD08 JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCD0Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCD0Cu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x82CD08u); }
    goto L_82CD0C;
L_82CD0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD0Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD0Cu,0x82CD0Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD0Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD0Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CD0C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82CD0Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82CD0Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82CCB0_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82CCB0u: goto L_82CCB0;
    case 0x82CCB2u: goto L_82CCB2;
    case 0x82CCB6u: goto L_82CCB6;
    case 0x82CCB8u: goto L_82CCB8;
    case 0x82CCBBu: goto L_82CCBB;
    case 0x82CCBCu: goto L_82CCBC;
    case 0x82CCBDu: goto L_82CCBD;
    case 0x82CCC1u: goto L_82CCC1;
    case 0x82CCC2u: goto L_82CCC2;
    case 0x82CCC6u: goto L_82CCC6;
    case 0x82CCC8u: goto L_82CCC8;
    case 0x82CCCCu: goto L_82CCCC;
    case 0x82CCCEu: goto L_82CCCE;
    case 0x82CCD0u: goto L_82CCD0;
    case 0x82CCD3u: goto L_82CCD3;
    case 0x82CCD4u: goto L_82CCD4;
    case 0x82CCD5u: goto L_82CCD5;
    case 0x82CCD9u: goto L_82CCD9;
    case 0x82CCDAu: goto L_82CCDA;
    case 0x82CCDEu: goto L_82CCDE;
    case 0x82CCE0u: goto L_82CCE0;
    case 0x82CCE2u: goto L_82CCE2;
    case 0x82CCE3u: goto L_82CCE3;
    case 0x82CCE6u: goto L_82CCE6;
    case 0x82CCE8u: goto L_82CCE8;
    case 0x82CCECu: goto L_82CCEC;
    case 0x82CCEEu: goto L_82CCEE;
    case 0x82CCF0u: goto L_82CCF0;
    case 0x82CCF3u: goto L_82CCF3;
    case 0x82CCF4u: goto L_82CCF4;
    case 0x82CCF5u: goto L_82CCF5;
    case 0x82CCF9u: goto L_82CCF9;
    case 0x82CCFAu: goto L_82CCFA;
    case 0x82CCFEu: goto L_82CCFE;
    case 0x82CD00u: goto L_82CD00;
    case 0x82CD02u: goto L_82CD02;
    case 0x82CD03u: goto L_82CD03;
    case 0x82CD06u: goto L_82CD06;
    case 0x82CD08u: goto L_82CD08;
    case 0x82CD0Cu: goto L_82CD0C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82CCB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCB0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCB0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCB0 STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_82CCB2;
L_82CCB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCB2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCB2u, 8u, 4u, 0x809315u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82CCB2 JSL -> $809315 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCCB5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCCB6u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809315u, 0x82CCB2u); }
    goto L_82CCB6;
L_82CCB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCB6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCCB6u,0x82CCB6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCB6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCB6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCB6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CCB8;
L_82CCB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCB8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCB8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCB8 AND
    cpu.logicAnd(0xFFu);
    goto L_82CCBB;
L_82CCBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCBBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCBBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCBB ASL
    cpu.aslA();
    goto L_82CCBC;
L_82CCBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCBCu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCBCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCBC TAX
    cpu.transfer("TAX");
    goto L_82CCBD;
L_82CCBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCBDu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCBDu, 6u, 4u, ((0x9E95C2u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCBD LDA
    cpu.loadA(hw.readW(((0x9E95C2u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CCC1;
L_82CCC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCC1u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCC1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCC1 TAX
    cpu.transfer("TAX");
    goto L_82CCC2;
L_82CCC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCC2u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCC2u, 6u, 4u, ((0x9E8232u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCC2 LDA
    cpu.loadA(hw.readW(((0x9E8232u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CCC6;
L_82CCC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCC6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCC6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCC6 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82CCC8;
L_82CCC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCC8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCC8u, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82CCC8 JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCCCBu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCCCCu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x82CCC8u); }
    goto L_82CCCC;
L_82CCCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCCCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCCCCu,0x82CCCCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCCCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCCCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCCC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CCCE;
L_82CCCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCCEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCCEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCCE BEQ -> $82CD0C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CD0C; }
    goto L_82CCD0;
L_82CCD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCD0u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCD0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCD0 AND
    cpu.logicAnd(0xFFu);
    goto L_82CCD3;
L_82CCD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCD3u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCD3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCD3 ASL
    cpu.aslA();
    goto L_82CCD4;
L_82CCD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCD4u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCD4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCD4 TAX
    cpu.transfer("TAX");
    goto L_82CCD5;
L_82CCD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCD5u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCD5u, 6u, 4u, ((0x9E95C2u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCD5 LDA
    cpu.loadA(hw.readW(((0x9E95C2u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CCD9;
L_82CCD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCD9u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCD9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCD9 TAX
    cpu.transfer("TAX");
    goto L_82CCDA;
L_82CCDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCDAu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCDAu, 6u, 4u, ((0x9E8232u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCDA LDA
    cpu.loadA(hw.readW(((0x9E8232u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CCDE;
L_82CCDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCDEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCDEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCDE STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82CCE0;
L_82CCE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCE0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCE0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCE0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CCE2;
L_82CCE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCE2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCE2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCE2 SEC
    cpu.setFlag('C', true);
    goto L_82CCE3;
L_82CCE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCE3u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCE3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCE3 SBC
    cpu.sbc(0x8u);
    goto L_82CCE6;
L_82CCE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCE6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCE6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCE6 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82CCE8;
L_82CCE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCE8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCE8u, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82CCE8 JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCCEBu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCCECu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x82CCE8u); }
    goto L_82CCEC;
L_82CCEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCECu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCCECu,0x82CCECu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCECu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCECu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCEC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CCEE;
L_82CCEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCEEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCEEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCEE BEQ -> $82CD0C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CD0C; }
    goto L_82CCF0;
L_82CCF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF0u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCF0 AND
    cpu.logicAnd(0xFFu);
    goto L_82CCF3;
L_82CCF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF3u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCF3 ASL
    cpu.aslA();
    goto L_82CCF4;
L_82CCF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF4u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCF4 TAX
    cpu.transfer("TAX");
    goto L_82CCF5;
L_82CCF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF5u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF5u, 6u, 4u, ((0x9E95C2u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCF5 LDA
    cpu.loadA(hw.readW(((0x9E95C2u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CCF9;
L_82CCF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF9u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCF9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCF9 TAX
    cpu.transfer("TAX");
    goto L_82CCFA;
L_82CCFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCFAu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCFAu, 6u, 4u, ((0x9E8232u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCFA LDA
    cpu.loadA(hw.readW(((0x9E8232u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CCFE;
L_82CCFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCCFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCCFEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCCFEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CCFE STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82CD00;
L_82CD00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD00u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD00u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD00 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CD02;
L_82CD02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD02u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD02u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD02 SEC
    cpu.setFlag('C', true);
    goto L_82CD03;
L_82CD03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD03u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD03u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD03 SBC
    cpu.sbc(0x8u);
    goto L_82CD06;
L_82CD06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD06u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD06u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CD06 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82CD08;
L_82CD08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD08u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD08u, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82CD08 JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCD0Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCD0Cu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x82CD08u); }
    goto L_82CD0C;
L_82CD0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD0Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD0Cu,0x82CD0Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD0Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD0Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CD0C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82CD0Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82CD0Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82E27E_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82E27Eu: goto L_82E27E;
    case 0x82E27Fu: goto L_82E27F;
    case 0x82E281u: goto L_82E281;
    case 0x82E283u: goto L_82E283;
    case 0x82E284u: goto L_82E284;
    case 0x82E285u: goto L_82E285;
    case 0x82E287u: goto L_82E287;
    case 0x82E289u: goto L_82E289;
    case 0x82E28Au: goto L_82E28A;
    case 0x82E28Du: goto L_82E28D;
    case 0x82E28Fu: goto L_82E28F;
    case 0x82E292u: goto L_82E292;
    case 0x82E294u: goto L_82E294;
    case 0x82E296u: goto L_82E296;
    case 0x82E299u: goto L_82E299;
    case 0x82E29Bu: goto L_82E29B;
    case 0x82E29Eu: goto L_82E29E;
    case 0x82E2A0u: goto L_82E2A0;
    case 0x82E2A2u: goto L_82E2A2;
    case 0x82E2A5u: goto L_82E2A5;
    case 0x82E2A7u: goto L_82E2A7;
    case 0x82E2A8u: goto L_82E2A8;
    case 0x82E2A9u: goto L_82E2A9;
    case 0x82E2ABu: goto L_82E2AB;
    case 0x82E2ACu: goto L_82E2AC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82E27E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE27Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Eu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82E27E PHB
    cpu.push("PHB", hw);
    goto L_82E27F;
L_82E27F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE27Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E27F SEP
    cpu.sep(0x20u);
    goto L_82E281;
L_82E281:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE281u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE281u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE281u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x69u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E281 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x69u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E283;
L_82E283:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE283u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE283u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE283u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82E283 PHA
    cpu.push("PHA", hw);
    goto L_82E284;
L_82E284:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE284u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE284u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE284u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82E284 PLB
    cpu.pop("PLB", hw);
    goto L_82E285;
L_82E285:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE285u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE285u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE285u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E285 REP
    cpu.rep(0x20u);
    goto L_82E287;
L_82E287:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE287u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE287u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE287u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x67u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E287 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E289;
L_82E289:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE289u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE289u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE289u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E289 CLC
    cpu.setFlag('C', false);
    goto L_82E28A;
L_82E28A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE28Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE28Au,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE28Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E28A ADC
    cpu.adc(0x16u);
    goto L_82E28D;
L_82E28D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE28Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE28Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE28Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E28D STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82E28F;
L_82E28F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE28Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE28Fu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE28Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E28F LDY
    cpu.setY(0x1F8u, 16);
    goto L_82E292;
L_82E292:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE292u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE292u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE292u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82E292 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E294;
L_82E294:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE294u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE294u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE294u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E294 BEQ -> $82E2A7
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E2A7; }
    goto L_82E296;
L_82E296:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE296u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE296u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE296u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E296 CMP
    cpu.compareA(0xFFFFu);
    goto L_82E299;
L_82E299:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE299u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE299u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE299u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E299 BEQ -> $82E2A7
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E2A7; }
    goto L_82E29B;
L_82E29B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE29Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE29Bu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE29Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E29B BIT
    cpu.bit(0xC000u, true);
    goto L_82E29E;
L_82E29E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE29Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE29Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE29Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E29E BNE -> $82E2A7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E2A7; }
    goto L_82E2A0;
L_82E2A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2A0u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2A0u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82E2A0 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E2A2;
L_82E2A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2A2u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2A2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2A2 ORA
    cpu.logicOr(0x8000u);
    goto L_82E2A5;
L_82E2A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2A5u,cpu,0x91u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2A5u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82E2A5 STA
    hw.write(cpu.addressDpIndirectY(hw, 0x67u), cpu.a, cpu.m8?8:16);
    goto L_82E2A7;
L_82E2A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2A7u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2A7 DEY
    cpu.decReg('Y');
    goto L_82E2A8;
L_82E2A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2A8u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2A8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2A8 DEY
    cpu.decReg('Y');
    goto L_82E2A9;
L_82E2A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2A9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2A9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E2A9 BNE -> $82E292
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E292; }
    goto L_82E2AB;
L_82E2AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2ABu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2ABu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82E2AB PLB
    cpu.pop("PLB", hw);
    goto L_82E2AC;
L_82E2AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE2ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE2ACu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE2ACu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E2AC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82E2ACu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82E2ACu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8487EA_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8487EAu: goto L_8487EA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8487EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87EAu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87EAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8487EA RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8487EAu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8487EAu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_848EB8_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848EB8u: goto L_848EB8;
    case 0x848EBBu: goto L_848EBB;
    case 0x848EBEu: goto L_848EBE;
    case 0x848EC0u: goto L_848EC0;
    case 0x848EC3u: goto L_848EC3;
    case 0x848EC6u: goto L_848EC6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848EB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EB8u, 5u + 1u, 3u, cpu.address("absx", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848EB8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x63Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848EBB;
L_848EBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EBBu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EBBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848EBB CMP
    cpu.compareA(0x1Eu);
    goto L_848EBE;
L_848EBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EBEu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EBEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848EBE BCC -> $848EC6
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_848EC6; }
    goto L_848EC0;
L_848EC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848EC0 LDA
    cpu.setA(0x1Du, 16);
    goto L_848EC3;
L_848EC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC3u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC3u, 6u, 3u, cpu.address("absx", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848EC3 STA
    hw.write(cpu.address("absx", 0x63Fu), cpu.a, cpu.m8?8:16);
    goto L_848EC6;
L_848EC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848EC6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848EC6u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848EC6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_849ABA_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849ABAu: goto L_849ABA;
    case 0x849ABCu: goto L_849ABC;
    case 0x849ABEu: goto L_849ABE;
    case 0x849AC1u: goto L_849AC1;
    case 0x849AC3u: goto L_849AC3;
    case 0x849AC6u: goto L_849AC6;
    case 0x849AC8u: goto L_849AC8;
    case 0x849ACBu: goto L_849ACB;
    case 0x849ACDu: goto L_849ACD;
    case 0x849ACFu: goto L_849ACF;
    case 0x849AD1u: goto L_849AD1;
    case 0x849AD4u: goto L_849AD4;
    case 0x849AD6u: goto L_849AD6;
    case 0x849AD8u: goto L_849AD8;
    case 0x849ADBu: goto L_849ADB;
    case 0x849ADEu: goto L_849ADE;
    case 0x849AE0u: goto L_849AE0;
    case 0x849AE2u: goto L_849AE2;
    case 0x849AE5u: goto L_849AE5;
    case 0x849AE7u: goto L_849AE7;
    case 0x849AEAu: goto L_849AEA;
    case 0x849AECu: goto L_849AEC;
    case 0x849AEFu: goto L_849AEF;
    case 0x849AF1u: goto L_849AF1;
    case 0x849AF4u: goto L_849AF4;
    case 0x849AF7u: goto L_849AF7;
    case 0x849AF9u: goto L_849AF9;
    case 0x849AFCu: goto L_849AFC;
    case 0x849AFFu: goto L_849AFF;
    case 0x849B02u: goto L_849B02;
    case 0x849B04u: goto L_849B04;
    case 0x849B07u: goto L_849B07;
    case 0x849B0Au: goto L_849B0A;
    case 0x849B0Cu: goto L_849B0C;
    case 0x849B0Fu: goto L_849B0F;
    case 0x849B12u: goto L_849B12;
    case 0x849B15u: goto L_849B15;
    case 0x849B17u: goto L_849B17;
    case 0x849B1Au: goto L_849B1A;
    case 0x849B1Du: goto L_849B1D;
    case 0x849B1Fu: goto L_849B1F;
    case 0x849B21u: goto L_849B21;
    case 0x849B24u: goto L_849B24;
    case 0x849B28u: goto L_849B28;
    case 0x849B2Bu: goto L_849B2B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849ABA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ABAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ABAu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ABAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849ABA REP
    cpu.rep(0x20u);
    goto L_849ABC;
L_849ABC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ABCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ABCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ABCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849ABC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849ABE;
L_849ABE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ABEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ABEu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ABEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849ABE BIT
    cpu.bit(0x300u, true);
    goto L_849AC1;
L_849AC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849AC1 BNE -> $849AC8
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_849AC8; }
    goto L_849AC3;
L_849AC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC3u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC3u, 5u, 3u, cpu.address("abs", 0x0660u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849AC3 STZ
    hw.write(cpu.address("abs", 0x660u), 0, cpu.m8?8:16);
    goto L_849AC6;
L_849AC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC6u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849AC6 BRA -> $849B2B
    goto L_849B2B;
L_849AC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC8u, 5u, 3u, cpu.address("abs", 0x0660u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849AC8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x660u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849ACB;
L_849ACB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ACBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ACBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ACBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849ACB BEQ -> $849AD8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_849AD8; }
    goto L_849ACD;
L_849ACD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ACDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ACDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ACDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849ACD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849ACF;
L_849ACF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ACFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ACFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ACFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849ACF BNE -> $849B2B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_849B2B; }
    goto L_849AD1;
L_849AD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AD1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AD1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849AD1 LDA
    cpu.setA(0x4u, 16);
    goto L_849AD4;
L_849AD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AD4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AD4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849AD4 STA
    hw.write(cpu.address("dp", 0x6Fu), cpu.a, cpu.m8?8:16);
    goto L_849AD6;
L_849AD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AD6u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AD6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849AD6 BRA -> $849AE0
    goto L_849AE0;
L_849AD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AD8u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AD8u, 8u, 3u, cpu.address("abs", 0x0660u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849AD8 INC
    cpu.incMem(hw, cpu.address("abs", 0x660u), cpu.m8?8:16);
    goto L_849ADB;
L_849ADB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ADBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ADBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ADBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849ADB LDA
    cpu.setA(0x10u, 16);
    goto L_849ADE;
L_849ADE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ADEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ADEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ADEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849ADE STA
    hw.write(cpu.address("dp", 0x6Fu), cpu.a, cpu.m8?8:16);
    goto L_849AE0;
L_849AE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849AE0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849AE2;
L_849AE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE2u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849AE2 BIT
    cpu.bit(0x100u, true);
    goto L_849AE5;
L_849AE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849AE5 BNE -> $849AF1
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_849AF1; }
    goto L_849AE7;
L_849AE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE7u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE7u, 9u, 3u, cpu.address("absx", 0x063Fu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849AE7 DEC
    cpu.decMem(hw, cpu.address("absx", 0x63Fu), cpu.m8?8:16);
    goto L_849AEA;
L_849AEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AEAu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AEAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849AEA BPL -> $849B1F
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_849B1F; }
    goto L_849AEC;
L_849AEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AECu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AECu, 6u, 3u, cpu.address("absx", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849AEC STZ
    hw.write(cpu.address("absx", 0x63Fu), 0, cpu.m8?8:16);
    goto L_849AEF;
L_849AEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AEFu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AEFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849AEF BRA -> $849B2B
    goto L_849B2B;
L_849AF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AF1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AF1u, 5u, 3u, cpu.address("abs", 0x0629u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849AF1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849AF4;
L_849AF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AF4u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AF4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849AF4 BIT
    cpu.bit(0x1u, true);
    goto L_849AF7;
L_849AF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AF7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AF7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849AF7 BNE -> $849B0C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_849B0C; }
    goto L_849AF9;
L_849AF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AF9u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AF9u, 9u, 3u, cpu.address("absx", 0x063Fu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849AF9 INC
    cpu.incMem(hw, cpu.address("absx", 0x63Fu), cpu.m8?8:16);
    goto L_849AFC;
L_849AFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AFCu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AFCu, 5u + 1u, 3u, cpu.address("absx", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849AFC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x63Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849AFF;
L_849AFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AFFu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AFFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849AFF CMP
    cpu.compareA(0x1Eu);
    goto L_849B02;
L_849B02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B02u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B02u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B02 BCC -> $849B1F
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_849B1F; }
    goto L_849B04;
L_849B04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B04u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B04u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B04 LDA
    cpu.setA(0x1Du, 16);
    goto L_849B07;
L_849B07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B07u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B07u, 6u, 3u, cpu.address("absx", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B07 STA
    hw.write(cpu.address("absx", 0x63Fu), cpu.a, cpu.m8?8:16);
    goto L_849B0A;
L_849B0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B0Au,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B0Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B0A BRA -> $849B2B
    goto L_849B2B;
L_849B0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B0Cu,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B0Cu, 9u, 3u, cpu.address("absx", 0x063Fu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B0C INC
    cpu.incMem(hw, cpu.address("absx", 0x63Fu), cpu.m8?8:16);
    goto L_849B0F;
L_849B0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B0Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B0Fu, 5u + 1u, 3u, cpu.address("absx", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B0F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x63Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849B12;
L_849B12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B12u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B12u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B12 CMP
    cpu.compareA(0xFu);
    goto L_849B15;
L_849B15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B15u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B15u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B15 BCC -> $849B1F
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_849B1F; }
    goto L_849B17;
L_849B17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B17u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B17u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B17 LDA
    cpu.setA(0xEu, 16);
    goto L_849B1A;
L_849B1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B1Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B1Au, 6u, 3u, cpu.address("absx", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B1A STA
    hw.write(cpu.address("absx", 0x63Fu), cpu.a, cpu.m8?8:16);
    goto L_849B1D;
L_849B1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B1Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B1Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B1D BRA -> $849B2B
    goto L_849B2B;
L_849B1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B1Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B1Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B1F REP
    cpu.rep(0x20u);
    goto L_849B21;
L_849B21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B21u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B21u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B21 LDA
    cpu.setA(0x7u, 16);
    goto L_849B24;
L_849B24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B24u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B24u, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849B24 JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9B27u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9B28u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x849B24u); }
    goto L_849B28;
L_849B28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B28u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9B28u,0x849B28u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B28u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B28u, 8u, 3u, cpu.address("abs", 0x06F7u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849B28 INC
    cpu.incMem(hw, cpu.address("abs", 0x6F7u), cpu.m8?8:16);
    goto L_849B2B;
L_849B2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B2Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B2Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849B2B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849B2Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849B2Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84BEB6_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84BEB6u: goto L_84BEB6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84BEB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB6u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84BEB6 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x84BEB6u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84BEB6u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_84BEB6_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84BEB6u: goto L_84BEB6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84BEB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB6u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84BEB6 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x84BEB6u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84BEB6u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_84BF64_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84BF64u: goto L_84BF64;
    case 0x84BF66u: goto L_84BF66;
    case 0x84BF69u: goto L_84BF69;
    case 0x84BF6Bu: goto L_84BF6B;
    case 0x84BF6Du: goto L_84BF6D;
    case 0x84BF6Fu: goto L_84BF6F;
    case 0x84BF71u: goto L_84BF71;
    case 0x84BF74u: goto L_84BF74;
    case 0x84BF76u: goto L_84BF76;
    case 0x84BF7Au: goto L_84BF7A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84BF64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF64u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF64u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF64 REP
    cpu.rep(0x20u);
    goto L_84BF66;
L_84BF66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF66u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF66u, 5u, 3u, cpu.address("abs", 0x012Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF66 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x12Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BF69;
L_84BF69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF69u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF69u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF69 BPL -> $84BF76
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_84BF76; }
    goto L_84BF6B;
L_84BF6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF6Bu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF6Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF6B SEP
    cpu.sep(0x20u);
    goto L_84BF6D;
L_84BF6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF6Du,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF6Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF6D INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_84BF6F;
L_84BF6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF6Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF6Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF6F REP
    cpu.rep(0x20u);
    goto L_84BF71;
L_84BF71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF71u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF71u, 5u, 3u, cpu.address("abs", 0x060Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF71 STZ
    hw.write(cpu.address("abs", 0x60Fu), 0, cpu.m8?8:16);
    goto L_84BF74;
L_84BF74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF74u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF74u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF74 BRA -> $84BF7A
    goto L_84BF7A;
L_84BF76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF76u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF76u, 8u, 4u, 0x80A880u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84BF76 JSL -> $80A880 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBF79u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBF7Au,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A880u, 0x84BF76u); }
    goto L_84BF7A;
L_84BF7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF7Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF7Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF7Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84BF7A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84BF7Au);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84BF7Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF7Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF7Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84BF7A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84BF7Au);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84BF7Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF7Au,0x84BF7Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_84BFE2_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84BFE2u: goto L_84BFE2;
    case 0x84BFE4u: goto L_84BFE4;
    case 0x84BFE6u: goto L_84BFE6;
    case 0x84BFE8u: goto L_84BFE8;
    case 0x84BFEBu: goto L_84BFEB;
    case 0x84BFEDu: goto L_84BFED;
    case 0x84BFF0u: goto L_84BFF0;
    case 0x84BFF2u: goto L_84BFF2;
    case 0x84BFF5u: goto L_84BFF5;
    case 0x84BFF7u: goto L_84BFF7;
    case 0x84BFF9u: goto L_84BFF9;
    case 0x84BFFCu: goto L_84BFFC;
    case 0x84C000u: goto L_84C000;
    case 0x84C002u: goto L_84C002;
    case 0x84C004u: goto L_84C004;
    case 0x84C006u: goto L_84C006;
    case 0x84C007u: goto L_84C007;
    case 0x84C009u: goto L_84C009;
    case 0x84C00Du: goto L_84C00D;
    case 0x84C010u: goto L_84C010;
    case 0x84C012u: goto L_84C012;
    case 0x84C014u: goto L_84C014;
    case 0x84C017u: goto L_84C017;
    case 0x84C019u: goto L_84C019;
    case 0x84C01Cu: goto L_84C01C;
    case 0x84C01Fu: goto L_84C01F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84BFE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFE2u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFE2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BFE2 REP
    cpu.rep(0x20u);
    goto L_84BFE4;
L_84BFE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFE4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFE4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BFE4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BFE6;
L_84BFE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFE6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFE6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BFE6 BNE -> $84C019
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84C019; }
    goto L_84BFE8;
L_84BFE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFE8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFE8u, 5u, 3u, cpu.address("abs", 0x0195u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BFE8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x195u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BFEB;
L_84BFEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFEBu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFEBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BFEB BNE -> $84BFF2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84BFF2; }
    goto L_84BFED;
L_84BFED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFEDu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFEDu, 8u, 3u, cpu.address("abs", 0x0193u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BFED INC
    cpu.incMem(hw, cpu.address("abs", 0x193u), cpu.m8?8:16);
    goto L_84BFF0;
L_84BFF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFF0u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFF0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BFF0 BRA -> $84C000
    goto L_84C000;
L_84BFF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFF2u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFF2u, 8u, 3u, cpu.address("abs", 0x0195u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BFF2 DEC
    cpu.decMem(hw, cpu.address("abs", 0x195u), cpu.m8?8:16);
    goto L_84BFF5;
L_84BFF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFF5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFF5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BFF5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BFF7;
L_84BFF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFF7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFF7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BFF7 BEQ -> $84C019
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_84C019; }
    goto L_84BFF9;
L_84BFF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFF9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFF9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BFF9 LDA
    cpu.setA(0x4u, 16);
    goto L_84BFFC;
L_84BFFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFFCu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFFCu, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84BFFC JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBFFFu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC000u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x84BFFCu); }
    goto L_84C000;
L_84C000:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC000u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC000u,0x84C000u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC000u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC000u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C000 SEP
    cpu.sep(0x20u);
    goto L_84C002;
L_84C002:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC002u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC002u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC002u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C002 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_84C004;
L_84C004:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC004u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC004u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC004u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C004 LDA
    cpu.setA(0x82u, 8);
    goto L_84C006;
L_84C006:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC006u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC006u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC006u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C006 XBA
    cpu.xba();
    goto L_84C007;
L_84C007:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC007u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC007u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC007u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C007 LDA
    cpu.setA(0xFu, 8);
    goto L_84C009;
L_84C009:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC009u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC009u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC009u, 8u, 4u, 0x8086F4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84C009 JSL -> $8086F4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC00Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC00Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8086F4u, 0x84C009u); }
    goto L_84C00D;
L_84C00D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC00Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC00Du,0x84C00Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC00Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC00Du, 4u, 3u, cpu.address("abs", 0x0193u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C00D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x193u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84C010;
L_84C010:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC010u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC010u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC010u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C010 BEQ -> $84C017
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_84C017; }
    goto L_84C012;
L_84C012:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC012u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC012u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC012u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C012 LDA
    cpu.setA(0x83u, 8);
    goto L_84C014;
L_84C014:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC014u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC014u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC014u, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C014 STA
    hw.write(cpu.address("abs", 0x2140u), cpu.a, cpu.m8?8:16);
    goto L_84C017;
L_84C017:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC017u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC017u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC017u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C017 REP
    cpu.rep(0x20u);
    goto L_84C019;
L_84C019:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC019u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC019u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC019u, 6u, 3u, cpu.address("abs", 0xC228u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84C019 JSR -> $84C228 stack real
    { cpu.push16Value(hw,0xC01Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC01Cu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC228u), 0x84C019u); }
    goto L_84C01C;
L_84C01C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC01Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC01Cu,0x84C01Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC01Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC01Cu, 6u, 3u, cpu.address("abs", 0xC25Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84C01C JSR -> $84C25B stack real
    { cpu.push16Value(hw,0xC01Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC01Fu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC25Bu), 0x84C01Cu); }
    goto L_84C01F;
L_84C01F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC01Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC01Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC01Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84C01F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84C01Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84C01Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC01Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC01Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84C01F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84C01Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84C01Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC01Fu,0x84C01Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

