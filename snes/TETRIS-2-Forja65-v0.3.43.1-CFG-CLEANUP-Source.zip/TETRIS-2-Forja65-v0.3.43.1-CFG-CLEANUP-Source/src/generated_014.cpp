#include "generated.hpp"
void sub_8082FB_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8082FBu: goto L_8082FB;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8082FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82FBu,cpu,0x40u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82FBu, 7u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $8082FB RTI stack real
    {auto dst=cpu.returnInterrupt(hw);hw.requestDispatch(dst,0x8082FBu);return;}
}

void sub_808363_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808363u: goto L_808363;
    case 0x808367u: goto L_808367;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808363:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8363u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8363u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8363u, 8u, 4u, 0x848249u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808363 JSL -> $848249 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8366u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8367u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848249u, 0x808363u); }
    goto L_808367;
L_808367:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8367u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8367u,0x808367u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8367u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8367u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808367 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808367u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808367u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808363_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808363u: goto L_808363;
    case 0x808367u: goto L_808367;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808363:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8363u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8363u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8363u, 8u, 4u, 0x848249u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808363 JSL -> $848249 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8366u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8367u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848249u, 0x808363u); }
    goto L_808367;
L_808367:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8367u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8367u,0x808367u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8367u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8367u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808367 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808367u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808367u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8084D4_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8084D4u: goto L_8084D4;
    case 0x8084D6u: goto L_8084D6;
    case 0x8084D8u: goto L_8084D8;
    case 0x8084DCu: goto L_8084DC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8084D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84D4u,cpu,0xC7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84D4u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x8Eu) & 0xFFFFu), 3u, 0u);
    // $8084D4 CMP
    cpu.compareA(hw.readW(cpu.addressDpLong(hw, 0x8Eu), cpu.m8?8:16));
    goto L_8084D6;
L_8084D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84D6u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84D6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8084D6 STY
    hw.write(cpu.address("dp", 0x6Bu), cpu.y, cpu.x8?8:16);
    goto L_8084D8;
L_8084D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84D8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84D8u, 8u, 4u, 0x84A1D1u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8084D8 JSL -> $84A1D1 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x84DBu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x84DCu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84A1D1u, 0x8084D8u); }
    goto L_8084DC;
L_8084DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84DCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84DCu,0x8084DCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84DCu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84DCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8084DC RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8084DCu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8084DCu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808556_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808556u: goto L_808556;
    case 0x808557u: goto L_808557;
    case 0x808559u: goto L_808559;
    case 0x80855Bu: goto L_80855B;
    case 0x80855Du: goto L_80855D;
    case 0x808560u: goto L_808560;
    case 0x808562u: goto L_808562;
    case 0x808563u: goto L_808563;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808556:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8556u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8556u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8556u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808556 PHP
    cpu.push("PHP", hw);
    goto L_808557;
L_808557:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8557u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8557u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8557u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808557 SEP
    cpu.sep(0x24u);
    goto L_808559;
L_808559:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8559u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8559u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8559u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x73u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808559 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x73u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80855B;
L_80855B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x855Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x855Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x855Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80855B AND
    cpu.logicAnd(0xEu);
    goto L_80855D;
L_80855D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x855Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x855Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x855Du, 4u, 3u, cpu.address("abs", 0x4200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80855D STA
    hw.write(cpu.address("abs", 0x4200u), cpu.a, cpu.m8?8:16);
    goto L_808560;
L_808560:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8560u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8560u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8560u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x73u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808560 STA
    hw.write(cpu.address("dp", 0x73u), cpu.a, cpu.m8?8:16);
    goto L_808562;
L_808562:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8562u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8562u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8562u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808562 PLP
    cpu.pop("PLP", hw);
    goto L_808563;
L_808563:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8563u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8563u,0x808563u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8563u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8563u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808563 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808563u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808563u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808BB9_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808BB9u: goto L_808BB9;
    case 0x808BBAu: goto L_808BBA;
    case 0x808BBBu: goto L_808BBB;
    case 0x808BBEu: goto L_808BBE;
    case 0x808BC0u: goto L_808BC0;
    case 0x808BC4u: goto L_808BC4;
    case 0x808BC5u: goto L_808BC5;
    case 0x808BC6u: goto L_808BC6;
    case 0x808BC7u: goto L_808BC7;
    case 0x808BC8u: goto L_808BC8;
    case 0x808BC9u: goto L_808BC9;
    case 0x808BCBu: goto L_808BCB;
    case 0x808BCDu: goto L_808BCD;
    case 0x808BCEu: goto L_808BCE;
    case 0x808BD1u: goto L_808BD1;
    case 0x808BD2u: goto L_808BD2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808BB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB9u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB9u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808BB9 PHP
    cpu.push("PHP", hw);
    goto L_808BBA;
L_808BBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BBAu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BBAu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808BBA PHY
    cpu.push("PHY", hw);
    goto L_808BBB;
L_808BBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BBBu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BBBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BBB LDY
    cpu.setY(0x0u, 16);
    goto L_808BBE;
L_808BBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BBEu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BBEu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BBEu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $808BBE LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808BC0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BBEu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BBEu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $808BBE LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808BC0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BBEu,0x808BBEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_808BC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BC0u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC0u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC0u, 6u, 4u, ((0x801900u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BC0 STA
    hw.write(((0x801900u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_808BC4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC0u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC0u, 6u, 4u, ((0x801900u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BC0 STA
    hw.write(((0x801900u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_808BC4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BC0u,0x808BC0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_808BC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BC4u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC4u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BC4 INX
    cpu.inc('X');
    goto L_808BC5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC4u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BC4 INX
    cpu.inc('X');
    goto L_808BC5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BC4u,0x808BC4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_808BC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BC5u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC5u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BC5 INX
    cpu.inc('X');
    goto L_808BC6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC5u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BC5 INX
    cpu.inc('X');
    goto L_808BC6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BC5u,0x808BC5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_808BC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BC6u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC6u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BC6 INY
    cpu.inc('Y');
    goto L_808BC7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC6u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BC6 INY
    cpu.inc('Y');
    goto L_808BC7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BC6u,0x808BC6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_808BC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BC7u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC7u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BC7 INY
    cpu.inc('Y');
    goto L_808BC8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC7u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BC7 INY
    cpu.inc('Y');
    goto L_808BC8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BC7u,0x808BC7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_808BC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BC8u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC8u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BC8 TYA
    cpu.transfer("TYA");
    goto L_808BC9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC8u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BC8 TYA
    cpu.transfer("TYA");
    goto L_808BC9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BC8u,0x808BC8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_808BC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BC9u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC9u,cpu,0xC3u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC9u, 5u, 2u, cpu.addressStack(0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BC9 CMP
    cpu.compareA(hw.readW(cpu.addressStack(0x1u), cpu.m8?8:16));
    goto L_808BCB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC9u,cpu,0xC3u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC9u, 5u, 2u, cpu.addressStack(0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BC9 CMP
    cpu.compareA(hw.readW(cpu.addressStack(0x1u), cpu.m8?8:16));
    goto L_808BCB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BC9u,0x808BC9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_808BCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCBu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BCB BCC -> $808BBE
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_808BBE; }
    goto L_808BCD;
L_808BCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCDu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCDu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808BCD PLA
    cpu.pop("PLA", hw);
    goto L_808BCE;
L_808BCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCEu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCEu, 8u, 3u, cpu.address("abs", 0x0122u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BCE INC
    cpu.incMem(hw, cpu.address("abs", 0x122u), cpu.m8?8:16);
    goto L_808BD1;
L_808BD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD1u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808BD1 PLP
    cpu.pop("PLP", hw);
    goto L_808BD2;
L_808BD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BD2u,0x808BD2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808BD2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808BD2u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808BD2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808BB9_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808BB9u: goto L_808BB9;
    case 0x808BBAu: goto L_808BBA;
    case 0x808BBBu: goto L_808BBB;
    case 0x808BBEu: goto L_808BBE;
    case 0x808BC0u: goto L_808BC0;
    case 0x808BC4u: goto L_808BC4;
    case 0x808BC5u: goto L_808BC5;
    case 0x808BC6u: goto L_808BC6;
    case 0x808BC7u: goto L_808BC7;
    case 0x808BC8u: goto L_808BC8;
    case 0x808BC9u: goto L_808BC9;
    case 0x808BCBu: goto L_808BCB;
    case 0x808BCDu: goto L_808BCD;
    case 0x808BCEu: goto L_808BCE;
    case 0x808BD1u: goto L_808BD1;
    case 0x808BD2u: goto L_808BD2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808BB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB9u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BB9u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808BB9 PHP
    cpu.push("PHP", hw);
    goto L_808BBA;
L_808BBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BBAu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BBAu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808BBA PHY
    cpu.push("PHY", hw);
    goto L_808BBB;
L_808BBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BBBu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BBBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BBB LDY
    cpu.setY(0x0u, 16);
    goto L_808BBE;
L_808BBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BBEu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BBEu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $808BBE LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808BC0;
L_808BC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC0u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC0u, 6u, 4u, ((0x801900u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BC0 STA
    hw.write(((0x801900u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_808BC4;
L_808BC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC4u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BC4 INX
    cpu.inc('X');
    goto L_808BC5;
L_808BC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC5u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BC5 INX
    cpu.inc('X');
    goto L_808BC6;
L_808BC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC6u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BC6 INY
    cpu.inc('Y');
    goto L_808BC7;
L_808BC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC7u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BC7 INY
    cpu.inc('Y');
    goto L_808BC8;
L_808BC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC8u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BC8 TYA
    cpu.transfer("TYA");
    goto L_808BC9;
L_808BC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC9u,cpu,0xC3u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BC9u, 5u, 2u, cpu.addressStack(0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BC9 CMP
    cpu.compareA(hw.readW(cpu.addressStack(0x1u), cpu.m8?8:16));
    goto L_808BCB;
L_808BCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCBu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BCB BCC -> $808BBE
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_808BBE; }
    goto L_808BCD;
L_808BCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCDu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCDu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808BCD PLA
    cpu.pop("PLA", hw);
    goto L_808BCE;
L_808BCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCEu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BCEu, 8u, 3u, cpu.address("abs", 0x0122u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BCE INC
    cpu.incMem(hw, cpu.address("abs", 0x122u), cpu.m8?8:16);
    goto L_808BD1;
L_808BD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD1u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808BD1 PLP
    cpu.pop("PLP", hw);
    goto L_808BD2;
L_808BD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BD2u,0x808BD2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808BD2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808BD2u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808BD2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808BD3_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808BD3u: goto L_808BD3;
    case 0x808BD4u: goto L_808BD4;
    case 0x808BD5u: goto L_808BD5;
    case 0x808BD8u: goto L_808BD8;
    case 0x808BDAu: goto L_808BDA;
    case 0x808BDEu: goto L_808BDE;
    case 0x808BDFu: goto L_808BDF;
    case 0x808BE0u: goto L_808BE0;
    case 0x808BE1u: goto L_808BE1;
    case 0x808BE2u: goto L_808BE2;
    case 0x808BE3u: goto L_808BE3;
    case 0x808BE5u: goto L_808BE5;
    case 0x808BE7u: goto L_808BE7;
    case 0x808BE8u: goto L_808BE8;
    case 0x808BE9u: goto L_808BE9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808BD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD3u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD3u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808BD3 PHP
    cpu.push("PHP", hw);
    goto L_808BD4;
L_808BD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD4u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD4u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808BD4 PHY
    cpu.push("PHY", hw);
    goto L_808BD5;
L_808BD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD5u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BD5 LDY
    cpu.setY(0x0u, 16);
    goto L_808BD8;
L_808BD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD8u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BD8u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $808BD8 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808BDA;
L_808BDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDAu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDAu, 6u, 4u, ((0x801B00u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BDA STA
    hw.write(((0x801B00u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_808BDE;
L_808BDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDEu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BDE INX
    cpu.inc('X');
    goto L_808BDF;
L_808BDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDFu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BDFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BDF INX
    cpu.inc('X');
    goto L_808BE0;
L_808BE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE0u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BE0 INY
    cpu.inc('Y');
    goto L_808BE1;
L_808BE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE1u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BE1 INY
    cpu.inc('Y');
    goto L_808BE2;
L_808BE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE2u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BE2 TYA
    cpu.transfer("TYA");
    goto L_808BE3;
L_808BE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE3u,cpu,0xC3u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE3u, 5u, 2u, cpu.addressStack(0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BE3 CMP
    cpu.compareA(hw.readW(cpu.addressStack(0x1u), cpu.m8?8:16));
    goto L_808BE5;
L_808BE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE5u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BE5 BCC -> $808BD8
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_808BD8; }
    goto L_808BE7;
L_808BE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE7u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE7u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808BE7 PLA
    cpu.pop("PLA", hw);
    goto L_808BE8;
L_808BE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE8u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE8u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808BE8 PLP
    cpu.pop("PLP", hw);
    goto L_808BE9;
L_808BE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BE9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8BE9u,0x808BE9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE9u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BE9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808BE9 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808BE9u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808BE9u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808BEA_E0M0X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808BEAu: goto L_808BEA;
    case 0x808BEBu: goto L_808BEB;
    case 0x808BEDu: goto L_808BED;
    case 0x808BEFu: goto L_808BEF;
    case 0x808BF1u: goto L_808BF1;
    case 0x808BF3u: goto L_808BF3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808BEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEAu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEAu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808BEA PHP
    cpu.push("PHP", hw);
    goto L_808BEB;
L_808BEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEBu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BEB REP
    cpu.rep(0x20u);
    goto L_808BED;
L_808BED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEDu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEDu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BED INC
    cpu.incMem(hw, cpu.address("dp", 0x6Bu), cpu.m8?8:16);
    goto L_808BEF;
L_808BEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEFu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BEFu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Du), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BEF INC
    cpu.incMem(hw, cpu.address("dp", 0x6Du), cpu.m8?8:16);
    goto L_808BF1;
L_808BF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF1u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808BF1 LDX
    cpu.setX(0x2u, 8);
    goto L_808BF3;
L_808BF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8BF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF3u,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8BF3u, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $808BF3 BRK
    hw.partial(0x808BF3u, "BRK"); return;
}

void sub_809C69_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809C69u: goto L_809C69;
    case 0x809C6Cu: goto L_809C6C;
    case 0x809C6Fu: goto L_809C6F;
    case 0x809C71u: goto L_809C71;
    case 0x809C74u: goto L_809C74;
    case 0x809C77u: goto L_809C77;
    case 0x809C79u: goto L_809C79;
    case 0x809C7Cu: goto L_809C7C;
    case 0x809C7Eu: goto L_809C7E;
    case 0x809C81u: goto L_809C81;
    case 0x809C82u: goto L_809C82;
    case 0x809C85u: goto L_809C85;
    case 0x809C88u: goto L_809C88;
    case 0x809C8Au: goto L_809C8A;
    case 0x809C8Du: goto L_809C8D;
    case 0x809C8Fu: goto L_809C8F;
    case 0x809C92u: goto L_809C92;
    case 0x809C95u: goto L_809C95;
    case 0x809C98u: goto L_809C98;
    case 0x809C9Au: goto L_809C9A;
    case 0x809C9Du: goto L_809C9D;
    case 0x809C9Fu: goto L_809C9F;
    case 0x809CA2u: goto L_809CA2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809C69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C69u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C69u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C69 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809C6C;
L_809C6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C6Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C6Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C6C CMP
    cpu.compareA(0x2u);
    goto L_809C6F;
L_809C6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C6Fu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C6Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C6F BCS -> $809C82
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_809C82; }
    goto L_809C71;
L_809C71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C71u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C71u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C71 LDX
    cpu.setX(0x0u, 16);
    goto L_809C74;
L_809C74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C74u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C74u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C74 LDA
    cpu.setA(0x1E6u, 16);
    goto L_809C77;
L_809C77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C77u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C77u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C77 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_809C79;
L_809C79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C79u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C79u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C79 LDA
    cpu.setA(0x5Cu, 16);
    goto L_809C7C;
L_809C7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C7Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C7Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C7C STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_809C7E;
L_809C7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C7Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C7Eu, 6u, 3u, cpu.address("abs", 0x9CA3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809C7E JSR -> $809CA3 stack real
    { cpu.push16Value(hw,0x9C80u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9C81u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9CA3u), 0x809C7Eu); }
    goto L_809C81;
L_809C81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C81u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C81u,0x809C81u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C81u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C81u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809C81 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x809C81u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x809C81u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_809C82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C82u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C82u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C82 LDX
    cpu.setX(0x0u, 16);
    goto L_809C85;
L_809C85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C85u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C85u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C85 LDA
    cpu.setA(0x1E6u, 16);
    goto L_809C88;
L_809C88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C88u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C88u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C88 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_809C8A;
L_809C8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C8Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C8Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C8A LDA
    cpu.setA(0x14u, 16);
    goto L_809C8D;
L_809C8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C8Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C8Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C8D STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_809C8F;
L_809C8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C8Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C8Fu, 6u, 3u, cpu.address("abs", 0x9CA3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809C8F JSR -> $809CA3 stack real
    { cpu.push16Value(hw,0x9C91u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9C92u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9CA3u), 0x809C8Fu); }
    goto L_809C92;
L_809C92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C92u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C92u,0x809C92u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C92u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C92u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C92 LDX
    cpu.setX(0x100u, 16);
    goto L_809C95;
L_809C95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C95u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C95u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C95 LDA
    cpu.setA(0x406u, 16);
    goto L_809C98;
L_809C98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C98u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C98u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C98 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_809C9A;
L_809C9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C9Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C9Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C9A LDA
    cpu.setA(0xA4u, 16);
    goto L_809C9D;
L_809C9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C9Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C9Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C9D STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_809C9F;
L_809C9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C9Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C9Fu, 6u, 3u, cpu.address("abs", 0x9CA3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809C9F JSR -> $809CA3 stack real
    { cpu.push16Value(hw,0x9CA1u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9CA2u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9CA3u), 0x809C9Fu); }
    goto L_809CA2;
L_809CA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CA2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CA2u,0x809CA2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CA2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809CA2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x809CA2u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x809CA2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80A0AA_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80A0AAu: goto L_80A0AA;
    case 0x80A0ADu: goto L_80A0AD;
    case 0x80A0B0u: goto L_80A0B0;
    case 0x80A0B3u: goto L_80A0B3;
    case 0x80A0B6u: goto L_80A0B6;
    case 0x80A0BAu: goto L_80A0BA;
    case 0x80A0BCu: goto L_80A0BC;
    case 0x80A0BEu: goto L_80A0BE;
    case 0x80A0BFu: goto L_80A0BF;
    case 0x80A0C2u: goto L_80A0C2;
    case 0x80A0C5u: goto L_80A0C5;
    case 0x80A0C8u: goto L_80A0C8;
    case 0x80A0CCu: goto L_80A0CC;
    case 0x80A0CFu: goto L_80A0CF;
    case 0x80A0D2u: goto L_80A0D2;
    case 0x80A0D5u: goto L_80A0D5;
    case 0x80A0D8u: goto L_80A0D8;
    case 0x80A0DCu: goto L_80A0DC;
    case 0x80A0DEu: goto L_80A0DE;
    case 0x80A0E0u: goto L_80A0E0;
    case 0x80A0E1u: goto L_80A0E1;
    case 0x80A0E4u: goto L_80A0E4;
    case 0x80A0E7u: goto L_80A0E7;
    case 0x80A0EAu: goto L_80A0EA;
    case 0x80A0EEu: goto L_80A0EE;
    case 0x80A0F1u: goto L_80A0F1;
    case 0x80A0F3u: goto L_80A0F3;
    case 0x80A0F6u: goto L_80A0F6;
    case 0x80A0F8u: goto L_80A0F8;
    case 0x80A0FBu: goto L_80A0FB;
    case 0x80A0FEu: goto L_80A0FE;
    case 0x80A102u: goto L_80A102;
    case 0x80A105u: goto L_80A105;
    case 0x80A108u: goto L_80A108;
    case 0x80A10Bu: goto L_80A10B;
    case 0x80A10Eu: goto L_80A10E;
    case 0x80A112u: goto L_80A112;
    case 0x80A113u: goto L_80A113;
    case 0x80A116u: goto L_80A116;
    case 0x80A119u: goto L_80A119;
    case 0x80A11Bu: goto L_80A11B;
    case 0x80A11Cu: goto L_80A11C;
    case 0x80A11Fu: goto L_80A11F;
    case 0x80A120u: goto L_80A120;
    case 0x80A123u: goto L_80A123;
    case 0x80A126u: goto L_80A126;
    case 0x80A129u: goto L_80A129;
    case 0x80A12Cu: goto L_80A12C;
    case 0x80A130u: goto L_80A130;
    case 0x80A131u: goto L_80A131;
    case 0x80A134u: goto L_80A134;
    case 0x80A137u: goto L_80A137;
    case 0x80A139u: goto L_80A139;
    case 0x80A13Au: goto L_80A13A;
    case 0x80A13Du: goto L_80A13D;
    case 0x80A13Eu: goto L_80A13E;
    case 0x80A141u: goto L_80A141;
    case 0x80A144u: goto L_80A144;
    case 0x80A147u: goto L_80A147;
    case 0x80A14Au: goto L_80A14A;
    case 0x80A14Eu: goto L_80A14E;
    case 0x80A14Fu: goto L_80A14F;
    case 0x80A152u: goto L_80A152;
    case 0x80A155u: goto L_80A155;
    case 0x80A157u: goto L_80A157;
    case 0x80A158u: goto L_80A158;
    case 0x80A15Bu: goto L_80A15B;
    case 0x80A15Cu: goto L_80A15C;
    case 0x80A15Fu: goto L_80A15F;
    case 0x80A163u: goto L_80A163;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80A0AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0AAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0AAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A0AA LDA
    cpu.setA(0x8980u, 16);
    goto L_80A0AD;
L_80A0AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0ADu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0ADu, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A0AD STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_80A0B0;
L_80A0B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0B0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0B0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A0B0 LDA
    cpu.setA(0x8Cu, 16);
    goto L_80A0B3;
L_80A0B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0B3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0B3u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A0B3 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_80A0B6;
L_80A0B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0B6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0B6u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A0B6 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA0B9u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA0BAu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x80A0B6u); }
    goto L_80A0BA;
L_80A0BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0BAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA0BAu,0x80A0BAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0BAu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0BAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A0BA SEP
    cpu.sep(0x20u);
    goto L_80A0BC;
L_80A0BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0BCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0BCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A0BC LDA
    cpu.setA(0x7Eu, 8);
    goto L_80A0BE;
L_80A0BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0BEu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0BEu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A0BE PHA
    cpu.push("PHA", hw);
    goto L_80A0BF;
L_80A0BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0BFu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0BFu, 5u, 3u, cpu.address("abs", 0x8000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A0BF PEA
    cpu.push16Value(hw, 0x8000u);
    goto L_80A0C2;
L_80A0C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0C2u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0C2u, 5u, 3u, cpu.address("abs", 0x6000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A0C2 PEA
    cpu.push16Value(hw, 0x6000u);
    goto L_80A0C5;
L_80A0C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0C5u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0C5u, 5u, 3u, cpu.address("abs", 0x2000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A0C5 PEA
    cpu.push16Value(hw, 0x2000u);
    goto L_80A0C8;
L_80A0C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0C8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0C8u, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A0C8 JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA0CBu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA0CCu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x80A0C8u); }
    goto L_80A0CC;
L_80A0CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0CCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA0CCu,0x80A0CCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0CCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0CCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A0CC LDA
    cpu.setA(0x94FBu, 16);
    goto L_80A0CF;
L_80A0CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0CFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0CFu, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A0CF STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_80A0D2;
L_80A0D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A0D2 LDA
    cpu.setA(0x91u, 16);
    goto L_80A0D5;
L_80A0D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D5u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A0D5 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_80A0D8;
L_80A0D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D8u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A0D8 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA0DBu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA0DCu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x80A0D8u); }
    goto L_80A0DC;
L_80A0DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0DCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA0DCu,0x80A0DCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0DCu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0DCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A0DC SEP
    cpu.sep(0x20u);
    goto L_80A0DE;
L_80A0DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0DEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0DEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A0DE LDA
    cpu.setA(0x7Eu, 8);
    goto L_80A0E0;
L_80A0E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E0u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E0u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A0E0 PHA
    cpu.push("PHA", hw);
    goto L_80A0E1;
L_80A0E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E1u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E1u, 5u, 3u, cpu.address("abs", 0x8000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A0E1 PEA
    cpu.push16Value(hw, 0x8000u);
    goto L_80A0E4;
L_80A0E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E4u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E4u, 5u, 3u, cpu.address("abs", 0x2000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A0E4 PEA
    cpu.push16Value(hw, 0x2000u);
    goto L_80A0E7;
L_80A0E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E7u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E7u, 5u, 3u, cpu.address("abs", 0x6000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A0E7 PEA
    cpu.push16Value(hw, 0x6000u);
    goto L_80A0EA;
L_80A0EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0EAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0EAu, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A0EA JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA0EDu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA0EEu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x80A0EAu); }
    goto L_80A0EE;
L_80A0EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0EEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA0EEu,0x80A0EEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0EEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0EEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A0EE LDA
    cpu.setA(0x8E6Cu, 16);
    goto L_80A0F1;
L_80A0F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A0F1 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80A0F3;
L_80A0F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A0F3 LDA
    cpu.setA(0x8Au, 16);
    goto L_80A0F6;
L_80A0F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A0F6 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_80A0F8;
L_80A0F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F8u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A0F8 LDX
    cpu.setX(0x0u, 16);
    goto L_80A0FB;
L_80A0FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0FBu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0FBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A0FB LDY
    cpu.setY(0x200u, 16);
    goto L_80A0FE;
L_80A0FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0FEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0FEu, 8u, 4u, 0x808BB9u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A0FE JSL -> $808BB9 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA101u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA102u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808BB9u, 0x80A0FEu); }
    goto L_80A102;
L_80A102:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA102u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA102u,0x80A102u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA102u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA102u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A102 LDA
    cpu.setA(0xB991u, 16);
    goto L_80A105;
L_80A105:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA105u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA105u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA105u, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A105 STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_80A108;
L_80A108:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA108u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA108u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA108u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A108 LDA
    cpu.setA(0x8Au, 16);
    goto L_80A10B;
L_80A10B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA10Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Bu, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A10B STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_80A10E;
L_80A10E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA10Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Eu, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A10E JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA111u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA112u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x80A10Eu); }
    goto L_80A112;
L_80A112:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA112u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA112u,0x80A112u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA112u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA112u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A112 PHB
    cpu.push("PHB", hw);
    goto L_80A113;
L_80A113:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA113u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA113u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA113u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A113 LDX
    cpu.setX(0x8000u, 16);
    goto L_80A116;
L_80A116:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA116u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA116u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA116u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A116 LDY
    cpu.setY(0x2800u, 16);
    goto L_80A119;
L_80A119:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA119u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA119u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA119u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A119 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A11B;
L_80A11B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA11Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA11Bu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA11Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A11B DEC
    cpu.decReg('A');
    goto L_80A11C;
L_80A11C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA11Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA11Cu,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xA11Cu, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $80A11C MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_80A11F;
L_80A11F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA11Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA11Fu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA11Fu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A11F PLB
    cpu.pop("PLB", hw);
    goto L_80A120;
L_80A120:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA120u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA120u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA120u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A120 LDA
    cpu.setA(0xB18Fu, 16);
    goto L_80A123;
L_80A123:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA123u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA123u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA123u, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A123 STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_80A126;
L_80A126:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA126u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA126u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA126u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A126 LDA
    cpu.setA(0x8Bu, 16);
    goto L_80A129;
L_80A129:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA129u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA129u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA129u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A129 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_80A12C;
L_80A12C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA12Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA12Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA12Cu, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A12C JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA12Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA130u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x80A12Cu); }
    goto L_80A130;
L_80A130:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA130u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA130u,0x80A130u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA130u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA130u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A130 PHB
    cpu.push("PHB", hw);
    goto L_80A131;
L_80A131:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA131u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA131u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA131u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A131 LDX
    cpu.setX(0x8000u, 16);
    goto L_80A134;
L_80A134:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA134u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA134u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA134u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A134 LDY
    cpu.setY(0x4000u, 16);
    goto L_80A137;
L_80A137:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA137u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA137u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA137u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A137 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A139;
L_80A139:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA139u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA139u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA139u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A139 DEC
    cpu.decReg('A');
    goto L_80A13A;
L_80A13A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA13Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA13Au,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xA13Au, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $80A13A MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_80A13D;
L_80A13D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA13Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA13Du,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA13Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A13D PLB
    cpu.pop("PLB", hw);
    goto L_80A13E;
L_80A13E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA13Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA13Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA13Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A13E LDA
    cpu.setA(0x8E5Fu, 16);
    goto L_80A141;
L_80A141:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA141u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA141u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA141u, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A141 STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_80A144;
L_80A144:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA144u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA144u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA144u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A144 LDA
    cpu.setA(0x89u, 16);
    goto L_80A147;
L_80A147:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA147u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA147u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA147u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A147 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_80A14A;
L_80A14A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA14Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA14Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA14Au, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A14A JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA14Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA14Eu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x80A14Au); }
    goto L_80A14E;
L_80A14E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA14Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA14Eu,0x80A14Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA14Eu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA14Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A14E PHB
    cpu.push("PHB", hw);
    goto L_80A14F;
L_80A14F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA14Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA14Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA14Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A14F LDX
    cpu.setX(0x8000u, 16);
    goto L_80A152;
L_80A152:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA152u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA152u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA152u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A152 LDY
    cpu.setY(0x6000u, 16);
    goto L_80A155;
L_80A155:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA155u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA155u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA155u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A155 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A157;
L_80A157:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA157u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA157u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA157u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A157 DEC
    cpu.decReg('A');
    goto L_80A158;
L_80A158:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA158u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA158u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xA158u, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $80A158 MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_80A15B;
L_80A15B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA15Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA15Bu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA15Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A15B PLB
    cpu.pop("PLB", hw);
    goto L_80A15C;
L_80A15C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA15Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA15Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA15Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A15C LDA
    cpu.setA(0xFFFFu, 16);
    goto L_80A15F;
L_80A15F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA15Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA15Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA15Fu, 8u, 4u, 0x80A460u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A15F JSL -> $80A460 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA162u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA163u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A460u, 0x80A15Fu); }
    goto L_80A163;
L_80A163:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA163u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA163u,0x80A163u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA163u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA163u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A163 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80A163u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80A163u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80AD86_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AD86u: goto L_80AD86;
    case 0x80AD89u: goto L_80AD89;
    case 0x80AD8Cu: goto L_80AD8C;
    case 0x80AD8Fu: goto L_80AD8F;
    case 0x80AD92u: goto L_80AD92;
    case 0x80AD95u: goto L_80AD95;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AD86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD86u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD86u, 6u, 3u, cpu.address("abs", 0xBA9Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AD86 JSR -> $80BA9F stack real
    { cpu.push16Value(hw,0xAD88u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAD89u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBA9Fu), 0x80AD86u); }
    goto L_80AD89;
L_80AD89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD89u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD89u,0x80AD89u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD89u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD89u, 6u, 3u, cpu.address("abs", 0xBAE7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AD89 JSR -> $80BAE7 stack real
    { cpu.push16Value(hw,0xAD8Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAD8Cu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBAE7u), 0x80AD89u); }
    goto L_80AD8C;
L_80AD8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD8Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD8Cu,0x80AD8Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Cu, 6u, 3u, cpu.address("abs", 0xBB30u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AD8C JSR -> $80BB30 stack real
    { cpu.push16Value(hw,0xAD8Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAD8Fu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBB30u), 0x80AD8Cu); }
    goto L_80AD8F;
L_80AD8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD8Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD8Fu,0x80AD8Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Fu, 6u, 3u, cpu.address("abs", 0xBB7Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AD8F JSR -> $80BB7F stack real
    { cpu.push16Value(hw,0xAD91u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAD92u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBB7Fu), 0x80AD8Fu); }
    goto L_80AD92;
L_80AD92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD92u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD92u,0x80AD92u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD92u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD92u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD92 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AD95;
L_80AD95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD95u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD95u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AD95 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AD95u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AD95u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80BD77_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80BD77u: goto L_80BD77;
    case 0x80BD7Au: goto L_80BD7A;
    case 0x80BD7Cu: goto L_80BD7C;
    case 0x80BD7Fu: goto L_80BD7F;
    case 0x80BD81u: goto L_80BD81;
    case 0x80BD84u: goto L_80BD84;
    case 0x80BD87u: goto L_80BD87;
    case 0x80BD89u: goto L_80BD89;
    case 0x80BD8Cu: goto L_80BD8C;
    case 0x80BD8Eu: goto L_80BD8E;
    case 0x80BD90u: goto L_80BD90;
    case 0x80BD93u: goto L_80BD93;
    case 0x80BD94u: goto L_80BD94;
    case 0x80BD97u: goto L_80BD97;
    case 0x80BD98u: goto L_80BD98;
    case 0x80BD9Cu: goto L_80BD9C;
    case 0x80BD9Eu: goto L_80BD9E;
    case 0x80BDA1u: goto L_80BDA1;
    case 0x80BDA3u: goto L_80BDA3;
    case 0x80BDA5u: goto L_80BDA5;
    case 0x80BDA7u: goto L_80BDA7;
    case 0x80BDA9u: goto L_80BDA9;
    case 0x80BDACu: goto L_80BDAC;
    case 0x80BDAFu: goto L_80BDAF;
    case 0x80BDB1u: goto L_80BDB1;
    case 0x80BDB3u: goto L_80BDB3;
    case 0x80BDB6u: goto L_80BDB6;
    case 0x80BDB9u: goto L_80BDB9;
    case 0x80BDBCu: goto L_80BDBC;
    case 0x80BDBFu: goto L_80BDBF;
    case 0x80BDC2u: goto L_80BDC2;
    case 0x80BDC5u: goto L_80BDC5;
    case 0x80BDC7u: goto L_80BDC7;
    case 0x80BDCAu: goto L_80BDCA;
    case 0x80BDCCu: goto L_80BDCC;
    case 0x80BDCEu: goto L_80BDCE;
    case 0x80BDD0u: goto L_80BDD0;
    case 0x80BDD2u: goto L_80BDD2;
    case 0x80BDD5u: goto L_80BDD5;
    case 0x80BDD8u: goto L_80BDD8;
    case 0x80BDDBu: goto L_80BDDB;
    case 0x80BDDDu: goto L_80BDDD;
    case 0x80BDE0u: goto L_80BDE0;
    case 0x80BDE2u: goto L_80BDE2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80BD77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD77u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD77u, 5u, 3u, cpu.address("abs", 0x0952u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD77 STX
    hw.write(cpu.address("abs", 0x952u), cpu.x, cpu.x8?8:16);
    goto L_80BD7A;
L_80BD7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD7Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD7Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD7A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BD7C;
L_80BD7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD7Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD7Cu, 5u, 3u, cpu.address("abs", 0x0954u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD7C STA
    hw.write(cpu.address("abs", 0x954u), cpu.a, cpu.m8?8:16);
    goto L_80BD7F;
L_80BD7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD7Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD7Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD7F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BD81;
L_80BD81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD81u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD81u, 5u, 3u, cpu.address("abs", 0x0956u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD81 STA
    hw.write(cpu.address("abs", 0x956u), cpu.a, cpu.m8?8:16);
    goto L_80BD84;
L_80BD84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD84u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD84u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD84 LDA
    cpu.setA(0x6u, 16);
    goto L_80BD87;
L_80BD87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD87u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD87u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD87 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80BD89;
L_80BD89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD89u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD89u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD89u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD89 LDA
    cpu.setA(0x8u, 16);
    goto L_80BD8C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD89u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD89u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD89 LDA
    cpu.setA(0x8u, 16);
    goto L_80BD8C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD89u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD89u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD89 LDA
    cpu.setA(0x8u, 16);
    goto L_80BD8C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBD89u,0x80BD89u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BD8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD8Cu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD8C STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_80BD8E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD8C STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_80BD8E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD8C STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_80BD8E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBD8Cu,0x80BD8Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BD8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD8Eu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Eu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD8E LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x10u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BD90;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Eu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD8E LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x10u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BD90;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Eu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD8E LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x10u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BD90;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBD8Eu,0x80BD8Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BD90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD90u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD90u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD90u, 5u + 1u, 3u, cpu.address("absy", 0xBDE3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD90 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xBDE3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BD93;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD90u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD90u, 5u + 1u, 3u, cpu.address("absy", 0xBDE3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD90 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xBDE3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BD93;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD90u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD90u, 5u + 1u, 3u, cpu.address("absy", 0xBDE3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD90 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xBDE3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BD93;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBD90u,0x80BD90u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BD93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD93u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD93u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD93u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD93 CLC
    cpu.setFlag('C', false);
    goto L_80BD94;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD93u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD93u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD93 CLC
    cpu.setFlag('C', false);
    goto L_80BD94;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD93u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD93u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD93 CLC
    cpu.setFlag('C', false);
    goto L_80BD94;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBD93u,0x80BD93u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BD94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD94u,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD94u, 5u, 3u, cpu.address("abs", 0x0952u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD94 ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x952u), cpu.m8?8:16));
    goto L_80BD97;
L_80BD97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD97u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD97u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD97 TAX
    cpu.transfer("TAX");
    goto L_80BD98;
L_80BD98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD98u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD98u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD98 LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BD9C;
L_80BD9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD9Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD9Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD9C BNE -> $80BDCC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BDCC; }
    goto L_80BD9E;
L_80BD9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD9Eu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD9Eu, 5u, 3u, cpu.address("abs", 0x0918u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD9E STX
    hw.write(cpu.address("abs", 0x918u), cpu.x, cpu.x8?8:16);
    goto L_80BDA1;
L_80BDA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDA1u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA1u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA1u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDA1 DEC
    cpu.decMem(hw, cpu.address("dp", 0x12u), cpu.m8?8:16);
    goto L_80BDA3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA1u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA1u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDA1 DEC
    cpu.decMem(hw, cpu.address("dp", 0x12u), cpu.m8?8:16);
    goto L_80BDA3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA1u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA1u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDA1 DEC
    cpu.decMem(hw, cpu.address("dp", 0x12u), cpu.m8?8:16);
    goto L_80BDA3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBDA1u,0x80BDA1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BDA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDA3u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA3u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA3u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDA3 DEC
    cpu.decMem(hw, cpu.address("dp", 0x12u), cpu.m8?8:16);
    goto L_80BDA5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA3u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA3u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDA3 DEC
    cpu.decMem(hw, cpu.address("dp", 0x12u), cpu.m8?8:16);
    goto L_80BDA5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA3u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA3u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDA3 DEC
    cpu.decMem(hw, cpu.address("dp", 0x12u), cpu.m8?8:16);
    goto L_80BDA5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBDA3u,0x80BDA3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BDA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDA5u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA5u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDA5 BMI -> $80BDCC
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BDCC; }
    goto L_80BDA7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA5u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDA5 BMI -> $80BDCC
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BDCC; }
    goto L_80BDA7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA5u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDA5 BMI -> $80BDCC
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BDCC; }
    goto L_80BDA7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBDA5u,0x80BDA5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BDA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDA7u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA7u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDA7 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x12u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BDA9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA7u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDA7 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x12u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BDA9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA7u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDA7 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x12u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BDA9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBDA7u,0x80BDA7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BDA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDA9u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA9u, 5u + 1u, 3u, cpu.address("absx", 0x0906u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDA9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x906u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BDAC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA9u, 5u + 1u, 3u, cpu.address("absx", 0x0906u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDA9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x906u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BDAC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA9u, 5u + 1u, 3u, cpu.address("absx", 0x0906u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDA9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x906u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BDAC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBDA9u,0x80BDA9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BDAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDACu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDACu,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDACu, 5u, 3u, cpu.address("abs", 0x097Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDAC CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x97Au), cpu.m8?8:16));
    goto L_80BDAF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDACu,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDACu, 5u, 3u, cpu.address("abs", 0x097Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDAC CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x97Au), cpu.m8?8:16));
    goto L_80BDAF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDACu,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDACu, 5u, 3u, cpu.address("abs", 0x097Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDAC CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x97Au), cpu.m8?8:16));
    goto L_80BDAF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBDACu,0x80BDACu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BDAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDAFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDAFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDAF BNE -> $80BDA1
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BDA1; }
    goto L_80BDB1;
L_80BDB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB1u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDB1 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x10u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BDB3;
L_80BDB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB3u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB3u, 5u + 1u, 3u, cpu.address("absy", 0xBDF3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDB3 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xBDF3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BDB6;
L_80BDB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB6u, 5u, 3u, cpu.address("abs", 0x0920u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDB6 STA
    hw.write(cpu.address("abs", 0x920u), cpu.a, cpu.m8?8:16);
    goto L_80BDB9;
L_80BDB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB9u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB9u, 5u, 3u, cpu.address("abs", 0x091Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDB9 STX
    hw.write(cpu.address("abs", 0x91Eu), cpu.x, cpu.x8?8:16);
    goto L_80BDBC;
L_80BDBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDBCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDBCu, 6u, 3u, cpu.address("abs", 0xBA05u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BDBC JSR -> $80BA05 stack real
    { cpu.push16Value(hw,0xBDBEu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBDBFu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBA05u), 0x80BDBCu); }
    goto L_80BDBF;
L_80BDBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDBFu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBDBFu,0x80BDBFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDBFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDBFu, 5u, 3u, cpu.address("abs", 0x0926u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDBF STA
    hw.write(cpu.address("abs", 0x926u), cpu.a, cpu.m8?8:16);
    goto L_80BDC2;
L_80BDC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDC2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDC2u, 6u, 3u, cpu.address("abs", 0xBE99u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BDC2 JSR -> $80BE99 stack real
    { cpu.push16Value(hw,0xBDC4u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBDC5u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBE99u), 0x80BDC2u); }
    goto L_80BDC5;
L_80BDC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDC5u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDC5u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDC5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDC5 BCS -> $80BDA1
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80BDA1; }
    goto L_80BDC7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDC5u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDC5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDC5 BCS -> $80BDA1
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80BDA1; }
    goto L_80BDC7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBDC5u,0x80BDC5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BDC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDC7u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDC7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDC7u, 6u, 3u, cpu.address("abs", 0xBE03u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BDC7 JSR -> $80BE03 stack real
    { cpu.push16Value(hw,0xBDC9u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBDCAu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBE03u), 0x80BDC7u); }
    goto L_80BDCA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDC7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDC7u, 6u, 3u, cpu.address("abs", 0xBE03u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BDC7 JSR -> $80BE03 stack real
    { cpu.push16Value(hw,0xBDC9u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBDCAu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBE03u), 0x80BDC7u); }
    goto L_80BDCA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBDC7u,0x80BDC7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BDCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDCAu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDCAu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDCAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDCA BRA -> $80BDD5
    goto L_80BDD5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDCAu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDCAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDCA BRA -> $80BDD5
    goto L_80BDD5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDCAu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDCAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDCA BRA -> $80BDD5
    goto L_80BDD5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBDCAu,0x80BDCAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BDCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDCCu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDCCu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDCCu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDCC DEC
    cpu.decMem(hw, cpu.address("dp", 0x10u), cpu.m8?8:16);
    goto L_80BDCE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDCCu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDCCu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDCC DEC
    cpu.decMem(hw, cpu.address("dp", 0x10u), cpu.m8?8:16);
    goto L_80BDCE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDCCu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDCCu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDCC DEC
    cpu.decMem(hw, cpu.address("dp", 0x10u), cpu.m8?8:16);
    goto L_80BDCE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBDCCu,0x80BDCCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BDCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDCEu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDCEu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDCEu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDCE DEC
    cpu.decMem(hw, cpu.address("dp", 0x10u), cpu.m8?8:16);
    goto L_80BDD0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDCEu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDCEu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDCE DEC
    cpu.decMem(hw, cpu.address("dp", 0x10u), cpu.m8?8:16);
    goto L_80BDD0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDCEu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDCEu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDCE DEC
    cpu.decMem(hw, cpu.address("dp", 0x10u), cpu.m8?8:16);
    goto L_80BDD0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBDCEu,0x80BDCEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BDD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDD0u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDD0u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDD0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDD0 BPL -> $80BD89
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BD89; }
    goto L_80BDD2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDD0u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDD0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDD0 BPL -> $80BD89
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BD89; }
    goto L_80BDD2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDD0u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDD0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDD0 BPL -> $80BD89
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BD89; }
    goto L_80BDD2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBDD0u,0x80BDD0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BDD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDD2u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDD2u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDD2u, 8u, 3u, cpu.address("abs", 0x0958u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDD2 INC
    cpu.incMem(hw, cpu.address("abs", 0x958u), cpu.m8?8:16);
    goto L_80BDD5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDD2u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDD2u, 8u, 3u, cpu.address("abs", 0x0958u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDD2 INC
    cpu.incMem(hw, cpu.address("abs", 0x958u), cpu.m8?8:16);
    goto L_80BDD5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDD2u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDD2u, 8u, 3u, cpu.address("abs", 0x0958u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDD2 INC
    cpu.incMem(hw, cpu.address("abs", 0x958u), cpu.m8?8:16);
    goto L_80BDD5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBDD2u,0x80BDD2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BDD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDD5u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDD5u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDD5u, 5u, 3u, cpu.address("abs", 0x0952u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDD5 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x952u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BDD8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDD5u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDD5u, 5u, 3u, cpu.address("abs", 0x0952u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDD5 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x952u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BDD8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDD5u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDD5u, 5u, 3u, cpu.address("abs", 0x0952u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDD5 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x952u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BDD8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBDD5u,0x80BDD5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BDD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDD8u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDD8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDD8u, 5u, 3u, cpu.address("abs", 0x0954u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDD8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x954u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BDDB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDD8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDD8u, 5u, 3u, cpu.address("abs", 0x0954u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDD8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x954u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BDDB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDD8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDD8u, 5u, 3u, cpu.address("abs", 0x0954u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDD8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x954u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BDDB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBDD8u,0x80BDD8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BDDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDDBu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDDBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDDBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDDB STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80BDDD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDDBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDDBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDDB STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80BDDD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDDBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDDBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDDB STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80BDDD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBDDBu,0x80BDDBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BDDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDDDu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDDDu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDDDu, 5u, 3u, cpu.address("abs", 0x0956u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDDD LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x956u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BDE0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDDDu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDDDu, 5u, 3u, cpu.address("abs", 0x0956u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDDD LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x956u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BDE0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDDDu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDDDu, 5u, 3u, cpu.address("abs", 0x0956u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDDD LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x956u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BDE0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBDDDu,0x80BDDDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BDE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDE0u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDE0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDE0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDE0 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_80BDE2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDE0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDE0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDE0 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_80BDE2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDE0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDE0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BDE0 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_80BDE2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBDE0u,0x80BDE0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BDE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDE2u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDE2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDE2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BDE2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80BDE2u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80BDE2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDE2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDE2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BDE2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80BDE2u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80BDE2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDE2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDE2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BDE2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80BDE2u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80BDE2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBDE2u,0x80BDE2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80C85C_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80C85Cu: goto L_80C85C;
    case 0x80C85Du: goto L_80C85D;
    case 0x80C85Eu: goto L_80C85E;
    case 0x80C85Fu: goto L_80C85F;
    case 0x80C862u: goto L_80C862;
    case 0x80C863u: goto L_80C863;
    case 0x80C864u: goto L_80C864;
    case 0x80C867u: goto L_80C867;
    case 0x80C869u: goto L_80C869;
    case 0x80C86Du: goto L_80C86D;
    case 0x80C86Fu: goto L_80C86F;
    case 0x80C872u: goto L_80C872;
    case 0x80C874u: goto L_80C874;
    case 0x80C877u: goto L_80C877;
    case 0x80C87Au: goto L_80C87A;
    case 0x80C87Cu: goto L_80C87C;
    case 0x80C880u: goto L_80C880;
    case 0x80C883u: goto L_80C883;
    case 0x80C886u: goto L_80C886;
    case 0x80C888u: goto L_80C888;
    case 0x80C88Au: goto L_80C88A;
    case 0x80C88Cu: goto L_80C88C;
    case 0x80C88Eu: goto L_80C88E;
    case 0x80C891u: goto L_80C891;
    case 0x80C893u: goto L_80C893;
    case 0x80C896u: goto L_80C896;
    case 0x80C899u: goto L_80C899;
    case 0x80C89Bu: goto L_80C89B;
    case 0x80C89Cu: goto L_80C89C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80C85C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC85Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Cu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C85C PHB
    cpu.push("PHB", hw);
    goto L_80C85D;
L_80C85D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC85Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Du,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C85D PHK
    cpu.push("PHK", hw);
    goto L_80C85E;
L_80C85E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC85Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Eu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C85E PLB
    cpu.pop("PLB", hw);
    goto L_80C85F;
L_80C85F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC85Fu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Fu, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C85F STZ
    hw.write(cpu.address("abs", 0x958u), 0, cpu.m8?8:16);
    goto L_80C862;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Fu, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C85F STZ
    hw.write(cpu.address("abs", 0x958u), 0, cpu.m8?8:16);
    goto L_80C862;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Fu, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C85F STZ
    hw.write(cpu.address("abs", 0x958u), 0, cpu.m8?8:16);
    goto L_80C862;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC85Fu,0x80C85Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C862:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC862u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC862u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC862u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C862 DEX
    cpu.decReg('X');
    goto L_80C863;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC862u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC862u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C862 DEX
    cpu.decReg('X');
    goto L_80C863;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC862u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC862u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C862 DEX
    cpu.decReg('X');
    goto L_80C863;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC862u,0x80C862u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C863:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC863u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC863u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC863u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C863 DEX
    cpu.decReg('X');
    goto L_80C864;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC863u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC863u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C863 DEX
    cpu.decReg('X');
    goto L_80C864;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC863u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC863u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C863 DEX
    cpu.decReg('X');
    goto L_80C864;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC863u,0x80C863u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C864:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC864u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC864u,cpu,0xECu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC864u, 5u, 3u, cpu.address("abs", 0x096Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C864 CPX
    cpu.compareX(hw.readW(cpu.address("abs", 0x96Eu), cpu.x8?8:16));
    goto L_80C867;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC864u,cpu,0xECu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC864u, 5u, 3u, cpu.address("abs", 0x096Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C864 CPX
    cpu.compareX(hw.readW(cpu.address("abs", 0x96Eu), cpu.x8?8:16));
    goto L_80C867;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC864u,cpu,0xECu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC864u, 5u, 3u, cpu.address("abs", 0x096Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C864 CPX
    cpu.compareX(hw.readW(cpu.address("abs", 0x96Eu), cpu.x8?8:16));
    goto L_80C867;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC864u,0x80C864u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C867:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC867u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC867u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC867u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C867 BCC -> $80C88E
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C88E; }
    goto L_80C869;
L_80C869:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC869u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC869u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC869u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C869 LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C86D;
L_80C86D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC86Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC86Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC86Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C86D BEQ -> $80C85F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C85F; }
    goto L_80C86F;
L_80C86F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC86Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC86Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC86Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C86F CMP
    cpu.compareA(0xFFFFu);
    goto L_80C872;
L_80C872:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC872u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC872u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC872u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C872 BEQ -> $80C88A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C88A; }
    goto L_80C874;
L_80C874:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC874u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC874u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC874u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C874 AND
    cpu.logicAnd(0xFu);
    goto L_80C877;
L_80C877:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC877u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC877u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC877u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C877 CMP
    cpu.compareA(0xFu);
    goto L_80C87A;
L_80C87A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC87Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC87Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC87Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C87A BNE -> $80C85F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C85F; }
    goto L_80C87C;
L_80C87C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC87Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC87Cu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC87Cu, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C87C LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C880;
L_80C880:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC880u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC880u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC880u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C880 AND
    cpu.logicAnd(0x300u);
    goto L_80C883;
L_80C883:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC883u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC883u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC883u, 5u, 3u, cpu.address("abs", 0x097Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C883 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x97Au), cpu.m8?8:16));
    goto L_80C886;
L_80C886:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC886u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC886u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC886u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C886 BEQ -> $80C893
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C893; }
    goto L_80C888;
L_80C888:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC888u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC888u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC888u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C888 BRA -> $80C85F
    goto L_80C85F;
L_80C88A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC88Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC88Au,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC88Au, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C88A DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_80C88C;
L_80C88C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC88Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC88Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC88Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C88C BNE -> $80C85F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C85F; }
    goto L_80C88E;
L_80C88E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC88Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC88Eu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC88Eu, 8u, 3u, cpu.address("abs", 0x0958u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C88E INC
    cpu.incMem(hw, cpu.address("abs", 0x958u), cpu.m8?8:16);
    goto L_80C891;
L_80C891:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC891u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC891u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC891u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C891 BRA -> $80C89B
    goto L_80C89B;
L_80C893:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC893u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC893u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC893u, 6u, 3u, cpu.address("abs", 0xBD77u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C893 JSR -> $80BD77 stack real
    { cpu.push16Value(hw,0xC895u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC896u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBD77u), 0x80C893u); }
    goto L_80C896;
L_80C896:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC896u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC896u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC896u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C896 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C899;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC896u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC896u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C896 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C899;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC896u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC896u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C896 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C899;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC896u,0x80C896u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C899:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC899u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC899u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC899u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C899 BNE -> $80C85F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C85F; }
    goto L_80C89B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC899u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC899u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C899 BNE -> $80C85F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C85F; }
    goto L_80C89B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC899u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC899u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C899 BNE -> $80C85F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C85F; }
    goto L_80C89B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC899u,0x80C899u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C89B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC89Bu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC89Bu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC89Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C89B PLB
    cpu.pop("PLB", hw);
    goto L_80C89C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC89Bu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC89Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C89B PLB
    cpu.pop("PLB", hw);
    goto L_80C89C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC89Bu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC89Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C89B PLB
    cpu.pop("PLB", hw);
    goto L_80C89C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC89Bu,0x80C89Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C89C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC89Cu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC89Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC89Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C89C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80C89Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80C89Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC89Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC89Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C89C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80C89Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80C89Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC89Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC89Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C89C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80C89Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80C89Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC89Cu,0x80C89Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80C85C_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80C85Cu: goto L_80C85C;
    case 0x80C85Du: goto L_80C85D;
    case 0x80C85Eu: goto L_80C85E;
    case 0x80C85Fu: goto L_80C85F;
    case 0x80C862u: goto L_80C862;
    case 0x80C863u: goto L_80C863;
    case 0x80C864u: goto L_80C864;
    case 0x80C867u: goto L_80C867;
    case 0x80C869u: goto L_80C869;
    case 0x80C86Du: goto L_80C86D;
    case 0x80C86Fu: goto L_80C86F;
    case 0x80C872u: goto L_80C872;
    case 0x80C874u: goto L_80C874;
    case 0x80C877u: goto L_80C877;
    case 0x80C87Au: goto L_80C87A;
    case 0x80C87Cu: goto L_80C87C;
    case 0x80C880u: goto L_80C880;
    case 0x80C883u: goto L_80C883;
    case 0x80C886u: goto L_80C886;
    case 0x80C888u: goto L_80C888;
    case 0x80C88Au: goto L_80C88A;
    case 0x80C88Cu: goto L_80C88C;
    case 0x80C88Eu: goto L_80C88E;
    case 0x80C891u: goto L_80C891;
    case 0x80C893u: goto L_80C893;
    case 0x80C896u: goto L_80C896;
    case 0x80C899u: goto L_80C899;
    case 0x80C89Bu: goto L_80C89B;
    case 0x80C89Cu: goto L_80C89C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80C85C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC85Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Cu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C85C PHB
    cpu.push("PHB", hw);
    goto L_80C85D;
L_80C85D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC85Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Du,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C85D PHK
    cpu.push("PHK", hw);
    goto L_80C85E;
L_80C85E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC85Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Eu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C85E PLB
    cpu.pop("PLB", hw);
    goto L_80C85F;
L_80C85F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC85Fu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Fu, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C85F STZ
    hw.write(cpu.address("abs", 0x958u), 0, cpu.m8?8:16);
    goto L_80C862;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Fu, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C85F STZ
    hw.write(cpu.address("abs", 0x958u), 0, cpu.m8?8:16);
    goto L_80C862;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Fu, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C85F STZ
    hw.write(cpu.address("abs", 0x958u), 0, cpu.m8?8:16);
    goto L_80C862;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC85Fu,0x80C85Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C862:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC862u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC862u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC862u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C862 DEX
    cpu.decReg('X');
    goto L_80C863;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC862u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC862u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C862 DEX
    cpu.decReg('X');
    goto L_80C863;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC862u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC862u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C862 DEX
    cpu.decReg('X');
    goto L_80C863;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC862u,0x80C862u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C863:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC863u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC863u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC863u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C863 DEX
    cpu.decReg('X');
    goto L_80C864;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC863u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC863u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C863 DEX
    cpu.decReg('X');
    goto L_80C864;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC863u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC863u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C863 DEX
    cpu.decReg('X');
    goto L_80C864;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC863u,0x80C863u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C864:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC864u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC864u,cpu,0xECu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC864u, 5u, 3u, cpu.address("abs", 0x096Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C864 CPX
    cpu.compareX(hw.readW(cpu.address("abs", 0x96Eu), cpu.x8?8:16));
    goto L_80C867;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC864u,cpu,0xECu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC864u, 5u, 3u, cpu.address("abs", 0x096Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C864 CPX
    cpu.compareX(hw.readW(cpu.address("abs", 0x96Eu), cpu.x8?8:16));
    goto L_80C867;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC864u,cpu,0xECu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC864u, 5u, 3u, cpu.address("abs", 0x096Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C864 CPX
    cpu.compareX(hw.readW(cpu.address("abs", 0x96Eu), cpu.x8?8:16));
    goto L_80C867;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC864u,0x80C864u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C867:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC867u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC867u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC867u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C867 BCC -> $80C88E
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C88E; }
    goto L_80C869;
L_80C869:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC869u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC869u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC869u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C869 LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C86D;
L_80C86D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC86Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC86Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC86Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C86D BEQ -> $80C85F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C85F; }
    goto L_80C86F;
L_80C86F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC86Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC86Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC86Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C86F CMP
    cpu.compareA(0xFFFFu);
    goto L_80C872;
L_80C872:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC872u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC872u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC872u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C872 BEQ -> $80C88A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C88A; }
    goto L_80C874;
L_80C874:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC874u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC874u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC874u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C874 AND
    cpu.logicAnd(0xFu);
    goto L_80C877;
L_80C877:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC877u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC877u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC877u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C877 CMP
    cpu.compareA(0xFu);
    goto L_80C87A;
L_80C87A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC87Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC87Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC87Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C87A BNE -> $80C85F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C85F; }
    goto L_80C87C;
L_80C87C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC87Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC87Cu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC87Cu, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C87C LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C880;
L_80C880:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC880u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC880u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC880u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C880 AND
    cpu.logicAnd(0x300u);
    goto L_80C883;
L_80C883:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC883u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC883u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC883u, 5u, 3u, cpu.address("abs", 0x097Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C883 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x97Au), cpu.m8?8:16));
    goto L_80C886;
L_80C886:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC886u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC886u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC886u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C886 BEQ -> $80C893
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C893; }
    goto L_80C888;
L_80C888:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC888u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC888u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC888u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C888 BRA -> $80C85F
    goto L_80C85F;
L_80C88A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC88Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC88Au,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC88Au, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C88A DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_80C88C;
L_80C88C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC88Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC88Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC88Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C88C BNE -> $80C85F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C85F; }
    goto L_80C88E;
L_80C88E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC88Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC88Eu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC88Eu, 8u, 3u, cpu.address("abs", 0x0958u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C88E INC
    cpu.incMem(hw, cpu.address("abs", 0x958u), cpu.m8?8:16);
    goto L_80C891;
L_80C891:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC891u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC891u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC891u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C891 BRA -> $80C89B
    goto L_80C89B;
L_80C893:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC893u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC893u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC893u, 6u, 3u, cpu.address("abs", 0xBD77u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C893 JSR -> $80BD77 stack real
    { cpu.push16Value(hw,0xC895u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC896u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBD77u), 0x80C893u); }
    goto L_80C896;
L_80C896:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC896u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC896u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC896u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C896 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C899;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC896u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC896u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C896 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C899;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC896u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC896u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C896 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C899;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC896u,0x80C896u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C899:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC899u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC899u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC899u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C899 BNE -> $80C85F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C85F; }
    goto L_80C89B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC899u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC899u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C899 BNE -> $80C85F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C85F; }
    goto L_80C89B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC899u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC899u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C899 BNE -> $80C85F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C85F; }
    goto L_80C89B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC899u,0x80C899u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C89B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC89Bu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC89Bu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC89Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C89B PLB
    cpu.pop("PLB", hw);
    goto L_80C89C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC89Bu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC89Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C89B PLB
    cpu.pop("PLB", hw);
    goto L_80C89C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC89Bu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC89Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C89B PLB
    cpu.pop("PLB", hw);
    goto L_80C89C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC89Bu,0x80C89Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C89C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC89Cu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC89Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC89Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C89C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80C89Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80C89Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC89Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC89Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C89C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80C89Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80C89Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC89Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC89Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C89C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80C89Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80C89Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC89Cu,0x80C89Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80C89D_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80C89Du: goto L_80C89D;
    case 0x80C8A0u: goto L_80C8A0;
    case 0x80C8A3u: goto L_80C8A3;
    case 0x80C8A5u: goto L_80C8A5;
    case 0x80C8A8u: goto L_80C8A8;
    case 0x80C8AAu: goto L_80C8AA;
    case 0x80C8ACu: goto L_80C8AC;
    case 0x80C8AEu: goto L_80C8AE;
    case 0x80C8B0u: goto L_80C8B0;
    case 0x80C8B1u: goto L_80C8B1;
    case 0x80C8B2u: goto L_80C8B2;
    case 0x80C8B6u: goto L_80C8B6;
    case 0x80C8B8u: goto L_80C8B8;
    case 0x80C8BBu: goto L_80C8BB;
    case 0x80C8BDu: goto L_80C8BD;
    case 0x80C8BFu: goto L_80C8BF;
    case 0x80C8C2u: goto L_80C8C2;
    case 0x80C8C4u: goto L_80C8C4;
    case 0x80C8C8u: goto L_80C8C8;
    case 0x80C8CAu: goto L_80C8CA;
    case 0x80C8CCu: goto L_80C8CC;
    case 0x80C8CDu: goto L_80C8CD;
    case 0x80C8CFu: goto L_80C8CF;
    case 0x80C8D3u: goto L_80C8D3;
    case 0x80C8D5u: goto L_80C8D5;
    case 0x80C8D9u: goto L_80C8D9;
    case 0x80C8DCu: goto L_80C8DC;
    case 0x80C8E0u: goto L_80C8E0;
    case 0x80C8E2u: goto L_80C8E2;
    case 0x80C8E4u: goto L_80C8E4;
    case 0x80C8E6u: goto L_80C8E6;
    case 0x80C8E8u: goto L_80C8E8;
    case 0x80C8EAu: goto L_80C8EA;
    case 0x80C8ECu: goto L_80C8EC;
    case 0x80C8EEu: goto L_80C8EE;
    case 0x80C8F0u: goto L_80C8F0;
    case 0x80C8F2u: goto L_80C8F2;
    case 0x80C8F4u: goto L_80C8F4;
    case 0x80C8F6u: goto L_80C8F6;
    case 0x80C8F9u: goto L_80C8F9;
    case 0x80C8FDu: goto L_80C8FD;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80C89D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC89Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC89Du,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC89Du, 5u, 3u, cpu.address("abs", 0x096Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C89D LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x96Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C8A0;
L_80C8A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8A0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8A0u, 5u, 3u, cpu.address("abs", 0x0970u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8A0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x970u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C8A3;
L_80C8A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8A3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8A3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8A3 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80C8A5;
L_80C8A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8A5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8A5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8A5 LDA
    cpu.setA(0x3Cu, 16);
    goto L_80C8A8;
L_80C8A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8A8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8A8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8A8 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_80C8AA;
L_80C8AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8AAu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8AAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8AA STZ
    hw.write(cpu.address("dp", 0x63u), 0, cpu.m8?8:16);
    goto L_80C8AC;
L_80C8AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8ACu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8ACu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8ACu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8AC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C8AE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8ACu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8ACu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8AC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C8AE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC8ACu,0x80C8ACu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C8AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8AEu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8AEu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8AEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8AE BMI -> $80C8F4
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80C8F4; }
    goto L_80C8B0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8AEu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8AEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8AE BMI -> $80C8F4
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80C8F4; }
    goto L_80C8B0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC8AEu,0x80C8AEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C8B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8B0u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8B0u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8B0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8B0 INX
    cpu.inc('X');
    goto L_80C8B1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8B0u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8B0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8B0 INX
    cpu.inc('X');
    goto L_80C8B1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC8B0u,0x80C8B0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C8B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8B1u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8B1u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8B1 INX
    cpu.inc('X');
    goto L_80C8B2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8B1u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8B1 INX
    cpu.inc('X');
    goto L_80C8B2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC8B1u,0x80C8B1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C8B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8B2u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8B2u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8B2u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8B2 LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C8B6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8B2u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8B2u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8B2 LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C8B6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC8B2u,0x80C8B2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C8B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8B6u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8B6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8B6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8B6 BEQ -> $80C8AC
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C8AC; }
    goto L_80C8B8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8B6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8B6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8B6 BEQ -> $80C8AC
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C8AC; }
    goto L_80C8B8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC8B6u,0x80C8B6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C8B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8B8u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8B8u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8B8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8B8 CMP
    cpu.compareA(0xFFFFu);
    goto L_80C8BB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8B8u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8B8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8B8 CMP
    cpu.compareA(0xFFFFu);
    goto L_80C8BB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC8B8u,0x80C8B8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C8BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8BBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8BBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8BB BEQ -> $80C8F0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C8F0; }
    goto L_80C8BD;
L_80C8BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8BDu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8BDu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8BD DEC
    cpu.decMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_80C8BF;
L_80C8BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8BFu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8BFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8BF AND
    cpu.logicAnd(0x300u);
    goto L_80C8C2;
L_80C8C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8C2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8C2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8C2 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80C8C4;
L_80C8C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8C4u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8C4u, 6u, 4u, ((0x7E1FEAu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8C4 LDA
    cpu.loadA(hw.readW(((0x7E1FEAu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C8C8;
L_80C8C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8C8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8C8 BNE -> $80C8AC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C8AC; }
    goto L_80C8CA;
L_80C8CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8CAu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8CAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8CA STX
    hw.write(cpu.address("dp", 0x61u), cpu.x, cpu.x8?8:16);
    goto L_80C8CC;
L_80C8CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8CCu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8CCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8CC TXA
    cpu.transfer("TXA");
    goto L_80C8CD;
L_80C8CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8CDu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8CDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8CD LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C8CF;
L_80C8CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8CFu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8CFu, 6u, 4u, ((0x7E2444u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8CF STA
    hw.write(((0x7E2444u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80C8D3;
L_80C8D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8D3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8D3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8D3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C8D5;
L_80C8D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8D5u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8D5u, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8D5 STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80C8D9;
L_80C8D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8D9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8D9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8D9 LDA
    cpu.setA(0x4u, 16);
    goto L_80C8DC;
L_80C8DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8DCu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8DCu, 6u, 4u, ((0x7E2442u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8DC STA
    hw.write(((0x7E2442u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80C8E0;
L_80C8E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8E0u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8E0u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8E0 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C8E2;
L_80C8E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8E2u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8E2u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8E2 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C8E4;
L_80C8E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8E4u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8E4u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8E4 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C8E6;
L_80C8E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8E6u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8E6u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8E6 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C8E8;
L_80C8E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8E8u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8E8u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8E8 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C8EA;
L_80C8EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8EAu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8EAu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8EA INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C8EC;
L_80C8EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8ECu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8ECu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8EC LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C8EE;
L_80C8EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8EEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8EEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8EE BRA -> $80C8AC
    goto L_80C8AC;
L_80C8F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8F0u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8F0u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8F0 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_80C8F2;
L_80C8F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8F2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8F2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8F2 BNE -> $80C8AC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C8AC; }
    goto L_80C8F4;
L_80C8F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8F4u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8F4u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8F4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8F4 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C8F6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8F4u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8F4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8F4 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C8F6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC8F4u,0x80C8F4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C8F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8F6u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8F6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8F6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8F6 LDA
    cpu.setA(0xFFFFu, 16);
    goto L_80C8F9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8F6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8F6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8F6 LDA
    cpu.setA(0xFFFFu, 16);
    goto L_80C8F9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC8F6u,0x80C8F6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C8F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8F9u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8F9u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8F9u, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8F9 STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80C8FD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8F9u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8F9u, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C8F9 STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80C8FD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC8F9u,0x80C8F9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80C8FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC8FDu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8FDu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8FDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C8FD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80C8FDu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80C8FDu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC8FDu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC8FDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C8FD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80C8FDu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80C8FDu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC8FDu,0x80C8FDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82A7C0_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82A7C0u: goto L_82A7C0;
    case 0x82A7C3u: goto L_82A7C3;
    case 0x82A7C6u: goto L_82A7C6;
    case 0x82A7C8u: goto L_82A7C8;
    case 0x82A7CBu: goto L_82A7CB;
    case 0x82A7CDu: goto L_82A7CD;
    case 0x82A7CFu: goto L_82A7CF;
    case 0x82A7D1u: goto L_82A7D1;
    case 0x82A7D4u: goto L_82A7D4;
    case 0x82A7D6u: goto L_82A7D6;
    case 0x82A7D9u: goto L_82A7D9;
    case 0x82A7DBu: goto L_82A7DB;
    case 0x82A7DCu: goto L_82A7DC;
    case 0x82A7DFu: goto L_82A7DF;
    case 0x82A7E0u: goto L_82A7E0;
    case 0x82A7E4u: goto L_82A7E4;
    case 0x82A7E7u: goto L_82A7E7;
    case 0x82A7EAu: goto L_82A7EA;
    case 0x82A7EDu: goto L_82A7ED;
    case 0x82A7F0u: goto L_82A7F0;
    case 0x82A7F3u: goto L_82A7F3;
    case 0x82A7F6u: goto L_82A7F6;
    case 0x82A7F7u: goto L_82A7F7;
    case 0x82A7F8u: goto L_82A7F8;
    case 0x82A7F9u: goto L_82A7F9;
    case 0x82A7FBu: goto L_82A7FB;
    case 0x82A7FFu: goto L_82A7FF;
    case 0x82A802u: goto L_82A802;
    case 0x82A803u: goto L_82A803;
    case 0x82A805u: goto L_82A805;
    case 0x82A808u: goto L_82A808;
    case 0x82A80Bu: goto L_82A80B;
    case 0x82A80Eu: goto L_82A80E;
    case 0x82A811u: goto L_82A811;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82A7C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C0u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7C0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A7C3;
L_82A7C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C3u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7C3 CMP
    cpu.compareA(0x2u);
    goto L_82A7C6;
L_82A7C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C6u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7C6 BCS -> $82A7CD
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82A7CD; }
    goto L_82A7C8;
L_82A7C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7C8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7C8 LDA
    cpu.setA(0x0u, 16);
    goto L_82A7CB;
L_82A7CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7CBu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7CBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7CB BRA -> $82A7D9
    goto L_82A7D9;
L_82A7CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7CDu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7CDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7CD LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A7CF;
L_82A7CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7CFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7CFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7CF BNE -> $82A7D6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A7D6; }
    goto L_82A7D1;
L_82A7D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7D1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7D1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7D1 LDA
    cpu.setA(0xAu, 16);
    goto L_82A7D4;
L_82A7D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7D4u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7D4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7D4 BRA -> $82A7D9
    goto L_82A7D9;
L_82A7D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7D6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7D6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7D6 LDA
    cpu.setA(0x14u, 16);
    goto L_82A7D9;
L_82A7D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7D9u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7D9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7D9 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A7DB;
L_82A7DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7DBu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7DBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7DB CLC
    cpu.setFlag('C', false);
    goto L_82A7DC;
L_82A7DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7DCu,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7DCu, 5u + 1u, 3u, cpu.address("absy", 0x0206u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7DC ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x206u), cpu.m8?8:16));
    goto L_82A7DF;
L_82A7DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7DFu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7DFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7DF TAX
    cpu.transfer("TAX");
    goto L_82A7E0;
L_82A7E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E0u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E0u, 6u, 4u, ((0x82A812u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7E0 LDA
    cpu.loadA(hw.readW(((0x82A812u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A7E4;
L_82A7E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7E4 AND
    cpu.logicAnd(0xFFu);
    goto L_82A7E7;
L_82A7E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E7u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7E7u, 6u, 3u, cpu.address("absy", 0x0276u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7E7 STA
    hw.write(cpu.address("absy", 0x276u), cpu.a, cpu.m8?8:16);
    goto L_82A7EA;
L_82A7EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7EAu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7EAu, 6u, 3u, cpu.address("absy", 0x0278u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7EA STA
    hw.write(cpu.address("absy", 0x278u), cpu.a, cpu.m8?8:16);
    goto L_82A7ED;
L_82A7ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7EDu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7EDu, 6u, 3u, cpu.address("absy", 0x027Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7ED STA
    hw.write(cpu.address("absy", 0x27Au), cpu.a, cpu.m8?8:16);
    goto L_82A7F0;
L_82A7F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F0u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F0u, 6u, 3u, cpu.address("absy", 0x027Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7F0 STA
    hw.write(cpu.address("absy", 0x27Cu), cpu.a, cpu.m8?8:16);
    goto L_82A7F3;
L_82A7F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F3u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F3u, 5u + 1u, 3u, cpu.address("absy", 0x0400u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7F3 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x400u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A7F6;
L_82A7F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7F6 ASL
    cpu.aslA();
    goto L_82A7F7;
L_82A7F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7F7 ASL
    cpu.aslA();
    goto L_82A7F8;
L_82A7F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F8u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7F8 ASL
    cpu.aslA();
    goto L_82A7F9;
L_82A7F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7F9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7F9 STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_82A7FB;
L_82A7FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FBu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FBu, 6u, 4u, ((0x82A830u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7FB LDA
    cpu.loadA(hw.readW(((0x82A830u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A7FF;
L_82A7FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA7FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FFu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA7FFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A7FF AND
    cpu.logicAnd(0xFFu);
    goto L_82A802;
L_82A802:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA802u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA802u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA802u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A802 CLC
    cpu.setFlag('C', false);
    goto L_82A803;
L_82A803:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA803u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA803u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA803u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A803 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16));
    goto L_82A805;
L_82A805:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA805u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA805u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA805u, 6u, 3u, cpu.address("absy", 0x027Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A805 STA
    hw.write(cpu.address("absy", 0x27Eu), cpu.a, cpu.m8?8:16);
    goto L_82A808;
L_82A808:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA808u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA808u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA808u, 6u, 3u, cpu.address("absy", 0x0280u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A808 STA
    hw.write(cpu.address("absy", 0x280u), cpu.a, cpu.m8?8:16);
    goto L_82A80B;
L_82A80B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA80Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA80Bu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA80Bu, 6u, 3u, cpu.address("absy", 0x0282u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A80B STA
    hw.write(cpu.address("absy", 0x282u), cpu.a, cpu.m8?8:16);
    goto L_82A80E;
L_82A80E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA80Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA80Eu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA80Eu, 6u, 3u, cpu.address("absy", 0x0284u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A80E STA
    hw.write(cpu.address("absy", 0x284u), cpu.a, cpu.m8?8:16);
    goto L_82A811;
L_82A811:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA811u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA811u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA811u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A811 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A811u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A811u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82AF78_E0M1X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82AF78u: goto L_82AF78;
    case 0x82AF7Au: goto L_82AF7A;
    case 0x82AF7Eu: goto L_82AF7E;
    case 0x82AF81u: goto L_82AF81;
    case 0x82AF84u: goto L_82AF84;
    case 0x82AF87u: goto L_82AF87;
    case 0x82AF8Bu: goto L_82AF8B;
    case 0x82AF8Eu: goto L_82AF8E;
    case 0x82AF91u: goto L_82AF91;
    case 0x82AF94u: goto L_82AF94;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82AF78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF78u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF78u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF78 REP
    cpu.rep(0x20u);
    goto L_82AF7A;
L_82AF7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Au, 8u, 4u, 0x809D16u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AF7A JSL -> $809D16 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAF7Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF7Eu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809D16u, 0x82AF7Au); }
    goto L_82AF7E;
L_82AF7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF7Eu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF7E LDA
    cpu.setA(0x800u, 16);
    goto L_82AF81;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF7E LDA
    cpu.setA(0x800u, 16);
    goto L_82AF81;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF7Eu,0x82AF7Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82AF81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF81u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF81u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF81u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF81 LDX
    cpu.setX(0x2800u, 16);
    goto L_82AF84;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF81u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF81u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF81 LDX
    cpu.setX(0x2800u, 16);
    goto L_82AF84;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF81u,0x82AF81u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82AF84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF84u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF84u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF84u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF84 LDY
    cpu.setY(0x5000u, 16);
    goto L_82AF87;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF84u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF84u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF84 LDY
    cpu.setY(0x5000u, 16);
    goto L_82AF87;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF84u,0x82AF84u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82AF87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF87u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF87u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF87u, 8u, 4u, 0x808EBFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AF87 JSL -> $808EBF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAF8Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF8Bu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808EBFu, 0x82AF87u); }
    goto L_82AF8B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF87u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF87u, 8u, 4u, 0x808EBFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AF87 JSL -> $808EBF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAF8Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF8Bu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808EBFu, 0x82AF87u); }
    goto L_82AF8B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF87u,0x82AF87u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82AF8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF8Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Bu, 6u, 3u, cpu.address("abs", 0xC781u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AF8B JSR -> $82C781 stack real
    { cpu.push16Value(hw,0xAF8Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF8Eu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC781u), 0x82AF8Bu); }
    goto L_82AF8E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Bu, 6u, 3u, cpu.address("abs", 0xC781u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AF8B JSR -> $82C781 stack real
    { cpu.push16Value(hw,0xAF8Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF8Eu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC781u), 0x82AF8Bu); }
    goto L_82AF8E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF8Bu,0x82AF8Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82AF8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF8Eu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Eu, 6u, 3u, cpu.address("abs", 0xDAB2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AF8E JSR -> $82DAB2 stack real
    { cpu.push16Value(hw,0xAF90u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF91u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xDAB2u), 0x82AF8Eu); }
    goto L_82AF91;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Eu, 6u, 3u, cpu.address("abs", 0xDAB2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AF8E JSR -> $82DAB2 stack real
    { cpu.push16Value(hw,0xAF90u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF91u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xDAB2u), 0x82AF8Eu); }
    goto L_82AF91;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF8Eu,0x82AF8Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82AF91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF91u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF91u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF91u, 6u, 3u, cpu.address("abs", 0xD7FDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AF91 JSR -> $82D7FD stack real
    { cpu.push16Value(hw,0xAF93u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF94u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD7FDu), 0x82AF91u); }
    goto L_82AF94;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF91u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF91u, 6u, 3u, cpu.address("abs", 0xD7FDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AF91 JSR -> $82D7FD stack real
    { cpu.push16Value(hw,0xAF93u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF94u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD7FDu), 0x82AF91u); }
    goto L_82AF94;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF91u,0x82AF91u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82AF94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF94u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF94u,0x82AF94u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF94u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF94u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AF94 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82AF94u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82AF94u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82AF78_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82AF78u: goto L_82AF78;
    case 0x82AF7Au: goto L_82AF7A;
    case 0x82AF7Eu: goto L_82AF7E;
    case 0x82AF81u: goto L_82AF81;
    case 0x82AF84u: goto L_82AF84;
    case 0x82AF87u: goto L_82AF87;
    case 0x82AF8Bu: goto L_82AF8B;
    case 0x82AF8Eu: goto L_82AF8E;
    case 0x82AF91u: goto L_82AF91;
    case 0x82AF94u: goto L_82AF94;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82AF78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF78u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF78u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF78 REP
    cpu.rep(0x20u);
    goto L_82AF7A;
L_82AF7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Au, 8u, 4u, 0x809D16u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AF7A JSL -> $809D16 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAF7Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF7Eu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809D16u, 0x82AF7Au); }
    goto L_82AF7E;
L_82AF7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF7Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF7Eu,0x82AF7Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF7E LDA
    cpu.setA(0x800u, 16);
    goto L_82AF81;
L_82AF81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF81u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF81u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF81 LDX
    cpu.setX(0x2800u, 16);
    goto L_82AF84;
L_82AF84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF84u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF84u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF84 LDY
    cpu.setY(0x5000u, 16);
    goto L_82AF87;
L_82AF87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF87u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF87u, 8u, 4u, 0x808EBFu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AF87 JSL -> $808EBF stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAF8Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF8Bu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808EBFu, 0x82AF87u); }
    goto L_82AF8B;
L_82AF8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF8Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF8Bu,0x82AF8Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Bu, 6u, 3u, cpu.address("abs", 0xC781u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AF8B JSR -> $82C781 stack real
    { cpu.push16Value(hw,0xAF8Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF8Eu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC781u), 0x82AF8Bu); }
    goto L_82AF8E;
L_82AF8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF8Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF8Eu,0x82AF8Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Eu, 6u, 3u, cpu.address("abs", 0xDAB2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AF8E JSR -> $82DAB2 stack real
    { cpu.push16Value(hw,0xAF90u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF91u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xDAB2u), 0x82AF8Eu); }
    goto L_82AF91;
L_82AF91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF91u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF91u,0x82AF91u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF91u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF91u, 6u, 3u, cpu.address("abs", 0xD7FDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AF91 JSR -> $82D7FD stack real
    { cpu.push16Value(hw,0xAF93u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF94u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD7FDu), 0x82AF91u); }
    goto L_82AF94;
L_82AF94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF94u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF94u,0x82AF94u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF94u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF94u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AF94 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82AF94u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82AF94u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82AFF7_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82AFF7u: goto L_82AFF7;
    case 0x82AFFAu: goto L_82AFFA;
    case 0x82AFFCu: goto L_82AFFC;
    case 0x82AFFFu: goto L_82AFFF;
    case 0x82B002u: goto L_82B002;
    case 0x82B005u: goto L_82B005;
    case 0x82B007u: goto L_82B007;
    case 0x82B00Au: goto L_82B00A;
    case 0x82B00Du: goto L_82B00D;
    case 0x82B010u: goto L_82B010;
    case 0x82B012u: goto L_82B012;
    case 0x82B014u: goto L_82B014;
    case 0x82B016u: goto L_82B016;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82AFF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF7u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFF7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFF7 LDX
    cpu.setX(0x0u, 16);
    goto L_82AFFA;
L_82AFFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFFAu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFFAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFFA STX
    hw.write(cpu.address("dp", 0x5Bu), cpu.x, cpu.x8?8:16);
    goto L_82AFFC;
L_82AFFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFFCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFFCu, 6u, 3u, cpu.address("abs", 0xA92Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AFFC JSR -> $82A92A stack real
    { cpu.push16Value(hw,0xAFFEu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAFFFu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA92Au), 0x82AFFCu); }
    goto L_82AFFF;
L_82AFFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFFFu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFFFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFFFu, 6u, 3u, cpu.address("abs", 0xA5D0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AFFF JSR -> $82A5D0 stack real
    { cpu.push16Value(hw,0xB001u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB002u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA5D0u), 0x82AFFFu); }
    goto L_82B002;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFFFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFFFu, 6u, 3u, cpu.address("abs", 0xA5D0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AFFF JSR -> $82A5D0 stack real
    { cpu.push16Value(hw,0xB001u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB002u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA5D0u), 0x82AFFFu); }
    goto L_82B002;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAFFFu,0x82AFFFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B002:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB002u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB002u,0x82B002u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB002u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB002u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B002 LDX
    cpu.setX(0x100u, 16);
    goto L_82B005;
L_82B005:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB005u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB005u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB005u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B005 STX
    hw.write(cpu.address("dp", 0x5Bu), cpu.x, cpu.x8?8:16);
    goto L_82B007;
L_82B007:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB007u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB007u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB007u, 6u, 3u, cpu.address("abs", 0xA92Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B007 JSR -> $82A92A stack real
    { cpu.push16Value(hw,0xB009u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB00Au,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA92Au), 0x82B007u); }
    goto L_82B00A;
L_82B00A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB00Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB00Au,0x82B00Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB00Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB00Au, 6u, 3u, cpu.address("abs", 0xA5D0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B00A JSR -> $82A5D0 stack real
    { cpu.push16Value(hw,0xB00Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB00Du,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA5D0u), 0x82B00Au); }
    goto L_82B00D;
L_82B00D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB00Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB00Du,0x82B00Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB00Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB00Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B00D LDA
    cpu.setA(0x80u, 16);
    goto L_82B010;
L_82B010:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB010u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB010u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB010u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B010 STA
    hw.write(cpu.address("dp", 0x6Fu), cpu.a, cpu.m8?8:16);
    goto L_82B012;
L_82B012:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB012u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB012u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB012u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B012 SEP
    cpu.sep(0x20u);
    goto L_82B014;
L_82B014:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB014u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB014u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB014u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B014 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_82B016;
L_82B016:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB016u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB016u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB016u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B016 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B016u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B016u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B268_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B268u: goto L_82B268;
    case 0x82B26Au: goto L_82B26A;
    case 0x82B26Cu: goto L_82B26C;
    case 0x82B26Eu: goto L_82B26E;
    case 0x82B270u: goto L_82B270;
    case 0x82B272u: goto L_82B272;
    case 0x82B274u: goto L_82B274;
    case 0x82B276u: goto L_82B276;
    case 0x82B278u: goto L_82B278;
    case 0x82B27Au: goto L_82B27A;
    case 0x82B27Du: goto L_82B27D;
    case 0x82B280u: goto L_82B280;
    case 0x82B283u: goto L_82B283;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B268:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB268u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB268u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB268u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B268 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B26A;
L_82B26A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB26Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B26A BNE -> $82B27A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B27A; }
    goto L_82B26C;
L_82B26C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB26Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B26C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B26E;
L_82B26E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB26Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Eu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB26Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B26E ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Eu), cpu.m8?8:16));
    goto L_82B270;
L_82B270:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB270u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB270u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB270u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B270 BEQ -> $82B27A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B27A; }
    goto L_82B272;
L_82B272:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB272u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB272u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB272u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B272 SEP
    cpu.sep(0x20u);
    goto L_82B274;
L_82B274:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB274u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB274u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB274u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B274 LDA
    cpu.setA(0xBu, 8);
    goto L_82B276;
L_82B276:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB276u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB276u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB276u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B276 STA
    hw.write(cpu.address("dp", 0x49u), cpu.a, cpu.m8?8:16);
    goto L_82B278;
L_82B278:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB278u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB278u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB278u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B278 REP
    cpu.rep(0x20u);
    goto L_82B27A;
L_82B27A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB27Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Au, 6u, 3u, cpu.address("abs", 0xCAA5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B27A JSR -> $82CAA5 stack real
    { cpu.push16Value(hw,0xB27Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB27Du,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCAA5u), 0x82B27Au); }
    goto L_82B27D;
L_82B27D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB27Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB27Du,0x82B27Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Du, 6u, 3u, cpu.address("abs", 0xD5A3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B27D JSR -> $82D5A3 stack real
    { cpu.push16Value(hw,0xB27Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB280u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD5A3u), 0x82B27Du); }
    goto L_82B280;
L_82B280:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB280u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB280u,0x82B280u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB280u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB280u, 6u, 3u, cpu.address("abs", 0xD4F9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B280 JSR -> $82D4F9 stack real
    { cpu.push16Value(hw,0xB282u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB283u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD4F9u), 0x82B280u); }
    goto L_82B283;
L_82B283:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB283u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB283u,0x82B283u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB283u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB283u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B283 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B283u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B283u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B4F0_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B4F0u: goto L_82B4F0;
    case 0x82B4F2u: goto L_82B4F2;
    case 0x82B4F4u: goto L_82B4F4;
    case 0x82B4F6u: goto L_82B4F6;
    case 0x82B4F8u: goto L_82B4F8;
    case 0x82B4FAu: goto L_82B4FA;
    case 0x82B4FCu: goto L_82B4FC;
    case 0x82B4FFu: goto L_82B4FF;
    case 0x82B500u: goto L_82B500;
    case 0x82B503u: goto L_82B503;
    case 0x82B504u: goto L_82B504;
    case 0x82B507u: goto L_82B507;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B4F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4F0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B4F2;
L_82B4F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F2u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4F2 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16));
    goto L_82B4F4;
L_82B4F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4F4 BEQ -> $82B504
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B504; }
    goto L_82B4F6;
L_82B4F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4F6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B4F8;
L_82B4F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F8u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4F8 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0xFu), cpu.m8?8:16));
    goto L_82B4FA;
L_82B4FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4FA BEQ -> $82B500
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B500; }
    goto L_82B4FC;
L_82B4FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FCu, 6u, 3u, cpu.address("abs", 0xB559u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B4FC JSR -> $82B559 stack real
    { cpu.push16Value(hw,0xB4FEu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB4FFu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB559u), 0x82B4FCu); }
    goto L_82B4FF;
L_82B4FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4FFu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B4FF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B4FFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B4FFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B4FF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B4FFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B4FFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B4FF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B4FFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B4FFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB4FFu,0x82B4FFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B500:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB500u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB500u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB500u, 6u, 3u, cpu.address("abs", 0xB5D8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B500 JSR -> $82B5D8 stack real
    { cpu.push16Value(hw,0xB502u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB503u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB5D8u), 0x82B500u); }
    goto L_82B503;
L_82B503:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB503u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB503u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB503u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B503 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B503u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B503u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB503u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB503u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B503 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B503u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B503u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB503u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB503u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B503 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B503u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B503u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB503u,0x82B503u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B504:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB504u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB504u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB504u, 6u, 3u, cpu.address("abs", 0xB64Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B504 JSR -> $82B64A stack real
    { cpu.push16Value(hw,0xB506u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB507u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB64Au), 0x82B504u); }
    goto L_82B507;
L_82B507:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB507u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB507u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB507u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B507 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B507u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B507u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB507u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB507u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B507 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B507u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B507u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB507u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB507u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B507 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B507u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B507u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB507u,0x82B507u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82B937_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B937u: goto L_82B937;
    case 0x82B93Au: goto L_82B93A;
    case 0x82B93Cu: goto L_82B93C;
    case 0x82B93Fu: goto L_82B93F;
    case 0x82B941u: goto L_82B941;
    case 0x82B944u: goto L_82B944;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B937:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB937u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB937u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB937u, 6u, 3u, cpu.address("abs", 0xB9B0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B937 JSR -> $82B9B0 stack real
    { cpu.push16Value(hw,0xB939u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB93Au,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB9B0u), 0x82B937u); }
    goto L_82B93A;
L_82B93A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB93Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB93Au,0x82B93Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB93Au,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB93Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B93A LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B93C;
L_82B93C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB93Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB93Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB93Cu, 6u, 3u, cpu.address("abs", 0xB998u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B93C JSR -> $82B998 stack real
    { cpu.push16Value(hw,0xB93Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB93Fu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB998u), 0x82B93Cu); }
    goto L_82B93F;
L_82B93F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB93Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB93Fu,0x82B93Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB93Fu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB93Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B93F LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B941;
L_82B941:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB941u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB941u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB941u, 6u, 3u, cpu.address("abs", 0xB9A2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B941 JSR -> $82B9A2 stack real
    { cpu.push16Value(hw,0xB943u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB944u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB9A2u), 0x82B941u); }
    goto L_82B944;
L_82B944:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB944u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB944u,0x82B944u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB944u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB944u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B944 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B944u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B944u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82D4C4_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82D4C4u: goto L_82D4C4;
    case 0x82D4C7u: goto L_82D4C7;
    case 0x82D4CAu: goto L_82D4CA;
    case 0x82D4CDu: goto L_82D4CD;
    case 0x82D4D0u: goto L_82D4D0;
    case 0x82D4D3u: goto L_82D4D3;
    case 0x82D4D5u: goto L_82D4D5;
    case 0x82D4D8u: goto L_82D4D8;
    case 0x82D4DAu: goto L_82D4DA;
    case 0x82D4DCu: goto L_82D4DC;
    case 0x82D4DEu: goto L_82D4DE;
    case 0x82D4E0u: goto L_82D4E0;
    case 0x82D4E3u: goto L_82D4E3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82D4C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4C4u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4C4u, 8u, 3u, cpu.address("abs", 0x014Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4C4 INC
    cpu.incMem(hw, cpu.address("abs", 0x14Au), cpu.m8?8:16);
    goto L_82D4C7;
L_82D4C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4C7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4C7u, 6u, 3u, cpu.address("abs", 0xD5A3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D4C7 JSR -> $82D5A3 stack real
    { cpu.push16Value(hw,0xD4C9u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD4CAu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD5A3u), 0x82D4C7u); }
    goto L_82D4CA;
L_82D4CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4CAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD4CAu,0x82D4CAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4CAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4CAu, 6u, 3u, cpu.address("abs", 0xD5DFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D4CA JSR -> $82D5DF stack real
    { cpu.push16Value(hw,0xD4CCu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD4CDu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD5DFu), 0x82D4CAu); }
    goto L_82D4CD;
L_82D4CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4CDu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD4CDu,0x82D4CDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4CDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4CDu, 6u, 3u, cpu.address("abs", 0xD4F9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D4CD JSR -> $82D4F9 stack real
    { cpu.push16Value(hw,0xD4CFu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD4D0u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD4F9u), 0x82D4CDu); }
    goto L_82D4D0;
L_82D4D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4D0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD4D0u,0x82D4D0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4D0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4D0u, 5u, 3u, cpu.address("abs", 0x018Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4D0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D4D3;
L_82D4D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4D3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4D3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4D3 BEQ -> $82D4DA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D4DA; }
    goto L_82D4D5;
L_82D4D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4D5u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4D5u, 8u, 3u, cpu.address("abs", 0x018Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4D5 DEC
    cpu.decMem(hw, cpu.address("abs", 0x18Bu), cpu.m8?8:16);
    goto L_82D4D8;
L_82D4D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4D8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4D8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4D8 BNE -> $82D4E3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D4E3; }
    goto L_82D4DA;
L_82D4DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4DAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4DAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4DA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D4DC;
L_82D4DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4DCu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4DCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4DC ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x9Eu), cpu.m8?8:16));
    goto L_82D4DE;
L_82D4DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4DEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4DEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4DE BEQ -> $82D4E3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D4E3; }
    goto L_82D4E0;
L_82D4E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4E0u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4E0u, 8u, 3u, cpu.address("abs", 0x0141u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4E0 INC
    cpu.incMem(hw, cpu.address("abs", 0x141u), cpu.m8?8:16);
    goto L_82D4E3;
L_82D4E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4E3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4E3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D4E3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D4E3u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D4E3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82DE38_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82DE38u: goto L_82DE38;
    case 0x82DE3Bu: goto L_82DE3B;
    case 0x82DE3Du: goto L_82DE3D;
    case 0x82DE40u: goto L_82DE40;
    case 0x82DE41u: goto L_82DE41;
    case 0x82DE44u: goto L_82DE44;
    case 0x82DE46u: goto L_82DE46;
    case 0x82DE49u: goto L_82DE49;
    case 0x82DE4Cu: goto L_82DE4C;
    case 0x82DE4Fu: goto L_82DE4F;
    case 0x82DE52u: goto L_82DE52;
    case 0x82DE53u: goto L_82DE53;
    case 0x82DE56u: goto L_82DE56;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82DE38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE38u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE38u, 5u, 3u, cpu.address("abs", 0x013Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DE38 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DE3B;
L_82DE3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE3Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE3Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DE3B BEQ -> $82DE41
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82DE41; }
    goto L_82DE3D;
L_82DE3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE3Du,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE3Du, 8u, 3u, cpu.address("abs", 0x013Du), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DE3D DEC
    cpu.decMem(hw, cpu.address("abs", 0x13Du), cpu.m8?8:16);
    goto L_82DE40;
L_82DE40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE40u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE40u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82DE40 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82DE40u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82DE40u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82DE41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE41u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE41u, 5u, 3u, cpu.address("abs", 0x017Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DE41 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x17Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DE44;
L_82DE44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE44u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE44u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DE44 BEQ -> $82DE53
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82DE53; }
    goto L_82DE46;
L_82DE46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE46u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE46u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DE46 LDA
    cpu.setA(0xAu, 16);
    goto L_82DE49;
L_82DE49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE49u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE49u, 5u, 3u, cpu.address("abs", 0x013Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DE49 STA
    hw.write(cpu.address("abs", 0x13Du), cpu.a, cpu.m8?8:16);
    goto L_82DE4C;
L_82DE4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE4Cu,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE4Cu, 8u, 3u, cpu.address("abs", 0x017Fu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DE4C DEC
    cpu.decMem(hw, cpu.address("abs", 0x17Fu), cpu.m8?8:16);
    goto L_82DE4F;
L_82DE4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE4Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE4Fu, 6u, 3u, cpu.address("abs", 0xDE5Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82DE4F JSR -> $82DE5F stack real
    { cpu.push16Value(hw,0xDE51u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDE52u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xDE5Fu), 0x82DE4Fu); }
    goto L_82DE52;
L_82DE52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE52u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDE52u,0x82DE52u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE52u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE52u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82DE52 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82DE52u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82DE52u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82DE53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE53u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE53u, 8u, 3u, cpu.address("abs", 0x013Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DE53 INC
    cpu.incMem(hw, cpu.address("abs", 0x13Bu), cpu.m8?8:16);
    goto L_82DE56;
L_82DE56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE56u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE56u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82DE56 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82DE56u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82DE56u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8480A6_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8480A6u: goto L_8480A6;
    case 0x8480A9u: goto L_8480A9;
    case 0x8480ADu: goto L_8480AD;
    case 0x8480AFu: goto L_8480AF;
    case 0x8480B1u: goto L_8480B1;
    case 0x8480B4u: goto L_8480B4;
    case 0x8480B6u: goto L_8480B6;
    case 0x8480B8u: goto L_8480B8;
    case 0x8480BBu: goto L_8480BB;
    case 0x8480BEu: goto L_8480BE;
    case 0x8480C0u: goto L_8480C0;
    case 0x8480C3u: goto L_8480C3;
    case 0x8480C5u: goto L_8480C5;
    case 0x8480C7u: goto L_8480C7;
    case 0x8480C8u: goto L_8480C8;
    case 0x8480C9u: goto L_8480C9;
    case 0x8480CAu: goto L_8480CA;
    case 0x8480CBu: goto L_8480CB;
    case 0x8480CCu: goto L_8480CC;
    case 0x8480CFu: goto L_8480CF;
    case 0x8480D2u: goto L_8480D2;
    case 0x8480D4u: goto L_8480D4;
    case 0x8480D8u: goto L_8480D8;
    case 0x8480DAu: goto L_8480DA;
    case 0x8480DCu: goto L_8480DC;
    case 0x8480DDu: goto L_8480DD;
    case 0x8480DEu: goto L_8480DE;
    case 0x8480E0u: goto L_8480E0;
    case 0x8480E1u: goto L_8480E1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8480A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8480A6 LDY
    cpu.setY(0x0u, 16);
    goto L_8480A9;
L_8480A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A9u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A9u, 8u, 4u, 0x8096BAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8480A9 JSL -> $8096BA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80ACu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80ADu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8096BAu, 0x8480A9u); }
    goto L_8480AD;
L_8480AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80ADu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80ADu,0x8480ADu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80ADu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80ADu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x55u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8480AD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x55u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8480AF;
L_8480AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8480AF STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_8480B1;
L_8480B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B1u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8480B1 AND
    cpu.logicAnd(0x1Fu);
    goto L_8480B4;
L_8480B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B4u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8480B4 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x18u), cpu.m8?8:16));
    goto L_8480B6;
L_8480B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B6u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8480B6 BCS -> $8480A9
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_8480A9; }
    goto L_8480B8;
L_8480B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B8u, 6u, 3u, cpu.address("abs", 0x80E2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8480B8 JSR -> $8480E2 stack real
    { cpu.push16Value(hw,0x80BAu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80BBu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x80E2u), 0x8480B8u); }
    goto L_8480BB;
L_8480BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80BBu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80BBu,0x8480BBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BBu, 6u, 3u, cpu.address("abs", 0x80F2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8480BB JSR -> $8480F2 stack real
    { cpu.push16Value(hw,0x80BDu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80BEu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x80F2u), 0x8480BBu); }
    goto L_8480BE;
L_8480BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80BEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80BEu,0x8480BEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8480BE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8480C0;
L_8480C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C0u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8480C0 CMP
    cpu.compareA(0x5u);
    goto L_8480C3;
L_8480C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C3u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8480C3 BCS -> $8480A9
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_8480A9; }
    goto L_8480C5;
L_8480C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8480C5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8480C7;
L_8480C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C7u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8480C7 LSR
    cpu.lsrA();
    goto L_8480C8;
L_8480C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C8u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8480C8 LSR
    cpu.lsrA();
    goto L_8480C9;
L_8480C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C9u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8480C9 LSR
    cpu.lsrA();
    goto L_8480CA;
L_8480CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CAu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8480CA LSR
    cpu.lsrA();
    goto L_8480CB;
L_8480CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CBu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8480CB LSR
    cpu.lsrA();
    goto L_8480CC;
L_8480CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CCu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8480CC AND
    cpu.logicAnd(0xFu);
    goto L_8480CF;
L_8480CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CFu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8480CF CMP
    cpu.compareA(0xAu);
    goto L_8480D2;
L_8480D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D2u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8480D2 BCC -> $8480DC
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8480DC; }
    goto L_8480D4;
L_8480D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D4u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D4u, 8u, 4u, 0x8096BAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8480D4 JSL -> $8096BA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80D7u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80D8u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8096BAu, 0x8480D4u); }
    goto L_8480D8;
L_8480D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D8u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80D8u,0x8480D8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x55u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8480D8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x55u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8480DA;
L_8480DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80DAu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80DAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8480DA BRA -> $8480C7
    goto L_8480C7;
L_8480DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80DCu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80DCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8480DC ASL
    cpu.aslA();
    goto L_8480DD;
L_8480DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80DDu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80DDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8480DD CLC
    cpu.setFlag('C', false);
    goto L_8480DE;
L_8480DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80DEu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80DEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8480DE ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_8480E0;
L_8480E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E0u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8480E0 TAY
    cpu.transfer("TAY");
    goto L_8480E1;
L_8480E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8480E1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8480E1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8480E1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8484F0_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8484F0u: goto L_8484F0;
    case 0x8484F2u: goto L_8484F2;
    case 0x8484F5u: goto L_8484F5;
    case 0x8484F7u: goto L_8484F7;
    case 0x8484F9u: goto L_8484F9;
    case 0x8484FCu: goto L_8484FC;
    case 0x8484FEu: goto L_8484FE;
    case 0x848500u: goto L_848500;
    case 0x848501u: goto L_848501;
    case 0x848504u: goto L_848504;
    case 0x848506u: goto L_848506;
    case 0x848508u: goto L_848508;
    case 0x84850Bu: goto L_84850B;
    case 0x84850Du: goto L_84850D;
    case 0x84850Fu: goto L_84850F;
    case 0x848511u: goto L_848511;
    case 0x848514u: goto L_848514;
    case 0x848517u: goto L_848517;
    case 0x848519u: goto L_848519;
    case 0x84851Cu: goto L_84851C;
    case 0x84851Eu: goto L_84851E;
    case 0x84851Fu: goto L_84851F;
    case 0x848521u: goto L_848521;
    case 0x848525u: goto L_848525;
    case 0x848527u: goto L_848527;
    case 0x84852Au: goto L_84852A;
    case 0x84852Du: goto L_84852D;
    case 0x848530u: goto L_848530;
    case 0x848533u: goto L_848533;
    case 0x848537u: goto L_848537;
    case 0x848538u: goto L_848538;
    case 0x84853Bu: goto L_84853B;
    case 0x84853Eu: goto L_84853E;
    case 0x848540u: goto L_848540;
    case 0x848541u: goto L_848541;
    case 0x848544u: goto L_848544;
    case 0x848545u: goto L_848545;
    case 0x848548u: goto L_848548;
    case 0x84854Bu: goto L_84854B;
    case 0x84854Eu: goto L_84854E;
    case 0x848550u: goto L_848550;
    case 0x848553u: goto L_848553;
    case 0x848555u: goto L_848555;
    case 0x848558u: goto L_848558;
    case 0x84855Au: goto L_84855A;
    case 0x84855Eu: goto L_84855E;
    case 0x848561u: goto L_848561;
    case 0x848564u: goto L_848564;
    case 0x848567u: goto L_848567;
    case 0x848569u: goto L_848569;
    case 0x84856Cu: goto L_84856C;
    case 0x84856Fu: goto L_84856F;
    case 0x848571u: goto L_848571;
    case 0x848574u: goto L_848574;
    case 0x848576u: goto L_848576;
    case 0x848578u: goto L_848578;
    case 0x84857Bu: goto L_84857B;
    case 0x84857Du: goto L_84857D;
    case 0x84857Fu: goto L_84857F;
    case 0x848581u: goto L_848581;
    case 0x848584u: goto L_848584;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8484F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84F0u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84F0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484F0 SEP
    cpu.sep(0x20u);
    goto L_8484F2;
L_8484F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84F2u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84F2u, 4u, 3u, cpu.address("abs", 0x0657u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484F2 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x657u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8484F5;
L_8484F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84F5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84F5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484F5 BEQ -> $848501
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848501; }
    goto L_8484F7;
L_8484F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84F7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484F7 LDA
    cpu.setA(0x83u, 8);
    goto L_8484F9;
L_8484F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84F9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84F9u, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484F9 STA
    hw.write(cpu.address("abs", 0x2140u), cpu.a, cpu.m8?8:16);
    goto L_8484FC;
L_8484FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84FCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84FCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484FC LDA
    cpu.setA(0x81u, 8);
    goto L_8484FE;
L_8484FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84FEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84FEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484FE STA
    hw.write(cpu.address("dp", 0x46u), cpu.a, cpu.m8?8:16);
    goto L_848500;
L_848500:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8500u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8500u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8500u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848500 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848500u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848500u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_848501:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8501u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8501u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8501u, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848501 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848504;
L_848504:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8504u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8504u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8504u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848504 BIT
    cpu.bit(0x1u, true);
    goto L_848506;
L_848506:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8506u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8506u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8506u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848506 BNE -> $848569
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848569; }
    goto L_848508;
L_848508:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8508u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8508u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8508u, 4u, 3u, cpu.address("abs", 0x062Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848508 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84850B;
L_84850B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x850Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x850Bu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x850Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84850B BIT
    cpu.bit(0x1u, true);
    goto L_84850D;
L_84850D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x850Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x850Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x850Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84850D BEQ -> $848569
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848569; }
    goto L_84850F;
L_84850F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x850Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x850Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x850Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84850F LDA
    cpu.setA(0x1u, 8);
    goto L_848511;
L_848511:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8511u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8511u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8511u, 4u, 3u, cpu.address("abs", 0x062Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848511 STA
    hw.write(cpu.address("abs", 0x62Fu), cpu.a, cpu.m8?8:16);
    goto L_848514;
L_848514:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8514u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8514u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8514u, 4u, 3u, cpu.address("abs", 0x06FDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848514 STZ
    hw.write(cpu.address("abs", 0x6FDu), 0, cpu.m8?8:16);
    goto L_848517;
L_848517:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8517u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8517u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8517u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848517 STZ
    hw.write(cpu.address("dp", 0x49u), 0, cpu.m8?8:16);
    goto L_848519;
L_848519:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8519u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8519u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8519u, 4u, 3u, cpu.address("abs", 0x0657u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848519 STZ
    hw.write(cpu.address("abs", 0x657u), 0, cpu.m8?8:16);
    goto L_84851C;
L_84851C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x851Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x851Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x851Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84851C LDA
    cpu.setA(0xC1u, 8);
    goto L_84851E;
L_84851E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x851Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x851Eu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x851Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84851E XBA
    cpu.xba();
    goto L_84851F;
L_84851F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x851Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x851Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x851Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84851F LDA
    cpu.setA(0xF5u, 8);
    goto L_848521;
L_848521:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8521u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8521u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8521u, 8u, 4u, 0x808700u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848521 JSL -> $808700 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8524u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8525u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808700u, 0x848521u); }
    goto L_848525;
L_848525:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8525u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8525u,0x848525u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8525u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8525u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848525 REP
    cpu.rep(0x20u);
    goto L_848527;
L_848527:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8527u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8527u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8527u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848527 LDA
    cpu.setA(0xEE68u, 16);
    goto L_84852A;
L_84852A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x852Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x852Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x852Au, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84852A STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_84852D;
L_84852D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x852Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x852Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x852Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84852D LDA
    cpu.setA(0x8Au, 16);
    goto L_848530;
L_848530:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8530u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8530u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8530u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848530 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_848533;
L_848533:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8533u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8533u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8533u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848533 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8536u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8537u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x848533u); }
    goto L_848537;
L_848537:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8537u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8537u,0x848537u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8537u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8537u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $848537 PHB
    cpu.push("PHB", hw);
    goto L_848538;
L_848538:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8538u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8538u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8538u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848538 LDX
    cpu.setX(0x8000u, 16);
    goto L_84853B;
L_84853B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x853Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x853Bu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x853Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84853B LDY
    cpu.setY(0x2800u, 16);
    goto L_84853E;
L_84853E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x853Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x853Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x853Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84853E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848540;
L_848540:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8540u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8540u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8540u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848540 DEC
    cpu.decReg('A');
    goto L_848541;
L_848541:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8541u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8541u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0x8541u, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $848541 MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_848544;
L_848544:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8544u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8544u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8544u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $848544 PLB
    cpu.pop("PLB", hw);
    goto L_848545;
L_848545:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8545u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8545u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8545u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848545 LDX
    cpu.setX(0xCu, 16);
    goto L_848548;
L_848548:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8548u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8548u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8548u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848548 LDY
    cpu.setY(0x1Cu, 16);
    goto L_84854B;
L_84854B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x854Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x854Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x854Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84854B LDA
    cpu.setA(0x6384u, 16);
    goto L_84854E;
L_84854E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x854Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x854Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x854Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84854E STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_848550;
L_848550:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8550u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8550u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8550u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848550 LDA
    cpu.setA(0x7Eu, 16);
    goto L_848553;
L_848553:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8553u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8553u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8553u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848553 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_848555;
L_848555:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8555u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8555u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8555u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848555 LDA
    cpu.setA(0x0u, 16);
    goto L_848558;
L_848558:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8558u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8558u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8558u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848558 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_84855A;
L_84855A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x855Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x855Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x855Au, 8u, 4u, 0x80A85Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84855A JSL -> $80A85F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x855Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x855Eu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A85Fu, 0x84855Au); }
    goto L_84855E;
L_84855E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x855Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x855Eu,0x84855Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x855Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x855Eu, 6u, 3u, cpu.address("abs", 0x87A2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84855E JSR -> $8487A2 stack real
    { cpu.push16Value(hw,0x8560u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8561u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x87A2u), 0x84855Eu); }
    goto L_848561;
L_848561:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8561u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8561u,0x848561u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8561u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8561u, 6u, 3u, cpu.address("abs", 0x874Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848561 JSR -> $84874A stack real
    { cpu.push16Value(hw,0x8563u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8564u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x874Au), 0x848561u); }
    goto L_848564;
L_848564:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8564u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8564u,0x848564u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8564u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8564u, 6u, 3u, cpu.address("abs", 0x8C34u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848564 JSR -> $848C34 stack real
    { cpu.push16Value(hw,0x8566u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8567u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8C34u), 0x848564u); }
    goto L_848567;
L_848567:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8567u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8567u,0x848567u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8567u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8567u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848567 BRA -> $848584
    goto L_848584;
L_848569:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8569u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8569u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8569u, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848569 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84856C;
L_84856C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x856Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x856Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x856Cu, 6u, 3u, cpu.address("abs", 0x869Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84856C JSR -> $84869B stack real
    { cpu.push16Value(hw,0x856Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x856Fu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x869Bu), 0x84856Cu); }
    goto L_84856F;
L_84856F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x856Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x856Fu,0x84856Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x856Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x856Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84856F SEP
    cpu.sep(0x20u);
    goto L_848571;
L_848571:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8571u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8571u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8571u, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848571 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848574;
L_848574:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8574u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8574u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8574u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848574 BIT
    cpu.bit(0x1u, true);
    goto L_848576;
L_848576:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8576u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8576u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8576u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848576 BEQ -> $84857F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_84857F; }
    goto L_848578;
L_848578:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8578u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8578u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8578u, 4u, 3u, cpu.address("abs", 0x062Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848578 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84857B;
L_84857B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x857Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x857Bu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x857Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84857B BIT
    cpu.bit(0x1u, true);
    goto L_84857D;
L_84857D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x857Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x857Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x857Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84857D BNE -> $848584
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848584; }
    goto L_84857F;
L_84857F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x857Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x857Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x857Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84857F LDA
    cpu.setA(0x83u, 8);
    goto L_848581;
L_848581:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8581u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8581u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8581u, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848581 STA
    hw.write(cpu.address("abs", 0x2140u), cpu.a, cpu.m8?8:16);
    goto L_848584;
L_848584:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8584u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8584u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8584u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848584 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848584u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848584u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8584u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8584u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848584 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848584u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848584u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8584u,0x848584u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_8484F0_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8484F0u: goto L_8484F0;
    case 0x8484F2u: goto L_8484F2;
    case 0x8484F5u: goto L_8484F5;
    case 0x8484F7u: goto L_8484F7;
    case 0x8484F9u: goto L_8484F9;
    case 0x8484FCu: goto L_8484FC;
    case 0x8484FEu: goto L_8484FE;
    case 0x848500u: goto L_848500;
    case 0x848501u: goto L_848501;
    case 0x848504u: goto L_848504;
    case 0x848506u: goto L_848506;
    case 0x848508u: goto L_848508;
    case 0x84850Bu: goto L_84850B;
    case 0x84850Du: goto L_84850D;
    case 0x84850Fu: goto L_84850F;
    case 0x848511u: goto L_848511;
    case 0x848514u: goto L_848514;
    case 0x848517u: goto L_848517;
    case 0x848519u: goto L_848519;
    case 0x84851Cu: goto L_84851C;
    case 0x84851Eu: goto L_84851E;
    case 0x84851Fu: goto L_84851F;
    case 0x848521u: goto L_848521;
    case 0x848525u: goto L_848525;
    case 0x848527u: goto L_848527;
    case 0x84852Au: goto L_84852A;
    case 0x84852Du: goto L_84852D;
    case 0x848530u: goto L_848530;
    case 0x848533u: goto L_848533;
    case 0x848537u: goto L_848537;
    case 0x848538u: goto L_848538;
    case 0x84853Bu: goto L_84853B;
    case 0x84853Eu: goto L_84853E;
    case 0x848540u: goto L_848540;
    case 0x848541u: goto L_848541;
    case 0x848544u: goto L_848544;
    case 0x848545u: goto L_848545;
    case 0x848548u: goto L_848548;
    case 0x84854Bu: goto L_84854B;
    case 0x84854Eu: goto L_84854E;
    case 0x848550u: goto L_848550;
    case 0x848553u: goto L_848553;
    case 0x848555u: goto L_848555;
    case 0x848558u: goto L_848558;
    case 0x84855Au: goto L_84855A;
    case 0x84855Eu: goto L_84855E;
    case 0x848561u: goto L_848561;
    case 0x848564u: goto L_848564;
    case 0x848567u: goto L_848567;
    case 0x848569u: goto L_848569;
    case 0x84856Cu: goto L_84856C;
    case 0x84856Fu: goto L_84856F;
    case 0x848571u: goto L_848571;
    case 0x848574u: goto L_848574;
    case 0x848576u: goto L_848576;
    case 0x848578u: goto L_848578;
    case 0x84857Bu: goto L_84857B;
    case 0x84857Du: goto L_84857D;
    case 0x84857Fu: goto L_84857F;
    case 0x848581u: goto L_848581;
    case 0x848584u: goto L_848584;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8484F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84F0u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84F0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484F0 SEP
    cpu.sep(0x20u);
    goto L_8484F2;
L_8484F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84F2u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84F2u, 4u, 3u, cpu.address("abs", 0x0657u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484F2 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x657u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8484F5;
L_8484F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84F5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84F5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484F5 BEQ -> $848501
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848501; }
    goto L_8484F7;
L_8484F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84F7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484F7 LDA
    cpu.setA(0x83u, 8);
    goto L_8484F9;
L_8484F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84F9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84F9u, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484F9 STA
    hw.write(cpu.address("abs", 0x2140u), cpu.a, cpu.m8?8:16);
    goto L_8484FC;
L_8484FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84FCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84FCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484FC LDA
    cpu.setA(0x81u, 8);
    goto L_8484FE;
L_8484FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84FEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84FEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484FE STA
    hw.write(cpu.address("dp", 0x46u), cpu.a, cpu.m8?8:16);
    goto L_848500;
L_848500:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8500u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8500u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8500u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848500 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848500u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848500u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_848501:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8501u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8501u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8501u, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848501 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848504;
L_848504:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8504u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8504u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8504u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848504 BIT
    cpu.bit(0x1u, true);
    goto L_848506;
L_848506:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8506u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8506u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8506u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848506 BNE -> $848569
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848569; }
    goto L_848508;
L_848508:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8508u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8508u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8508u, 4u, 3u, cpu.address("abs", 0x062Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848508 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84850B;
L_84850B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x850Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x850Bu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x850Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84850B BIT
    cpu.bit(0x1u, true);
    goto L_84850D;
L_84850D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x850Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x850Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x850Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84850D BEQ -> $848569
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848569; }
    goto L_84850F;
L_84850F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x850Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x850Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x850Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84850F LDA
    cpu.setA(0x1u, 8);
    goto L_848511;
L_848511:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8511u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8511u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8511u, 4u, 3u, cpu.address("abs", 0x062Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848511 STA
    hw.write(cpu.address("abs", 0x62Fu), cpu.a, cpu.m8?8:16);
    goto L_848514;
L_848514:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8514u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8514u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8514u, 4u, 3u, cpu.address("abs", 0x06FDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848514 STZ
    hw.write(cpu.address("abs", 0x6FDu), 0, cpu.m8?8:16);
    goto L_848517;
L_848517:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8517u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8517u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8517u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848517 STZ
    hw.write(cpu.address("dp", 0x49u), 0, cpu.m8?8:16);
    goto L_848519;
L_848519:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8519u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8519u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8519u, 4u, 3u, cpu.address("abs", 0x0657u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848519 STZ
    hw.write(cpu.address("abs", 0x657u), 0, cpu.m8?8:16);
    goto L_84851C;
L_84851C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x851Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x851Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x851Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84851C LDA
    cpu.setA(0xC1u, 8);
    goto L_84851E;
L_84851E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x851Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x851Eu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x851Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84851E XBA
    cpu.xba();
    goto L_84851F;
L_84851F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x851Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x851Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x851Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84851F LDA
    cpu.setA(0xF5u, 8);
    goto L_848521;
L_848521:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8521u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8521u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8521u, 8u, 4u, 0x808700u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848521 JSL -> $808700 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8524u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8525u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808700u, 0x848521u); }
    goto L_848525;
L_848525:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8525u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8525u,0x848525u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8525u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8525u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848525 REP
    cpu.rep(0x20u);
    goto L_848527;
L_848527:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8527u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8527u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8527u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848527 LDA
    cpu.setA(0xEE68u, 16);
    goto L_84852A;
L_84852A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x852Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x852Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x852Au, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84852A STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_84852D;
L_84852D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x852Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x852Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x852Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84852D LDA
    cpu.setA(0x8Au, 16);
    goto L_848530;
L_848530:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8530u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8530u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8530u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848530 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_848533;
L_848533:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8533u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8533u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8533u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848533 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8536u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8537u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x848533u); }
    goto L_848537;
L_848537:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8537u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8537u,0x848537u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8537u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8537u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $848537 PHB
    cpu.push("PHB", hw);
    goto L_848538;
L_848538:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8538u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8538u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8538u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848538 LDX
    cpu.setX(0x8000u, 16);
    goto L_84853B;
L_84853B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x853Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x853Bu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x853Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84853B LDY
    cpu.setY(0x2800u, 16);
    goto L_84853E;
L_84853E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x853Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x853Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x853Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84853E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848540;
L_848540:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8540u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8540u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8540u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848540 DEC
    cpu.decReg('A');
    goto L_848541;
L_848541:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8541u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8541u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0x8541u, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $848541 MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_848544;
L_848544:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8544u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8544u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8544u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $848544 PLB
    cpu.pop("PLB", hw);
    goto L_848545;
L_848545:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8545u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8545u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8545u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848545 LDX
    cpu.setX(0xCu, 16);
    goto L_848548;
L_848548:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8548u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8548u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8548u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848548 LDY
    cpu.setY(0x1Cu, 16);
    goto L_84854B;
L_84854B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x854Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x854Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x854Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84854B LDA
    cpu.setA(0x6384u, 16);
    goto L_84854E;
L_84854E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x854Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x854Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x854Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84854E STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_848550;
L_848550:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8550u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8550u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8550u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848550 LDA
    cpu.setA(0x7Eu, 16);
    goto L_848553;
L_848553:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8553u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8553u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8553u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848553 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_848555;
L_848555:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8555u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8555u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8555u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848555 LDA
    cpu.setA(0x0u, 16);
    goto L_848558;
L_848558:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8558u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8558u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8558u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848558 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_84855A;
L_84855A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x855Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x855Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x855Au, 8u, 4u, 0x80A85Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84855A JSL -> $80A85F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x855Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x855Eu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A85Fu, 0x84855Au); }
    goto L_84855E;
L_84855E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x855Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x855Eu,0x84855Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x855Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x855Eu, 6u, 3u, cpu.address("abs", 0x87A2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84855E JSR -> $8487A2 stack real
    { cpu.push16Value(hw,0x8560u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8561u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x87A2u), 0x84855Eu); }
    goto L_848561;
L_848561:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8561u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8561u,0x848561u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8561u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8561u, 6u, 3u, cpu.address("abs", 0x874Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848561 JSR -> $84874A stack real
    { cpu.push16Value(hw,0x8563u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8564u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x874Au), 0x848561u); }
    goto L_848564;
L_848564:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8564u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8564u,0x848564u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8564u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8564u, 6u, 3u, cpu.address("abs", 0x8C34u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848564 JSR -> $848C34 stack real
    { cpu.push16Value(hw,0x8566u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8567u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8C34u), 0x848564u); }
    goto L_848567;
L_848567:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8567u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8567u,0x848567u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8567u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8567u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848567 BRA -> $848584
    goto L_848584;
L_848569:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8569u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8569u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8569u, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848569 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84856C;
L_84856C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x856Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x856Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x856Cu, 6u, 3u, cpu.address("abs", 0x869Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84856C JSR -> $84869B stack real
    { cpu.push16Value(hw,0x856Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x856Fu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x869Bu), 0x84856Cu); }
    goto L_84856F;
L_84856F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x856Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x856Fu,0x84856Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x856Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x856Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84856F SEP
    cpu.sep(0x20u);
    goto L_848571;
L_848571:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8571u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8571u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8571u, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848571 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848574;
L_848574:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8574u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8574u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8574u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848574 BIT
    cpu.bit(0x1u, true);
    goto L_848576;
L_848576:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8576u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8576u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8576u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848576 BEQ -> $84857F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_84857F; }
    goto L_848578;
L_848578:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8578u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8578u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8578u, 4u, 3u, cpu.address("abs", 0x062Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848578 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84857B;
L_84857B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x857Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x857Bu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x857Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84857B BIT
    cpu.bit(0x1u, true);
    goto L_84857D;
L_84857D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x857Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x857Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x857Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84857D BNE -> $848584
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848584; }
    goto L_84857F;
L_84857F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x857Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x857Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x857Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84857F LDA
    cpu.setA(0x83u, 8);
    goto L_848581;
L_848581:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8581u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8581u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8581u, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848581 STA
    hw.write(cpu.address("abs", 0x2140u), cpu.a, cpu.m8?8:16);
    goto L_848584;
L_848584:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8584u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8584u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8584u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848584 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848584u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848584u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8584u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8584u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848584 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848584u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848584u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8584u,0x848584u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_848EC7_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848EC7u: goto L_848EC7;
    case 0x848EC9u: goto L_848EC9;
    case 0x848ECBu: goto L_848ECB;
    case 0x848ECDu: goto L_848ECD;
    case 0x848ED0u: goto L_848ED0;
    case 0x848ED1u: goto L_848ED1;
    case 0x848ED2u: goto L_848ED2;
    case 0x848ED5u: goto L_848ED5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848EC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC7u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848EC7 SEP
    cpu.sep(0x20u);
    goto L_848EC9;
L_848EC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848EC9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x49u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848ECB;
L_848ECB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ECBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECBu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848ECB REP
    cpu.rep(0x20u);
    goto L_848ECD;
L_848ECD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ECDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECDu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848ECD AND
    cpu.logicAnd(0xFFu);
    goto L_848ED0;
L_848ED0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848ED0 ASL
    cpu.aslA();
    goto L_848ED1;
L_848ED1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED1u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848ED1 TAX
    cpu.transfer("TAX");
    goto L_848ED2;
L_848ED2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED2u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED2u, 5u, 3u, cpu.address("abs", 0x8ED7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848ED2 PEA
    cpu.push16Value(hw, 0x8ED7u);
    goto L_848ED5;
L_848ED5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED5u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED5u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x8EFDu + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $848ED5 JMP (8EFD,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x8EFDu+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x848ED5u); return; }
}

void sub_848EC7_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848EC7u: goto L_848EC7;
    case 0x848EC9u: goto L_848EC9;
    case 0x848ECBu: goto L_848ECB;
    case 0x848ECDu: goto L_848ECD;
    case 0x848ED0u: goto L_848ED0;
    case 0x848ED1u: goto L_848ED1;
    case 0x848ED2u: goto L_848ED2;
    case 0x848ED5u: goto L_848ED5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848EC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC7u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848EC7 SEP
    cpu.sep(0x20u);
    goto L_848EC9;
L_848EC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EC9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848EC9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x49u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848ECB;
L_848ECB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ECBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECBu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848ECB REP
    cpu.rep(0x20u);
    goto L_848ECD;
L_848ECD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ECDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECDu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848ECD AND
    cpu.logicAnd(0xFFu);
    goto L_848ED0;
L_848ED0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848ED0 ASL
    cpu.aslA();
    goto L_848ED1;
L_848ED1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED1u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848ED1 TAX
    cpu.transfer("TAX");
    goto L_848ED2;
L_848ED2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED2u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED2u, 5u, 3u, cpu.address("abs", 0x8ED7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848ED2 PEA
    cpu.push16Value(hw, 0x8ED7u);
    goto L_848ED5;
L_848ED5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED5u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED5u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x8EFDu + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $848ED5 JMP (8EFD,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x8EFDu+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x848ED5u); return; }
}

void sub_849DA7_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849DA7u: goto L_849DA7;
    case 0x849DA8u: goto L_849DA8;
    case 0x849DABu: goto L_849DAB;
    case 0x849DADu: goto L_849DAD;
    case 0x849DB0u: goto L_849DB0;
    case 0x849DB3u: goto L_849DB3;
    case 0x849DB6u: goto L_849DB6;
    case 0x849DB8u: goto L_849DB8;
    case 0x849DBBu: goto L_849DBB;
    case 0x849DBEu: goto L_849DBE;
    case 0x849DC1u: goto L_849DC1;
    case 0x849DC4u: goto L_849DC4;
    case 0x849DC7u: goto L_849DC7;
    case 0x849DC8u: goto L_849DC8;
    case 0x849DC9u: goto L_849DC9;
    case 0x849DCDu: goto L_849DCD;
    case 0x849DCEu: goto L_849DCE;
    case 0x849DD1u: goto L_849DD1;
    case 0x849DD4u: goto L_849DD4;
    case 0x849DD7u: goto L_849DD7;
    case 0x849DDAu: goto L_849DDA;
    case 0x849DDBu: goto L_849DDB;
    case 0x849DDCu: goto L_849DDC;
    case 0x849DDDu: goto L_849DDD;
    case 0x849DE0u: goto L_849DE0;
    case 0x849DE1u: goto L_849DE1;
    case 0x849DE4u: goto L_849DE4;
    case 0x849DE7u: goto L_849DE7;
    case 0x849DEAu: goto L_849DEA;
    case 0x849DEDu: goto L_849DED;
    case 0x849DF0u: goto L_849DF0;
    case 0x849DF2u: goto L_849DF2;
    case 0x849DF5u: goto L_849DF5;
    case 0x849DF8u: goto L_849DF8;
    case 0x849DFBu: goto L_849DFB;
    case 0x849DFEu: goto L_849DFE;
    case 0x849E01u: goto L_849E01;
    case 0x849E02u: goto L_849E02;
    case 0x849E03u: goto L_849E03;
    case 0x849E07u: goto L_849E07;
    case 0x849E08u: goto L_849E08;
    case 0x849E0Bu: goto L_849E0B;
    case 0x849E0Eu: goto L_849E0E;
    case 0x849E11u: goto L_849E11;
    case 0x849E14u: goto L_849E14;
    case 0x849E15u: goto L_849E15;
    case 0x849E16u: goto L_849E16;
    case 0x849E17u: goto L_849E17;
    case 0x849E1Au: goto L_849E1A;
    case 0x849E1Bu: goto L_849E1B;
    case 0x849E1Eu: goto L_849E1E;
    case 0x849E21u: goto L_849E21;
    case 0x849E23u: goto L_849E23;
    case 0x849E26u: goto L_849E26;
    case 0x849E29u: goto L_849E29;
    case 0x849E2Au: goto L_849E2A;
    case 0x849E2Bu: goto L_849E2B;
    case 0x849E2Fu: goto L_849E2F;
    case 0x849E30u: goto L_849E30;
    case 0x849E33u: goto L_849E33;
    case 0x849E36u: goto L_849E36;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849DA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DA7u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DA7u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $849DA7 PLB
    cpu.pop("PLB", hw);
    goto L_849DA8;
L_849DA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DA8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DA8u, 6u, 3u, cpu.address("absx", 0x9E37u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DA8 STA
    hw.write(cpu.address("absx", 0x9E37u), cpu.a, cpu.m8?8:16);
    goto L_849DAB;
L_849DAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DABu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DABu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DAB REP
    cpu.rep(0x20u);
    goto L_849DAD;
L_849DAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DADu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DADu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DAD LDY
    cpu.setY(0x8u, 16);
    goto L_849DB0;
L_849DB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB0u, 5u + 1u, 3u, cpu.address("absy", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DB0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x63Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849DB3;
L_849DB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB3u, 6u, 3u, cpu.address("abs", 0x9F4Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849DB3 JSR -> $849F4E stack real
    { cpu.push16Value(hw,0x9DB5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9DB6u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F4Eu), 0x849DB3u); }
    goto L_849DB6;
L_849DB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DB6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9DB6u,0x849DB6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB6u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DB6 REP
    cpu.rep(0x20u);
    goto L_849DB8;
L_849DB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB8u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DB8 LDX
    cpu.setX(0x0u, 16);
    goto L_849DBB;
L_849DBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DBBu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DBBu, 5u + 1u, 3u, cpu.address("absy", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DBB LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x63Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849DBE;
L_849DBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DBEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DBEu, 6u, 3u, cpu.address("abs", 0x9F86u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849DBE JSR -> $849F86 stack real
    { cpu.push16Value(hw,0x9DC0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9DC1u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F86u), 0x849DBEu); }
    goto L_849DC1;
L_849DC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DC1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9DC1u,0x849DC1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC1u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DC1 LDY
    cpu.setY(0x8u, 16);
    goto L_849DC4;
L_849DC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC4u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC4u, 5u + 1u, 3u, cpu.address("absy", 0x0633u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DC4 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x633u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849DC7;
L_849DC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DC7 ASL
    cpu.aslA();
    goto L_849DC8;
L_849DC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC8u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DC8 TAX
    cpu.transfer("TAX");
    goto L_849DC9;
L_849DC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC9u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC9u, 6u, 4u, ((0x849FBEu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DC9 LDA
    cpu.loadA(hw.readW(((0x849FBEu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849DCD;
L_849DCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DCDu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DCDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DCD TAY
    cpu.transfer("TAY");
    goto L_849DCE;
L_849DCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DCEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DCEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DCE LDA
    cpu.setA(0x0u, 16);
    goto L_849DD1;
L_849DD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD1u, 6u, 3u, cpu.address("abs", 0x9EF1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849DD1 JSR -> $849EF1 stack real
    { cpu.push16Value(hw,0x9DD3u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9DD4u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9EF1u), 0x849DD1u); }
    goto L_849DD4;
L_849DD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DD4u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9DD4u,0x849DD4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD4u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DD4 LDY
    cpu.setY(0x8u, 16);
    goto L_849DD7;
L_849DD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD7u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD7u, 5u + 1u, 3u, cpu.address("absy", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DD7 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x63Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849DDA;
L_849DDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDAu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DDA ASL
    cpu.aslA();
    goto L_849DDB;
L_849DDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DDB ASL
    cpu.aslA();
    goto L_849DDC;
L_849DDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDCu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DDC ASL
    cpu.aslA();
    goto L_849DDD;
L_849DDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDDu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DDD ADC
    cpu.adc(0x68u);
    goto L_849DE0;
L_849DE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE0u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DE0 TAY
    cpu.transfer("TAY");
    goto L_849DE1;
L_849DE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DE1 LDA
    cpu.setA(0x3u, 16);
    goto L_849DE4;
L_849DE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE4u, 6u, 3u, cpu.address("abs", 0x9EF1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849DE4 JSR -> $849EF1 stack real
    { cpu.push16Value(hw,0x9DE6u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9DE7u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9EF1u), 0x849DE4u); }
    goto L_849DE7;
L_849DE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DE7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9DE7u,0x849DE7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE7u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DE7 LDY
    cpu.setY(0x4u, 16);
    goto L_849DEA;
L_849DEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DEAu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DEAu, 5u + 1u, 3u, cpu.address("absy", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DEA LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x63Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849DED;
L_849DED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DEDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DEDu, 6u, 3u, cpu.address("abs", 0x9F4Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849DED JSR -> $849F4E stack real
    { cpu.push16Value(hw,0x9DEFu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9DF0u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F4Eu), 0x849DEDu); }
    goto L_849DF0;
L_849DF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DF0u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9DF0u,0x849DF0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF0u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DF0 REP
    cpu.rep(0x20u);
    goto L_849DF2;
L_849DF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF2u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF2u, 5u + 1u, 3u, cpu.address("absy", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DF2 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x63Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849DF5;
L_849DF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF5u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DF5 LDX
    cpu.setX(0x2u, 16);
    goto L_849DF8;
L_849DF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF8u, 6u, 3u, cpu.address("abs", 0x9F86u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849DF8 JSR -> $849F86 stack real
    { cpu.push16Value(hw,0x9DFAu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9DFBu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F86u), 0x849DF8u); }
    goto L_849DFB;
L_849DFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DFBu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9DFBu,0x849DFBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DFBu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DFBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DFB LDY
    cpu.setY(0x4u, 16);
    goto L_849DFE;
L_849DFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DFEu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DFEu, 5u + 1u, 3u, cpu.address("absy", 0x0633u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DFE LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x633u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849E01;
L_849E01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E01u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E01u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E01 ASL
    cpu.aslA();
    goto L_849E02;
L_849E02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E02u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E02u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E02 TAX
    cpu.transfer("TAX");
    goto L_849E03;
L_849E03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E03u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E03u, 6u, 4u, ((0x849FBEu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E03 LDA
    cpu.loadA(hw.readW(((0x849FBEu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849E07;
L_849E07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E07u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E07u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E07 TAY
    cpu.transfer("TAY");
    goto L_849E08;
L_849E08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E08u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E08u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E08 LDA
    cpu.setA(0x1u, 16);
    goto L_849E0B;
L_849E0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E0Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E0Bu, 6u, 3u, cpu.address("abs", 0x9EF1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849E0B JSR -> $849EF1 stack real
    { cpu.push16Value(hw,0x9E0Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9E0Eu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9EF1u), 0x849E0Bu); }
    goto L_849E0E;
L_849E0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E0Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E0Eu,0x849E0Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E0Eu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E0Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E0E LDY
    cpu.setY(0x4u, 16);
    goto L_849E11;
L_849E11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E11u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E11u, 5u + 1u, 3u, cpu.address("absy", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E11 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x63Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849E14;
L_849E14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E14u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E14u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E14 ASL
    cpu.aslA();
    goto L_849E15;
L_849E15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E15u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E15u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E15 ASL
    cpu.aslA();
    goto L_849E16;
L_849E16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E16u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E16u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E16 ASL
    cpu.aslA();
    goto L_849E17;
L_849E17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E17u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E17u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E17 ADC
    cpu.adc(0x68u);
    goto L_849E1A;
L_849E1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Au,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E1A TAY
    cpu.transfer("TAY");
    goto L_849E1B;
L_849E1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E1B LDA
    cpu.setA(0x4u, 16);
    goto L_849E1E;
L_849E1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Eu, 6u, 3u, cpu.address("abs", 0x9EF1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849E1E JSR -> $849EF1 stack real
    { cpu.push16Value(hw,0x9E20u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9E21u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9EF1u), 0x849E1Eu); }
    goto L_849E21;
L_849E21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E21u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E21u,0x849E21u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E21u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E21u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E21 REP
    cpu.rep(0x20u);
    goto L_849E23;
L_849E23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E23u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E23u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E23 LDY
    cpu.setY(0x4u, 16);
    goto L_849E26;
L_849E26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E26u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E26u, 5u + 1u, 3u, cpu.address("absy", 0x064Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E26 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x64Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849E29;
L_849E29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E29u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E29u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E29 ASL
    cpu.aslA();
    goto L_849E2A;
L_849E2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Au,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E2A TAX
    cpu.transfer("TAX");
    goto L_849E2B;
L_849E2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Bu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Bu, 6u, 4u, ((0x849FC8u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E2B LDA
    cpu.loadA(hw.readW(((0x849FC8u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849E2F;
L_849E2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Fu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E2F TAY
    cpu.transfer("TAY");
    goto L_849E30;
L_849E30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E30u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E30u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E30 LDA
    cpu.setA(0x6u, 16);
    goto L_849E33;
L_849E33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E33u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E33u, 6u, 3u, cpu.address("abs", 0x9EF1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849E33 JSR -> $849EF1 stack real
    { cpu.push16Value(hw,0x9E35u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9E36u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9EF1u), 0x849E33u); }
    goto L_849E36;
L_849E36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E36u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E36u,0x849E36u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E36u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E36u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849E36 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849E36u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849E36u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_849DA7_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849DA7u: goto L_849DA7;
    case 0x849DA8u: goto L_849DA8;
    case 0x849DABu: goto L_849DAB;
    case 0x849DADu: goto L_849DAD;
    case 0x849DB0u: goto L_849DB0;
    case 0x849DB3u: goto L_849DB3;
    case 0x849DB6u: goto L_849DB6;
    case 0x849DB8u: goto L_849DB8;
    case 0x849DBBu: goto L_849DBB;
    case 0x849DBEu: goto L_849DBE;
    case 0x849DC1u: goto L_849DC1;
    case 0x849DC4u: goto L_849DC4;
    case 0x849DC7u: goto L_849DC7;
    case 0x849DC8u: goto L_849DC8;
    case 0x849DC9u: goto L_849DC9;
    case 0x849DCDu: goto L_849DCD;
    case 0x849DCEu: goto L_849DCE;
    case 0x849DD1u: goto L_849DD1;
    case 0x849DD4u: goto L_849DD4;
    case 0x849DD7u: goto L_849DD7;
    case 0x849DDAu: goto L_849DDA;
    case 0x849DDBu: goto L_849DDB;
    case 0x849DDCu: goto L_849DDC;
    case 0x849DDDu: goto L_849DDD;
    case 0x849DE0u: goto L_849DE0;
    case 0x849DE1u: goto L_849DE1;
    case 0x849DE4u: goto L_849DE4;
    case 0x849DE7u: goto L_849DE7;
    case 0x849DEAu: goto L_849DEA;
    case 0x849DEDu: goto L_849DED;
    case 0x849DF0u: goto L_849DF0;
    case 0x849DF2u: goto L_849DF2;
    case 0x849DF5u: goto L_849DF5;
    case 0x849DF8u: goto L_849DF8;
    case 0x849DFBu: goto L_849DFB;
    case 0x849DFEu: goto L_849DFE;
    case 0x849E01u: goto L_849E01;
    case 0x849E02u: goto L_849E02;
    case 0x849E03u: goto L_849E03;
    case 0x849E07u: goto L_849E07;
    case 0x849E08u: goto L_849E08;
    case 0x849E0Bu: goto L_849E0B;
    case 0x849E0Eu: goto L_849E0E;
    case 0x849E11u: goto L_849E11;
    case 0x849E14u: goto L_849E14;
    case 0x849E15u: goto L_849E15;
    case 0x849E16u: goto L_849E16;
    case 0x849E17u: goto L_849E17;
    case 0x849E1Au: goto L_849E1A;
    case 0x849E1Bu: goto L_849E1B;
    case 0x849E1Eu: goto L_849E1E;
    case 0x849E21u: goto L_849E21;
    case 0x849E23u: goto L_849E23;
    case 0x849E26u: goto L_849E26;
    case 0x849E29u: goto L_849E29;
    case 0x849E2Au: goto L_849E2A;
    case 0x849E2Bu: goto L_849E2B;
    case 0x849E2Fu: goto L_849E2F;
    case 0x849E30u: goto L_849E30;
    case 0x849E33u: goto L_849E33;
    case 0x849E36u: goto L_849E36;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849DA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DA7u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DA7u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $849DA7 PLB
    cpu.pop("PLB", hw);
    goto L_849DA8;
L_849DA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DA8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DA8u, 6u, 3u, cpu.address("absx", 0x9E37u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DA8 STA
    hw.write(cpu.address("absx", 0x9E37u), cpu.a, cpu.m8?8:16);
    goto L_849DAB;
L_849DAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DABu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DABu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DAB REP
    cpu.rep(0x20u);
    goto L_849DAD;
L_849DAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DADu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DADu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DAD LDY
    cpu.setY(0x8u, 16);
    goto L_849DB0;
L_849DB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB0u, 5u + 1u, 3u, cpu.address("absy", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DB0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x63Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849DB3;
L_849DB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB3u, 6u, 3u, cpu.address("abs", 0x9F4Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849DB3 JSR -> $849F4E stack real
    { cpu.push16Value(hw,0x9DB5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9DB6u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F4Eu), 0x849DB3u); }
    goto L_849DB6;
L_849DB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DB6u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9DB6u,0x849DB6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB6u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DB6 REP
    cpu.rep(0x20u);
    goto L_849DB8;
L_849DB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB8u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DB8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DB8 LDX
    cpu.setX(0x0u, 16);
    goto L_849DBB;
L_849DBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DBBu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DBBu, 5u + 1u, 3u, cpu.address("absy", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DBB LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x63Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849DBE;
L_849DBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DBEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DBEu, 6u, 3u, cpu.address("abs", 0x9F86u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849DBE JSR -> $849F86 stack real
    { cpu.push16Value(hw,0x9DC0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9DC1u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F86u), 0x849DBEu); }
    goto L_849DC1;
L_849DC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DC1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9DC1u,0x849DC1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC1u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DC1 LDY
    cpu.setY(0x8u, 16);
    goto L_849DC4;
L_849DC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC4u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC4u, 5u + 1u, 3u, cpu.address("absy", 0x0633u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DC4 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x633u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849DC7;
L_849DC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DC7 ASL
    cpu.aslA();
    goto L_849DC8;
L_849DC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC8u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DC8 TAX
    cpu.transfer("TAX");
    goto L_849DC9;
L_849DC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC9u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DC9u, 6u, 4u, ((0x849FBEu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DC9 LDA
    cpu.loadA(hw.readW(((0x849FBEu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849DCD;
L_849DCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DCDu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DCDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DCD TAY
    cpu.transfer("TAY");
    goto L_849DCE;
L_849DCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DCEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DCEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DCE LDA
    cpu.setA(0x0u, 16);
    goto L_849DD1;
L_849DD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD1u, 6u, 3u, cpu.address("abs", 0x9EF1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849DD1 JSR -> $849EF1 stack real
    { cpu.push16Value(hw,0x9DD3u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9DD4u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9EF1u), 0x849DD1u); }
    goto L_849DD4;
L_849DD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DD4u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9DD4u,0x849DD4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD4u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DD4 LDY
    cpu.setY(0x8u, 16);
    goto L_849DD7;
L_849DD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD7u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DD7u, 5u + 1u, 3u, cpu.address("absy", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DD7 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x63Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849DDA;
L_849DDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDAu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DDA ASL
    cpu.aslA();
    goto L_849DDB;
L_849DDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DDB ASL
    cpu.aslA();
    goto L_849DDC;
L_849DDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDCu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DDC ASL
    cpu.aslA();
    goto L_849DDD;
L_849DDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDDu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DDDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DDD ADC
    cpu.adc(0x68u);
    goto L_849DE0;
L_849DE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE0u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DE0 TAY
    cpu.transfer("TAY");
    goto L_849DE1;
L_849DE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DE1 LDA
    cpu.setA(0x3u, 16);
    goto L_849DE4;
L_849DE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE4u, 6u, 3u, cpu.address("abs", 0x9EF1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849DE4 JSR -> $849EF1 stack real
    { cpu.push16Value(hw,0x9DE6u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9DE7u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9EF1u), 0x849DE4u); }
    goto L_849DE7;
L_849DE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DE7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9DE7u,0x849DE7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE7u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DE7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DE7 LDY
    cpu.setY(0x4u, 16);
    goto L_849DEA;
L_849DEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DEAu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DEAu, 5u + 1u, 3u, cpu.address("absy", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DEA LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x63Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849DED;
L_849DED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DEDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DEDu, 6u, 3u, cpu.address("abs", 0x9F4Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849DED JSR -> $849F4E stack real
    { cpu.push16Value(hw,0x9DEFu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9DF0u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F4Eu), 0x849DEDu); }
    goto L_849DF0;
L_849DF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DF0u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9DF0u,0x849DF0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF0u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DF0 REP
    cpu.rep(0x20u);
    goto L_849DF2;
L_849DF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF2u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF2u, 5u + 1u, 3u, cpu.address("absy", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DF2 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x63Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849DF5;
L_849DF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF5u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DF5 LDX
    cpu.setX(0x2u, 16);
    goto L_849DF8;
L_849DF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DF8u, 6u, 3u, cpu.address("abs", 0x9F86u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849DF8 JSR -> $849F86 stack real
    { cpu.push16Value(hw,0x9DFAu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9DFBu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F86u), 0x849DF8u); }
    goto L_849DFB;
L_849DFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DFBu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9DFBu,0x849DFBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DFBu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DFBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DFB LDY
    cpu.setY(0x4u, 16);
    goto L_849DFE;
L_849DFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DFEu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DFEu, 5u + 1u, 3u, cpu.address("absy", 0x0633u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849DFE LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x633u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849E01;
L_849E01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E01u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E01u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E01 ASL
    cpu.aslA();
    goto L_849E02;
L_849E02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E02u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E02u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E02 TAX
    cpu.transfer("TAX");
    goto L_849E03;
L_849E03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E03u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E03u, 6u, 4u, ((0x849FBEu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E03 LDA
    cpu.loadA(hw.readW(((0x849FBEu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849E07;
L_849E07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E07u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E07u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E07 TAY
    cpu.transfer("TAY");
    goto L_849E08;
L_849E08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E08u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E08u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E08 LDA
    cpu.setA(0x1u, 16);
    goto L_849E0B;
L_849E0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E0Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E0Bu, 6u, 3u, cpu.address("abs", 0x9EF1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849E0B JSR -> $849EF1 stack real
    { cpu.push16Value(hw,0x9E0Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9E0Eu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9EF1u), 0x849E0Bu); }
    goto L_849E0E;
L_849E0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E0Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E0Eu,0x849E0Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E0Eu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E0Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E0E LDY
    cpu.setY(0x4u, 16);
    goto L_849E11;
L_849E11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E11u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E11u, 5u + 1u, 3u, cpu.address("absy", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E11 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x63Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849E14;
L_849E14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E14u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E14u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E14 ASL
    cpu.aslA();
    goto L_849E15;
L_849E15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E15u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E15u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E15 ASL
    cpu.aslA();
    goto L_849E16;
L_849E16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E16u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E16u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E16 ASL
    cpu.aslA();
    goto L_849E17;
L_849E17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E17u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E17u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E17 ADC
    cpu.adc(0x68u);
    goto L_849E1A;
L_849E1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Au,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E1A TAY
    cpu.transfer("TAY");
    goto L_849E1B;
L_849E1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E1B LDA
    cpu.setA(0x4u, 16);
    goto L_849E1E;
L_849E1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Eu, 6u, 3u, cpu.address("abs", 0x9EF1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849E1E JSR -> $849EF1 stack real
    { cpu.push16Value(hw,0x9E20u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9E21u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9EF1u), 0x849E1Eu); }
    goto L_849E21;
L_849E21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E21u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E21u,0x849E21u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E21u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E21u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E21 REP
    cpu.rep(0x20u);
    goto L_849E23;
L_849E23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E23u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E23u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E23 LDY
    cpu.setY(0x4u, 16);
    goto L_849E26;
L_849E26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E26u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E26u, 5u + 1u, 3u, cpu.address("absy", 0x064Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E26 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x64Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849E29;
L_849E29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E29u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E29u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E29 ASL
    cpu.aslA();
    goto L_849E2A;
L_849E2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Au,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E2A TAX
    cpu.transfer("TAX");
    goto L_849E2B;
L_849E2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Bu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Bu, 6u, 4u, ((0x849FC8u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E2B LDA
    cpu.loadA(hw.readW(((0x849FC8u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849E2F;
L_849E2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Fu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E2F TAY
    cpu.transfer("TAY");
    goto L_849E30;
L_849E30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E30u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E30u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849E30 LDA
    cpu.setA(0x6u, 16);
    goto L_849E33;
L_849E33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E33u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E33u, 6u, 3u, cpu.address("abs", 0x9EF1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849E33 JSR -> $849EF1 stack real
    { cpu.push16Value(hw,0x9E35u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9E36u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9EF1u), 0x849E33u); }
    goto L_849E36;
L_849E36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E36u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E36u,0x849E36u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E36u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E36u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849E36 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849E36u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849E36u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84B4F8_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84B4F8u: goto L_84B4F8;
    case 0x84B4FAu: goto L_84B4FA;
    case 0x84B4FCu: goto L_84B4FC;
    case 0x84B4FEu: goto L_84B4FE;
    case 0x84B501u: goto L_84B501;
    case 0x84B502u: goto L_84B502;
    case 0x84B503u: goto L_84B503;
    case 0x84B506u: goto L_84B506;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84B4F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F8u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4F8 SEP
    cpu.sep(0x20u);
    goto L_84B4FA;
L_84B4FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4FA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x49u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B4FC;
L_84B4FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FCu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4FC REP
    cpu.rep(0x20u);
    goto L_84B4FE;
L_84B4FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4FE AND
    cpu.logicAnd(0xFFu);
    goto L_84B501;
L_84B501:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB501u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB501u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB501u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B501 ASL
    cpu.aslA();
    goto L_84B502;
L_84B502:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB502u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB502u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB502u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B502 TAX
    cpu.transfer("TAX");
    goto L_84B503;
L_84B503:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB503u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB503u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB503u, 5u, 3u, cpu.address("abs", 0xB508u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B503 PEA
    cpu.push16Value(hw, 0xB508u);
    goto L_84B506;
L_84B506:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB506u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB506u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB506u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xB513u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $84B506 JMP (B513,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xB513u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x84B506u); return; }
}

void sub_84B4F8_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84B4F8u: goto L_84B4F8;
    case 0x84B4FAu: goto L_84B4FA;
    case 0x84B4FCu: goto L_84B4FC;
    case 0x84B4FEu: goto L_84B4FE;
    case 0x84B501u: goto L_84B501;
    case 0x84B502u: goto L_84B502;
    case 0x84B503u: goto L_84B503;
    case 0x84B506u: goto L_84B506;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84B4F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F8u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4F8 SEP
    cpu.sep(0x20u);
    goto L_84B4FA;
L_84B4FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4FA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x49u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B4FC;
L_84B4FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FCu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4FC REP
    cpu.rep(0x20u);
    goto L_84B4FE;
L_84B4FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B4FE AND
    cpu.logicAnd(0xFFu);
    goto L_84B501;
L_84B501:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB501u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB501u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB501u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B501 ASL
    cpu.aslA();
    goto L_84B502;
L_84B502:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB502u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB502u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB502u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B502 TAX
    cpu.transfer("TAX");
    goto L_84B503;
L_84B503:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB503u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB503u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB503u, 5u, 3u, cpu.address("abs", 0xB508u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B503 PEA
    cpu.push16Value(hw, 0xB508u);
    goto L_84B506;
L_84B506:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB506u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB506u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB506u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xB513u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $84B506 JMP (B513,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xB513u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x84B506u); return; }
}

void sub_84B509_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84B509u: goto L_84B509;
    case 0x84B50Cu: goto L_84B50C;
    case 0x84B50Fu: goto L_84B50F;
    case 0x84B512u: goto L_84B512;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84B509:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB509u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB509u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB509u, 6u, 3u, cpu.address("abs", 0xB6B9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B509 JSR -> $84B6B9 stack real
    { cpu.push16Value(hw,0xB50Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB50Cu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB6B9u), 0x84B509u); }
    goto L_84B50C;
L_84B50C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB50Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB50Cu,0x84B50Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Cu, 6u, 3u, cpu.address("abs", 0xB855u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B50C JSR -> $84B855 stack real
    { cpu.push16Value(hw,0xB50Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB50Fu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB855u), 0x84B50Cu); }
    goto L_84B50F;
L_84B50F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB50Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB50Fu,0x84B50Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Fu, 6u, 3u, cpu.address("abs", 0xBBF7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B50F JSR -> $84BBF7 stack real
    { cpu.push16Value(hw,0xB511u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB512u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBBF7u), 0x84B50Fu); }
    goto L_84B512;
L_84B512:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB512u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB512u,0x84B512u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB512u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB512u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B512 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x84B512u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84B512u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_84B509_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84B509u: goto L_84B509;
    case 0x84B50Cu: goto L_84B50C;
    case 0x84B50Fu: goto L_84B50F;
    case 0x84B512u: goto L_84B512;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84B509:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB509u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB509u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB509u, 6u, 3u, cpu.address("abs", 0xB6B9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B509 JSR -> $84B6B9 stack real
    { cpu.push16Value(hw,0xB50Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB50Cu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB6B9u), 0x84B509u); }
    goto L_84B50C;
L_84B50C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB50Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB50Cu,0x84B50Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Cu, 6u, 3u, cpu.address("abs", 0xB855u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B50C JSR -> $84B855 stack real
    { cpu.push16Value(hw,0xB50Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB50Fu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB855u), 0x84B50Cu); }
    goto L_84B50F;
L_84B50F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB50Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB50Fu,0x84B50Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Fu, 6u, 3u, cpu.address("abs", 0xBBF7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B50F JSR -> $84BBF7 stack real
    { cpu.push16Value(hw,0xB511u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB512u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBBF7u), 0x84B50Fu); }
    goto L_84B512;
L_84B512:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB512u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB512u,0x84B512u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB512u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB512u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B512 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x84B512u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84B512u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_84B534_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84B534u: goto L_84B534;
    case 0x84B537u: goto L_84B537;
    case 0x84B53Au: goto L_84B53A;
    case 0x84B53Cu: goto L_84B53C;
    case 0x84B53Fu: goto L_84B53F;
    case 0x84B541u: goto L_84B541;
    case 0x84B544u: goto L_84B544;
    case 0x84B546u: goto L_84B546;
    case 0x84B549u: goto L_84B549;
    case 0x84B54Cu: goto L_84B54C;
    case 0x84B54Du: goto L_84B54D;
    case 0x84B54Eu: goto L_84B54E;
    case 0x84B552u: goto L_84B552;
    case 0x84B554u: goto L_84B554;
    case 0x84B557u: goto L_84B557;
    case 0x84B559u: goto L_84B559;
    case 0x84B55Cu: goto L_84B55C;
    case 0x84B55Du: goto L_84B55D;
    case 0x84B55Eu: goto L_84B55E;
    case 0x84B560u: goto L_84B560;
    case 0x84B563u: goto L_84B563;
    case 0x84B565u: goto L_84B565;
    case 0x84B567u: goto L_84B567;
    case 0x84B56Au: goto L_84B56A;
    case 0x84B56Du: goto L_84B56D;
    case 0x84B56Fu: goto L_84B56F;
    case 0x84B572u: goto L_84B572;
    case 0x84B573u: goto L_84B573;
    case 0x84B576u: goto L_84B576;
    case 0x84B579u: goto L_84B579;
    case 0x84B57Bu: goto L_84B57B;
    case 0x84B57Du: goto L_84B57D;
    case 0x84B57Fu: goto L_84B57F;
    case 0x84B580u: goto L_84B580;
    case 0x84B582u: goto L_84B582;
    case 0x84B586u: goto L_84B586;
    case 0x84B589u: goto L_84B589;
    case 0x84B58Bu: goto L_84B58B;
    case 0x84B58Du: goto L_84B58D;
    case 0x84B58Fu: goto L_84B58F;
    case 0x84B592u: goto L_84B592;
    case 0x84B594u: goto L_84B594;
    case 0x84B596u: goto L_84B596;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84B534:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB534u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB534u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB534u, 5u, 3u, cpu.address("abs", 0x0657u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B534 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x657u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B537;
L_84B537:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB537u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB537u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB537u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B537 AND
    cpu.logicAnd(0xFFu);
    goto L_84B53A;
L_84B53A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB53Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB53Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB53Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B53A BNE -> $84B57B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84B57B; }
    goto L_84B53C;
L_84B53C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB53Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB53Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB53Cu, 5u, 3u, cpu.address("abs", 0x01A1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B53C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1A1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B53F;
L_84B53F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB53Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB53Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB53Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B53F BEQ -> $84B546
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_84B546; }
    goto L_84B541;
L_84B541:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB541u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB541u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB541u, 8u, 3u, cpu.address("abs", 0x01A1u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B541 DEC
    cpu.decMem(hw, cpu.address("abs", 0x1A1u), cpu.m8?8:16);
    goto L_84B544;
L_84B544:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB544u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB544u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB544u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B544 BRA -> $84B596
    goto L_84B596;
L_84B546:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB546u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB546u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB546u, 5u, 3u, cpu.address("abs", 0x062Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B546 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B549;
L_84B549:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB549u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB549u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB549u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B549 AND
    cpu.logicAnd(0xFFu);
    goto L_84B54C;
L_84B54C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB54Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB54Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB54Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B54C ASL
    cpu.aslA();
    goto L_84B54D;
L_84B54D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB54Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB54Du,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB54Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B54D TAX
    cpu.transfer("TAX");
    goto L_84B54E;
L_84B54E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB54Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB54Eu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB54Eu, 6u, 4u, ((0x9E9025u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B54E LDA
    cpu.loadA(hw.readW(((0x9E9025u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B552;
L_84B552:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB552u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB552u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB552u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B552 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84B554;
L_84B554:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB554u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB554u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB554u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B554 LDA
    cpu.setA(0x9Eu, 16);
    goto L_84B557;
L_84B557:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB557u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB557u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB557u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B557 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_84B559;
L_84B559:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB559u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB559u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB559u, 5u, 3u, cpu.address("abs", 0x01A5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B559 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1A5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B55C;
L_84B55C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB55Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB55Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB55Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B55C ASL
    cpu.aslA();
    goto L_84B55D;
L_84B55D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB55Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB55Du,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB55Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B55D TAY
    cpu.transfer("TAY");
    goto L_84B55E;
L_84B55E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB55Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB55Eu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB55Eu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $84B55E LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B560;
L_84B560:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB560u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB560u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB560u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B560 CMP
    cpu.compareA(0xFFFFu);
    goto L_84B563;
L_84B563:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB563u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB563u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB563u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B563 BEQ -> $84B57B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_84B57B; }
    goto L_84B565;
L_84B565:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB565u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB565u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB565u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B565 STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_84B567;
L_84B567:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB567u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB567u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB567u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B567 AND
    cpu.logicAnd(0xFFu);
    goto L_84B56A;
L_84B56A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB56Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB56Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB56Au, 5u, 3u, cpu.address("abs", 0x01A1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B56A STA
    hw.write(cpu.address("abs", 0x1A1u), cpu.a, cpu.m8?8:16);
    goto L_84B56D;
L_84B56D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB56Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB56Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB56Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B56D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B56F;
L_84B56F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB56Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB56Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB56Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B56F AND
    cpu.logicAnd(0xFF00u);
    goto L_84B572;
L_84B572:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB572u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB572u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB572u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B572 XBA
    cpu.xba();
    goto L_84B573;
L_84B573:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB573u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB573u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB573u, 5u, 3u, cpu.address("abs", 0x01A9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B573 STA
    hw.write(cpu.address("abs", 0x1A9u), cpu.a, cpu.m8?8:16);
    goto L_84B576;
L_84B576:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB576u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB576u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB576u, 8u, 3u, cpu.address("abs", 0x01A5u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B576 INC
    cpu.incMem(hw, cpu.address("abs", 0x1A5u), cpu.m8?8:16);
    goto L_84B579;
L_84B579:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB579u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB579u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB579u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B579 BRA -> $84B596
    goto L_84B596;
L_84B57B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB57Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Bu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B57B SEP
    cpu.sep(0x20u);
    goto L_84B57D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Bu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B57B SEP
    cpu.sep(0x20u);
    goto L_84B57D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB57Bu,0x84B57Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84B57D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB57Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B57D LDA
    cpu.setA(0x81u, 8);
    goto L_84B57F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B57D LDA
    cpu.setA(0x81u, 8);
    goto L_84B57F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB57Du,0x84B57Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84B57F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB57Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Fu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Fu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B57F XBA
    cpu.xba();
    goto L_84B580;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Fu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Fu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B57F XBA
    cpu.xba();
    goto L_84B580;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB57Fu,0x84B57Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84B580:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB580u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB580u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB580u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B580 LDA
    cpu.setA(0xFu, 8);
    goto L_84B582;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB580u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB580u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B580 LDA
    cpu.setA(0xFu, 8);
    goto L_84B582;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB580u,0x84B580u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84B582:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB582u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB582u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB582u, 8u, 4u, 0x8086F4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B582 JSL -> $8086F4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB585u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB586u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8086F4u, 0x84B582u); }
    goto L_84B586;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB582u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB582u, 8u, 4u, 0x8086F4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B582 JSL -> $8086F4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB585u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB586u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8086F4u, 0x84B582u); }
    goto L_84B586;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB582u,0x84B582u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84B586:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB586u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB586u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB586u, 4u, 3u, cpu.address("abs", 0x0657u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B586 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x657u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B589;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB586u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB586u, 4u, 3u, cpu.address("abs", 0x0657u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B586 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x657u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B589;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB586u,0x84B586u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84B589:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB589u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB589u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB589u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B589 AND
    cpu.logicAnd(0xFFu);
    goto L_84B58B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB589u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB589u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B589 AND
    cpu.logicAnd(0xFFu);
    goto L_84B58B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB589u,0x84B589u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84B58B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB58Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B58B BNE -> $84B592
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84B592; }
    goto L_84B58D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B58B BNE -> $84B592
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84B592; }
    goto L_84B58D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB58Bu,0x84B58Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84B58D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB58Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B58D LDA
    cpu.setA(0x83u, 8);
    goto L_84B58F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B58D LDA
    cpu.setA(0x83u, 8);
    goto L_84B58F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB58Du,0x84B58Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84B58F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB58Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Fu, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B58F STA
    hw.write(cpu.address("abs", 0x2140u), cpu.a, cpu.m8?8:16);
    goto L_84B592;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Fu, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B58F STA
    hw.write(cpu.address("abs", 0x2140u), cpu.a, cpu.m8?8:16);
    goto L_84B592;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB58Fu,0x84B58Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84B592:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB592u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB592u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB592u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B592 REP
    cpu.rep(0x20u);
    goto L_84B594;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB592u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB592u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B592 REP
    cpu.rep(0x20u);
    goto L_84B594;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB592u,0x84B592u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84B594:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB594u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB594u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB594u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B594 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_84B596;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB594u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB594u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B594 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_84B596;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB594u,0x84B594u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84B596:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB596u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB596u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB596u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B596 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84B596u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84B596u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB596u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB596u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B596 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84B596u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84B596u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB596u,0x84B596u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

