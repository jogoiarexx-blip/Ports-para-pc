#include "generated.hpp"
void sub_8084CE_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8084CEu: goto L_8084CE;
    case 0x8084D2u: goto L_8084D2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8084CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84CEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84CEu, 8u, 4u, 0x848453u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8084CE JSL -> $848453 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x84D1u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x84D2u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848453u, 0x8084CEu); }
    goto L_8084D2;
L_8084D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84D2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84D2u,0x8084D2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84D2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84D2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8084D2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8084D2u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8084D2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8084CE_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8084CEu: goto L_8084CE;
    case 0x8084D2u: goto L_8084D2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8084CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84CEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84CEu, 8u, 4u, 0x848453u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8084CE JSL -> $848453 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x84D1u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x84D2u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848453u, 0x8084CEu); }
    goto L_8084D2;
L_8084D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84D2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84D2u,0x8084D2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84D2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84D2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8084D2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8084D2u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8084D2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808505_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808505u: goto L_808505;
    case 0x808509u: goto L_808509;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808505:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8505u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8505u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8505u, 8u, 4u, 0x84B4F8u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808505 JSL -> $84B4F8 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8508u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8509u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84B4F8u, 0x808505u); }
    goto L_808509;
L_808509:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8509u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8509u,0x808509u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8509u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8509u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808509 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808509u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808509u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808505_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808505u: goto L_808505;
    case 0x808509u: goto L_808509;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808505:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8505u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8505u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8505u, 8u, 4u, 0x84B4F8u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808505 JSL -> $84B4F8 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8508u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8509u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84B4F8u, 0x808505u); }
    goto L_808509;
L_808509:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8509u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8509u,0x808509u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8509u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8509u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808509 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808509u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808509u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808547_E0M0X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808547u: goto L_808547;
    case 0x808548u: goto L_808548;
    case 0x80854Au: goto L_80854A;
    case 0x80854Bu: goto L_80854B;
    case 0x80854Du: goto L_80854D;
    case 0x80854Fu: goto L_80854F;
    case 0x808552u: goto L_808552;
    case 0x808554u: goto L_808554;
    case 0x808555u: goto L_808555;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808547:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8547u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8547u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8547u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808547 PHP
    cpu.push("PHP", hw);
    goto L_808548;
L_808548:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8548u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8548u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8548u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808548 SEP
    cpu.sep(0x20u);
    goto L_80854A;
L_80854A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x854Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x854Au,cpu,0x58u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x854Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80854A CLI
    cpu.setFlag('I', false);
    goto L_80854B;
L_80854B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x854Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x854Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x854Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x73u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80854B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x73u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80854D;
L_80854D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x854Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x854Du,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x854Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80854D ORA
    cpu.logicOr(0x81u);
    goto L_80854F;
L_80854F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x854Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x854Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x854Fu, 4u, 3u, cpu.address("abs", 0x4200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80854F STA
    hw.write(cpu.address("abs", 0x4200u), cpu.a, cpu.m8?8:16);
    goto L_808552;
L_808552:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8552u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8552u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8552u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x73u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808552 STA
    hw.write(cpu.address("dp", 0x73u), cpu.a, cpu.m8?8:16);
    goto L_808554;
L_808554:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8554u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8554u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8554u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808554 PLP
    cpu.pop("PLP", hw);
    goto L_808555;
L_808555:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8555u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8555u,0x808555u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8555u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8555u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808555 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808555u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808555u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808564_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808564u: goto L_808564;
    case 0x808565u: goto L_808565;
    case 0x808567u: goto L_808567;
    case 0x808569u: goto L_808569;
    case 0x80856Bu: goto L_80856B;
    case 0x80856Du: goto L_80856D;
    case 0x808570u: goto L_808570;
    case 0x808571u: goto L_808571;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808564:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8564u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8564u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8564u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808564 PHP
    cpu.push("PHP", hw);
    goto L_808565;
L_808565:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8565u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8565u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8565u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808565 SEP
    cpu.sep(0x20u);
    goto L_808567;
L_808567:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8567u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8567u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8567u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808567 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x74u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808569;
L_808569:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8569u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8569u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8569u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808569 AND
    cpu.logicAnd(0xFu);
    goto L_80856B;
L_80856B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x856Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x856Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x856Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80856B STA
    hw.write(cpu.address("dp", 0x74u), cpu.a, cpu.m8?8:16);
    goto L_80856D;
L_80856D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x856Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x856Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x856Du, 4u, 3u, cpu.address("abs", 0x2100u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80856D STA
    hw.write(cpu.address("abs", 0x2100u), cpu.a, cpu.m8?8:16);
    goto L_808570;
L_808570:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8570u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8570u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8570u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808570 PLP
    cpu.pop("PLP", hw);
    goto L_808571;
L_808571:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8571u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8571u,0x808571u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8571u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8571u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808571 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808571u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808571u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80870C_E0M1X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80870Cu: goto L_80870C;
    case 0x80870Eu: goto L_80870E;
    case 0x808710u: goto L_808710;
    case 0x808712u: goto L_808712;
    case 0x808714u: goto L_808714;
    case 0x808716u: goto L_808716;
    case 0x808718u: goto L_808718;
    case 0x80871Au: goto L_80871A;
    case 0x80871Bu: goto L_80871B;
    case 0x80871Du: goto L_80871D;
    case 0x80871Fu: goto L_80871F;
    case 0x808720u: goto L_808720;
    case 0x808722u: goto L_808722;
    case 0x808724u: goto L_808724;
    case 0x808726u: goto L_808726;
    case 0x808728u: goto L_808728;
    case 0x80872Au: goto L_80872A;
    case 0x80872Cu: goto L_80872C;
    case 0x80872Eu: goto L_80872E;
    case 0x808730u: goto L_808730;
    case 0x808732u: goto L_808732;
    case 0x808734u: goto L_808734;
    case 0x808736u: goto L_808736;
    case 0x808738u: goto L_808738;
    case 0x80873Au: goto L_80873A;
    case 0x80873Bu: goto L_80873B;
    case 0x80873Du: goto L_80873D;
    case 0x80873Fu: goto L_80873F;
    case 0x808741u: goto L_808741;
    case 0x808743u: goto L_808743;
    case 0x808745u: goto L_808745;
    case 0x808747u: goto L_808747;
    case 0x808748u: goto L_808748;
    case 0x80874Au: goto L_80874A;
    case 0x80874Cu: goto L_80874C;
    case 0x80874Eu: goto L_80874E;
    case 0x808750u: goto L_808750;
    case 0x808752u: goto L_808752;
    case 0x808754u: goto L_808754;
    case 0x808756u: goto L_808756;
    case 0x808758u: goto L_808758;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80870C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x870Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x870Cu,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x870Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80870C BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), false);
    goto L_80870E;
L_80870E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x870Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x870Eu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x870Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80870E BPL -> $80872E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80872E; }
    goto L_808710;
L_808710:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8710u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8710u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8710u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808710 DEC
    cpu.decMem(hw, cpu.address("dp", 0x76u), cpu.m8?8:16);
    goto L_808712;
L_808712:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8712u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8712u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8712u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808712 BPL -> $80872E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80872E; }
    goto L_808714;
L_808714:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8714u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8714u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8714u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808714 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x74u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808716;
L_808716:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8716u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8716u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8716u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808716 AND
    cpu.logicAnd(0xFu);
    goto L_808718;
L_808718:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8718u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8718u,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8718u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808718 BVS -> $80871F
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_80871F; }
    goto L_80871A;
L_80871A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x871Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x871Au,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x871Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80871A DEC
    cpu.decReg('A');
    goto L_80871B;
L_80871B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x871Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x871Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x871Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80871B BNE -> $808726
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_808726; }
    goto L_80871D;
L_80871D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x871Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x871Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x871Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80871D BRA -> $808724
    goto L_808724;
L_80871F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x871Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x871Fu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x871Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80871F INC
    cpu.inc('A');
    goto L_808720;
L_808720:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8720u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8720u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8720u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808720 CMP
    cpu.compareA(0xFu);
    goto L_808722;
L_808722:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8722u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8722u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8722u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808722 BCC -> $808726
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_808726; }
    goto L_808724;
L_808724:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8724u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8724u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8724u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808724 STZ
    hw.write(cpu.address("dp", 0x75u), 0, cpu.m8?8:16);
    goto L_808726;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8724u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8724u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808724 STZ
    hw.write(cpu.address("dp", 0x75u), 0, cpu.m8?8:16);
    goto L_808726;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8724u,0x808724u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_808726:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8726u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8726u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8726u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808726 STA
    hw.write(cpu.address("dp", 0x74u), cpu.a, cpu.m8?8:16);
    goto L_808728;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8726u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8726u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808726 STA
    hw.write(cpu.address("dp", 0x74u), cpu.a, cpu.m8?8:16);
    goto L_808728;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8726u,0x808726u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_808728:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8728u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8728u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8728u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808728 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80872A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8728u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8728u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808728 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80872A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8728u,0x808728u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80872A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x872Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x872Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x872Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80872A AND
    cpu.logicAnd(0x3Fu);
    goto L_80872C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x872Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x872Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80872A AND
    cpu.logicAnd(0x3Fu);
    goto L_80872C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x872Au,0x80872Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80872C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x872Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x872Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x872Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80872C STA
    hw.write(cpu.address("dp", 0x76u), cpu.a, cpu.m8?8:16);
    goto L_80872E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x872Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x872Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80872C STA
    hw.write(cpu.address("dp", 0x76u), cpu.a, cpu.m8?8:16);
    goto L_80872E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x872Cu,0x80872Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80872E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x872Eu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x872Eu,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x872Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x78u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80872E BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x78u), cpu.m8?8:16), false);
    goto L_808730;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x872Eu,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x872Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x78u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80872E BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x78u), cpu.m8?8:16), false);
    goto L_808730;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x872Eu,0x80872Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_808730:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8730u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8730u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8730u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808730 BPL -> $808758
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808758; }
    goto L_808732;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8730u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8730u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808730 BPL -> $808758
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808758; }
    goto L_808732;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8730u,0x808730u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_808732:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8732u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8732u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8732u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x79u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808732 DEC
    cpu.decMem(hw, cpu.address("dp", 0x79u), cpu.m8?8:16);
    goto L_808734;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8732u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8732u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x79u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808732 DEC
    cpu.decMem(hw, cpu.address("dp", 0x79u), cpu.m8?8:16);
    goto L_808734;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8732u,0x808732u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_808734:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8734u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8734u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8734u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808734 BPL -> $808758
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808758; }
    goto L_808736;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8734u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8734u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808734 BPL -> $808758
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808758; }
    goto L_808736;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8734u,0x808734u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_808736:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8736u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8736u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8736u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808736 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808738;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8736u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8736u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808736 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808738;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8736u,0x808736u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_808738:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8738u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8738u,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8738u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808738 BVS -> $808747
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_808747; }
    goto L_80873A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8738u,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8738u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808738 BVS -> $808747
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_808747; }
    goto L_80873A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8738u,0x808738u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80873A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x873Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x873Au,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x873Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80873A CLC
    cpu.setFlag('C', false);
    goto L_80873B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x873Au,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x873Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80873A CLC
    cpu.setFlag('C', false);
    goto L_80873B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x873Au,0x80873Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80873B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x873Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x873Bu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x873Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80873B ADC
    cpu.adc(0x10u);
    goto L_80873D;
L_80873D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x873Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x873Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x873Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80873D CMP
    cpu.compareA(0xF0u);
    goto L_80873F;
L_80873F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x873Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x873Fu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x873Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80873F BCC -> $808750
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_808750; }
    goto L_808741;
L_808741:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8741u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8741u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8741u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808741 AND
    cpu.logicAnd(0xFu);
    goto L_808743;
L_808743:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8743u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8743u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8743u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808743 ORA
    cpu.logicOr(0xF0u);
    goto L_808745;
L_808745:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8745u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8745u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8745u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808745 BRA -> $80874E
    goto L_80874E;
L_808747:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8747u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8747u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8747u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808747 SEC
    cpu.setFlag('C', true);
    goto L_808748;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8747u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8747u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808747 SEC
    cpu.setFlag('C', true);
    goto L_808748;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8747u,0x808747u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_808748:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8748u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8748u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8748u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808748 SBC
    cpu.sbc(0x10u);
    goto L_80874A;
L_80874A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x874Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x874Au,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x874Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80874A BCS -> $808750
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_808750; }
    goto L_80874C;
L_80874C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x874Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x874Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x874Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80874C LDA
    cpu.setA(0x0u, 8);
    goto L_80874E;
L_80874E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x874Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x874Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x874Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x78u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80874E STZ
    hw.write(cpu.address("dp", 0x78u), 0, cpu.m8?8:16);
    goto L_808750;
L_808750:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8750u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8750u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8750u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808750 STA
    hw.write(cpu.address("dp", 0x77u), cpu.a, cpu.m8?8:16);
    goto L_808752;
L_808752:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8752u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8752u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8752u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x78u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808752 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x78u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808754;
L_808754:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8754u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8754u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8754u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808754 AND
    cpu.logicAnd(0x3Fu);
    goto L_808756;
L_808756:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8756u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8756u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8756u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x79u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808756 STA
    hw.write(cpu.address("dp", 0x79u), cpu.a, cpu.m8?8:16);
    goto L_808758;
L_808758:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8758u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8758u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8758u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808758 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808758u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808758u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8758u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8758u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808758 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808758u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808758u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8758u,0x808758u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80870C_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80870Cu: goto L_80870C;
    case 0x80870Eu: goto L_80870E;
    case 0x808710u: goto L_808710;
    case 0x808712u: goto L_808712;
    case 0x808714u: goto L_808714;
    case 0x808716u: goto L_808716;
    case 0x808718u: goto L_808718;
    case 0x80871Au: goto L_80871A;
    case 0x80871Bu: goto L_80871B;
    case 0x80871Du: goto L_80871D;
    case 0x80871Fu: goto L_80871F;
    case 0x808720u: goto L_808720;
    case 0x808722u: goto L_808722;
    case 0x808724u: goto L_808724;
    case 0x808726u: goto L_808726;
    case 0x808728u: goto L_808728;
    case 0x80872Au: goto L_80872A;
    case 0x80872Cu: goto L_80872C;
    case 0x80872Eu: goto L_80872E;
    case 0x808730u: goto L_808730;
    case 0x808732u: goto L_808732;
    case 0x808734u: goto L_808734;
    case 0x808736u: goto L_808736;
    case 0x808738u: goto L_808738;
    case 0x80873Au: goto L_80873A;
    case 0x80873Bu: goto L_80873B;
    case 0x80873Du: goto L_80873D;
    case 0x80873Fu: goto L_80873F;
    case 0x808741u: goto L_808741;
    case 0x808743u: goto L_808743;
    case 0x808745u: goto L_808745;
    case 0x808747u: goto L_808747;
    case 0x808748u: goto L_808748;
    case 0x80874Au: goto L_80874A;
    case 0x80874Cu: goto L_80874C;
    case 0x80874Eu: goto L_80874E;
    case 0x808750u: goto L_808750;
    case 0x808752u: goto L_808752;
    case 0x808754u: goto L_808754;
    case 0x808756u: goto L_808756;
    case 0x808758u: goto L_808758;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80870C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x870Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x870Cu,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x870Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80870C BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), false);
    goto L_80870E;
L_80870E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x870Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x870Eu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x870Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80870E BPL -> $80872E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80872E; }
    goto L_808710;
L_808710:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8710u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8710u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8710u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808710 DEC
    cpu.decMem(hw, cpu.address("dp", 0x76u), cpu.m8?8:16);
    goto L_808712;
L_808712:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8712u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8712u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8712u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808712 BPL -> $80872E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80872E; }
    goto L_808714;
L_808714:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8714u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8714u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8714u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808714 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x74u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808716;
L_808716:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8716u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8716u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8716u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808716 AND
    cpu.logicAnd(0xFu);
    goto L_808718;
L_808718:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8718u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8718u,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8718u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808718 BVS -> $80871F
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_80871F; }
    goto L_80871A;
L_80871A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x871Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x871Au,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x871Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80871A DEC
    cpu.decReg('A');
    goto L_80871B;
L_80871B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x871Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x871Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x871Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80871B BNE -> $808726
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_808726; }
    goto L_80871D;
L_80871D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x871Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x871Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x871Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80871D BRA -> $808724
    goto L_808724;
L_80871F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x871Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x871Fu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x871Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80871F INC
    cpu.inc('A');
    goto L_808720;
L_808720:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8720u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8720u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8720u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808720 CMP
    cpu.compareA(0xFu);
    goto L_808722;
L_808722:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8722u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8722u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8722u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808722 BCC -> $808726
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_808726; }
    goto L_808724;
L_808724:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8724u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8724u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8724u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808724 STZ
    hw.write(cpu.address("dp", 0x75u), 0, cpu.m8?8:16);
    goto L_808726;
L_808726:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8726u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8726u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8726u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808726 STA
    hw.write(cpu.address("dp", 0x74u), cpu.a, cpu.m8?8:16);
    goto L_808728;
L_808728:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8728u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8728u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8728u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808728 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80872A;
L_80872A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x872Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x872Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x872Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80872A AND
    cpu.logicAnd(0x3Fu);
    goto L_80872C;
L_80872C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x872Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x872Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x872Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80872C STA
    hw.write(cpu.address("dp", 0x76u), cpu.a, cpu.m8?8:16);
    goto L_80872E;
L_80872E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x872Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x872Eu,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x872Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x78u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80872E BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x78u), cpu.m8?8:16), false);
    goto L_808730;
L_808730:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8730u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8730u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8730u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808730 BPL -> $808758
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808758; }
    goto L_808732;
L_808732:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8732u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8732u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8732u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x79u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808732 DEC
    cpu.decMem(hw, cpu.address("dp", 0x79u), cpu.m8?8:16);
    goto L_808734;
L_808734:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8734u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8734u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8734u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808734 BPL -> $808758
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808758; }
    goto L_808736;
L_808736:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8736u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8736u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8736u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808736 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x77u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808738;
L_808738:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8738u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8738u,cpu,0x70u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8738u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808738 BVS -> $808747
    if (cpu.v) { hw.addCpuInternalCycles(1u); goto L_808747; }
    goto L_80873A;
L_80873A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x873Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x873Au,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x873Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80873A CLC
    cpu.setFlag('C', false);
    goto L_80873B;
L_80873B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x873Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x873Bu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x873Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80873B ADC
    cpu.adc(0x10u);
    goto L_80873D;
L_80873D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x873Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x873Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x873Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80873D CMP
    cpu.compareA(0xF0u);
    goto L_80873F;
L_80873F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x873Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x873Fu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x873Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80873F BCC -> $808750
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_808750; }
    goto L_808741;
L_808741:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8741u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8741u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8741u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808741 AND
    cpu.logicAnd(0xFu);
    goto L_808743;
L_808743:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8743u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8743u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8743u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808743 ORA
    cpu.logicOr(0xF0u);
    goto L_808745;
L_808745:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8745u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8745u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8745u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808745 BRA -> $80874E
    goto L_80874E;
L_808747:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8747u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8747u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8747u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808747 SEC
    cpu.setFlag('C', true);
    goto L_808748;
L_808748:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8748u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8748u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8748u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808748 SBC
    cpu.sbc(0x10u);
    goto L_80874A;
L_80874A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x874Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x874Au,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x874Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80874A BCS -> $808750
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_808750; }
    goto L_80874C;
L_80874C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x874Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x874Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x874Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80874C LDA
    cpu.setA(0x0u, 8);
    goto L_80874E;
L_80874E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x874Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x874Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x874Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x78u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80874E STZ
    hw.write(cpu.address("dp", 0x78u), 0, cpu.m8?8:16);
    goto L_808750;
L_808750:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8750u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8750u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8750u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808750 STA
    hw.write(cpu.address("dp", 0x77u), cpu.a, cpu.m8?8:16);
    goto L_808752;
L_808752:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8752u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8752u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8752u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x78u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808752 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x78u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808754;
L_808754:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8754u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8754u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8754u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808754 AND
    cpu.logicAnd(0x3Fu);
    goto L_808756;
L_808756:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8756u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8756u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8756u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x79u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808756 STA
    hw.write(cpu.address("dp", 0x79u), cpu.a, cpu.m8?8:16);
    goto L_808758;
L_808758:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8758u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8758u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8758u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808758 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808758u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808758u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_809BD0_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809BD0u: goto L_809BD0;
    case 0x809BD2u: goto L_809BD2;
    case 0x809BD4u: goto L_809BD4;
    case 0x809BD5u: goto L_809BD5;
    case 0x809BD7u: goto L_809BD7;
    case 0x809BDAu: goto L_809BDA;
    case 0x809BDCu: goto L_809BDC;
    case 0x809BDEu: goto L_809BDE;
    case 0x809BE0u: goto L_809BE0;
    case 0x809BE1u: goto L_809BE1;
    case 0x809BE4u: goto L_809BE4;
    case 0x809BE5u: goto L_809BE5;
    case 0x809BE7u: goto L_809BE7;
    case 0x809BEAu: goto L_809BEA;
    case 0x809BECu: goto L_809BEC;
    case 0x809BEDu: goto L_809BED;
    case 0x809BF0u: goto L_809BF0;
    case 0x809BF3u: goto L_809BF3;
    case 0x809BF5u: goto L_809BF5;
    case 0x809BF6u: goto L_809BF6;
    case 0x809BF7u: goto L_809BF7;
    case 0x809BF8u: goto L_809BF8;
    case 0x809BF9u: goto L_809BF9;
    case 0x809BFBu: goto L_809BFB;
    case 0x809BFDu: goto L_809BFD;
    case 0x809BFFu: goto L_809BFF;
    case 0x809C00u: goto L_809C00;
    case 0x809C02u: goto L_809C02;
    case 0x809C06u: goto L_809C06;
    case 0x809C07u: goto L_809C07;
    case 0x809C08u: goto L_809C08;
    case 0x809C09u: goto L_809C09;
    case 0x809C0Au: goto L_809C0A;
    case 0x809C0Cu: goto L_809C0C;
    case 0x809C0Fu: goto L_809C0F;
    case 0x809C12u: goto L_809C12;
    case 0x809C15u: goto L_809C15;
    case 0x809C19u: goto L_809C19;
    case 0x809C1Du: goto L_809C1D;
    case 0x809C1Eu: goto L_809C1E;
    case 0x809C1Fu: goto L_809C1F;
    case 0x809C22u: goto L_809C22;
    case 0x809C23u: goto L_809C23;
    case 0x809C24u: goto L_809C24;
    case 0x809C26u: goto L_809C26;
    case 0x809C29u: goto L_809C29;
    case 0x809C2Cu: goto L_809C2C;
    case 0x809C30u: goto L_809C30;
    case 0x809C34u: goto L_809C34;
    case 0x809C35u: goto L_809C35;
    case 0x809C36u: goto L_809C36;
    case 0x809C37u: goto L_809C37;
    case 0x809C39u: goto L_809C39;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809BD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BD0u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BD0u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $809BD0 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809BD2;
L_809BD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BD2u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BD2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BD2 BPL -> $809BD5
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_809BD5; }
    goto L_809BD4;
L_809BD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BD4u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BD4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809BD4 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x809BD4u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x809BD4u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_809BD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BD5u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BD5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BD5 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_809BD7;
L_809BD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BD7u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BD7u, 6u, 3u, cpu.address("absx", 0x2800u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BD7 STA
    hw.write(cpu.address("absx", 0x2800u), cpu.a, cpu.m8?8:16);
    goto L_809BDA;
L_809BDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BDAu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BDAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BDA STX
    hw.write(cpu.address("dp", 0x63u), cpu.x, cpu.x8?8:16);
    goto L_809BDC;
L_809BDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BDCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BDCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BDC STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_809BDE;
L_809BDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BDEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BDEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BDE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x63u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809BE0;
L_809BE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BE0u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BE0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BE0 CLC
    cpu.setFlag('C', false);
    goto L_809BE1;
L_809BE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BE1u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BE1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BE1 ADC
    cpu.adc(0x40u);
    goto L_809BE4;
L_809BE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BE4u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BE4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BE4 TAX
    cpu.transfer("TAX");
    goto L_809BE5;
L_809BE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BE5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BE5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BE5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809BE7;
L_809BE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BE7u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BE7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BE7 CMP
    cpu.compareA(0x3400u);
    goto L_809BEA;
L_809BEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BEAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BEAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BEA BEQ -> $809BF0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_809BF0; }
    goto L_809BEC;
L_809BEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BECu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BECu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BEC CLC
    cpu.setFlag('C', false);
    goto L_809BED;
L_809BED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BEDu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BEDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BED ADC
    cpu.adc(0x10u);
    goto L_809BF0;
L_809BF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF0u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF0u, 6u, 3u, cpu.address("absx", 0x2800u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BF0 STA
    hw.write(cpu.address("absx", 0x2800u), cpu.a, cpu.m8?8:16);
    goto L_809BF3;
L_809BF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF3u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BF3 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_809BF5;
L_809BF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF5u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BF5 INX
    cpu.inc('X');
    goto L_809BF6;
L_809BF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF6u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BF6 INX
    cpu.inc('X');
    goto L_809BF7;
L_809BF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF7u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BF7 INY
    cpu.inc('Y');
    goto L_809BF8;
L_809BF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF8u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BF8 INY
    cpu.inc('Y');
    goto L_809BF9;
L_809BF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF9u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BF9 BPL -> $809BD0
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_809BD0; }
    goto L_809BFB;
L_809BFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFBu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFBu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $809BFB LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809BFD;
L_809BFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFDu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BFD BPL -> $809C00
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_809C00; }
    goto L_809BFF;
L_809BFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFFu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809BFF RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x809BFFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x809BFFu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_809C00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C00u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C00u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C00 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_809C02;
L_809C02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C02u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C02u, 6u, 4u, ((0x7E2800u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C02 STA
    hw.write(((0x7E2800u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_809C06;
L_809C06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C06u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C06u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C06 INX
    cpu.inc('X');
    goto L_809C07;
L_809C07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C07u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C07u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C07 INX
    cpu.inc('X');
    goto L_809C08;
L_809C08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C08u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C08u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C08 INY
    cpu.inc('Y');
    goto L_809C09;
L_809C09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C09u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C09u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C09 INY
    cpu.inc('Y');
    goto L_809C0A;
L_809C0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C0A BPL -> $809BFB
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_809BFB; }
    goto L_809C0C;
L_809C0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Cu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C0C LDY
    cpu.setY(0x16u, 16);
    goto L_809C0F;
L_809C0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C0F LDX
    cpu.setX(0x0u, 16);
    goto L_809C12;
L_809C12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C12u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C12u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C12 LDA
    cpu.setA(0xFFFFu, 16);
    goto L_809C15;
L_809C15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C15u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C15u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C15 STA
    hw.write(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_809C19;
L_809C19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C19u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C19u, 6u, 4u, ((0x7E2220u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C19 STA
    hw.write(((0x7E2220u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_809C1D;
L_809C1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Du,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C1D TXA
    cpu.transfer("TXA");
    goto L_809C1E;
L_809C1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Eu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C1E CLC
    cpu.setFlag('C', false);
    goto L_809C1F;
L_809C1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Fu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C1F ADC
    cpu.adc(0x16u);
    goto L_809C22;
L_809C22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C22u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C22u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C22 TAX
    cpu.transfer("TAX");
    goto L_809C23;
L_809C23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C23u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C23u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C23 DEY
    cpu.decReg('Y');
    goto L_809C24;
L_809C24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C24u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C24 BPL -> $809C12
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_809C12; }
    goto L_809C26;
L_809C26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C26u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C26u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C26 LDY
    cpu.setY(0xBu, 16);
    goto L_809C29;
L_809C29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C29u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C29u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C29 LDA
    cpu.setA(0xFFFFu, 16);
    goto L_809C2C;
L_809C2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C2Cu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C2Cu, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C2C STA
    hw.write(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_809C30;
L_809C30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C30u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C30u, 6u, 4u, ((0x7E2220u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C30 STA
    hw.write(((0x7E2220u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_809C34;
L_809C34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C34u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C34u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C34 INX
    cpu.inc('X');
    goto L_809C35;
L_809C35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C35u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C35u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C35 INX
    cpu.inc('X');
    goto L_809C36;
L_809C36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C36u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C36u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C36 DEY
    cpu.decReg('Y');
    goto L_809C37;
L_809C37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C37u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C37u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809C37 BPL -> $809C29
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_809C29; }
    goto L_809C39;
L_809C39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C39u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C39u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809C39 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x809C39u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x809C39u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_809F25_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809F25u: goto L_809F25;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809F25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F25u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F25u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809F25 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x809F25u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x809F25u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80A2D8_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80A2D8u: goto L_80A2D8;
    case 0x80A2DBu: goto L_80A2DB;
    case 0x80A2DEu: goto L_80A2DE;
    case 0x80A2E1u: goto L_80A2E1;
    case 0x80A2E4u: goto L_80A2E4;
    case 0x80A2E8u: goto L_80A2E8;
    case 0x80A2EAu: goto L_80A2EA;
    case 0x80A2ECu: goto L_80A2EC;
    case 0x80A2EDu: goto L_80A2ED;
    case 0x80A2F0u: goto L_80A2F0;
    case 0x80A2F3u: goto L_80A2F3;
    case 0x80A2F6u: goto L_80A2F6;
    case 0x80A2FAu: goto L_80A2FA;
    case 0x80A2FDu: goto L_80A2FD;
    case 0x80A300u: goto L_80A300;
    case 0x80A303u: goto L_80A303;
    case 0x80A306u: goto L_80A306;
    case 0x80A30Au: goto L_80A30A;
    case 0x80A30Cu: goto L_80A30C;
    case 0x80A30Eu: goto L_80A30E;
    case 0x80A30Fu: goto L_80A30F;
    case 0x80A312u: goto L_80A312;
    case 0x80A315u: goto L_80A315;
    case 0x80A318u: goto L_80A318;
    case 0x80A31Cu: goto L_80A31C;
    case 0x80A31Fu: goto L_80A31F;
    case 0x80A321u: goto L_80A321;
    case 0x80A324u: goto L_80A324;
    case 0x80A326u: goto L_80A326;
    case 0x80A329u: goto L_80A329;
    case 0x80A32Cu: goto L_80A32C;
    case 0x80A330u: goto L_80A330;
    case 0x80A333u: goto L_80A333;
    case 0x80A336u: goto L_80A336;
    case 0x80A339u: goto L_80A339;
    case 0x80A33Cu: goto L_80A33C;
    case 0x80A340u: goto L_80A340;
    case 0x80A341u: goto L_80A341;
    case 0x80A344u: goto L_80A344;
    case 0x80A347u: goto L_80A347;
    case 0x80A349u: goto L_80A349;
    case 0x80A34Au: goto L_80A34A;
    case 0x80A34Du: goto L_80A34D;
    case 0x80A34Eu: goto L_80A34E;
    case 0x80A351u: goto L_80A351;
    case 0x80A354u: goto L_80A354;
    case 0x80A357u: goto L_80A357;
    case 0x80A35Au: goto L_80A35A;
    case 0x80A35Eu: goto L_80A35E;
    case 0x80A35Fu: goto L_80A35F;
    case 0x80A362u: goto L_80A362;
    case 0x80A365u: goto L_80A365;
    case 0x80A367u: goto L_80A367;
    case 0x80A368u: goto L_80A368;
    case 0x80A36Bu: goto L_80A36B;
    case 0x80A36Cu: goto L_80A36C;
    case 0x80A36Fu: goto L_80A36F;
    case 0x80A372u: goto L_80A372;
    case 0x80A375u: goto L_80A375;
    case 0x80A378u: goto L_80A378;
    case 0x80A37Cu: goto L_80A37C;
    case 0x80A37Du: goto L_80A37D;
    case 0x80A380u: goto L_80A380;
    case 0x80A383u: goto L_80A383;
    case 0x80A385u: goto L_80A385;
    case 0x80A386u: goto L_80A386;
    case 0x80A389u: goto L_80A389;
    case 0x80A38Au: goto L_80A38A;
    case 0x80A38Du: goto L_80A38D;
    case 0x80A391u: goto L_80A391;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80A2D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2D8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2D8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A2D8 LDA
    cpu.setA(0x8000u, 16);
    goto L_80A2DB;
L_80A2DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2DBu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2DBu, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A2DB STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_80A2DE;
L_80A2DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2DEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2DEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A2DE LDA
    cpu.setA(0x8Eu, 16);
    goto L_80A2E1;
L_80A2E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2E1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2E1u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A2E1 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_80A2E4;
L_80A2E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2E4u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2E4u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A2E4 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA2E7u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA2E8u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x80A2E4u); }
    goto L_80A2E8;
L_80A2E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2E8u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA2E8u,0x80A2E8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2E8u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2E8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A2E8 SEP
    cpu.sep(0x20u);
    goto L_80A2EA;
L_80A2EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2EAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2EAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A2EA LDA
    cpu.setA(0x7Eu, 8);
    goto L_80A2EC;
L_80A2EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2ECu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2ECu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A2EC PHA
    cpu.push("PHA", hw);
    goto L_80A2ED;
L_80A2ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2EDu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2EDu, 5u, 3u, cpu.address("abs", 0x8000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A2ED PEA
    cpu.push16Value(hw, 0x8000u);
    goto L_80A2F0;
L_80A2F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2F0u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2F0u, 5u, 3u, cpu.address("abs", 0x6000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A2F0 PEA
    cpu.push16Value(hw, 0x6000u);
    goto L_80A2F3;
L_80A2F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2F3u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2F3u, 5u, 3u, cpu.address("abs", 0x2000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A2F3 PEA
    cpu.push16Value(hw, 0x2000u);
    goto L_80A2F6;
L_80A2F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2F6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2F6u, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A2F6 JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA2F9u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA2FAu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x80A2F6u); }
    goto L_80A2FA;
L_80A2FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2FAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA2FAu,0x80A2FAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2FAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2FAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A2FA LDA
    cpu.setA(0x8000u, 16);
    goto L_80A2FD;
L_80A2FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2FDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2FDu, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A2FD STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_80A300;
L_80A300:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA300u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA300u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA300u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A300 LDA
    cpu.setA(0x98u, 16);
    goto L_80A303;
L_80A303:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA303u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA303u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA303u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A303 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_80A306;
L_80A306:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA306u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA306u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA306u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A306 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA309u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA30Au,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x80A306u); }
    goto L_80A30A;
L_80A30A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA30Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA30Au,0x80A30Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA30Au,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA30Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A30A SEP
    cpu.sep(0x20u);
    goto L_80A30C;
L_80A30C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA30Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA30Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA30Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A30C LDA
    cpu.setA(0x7Eu, 8);
    goto L_80A30E;
L_80A30E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA30Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA30Eu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA30Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A30E PHA
    cpu.push("PHA", hw);
    goto L_80A30F;
L_80A30F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA30Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA30Fu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA30Fu, 5u, 3u, cpu.address("abs", 0x8000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A30F PEA
    cpu.push16Value(hw, 0x8000u);
    goto L_80A312;
L_80A312:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA312u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA312u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA312u, 5u, 3u, cpu.address("abs", 0x2000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A312 PEA
    cpu.push16Value(hw, 0x2000u);
    goto L_80A315;
L_80A315:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA315u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA315u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA315u, 5u, 3u, cpu.address("abs", 0x6000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A315 PEA
    cpu.push16Value(hw, 0x6000u);
    goto L_80A318;
L_80A318:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA318u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA318u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA318u, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A318 JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA31Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA31Cu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x80A318u); }
    goto L_80A31C;
L_80A31C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA31Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA31Cu,0x80A31Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA31Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA31Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A31C LDA
    cpu.setA(0x8C6Cu, 16);
    goto L_80A31F;
L_80A31F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA31Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA31Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA31Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A31F STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80A321;
L_80A321:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA321u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA321u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA321u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A321 LDA
    cpu.setA(0x8Au, 16);
    goto L_80A324;
L_80A324:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA324u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA324u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA324u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A324 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_80A326;
L_80A326:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA326u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA326u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA326u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A326 LDX
    cpu.setX(0x0u, 16);
    goto L_80A329;
L_80A329:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA329u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA329u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA329u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A329 LDY
    cpu.setY(0x200u, 16);
    goto L_80A32C;
L_80A32C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA32Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA32Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA32Cu, 8u, 4u, 0x808BB9u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A32C JSL -> $808BB9 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA32Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA330u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808BB9u, 0x80A32Cu); }
    goto L_80A330;
L_80A330:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA330u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA330u,0x80A330u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA330u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA330u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A330 LDA
    cpu.setA(0xC361u, 16);
    goto L_80A333;
L_80A333:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA333u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA333u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA333u, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A333 STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_80A336;
L_80A336:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA336u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA336u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA336u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A336 LDA
    cpu.setA(0x8Cu, 16);
    goto L_80A339;
L_80A339:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA339u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA339u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA339u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A339 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_80A33C;
L_80A33C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA33Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA33Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA33Cu, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A33C JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA33Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA340u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x80A33Cu); }
    goto L_80A340;
L_80A340:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA340u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA340u,0x80A340u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA340u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA340u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A340 PHB
    cpu.push("PHB", hw);
    goto L_80A341;
L_80A341:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA341u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA341u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA341u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A341 LDX
    cpu.setX(0x8000u, 16);
    goto L_80A344;
L_80A344:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA344u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA344u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA344u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A344 LDY
    cpu.setY(0x2800u, 16);
    goto L_80A347;
L_80A347:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA347u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA347u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA347u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A347 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A349;
L_80A349:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA349u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA349u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA349u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A349 DEC
    cpu.decReg('A');
    goto L_80A34A;
L_80A34A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA34Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA34Au,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xA34Au, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $80A34A MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_80A34D;
L_80A34D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA34Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA34Du,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA34Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A34D PLB
    cpu.pop("PLB", hw);
    goto L_80A34E;
L_80A34E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA34Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA34Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA34Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A34E LDA
    cpu.setA(0xAC0Bu, 16);
    goto L_80A351;
L_80A351:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA351u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA351u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA351u, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A351 STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_80A354;
L_80A354:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA354u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA354u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA354u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A354 LDA
    cpu.setA(0x8Bu, 16);
    goto L_80A357;
L_80A357:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA357u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA357u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA357u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A357 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_80A35A;
L_80A35A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA35Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA35Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA35Au, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A35A JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA35Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA35Eu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x80A35Au); }
    goto L_80A35E;
L_80A35E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA35Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA35Eu,0x80A35Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA35Eu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA35Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A35E PHB
    cpu.push("PHB", hw);
    goto L_80A35F;
L_80A35F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA35Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA35Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA35Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A35F LDX
    cpu.setX(0x8000u, 16);
    goto L_80A362;
L_80A362:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA362u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA362u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA362u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A362 LDY
    cpu.setY(0x4000u, 16);
    goto L_80A365;
L_80A365:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA365u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA365u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA365u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A365 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A367;
L_80A367:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA367u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA367u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA367u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A367 DEC
    cpu.decReg('A');
    goto L_80A368;
L_80A368:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA368u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA368u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xA368u, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $80A368 MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_80A36B;
L_80A36B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA36Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Bu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A36B PLB
    cpu.pop("PLB", hw);
    goto L_80A36C;
L_80A36C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA36Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A36C LDA
    cpu.setA(0x87C9u, 16);
    goto L_80A36F;
L_80A36F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA36Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA36Fu, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A36F STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_80A372;
L_80A372:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA372u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA372u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA372u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A372 LDA
    cpu.setA(0x89u, 16);
    goto L_80A375;
L_80A375:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA375u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA375u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA375u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A375 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_80A378;
L_80A378:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA378u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA378u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA378u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A378 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA37Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA37Cu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x80A378u); }
    goto L_80A37C;
L_80A37C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA37Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA37Cu,0x80A37Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Cu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A37C PHB
    cpu.push("PHB", hw);
    goto L_80A37D;
L_80A37D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA37Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA37Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A37D LDX
    cpu.setX(0x8000u, 16);
    goto L_80A380;
L_80A380:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA380u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA380u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA380u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A380 LDY
    cpu.setY(0x6000u, 16);
    goto L_80A383;
L_80A383:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA383u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA383u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA383u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A383 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A385;
L_80A385:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA385u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA385u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA385u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A385 DEC
    cpu.decReg('A');
    goto L_80A386;
L_80A386:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA386u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA386u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xA386u, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $80A386 MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_80A389;
L_80A389:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA389u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA389u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA389u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A389 PLB
    cpu.pop("PLB", hw);
    goto L_80A38A;
L_80A38A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA38Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A38A LDA
    cpu.setA(0xFFFFu, 16);
    goto L_80A38D;
L_80A38D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA38Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA38Du, 8u, 4u, 0x80A460u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A38D JSL -> $80A460 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA390u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA391u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A460u, 0x80A38Du); }
    goto L_80A391;
L_80A391:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA391u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA391u,0x80A391u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA391u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA391u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A391 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80A391u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80A391u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80BF67_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80BF67u: goto L_80BF67;
    case 0x80BF6Au: goto L_80BF6A;
    case 0x80BF6Cu: goto L_80BF6C;
    case 0x80BF6Du: goto L_80BF6D;
    case 0x80BF70u: goto L_80BF70;
    case 0x80BF73u: goto L_80BF73;
    case 0x80BF76u: goto L_80BF76;
    case 0x80BF79u: goto L_80BF79;
    case 0x80BF7Cu: goto L_80BF7C;
    case 0x80BF7Fu: goto L_80BF7F;
    case 0x80BF82u: goto L_80BF82;
    case 0x80BF85u: goto L_80BF85;
    case 0x80BF88u: goto L_80BF88;
    case 0x80BF8Bu: goto L_80BF8B;
    case 0x80BF8Eu: goto L_80BF8E;
    case 0x80BF90u: goto L_80BF90;
    case 0x80BF92u: goto L_80BF92;
    case 0x80BF95u: goto L_80BF95;
    case 0x80BF97u: goto L_80BF97;
    case 0x80BF9Au: goto L_80BF9A;
    case 0x80BF9Cu: goto L_80BF9C;
    case 0x80BF9Du: goto L_80BF9D;
    case 0x80BFA0u: goto L_80BFA0;
    case 0x80BFA3u: goto L_80BFA3;
    case 0x80BFA6u: goto L_80BFA6;
    case 0x80BFA8u: goto L_80BFA8;
    case 0x80BFA9u: goto L_80BFA9;
    case 0x80BFAAu: goto L_80BFAA;
    case 0x80BFABu: goto L_80BFAB;
    case 0x80BFACu: goto L_80BFAC;
    case 0x80BFAEu: goto L_80BFAE;
    case 0x80BFB1u: goto L_80BFB1;
    case 0x80BFB4u: goto L_80BFB4;
    case 0x80BFB7u: goto L_80BFB7;
    case 0x80BFBAu: goto L_80BFBA;
    case 0x80BFBDu: goto L_80BFBD;
    case 0x80BFBFu: goto L_80BFBF;
    case 0x80BFC3u: goto L_80BFC3;
    case 0x80BFC5u: goto L_80BFC5;
    case 0x80BFC6u: goto L_80BFC6;
    case 0x80BFC7u: goto L_80BFC7;
    case 0x80BFC9u: goto L_80BFC9;
    case 0x80BFCBu: goto L_80BFCB;
    case 0x80BFCEu: goto L_80BFCE;
    case 0x80BFD1u: goto L_80BFD1;
    case 0x80BFD4u: goto L_80BFD4;
    case 0x80BFD6u: goto L_80BFD6;
    case 0x80BFDAu: goto L_80BFDA;
    case 0x80BFDCu: goto L_80BFDC;
    case 0x80BFDDu: goto L_80BFDD;
    case 0x80BFDEu: goto L_80BFDE;
    case 0x80BFE0u: goto L_80BFE0;
    case 0x80BFE2u: goto L_80BFE2;
    case 0x80BFE5u: goto L_80BFE5;
    case 0x80BFE8u: goto L_80BFE8;
    case 0x80BFEBu: goto L_80BFEB;
    case 0x80BFEDu: goto L_80BFED;
    case 0x80BFF1u: goto L_80BFF1;
    case 0x80BFF3u: goto L_80BFF3;
    case 0x80BFF4u: goto L_80BFF4;
    case 0x80BFF5u: goto L_80BFF5;
    case 0x80BFF7u: goto L_80BFF7;
    case 0x80BFF9u: goto L_80BFF9;
    case 0x80BFFCu: goto L_80BFFC;
    case 0x80BFFFu: goto L_80BFFF;
    case 0x80C002u: goto L_80C002;
    case 0x80C004u: goto L_80C004;
    case 0x80C007u: goto L_80C007;
    case 0x80C00Au: goto L_80C00A;
    case 0x80C00Cu: goto L_80C00C;
    case 0x80C00Fu: goto L_80C00F;
    case 0x80C011u: goto L_80C011;
    case 0x80C013u: goto L_80C013;
    case 0x80C016u: goto L_80C016;
    case 0x80C019u: goto L_80C019;
    case 0x80C01Bu: goto L_80C01B;
    case 0x80C01Eu: goto L_80C01E;
    case 0x80C021u: goto L_80C021;
    case 0x80C023u: goto L_80C023;
    case 0x80C026u: goto L_80C026;
    case 0x80C029u: goto L_80C029;
    case 0x80C02Bu: goto L_80C02B;
    case 0x80C02Eu: goto L_80C02E;
    case 0x80C031u: goto L_80C031;
    case 0x80C034u: goto L_80C034;
    case 0x80C036u: goto L_80C036;
    case 0x80C038u: goto L_80C038;
    case 0x80C03Au: goto L_80C03A;
    case 0x80C03Du: goto L_80C03D;
    case 0x80C040u: goto L_80C040;
    case 0x80C042u: goto L_80C042;
    case 0x80C045u: goto L_80C045;
    case 0x80C048u: goto L_80C048;
    case 0x80C04Au: goto L_80C04A;
    case 0x80C04Du: goto L_80C04D;
    case 0x80C050u: goto L_80C050;
    case 0x80C052u: goto L_80C052;
    case 0x80C054u: goto L_80C054;
    case 0x80C057u: goto L_80C057;
    case 0x80C05Au: goto L_80C05A;
    case 0x80C05Du: goto L_80C05D;
    case 0x80C060u: goto L_80C060;
    case 0x80C063u: goto L_80C063;
    case 0x80C064u: goto L_80C064;
    case 0x80C065u: goto L_80C065;
    case 0x80C066u: goto L_80C066;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80BF67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF67u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF67u, 6u, 3u, cpu.address("abs", 0xC067u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BF67 JSR -> $80C067 stack real
    { cpu.push16Value(hw,0xBF69u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBF6Au,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC067u), 0x80BF67u); }
    goto L_80BF6A;
L_80BF6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF6Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF6Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF6Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF6A BCC -> $80BF6D
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80BF6D; }
    goto L_80BF6C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF6Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF6Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF6A BCC -> $80BF6D
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80BF6D; }
    goto L_80BF6C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF6Au,0x80BF6Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BF6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF6Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF6Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF6Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BF6C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80BF6Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80BF6Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF6Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF6Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BF6C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80BF6Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80BF6Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF6Cu,0x80BF6Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BF6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF6Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF6Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF6Du, 5u, 3u, cpu.address("abs", 0x094Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF6D STZ
    hw.write(cpu.address("abs", 0x94Au), 0, cpu.m8?8:16);
    goto L_80BF70;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF6Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF6Du, 5u, 3u, cpu.address("abs", 0x094Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF6D STZ
    hw.write(cpu.address("abs", 0x94Au), 0, cpu.m8?8:16);
    goto L_80BF70;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF6Du,0x80BF6Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BF70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF70u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF70u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF70u, 5u, 3u, cpu.address("abs", 0x0948u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF70 STZ
    hw.write(cpu.address("abs", 0x948u), 0, cpu.m8?8:16);
    goto L_80BF73;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF70u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF70u, 5u, 3u, cpu.address("abs", 0x0948u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF70 STZ
    hw.write(cpu.address("abs", 0x948u), 0, cpu.m8?8:16);
    goto L_80BF73;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF70u,0x80BF70u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BF73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF73u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF73u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF73u, 5u, 3u, cpu.address("abs", 0x0994u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF73 STZ
    hw.write(cpu.address("abs", 0x994u), 0, cpu.m8?8:16);
    goto L_80BF76;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF73u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF73u, 5u, 3u, cpu.address("abs", 0x0994u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF73 STZ
    hw.write(cpu.address("abs", 0x994u), 0, cpu.m8?8:16);
    goto L_80BF76;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF73u,0x80BF73u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BF76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF76u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF76u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF76u, 5u, 3u, cpu.address("abs", 0x0996u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF76 STZ
    hw.write(cpu.address("abs", 0x996u), 0, cpu.m8?8:16);
    goto L_80BF79;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF76u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF76u, 5u, 3u, cpu.address("abs", 0x0996u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF76 STZ
    hw.write(cpu.address("abs", 0x996u), 0, cpu.m8?8:16);
    goto L_80BF79;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF76u,0x80BF76u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BF79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF79u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF79u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF79u, 5u, 3u, cpu.address("abs", 0x0968u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF79 STZ
    hw.write(cpu.address("abs", 0x968u), 0, cpu.m8?8:16);
    goto L_80BF7C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF79u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF79u, 5u, 3u, cpu.address("abs", 0x0968u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF79 STZ
    hw.write(cpu.address("abs", 0x968u), 0, cpu.m8?8:16);
    goto L_80BF7C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF79u,0x80BF79u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BF7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF7Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF7Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF7Cu, 5u, 3u, cpu.address("abs", 0x096Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF7C STZ
    hw.write(cpu.address("abs", 0x96Au), 0, cpu.m8?8:16);
    goto L_80BF7F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF7Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF7Cu, 5u, 3u, cpu.address("abs", 0x096Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF7C STZ
    hw.write(cpu.address("abs", 0x96Au), 0, cpu.m8?8:16);
    goto L_80BF7F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF7Cu,0x80BF7Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BF7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF7Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF7Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF7Fu, 5u, 3u, cpu.address("abs", 0x09A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF7F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x9A2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BF82;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF7Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF7Fu, 5u, 3u, cpu.address("abs", 0x09A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF7F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x9A2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BF82;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF7Fu,0x80BF7Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BF82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF82u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF82u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF82u, 5u, 3u, cpu.address("abs", 0x095Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF82 STA
    hw.write(cpu.address("abs", 0x95Cu), cpu.a, cpu.m8?8:16);
    goto L_80BF85;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF82u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF82u, 5u, 3u, cpu.address("abs", 0x095Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF82 STA
    hw.write(cpu.address("abs", 0x95Cu), cpu.a, cpu.m8?8:16);
    goto L_80BF85;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF82u,0x80BF82u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BF85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF85u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF85u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF85u, 5u, 3u, cpu.address("abs", 0x0972u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF85 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x972u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BF88;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF85u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF85u, 5u, 3u, cpu.address("abs", 0x0972u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF85 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x972u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BF88;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF85u,0x80BF85u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BF88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF88u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF88u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF88u, 5u, 3u, cpu.address("abs", 0x095Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF88 STA
    hw.write(cpu.address("abs", 0x95Eu), cpu.a, cpu.m8?8:16);
    goto L_80BF8B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF88u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF88u, 5u, 3u, cpu.address("abs", 0x095Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF88 STA
    hw.write(cpu.address("abs", 0x95Eu), cpu.a, cpu.m8?8:16);
    goto L_80BF8B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF88u,0x80BF88u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BF8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF8Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF8Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF8Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF8B LDX
    cpu.setX(0x0u, 16);
    goto L_80BF8E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF8Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF8Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF8B LDX
    cpu.setX(0x0u, 16);
    goto L_80BF8E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF8Bu,0x80BF8Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BF8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF8Eu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF8Eu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF8Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF8E LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xB2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BF90;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF8Eu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF8Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF8E LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xB2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BF90;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF8Eu,0x80BF8Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BF90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF90u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF90u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF90u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xAEu) & 0xFFFFu), 2u, 0u);
    // $80BF90 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0xAEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BF92;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF90u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF90u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xAEu) & 0xFFFFu), 2u, 0u);
    // $80BF90 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0xAEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BF92;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF90u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF90u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xAEu) & 0xFFFFu), 2u, 0u);
    // $80BF90 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0xAEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BF92;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF90u,0x80BF90u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BF92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF92u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF92u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF92u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF92 CMP
    cpu.compareA(0xFFFFu);
    goto L_80BF95;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF92u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF92u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF92 CMP
    cpu.compareA(0xFFFFu);
    goto L_80BF95;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF92u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF92u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF92 CMP
    cpu.compareA(0xFFFFu);
    goto L_80BF95;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF92u,0x80BF92u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BF95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF95u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF95u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF95 BNE -> $80BF9C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BF9C; }
    goto L_80BF97;
L_80BF97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF97u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF97u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF97 LDA
    cpu.setA(0xFF00u, 16);
    goto L_80BF9A;
L_80BF9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF9Au,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF9Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF9A BRA -> $80BFA0
    goto L_80BFA0;
L_80BF9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF9Cu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF9Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF9C CLC
    cpu.setFlag('C', false);
    goto L_80BF9D;
L_80BF9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF9Du,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF9Du, 5u, 3u, cpu.address("abs", 0x096Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BF9D ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x96Cu), cpu.m8?8:16));
    goto L_80BFA0;
L_80BFA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA0u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA0u, 6u, 3u, cpu.address("absx", 0x0960u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFA0 STA
    hw.write(cpu.address("absx", 0x960u), cpu.a, cpu.m8?8:16);
    goto L_80BFA3;
L_80BFA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA3u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFA3 CPX
    cpu.compareX(0x6u);
    goto L_80BFA6;
L_80BFA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFA6 BEQ -> $80BFAE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BFAE; }
    goto L_80BFA8;
L_80BFA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA8u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFA8 INX
    cpu.inc('X');
    goto L_80BFA9;
L_80BFA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA9u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFA9 INX
    cpu.inc('X');
    goto L_80BFAA;
L_80BFAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFAAu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFAAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFAA INY
    cpu.inc('Y');
    goto L_80BFAB;
L_80BFAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFABu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFABu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFAB INY
    cpu.inc('Y');
    goto L_80BFAC;
L_80BFAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFACu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFACu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFAC BRA -> $80BF90
    goto L_80BF90;
L_80BFAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFAEu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFAEu, 5u, 3u, cpu.address("abs", 0x0946u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFAE STZ
    hw.write(cpu.address("abs", 0x946u), 0, cpu.m8?8:16);
    goto L_80BFB1;
L_80BFB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFB1u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFB1u, 5u, 3u, cpu.address("abs", 0x0942u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFB1 STZ
    hw.write(cpu.address("abs", 0x942u), 0, cpu.m8?8:16);
    goto L_80BFB4;
L_80BFB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFB4u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFB4u, 5u, 3u, cpu.address("abs", 0x0944u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFB4 STZ
    hw.write(cpu.address("abs", 0x944u), 0, cpu.m8?8:16);
    goto L_80BFB7;
L_80BFB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFB7u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFB7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFB7 LDY
    cpu.setY(0x6u, 16);
    goto L_80BFBA;
L_80BFBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFBAu,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFBAu, 5u + 1u, 3u, cpu.address("absy", 0x0960u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFBA LDX
    cpu.setX(hw.readW(cpu.address("absy", 0x960u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BFBD;
L_80BFBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFBDu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFBDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFBD BMI -> $80BFC5
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BFC5; }
    goto L_80BFBF;
L_80BFBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFBFu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFBFu, 6u, 4u, ((0x7E2002u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFBF LDA
    cpu.loadA(hw.readW(((0x7E2002u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BFC3;
L_80BFC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFC3 BNE -> $80BFCB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BFCB; }
    goto L_80BFC5;
L_80BFC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC5u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFC5 DEY
    cpu.decReg('Y');
    goto L_80BFC6;
L_80BFC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC6u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFC6 DEY
    cpu.decReg('Y');
    goto L_80BFC7;
L_80BFC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC7u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFC7 BPL -> $80BFBA
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BFBA; }
    goto L_80BFC9;
L_80BFC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC9u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFC9 BRA -> $80BFCE
    goto L_80BFCE;
L_80BFCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFCBu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFCBu, 8u, 3u, cpu.address("abs", 0x0942u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFCB INC
    cpu.incMem(hw, cpu.address("abs", 0x942u), cpu.m8?8:16);
    goto L_80BFCE;
L_80BFCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFCEu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFCEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFCE LDY
    cpu.setY(0x6u, 16);
    goto L_80BFD1;
L_80BFD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD1u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD1u, 5u + 1u, 3u, cpu.address("absy", 0x0960u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFD1 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0x960u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BFD4;
L_80BFD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD4u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFD4 BMI -> $80BFDC
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BFDC; }
    goto L_80BFD6;
L_80BFD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD6u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD6u, 6u, 4u, ((0x7E1FFEu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFD6 LDA
    cpu.loadA(hw.readW(((0x7E1FFEu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BFDA;
L_80BFDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFDAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFDAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFDA BNE -> $80BFE2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BFE2; }
    goto L_80BFDC;
L_80BFDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFDCu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFDCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFDC DEY
    cpu.decReg('Y');
    goto L_80BFDD;
L_80BFDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFDDu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFDDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFDD DEY
    cpu.decReg('Y');
    goto L_80BFDE;
L_80BFDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFDEu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFDEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFDE BPL -> $80BFD1
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BFD1; }
    goto L_80BFE0;
L_80BFE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFE0u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFE0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFE0 BRA -> $80BFE5
    goto L_80BFE5;
L_80BFE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFE2u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFE2u, 8u, 3u, cpu.address("abs", 0x0944u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFE2 INC
    cpu.incMem(hw, cpu.address("abs", 0x944u), cpu.m8?8:16);
    goto L_80BFE5;
L_80BFE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFE5u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFE5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFE5 LDY
    cpu.setY(0x6u, 16);
    goto L_80BFE8;
L_80BFE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFE8u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFE8u, 5u + 1u, 3u, cpu.address("absy", 0x0960u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFE8 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0x960u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BFEB;
L_80BFEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFEBu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFEBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFEB BMI -> $80BFF3
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BFF3; }
    goto L_80BFED;
L_80BFED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFEDu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFEDu, 6u, 4u, ((0x7E2016u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFED LDA
    cpu.loadA(hw.readW(((0x7E2016u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BFF1;
L_80BFF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFF1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFF1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFF1 BNE -> $80BFF9
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BFF9; }
    goto L_80BFF3;
L_80BFF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFF3u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFF3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFF3 DEY
    cpu.decReg('Y');
    goto L_80BFF4;
L_80BFF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFF4u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFF4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFF4 DEY
    cpu.decReg('Y');
    goto L_80BFF5;
L_80BFF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFF5u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFF5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFF5 BPL -> $80BFE8
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BFE8; }
    goto L_80BFF7;
L_80BFF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFF7u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFF7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFF7 BRA -> $80BFFC
    goto L_80BFFC;
L_80BFF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFF9u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFF9u, 8u, 3u, cpu.address("abs", 0x0946u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFF9 INC
    cpu.incMem(hw, cpu.address("abs", 0x946u), cpu.m8?8:16);
    goto L_80BFFC;
L_80BFFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFFCu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFFCu, 5u, 3u, cpu.address("abs", 0x095Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFFC LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x95Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BFFF;
L_80BFFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFFFu,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFFFu, 5u, 3u, cpu.address("abs", 0x091Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BFFF CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x91Au), cpu.m8?8:16));
    goto L_80C002;
L_80C002:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC002u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC002u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC002u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C002 BEQ -> $80C02B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C02B; }
    goto L_80C004;
L_80C004:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC004u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC004u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC004u, 5u, 3u, cpu.address("abs", 0x0994u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C004 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x994u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C007;
L_80C007:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC007u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC007u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC007u, 5u, 3u, cpu.address("abs", 0x0996u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C007 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x996u), cpu.m8?8:16));
    goto L_80C00A;
L_80C00A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC00Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC00Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC00Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C00A BEQ -> $80C013
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C013; }
    goto L_80C00C;
L_80C00C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC00Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC00Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC00Cu, 5u, 3u, cpu.address("abs", 0x0994u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C00C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x994u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C00F;
L_80C00F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC00Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC00Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC00Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C00F BEQ -> $80C023
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C023; }
    goto L_80C011;
L_80C011:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC011u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC011u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC011u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C011 BRA -> $80C01B
    goto L_80C01B;
L_80C013:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC013u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC013u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC013u, 5u, 3u, cpu.address("abs", 0x095Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C013 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x95Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C016;
L_80C016:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC016u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC016u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC016u, 5u, 3u, cpu.address("abs", 0x091Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C016 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x91Au), cpu.m8?8:16));
    goto L_80C019;
L_80C019:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC019u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC019u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC019u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C019 BCS -> $80C023
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C023; }
    goto L_80C01B;
L_80C01B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC01Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC01Bu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC01Bu, 8u, 3u, cpu.address("abs", 0x0994u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C01B INC
    cpu.incMem(hw, cpu.address("abs", 0x994u), cpu.m8?8:16);
    goto L_80C01E;
L_80C01E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC01Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC01Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC01Eu, 6u, 3u, cpu.address("abs", 0xC0A7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C01E JSR -> $80C0A7 stack real
    { cpu.push16Value(hw,0xC020u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC021u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC0A7u), 0x80C01Eu); }
    goto L_80C021;
L_80C021:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC021u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC021u,0x80C021u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC021u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC021u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C021 BRA -> $80C02E
    goto L_80C02E;
L_80C023:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC023u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC023u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC023u, 8u, 3u, cpu.address("abs", 0x0996u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C023 INC
    cpu.incMem(hw, cpu.address("abs", 0x996u), cpu.m8?8:16);
    goto L_80C026;
L_80C026:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC026u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC026u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC026u, 6u, 3u, cpu.address("abs", 0xC152u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C026 JSR -> $80C152 stack real
    { cpu.push16Value(hw,0xC028u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC029u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC152u), 0x80C026u); }
    goto L_80C029;
L_80C029:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC029u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC029u,0x80C029u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC029u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC029u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C029 BRA -> $80C02E
    goto L_80C02E;
L_80C02B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC02Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC02Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC02Bu, 6u, 3u, cpu.address("abs", 0xC1FDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C02B JSR -> $80C1FD stack real
    { cpu.push16Value(hw,0xC02Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC02Eu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC1FDu), 0x80C02Bu); }
    goto L_80C02E;
L_80C02E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC02Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC02Eu,0x80C02Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC02Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC02Eu, 5u, 3u, cpu.address("abs", 0x095Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C02E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x95Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C031;
L_80C031:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC031u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC031u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC031u, 5u, 3u, cpu.address("abs", 0x091Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C031 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x91Cu), cpu.m8?8:16));
    goto L_80C034;
L_80C034:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC034u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC034u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC034u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C034 BEQ -> $80C03A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C03A; }
    goto L_80C036;
L_80C036:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC036u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC036u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC036u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C036 BCS -> $80C063
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C063; }
    goto L_80C038;
L_80C038:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC038u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC038u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC038u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C038 BRA -> $80C042
    goto L_80C042;
L_80C03A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC03Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC03Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC03Au, 5u, 3u, cpu.address("abs", 0x095Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C03A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x95Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C03D;
L_80C03D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC03Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC03Du,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC03Du, 5u, 3u, cpu.address("abs", 0x091Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C03D CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x91Au), cpu.m8?8:16));
    goto L_80C040;
L_80C040:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC040u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC040u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC040u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C040 BEQ -> $80C065
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C065; }
    goto L_80C042;
L_80C042:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC042u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC042u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC042u, 5u, 3u, cpu.address("abs", 0x0968u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C042 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x968u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C045;
L_80C045:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC045u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC045u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC045u, 5u, 3u, cpu.address("abs", 0x095Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C045 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x95Cu), cpu.m8?8:16));
    goto L_80C048;
L_80C048:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC048u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC048u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC048u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C048 BNE -> $80C054
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C054; }
    goto L_80C04A;
L_80C04A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC04Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC04Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC04Au, 5u, 3u, cpu.address("abs", 0x096Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C04A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x96Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C04D;
L_80C04D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC04Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC04Du,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC04Du, 5u, 3u, cpu.address("abs", 0x095Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C04D CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x95Eu), cpu.m8?8:16));
    goto L_80C050;
L_80C050:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC050u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC050u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC050u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C050 BNE -> $80C054
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C054; }
    goto L_80C052;
L_80C052:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC052u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC052u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC052u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C052 BRA -> $80C063
    goto L_80C063;
L_80C054:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC054u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC054u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC054u, 5u, 3u, cpu.address("abs", 0x095Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C054 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x95Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C057;
L_80C057:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC057u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC057u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC057u, 5u, 3u, cpu.address("abs", 0x0968u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C057 STA
    hw.write(cpu.address("abs", 0x968u), cpu.a, cpu.m8?8:16);
    goto L_80C05A;
L_80C05A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC05Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC05Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC05Au, 5u, 3u, cpu.address("abs", 0x095Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C05A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x95Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C05D;
L_80C05D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC05Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC05Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC05Du, 5u, 3u, cpu.address("abs", 0x096Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C05D STA
    hw.write(cpu.address("abs", 0x96Au), cpu.a, cpu.m8?8:16);
    goto L_80C060;
L_80C060:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC060u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC060u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC060u, 3u, 3u, cpu.address("abs", 0xBFAEu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C060 JMP -> $80BFAE
    goto L_80BFAE;
L_80C063:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC063u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC063u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC063u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C063 SEC
    cpu.setFlag('C', true);
    goto L_80C064;
L_80C064:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC064u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC064u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC064u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C064 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80C064u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80C064u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80C065:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC065u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC065u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC065u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C065 CLC
    cpu.setFlag('C', false);
    goto L_80C066;
L_80C066:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC066u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC066u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC066u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C066 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80C066u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80C066u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_829272_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829272u: goto L_829272;
    case 0x829275u: goto L_829275;
    case 0x829278u: goto L_829278;
    case 0x829279u: goto L_829279;
    case 0x82927Au: goto L_82927A;
    case 0x82927Du: goto L_82927D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829272:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9272u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9272u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9272u, 5u, 3u, cpu.address("abs", 0x0141u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829272 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x141u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829275;
L_829275:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9275u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9275u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9275u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829275 AND
    cpu.logicAnd(0xFFu);
    goto L_829278;
L_829278:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9278u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9278u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9278u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829278 ASL
    cpu.aslA();
    goto L_829279;
L_829279:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9279u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9279u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9279u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829279 TAX
    cpu.transfer("TAX");
    goto L_82927A;
L_82927A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x927Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x927Au,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x927Au, 5u, 3u, cpu.address("abs", 0x927Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82927A PEA
    cpu.push16Value(hw, 0x927Fu);
    goto L_82927D;
L_82927D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x927Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x927Du,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x927Du, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x9283u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $82927D JMP (9283,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x9283u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x82927Du); return; }
}

void sub_829272_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829272u: goto L_829272;
    case 0x829275u: goto L_829275;
    case 0x829278u: goto L_829278;
    case 0x829279u: goto L_829279;
    case 0x82927Au: goto L_82927A;
    case 0x82927Du: goto L_82927D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829272:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9272u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9272u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9272u, 5u, 3u, cpu.address("abs", 0x0141u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829272 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x141u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829275;
L_829275:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9275u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9275u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9275u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829275 AND
    cpu.logicAnd(0xFFu);
    goto L_829278;
L_829278:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9278u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9278u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9278u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829278 ASL
    cpu.aslA();
    goto L_829279;
L_829279:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9279u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9279u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9279u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829279 TAX
    cpu.transfer("TAX");
    goto L_82927A;
L_82927A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x927Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x927Au,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x927Au, 5u, 3u, cpu.address("abs", 0x927Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82927A PEA
    cpu.push16Value(hw, 0x927Fu);
    goto L_82927D;
L_82927D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x927Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x927Du,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x927Du, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x9283u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $82927D JMP (9283,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x9283u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x82927Du); return; }
}

void sub_829483_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829483u: goto L_829483;
    case 0x829486u: goto L_829486;
    case 0x829488u: goto L_829488;
    case 0x82948Bu: goto L_82948B;
    case 0x82948Du: goto L_82948D;
    case 0x82948Fu: goto L_82948F;
    case 0x829492u: goto L_829492;
    case 0x829494u: goto L_829494;
    case 0x829496u: goto L_829496;
    case 0x829499u: goto L_829499;
    case 0x82949Cu: goto L_82949C;
    case 0x82949Eu: goto L_82949E;
    case 0x8294A1u: goto L_8294A1;
    case 0x8294A3u: goto L_8294A3;
    case 0x8294A6u: goto L_8294A6;
    case 0x8294A8u: goto L_8294A8;
    case 0x8294A9u: goto L_8294A9;
    case 0x8294AAu: goto L_8294AA;
    case 0x8294ABu: goto L_8294AB;
    case 0x8294ADu: goto L_8294AD;
    case 0x8294AFu: goto L_8294AF;
    case 0x8294B1u: goto L_8294B1;
    case 0x8294B4u: goto L_8294B4;
    case 0x8294B6u: goto L_8294B6;
    case 0x8294BAu: goto L_8294BA;
    case 0x8294BDu: goto L_8294BD;
    case 0x8294BFu: goto L_8294BF;
    case 0x8294C0u: goto L_8294C0;
    case 0x8294C2u: goto L_8294C2;
    case 0x8294C5u: goto L_8294C5;
    case 0x8294C8u: goto L_8294C8;
    case 0x8294CBu: goto L_8294CB;
    case 0x8294CEu: goto L_8294CE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829483:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9483u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9483u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9483u, 5u, 3u, cpu.address("abs", 0x0222u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829483 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x222u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829486;
L_829486:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9486u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9486u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9486u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829486 BNE -> $82948F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82948F; }
    goto L_829488;
L_829488:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9488u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9488u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9488u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829488 LDA
    cpu.setA(0x208u, 16);
    goto L_82948B;
L_82948B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x948Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x948Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x948Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82948B STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82948D;
L_82948D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x948Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x948Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x948Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82948D BRA -> $829494
    goto L_829494;
L_82948F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x948Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x948Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x948Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82948F LDA
    cpu.setA(0x224u, 16);
    goto L_829492;
L_829492:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9492u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9492u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9492u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829492 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_829494;
L_829494:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9494u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9494u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9494u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829494 STZ
    hw.write(cpu.address("dp", 0x2u), 0, cpu.m8?8:16);
    goto L_829496;
L_829496:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9496u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9496u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9496u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829496 LDY
    cpu.setY(0x6u, 16);
    goto L_829499;
L_829499:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9499u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9499u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9499u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829499 LDX
    cpu.setX(0x3u, 16);
    goto L_82949C;
L_82949C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x949Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x949Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x949Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82949C SEP
    cpu.sep(0x20u);
    goto L_82949E;
L_82949E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x949Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x949Eu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x949Eu, 4u + 1u, 3u, cpu.address("absy", 0x0276u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82949E LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x276u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8294A1;
L_8294A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94A1u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94A1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8294A1 STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_8294A3;
L_8294A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94A3u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94A3u, 4u + 1u, 3u, cpu.address("absy", 0x027Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8294A3 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x27Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8294A6;
L_8294A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94A6u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94A6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8294A6 STA
    hw.write(cpu.address("dpx", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_8294A8;
L_8294A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94A8u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94A8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8294A8 DEY
    cpu.decReg('Y');
    goto L_8294A9;
L_8294A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94A9u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94A9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8294A9 DEY
    cpu.decReg('Y');
    goto L_8294AA;
L_8294AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94AAu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94AAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8294AA DEX
    cpu.decReg('X');
    goto L_8294AB;
L_8294AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94ABu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94ABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8294AB BPL -> $82949E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82949E; }
    goto L_8294AD;
L_8294AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94ADu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94ADu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8294AD REP
    cpu.rep(0x20u);
    goto L_8294AF;
L_8294AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94AFu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94AFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8294AF STZ
    hw.write(cpu.address("dp", 0xEu), 0, cpu.m8?8:16);
    goto L_8294B1;
L_8294B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94B1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94B1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8294B1 LDA
    cpu.setA(0x0u, 16);
    goto L_8294B4;
L_8294B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94B4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94B4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8294B4 STA
    hw.write(cpu.address("dp", 0x5Bu), cpu.a, cpu.m8?8:16);
    goto L_8294B6;
L_8294B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94B6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94B6u, 8u, 4u, 0x808915u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8294B6 JSL -> $808915 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x94B9u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x94BAu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808915u, 0x8294B6u); }
    goto L_8294BA;
L_8294BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94BAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x94BAu,0x8294BAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94BAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94BAu, 5u, 3u, cpu.address("abs", 0x0222u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8294BA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x222u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8294BD;
L_8294BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94BDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94BDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8294BD BNE -> $8294C0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8294C0; }
    goto L_8294BF;
L_8294BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94BFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94BFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8294BF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8294BFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8294BFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_8294C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94C0u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94C0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8294C0 BMI -> $8294CB
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_8294CB; }
    goto L_8294C2;
L_8294C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94C2u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94C2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8294C2 LDX
    cpu.setX(0x0u, 16);
    goto L_8294C5;
L_8294C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94C5u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94C5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8294C5 LDY
    cpu.setY(0x0u, 16);
    goto L_8294C8;
L_8294C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94C8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94C8u, 6u, 3u, cpu.address("abs", 0xA1CFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8294C8 JSR -> $82A1CF stack real
    { cpu.push16Value(hw,0x94CAu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x94CBu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA1CFu), 0x8294C8u); }
    goto L_8294CB;
L_8294CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94CBu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94CBu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94CBu, 5u, 3u, cpu.address("abs", 0x0222u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8294CB STZ
    hw.write(cpu.address("abs", 0x222u), 0, cpu.m8?8:16);
    goto L_8294CE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94CBu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94CBu, 5u, 3u, cpu.address("abs", 0x0222u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8294CB STZ
    hw.write(cpu.address("abs", 0x222u), 0, cpu.m8?8:16);
    goto L_8294CE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x94CBu,0x8294CBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8294CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94CEu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94CEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94CEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8294CE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8294CEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8294CEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94CEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94CEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8294CE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8294CEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8294CEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x94CEu,0x8294CEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_829483_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829483u: goto L_829483;
    case 0x829486u: goto L_829486;
    case 0x829488u: goto L_829488;
    case 0x82948Bu: goto L_82948B;
    case 0x82948Du: goto L_82948D;
    case 0x82948Fu: goto L_82948F;
    case 0x829492u: goto L_829492;
    case 0x829494u: goto L_829494;
    case 0x829496u: goto L_829496;
    case 0x829499u: goto L_829499;
    case 0x82949Cu: goto L_82949C;
    case 0x82949Eu: goto L_82949E;
    case 0x8294A1u: goto L_8294A1;
    case 0x8294A3u: goto L_8294A3;
    case 0x8294A6u: goto L_8294A6;
    case 0x8294A8u: goto L_8294A8;
    case 0x8294A9u: goto L_8294A9;
    case 0x8294AAu: goto L_8294AA;
    case 0x8294ABu: goto L_8294AB;
    case 0x8294ADu: goto L_8294AD;
    case 0x8294AFu: goto L_8294AF;
    case 0x8294B1u: goto L_8294B1;
    case 0x8294B4u: goto L_8294B4;
    case 0x8294B6u: goto L_8294B6;
    case 0x8294BAu: goto L_8294BA;
    case 0x8294BDu: goto L_8294BD;
    case 0x8294BFu: goto L_8294BF;
    case 0x8294C0u: goto L_8294C0;
    case 0x8294C2u: goto L_8294C2;
    case 0x8294C5u: goto L_8294C5;
    case 0x8294C8u: goto L_8294C8;
    case 0x8294CBu: goto L_8294CB;
    case 0x8294CEu: goto L_8294CE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829483:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9483u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9483u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9483u, 5u, 3u, cpu.address("abs", 0x0222u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829483 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x222u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829486;
L_829486:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9486u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9486u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9486u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829486 BNE -> $82948F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82948F; }
    goto L_829488;
L_829488:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9488u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9488u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9488u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829488 LDA
    cpu.setA(0x208u, 16);
    goto L_82948B;
L_82948B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x948Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x948Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x948Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82948B STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82948D;
L_82948D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x948Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x948Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x948Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82948D BRA -> $829494
    goto L_829494;
L_82948F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x948Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x948Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x948Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82948F LDA
    cpu.setA(0x224u, 16);
    goto L_829492;
L_829492:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9492u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9492u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9492u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829492 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_829494;
L_829494:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9494u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9494u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9494u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829494 STZ
    hw.write(cpu.address("dp", 0x2u), 0, cpu.m8?8:16);
    goto L_829496;
L_829496:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9496u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9496u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9496u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829496 LDY
    cpu.setY(0x6u, 16);
    goto L_829499;
L_829499:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9499u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9499u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9499u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829499 LDX
    cpu.setX(0x3u, 16);
    goto L_82949C;
L_82949C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x949Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x949Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x949Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82949C SEP
    cpu.sep(0x20u);
    goto L_82949E;
L_82949E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x949Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x949Eu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x949Eu, 4u + 1u, 3u, cpu.address("absy", 0x0276u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82949E LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x276u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8294A1;
L_8294A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94A1u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94A1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8294A1 STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_8294A3;
L_8294A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94A3u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94A3u, 4u + 1u, 3u, cpu.address("absy", 0x027Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8294A3 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x27Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8294A6;
L_8294A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94A6u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94A6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8294A6 STA
    hw.write(cpu.address("dpx", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_8294A8;
L_8294A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94A8u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94A8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8294A8 DEY
    cpu.decReg('Y');
    goto L_8294A9;
L_8294A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94A9u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94A9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8294A9 DEY
    cpu.decReg('Y');
    goto L_8294AA;
L_8294AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94AAu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94AAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8294AA DEX
    cpu.decReg('X');
    goto L_8294AB;
L_8294AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94ABu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94ABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8294AB BPL -> $82949E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82949E; }
    goto L_8294AD;
L_8294AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94ADu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94ADu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8294AD REP
    cpu.rep(0x20u);
    goto L_8294AF;
L_8294AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94AFu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94AFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8294AF STZ
    hw.write(cpu.address("dp", 0xEu), 0, cpu.m8?8:16);
    goto L_8294B1;
L_8294B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94B1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94B1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8294B1 LDA
    cpu.setA(0x0u, 16);
    goto L_8294B4;
L_8294B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94B4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94B4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8294B4 STA
    hw.write(cpu.address("dp", 0x5Bu), cpu.a, cpu.m8?8:16);
    goto L_8294B6;
L_8294B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94B6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94B6u, 8u, 4u, 0x808915u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8294B6 JSL -> $808915 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x94B9u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x94BAu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808915u, 0x8294B6u); }
    goto L_8294BA;
L_8294BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94BAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x94BAu,0x8294BAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94BAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94BAu, 5u, 3u, cpu.address("abs", 0x0222u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8294BA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x222u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8294BD;
L_8294BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94BDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94BDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8294BD BNE -> $8294C0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8294C0; }
    goto L_8294BF;
L_8294BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94BFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94BFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8294BF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8294BFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8294BFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_8294C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94C0u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94C0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8294C0 BMI -> $8294CB
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_8294CB; }
    goto L_8294C2;
L_8294C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94C2u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94C2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8294C2 LDX
    cpu.setX(0x0u, 16);
    goto L_8294C5;
L_8294C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94C5u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94C5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8294C5 LDY
    cpu.setY(0x0u, 16);
    goto L_8294C8;
L_8294C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94C8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94C8u, 6u, 3u, cpu.address("abs", 0xA1CFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8294C8 JSR -> $82A1CF stack real
    { cpu.push16Value(hw,0x94CAu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x94CBu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA1CFu), 0x8294C8u); }
    goto L_8294CB;
L_8294CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94CBu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x94CBu,0x8294CBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94CBu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94CBu, 5u, 3u, cpu.address("abs", 0x0222u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8294CB STZ
    hw.write(cpu.address("abs", 0x222u), 0, cpu.m8?8:16);
    goto L_8294CE;
L_8294CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94CEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94CEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8294CE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8294CEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8294CEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_829B56_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829B56u: goto L_829B56;
    case 0x829B58u: goto L_829B58;
    case 0x829B5Bu: goto L_829B5B;
    case 0x829B5Eu: goto L_829B5E;
    case 0x829B61u: goto L_829B61;
    case 0x829B63u: goto L_829B63;
    case 0x829B66u: goto L_829B66;
    case 0x829B68u: goto L_829B68;
    case 0x829B6Bu: goto L_829B6B;
    case 0x829B6Eu: goto L_829B6E;
    case 0x829B6Fu: goto L_829B6F;
    case 0x829B70u: goto L_829B70;
    case 0x829B73u: goto L_829B73;
    case 0x829B83u: goto L_829B83;
    case 0x829B86u: goto L_829B86;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829B56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B56u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B56u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B56 BNE -> $829B83
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829B83; }
    goto L_829B58;
L_829B58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B58u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B58u, 6u, 3u, cpu.address("abs", 0xBF6Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829B58 JSR -> $82BF6E stack real
    { cpu.push16Value(hw,0x9B5Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9B5Bu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBF6Eu), 0x829B58u); }
    goto L_829B5B;
L_829B5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B5Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Bu, 5u, 3u, cpu.address("abs", 0x013Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B5B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829B5E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Bu, 5u, 3u, cpu.address("abs", 0x013Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B5B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829B5E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9B5Bu,0x829B5Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829B5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B5Eu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Eu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Eu, 5u, 3u, cpu.address("abs", 0x0139u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B5E ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x139u), cpu.m8?8:16));
    goto L_829B61;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Eu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Eu, 5u, 3u, cpu.address("abs", 0x0139u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B5E ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x139u), cpu.m8?8:16));
    goto L_829B61;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9B5Eu,0x829B5Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829B61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B61u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B61u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B61u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B61 BNE -> $829B83
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829B83; }
    goto L_829B63;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B61u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B61u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B61 BNE -> $829B83
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829B83; }
    goto L_829B63;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9B61u,0x829B61u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829B63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B63u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B63u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B63u, 6u, 3u, cpu.address("abs", 0xA8DAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829B63 JSR -> $82A8DA stack real
    { cpu.push16Value(hw,0x9B65u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9B66u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA8DAu), 0x829B63u); }
    goto L_829B66;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B63u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B63u, 6u, 3u, cpu.address("abs", 0xA8DAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829B63 JSR -> $82A8DA stack real
    { cpu.push16Value(hw,0x9B65u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9B66u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA8DAu), 0x829B63u); }
    goto L_829B66;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9B63u,0x829B63u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829B66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B66u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9B66u,0x829B66u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B66u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B66u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B66 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829B68;
L_829B68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B68u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B68u, 5u + 1u, 3u, cpu.address("absy", 0x0200u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B68 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x200u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829B6B;
L_829B6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B6Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B6Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B6B AND
    cpu.logicAnd(0xFFu);
    goto L_829B6E;
L_829B6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B6Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B6Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B6E ASL
    cpu.aslA();
    goto L_829B6F;
L_829B6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B6Fu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B6Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B6F TAX
    cpu.transfer("TAX");
    goto L_829B70;
L_829B70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B70u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B70u, 5u, 3u, cpu.address("abs", 0x9B75u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829B70 PEA
    cpu.push16Value(hw, 0x9B75u);
    goto L_829B73;
L_829B73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B73u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B73u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x9B87u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $829B73 JMP (9B87,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x9B87u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x829B73u); return; }
L_829B83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B83u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B83u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B83u, 6u, 3u, cpu.address("abs", 0xBFDEu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829B83 JSR -> $82BFDE stack real
    { cpu.push16Value(hw,0x9B85u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9B86u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBFDEu), 0x829B83u); }
    goto L_829B86;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B83u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B83u, 6u, 3u, cpu.address("abs", 0xBFDEu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829B83 JSR -> $82BFDE stack real
    { cpu.push16Value(hw,0x9B85u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9B86u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBFDEu), 0x829B83u); }
    goto L_829B86;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9B83u,0x829B83u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829B86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B86u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B86u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B86u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829B86 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829B86u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829B86u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B86u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B86u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829B86 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829B86u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829B86u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9B86u,0x829B86u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_829B56_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829B56u: goto L_829B56;
    case 0x829B58u: goto L_829B58;
    case 0x829B5Bu: goto L_829B5B;
    case 0x829B5Eu: goto L_829B5E;
    case 0x829B61u: goto L_829B61;
    case 0x829B63u: goto L_829B63;
    case 0x829B66u: goto L_829B66;
    case 0x829B68u: goto L_829B68;
    case 0x829B6Bu: goto L_829B6B;
    case 0x829B6Eu: goto L_829B6E;
    case 0x829B6Fu: goto L_829B6F;
    case 0x829B70u: goto L_829B70;
    case 0x829B73u: goto L_829B73;
    case 0x829B83u: goto L_829B83;
    case 0x829B86u: goto L_829B86;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829B56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B56u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B56u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B56 BNE -> $829B83
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829B83; }
    goto L_829B58;
L_829B58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B58u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B58u, 6u, 3u, cpu.address("abs", 0xBF6Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829B58 JSR -> $82BF6E stack real
    { cpu.push16Value(hw,0x9B5Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9B5Bu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBF6Eu), 0x829B58u); }
    goto L_829B5B;
L_829B5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B5Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9B5Bu,0x829B5Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Bu, 5u, 3u, cpu.address("abs", 0x013Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B5B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829B5E;
L_829B5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Eu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Eu, 5u, 3u, cpu.address("abs", 0x0139u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B5E ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x139u), cpu.m8?8:16));
    goto L_829B61;
L_829B61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B61u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B61u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B61 BNE -> $829B83
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829B83; }
    goto L_829B63;
L_829B63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B63u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B63u, 6u, 3u, cpu.address("abs", 0xA8DAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829B63 JSR -> $82A8DA stack real
    { cpu.push16Value(hw,0x9B65u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9B66u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA8DAu), 0x829B63u); }
    goto L_829B66;
L_829B66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B66u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9B66u,0x829B66u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B66u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B66u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B66 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829B68;
L_829B68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B68u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B68u, 5u + 1u, 3u, cpu.address("absy", 0x0200u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B68 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x200u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829B6B;
L_829B6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B6Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B6Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B6B AND
    cpu.logicAnd(0xFFu);
    goto L_829B6E;
L_829B6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B6Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B6Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B6E ASL
    cpu.aslA();
    goto L_829B6F;
L_829B6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B6Fu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B6Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B6F TAX
    cpu.transfer("TAX");
    goto L_829B70;
L_829B70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B70u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B70u, 5u, 3u, cpu.address("abs", 0x9B75u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829B70 PEA
    cpu.push16Value(hw, 0x9B75u);
    goto L_829B73;
L_829B73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B73u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B73u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x9B87u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $829B73 JMP (9B87,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x9B87u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x829B73u); return; }
L_829B83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B83u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B83u, 6u, 3u, cpu.address("abs", 0xBFDEu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829B83 JSR -> $82BFDE stack real
    { cpu.push16Value(hw,0x9B85u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9B86u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBFDEu), 0x829B83u); }
    goto L_829B86;
L_829B86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B86u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9B86u,0x829B86u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B86u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B86u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829B86 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829B86u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829B86u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82A19F_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82A19Fu: goto L_82A19F;
    case 0x82A1A1u: goto L_82A1A1;
    case 0x82A1A3u: goto L_82A1A3;
    case 0x82A1A5u: goto L_82A1A5;
    case 0x82A1A8u: goto L_82A1A8;
    case 0x82A1AAu: goto L_82A1AA;
    case 0x82A1ACu: goto L_82A1AC;
    case 0x82A1AEu: goto L_82A1AE;
    case 0x82A1B0u: goto L_82A1B0;
    case 0x82A1B1u: goto L_82A1B1;
    case 0x82A1B4u: goto L_82A1B4;
    case 0x82A1B6u: goto L_82A1B6;
    case 0x82A1B8u: goto L_82A1B8;
    case 0x82A1B9u: goto L_82A1B9;
    case 0x82A1BCu: goto L_82A1BC;
    case 0x82A1BDu: goto L_82A1BD;
    case 0x82A1BFu: goto L_82A1BF;
    case 0x82A1C2u: goto L_82A1C2;
    case 0x82A1C4u: goto L_82A1C4;
    case 0x82A1C7u: goto L_82A1C7;
    case 0x82A1C8u: goto L_82A1C8;
    case 0x82A1C9u: goto L_82A1C9;
    case 0x82A1CAu: goto L_82A1CA;
    case 0x82A1CBu: goto L_82A1CB;
    case 0x82A1CCu: goto L_82A1CC;
    case 0x82A1CDu: goto L_82A1CD;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82A19F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA19Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA19Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA19Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A19F SEP
    cpu.sep(0x20u);
    goto L_82A1A1;
L_82A1A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1A1u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1A1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1A1 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A1A3;
L_82A1A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1A3u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1A3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1A3 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A1A5;
L_82A1A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1A5u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1A5u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1A5u, 4u + 1u, 3u, cpu.address("absy", 0x0208u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1A5 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x208u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A1A8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1A5u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1A5u, 4u + 1u, 3u, cpu.address("absy", 0x0208u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1A5 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x208u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A1A8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1A5u,0x82A1A5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A1A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1A8u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1A8u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1A8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1A8 BPL -> $82A1B1
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82A1B1; }
    goto L_82A1AA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1A8u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1A8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1A8 BPL -> $82A1B1
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82A1B1; }
    goto L_82A1AA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1A8u,0x82A1A8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A1AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1AAu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1AAu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1AAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1AA CMP
    cpu.compareA(0x80u);
    goto L_82A1AC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1AAu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1AAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1AA CMP
    cpu.compareA(0x80u);
    goto L_82A1AC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1AAu,0x82A1AAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A1AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1ACu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1ACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1AC BNE -> $82A1C7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A1C7; }
    goto L_82A1AE;
L_82A1AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1AEu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1AEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1AE REP
    cpu.rep(0x20u);
    goto L_82A1B0;
L_82A1B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A1B0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A1B0u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A1B0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82A1B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1B1u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B1u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B1u, 4u + 1u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1B1 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x20Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A1B4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B1u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B1u, 4u + 1u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1B1 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x20Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A1B4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1B1u,0x82A1B1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A1B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1B4u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1B4 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82A1B6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1B4 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82A1B6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1B4u,0x82A1B4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A1B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1B6u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1B6 LDA
    cpu.setA(0x0u, 8);
    goto L_82A1B8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1B6 LDA
    cpu.setA(0x0u, 8);
    goto L_82A1B8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1B6u,0x82A1B6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A1B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1B8u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B8u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1B8 SEC
    cpu.setFlag('C', true);
    goto L_82A1B9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B8u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1B8 SEC
    cpu.setFlag('C', true);
    goto L_82A1B9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1B8u,0x82A1B8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82A1B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B9u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B9u, 4u + 1u, 3u, cpu.address("absy", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1B9 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x20Au), cpu.m8?8:16));
    goto L_82A1BC;
L_82A1BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1BCu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1BCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1BC SEC
    cpu.setFlag('C', true);
    goto L_82A1BD;
L_82A1BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1BDu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1BDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1BD SBC
    cpu.sbc(0x8u);
    goto L_82A1BF;
L_82A1BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1BFu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1BFu, 5u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1BF STA
    hw.write(cpu.address("absy", 0x20Bu), cpu.a, cpu.m8?8:16);
    goto L_82A1C2;
L_82A1C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1C2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A1C4;
L_82A1C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C4u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C4u, 5u, 3u, cpu.address("absy", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1C4 STA
    hw.write(cpu.address("absy", 0x20Au), cpu.a, cpu.m8?8:16);
    goto L_82A1C7;
L_82A1C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C7u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1C7 INY
    cpu.inc('Y');
    goto L_82A1C8;
L_82A1C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C8u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1C8 INY
    cpu.inc('Y');
    goto L_82A1C9;
L_82A1C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C9u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1C9 INY
    cpu.inc('Y');
    goto L_82A1CA;
L_82A1CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CAu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1CA INY
    cpu.inc('Y');
    goto L_82A1CB;
L_82A1CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CBu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1CB INY
    cpu.inc('Y');
    goto L_82A1CC;
L_82A1CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CCu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1CC INY
    cpu.inc('Y');
    goto L_82A1CD;
L_82A1CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CDu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1CD BRA -> $82A1A5
    goto L_82A1A5;
}

void sub_82A19F_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82A19Fu: goto L_82A19F;
    case 0x82A1A1u: goto L_82A1A1;
    case 0x82A1A3u: goto L_82A1A3;
    case 0x82A1A5u: goto L_82A1A5;
    case 0x82A1A8u: goto L_82A1A8;
    case 0x82A1AAu: goto L_82A1AA;
    case 0x82A1ACu: goto L_82A1AC;
    case 0x82A1AEu: goto L_82A1AE;
    case 0x82A1B0u: goto L_82A1B0;
    case 0x82A1B1u: goto L_82A1B1;
    case 0x82A1B4u: goto L_82A1B4;
    case 0x82A1B6u: goto L_82A1B6;
    case 0x82A1B8u: goto L_82A1B8;
    case 0x82A1B9u: goto L_82A1B9;
    case 0x82A1BCu: goto L_82A1BC;
    case 0x82A1BDu: goto L_82A1BD;
    case 0x82A1BFu: goto L_82A1BF;
    case 0x82A1C2u: goto L_82A1C2;
    case 0x82A1C4u: goto L_82A1C4;
    case 0x82A1C7u: goto L_82A1C7;
    case 0x82A1C8u: goto L_82A1C8;
    case 0x82A1C9u: goto L_82A1C9;
    case 0x82A1CAu: goto L_82A1CA;
    case 0x82A1CBu: goto L_82A1CB;
    case 0x82A1CCu: goto L_82A1CC;
    case 0x82A1CDu: goto L_82A1CD;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82A19F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA19Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA19Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA19Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A19F SEP
    cpu.sep(0x20u);
    goto L_82A1A1;
L_82A1A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1A1u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1A1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1A1 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A1A3;
L_82A1A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1A3u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1A3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1A3 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A1A5;
L_82A1A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1A5u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1A5u, 4u + 1u, 3u, cpu.address("absy", 0x0208u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1A5 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x208u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A1A8;
L_82A1A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1A8u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1A8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1A8 BPL -> $82A1B1
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82A1B1; }
    goto L_82A1AA;
L_82A1AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1AAu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1AAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1AA CMP
    cpu.compareA(0x80u);
    goto L_82A1AC;
L_82A1AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1ACu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1ACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1AC BNE -> $82A1C7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A1C7; }
    goto L_82A1AE;
L_82A1AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1AEu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1AEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1AE REP
    cpu.rep(0x20u);
    goto L_82A1B0;
L_82A1B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A1B0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A1B0u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A1B0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82A1B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B1u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B1u, 4u + 1u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1B1 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x20Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A1B4;
L_82A1B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1B4 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82A1B6;
L_82A1B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1B6 LDA
    cpu.setA(0x0u, 8);
    goto L_82A1B8;
L_82A1B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B8u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1B8 SEC
    cpu.setFlag('C', true);
    goto L_82A1B9;
L_82A1B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B9u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B9u, 4u + 1u, 3u, cpu.address("absy", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1B9 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x20Au), cpu.m8?8:16));
    goto L_82A1BC;
L_82A1BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1BCu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1BCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1BC SEC
    cpu.setFlag('C', true);
    goto L_82A1BD;
L_82A1BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1BDu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1BDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1BD SBC
    cpu.sbc(0x8u);
    goto L_82A1BF;
L_82A1BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1BFu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1BFu, 5u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1BF STA
    hw.write(cpu.address("absy", 0x20Bu), cpu.a, cpu.m8?8:16);
    goto L_82A1C2;
L_82A1C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1C2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A1C4;
L_82A1C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C4u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C4u, 5u, 3u, cpu.address("absy", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1C4 STA
    hw.write(cpu.address("absy", 0x20Au), cpu.a, cpu.m8?8:16);
    goto L_82A1C7;
L_82A1C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C7u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1C7 INY
    cpu.inc('Y');
    goto L_82A1C8;
L_82A1C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C8u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1C8 INY
    cpu.inc('Y');
    goto L_82A1C9;
L_82A1C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C9u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1C9 INY
    cpu.inc('Y');
    goto L_82A1CA;
L_82A1CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CAu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1CA INY
    cpu.inc('Y');
    goto L_82A1CB;
L_82A1CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CBu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1CB INY
    cpu.inc('Y');
    goto L_82A1CC;
L_82A1CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CCu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1CC INY
    cpu.inc('Y');
    goto L_82A1CD;
L_82A1CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CDu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1CD BRA -> $82A1A5
    goto L_82A1A5;
}

void sub_82C053_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82C053u: goto L_82C053;
    case 0x82C056u: goto L_82C056;
    case 0x82C058u: goto L_82C058;
    case 0x82C05Bu: goto L_82C05B;
    case 0x82C05Eu: goto L_82C05E;
    case 0x82C060u: goto L_82C060;
    case 0x82C063u: goto L_82C063;
    case 0x82C064u: goto L_82C064;
    case 0x82C067u: goto L_82C067;
    case 0x82C068u: goto L_82C068;
    case 0x82C06Bu: goto L_82C06B;
    case 0x82C06Du: goto L_82C06D;
    case 0x82C070u: goto L_82C070;
    case 0x82C071u: goto L_82C071;
    case 0x82C074u: goto L_82C074;
    case 0x82C077u: goto L_82C077;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82C053:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC053u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC053u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC053u, 5u, 3u, cpu.address("abs", 0x0139u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C053 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x139u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C056;
L_82C056:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC056u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC056u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC056u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C056 BEQ -> $82C068
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C068; }
    goto L_82C058;
L_82C058:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC058u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC058u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC058u, 5u, 3u, cpu.address("abs", 0x014Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C058 STZ
    hw.write(cpu.address("abs", 0x14Au), 0, cpu.m8?8:16);
    goto L_82C05B;
L_82C05B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC05Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC05Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC05Bu, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C05B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C05E;
L_82C05E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC05Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC05Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC05Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C05E BNE -> $82C064
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C064; }
    goto L_82C060;
L_82C060:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC060u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC060u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC060u, 8u, 3u, cpu.address("abs", 0x013Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C060 INC
    cpu.incMem(hw, cpu.address("abs", 0x13Bu), cpu.m8?8:16);
    goto L_82C063;
L_82C063:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC063u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC063u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC063u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C063 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C063u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C063u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82C064:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC064u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC064u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC064u, 5u, 3u, cpu.address("abs", 0x013Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C064 STZ
    hw.write(cpu.address("abs", 0x13Bu), 0, cpu.m8?8:16);
    goto L_82C067;
L_82C067:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC067u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC067u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC067u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C067 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C067u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C067u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82C068:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC068u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC068u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC068u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C068 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C06B;
L_82C06B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC06Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC06Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC06Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C06B BEQ -> $82C071
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C071; }
    goto L_82C06D;
L_82C06D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC06Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC06Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC06Du, 5u, 3u, cpu.address("abs", 0x013Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C06D STZ
    hw.write(cpu.address("abs", 0x13Bu), 0, cpu.m8?8:16);
    goto L_82C070;
L_82C070:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC070u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC070u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC070u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C070 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C070u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C070u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82C071:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC071u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC071u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC071u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C071 LDA
    cpu.setA(0x4u, 16);
    goto L_82C074;
L_82C074:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC074u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC074u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC074u, 5u, 3u, cpu.address("abs", 0x013Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C074 STA
    hw.write(cpu.address("abs", 0x13Bu), cpu.a, cpu.m8?8:16);
    goto L_82C077;
L_82C077:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC077u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC077u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC077u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C077 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C077u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C077u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82C053_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82C053u: goto L_82C053;
    case 0x82C056u: goto L_82C056;
    case 0x82C058u: goto L_82C058;
    case 0x82C05Bu: goto L_82C05B;
    case 0x82C05Eu: goto L_82C05E;
    case 0x82C060u: goto L_82C060;
    case 0x82C063u: goto L_82C063;
    case 0x82C064u: goto L_82C064;
    case 0x82C067u: goto L_82C067;
    case 0x82C068u: goto L_82C068;
    case 0x82C06Bu: goto L_82C06B;
    case 0x82C06Du: goto L_82C06D;
    case 0x82C070u: goto L_82C070;
    case 0x82C071u: goto L_82C071;
    case 0x82C074u: goto L_82C074;
    case 0x82C077u: goto L_82C077;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82C053:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC053u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC053u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC053u, 5u, 3u, cpu.address("abs", 0x0139u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C053 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x139u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C056;
L_82C056:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC056u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC056u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC056u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C056 BEQ -> $82C068
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C068; }
    goto L_82C058;
L_82C058:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC058u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC058u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC058u, 5u, 3u, cpu.address("abs", 0x014Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C058 STZ
    hw.write(cpu.address("abs", 0x14Au), 0, cpu.m8?8:16);
    goto L_82C05B;
L_82C05B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC05Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC05Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC05Bu, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C05B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C05E;
L_82C05E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC05Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC05Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC05Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C05E BNE -> $82C064
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C064; }
    goto L_82C060;
L_82C060:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC060u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC060u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC060u, 8u, 3u, cpu.address("abs", 0x013Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C060 INC
    cpu.incMem(hw, cpu.address("abs", 0x13Bu), cpu.m8?8:16);
    goto L_82C063;
L_82C063:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC063u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC063u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC063u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C063 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C063u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C063u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82C064:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC064u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC064u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC064u, 5u, 3u, cpu.address("abs", 0x013Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C064 STZ
    hw.write(cpu.address("abs", 0x13Bu), 0, cpu.m8?8:16);
    goto L_82C067;
L_82C067:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC067u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC067u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC067u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C067 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C067u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C067u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82C068:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC068u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC068u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC068u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C068 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C06B;
L_82C06B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC06Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC06Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC06Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C06B BEQ -> $82C071
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C071; }
    goto L_82C06D;
L_82C06D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC06Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC06Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC06Du, 5u, 3u, cpu.address("abs", 0x013Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C06D STZ
    hw.write(cpu.address("abs", 0x13Bu), 0, cpu.m8?8:16);
    goto L_82C070;
L_82C070:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC070u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC070u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC070u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C070 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C070u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C070u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82C071:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC071u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC071u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC071u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C071 LDA
    cpu.setA(0x4u, 16);
    goto L_82C074;
L_82C074:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC074u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC074u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC074u, 5u, 3u, cpu.address("abs", 0x013Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C074 STA
    hw.write(cpu.address("abs", 0x13Bu), cpu.a, cpu.m8?8:16);
    goto L_82C077;
L_82C077:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC077u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC077u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC077u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C077 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C077u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C077u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_848689_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848689u: goto L_848689;
    case 0x84868Bu: goto L_84868B;
    case 0x84868Eu: goto L_84868E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848689:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8689u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8689u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8689u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848689 SEP
    cpu.sep(0x20u);
    goto L_84868B;
L_84868B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x868Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x868Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x868Bu, 6u, 3u, cpu.address("abs", 0x8B80u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84868B JSR -> $848B80 stack real
    { cpu.push16Value(hw,0x868Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x868Eu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8B80u), 0x84868Bu); }
    goto L_84868E;
L_84868E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x868Eu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x868Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x868Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84868E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84868Eu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84868Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x868Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x868Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84868E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84868Eu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84868Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x868Eu,0x84868Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_848689_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848689u: goto L_848689;
    case 0x84868Bu: goto L_84868B;
    case 0x84868Eu: goto L_84868E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848689:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8689u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8689u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8689u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848689 SEP
    cpu.sep(0x20u);
    goto L_84868B;
L_84868B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x868Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x868Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x868Bu, 6u, 3u, cpu.address("abs", 0x8B80u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84868B JSR -> $848B80 stack real
    { cpu.push16Value(hw,0x868Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x868Eu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8B80u), 0x84868Bu); }
    goto L_84868E;
L_84868E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x868Eu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x868Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x868Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84868E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84868Eu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84868Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x868Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x868Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84868E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84868Eu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84868Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x868Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x868Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84868E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84868Eu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84868Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x868Eu,0x84868Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_84880B_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84880Bu: goto L_84880B;
    case 0x84880Du: goto L_84880D;
    case 0x848810u: goto L_848810;
    case 0x848813u: goto L_848813;
    case 0x848816u: goto L_848816;
    case 0x848818u: goto L_848818;
    case 0x84881Bu: goto L_84881B;
    case 0x84881Du: goto L_84881D;
    case 0x848820u: goto L_848820;
    case 0x848822u: goto L_848822;
    case 0x848826u: goto L_848826;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84880B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x880Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x880Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x880Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84880B REP
    cpu.rep(0x20u);
    goto L_84880D;
L_84880D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x880Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x880Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x880Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84880D LDX
    cpu.setX(0x2u, 16);
    goto L_848810;
L_848810:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8810u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8810u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8810u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848810 LDY
    cpu.setY(0x8u, 16);
    goto L_848813;
L_848813:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8813u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8813u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8813u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848813 LDA
    cpu.setA(0x2AA8u, 16);
    goto L_848816;
L_848816:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8816u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8816u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8816u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848816 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_848818;
L_848818:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8818u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8818u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8818u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848818 LDA
    cpu.setA(0x7Eu, 16);
    goto L_84881B;
L_84881B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x881Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x881Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x881Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84881B STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_84881D;
L_84881D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x881Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x881Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x881Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84881D LDA
    cpu.setA(0x1800u, 16);
    goto L_848820;
L_848820:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8820u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8820u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8820u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848820 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_848822;
L_848822:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8822u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8822u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8822u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848822 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8825u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8826u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x848822u); }
    goto L_848826;
L_848826:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8826u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8826u,0x848826u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8826u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8826u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848826 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848826u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848826u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8488F1_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8488F1u: goto L_8488F1;
    case 0x8488F3u: goto L_8488F3;
    case 0x8488F6u: goto L_8488F6;
    case 0x8488F9u: goto L_8488F9;
    case 0x8488FCu: goto L_8488FC;
    case 0x8488FEu: goto L_8488FE;
    case 0x848901u: goto L_848901;
    case 0x848903u: goto L_848903;
    case 0x848906u: goto L_848906;
    case 0x848908u: goto L_848908;
    case 0x84890Cu: goto L_84890C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8488F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F1u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488F1 REP
    cpu.rep(0x20u);
    goto L_8488F3;
L_8488F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F3u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488F3 LDX
    cpu.setX(0x2u, 16);
    goto L_8488F6;
L_8488F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F6u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488F6 LDY
    cpu.setY(0x6u, 16);
    goto L_8488F9;
L_8488F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488F9 LDA
    cpu.setA(0x2C06u, 16);
    goto L_8488FC;
L_8488FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88FCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88FCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488FC STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_8488FE;
L_8488FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88FEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88FEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488FE LDA
    cpu.setA(0x7Eu, 16);
    goto L_848901;
L_848901:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8901u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8901u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8901u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848901 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_848903;
L_848903:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8903u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8903u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8903u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848903 LDA
    cpu.setA(0x1C00u, 16);
    goto L_848906;
L_848906:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8906u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8906u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8906u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848906 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_848908;
L_848908:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8908u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8908u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8908u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848908 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x890Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x890Cu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x848908u); }
    goto L_84890C;
L_84890C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x890Cu,0x84890Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84890C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84890Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84890Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8488F1_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8488F1u: goto L_8488F1;
    case 0x8488F3u: goto L_8488F3;
    case 0x8488F6u: goto L_8488F6;
    case 0x8488F9u: goto L_8488F9;
    case 0x8488FCu: goto L_8488FC;
    case 0x8488FEu: goto L_8488FE;
    case 0x848901u: goto L_848901;
    case 0x848903u: goto L_848903;
    case 0x848906u: goto L_848906;
    case 0x848908u: goto L_848908;
    case 0x84890Cu: goto L_84890C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8488F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F1u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488F1 REP
    cpu.rep(0x20u);
    goto L_8488F3;
L_8488F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F3u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488F3 LDX
    cpu.setX(0x2u, 16);
    goto L_8488F6;
L_8488F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F6u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488F6 LDY
    cpu.setY(0x6u, 16);
    goto L_8488F9;
L_8488F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488F9 LDA
    cpu.setA(0x2C06u, 16);
    goto L_8488FC;
L_8488FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88FCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88FCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488FC STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_8488FE;
L_8488FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88FEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88FEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8488FE LDA
    cpu.setA(0x7Eu, 16);
    goto L_848901;
L_848901:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8901u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8901u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8901u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848901 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_848903;
L_848903:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8903u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8903u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8903u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848903 LDA
    cpu.setA(0x1C00u, 16);
    goto L_848906;
L_848906:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8906u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8906u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8906u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848906 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_848908;
L_848908:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8908u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8908u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8908u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848908 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x890Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x890Cu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x848908u); }
    goto L_84890C;
L_84890C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x890Cu,0x84890Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84890C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84890Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84890Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_849BD2_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849BD2u: goto L_849BD2;
    case 0x849BD5u: goto L_849BD5;
    case 0x849BD8u: goto L_849BD8;
    case 0x849BD9u: goto L_849BD9;
    case 0x849BDCu: goto L_849BDC;
    case 0x849BDDu: goto L_849BDD;
    case 0x849BDEu: goto L_849BDE;
    case 0x849BE0u: goto L_849BE0;
    case 0x849BE3u: goto L_849BE3;
    case 0x849BE5u: goto L_849BE5;
    case 0x849BE8u: goto L_849BE8;
    case 0x849BEAu: goto L_849BEA;
    case 0x849BECu: goto L_849BEC;
    case 0x849BEFu: goto L_849BEF;
    case 0x849BF1u: goto L_849BF1;
    case 0x849BF4u: goto L_849BF4;
    case 0x849BF6u: goto L_849BF6;
    case 0x849BF9u: goto L_849BF9;
    case 0x849BFCu: goto L_849BFC;
    case 0x849BFFu: goto L_849BFF;
    case 0x849C01u: goto L_849C01;
    case 0x849C04u: goto L_849C04;
    case 0x849C07u: goto L_849C07;
    case 0x849C09u: goto L_849C09;
    case 0x849C0Cu: goto L_849C0C;
    case 0x849C0Du: goto L_849C0D;
    case 0x849C0Fu: goto L_849C0F;
    case 0x849C12u: goto L_849C12;
    case 0x849C14u: goto L_849C14;
    case 0x849C16u: goto L_849C16;
    case 0x849C1Au: goto L_849C1A;
    case 0x849C1Cu: goto L_849C1C;
    case 0x849C1Eu: goto L_849C1E;
    case 0x849C22u: goto L_849C22;
    case 0x849C24u: goto L_849C24;
    case 0x849C28u: goto L_849C28;
    case 0x849C2Cu: goto L_849C2C;
    case 0x849C30u: goto L_849C30;
    case 0x849C32u: goto L_849C32;
    case 0x849C36u: goto L_849C36;
    case 0x849C38u: goto L_849C38;
    case 0x849C3Au: goto L_849C3A;
    case 0x849C3Du: goto L_849C3D;
    case 0x849C41u: goto L_849C41;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849BD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BD2u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BD2u, 5u, 3u, cpu.address("abs", 0x062Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BD2 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849BD5;
L_849BD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BD5u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BD5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BD5 AND
    cpu.logicAnd(0x1u);
    goto L_849BD8;
L_849BD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BD8u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BD8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BD8 CLC
    cpu.setFlag('C', false);
    goto L_849BD9;
L_849BD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BD9u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BD9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BD9 ADC
    cpu.adc(0x2u);
    goto L_849BDC;
L_849BDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BDCu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BDCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BDC ASL
    cpu.aslA();
    goto L_849BDD;
L_849BDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BDDu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BDDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BDD TAX
    cpu.transfer("TAX");
    goto L_849BDE;
L_849BDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BDEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BDEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BDE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849BE0;
L_849BE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BE0u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BE0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BE0 BIT
    cpu.bit(0x200u, true);
    goto L_849BE3;
L_849BE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BE3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BE3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BE3 BNE -> $849BEC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_849BEC; }
    goto L_849BE5;
L_849BE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BE5u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BE5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BE5 BIT
    cpu.bit(0x100u, true);
    goto L_849BE8;
L_849BE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BE8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BE8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BE8 BNE -> $849BF6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_849BF6; }
    goto L_849BEA;
L_849BEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BEAu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BEAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BEA BRA -> $849C41
    goto L_849C41;
L_849BEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BECu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BECu, 9u, 3u, cpu.address("absx", 0x064Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BEC DEC
    cpu.decMem(hw, cpu.address("absx", 0x64Bu), cpu.m8?8:16);
    goto L_849BEF;
L_849BEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BEFu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BEFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BEF BPL -> $849C09
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_849C09; }
    goto L_849BF1;
L_849BF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF1u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF1u, 6u, 3u, cpu.address("absx", 0x064Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BF1 STZ
    hw.write(cpu.address("absx", 0x64Bu), 0, cpu.m8?8:16);
    goto L_849BF4;
L_849BF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF4u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BF4 BRA -> $849C41
    goto L_849C41;
L_849BF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF6u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF6u, 9u, 3u, cpu.address("absx", 0x064Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BF6 INC
    cpu.incMem(hw, cpu.address("absx", 0x64Bu), cpu.m8?8:16);
    goto L_849BF9;
L_849BF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF9u, 5u + 1u, 3u, cpu.address("absx", 0x064Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BF9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x64Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849BFC;
L_849BFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFCu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BFC CMP
    cpu.compareA(0x5u);
    goto L_849BFF;
L_849BFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFFu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BFF BCC -> $849C09
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_849C09; }
    goto L_849C01;
L_849C01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C01u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C01u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C01 LDA
    cpu.setA(0x4u, 16);
    goto L_849C04;
L_849C04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C04u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C04u, 6u, 3u, cpu.address("absx", 0x064Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C04 STA
    hw.write(cpu.address("absx", 0x64Bu), cpu.a, cpu.m8?8:16);
    goto L_849C07;
L_849C07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C07u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C07u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C07 BRA -> $849C41
    goto L_849C41;
L_849C09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C09u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C09u, 5u + 1u, 3u, cpu.address("absx", 0x064Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C09 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x64Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849C0C;
L_849C0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Cu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C0C TAX
    cpu.transfer("TAX");
    goto L_849C0D;
L_849C0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C0D SEP
    cpu.sep(0x20u);
    goto L_849C0F;
L_849C0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Fu, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C0F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849C12;
L_849C12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C12u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C12u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C12 BIT
    cpu.bit(0x1u, true);
    goto L_849C14;
L_849C14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C14u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C14u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C14 BNE -> $849C1C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_849C1C; }
    goto L_849C16;
L_849C16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C16u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C16u, 5u, 4u, ((0x9E9564u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C16 LDA
    cpu.loadA(hw.readW(((0x9E9564u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849C1A;
L_849C1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Au,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C1A BRA -> $849C22
    goto L_849C22;
L_849C1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C1C SEP
    cpu.sep(0x20u);
    goto L_849C1E;
L_849C1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Eu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Eu, 5u, 4u, ((0x9E9569u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C1E LDA
    cpu.loadA(hw.readW(((0x9E9569u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849C22;
L_849C22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C22u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C22u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C22 BEQ -> $849C32
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_849C32; }
    goto L_849C24;
L_849C24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C24u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C24u, 8u, 4u, 0x80A6BDu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849C24 JSL -> $80A6BD stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9C27u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9C28u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6BDu, 0x849C24u); }
    goto L_849C28;
L_849C28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C28u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C28u,0x849C28u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C28u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C28u, 8u, 4u, 0x80A6A5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849C28 JSL -> $80A6A5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9C2Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9C2Cu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6A5u, 0x849C28u); }
    goto L_849C2C;
L_849C2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C2Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C2Cu,0x849C2Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C2Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C2Cu, 8u, 4u, 0x808D2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849C2C JSL -> $808D2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9C2Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9C30u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D2Fu, 0x849C2Cu); }
    goto L_849C30;
L_849C30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C30u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C30u,0x849C30u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C30u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C30u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C30 BRA -> $849C38
    goto L_849C38;
L_849C32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C32u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C32u, 8u, 4u, 0x80A5D1u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849C32 JSL -> $80A5D1 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9C35u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9C36u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A5D1u, 0x849C32u); }
    goto L_849C36;
L_849C36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C36u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C36u,0x849C36u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C36u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C36u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C36 BRA -> $849C38
    goto L_849C38;
L_849C38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C38u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C38u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C38 REP
    cpu.rep(0x20u);
    goto L_849C3A;
L_849C3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C3Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C3Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C3A LDA
    cpu.setA(0x7u, 16);
    goto L_849C3D;
L_849C3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C3Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C3Du, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849C3D JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9C40u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9C41u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x849C3Du); }
    goto L_849C41;
L_849C41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C41u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C41u,0x849C41u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C41u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C41u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849C41 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849C41u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849C41u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_849F86_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849F86u: goto L_849F86;
    case 0x849F88u: goto L_849F88;
    case 0x849F89u: goto L_849F89;
    case 0x849F8Au: goto L_849F8A;
    case 0x849F8Cu: goto L_849F8C;
    case 0x849F8Fu: goto L_849F8F;
    case 0x849F92u: goto L_849F92;
    case 0x849F94u: goto L_849F94;
    case 0x849F96u: goto L_849F96;
    case 0x849F97u: goto L_849F97;
    case 0x849F99u: goto L_849F99;
    case 0x849F9Bu: goto L_849F9B;
    case 0x849F9Cu: goto L_849F9C;
    case 0x849F9Fu: goto L_849F9F;
    case 0x849FA1u: goto L_849FA1;
    case 0x849FA4u: goto L_849FA4;
    case 0x849FA6u: goto L_849FA6;
    case 0x849FA9u: goto L_849FA9;
    case 0x849FABu: goto L_849FAB;
    case 0x849FADu: goto L_849FAD;
    case 0x849FAFu: goto L_849FAF;
    case 0x849FB3u: goto L_849FB3;
    case 0x849FB5u: goto L_849FB5;
    case 0x849FB9u: goto L_849FB9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849F86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F86u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F86u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849F86 REP
    cpu.rep(0x20u);
    goto L_849F88;
L_849F88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F88u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F88u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849F88 ASL
    cpu.aslA();
    goto L_849F89;
L_849F89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F89u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F89u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849F89 ASL
    cpu.aslA();
    goto L_849F8A;
L_849F8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F8Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F8Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849F8A STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_849F8C;
L_849F8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F8Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F8Cu, 5u, 3u, cpu.address("abs", 0x0629u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849F8C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849F8F;
L_849F8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F8Fu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F8Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849F8F BIT
    cpu.bit(0x1u, true);
    goto L_849F92;
L_849F92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F92u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F92u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849F92 BEQ -> $849F99
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_849F99; }
    goto L_849F94;
L_849F94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F94u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F94u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849F94 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849F96;
L_849F96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F96u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F96u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849F96 ASL
    cpu.aslA();
    goto L_849F97;
L_849F97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F97u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F97u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849F97 STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_849F99;
L_849F99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F99u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F99u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849F99 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849F9B;
L_849F9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F9Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F9Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849F9B CLC
    cpu.setFlag('C', false);
    goto L_849F9C;
L_849F9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F9Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F9Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849F9C ADC
    cpu.adc(0x68u);
    goto L_849F9F;
L_849F9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F9Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F9Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849F9F STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_849FA1;
L_849FA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FA1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FA1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849FA1 LDA
    cpu.setA(0x10u, 16);
    goto L_849FA4;
L_849FA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FA4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FA4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849FA4 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_849FA6;
L_849FA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FA6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FA6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849FA6 LDA
    cpu.setA(0x84u, 16);
    goto L_849FA9;
L_849FA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FA9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FA9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849FA9 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_849FAB;
L_849FAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FABu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FABu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849FAB STZ
    hw.write(cpu.address("dp", 0x3u), 0, cpu.m8?8:16);
    goto L_849FAD;
L_849FAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FADu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FADu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849FAD STZ
    hw.write(cpu.address("dp", 0x4u), 0, cpu.m8?8:16);
    goto L_849FAF;
L_849FAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FAFu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FAFu, 6u, 4u, ((0x849FBAu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849FAF LDA
    cpu.loadA(hw.readW(((0x849FBAu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849FB3;
L_849FB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FB3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FB3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849FB3 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_849FB5;
L_849FB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FB5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FB5u, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849FB5 JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9FB8u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9FB9u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x849FB5u); }
    goto L_849FB9;
L_849FB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FB9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9FB9u,0x849FB9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FB9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FB9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849FB9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849FB9u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849FB9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84B80F_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84B80Fu: goto L_84B80F;
    case 0x84B811u: goto L_84B811;
    case 0x84B814u: goto L_84B814;
    case 0x84B817u: goto L_84B817;
    case 0x84B81Au: goto L_84B81A;
    case 0x84B81Du: goto L_84B81D;
    case 0x84B820u: goto L_84B820;
    case 0x84B823u: goto L_84B823;
    case 0x84B826u: goto L_84B826;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84B80F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB80Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB80Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB80Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B80F REP
    cpu.rep(0x20u);
    goto L_84B811;
L_84B811:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB811u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB811u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB811u, 5u, 3u, cpu.address("abs", 0x014Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B811 STZ
    hw.write(cpu.address("abs", 0x14Eu), 0, cpu.m8?8:16);
    goto L_84B814;
L_84B814:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB814u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB814u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB814u, 5u, 3u, cpu.address("abs", 0x0150u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B814 STZ
    hw.write(cpu.address("abs", 0x150u), 0, cpu.m8?8:16);
    goto L_84B817;
L_84B817:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB817u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB817u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB817u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B817 LDX
    cpu.setX(0x0u, 16);
    goto L_84B81A;
L_84B81A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB81Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB81Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB81Au, 5u + 1u, 3u, cpu.address("absx", 0x0670u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B81A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x670u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B81D;
L_84B81D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB81Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB81Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB81Du, 5u, 3u, cpu.address("abs", 0x0152u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B81D STA
    hw.write(cpu.address("abs", 0x152u), cpu.a, cpu.m8?8:16);
    goto L_84B820;
L_84B820:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB820u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB820u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB820u, 5u + 1u, 3u, cpu.address("absx", 0x0672u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B820 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x672u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B823;
L_84B823:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB823u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB823u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB823u, 5u, 3u, cpu.address("abs", 0x0154u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B823 STA
    hw.write(cpu.address("abs", 0x154u), cpu.a, cpu.m8?8:16);
    goto L_84B826;
L_84B826:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB826u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB826u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB826u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B826 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x84B826u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84B826u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_84B80F_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84B80Fu: goto L_84B80F;
    case 0x84B811u: goto L_84B811;
    case 0x84B814u: goto L_84B814;
    case 0x84B817u: goto L_84B817;
    case 0x84B81Au: goto L_84B81A;
    case 0x84B81Du: goto L_84B81D;
    case 0x84B820u: goto L_84B820;
    case 0x84B823u: goto L_84B823;
    case 0x84B826u: goto L_84B826;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84B80F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB80Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB80Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB80Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B80F REP
    cpu.rep(0x20u);
    goto L_84B811;
L_84B811:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB811u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB811u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB811u, 5u, 3u, cpu.address("abs", 0x014Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B811 STZ
    hw.write(cpu.address("abs", 0x14Eu), 0, cpu.m8?8:16);
    goto L_84B814;
L_84B814:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB814u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB814u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB814u, 5u, 3u, cpu.address("abs", 0x0150u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B814 STZ
    hw.write(cpu.address("abs", 0x150u), 0, cpu.m8?8:16);
    goto L_84B817;
L_84B817:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB817u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB817u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB817u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B817 LDX
    cpu.setX(0x0u, 16);
    goto L_84B81A;
L_84B81A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB81Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB81Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB81Au, 5u + 1u, 3u, cpu.address("absx", 0x0670u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B81A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x670u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B81D;
L_84B81D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB81Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB81Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB81Du, 5u, 3u, cpu.address("abs", 0x0152u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B81D STA
    hw.write(cpu.address("abs", 0x152u), cpu.a, cpu.m8?8:16);
    goto L_84B820;
L_84B820:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB820u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB820u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB820u, 5u + 1u, 3u, cpu.address("absx", 0x0672u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B820 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x672u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B823;
L_84B823:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB823u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB823u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB823u, 5u, 3u, cpu.address("abs", 0x0154u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B823 STA
    hw.write(cpu.address("abs", 0x154u), cpu.a, cpu.m8?8:16);
    goto L_84B826;
L_84B826:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB826u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB826u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB826u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B826 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x84B826u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84B826u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_84B9B8_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84B9B8u: goto L_84B9B8;
    case 0x84B9BAu: goto L_84B9BA;
    case 0x84B9BDu: goto L_84B9BD;
    case 0x84B9BFu: goto L_84B9BF;
    case 0x84B9C0u: goto L_84B9C0;
    case 0x84B9C3u: goto L_84B9C3;
    case 0x84B9C6u: goto L_84B9C6;
    case 0x84B9C9u: goto L_84B9C9;
    case 0x84B9CCu: goto L_84B9CC;
    case 0x84B9CEu: goto L_84B9CE;
    case 0x84B9CFu: goto L_84B9CF;
    case 0x84B9D0u: goto L_84B9D0;
    case 0x84B9D1u: goto L_84B9D1;
    case 0x84B9D4u: goto L_84B9D4;
    case 0x84B9D6u: goto L_84B9D6;
    case 0x84B9D8u: goto L_84B9D8;
    case 0x84B9D9u: goto L_84B9D9;
    case 0x84B9DCu: goto L_84B9DC;
    case 0x84B9DEu: goto L_84B9DE;
    case 0x84B9E0u: goto L_84B9E0;
    case 0x84B9E2u: goto L_84B9E2;
    case 0x84B9E3u: goto L_84B9E3;
    case 0x84B9E4u: goto L_84B9E4;
    case 0x84B9E5u: goto L_84B9E5;
    case 0x84B9E6u: goto L_84B9E6;
    case 0x84B9E9u: goto L_84B9E9;
    case 0x84B9EBu: goto L_84B9EB;
    case 0x84B9EDu: goto L_84B9ED;
    case 0x84B9EFu: goto L_84B9EF;
    case 0x84B9F0u: goto L_84B9F0;
    case 0x84B9F1u: goto L_84B9F1;
    case 0x84B9F4u: goto L_84B9F4;
    case 0x84B9F6u: goto L_84B9F6;
    case 0x84B9F8u: goto L_84B9F8;
    case 0x84B9FAu: goto L_84B9FA;
    case 0x84B9FBu: goto L_84B9FB;
    case 0x84B9FCu: goto L_84B9FC;
    case 0x84B9FFu: goto L_84B9FF;
    case 0x84BA01u: goto L_84BA01;
    case 0x84BA03u: goto L_84BA03;
    case 0x84BA05u: goto L_84BA05;
    case 0x84BA06u: goto L_84BA06;
    case 0x84BA09u: goto L_84BA09;
    case 0x84BA0Bu: goto L_84BA0B;
    case 0x84BA0Du: goto L_84BA0D;
    case 0x84BA0Fu: goto L_84BA0F;
    case 0x84BA10u: goto L_84BA10;
    case 0x84BA11u: goto L_84BA11;
    case 0x84BA12u: goto L_84BA12;
    case 0x84BA13u: goto L_84BA13;
    case 0x84BA14u: goto L_84BA14;
    case 0x84BA17u: goto L_84BA17;
    case 0x84BA19u: goto L_84BA19;
    case 0x84BA1Bu: goto L_84BA1B;
    case 0x84BA1Du: goto L_84BA1D;
    case 0x84BA20u: goto L_84BA20;
    case 0x84BA22u: goto L_84BA22;
    case 0x84BA24u: goto L_84BA24;
    case 0x84BA27u: goto L_84BA27;
    case 0x84BA28u: goto L_84BA28;
    case 0x84BA2Au: goto L_84BA2A;
    case 0x84BA2Cu: goto L_84BA2C;
    case 0x84BA2Du: goto L_84BA2D;
    case 0x84BA2Eu: goto L_84BA2E;
    case 0x84BA30u: goto L_84BA30;
    case 0x84BA32u: goto L_84BA32;
    case 0x84BA33u: goto L_84BA33;
    case 0x84BA34u: goto L_84BA34;
    case 0x84BA38u: goto L_84BA38;
    case 0x84BA3Bu: goto L_84BA3B;
    case 0x84BA3Eu: goto L_84BA3E;
    case 0x84BA40u: goto L_84BA40;
    case 0x84BA41u: goto L_84BA41;
    case 0x84BA42u: goto L_84BA42;
    case 0x84BA46u: goto L_84BA46;
    case 0x84BA49u: goto L_84BA49;
    case 0x84BA4Cu: goto L_84BA4C;
    case 0x84BA4Eu: goto L_84BA4E;
    case 0x84BA4Fu: goto L_84BA4F;
    case 0x84BA50u: goto L_84BA50;
    case 0x84BA54u: goto L_84BA54;
    case 0x84BA57u: goto L_84BA57;
    case 0x84BA5Au: goto L_84BA5A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84B9B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9B8 REP
    cpu.rep(0x20u);
    goto L_84B9BA;
L_84B9BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9BAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9BAu, 6u, 3u, cpu.address("abs", 0xBB27u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B9BA JSR -> $84BB27 stack real
    { cpu.push16Value(hw,0xB9BCu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB9BDu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBB27u), 0x84B9BAu); }
    goto L_84B9BD;
L_84B9BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9BDu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9BDu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9BDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9BD BCC -> $84B9C0
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_84B9C0; }
    goto L_84B9BF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9BDu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9BDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9BD BCC -> $84B9C0
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_84B9C0; }
    goto L_84B9BF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB9BDu,0x84B9BDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84B9BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9BFu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9BFu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9BFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B9BF RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x84B9BFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84B9BFu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9BFu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9BFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B9BF RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x84B9BFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84B9BFu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB9BFu,0x84B9BFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84B9C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9C0u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C0u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C0u, 5u, 3u, cpu.address("abs", 0x06C6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9C0 STZ
    hw.write(cpu.address("abs", 0x6C6u), 0, cpu.m8?8:16);
    goto L_84B9C3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C0u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C0u, 5u, 3u, cpu.address("abs", 0x06C6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9C0 STZ
    hw.write(cpu.address("abs", 0x6C6u), 0, cpu.m8?8:16);
    goto L_84B9C3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB9C0u,0x84B9C0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84B9C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9C3u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C3u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C3u, 5u, 3u, cpu.address("abs", 0x06C8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9C3 STZ
    hw.write(cpu.address("abs", 0x6C8u), 0, cpu.m8?8:16);
    goto L_84B9C6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C3u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C3u, 5u, 3u, cpu.address("abs", 0x06C8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9C3 STZ
    hw.write(cpu.address("abs", 0x6C8u), 0, cpu.m8?8:16);
    goto L_84B9C6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB9C3u,0x84B9C3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84B9C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9C6u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C6u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C6u, 5u, 3u, cpu.address("abs", 0x06CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9C6 STZ
    hw.write(cpu.address("abs", 0x6CAu), 0, cpu.m8?8:16);
    goto L_84B9C9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C6u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C6u, 5u, 3u, cpu.address("abs", 0x06CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9C6 STZ
    hw.write(cpu.address("abs", 0x6CAu), 0, cpu.m8?8:16);
    goto L_84B9C9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB9C6u,0x84B9C6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84B9C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9C9u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C9u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C9u, 5u, 3u, cpu.address("abs", 0x02CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9C9 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2CEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B9CC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C9u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C9u, 5u, 3u, cpu.address("abs", 0x02CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9C9 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2CEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B9CC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB9C9u,0x84B9C9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84B9CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9CCu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9CCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9CCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9CC STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_84B9CE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9CCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9CCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9CC STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_84B9CE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB9CCu,0x84B9CCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84B9CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9CEu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9CEu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9CEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9CE LSR
    cpu.lsrA();
    goto L_84B9CF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9CEu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9CEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9CE LSR
    cpu.lsrA();
    goto L_84B9CF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB9CEu,0x84B9CEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84B9CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9CFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9CFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9CF LSR
    cpu.lsrA();
    goto L_84B9D0;
L_84B9D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D0u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9D0 LSR
    cpu.lsrA();
    goto L_84B9D1;
L_84B9D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D1u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9D1 AND
    cpu.logicAnd(0x1u);
    goto L_84B9D4;
L_84B9D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9D4 STA
    hw.write(cpu.address("dp", 0x61u), cpu.a, cpu.m8?8:16);
    goto L_84B9D6;
L_84B9D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9D6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B9D8;
L_84B9D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D8u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9D8 ASL
    cpu.aslA();
    goto L_84B9D9;
L_84B9D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9D9 AND
    cpu.logicAnd(0x2u);
    goto L_84B9DC;
L_84B9DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9DCu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9DCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9DC ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x61u), cpu.m8?8:16));
    goto L_84B9DE;
L_84B9DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9DEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9DEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9DE STA
    hw.write(cpu.address("dp", 0x61u), cpu.a, cpu.m8?8:16);
    goto L_84B9E0;
L_84B9E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9E0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B9E2;
L_84B9E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E2u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9E2 LSR
    cpu.lsrA();
    goto L_84B9E3;
L_84B9E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E3u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9E3 LSR
    cpu.lsrA();
    goto L_84B9E4;
L_84B9E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E4u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9E4 LSR
    cpu.lsrA();
    goto L_84B9E5;
L_84B9E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E5u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9E5 LSR
    cpu.lsrA();
    goto L_84B9E6;
L_84B9E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E6u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9E6 AND
    cpu.logicAnd(0x4u);
    goto L_84B9E9;
L_84B9E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E9u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9E9 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x61u), cpu.m8?8:16));
    goto L_84B9EB;
L_84B9EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9EBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9EBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9EB STA
    hw.write(cpu.address("dp", 0x61u), cpu.a, cpu.m8?8:16);
    goto L_84B9ED;
L_84B9ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9EDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9EDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9ED LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B9EF;
L_84B9EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9EFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9EFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9EF LSR
    cpu.lsrA();
    goto L_84B9F0;
L_84B9F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F0u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9F0 LSR
    cpu.lsrA();
    goto L_84B9F1;
L_84B9F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F1u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9F1 AND
    cpu.logicAnd(0x8u);
    goto L_84B9F4;
L_84B9F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F4u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9F4 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x61u), cpu.m8?8:16));
    goto L_84B9F6;
L_84B9F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9F6 STA
    hw.write(cpu.address("dp", 0x61u), cpu.a, cpu.m8?8:16);
    goto L_84B9F8;
L_84B9F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9F8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B9FA;
L_84B9FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9FAu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9FAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9FA ASL
    cpu.aslA();
    goto L_84B9FB;
L_84B9FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9FBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9FBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9FB ASL
    cpu.aslA();
    goto L_84B9FC;
L_84B9FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9FCu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9FCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9FC AND
    cpu.logicAnd(0x10u);
    goto L_84B9FF;
L_84B9FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9FFu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9FFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B9FF ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x61u), cpu.m8?8:16));
    goto L_84BA01;
L_84BA01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA01u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA01u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA01 STA
    hw.write(cpu.address("dp", 0x61u), cpu.a, cpu.m8?8:16);
    goto L_84BA03;
L_84BA03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA03u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA03u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA03 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BA05;
L_84BA05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA05u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA05u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA05 ASL
    cpu.aslA();
    goto L_84BA06;
L_84BA06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA06u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA06u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA06 AND
    cpu.logicAnd(0x20u);
    goto L_84BA09;
L_84BA09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA09u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA09u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA09 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x61u), cpu.m8?8:16));
    goto L_84BA0B;
L_84BA0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA0Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA0Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA0B STA
    hw.write(cpu.address("dp", 0x61u), cpu.a, cpu.m8?8:16);
    goto L_84BA0D;
L_84BA0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA0Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA0Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA0D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BA0F;
L_84BA0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA0Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA0Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA0F ASL
    cpu.aslA();
    goto L_84BA10;
L_84BA10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA10u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA10u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA10 ASL
    cpu.aslA();
    goto L_84BA11;
L_84BA11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA11u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA11u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA11 ASL
    cpu.aslA();
    goto L_84BA12;
L_84BA12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA12u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA12u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA12 ASL
    cpu.aslA();
    goto L_84BA13;
L_84BA13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA13u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA13u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA13 ASL
    cpu.aslA();
    goto L_84BA14;
L_84BA14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA14u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA14u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA14 AND
    cpu.logicAnd(0x40u);
    goto L_84BA17;
L_84BA17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA17u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA17u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA17 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x61u), cpu.m8?8:16));
    goto L_84BA19;
L_84BA19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA19u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA19u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA19 STA
    hw.write(cpu.address("dp", 0x61u), cpu.a, cpu.m8?8:16);
    goto L_84BA1B;
L_84BA1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA1Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA1Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA1B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x61u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BA1D;
L_84BA1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA1Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA1Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA1D AND
    cpu.logicAnd(0x1Fu);
    goto L_84BA20;
L_84BA20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA20u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA20u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA20 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_84BA22;
L_84BA22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA22u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA22u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA22 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x61u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BA24;
L_84BA24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA24u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA24u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA24 AND
    cpu.logicAnd(0x3Fu);
    goto L_84BA27;
L_84BA27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA27u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA27u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA27 LSR
    cpu.lsrA();
    goto L_84BA28;
L_84BA28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA28u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA28u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA28 STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_84BA2A;
L_84BA2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA2A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x61u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BA2C;
L_84BA2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA2C LSR
    cpu.lsrA();
    goto L_84BA2D;
L_84BA2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA2D LSR
    cpu.lsrA();
    goto L_84BA2E;
L_84BA2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA2E STA
    hw.write(cpu.address("dp", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_84BA30;
L_84BA30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA30u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA30u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA30 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BA32;
L_84BA32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA32u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA32u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA32 ASL
    cpu.aslA();
    goto L_84BA33;
L_84BA33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA33u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA33u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA33 TAX
    cpu.transfer("TAX");
    goto L_84BA34;
L_84BA34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA34u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA34u, 6u, 4u, ((0x84BA5Bu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA34 LDA
    cpu.loadA(hw.readW(((0x84BA5Bu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BA38;
L_84BA38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA38u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA38u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA38 AND
    cpu.logicAnd(0xFFu);
    goto L_84BA3B;
L_84BA3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA3Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA3Bu, 5u, 3u, cpu.address("abs", 0x06C6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA3B STA
    hw.write(cpu.address("abs", 0x6C6u), cpu.a, cpu.m8?8:16);
    goto L_84BA3E;
L_84BA3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA3Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA3Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA3E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BA40;
L_84BA40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA40u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA40u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA40 ASL
    cpu.aslA();
    goto L_84BA41;
L_84BA41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA41u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA41u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA41 TAX
    cpu.transfer("TAX");
    goto L_84BA42;
L_84BA42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA42u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA42u, 6u, 4u, ((0x84BA9Fu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA42 LDA
    cpu.loadA(hw.readW(((0x84BA9Fu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BA46;
L_84BA46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA46u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA46u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA46 AND
    cpu.logicAnd(0xFFu);
    goto L_84BA49;
L_84BA49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA49u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA49u, 5u, 3u, cpu.address("abs", 0x06C8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA49 STA
    hw.write(cpu.address("abs", 0x6C8u), cpu.a, cpu.m8?8:16);
    goto L_84BA4C;
L_84BA4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA4Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA4Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA4C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BA4E;
L_84BA4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA4Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA4Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA4E ASL
    cpu.aslA();
    goto L_84BA4F;
L_84BA4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA4Fu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA4Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA4F TAX
    cpu.transfer("TAX");
    goto L_84BA50;
L_84BA50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA50u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA50u, 6u, 4u, ((0x84BAE3u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA50 LDA
    cpu.loadA(hw.readW(((0x84BAE3u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BA54;
L_84BA54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA54u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA54u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA54 AND
    cpu.logicAnd(0xFFu);
    goto L_84BA57;
L_84BA57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA57u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA57u, 5u, 3u, cpu.address("abs", 0x06CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BA57 STA
    hw.write(cpu.address("abs", 0x6CAu), cpu.a, cpu.m8?8:16);
    goto L_84BA5A;
L_84BA5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA5Au,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA5Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84BA5A RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x84BA5Au);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84BA5Au,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_DC8189_E0M0X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xDC8189u: goto L_DC8189;
    case 0xDC818Cu: goto L_DC818C;
    case 0xDC818Eu: goto L_DC818E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_DC8189:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8189u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8189u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8189u, 9u, 3u, cpu.address("absx", 0x1040u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $DC8189 INC
    cpu.incMem(hw, cpu.address("absx", 0x1040u), cpu.m8?8:16);
    goto L_DC818C;
L_DC818C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x818Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x818Cu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x818Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $DC818C CPX
    cpu.compareX(0x66u);
    goto L_DC818E;
L_DC818E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x818Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x818Eu,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x818Eu, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $DC818E BRK
    hw.partial(0xDC818Eu, "BRK"); return;
}

