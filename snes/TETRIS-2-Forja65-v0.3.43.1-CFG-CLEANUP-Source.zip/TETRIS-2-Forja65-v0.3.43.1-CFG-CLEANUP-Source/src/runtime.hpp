#pragma once
#include <cstdint>
#include <cstddef>
#include <stdexcept>
#include <string>
#include <vector>
#include <array>
#include <fstream>
#include <algorithm>
#include <chrono>
#include <thread>
#include <iterator>
#include <cstdlib>
#include <filesystem>
#include <sstream>
#include <iomanip>
#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
#include <xinput.h>
#endif
#ifndef FORJA_TRACE_HPP
#define FORJA_TRACE_HPP
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <string>
#include <stdexcept>
#ifndef FORJA65_ENABLE_TRACE
#define FORJA65_ENABLE_TRACE 1
#endif
// No observer performs a bus read. Disabled builds perform no file or event work.
struct ForjaTrace {
#if FORJA65_ENABLE_TRACE
  std::ofstream out;
  std::uint64_t sequence{},written{},dropped{},limit{250000};
  bool enabled{};
  void start(const std::string&path,const std::string&rom,std::uint64_t cap=250000){close();out.open(path,std::ios::trunc);if(!out)throw std::runtime_error("Cannot open ForjaTrace: "+path);sequence=written=dropped=0;limit=cap;enabled=true;out<<"# FORJA_TRACE 1 rom="<<rom<<"\nseq,frame,routine,pc,kind,space,address,value,source\n";}
  void initialize(const std::string&rom){const char*p=std::getenv("FORJA65_TRACE");if(!p||!*p||std::string(p)=="0")return;std::uint64_t cap=250000;if(const char*c=std::getenv("FORJA65_TRACE_LIMIT")){try{cap=std::stoull(c);}catch(...){throw std::runtime_error("Invalid FORJA65_TRACE_LIMIT");}}start(std::string(p)=="1"?"forja-trace.csv":p,rom,cap);}
  void emit(std::uint64_t frame,std::uint32_t routine,std::uint32_t pc,const char*kind,const char*space,std::uint32_t address,std::uint64_t value,const char*source="CPU"){if(!enabled)return;const auto seq=sequence++;if(written>=limit){dropped++;return;}out<<seq<<','<<frame<<','<<routine<<','<<pc<<','<<kind<<','<<space<<','<<address<<','<<value<<','<<source<<'\n';if(!out)throw std::runtime_error("ForjaTrace write failed");written++;}
  void close(){if(out.is_open()){out<<"# written="<<written<<" dropped="<<dropped<<'\n';out.close();}enabled=false;}
#else
  static constexpr bool enabled=false;
  void start(const std::string&,const std::string&,std::uint64_t=250000){}
  void initialize(const std::string&){}
  void emit(std::uint64_t,std::uint32_t,std::uint32_t,const char*,const char*,std::uint32_t,std::uint64_t,const char* = "CPU"){}
  void close(){}
#endif
  ~ForjaTrace(){close();}
};
struct ForjaTraceContext {
  std::uint32_t&routine;const char*&source;std::uint32_t oldRoutine;const char*oldSource;
  ForjaTraceContext(std::uint32_t&r,const char*&s,std::uint32_t next,const char*origin):routine(r),source(s),oldRoutine(r),oldSource(s){routine=next;source=origin;}
  ~ForjaTraceContext(){routine=oldRoutine;source=oldSource;}
};

#endif

#ifndef FORJA_IR_HPP
#define FORJA_IR_HPP
#include <array>
#include <cstdint>
#include <stdexcept>
#include <vector>
#include <utility>
// Host representation: no PPU registers, SNES DMA engine or ROM bus.
struct ForjaRenderer {
  std::array<std::uint16_t,256> palette{};
  struct Scroll {int x{},y{};};std::array<Scroll,4> layers{};
  std::uint64_t paletteUploads{},scrollUpdates{};
  void uploadPalette(unsigned first,const std::vector<std::uint16_t>&colors){if(first>256||colors.size()>256-first)throw std::out_of_range("Palette range");for(auto c:colors)if(c>0x7fff)throw std::out_of_range("Palette color");for(std::size_t i=0;i<colors.size();i++)palette[first+i]=colors[i];paletteUploads++;}
  void setLayerScroll(unsigned layer,int x,int y){if(layer>=layers.size())throw std::out_of_range("Layer");layers[layer]={x,y};scrollUpdates++;}
};
struct ForjaIR {
  enum class Op {SetPalette,SetScroll};
  Op op{};unsigned index{};int x{},y{};std::vector<std::uint16_t> colors;
  static ForjaIR setPalette(unsigned first,std::vector<std::uint16_t> colors){return {Op::SetPalette,first,0,0,std::move(colors)};}
  static ForjaIR setScroll(unsigned layer,int x,int y){return {Op::SetScroll,layer,x,y,{}};}
  void apply(ForjaRenderer&host)const{if(op==Op::SetPalette)host.uploadPalette(index,colors);else if(op==Op::SetScroll)host.setLayerScroll(index,x,y);else throw std::invalid_argument("Unknown ForjaIR op");}
};

#endif

struct SnesRuntime;
struct CpuState {
  std::uint16_t a{},x{},y{},s{0x1FF},d{}; std::uint8_t db{},pb{}; bool c{},z{},i{1},decimalMode{},v{},n{},e{1},m8{1},x8{1};
  void nz(std::uint16_t q,int w){std::uint16_t mask=w==8?0xFF:0xFFFF;q&=mask;z=q==0;n=(q&(w==8?0x80:0x8000))!=0;}
  void setA(std::uint32_t q,int w){a=(w==8)?((a&0xFF00)|(q&0xFF)):(q&0xFFFF);nz(a,w);} void setX(std::uint32_t q,int w){x=q&(w==8?0xFF:0xFFFF);nz(x,w);} void setY(std::uint32_t q,int w){y=q&(w==8?0xFF:0xFFFF);nz(y,w);} void loadA(std::uint32_t q,int w){setA(q,w);}
  std::uint32_t address(const std::string& mode,std::uint32_t q)const{if(mode=="dp")return(d+q)&0xFFFF;if(mode=="dpx")return(d+q+x)&0xFFFF;if(mode=="dpy")return(d+q+y)&0xFFFF;if(mode=="abs")return((std::uint32_t)db<<16)|(q&0xFFFF);if(mode=="absx")return((std::uint32_t)db<<16)|((q+x)&0xFFFF);if(mode=="absy")return((std::uint32_t)db<<16)|((q+y)&0xFFFF);return q&0xFFFFFF;}
  std::uint32_t addressDpIndirectX(SnesRuntime&,std::uint32_t q)const; std::uint32_t addressDpIndirect(SnesRuntime&,std::uint32_t q)const; std::uint32_t addressDpIndirectY(SnesRuntime&,std::uint32_t q)const; std::uint32_t addressDpLong(SnesRuntime&,std::uint32_t q)const; std::uint32_t addressDpLongY(SnesRuntime&,std::uint32_t q)const; std::uint32_t addressStack(std::uint32_t q)const{return(s+q)&0xFFFFu;} std::uint32_t addressStackIndirectY(SnesRuntime&,std::uint32_t q)const;
  void adc(std::uint32_t q){int w=m8?8:16;std::uint32_t mask=w==8?0xFF:0xFFFF,aa=a&mask,r=aa+(q&mask)+(c?1:0);c=r>mask;std::uint32_t rr=r&mask;v=((~(aa^q)&(aa^rr))&(w==8?0x80:0x8000))!=0;setA(rr,w);} void sbc(std::uint32_t q){adc((~q)&(m8?0xFF:0xFFFF));}
  void logicAnd(std::uint32_t q){setA(a&q,m8?8:16);} void logicOr(std::uint32_t q){setA(a|q,m8?8:16);} void logicXor(std::uint32_t q){setA(a^q,m8?8:16);}
  void compare(std::uint32_t lhs,std::uint32_t rhs,int w){std::uint32_t mask=w==8?0xFF:0xFFFF,l=lhs&mask,r=rhs&mask,res=(l-r)&mask;c=l>=r;z=res==0;n=(res&(w==8?0x80:0x8000))!=0;} void compareA(std::uint32_t q){compare(a,q,m8?8:16);} void compareX(std::uint32_t q){compare(x,q,x8?8:16);} void compareY(std::uint32_t q){compare(y,q,x8?8:16);}
  void bit(std::uint32_t q,bool immediate){int w=m8?8:16;std::uint32_t mask=w==8?0xFF:0xFFFF,sign=w==8?0x80:0x8000,ov=w==8?0x40:0x4000,vv=q&mask;z=((a&mask)&vv)==0;if(!immediate){n=(vv&sign)!=0;v=(vv&ov)!=0;}}
  void setFlag(char f,bool q){if(f=='C')c=q;else if(f=='I')i=q;else if(f=='D')decimalMode=q;else if(f=='V')v=q;}
  void enforceEmulation(){if(e){m8=true;x8=true;x&=0x00FFu;y&=0x00FFu;s=(std::uint16_t)(0x0100u|(s&0x00FFu));}}
  void rep(std::uint32_t q){if(!e){if(q&0x20)m8=false;if(q&0x10)x8=false;}if(q&1)c=false;if(q&2)z=false;if(q&4)i=false;if(q&8)decimalMode=false;if(q&0x40)v=false;if(q&0x80)n=false;enforceEmulation();}
  void sep(std::uint32_t q){if(q&0x20)m8=true;if(q&0x10){x8=true;x&=0x00FFu;y&=0x00FFu;}if(q&1)c=true;if(q&2)z=true;if(q&4)i=true;if(q&8)decimalMode=true;if(q&0x40)v=true;if(q&0x80)n=true;enforceEmulation();}
  void xce(){bool olde=e;e=c;c=olde;enforceEmulation();} void inc(char r){if(r=='A')setA(a+1,m8?8:16);else if(r=='X')setX(x+1,x8?8:16);else setY(y+1,x8?8:16);} void decReg(char r){if(r=='A')setA(a-1,m8?8:16);else if(r=='X')setX(x-1,x8?8:16);else setY(y-1,x8?8:16);}
  void transfer(const std::string&t){if(t=="TAX")setX(a,x8?8:16);else if(t=="TXA")setA(x,m8?8:16);else if(t=="TAY")setY(a,x8?8:16);else if(t=="TYA")setA(y,m8?8:16);else if(t=="TXY")setY(x,x8?8:16);else if(t=="TYX")setX(y,x8?8:16);else if(t=="TSX")setX(s,x8?8:16);else if(t=="TXS")s=e?(std::uint16_t)(0x0100u|(x&0x00FFu)):x;}
  void tcd(){d=a;nz(d,16);} void tcs(){s=e?(std::uint16_t)(0x0100u|(a&0x00FFu)):a;} void tdc(){a=d;nz(a,16);} void tsc(){a=s;nz(a,16);} void xba(){a=(std::uint16_t)((a<<8)|(a>>8));nz(a&0xFF,8);} void rolA(){int w=m8?8:16;std::uint32_t mask=w==8?0xFF:0xFFFF,sign=w==8?0x80:0x8000,old=a&mask,r=((old<<1)|(c?1:0))&mask;c=(old&sign)!=0;setA(r,w);} void rorA(){int w=m8?8:16;std::uint32_t mask=w==8?0xFF:0xFFFF,sign=w==8?0x80:0x8000,old=a&mask,r=((old>>1)|(c?sign:0))&mask;c=(old&1u)!=0;setA(r,w);} void aslA(){int w=m8?8:16;std::uint32_t mask=w==8?0xFF:0xFFFF,sign=w==8?0x80:0x8000,old=a&mask;c=(old&sign)!=0;setA((old<<1)&mask,w);} void lsrA(){int w=m8?8:16;std::uint32_t mask=w==8?0xFF:0xFFFF,old=a&mask;c=(old&1u)!=0;setA((old>>1)&mask,w);}
  std::uint8_t packP()const{return(std::uint8_t)((n?0x80:0)|(v?0x40:0)|(m8?0x20:0)|(x8?0x10:0)|(decimalMode?0x08:0)|(i?0x04:0)|(z?0x02:0)|(c?0x01:0));} void unpackP(std::uint8_t p){n=p&0x80;v=p&0x40;m8=p&0x20;x8=p&0x10;decimalMode=p&8;i=p&4;z=p&2;c=p&1;if(x8){x&=0x00FFu;y&=0x00FFu;}enforceEmulation();}
  void push(const std::string&,SnesRuntime&); void pop(const std::string&,SnesRuntime&); void push8Value(SnesRuntime&,std::uint8_t); std::uint8_t pop8Value(SnesRuntime&); std::uint8_t peekStack8(SnesRuntime&,unsigned=1)const; void push16Value(SnesRuntime&,std::uint16_t); std::uint16_t pop16Value(SnesRuntime&); std::uint16_t peekStack16(SnesRuntime&)const; void enterInterrupt(SnesRuntime&,std::uint32_t,bool=false); std::uint32_t returnInterrupt(SnesRuntime&); void incMem(SnesRuntime&,std::uint32_t,int); void decMem(SnesRuntime&,std::uint32_t,int); void aslMem(SnesRuntime&,std::uint32_t,int); void lsrMem(SnesRuntime&,std::uint32_t,int); void rolMem(SnesRuntime&,std::uint32_t,int); void rorMem(SnesRuntime&,std::uint32_t,int); void tsb(SnesRuntime&,std::uint32_t,int); void trb(SnesRuntime&,std::uint32_t,int); void blockMove(SnesRuntime&,std::uint8_t,std::uint8_t,bool);
};
struct PpuState {
  std::uint8_t regs[0x40]{}; std::vector<std::uint8_t> vram=std::vector<std::uint8_t>(0x10000); std::vector<std::uint8_t> cgram=std::vector<std::uint8_t>(512); std::vector<std::uint8_t> oam=std::vector<std::uint8_t>(544);
  std::uint8_t inidisp{},obsel{},bgmode{},mosaic{},vmain{},tm{},ts{},tmw{},tsw{},setini{},bgsc[4]{},bgnba[4]{};
  std::uint8_t m7sel{},w12sel{},w34sel{},wobjsel{},wh[4]{},wbglog{},wobjlog{},cgwsel{},cgadsub{},coldata{};
  std::uint8_t fixedR{},fixedG{},fixedB{}; std::uint16_t m7[6]{}; std::uint8_t m7Latch[6]{}; bool m7High[6]{};
  bool forceBlank{}; std::uint8_t brightness{}; std::uint16_t vmadd{},oamAddr{},vramReadBuffer{},oamWriteRegister{};
  std::uint8_t bgOfsByte{},m7Byte{},cgAddr{},cgSavedByte{}; bool oamFlip{},oamReadFlip{},cgHigh{},cgReadHigh{};
  std::uint16_t scrollX[4]{},scrollY[4]{},hCounter{},vCounter{}; bool hCounterHigh{},vCounterHigh{};
  std::uint16_t vramStep()const{switch(vmain&3){case 0:return 1;case 1:return 32;default:return 128;}}
  std::uint16_t vramMappedWord()const{unsigned mode=(vmain>>2)&3u;if(!mode)return vmadd;static const unsigned count[4]={0,32,64,128},shift[4]={0,5,6,7};unsigned c=count[mode],mask=c*8u-1u,rem=vmadd&mask;return(std::uint16_t)((vmadd&~mask)+(rem>>shift[mode])+((rem&(c-1u))<<3));}
  std::uint16_t vramByteAddress(bool high)const{return(std::uint16_t)(((std::uint32_t)vramMappedWord()*2u+(high?1u:0u))&0xFFFFu);}
  void updateVramReadBuffer(){auto p=vramByteAddress(false);vramReadBuffer=(std::uint16_t)(vram[p]|(vram[(p+1)&0xFFFFu]<<8));}
  void incVram(bool highPort){bool afterHigh=(vmain&0x80)!=0;if(afterHigh==highPort)vmadd=(std::uint16_t)(vmadd+vramStep());}
  void writeScroll(unsigned i,std::uint8_t v){if(i>=8)return;unsigned bg=i>>1;if((i&1u)==0)scrollX[bg]=(std::uint16_t)(((std::uint16_t)v<<8)|(bgOfsByte&~7u)|((scrollX[bg]>>8)&7u));else scrollY[bg]=(std::uint16_t)(((std::uint16_t)v<<8)|bgOfsByte);bgOfsByte=v;if(i<2)m7Byte=v;}
  void writeM7(unsigned i,std::uint8_t v){if(i>=6)return;m7[i]=(std::uint16_t)(m7Byte|((std::uint16_t)v<<8));m7Byte=v;}
  void writeOam(std::uint8_t v){if(!oamFlip)oamWriteRegister=(std::uint16_t)((oamWriteRegister&0xFF00u)|v);if(oamAddr&0x100u){unsigned a=((oamAddr&0x10Fu)<<1)+(oamFlip?1u:0u);if(a<oam.size())oam[a]=v;}else if(oamFlip){oamWriteRegister=(std::uint16_t)((oamWriteRegister&0x00FFu)|((std::uint16_t)v<<8));unsigned a=(oamAddr&0xFFu)<<1;if(a+1<oam.size()){oam[a]=(std::uint8_t)oamWriteRegister;oam[a+1]=(std::uint8_t)(oamWriteRegister>>8);}}oamFlip=!oamFlip;if(!oamFlip)oamAddr=(std::uint16_t)((oamAddr+1)&0x1FFu);}
  std::uint8_t readOam(){unsigned a=(oamAddr&0x100u)?(((oamAddr&0x10Fu)<<1)+(oamReadFlip?1u:0u)):(((oamAddr&0xFFu)<<1)+(oamReadFlip?1u:0u));std::uint8_t v=a<oam.size()?oam[a]:0;oamReadFlip=!oamReadFlip;if(!oamReadFlip)oamAddr=(std::uint16_t)((oamAddr+1)&0x1FFu);return v;}
  void writeCgram(std::uint8_t v){if(!cgHigh)cgSavedByte=v;else{unsigned a=(unsigned)cgAddr*2u;cgram[a&0x1FFu]=cgSavedByte;cgram[(a+1u)&0x1FFu]=v&0x7Fu;cgAddr++;}cgHigh=!cgHigh;}
  std::uint8_t readCgram(){unsigned a=(unsigned)cgAddr*2u;std::uint8_t v=!cgReadHigh?cgram[a&0x1FFu]:(cgram[(a+1u)&0x1FFu]&0x7Fu);if(cgReadHigh)cgAddr++;cgReadHigh=!cgReadHigh;return v;}
  void writeFixedColor(std::uint8_t v){coldata=v;std::uint8_t q=v&31u;if(v&0x20)fixedR=q;if(v&0x40)fixedG=q;if(v&0x80)fixedB=q;}
  void write(std::uint16_t a,std::uint8_t v){if(a>=0x2100&&a<=0x213F)regs[a-0x2100]=v;switch(a){
    case 0x2100:inidisp=v;forceBlank=(v&0x80)!=0;brightness=v&0x0F;break;case 0x2101:obsel=v;break;
    case 0x2102:oamAddr=(std::uint16_t)(((regs[3]&1u)<<8)|v);oamFlip=oamReadFlip=false;break;case 0x2103:oamAddr=(std::uint16_t)(((v&1u)<<8)|regs[2]);oamFlip=oamReadFlip=false;break;case 0x2104:writeOam(v);break;case 0x2105:bgmode=v;break;case 0x2106:mosaic=v;break;
    case 0x2107:case 0x2108:case 0x2109:case 0x210A:bgsc[a-0x2107]=v;break;
    case 0x210B:bgnba[0]=v&0x0F;bgnba[1]=(v>>4)&0x0F;break;case 0x210C:bgnba[2]=v&0x0F;bgnba[3]=(v>>4)&0x0F;break;
    case 0x210D:case 0x210E:case 0x210F:case 0x2110:case 0x2111:case 0x2112:case 0x2113:case 0x2114:writeScroll(a-0x210D,v);break;
    case 0x2115:vmain=v;break;case 0x2116:vmadd=(vmadd&0xFF00)|v;updateVramReadBuffer();break;case 0x2117:vmadd=(vmadd&0x00FF)|((std::uint16_t)v<<8);updateVramReadBuffer();break;
    case 0x2118:vram[vramByteAddress(false)]=v;incVram(false);break;case 0x2119:vram[vramByteAddress(true)]=v;incVram(true);break;
    case 0x211A:m7sel=v;break;case 0x211B:case 0x211C:case 0x211D:case 0x211E:case 0x211F:case 0x2120:writeM7(a-0x211B,v);break;
    case 0x2121:cgAddr=v;cgHigh=cgReadHigh=false;break;case 0x2122:writeCgram(v);break;
    case 0x2123:w12sel=v;break;case 0x2124:w34sel=v;break;case 0x2125:wobjsel=v;break;case 0x2126:case 0x2127:case 0x2128:case 0x2129:wh[a-0x2126]=v;break;case 0x212A:wbglog=v;break;case 0x212B:wobjlog=v;break;
    case 0x212C:tm=v;break;case 0x212D:ts=v;break;case 0x212E:tmw=v;break;case 0x212F:tsw=v;break;case 0x2130:cgwsel=v;break;case 0x2131:cgadsub=v;break;case 0x2132:writeFixedColor(v);break;case 0x2133:setini=v;break;default:break;}}
  std::uint8_t read(std::uint16_t a){switch(a){
    case 0x2134:case 0x2135:case 0x2136:{std::int32_t r=(std::int32_t)(std::int16_t)m7[0]*(std::int32_t)(std::int8_t)(m7[1]>>8);return(std::uint8_t)((r>>((a-0x2134)*8))&0xFF);}
    case 0x2137:hCounterHigh=vCounterHigh=false;return 0;
    case 0x2138:return readOam();
    case 0x2139:{std::uint8_t v=(std::uint8_t)vramReadBuffer;if(!(vmain&0x80u)){updateVramReadBuffer();vmadd=(std::uint16_t)(vmadd+vramStep());}return v;}
    case 0x213A:{std::uint8_t v=(std::uint8_t)(vramReadBuffer>>8);if(vmain&0x80u){updateVramReadBuffer();vmadd=(std::uint16_t)(vmadd+vramStep());}return v;}
    case 0x213B:return readCgram();
    case 0x213C:{std::uint8_t v=!hCounterHigh?(std::uint8_t)hCounter:(std::uint8_t)((hCounter>>8)&1u);hCounterHigh=!hCounterHigh;return v;}
    case 0x213D:{std::uint8_t v=!vCounterHigh?(std::uint8_t)vCounter:(std::uint8_t)((vCounter>>8)&1u);vCounterHigh=!vCounterHigh;return v;}
    case 0x213E:return 0x01u;
    case 0x213F:hCounterHigh=vCounterHigh=false;return 0x03u;
    default:return(a>=0x2100&&a<=0x213F)?regs[a-0x2100]:0;}}
  std::uint32_t color(unsigned idx)const{idx&=0xFF;std::uint16_t c=(std::uint16_t)(cgram[(idx*2)&0x1FF]|((cgram[(idx*2+1)&0x1FF]&0x7F)<<8));return rgba15(c);}
  unsigned tilePixel2(std::uint32_t base,unsigned tile,unsigned x,unsigned y)const{std::uint32_t p=(base+tile*16u+(y&7u)*2u)&0xFFFFu;unsigned bit=7-(x&7u);return ((vram[p]>>bit)&1u)|(((vram[(p+1)&0xFFFFu]>>bit)&1u)<<1);}
  unsigned tilePixel4(std::uint32_t base,unsigned tile,unsigned x,unsigned y)const{std::uint32_t p=(base+tile*32u+(y&7u)*2u)&0xFFFFu;unsigned bit=7-(x&7u);return ((vram[p]>>bit)&1u)|(((vram[(p+1)&0xFFFFu]>>bit)&1u)<<1)|(((vram[(p+16)&0xFFFFu]>>bit)&1u)<<2)|(((vram[(p+17)&0xFFFFu]>>bit)&1u)<<3);}
  unsigned tilePixel8(std::uint32_t base,unsigned tile,unsigned x,unsigned y)const{std::uint32_t p=(base+tile*64u+(y&7u)*2u)&0xFFFFu;unsigned bit=7-(x&7u),q=0;for(unsigned plane=0;plane<8;plane++){unsigned a=(p+(plane>>1)*16u+(plane&1u))&0xFFFFu;q|=((vram[a]>>bit)&1u)<<plane;}return q;}
  struct LayerPixel { std::uint16_t c15{}; std::uint8_t source{5},objPal{},priority{1},oamIndex{255}; bool valid{true}; };
  static int sign13(std::uint16_t q){q&=0x1FFFu;return(q&0x1000u)?(int)q-0x2000:(int)q;}
  static int sign16(std::uint16_t q){return (int)(std::int16_t)q;}
  std::uint16_t palette15(unsigned idx)const{idx&=0xFFu;return(std::uint16_t)(cgram[(idx*2u)&0x1FFu]|((cgram[(idx*2u+1u)&0x1FFu]&0x7Fu)<<8));}
  std::uint16_t directColor15(unsigned pal,unsigned c)const{unsigned r=((c&0x07u)<<2)|((pal&0x01u)<<1),g=((c&0x38u)>>1)|(pal&0x02u),b=((c&0xC0u)>>3)|(pal&0x04u);return(std::uint16_t)((r&31u)|((g&31u)<<5)|((b&31u)<<10));}
  std::uint16_t fixed15()const{return(std::uint16_t)((fixedR&31u)|((fixedG&31u)<<5)|((fixedB&31u)<<10));}
  std::uint32_t rgba15(std::uint16_t c)const{unsigned r=(c&31u)*255u/31u,g=((c>>5)&31u)*255u/31u,b=((c>>10)&31u)*255u/31u,br=brightness;r=r*br/15u;g=g*br/15u;b=b*br/15u;return 0xFF000000u|(r<<16)|(g<<8)|b;}
  static std::uint16_t blend15(std::uint16_t a,std::uint16_t b,bool sub,bool half){int ar=a&31,ag=(a>>5)&31,ab=(a>>10)&31,br=b&31,bg=(b>>5)&31,bb=(b>>10)&31;auto f=[&](int x,int y){int q=sub?x-y:x+y;if(q<0)q=0;if(q>31)q=31;if(half)q>>=1;return q;};return(std::uint16_t)(f(ar,br)|(f(ag,bg)<<5)|(f(ab,bb)<<10));}
  bool pseudoHires()const{return(setini&0x08u)!=0;} bool interlace()const{return(setini&0x01u)!=0;} bool extbg()const{return(setini&0x40u)!=0;}
  unsigned visibleHeight()const{return(setini&0x04u)?239u:224u;} unsigned outputWidth()const{unsigned m=bgmode&7u;return(m==5||m==6||pseudoHires())?512u:256u;} unsigned outputHeight()const{return visibleHeight()*(interlace()?2u:1u);}
  bool insideWin(unsigned n,int x)const{unsigned l=wh[(n&1u)*2u],r=wh[(n&1u)*2u+1u];return l<=r&&x>=(int)l&&x<=(int)r;}
  bool combineWin(std::uint8_t sel,unsigned shift,unsigned logic,int x)const{bool e1=(sel&(1u<<(shift+1)))!=0,i1=(sel&(1u<<shift))!=0,e2=(sel&(1u<<(shift+3)))!=0,i2=(sel&(1u<<(shift+2)))!=0;if(!e1&&!e2)return false;bool w1=insideWin(0,x);if(i1)w1=!w1;bool w2=insideWin(1,x);if(i2)w2=!w2;if(!e1)return w2;if(!e2)return w1;switch(logic&3u){case 0:return w1||w2;case 1:return w1&&w2;case 2:return w1!=w2;default:return w1==w2;}}
  bool layerWindow(unsigned layer,int x)const{if(layer<2)return combineWin(w12sel,layer?4u:0u,(wbglog>>(layer*2u))&3u,x);if(layer<4)return combineWin(w34sel,(layer-2u)?4u:0u,(wbglog>>(layer*2u))&3u,x);if(layer==4)return combineWin(wobjsel,0u,wobjlog&3u,x);return combineWin(wobjsel,4u,(wobjlog>>2)&3u,x);}
  bool hiddenByWindow(unsigned layer,int x,bool sub)const{std::uint8_t mask=sub?tsw:tmw;if(layer>4||!(mask&(1u<<layer)))return false;return layerWindow(layer,x);}
  static bool regionMatch(unsigned mode,bool inside){switch(mode&3u){case 0:return false;case 1:return !inside;case 2:return inside;default:return true;}}
  std::pair<unsigned,unsigned> bgDepth(unsigned bg)const{unsigned m=bgmode&7u;if(m==0){static const unsigned lo[4]={11,10,3,2},hi[4]={15,14,7,6};return{lo[bg&3],hi[bg&3]};}if(m==1){if(bg==0)return{11,15};if(bg==1)return{10,14};if(bg==2)return{3,(bgmode&0x08u)?17u:7u};}if(m>=2&&m<=6){if(bg==0)return{7,15};if(bg==1)return{3,11};}if(m==7){if(bg==0)return{7,7};if(bg==1)return{3,11};}return{1,1};}
  struct BgTileCache { unsigned tileX{},worldY{};bool valid{};std::array<LayerPixel,8> pixels{}; };
  using BgTileRows=std::array<BgTileCache,4>;
  LayerPixel sampleBg(unsigned bg,int sx,int sy,unsigned bpp,unsigned paletteBase=0,bool hires=false,bool allowDirect=false,BgTileCache*cache=nullptr)const{
    LayerPixel p{};p.valid=false;p.source=(std::uint8_t)bg;if(bg>=4)return p;
    unsigned mos=((mosaic>>4)&15u)+1u;if((mosaic&(1u<<bg))&&mos>1u){sx-=sx%(int)mos;sy-=sy%(int)mos;}
    std::uint32_t mapBase=((std::uint32_t)(bgsc[bg]&0xFCu)<<9)&0xFFFFu,charBase=((std::uint32_t)(bgnba[bg]&7u)*0x2000u)&0xFFFFu;
    unsigned sc=bgsc[bg]&3u,mapWTiles=(sc&1u)?64u:32u,mapHTiles=(sc&2u)?64u:32u;bool big=((bgmode>>(4u+bg))&1u)!=0;
    unsigned tileW=(big&&!hires)?16u:8u,tileH=big?16u:8u,mapW=mapWTiles*tileW,mapH=mapHTiles*tileH,wx=(unsigned)(sx+(int)scrollX[bg])&(mapW-1u),wy=(unsigned)(sy+(int)scrollY[bg])&(mapH-1u),tx=wx/tileW,ty=wy/tileH;
    if(cache&&cache->valid&&cache->tileX==(wx>>3)&&cache->worldY==wy)return cache->pixels[wx&7u];
    unsigned screenX=tx>>5,screenY=ty>>5,screen=screenX+screenY*((mapWTiles+31u)>>5),localX=tx&31u,localY=ty&31u;std::uint32_t ep=(mapBase+screen*0x800u+((localY*32u+localX)*2u))&0xFFFFu;
    std::uint16_t e=(std::uint16_t)(vram[ep]|(vram[(ep+1)&0xFFFFu]<<8));unsigned tile=e&0x3FFu,pal=(e>>10)&7u;bool pri=(e&0x2000u)!=0,hf=e&0x4000u,vf=e&0x8000u;
    unsigned px=wx&(tileW-1u),py=wy&(tileH-1u);if(hf)px=tileW-1u-px;if(vf)py=tileH-1u-py;if(big){if(tileW>8u)tile=(tile+(px>>3))&0x3FFu;if(tileH>8u)tile=(tile+((py>>3)<<4))&0x3FFu;}px&=7u;py&=7u;
    if(cache){
      // Decode plane bytes once for this eight-pixel tile row. The cache lives
      // only for a synchronized render segment; VRAM/palette/register writes
      // are therefore visible immediately in the next segment.
      std::array<unsigned,8> planes{};std::uint32_t base=(charBase+tile*(bpp*8u)+py*2u)&0xFFFFu;
      for(unsigned plane=0;plane<bpp;plane++)planes[plane]=vram[(base+(plane>>1)*16u+(plane&1u))&0xFFFFu];
      auto depth=bgDepth(bg);for(unsigned x=0;x<8;x++){
        LayerPixel q{};q.valid=false;q.source=(std::uint8_t)bg;unsigned bit=hf?x:7u-x,ci=0;
        for(unsigned plane=0;plane<bpp;plane++)ci|=((planes[plane]>>bit)&1u)<<plane;
        if(ci){if(bpp==8&&allowDirect&&(cgwsel&1u))q.c15=directColor15(pal,ci);else if(bpp==8)q.c15=palette15(ci);else q.c15=palette15(paletteBase+pal*(bpp==4?16u:4u)+ci);
          q.priority=(std::uint8_t)(pri?depth.second:depth.first);q.valid=true;}
        cache->pixels[x]=q;
      }cache->tileX=wx>>3;cache->worldY=wy;cache->valid=true;return cache->pixels[wx&7u];
    }
    unsigned ci=bpp==8?tilePixel8(charBase,tile,px,py):(bpp==4?tilePixel4(charBase,tile,px,py):tilePixel2(charBase,tile,px,py));if(!ci)return p;
    if(bpp==8&&allowDirect&&(cgwsel&1u))p.c15=directColor15(pal,ci);else if(bpp==8)p.c15=palette15(ci);else if(bpp==4)p.c15=palette15(paletteBase+pal*16u+ci);else p.c15=palette15(paletteBase+pal*4u+ci);
    auto d=bgDepth(bg);p.priority=(std::uint8_t)(pri?d.second:d.first);p.valid=true;return p;
  }
  LayerPixel sampleMode7(unsigned bg,int sx,int sy)const{
    LayerPixel p{};p.valid=false;p.source=(std::uint8_t)bg;int x=(m7sel&1u)?(255-sx):sx,y=(m7sel&2u)?(255-sy):sy;int A=sign16(m7[0]),B=sign16(m7[1]),C=sign16(m7[2]),D=sign16(m7[3]),cx=sign13(m7[4]),cy=sign13(m7[5]),hofs=sign13(scrollX[0]),vofs=sign13(scrollY[0]);
    long dx=(long)x+hofs-cx,dy=(long)y+vofs-cy;long tx=((long)A*dx+(long)B*dy)/256+cx,ty=((long)C*dx+(long)D*dy)/256+cy;bool outside=tx<0||ty<0||tx>1023||ty>1023;unsigned ux,uy,tile;
    if(!(m7sel&0x80u)){ux=(unsigned)tx&1023u;uy=(unsigned)ty&1023u;std::uint32_t mp=(((uy>>3)*128u+(ux>>3))*2u)&0xFFFFu;tile=vram[mp];}else if(outside){if(!(m7sel&0x40u))return p;ux=(unsigned)tx&7u;uy=(unsigned)ty&7u;tile=0;}else{ux=(unsigned)tx;uy=(unsigned)ty;std::uint32_t mp=(((uy>>3)*128u+(ux>>3))*2u)&0xFFFFu;tile=vram[mp];}
    std::uint32_t pp=(((tile*64u)+((uy&7u)*8u)+(ux&7u))*2u+1u)&0xFFFFu;unsigned ci=vram[pp];
    if(bg==1){if(!extbg())return p;bool pri=(ci&0x80u)!=0;ci&=0x7Fu;if(!ci)return p;p.c15=palette15(ci);p.priority=(std::uint8_t)(pri?11u:3u);}
    else{if(!ci)return p;p.c15=(cgwsel&1u)?directColor15(0,ci):palette15(ci);p.priority=7;}
    p.valid=true;return p;
  }
  std::pair<unsigned,unsigned> objDims(bool large)const{unsigned mode=(obsel>>5)&7u;static const unsigned sw[8]={8,8,8,16,16,32,16,16},sh[8]={8,8,8,16,16,32,32,32},lw[8]={16,32,64,32,64,64,32,32},lh[8]={16,32,64,32,64,64,64,32};return large?std::pair<unsigned,unsigned>{lw[mode],lh[mode]}:std::pair<unsigned,unsigned>{sw[mode],sh[mode]};}
  LayerPixel sampleSprites(int sx,int sy)const{
    LayerPixel best{};best.valid=false;best.source=4;std::uint32_t nameBase=(std::uint32_t)(obsel&3u)<<14,nameSelect=(std::uint32_t)((obsel>>3)&3u)<<13;
    for(int si=127;si>=0;--si){unsigned i=(unsigned)si,o=i*4u,hb=oam[512u+(i>>2)],pair=(hb>>((i&3u)*2u))&3u;int x=(int)oam[o]|((pair&1u)?256:0);if(x>=256)x-=512;int y=(int)oam[o+1];unsigned at=oam[o+3],pal=(at>>1)&7u,pri=(at>>4)&3u;auto dim=objDims((pair&2u)!=0);unsigned w=dim.first,h=dim.second;int px=sx-x,py=sy-y;if(px<0||py<0||px>=(int)w||py>=(int)h)continue;
      unsigned qx=(at&0x40u)?(w-1u-(unsigned)px):(unsigned)px,qy=(at&0x80u)?(h-1u-(unsigned)py):(unsigned)py,name=(unsigned)oam[o+2]|((at&1u)<<8),tile=(name&0x100u)|((((name&0xF0u)+((qy>>3)<<4))&0xF0u))|((name+(qx>>3))&0x0Fu),base=nameBase+((tile&0x100u)?nameSelect:0u),ci=tilePixel4(base,tile&0xFFu,qx&7u,qy&7u);std::uint8_t depth=(std::uint8_t)(4u+pri*4u);
      if(ci&&(!best.valid||depth>best.priority||(depth==best.priority&&i<best.oamIndex))){best.c15=palette15(128u+pal*16u+ci);best.objPal=(std::uint8_t)pal;best.priority=depth;best.oamIndex=(std::uint8_t)i;best.valid=true;}}
    return best;
  }
  using SpriteRow=std::array<LayerPixel,256>;
  SpriteRow buildSpriteRow(int sy)const{
    SpriteRow row{};for(auto&q:row){q.valid=false;q.source=4;}
    const std::uint32_t nameBase=(std::uint32_t)(obsel&3u)<<14,nameSelect=(std::uint32_t)((obsel>>3)&3u)<<13;
    for(int si=127;si>=0;--si){unsigned i=(unsigned)si,o=i*4u,hb=oam[512u+(i>>2)],pair=(hb>>((i&3u)*2u))&3u;
      int x=(int)oam[o]|((pair&1u)?256:0);if(x>=256)x-=512;int py=sy-(int)oam[o+1];auto dim=objDims((pair&2u)!=0);unsigned w=dim.first,h=dim.second;
      if(py<0||py>=(int)h){continue;}int left=std::max(0,x),right=std::min(256,x+(int)w);if(left>=right)continue;
      unsigned at=oam[o+3],pal=(at>>1)&7u,pri=(at>>4)&3u,qy=(at&0x80u)?(h-1u-(unsigned)py):(unsigned)py,name=(unsigned)oam[o+2]|((at&1u)<<8);
      const std::uint8_t depth=(std::uint8_t)(4u+pri*4u);
      for(int sx=left;sx<right;sx++){unsigned px=(unsigned)(sx-x),qx=(at&0x40u)?(w-1u-px):px;
        unsigned tile=(name&0x100u)|((((name&0xF0u)+((qy>>3)<<4))&0xF0u))|((name+(qx>>3))&0x0Fu),base=nameBase+((tile&0x100u)?nameSelect:0u),ci=tilePixel4(base,tile&0xFFu,qx&7u,qy&7u);auto&best=row[(unsigned)sx];
        if(ci&&(!best.valid||depth>best.priority||(depth==best.priority&&i<best.oamIndex))){best.c15=palette15(128u+pal*16u+ci);best.objPal=(std::uint8_t)pal;best.priority=depth;best.oamIndex=(std::uint8_t)i;best.valid=true;}
      }
    }return row;
  }
  LayerPixel compose(int x,int y,bool sub,bool hires=false,const SpriteRow*sprites=nullptr,BgTileRows*bgTiles=nullptr)const{
    LayerPixel out{palette15(0),5,0,1,255,true};std::uint8_t en=sub?ts:tm;unsigned mode=bgmode&7u;int wx=hires?(x>>1):x;
    auto take=[&](LayerPixel q){if(q.valid&&q.priority>out.priority)out=q;};
    auto bg=[&](unsigned n,unsigned bpp,unsigned palBase=0,bool dc=false){if(!(en&(1u<<n))||hiddenByWindow(n,wx,sub))return;take(sampleBg(n,x,y,bpp,palBase,hires,dc,bgTiles?&(*bgTiles)[n]:nullptr));};
    switch(mode){
      case 0:bg(3,2,96);bg(2,2,64);bg(1,2,32);bg(0,2,0);break;
      case 1:bg(2,2);bg(1,4);bg(0,4);break;
      case 2:bg(1,4);bg(0,4);break;
      case 3:bg(1,4);bg(0,8,0,true);break;
      case 4:bg(1,2);bg(0,8,0,true);break;
      case 5:bg(1,2);bg(0,4);break;
      case 6:bg(0,4);break;
      case 7:if((en&1u)&&!hiddenByWindow(0,wx,sub))take(sampleMode7(0,x,y));if((en&2u)&&!hiddenByWindow(1,wx,sub))take(sampleMode7(1,x,y));break;
    }
    if((en&0x10u)&&!hiddenByWindow(4,wx,sub)){int ox=hires?(x>>1):x;take(sprites&&ox>=0&&ox<256?(*sprites)[(unsigned)ox]:sampleSprites(ox,y));}return out;
  }
  std::uint16_t finalMain15(int x,int y,bool hires=false,const SpriteRow*sprites=nullptr,BgTileRows*bgTiles=nullptr)const{
    int wx=hires?(x>>1):x;bool cw=layerWindow(5,wx);auto main=compose(x,y,false,hires,sprites,bgTiles);if(regionMatch((cgwsel>>6)&3u,cw))main.c15=0;
    bool math=false;if(main.source<=3)math=(cgadsub&(1u<<main.source))!=0;else if(main.source==4)math=(cgadsub&0x10u)&&main.objPal>=4;else math=(cgadsub&0x20u)!=0;std::uint16_t result=main.c15;
    if(math){bool masked=regionMatch((cgwsel>>4)&3u,cw);LayerPixel subPixel{};if(cgwsel&0x02u)subPixel=compose(x,y,true,hires,sprites,bgTiles);std::uint16_t add=0;if(!masked)add=(cgwsel&0x02u)?subPixel.c15:fixed15();bool half=(cgadsub&0x40u)!=0;if((cgwsel&0x02u)&&subPixel.source==5)half=false;result=blend15(result,add,(cgadsub&0x80u)!=0,half);}return result;
  }
  void renderScanline(std::vector<std::uint32_t>&fb,int y,int w=256)const{if(y<0)return;if(fb.size()<(std::size_t)w*(y+1))fb.resize((std::size_t)w*(y+1),0xFF000000u);for(int x=0;x<w;x++){if(forceBlank||brightness==0){fb[(std::size_t)y*w+x]=0xFF000000u;continue;}fb[(std::size_t)y*w+x]=rgba15(finalMain15(x,y,false));}}
  void renderOutputSegment(std::vector<std::uint32_t>&fb,int y,unsigned x0,unsigned x1,unsigned field=0)const{
    if(y<0||(unsigned)y>=visibleHeight()){return;}unsigned ow=outputWidth(),oh=outputHeight(),row=interlace()?((unsigned)y*2u+(field&1u)):(unsigned)y;if(fb.size()<(std::size_t)ow*oh)fb.resize((std::size_t)ow*oh,0xFF000000u);x0=std::min(x0,ow);x1=std::min(x1,ow);if(x1<=x0)return;
    if(forceBlank||brightness==0){for(unsigned x=x0;x<x1;x++)fb[(std::size_t)row*ow+x]=0xFF000000u;return;}
    unsigned mode=bgmode&7u;int sy=((mode==5||mode==6)&&interlace())?((int)y*2+(int)(field&1u)):y;
    BgTileRows bgTiles{};
    // Segment-local row: rebuilt after every synchronized PPU mutation.
    SpriteRow spriteRow;const SpriteRow*sprites=nullptr;if((tm|ts)&0x10u){spriteRow=buildSpriteRow(sy);sprites=&spriteRow;}
    if(mode==5||mode==6){for(unsigned x=x0;x<x1;x++)fb[(std::size_t)row*ow+x]=rgba15(finalMain15((int)x,sy,true,sprites,&bgTiles));return;}
    if(pseudoHires()){for(unsigned ox=x0;ox<x1;ox++){unsigned lx=ox>>1;if((ox&1u)==0){auto sub=compose((int)lx,y,true,false,sprites,&bgTiles);fb[(std::size_t)row*ow+ox]=rgba15(sub.c15);}else fb[(std::size_t)row*ow+ox]=rgba15(finalMain15((int)lx,y,false,sprites,&bgTiles));}return;}
    for(unsigned x=x0;x<x1;x++)fb[(std::size_t)row*ow+x]=rgba15(finalMain15((int)x,y,false,sprites,&bgTiles));
  }
  void renderOutputScanline(std::vector<std::uint32_t>&fb,int y,unsigned field=0)const{renderOutputSegment(fb,y,0,outputWidth(),field);}
  std::vector<std::uint32_t> renderFrame(int w=256,int h=224)const{std::vector<std::uint32_t>fb((std::size_t)w*h,0xFF000000u);for(int y=0;y<h;y++)renderScanline(fb,y,w);return fb;}
  std::vector<std::uint32_t> renderNativeFrame(unsigned field=0)const{std::vector<std::uint32_t>fb((std::size_t)outputWidth()*outputHeight(),0xFF000000u);for(unsigned y=0;y<visibleHeight();y++)renderOutputScanline(fb,(int)y,field);return fb;}
  bool savePpm(const std::string&path,int w=256,int h=224)const{auto fb=renderFrame(w,h);std::ofstream f(path,std::ios::binary);if(!f)return false;f<<"P6\n"<<w<<" "<<h<<"\n255\n";for(auto p:fb){char q[3]={(char)((p>>16)&255),(char)((p>>8)&255),(char)(p&255)};f.write(q,3);}return(bool)f;}

};
struct CpuIoState {
  std::uint8_t nmitimen{},wrio{0xFF},mdmaen{},hdmaen{},memsel{},wrmpya{},wrmpyb{},wrdivb{};
  std::uint16_t wrdiv{},quotient{},remainder{},product{},htime{},vtime{}; std::uint32_t wramPortAddr{};
  bool nmiEnable{},vIrqEnable{},hIrqEnable{},autoJoypad{},nmiPending{},irqPending{},vblank{},hblank{},joyStrobe{};
  std::uint16_t joy[4]{},joyShift[2]{};
  void setNmitimen(std::uint8_t v){nmitimen=v;nmiEnable=v&0x80;vIrqEnable=v&0x20;hIrqEnable=v&0x10;autoJoypad=v&1;}
  void multiply(std::uint8_t v){wrmpyb=v;product=(std::uint16_t)(std::uint16_t(wrmpya)*std::uint16_t(wrmpyb));remainder=product;}
  void divide(std::uint8_t v){wrdivb=v;if(v==0){quotient=0xFFFF;remainder=wrdiv;}else{quotient=(std::uint16_t)(wrdiv/v);remainder=(std::uint16_t)(wrdiv%v);}}
  void latchJoy(){joyShift[0]=joy[0];joyShift[1]=joy[1];}
  void setJoyStrobe(bool v){if(v||joyStrobe)latchJoy();joyStrobe=v;}
  std::uint8_t readJoySerial(unsigned p){p&=1;if(joyStrobe)latchJoy();std::uint8_t bit=(joyShift[p]&0x8000u)?1u:0u;if(!joyStrobe)joyShift[p]=(std::uint16_t)((joyShift[p]<<1)|1u);return bit;}
};
struct SpcDsp {
  struct Voice { bool active{}; std::uint16_t addr{},loop{}; std::uint8_t blockPos{16},header{}; std::int16_t hist1{},hist2{}; std::int16_t decoded[16]{}; std::uint32_t phase{}; };
  std::uint8_t regs[128]{}; Voice voice[8]{};
  static std::int16_t clamp16(int v){if(v>32767)return 32767;if(v<-32768)return -32768;return (std::int16_t)v;}
  void writeReg(std::uint8_t a,std::uint8_t v,std::vector<std::uint8_t>&ram){a&=0x7F;regs[a]=v;if(a==0x4C){for(unsigned i=0;i<8;i++)if(v&(1u<<i))keyOn(i,ram);}else if(a==0x5C){for(unsigned i=0;i<8;i++)if(v&(1u<<i))voice[i].active=false;}}
  std::uint8_t readReg(std::uint8_t a)const{return regs[a&0x7F];}
  void keyOn(unsigned i,std::vector<std::uint8_t>&ram){auto&v=voice[i&7u];unsigned base=(unsigned)regs[0x5D]*0x100u+(unsigned)regs[(i<<4)|4]*4u;v.addr=(std::uint16_t)(ram[base&0xFFFFu]|(ram[(base+1)&0xFFFFu]<<8));v.loop=(std::uint16_t)(ram[(base+2)&0xFFFFu]|(ram[(base+3)&0xFFFFu]<<8));v.blockPos=16;v.hist1=v.hist2=0;v.phase=0;v.active=true;}
  void decodeBlock(Voice&v,std::vector<std::uint8_t>&ram){v.header=ram[v.addr];unsigned range=v.header>>4,filter=(v.header>>2)&3;for(unsigned n=0;n<16;n++){std::uint8_t b=ram[(v.addr+1+(n>>1))&0xFFFFu];int nib=(n&1)?(b&0x0F):(b>>4);if(nib&8)nib-=16;int s=(range<=12)?((nib<<range)>>1):(nib<0?-2048:0);if(filter==1)s+=v.hist1+((-v.hist1)>>4);else if(filter==2)s+=(v.hist1<<1)+((-3*v.hist1)>>5)-v.hist2+(v.hist2>>4);else if(filter==3)s+=(v.hist1<<1)+((-13*v.hist1)>>6)-v.hist2+((3*v.hist2)>>4);s=clamp16(s);v.decoded[n]=clamp16(s<<1);v.hist2=v.hist1;v.hist1=v.decoded[n];}v.addr=(std::uint16_t)(v.addr+9);v.blockPos=0;}
  std::int16_t nextSample(unsigned i,std::vector<std::uint8_t>&ram){auto&v=voice[i&7u];if(!v.active)return 0;unsigned pitch=(unsigned)regs[(i<<4)|2]|(((unsigned)regs[(i<<4)|3]&0x3F)<<8);v.phase+=pitch;while(v.phase>=0x1000u){v.phase-=0x1000u;if(v.blockPos>=16){bool end=v.header&1u,looping=v.header&2u;if(end){if(looping){v.addr=v.loop;v.blockPos=16;}else{v.active=false;return 0;}}decodeBlock(v,ram);}else v.blockPos++;}if(v.blockPos>=16)decodeBlock(v,ram);unsigned idx=v.blockPos<16?v.blockPos:15;int env=0x7FF;std::uint8_t adsr1=regs[(i<<4)|5],gain=regs[(i<<4)|7];if(!(adsr1&0x80)&&!(gain&0x80))env=(gain&0x7F)<<4;int s=(int)v.decoded[idx]*env/0x7FF;regs[(i<<4)|9]=(std::uint8_t)(s>>8);return clamp16(s);}
  std::vector<std::int16_t> render(std::vector<std::uint8_t>&ram,unsigned frames){std::vector<std::int16_t>out;out.reserve((std::size_t)frames*2);int mvl=(std::int8_t)regs[0x0C],mvr=(std::int8_t)regs[0x1C];for(unsigned n=0;n<frames;n++){int l=0,r=0;for(unsigned i=0;i<8;i++){int s=nextSample(i,ram);l+=s*(std::int8_t)regs[(i<<4)|0]/127;r+=s*(std::int8_t)regs[(i<<4)|1]/127;}l=l*mvl/127;r=r*mvr/127;out.push_back(clamp16(l));out.push_back(clamp16(r));}return out;}
  static bool saveWav(const std::string&path,const std::vector<std::int16_t>&pcm,unsigned rate=32000){if(pcm.empty())return false;std::ofstream f(path,std::ios::binary);if(!f)return false;auto w16=[&](std::uint16_t v){char b[2]={(char)v,(char)(v>>8)};f.write(b,2);};auto w32=[&](std::uint32_t v){char b[4]={(char)v,(char)(v>>8),(char)(v>>16),(char)(v>>24)};f.write(b,4);};std::uint32_t data=(std::uint32_t)(pcm.size()*2);f.write("RIFF",4);w32(36+data);f.write("WAVEfmt ",8);w32(16);w16(1);w16(2);w32(rate);w32(rate*4);w16(4);w16(16);f.write("data",4);w32(data);f.write((const char*)pcm.data(),data);return(bool)f;}
};
inline constexpr std::uint8_t kForja65Ipl[64] = {
  0xCD,0xEF,0xBD,0xE8,0x00,0xC6,0x1D,0xD0,0xFC,0x8F,0xAA,0xF4,0x8F,0xBB,0xF5,0x78,
  0xCC,0xF4,0xD0,0xFB,0x2F,0x19,0xEB,0xF4,0xD0,0xFC,0x7E,0xF4,0xD0,0x0B,0xE4,0xF5,
  0xCB,0xF4,0xD7,0x00,0xFC,0xD0,0xF3,0xAB,0x01,0x10,0xEF,0x7E,0xF4,0x10,0xEB,0xBA,
  0xF6,0xDA,0x00,0xBA,0xF4,0xC4,0xF4,0xDD,0x5D,0xD0,0xDB,0x1F,0x00,0x00,0xC0,0xFF};
struct SpcStateRuntime {
  std::vector<std::uint8_t> ram=std::vector<std::uint8_t>(65536); std::uint8_t dsp[128]{};
  std::uint16_t pc{0xFFC0},ya{}; std::uint8_t x{},sp{0xEF},psw{},control{0x80},dspAddr{};
  std::uint8_t portIn[4]{},portOut[4]{},timerOut[3]{},timerTarget[3]{}; int timerDiv[3]{},timerStage[3]{}; bool timersOn[3]{};
  std::uint8_t a()const{return(std::uint8_t)(ya&0xFFu);} std::uint8_t y()const{return(std::uint8_t)(ya>>8);}
  void setA(std::uint8_t v){ya=(std::uint16_t)((ya&0xFF00u)|v);} void setY(std::uint8_t v){ya=(std::uint16_t)((ya&0x00FFu)|(std::uint16_t(v)<<8));}
};
struct ApuBridge {
  using NativeStepHook=void(*)(ApuBridge&,unsigned);
  SpcStateRuntime spc; SpcDsp dsp; bool dirty[4]{}; NativeStepHook nativeStepHook{};
  bool transferStarted{},nativeDspEnabled{}; std::uint16_t uploadBase{},lastPorts23{},entryCandidate{}; std::size_t uploadCount{}; std::uint8_t lastCounter{},keyOn{},keyOff{}; std::uint64_t spcMasterRemainder{},nativeMasterCycles{},fallbackMasterCycles{},dspMasterRemainder{},dspNativeSamples{},dspFallbackSamples{}; std::vector<std::int16_t> nativePcm;
  static constexpr unsigned DSP_SAMPLE_MASTER_CYCLES=671u;
  void setNativeStepHook(NativeStepHook fn){nativeStepHook=fn;} bool nativeBackendReady()const{return nativeStepHook!=nullptr;} bool nativeDspReady()const{return nativeDspEnabled;}
  void setNativeDsp(bool on){nativeDspEnabled=on;}
  void tickDspMasterCycles(unsigned masterCycles){dspMasterRemainder+=masterCycles;while(dspMasterRemainder>=DSP_SAMPLE_MASTER_CYCLES){dspMasterRemainder-=DSP_SAMPLE_MASTER_CYCLES;if(!nativeDspEnabled){dspFallbackSamples++;continue;}auto q=dsp.render(spc.ram,1);if(q.size()==2){nativePcm.push_back(q[0]);nativePcm.push_back(q[1]);dspNativeSamples++;}}}
  bool saveNativeAudioWav(const std::string&path)const{return SpcDsp::saveWav(path,nativePcm,32000);}
  void write(unsigned i,std::uint8_t v){if(i>=4)return;spc.portIn[i]=v;dirty[i]=true;if(i==2||i==3)lastPorts23=(std::uint16_t)(spc.portIn[2]|(spc.portIn[3]<<8));if(i==0){if(!transferStarted){transferStarted=true;uploadBase=lastPorts23;uploadCount=0;}if(v!=lastCounter||uploadCount==0){uploadCount++;if(spc.portIn[1]==0)entryCandidate=lastPorts23;}lastCounter=v;}}
  std::uint8_t read(unsigned i)const{return i<4?spc.portOut[i]:0;}
  std::uint8_t spcRead(std::uint16_t a){if(a>=0xFFC0u&&(spc.control&0x80u))return kForja65Ipl[a-0xFFC0u];if(a==0xF2)return spc.dspAddr;if(a==0xF3)return dsp.readReg(spc.dspAddr);if(a>=0xF4&&a<=0xF7)return spc.portIn[a-0xF4];return spc.ram[a];}
  void spcWrite(std::uint16_t a,std::uint8_t v){if(a==0xF1){if(v&0x10){spc.portIn[0]=spc.portIn[1]=0;}if(v&0x20){spc.portIn[2]=spc.portIn[3]=0;}spc.control=v;for(int i=0;i<3;i++)spc.timersOn[i]=(v&(1u<<i))!=0;return;}if(a==0xF2){spc.dspAddr=v;return;}if(a==0xF3){spc.dsp[spc.dspAddr&0x7Fu]=v;dsp.writeReg(spc.dspAddr,v,spc.ram);return;}if(a>=0xF4&&a<=0xF7){spc.portOut[a-0xF4]=v;spc.ram[a]=v;return;}if(a>=0xFA&&a<=0xFC){spc.timerTarget[a-0xFA]=v;return;}spc.ram[a]=v;}
  void tickMasterCycles(unsigned masterCycles);
  bool saveDump(const std::string&path)const{if(!uploadCount)return false;std::ofstream f(path,std::ios::binary);if(!f)return false;f.write((const char*)spc.ram.data(),(std::streamsize)spc.ram.size());return(bool)f;}
  bool saveSnapshot(const std::string&binPath,const std::string&manifestPath)const{std::ofstream b(binPath,std::ios::binary|std::ios::trunc);if(!b)return false;b.write((const char*)spc.ram.data(),(std::streamsize)spc.ram.size());b.close();std::ofstream f(manifestPath,std::ios::trunc);if(!f)return false;f<<"entry=0x"<<std::hex<<spc.pc<<"\n"<<"pc=0x"<<spc.pc<<"\n"<<"a=0x"<<(unsigned)spc.a()<<"\n"<<"x=0x"<<(unsigned)spc.x<<"\n"<<"y=0x"<<(unsigned)spc.y()<<"\n"<<"sp=0x"<<(unsigned)spc.sp<<"\n"<<"psw=0x"<<(unsigned)spc.psw<<"\n"<<"upload_base=0x"<<uploadBase<<"\n"<<"upload_count="<<std::dec<<uploadCount<<"\n"<<"entry_candidate=0x"<<std::hex<<entryCandidate<<"\n"<<"native_backend_ready="<<(nativeBackendReady()?1:0)<<"\n";return(bool)f;}
  bool saveManifest(const std::string&path)const{if(!uploadCount)return false;std::ofstream f(path);if(!f)return false;f<<"upload_base=0x"<<std::hex<<uploadBase<<"\n"<<"upload_count="<<std::dec<<uploadCount<<"\n"<<"entry_candidate=0x"<<std::hex<<entryCandidate<<"\n"<<"dsp_backend=BRR_BASIC_8VOICE\n"<<"dsp_native_clock="<<(nativeDspReady()?1:0)<<"\n"<<"dsp_native_samples="<<dspNativeSamples<<"\n"<<"spc700_runtime=FULL_INTERPRETER_256_OPCODES\n"<<"native_hook_ready="<<(nativeBackendReady()?1:0)<<"\n"<<"cpu_port_shadow_write=DISABLED_HARDWARE_CORRECT\n";return(bool)f;}
};

static constexpr std::uint8_t CN=0x80,CV=0x40,CP=0x20,CB=0x10,CH=0x08,CI=0x04,CZ=0x02,CC=0x01;
static std::uint8_t sa(const ApuBridge& s) { return s.spc.a(); }
static void sZN(ApuBridge& s, std::uint8_t v) { s.spc.psw = (s.spc.psw & ~(CN | CZ)) | (v & CN) | (v ? 0 : CZ); }
static std::uint16_t sdp(const ApuBridge& s) { return (s.spc.psw & CP) ? 0x100 : 0; }

static std::uint8_t sr(ApuBridge& s, std::uint16_t a) {
    if (a >= 0xFFC0 && (s.spc.control & 0x80)) return kForja65Ipl[a - 0xFFC0];
    if (a >= 0xF0 && a <= 0xFF) {
        switch (a) {
        case 0xF2: return s.spc.dspAddr;
        case 0xF3: return s.dsp.readReg(s.spc.dspAddr);
        case 0xF4: case 0xF5: case 0xF6: case 0xF7: return s.spc.portIn[a - 0xF4];
        case 0xFD: case 0xFE: case 0xFF: {
            int i = a - 0xFD;
            if ((s.spc.timerOut[i] & 0x0F) == 0) s.spc.timerOut[i] = 1;
            std::uint8_t v = s.spc.timerOut[i] & 0x0F; s.spc.timerOut[i] = 0; return v;
        }
        default: return s.spc.ram[a];
        }
    }
    return s.spc.ram[a];
}
static void sw(ApuBridge& s, std::uint16_t a, std::uint8_t v) {
    if (a >= 0xF0 && a <= 0xFF) {
        switch (a) {
        case 0xF1:
            if (v & 0x10) { s.spc.portIn[0] = s.spc.portIn[1] = 0; }
            if (v & 0x20) { s.spc.portIn[2] = s.spc.portIn[3] = 0; }
            s.spc.control = v;
            for (int i = 0; i < 3; i++) s.spc.timersOn[i] = (v & (1 << i)) != 0;
            return;
        case 0xF2: s.spc.dspAddr = v; return;
        case 0xF3:
            s.spc.dsp[s.spc.dspAddr & 0x7F] = v; s.dsp.writeReg(s.spc.dspAddr, v, s.spc.ram);
            if ((s.spc.dspAddr & 0x7F) == 0x4C) s.keyOn = v;
            if ((s.spc.dspAddr & 0x7F) == 0x5C) s.keyOff = v;
            return;
        case 0xF4: case 0xF5: case 0xF6: case 0xF7: s.spc.portOut[a - 0xF4] = v; s.spc.ram[a] = v; return;
        case 0xFA: case 0xFB: case 0xFC: s.spc.timerTarget[a - 0xFA] = v; return;
        default: break;
        }
    }
    s.spc.ram[a] = v;
}
static std::uint16_t sr16(ApuBridge& s, std::uint16_t a) { return sr(s, a) | (std::uint16_t(sr(s, std::uint16_t(a + 1))) << 8); }
static void sw16(ApuBridge& s, std::uint16_t a, std::uint16_t v) { sw(s, a, v & 0xFF); sw(s, std::uint16_t(a + 1), v >> 8); }
static std::uint8_t sf(ApuBridge& s) { return sr(s, s.spc.pc++); }
static std::uint16_t sf16(ApuBridge& s) { std::uint8_t l = sf(s); return l | (std::uint16_t(sf(s)) << 8); }
static void spush(ApuBridge& s, std::uint8_t v) { sw(s, 0x100 | s.spc.sp, v); s.spc.sp--; }
static std::uint8_t spull(ApuBridge& s) { s.spc.sp++; return sr(s, 0x100 | s.spc.sp); }
static std::uint16_t ya(const ApuBridge& s) { return s.spc.ya; }
static void setYa(ApuBridge& s, std::uint16_t v) { s.spc.ya = v; }

static void adc(ApuBridge& s, std::uint8_t v) {
    int c = (s.spc.psw & CC) ? 1 : 0, a = sa(s), sum = a + v + c;
    s.spc.psw = (s.spc.psw & ~CH) | (((a & 15) + (v & 15) + c > 15) ? CH : 0);
    s.spc.psw = (s.spc.psw & ~CV) | ((~(a ^ v) & (a ^ sum) & 0x80) ? CV : 0);
    s.spc.psw = (s.spc.psw & ~CC) | (sum > 255 ? CC : 0);
    s.spc.setA(sum & 255); sZN(s, s.spc.a());
}
static void sbc(ApuBridge& s, std::uint8_t v) {
    int c = (s.spc.psw & CC) ? 1 : 0, a = sa(s), sum = a - v - (1 - c);
    s.spc.psw = (s.spc.psw & ~CH) | (((a & 15) - (v & 15) - (1 - c) < 0) ? 0 : CH);
    s.spc.psw = (s.spc.psw & ~CV) | (((a ^ v) & (a ^ sum) & 0x80) ? CV : 0);
    s.spc.psw = (s.spc.psw & ~CC) | (sum >= 0 ? CC : 0);
    s.spc.setA(sum & 255); sZN(s, s.spc.a());
}
static void cmp(ApuBridge& s, std::uint8_t a, std::uint8_t b) { s.spc.psw = (s.spc.psw & ~CC) | (a >= b ? CC : 0); sZN(s, std::uint8_t(a - b)); }
static void logicMem(ApuBridge& s, std::uint16_t addr, std::uint8_t b, int kind) {
    std::uint8_t m = sr(s, addr), r = kind == 0 ? (m | b) : kind == 1 ? (m & b) : kind == 2 ? (m ^ b) : std::uint8_t(m - b);
    if (kind == 3) cmp(s, m, b); else { sw(s, addr, r); sZN(s, r); }
}

inline int forja65SpcStep(ApuBridge& s) {
    std::uint8_t op = sf(s);
    auto dp = [&]() { return std::uint16_t(sdp(s) + sf(s)); };
    auto dpx = [&]() { return std::uint16_t(sdp(s) + std::uint8_t(sf(s) + s.spc.x)); };
    auto dpy = [&]() { return std::uint16_t(sdp(s) + std::uint8_t(sf(s) + s.spc.y())); };
    auto absx = [&]() { return std::uint16_t(sf16(s) + s.spc.x); };
    auto absy = [&]() { return std::uint16_t(sf16(s) + s.spc.y()); };
    auto ix = [&]() { return std::uint16_t(s.spc.x); };
    auto idpx = [&]() { return sr16(s, std::uint16_t(sdp(s) + std::uint8_t(sf(s) + s.spc.x))); };
    auto idpy = [&]() { return std::uint16_t(sr16(s, dp()) + s.spc.y()); };
    auto bitAddr = [&]() { std::uint16_t a = sf16(s); return std::pair<std::uint16_t, int>(a & 0x1FFF, a >> 13); };
    switch (op) {
    case 0x00: break;
    case 0x01: case 0x11: case 0x21: case 0x31: case 0x41: case 0x51: case 0x61: case 0x71:
    case 0x81: case 0x91: case 0xA1: case 0xB1: case 0xC1: case 0xD1: case 0xE1: case 0xF1: {
        int n = op >> 4; spush(s, s.spc.pc >> 8); spush(s, s.spc.pc & 0xFF);
        s.spc.pc = sr16(s, 0xFFDE - n * 2); break; }
    case 0x02: case 0x22: case 0x42: case 0x62: case 0x82: case 0xA2: case 0xC2: case 0xE2: { std::uint16_t a = dp(); sw(s, a, sr(s, a) | (1 << (op >> 5))); break; }
    case 0x12: case 0x32: case 0x52: case 0x72: case 0x92: case 0xB2: case 0xD2: case 0xF2: { std::uint16_t a = dp(); sw(s, a, sr(s, a) & ~(1 << ((op >> 5) & 7))); break; }
    case 0x03: case 0x23: case 0x43: case 0x63: case 0x83: case 0xA3: case 0xC3: case 0xE3: { std::uint16_t a = dp(); std::int8_t r = sf(s); if (sr(s, a) & (1 << (op >> 5))) s.spc.pc += r; break; }
    case 0x13: case 0x33: case 0x53: case 0x73: case 0x93: case 0xB3: case 0xD3: case 0xF3: { std::uint16_t a = dp(); std::int8_t r = sf(s); if (!(sr(s, a) & (1 << ((op >> 5) & 7)))) s.spc.pc += r; break; }
    case 0x04: s.spc.setA(sa(s) | sr(s, dp())); sZN(s, sa(s)); break;
    case 0x05: s.spc.setA(sa(s) | sr(s, sf16(s))); sZN(s, sa(s)); break;
    case 0x06: s.spc.setA(sa(s) | sr(s, ix())); sZN(s, sa(s)); break;
    case 0x07: s.spc.setA(sa(s) | sr(s, idpx())); sZN(s, sa(s)); break;
    case 0x08: s.spc.setA(sa(s) | sf(s)); sZN(s, sa(s)); break;
    case 0x09: { std::uint16_t d = dp(), src = dp(); logicMem(s, d, sr(s, src), 0); break; }
    case 0x0A: { auto [a, b] = bitAddr(); if (sr(s, a) & (1 << b)) s.spc.psw |= CC; break; }
    case 0x0B: { std::uint16_t a = dp(); std::uint8_t v = sr(s, a); s.spc.psw = (s.spc.psw & ~CC) | (v >> 7); v <<= 1; sw(s, a, v); sZN(s, v); break; }
    case 0x0C: { std::uint16_t a = sf16(s); std::uint8_t v = sr(s, a); s.spc.psw = (s.spc.psw & ~CC) | (v >> 7); v <<= 1; sw(s, a, v); sZN(s, v); break; }
    case 0x0D: spush(s, s.spc.psw); break;
    case 0x0E: { std::uint16_t a = sf16(s); std::uint8_t m = sr(s, a); sZN(s, sa(s) & m); sw(s, a, m | sa(s)); break; }
    case 0x0F: spush(s, s.spc.pc >> 8); spush(s, s.spc.pc & 0xFF); spush(s, s.spc.psw); s.spc.psw |= CI | CB; s.spc.pc = sr16(s, 0xFFDE); break;
    case 0x10: { std::int8_t r = sf(s); if (!(s.spc.psw & CN)) s.spc.pc += r; break; }
    case 0x14: s.spc.setA(sa(s) | sr(s, dpx())); sZN(s, sa(s)); break;
    case 0x15: s.spc.setA(sa(s) | sr(s, absx())); sZN(s, sa(s)); break;
    case 0x16: s.spc.setA(sa(s) | sr(s, absy())); sZN(s, sa(s)); break;
    case 0x17: s.spc.setA(sa(s) | sr(s, idpy())); sZN(s, sa(s)); break;
    case 0x18: { std::uint8_t imm = sf(s); std::uint16_t a = dp(); std::uint8_t v = sr(s, a) | imm; sw(s, a, v); sZN(s, v); break; }
    case 0x19: { std::uint8_t v = sr(s, s.spc.x) | sr(s, s.spc.y()); sw(s, s.spc.x, v); sZN(s, v); break; }
    case 0x1A: { std::uint16_t a = dp(); std::uint16_t v = sr16(s, a) - 1; sw16(s, a, v); sZN(s, v >> 8); s.spc.psw = (s.spc.psw & ~CZ) | (v ? 0 : CZ); break; }
    case 0x1B: { std::uint16_t a = dpx(); std::uint8_t v = sr(s, a); s.spc.psw = (s.spc.psw & ~CC) | (v >> 7); v <<= 1; sw(s, a, v); sZN(s, v); break; }
    case 0x1C: { std::uint8_t v = sa(s); s.spc.psw = (s.spc.psw & ~CC) | (v >> 7); s.spc.setA(v << 1); sZN(s, sa(s)); break; }
    case 0x1D: s.spc.x--; sZN(s, s.spc.x); break;
    case 0x1E: cmp(s, s.spc.x, sr(s, sf16(s))); break;
    case 0x1F: s.spc.pc = sr16(s, std::uint16_t(sf16(s) + s.spc.x)); break;
    case 0x20: s.spc.psw &= ~CP; break;
    case 0x24: s.spc.setA(sa(s) & sr(s, dp())); sZN(s, sa(s)); break;
    case 0x25: s.spc.setA(sa(s) & sr(s, sf16(s))); sZN(s, sa(s)); break;
    case 0x26: s.spc.setA(sa(s) & sr(s, ix())); sZN(s, sa(s)); break;
    case 0x27: s.spc.setA(sa(s) & sr(s, idpx())); sZN(s, sa(s)); break;
    case 0x28: s.spc.setA(sa(s) & sf(s)); sZN(s, sa(s)); break;
    case 0x29: { std::uint16_t d = dp(), src = dp(); logicMem(s, d, sr(s, src), 1); break; }
    case 0x2A: { auto [a, b] = bitAddr(); if (!(sr(s, a) & (1 << b))) s.spc.psw |= CC; break; }
    case 0x2B: { std::uint16_t a = dp(); std::uint8_t v = sr(s, a); int c = s.spc.psw & CC ? 1 : 0; s.spc.psw = (s.spc.psw & ~CC) | (v >> 7); v = (v << 1) | c; sw(s, a, v); sZN(s, v); break; }
    case 0x2C: { std::uint16_t a = sf16(s); std::uint8_t v = sr(s, a); int c = s.spc.psw & CC ? 1 : 0; s.spc.psw = (s.spc.psw & ~CC) | (v >> 7); v = (v << 1) | c; sw(s, a, v); sZN(s, v); break; }
    case 0x2D: spush(s, sa(s)); break;
    case 0x2E: { std::uint16_t a = dp(); std::int8_t r = sf(s); if (sr(s, a) != sa(s)) s.spc.pc += r; break; }
    case 0x2F: { std::int8_t r = sf(s); s.spc.pc += r; break; }
    case 0x30: { std::int8_t r = sf(s); if (s.spc.psw & CN) s.spc.pc += r; break; }
    case 0x34: s.spc.setA(sa(s) & sr(s, dpx())); sZN(s, sa(s)); break;
    case 0x35: s.spc.setA(sa(s) & sr(s, absx())); sZN(s, sa(s)); break;
    case 0x36: s.spc.setA(sa(s) & sr(s, absy())); sZN(s, sa(s)); break;
    case 0x37: s.spc.setA(sa(s) & sr(s, idpy())); sZN(s, sa(s)); break;
    case 0x38: { std::uint8_t imm = sf(s); std::uint16_t a = dp(); std::uint8_t v = sr(s, a) & imm; sw(s, a, v); sZN(s, v); break; }
    case 0x39: { std::uint8_t v = sr(s, s.spc.x) & sr(s, s.spc.y()); sw(s, s.spc.x, v); sZN(s, v); break; }
    case 0x3A: { std::uint16_t a = dp(); std::uint16_t v = sr16(s, a) + 1; sw16(s, a, v); s.spc.psw = (s.spc.psw & ~(CN | CZ)) | ((v >> 8) & CN) | (v ? 0 : CZ); break; }
    case 0x3B: { std::uint16_t a = dpx(); std::uint8_t v = sr(s, a); int c = s.spc.psw & CC ? 1 : 0; s.spc.psw = (s.spc.psw & ~CC) | (v >> 7); v = (v << 1) | c; sw(s, a, v); sZN(s, v); break; }
    case 0x3C: { std::uint8_t v = sa(s); int c = s.spc.psw & CC ? 1 : 0; s.spc.psw = (s.spc.psw & ~CC) | (v >> 7); s.spc.setA((v << 1) | c); sZN(s, sa(s)); break; }
    case 0x3D: s.spc.x++; sZN(s, s.spc.x); break;
    case 0x3E: cmp(s, s.spc.x, sr(s, dp())); break;
    case 0x3F: { std::uint16_t t = sf16(s); spush(s, s.spc.pc >> 8); spush(s, s.spc.pc & 0xFF); s.spc.pc = t; break; }
    case 0x40: s.spc.psw |= CP; break;
    case 0x44: s.spc.setA(sa(s) ^ sr(s, dp())); sZN(s, sa(s)); break;
    case 0x45: s.spc.setA(sa(s) ^ sr(s, sf16(s))); sZN(s, sa(s)); break;
    case 0x46: s.spc.setA(sa(s) ^ sr(s, ix())); sZN(s, sa(s)); break;
    case 0x47: s.spc.setA(sa(s) ^ sr(s, idpx())); sZN(s, sa(s)); break;
    case 0x48: s.spc.setA(sa(s) ^ sf(s)); sZN(s, sa(s)); break;
    case 0x49: { std::uint16_t d = dp(), src = dp(); logicMem(s, d, sr(s, src), 2); break; }
    case 0x4A: { auto [a, b] = bitAddr(); if (!(sr(s, a) & (1 << b))) s.spc.psw &= ~CC; break; }
    case 0x4B: { std::uint16_t a = dp(); std::uint8_t v = sr(s, a); s.spc.psw = (s.spc.psw & ~CC) | (v & 1); v >>= 1; sw(s, a, v); sZN(s, v); break; }
    case 0x4C: { std::uint16_t a = sf16(s); std::uint8_t v = sr(s, a); s.spc.psw = (s.spc.psw & ~CC) | (v & 1); v >>= 1; sw(s, a, v); sZN(s, v); break; }
    case 0x4D: spush(s, s.spc.x); break;
    case 0x4E: { std::uint16_t a = sf16(s); std::uint8_t m = sr(s, a); sZN(s, sa(s) & m); sw(s, a, m & ~sa(s)); break; }
    case 0x4F: { std::uint8_t n = sf(s); spush(s, s.spc.pc >> 8); spush(s, s.spc.pc & 0xFF); s.spc.pc = 0xFF00 | n; break; }
    case 0x50: { std::int8_t r = sf(s); if (!(s.spc.psw & CV)) s.spc.pc += r; break; }
    case 0x54: s.spc.setA(sa(s) ^ sr(s, dpx())); sZN(s, sa(s)); break;
    case 0x55: s.spc.setA(sa(s) ^ sr(s, absx())); sZN(s, sa(s)); break;
    case 0x56: s.spc.setA(sa(s) ^ sr(s, absy())); sZN(s, sa(s)); break;
    case 0x57: s.spc.setA(sa(s) ^ sr(s, idpy())); sZN(s, sa(s)); break;
    case 0x58: { std::uint8_t imm = sf(s); std::uint16_t a = dp(); std::uint8_t v = sr(s, a) ^ imm; sw(s, a, v); sZN(s, v); break; }
    case 0x59: { std::uint8_t v = sr(s, s.spc.x) ^ sr(s, s.spc.y()); sw(s, s.spc.x, v); sZN(s, v); break; }
    case 0x5A: { std::uint16_t a = dp(); std::uint16_t m = sr16(s, a); s.spc.psw = (s.spc.psw & ~CC) | (ya(s) >= m ? CC : 0); std::uint16_t r = ya(s) - m; s.spc.psw = (s.spc.psw & ~(CN | CZ)) | ((r >> 8) & CN) | (r ? 0 : CZ); break; }
    case 0x5B: { std::uint16_t a = dpx(); std::uint8_t v = sr(s, a); s.spc.psw = (s.spc.psw & ~CC) | (v & 1); v >>= 1; sw(s, a, v); sZN(s, v); break; }
    case 0x5C: { std::uint8_t v = sa(s); s.spc.psw = (s.spc.psw & ~CC) | (v & 1); s.spc.setA(v >> 1); sZN(s, sa(s)); break; }
    case 0x5D: s.spc.x = sa(s); sZN(s, s.spc.x); break;
    case 0x5E: cmp(s, s.spc.y(), sr(s, sf16(s))); break;
    case 0x5F: s.spc.pc = sf16(s); break;
    case 0x60: s.spc.psw &= ~CC; break;
    case 0x64: cmp(s, sa(s), sr(s, dp())); break;
    case 0x65: cmp(s, sa(s), sr(s, sf16(s))); break;
    case 0x66: cmp(s, sa(s), sr(s, ix())); break;
    case 0x67: cmp(s, sa(s), sr(s, idpx())); break;
    case 0x68: cmp(s, sa(s), sf(s)); break;
    case 0x69: { std::uint16_t d = dp(); cmp(s, sr(s, d), sr(s, dp())); break; }
    case 0x6A: { auto [a, b] = bitAddr(); if (sr(s, a) & (1 << b)) {} else s.spc.psw &= ~CC; break; }
    case 0x6B: { std::uint16_t a = dp(); std::uint8_t v = sr(s, a); int c = s.spc.psw & CC ? 1 : 0; s.spc.psw = (s.spc.psw & ~CC) | (v & 1); v = (v >> 1) | (c << 7); sw(s, a, v); sZN(s, v); break; }
    case 0x6C: { std::uint16_t a = sf16(s); std::uint8_t v = sr(s, a); int c = s.spc.psw & CC ? 1 : 0; s.spc.psw = (s.spc.psw & ~CC) | (v & 1); v = (v >> 1) | (c << 7); sw(s, a, v); sZN(s, v); break; }
    case 0x6D: spush(s, s.spc.y()); break;
    case 0x6E: { std::uint16_t a = dp(); std::int8_t r = sf(s); std::uint8_t v = sr(s, a) - 1; sw(s, a, v); if (v) s.spc.pc += r; break; }
    case 0x6F: { std::uint8_t l = spull(s); s.spc.pc = l | (std::uint16_t(spull(s)) << 8); break; }
    case 0x70: { std::int8_t r = sf(s); if (s.spc.psw & CV) s.spc.pc += r; break; }
    case 0x74: cmp(s, sa(s), sr(s, dpx())); break;
    case 0x75: cmp(s, sa(s), sr(s, absx())); break;
    case 0x76: cmp(s, sa(s), sr(s, absy())); break;
    case 0x77: cmp(s, sa(s), sr(s, idpy())); break;
    case 0x78: { std::uint8_t imm = sf(s); std::uint16_t a = dp(); cmp(s, sr(s, a), imm); break; }
    case 0x79: cmp(s, sr(s, s.spc.x), sr(s, s.spc.y())); break;
    case 0x7A: { std::uint16_t a = dp(); uint32_t r = ya(s) + sr16(s, a); s.spc.psw = (s.spc.psw & ~CC) | (r > 0xFFFF ? CC : 0); s.spc.psw = (s.spc.psw & ~CV) | (((~(ya(s) ^ sr16(s, a)) & (ya(s) ^ r) & 0x8000)) ? CV : 0); setYa(s, r & 0xFFFF); s.spc.psw = (s.spc.psw & ~(CN | CZ)) | ((r >> 8) & CN) | (r & 0xFFFF ? 0 : CZ); break; }
    case 0x7B: { std::uint16_t a = dpx(); std::uint8_t v = sr(s, a); int c = s.spc.psw & CC ? 1 : 0; s.spc.psw = (s.spc.psw & ~CC) | (v & 1); v = (v >> 1) | (c << 7); sw(s, a, v); sZN(s, v); break; }
    case 0x7C: { std::uint8_t v = sa(s); int c = s.spc.psw & CC ? 1 : 0; s.spc.psw = (s.spc.psw & ~CC) | (v & 1); s.spc.setA((v >> 1) | (c << 7)); sZN(s, sa(s)); break; }
    case 0x7D: s.spc.setA(s.spc.x); sZN(s, sa(s)); break;
    case 0x7E: cmp(s, s.spc.y(), sr(s, dp())); break;
    case 0x7F: { s.spc.psw = spull(s); std::uint8_t l = spull(s); s.spc.pc = l | (std::uint16_t(spull(s)) << 8); break; }
    case 0x80: s.spc.psw |= CC; break;
    case 0x84: adc(s, sr(s, dp())); break;
    case 0x85: adc(s, sr(s, sf16(s))); break;
    case 0x86: adc(s, sr(s, ix())); break;
    case 0x87: adc(s, sr(s, idpx())); break;
    case 0x88: adc(s, sf(s)); break;
    case 0x89: { std::uint8_t imm = sf(s); std::uint16_t a = dp(); std::uint8_t m = sr(s, a); int sum = m + imm; sw(s, a, sum & 255); sZN(s, sum & 255); break; }
    case 0x8A: { auto [a, b] = bitAddr(); bool bit = sr(s, a) & (1 << b); bool c = s.spc.psw & CC; s.spc.psw = (s.spc.psw & ~CC) | ((c ^ bit) ? CC : 0); break; }
    case 0x8B: { std::uint16_t a = dp(); std::uint8_t v = sr(s, a) - 1; sw(s, a, v); sZN(s, v); break; }
    case 0x8C: { std::uint16_t a = sf16(s); std::uint8_t v = sr(s, a) - 1; sw(s, a, v); sZN(s, v); break; }
    case 0x8D: s.spc.setY(sf(s)); sZN(s, s.spc.y()); break;
    case 0x8E: s.spc.psw = spull(s); break;
    case 0x8F: { std::uint8_t v = sf(s); sw(s, dp(), v); break; }
    case 0x90: { std::int8_t r = sf(s); if (!(s.spc.psw & CC)) s.spc.pc += r; break; }
    case 0x94: adc(s, sr(s, dpx())); break;
    case 0x95: adc(s, sr(s, absx())); break;
    case 0x96: adc(s, sr(s, absy())); break;
    case 0x97: adc(s, sr(s, idpy())); break;
    case 0x98: { std::uint16_t d = dp(); adc(s, sr(s, dp())); (void)d; break; }
    case 0x99: adc(s, sr(s, s.spc.y())); sw(s, s.spc.x, sa(s)); break;
    case 0x9A: { std::uint16_t a = dp(); std::uint16_t m = sr16(s, a); int r = ya(s) - m; s.spc.psw = (s.spc.psw & ~CC) | (ya(s) >= m ? CC : 0); setYa(s, r & 0xFFFF); s.spc.psw = (s.spc.psw & ~(CN | CZ)) | ((r >> 8) & CN) | ((r & 0xFFFF) ? 0 : CZ); break; }
    case 0x9B: { std::uint16_t a = dpx(); std::uint8_t v = sr(s, a) - 1; sw(s, a, v); sZN(s, v); break; }
    case 0x9C: s.spc.setA(sa(s) - 1); sZN(s, sa(s)); break;
    case 0x9D: s.spc.x = s.spc.sp; sZN(s, s.spc.x); break;
    case 0x9E: { uint32_t yv = ya(s); std::uint8_t x = s.spc.x ? s.spc.x : 1; s.spc.setA(yv / x); s.spc.setY(yv % x); sZN(s, sa(s)); s.spc.psw = (s.spc.psw & ~CV) | (s.spc.x == 0 ? CV : 0); break; }
    case 0x9F: { std::uint8_t v = sa(s); v = (v << 4) | (v >> 4); s.spc.setA(v); sZN(s, v); break; }
    case 0xA0: s.spc.psw |= CI; break;
    case 0xA4: sbc(s, sr(s, dp())); break;
    case 0xA5: sbc(s, sr(s, sf16(s))); break;
    case 0xA6: sbc(s, sr(s, ix())); break;
    case 0xA7: sbc(s, sr(s, idpx())); break;
    case 0xA8: sbc(s, sf(s)); break;
    case 0xA9: { std::uint16_t d = dp(), src = dp(); std::uint8_t m = sr(s, d); sbc(s, sr(s, src)); sw(s, d, sa(s)); s.spc.setA(m); break; }
    case 0xAA: { auto [a, b] = bitAddr(); s.spc.psw = (s.spc.psw & ~CC) | ((sr(s, a) & (1 << b)) ? CC : 0); break; }
    case 0xAB: { std::uint16_t a = dp(); std::uint8_t v = sr(s, a) + 1; sw(s, a, v); sZN(s, v); break; }
    case 0xAC: { std::uint16_t a = sf16(s); std::uint8_t v = sr(s, a) + 1; sw(s, a, v); sZN(s, v); break; }
    case 0xAD: cmp(s, s.spc.y(), sf(s)); break;
    case 0xAE: s.spc.setA(spull(s)); sZN(s, sa(s)); break;
    case 0xAF: sw(s, s.spc.x++, sa(s)); break;
    case 0xB0: { std::int8_t r = sf(s); if (s.spc.psw & CC) s.spc.pc += r; break; }
    case 0xB4: sbc(s, sr(s, dpx())); break;
    case 0xB5: sbc(s, sr(s, absx())); break;
    case 0xB6: sbc(s, sr(s, absy())); break;
    case 0xB7: sbc(s, sr(s, idpy())); break;
    case 0xB8: { std::uint8_t imm = sf(s); std::uint16_t a = dp(); std::uint8_t m = sr(s, a); int c = s.spc.psw & CC ? 1 : 0; int sum = m - imm - (1 - c); sw(s, a, sum & 255); s.spc.psw = (s.spc.psw & ~CC) | (sum >= 0 ? CC : 0); sZN(s, sum & 255); break; }
    case 0xB9: sbc(s, sr(s, s.spc.y())); sw(s, s.spc.x, sa(s)); break;
    case 0xBA: { std::uint16_t a = dp(); setYa(s, sr16(s, a)); s.spc.psw = (s.spc.psw & ~(CN | CZ)) | ((ya(s) >> 8) & CN) | (ya(s) ? 0 : CZ); break; }
    case 0xBB: { std::uint16_t a = dpx(); std::uint8_t v = sr(s, a) + 1; sw(s, a, v); sZN(s, v); break; }
    case 0xBC: s.spc.setA(sa(s) + 1); sZN(s, sa(s)); break;
    case 0xBD: s.spc.sp = s.spc.x; break;
    case 0xBE: { int a = sa(s); if (!(s.spc.psw & CC) || a > 0x99) { a -= 0x60; s.spc.psw &= ~CC; } else s.spc.psw |= CC; if (!(s.spc.psw & CH) || (a & 15) > 9) a -= 6; s.spc.setA(a & 255); sZN(s, sa(s)); break; }
    case 0xBF: s.spc.setA(sr(s, s.spc.x++)); sZN(s, sa(s)); break;
    case 0xC0: s.spc.psw &= ~CI; break;
    case 0xC4: sw(s, dp(), sa(s)); break;
    case 0xC5: sw(s, sf16(s), sa(s)); break;
    case 0xC6: sw(s, s.spc.x, sa(s)); break;
    case 0xC7: sw(s, idpx(), sa(s)); break;
    case 0xC8: cmp(s, s.spc.x, sf(s)); break;
    case 0xC9: sw(s, sf16(s), s.spc.x); break;
    case 0xCA: { auto [a, b] = bitAddr(); std::uint8_t m = sr(s, a); if (s.spc.psw & CC) m |= 1 << b; else m &= ~(1 << b); sw(s, a, m); break; }
    case 0xCB: sw(s, dp(), s.spc.y()); break;
    case 0xCC: sw(s, sf16(s), s.spc.y()); break;
    case 0xCD: s.spc.x = sf(s); sZN(s, s.spc.x); break;
    case 0xCE: s.spc.x = spull(s); sZN(s, s.spc.x); break;
    case 0xCF: setYa(s, std::uint16_t(s.spc.y()) * sa(s)); s.spc.psw = (s.spc.psw & ~(CN | CZ)) | ((ya(s) >> 8) & CN) | (ya(s) ? 0 : CZ); break;
    case 0xD0: { std::int8_t r = sf(s); if (!(s.spc.psw & CZ)) s.spc.pc += r; break; }
    case 0xD4: sw(s, dpx(), sa(s)); break;
    case 0xD5: sw(s, absx(), sa(s)); break;
    case 0xD6: sw(s, absy(), sa(s)); break;
    case 0xD7: sw(s, idpy(), sa(s)); break;
    case 0xD8: sw(s, dp(), s.spc.x); break;
    case 0xD9: sw(s, dpy(), s.spc.x); break;
    case 0xDA: sw16(s, dp(), ya(s)); break;
    case 0xDB: sw(s, dpx(), s.spc.y()); break;
    case 0xDC: s.spc.setY(s.spc.y() - 1); sZN(s, s.spc.y()); break;
    case 0xDD: s.spc.setA(s.spc.y()); sZN(s, sa(s)); break;
    case 0xDE: { std::uint16_t a = dpx(); std::int8_t r = sf(s); if (sr(s, a) != sa(s)) s.spc.pc += r; break; }
    case 0xDF: { std::uint8_t v = sa(s); if (s.spc.psw & CC || v > 0x99) { v += 0x60; s.spc.psw |= CC; } if (s.spc.psw & CH || (v & 15) > 9) v += 6; s.spc.setA(v); sZN(s, v); break; }
    case 0xE0: s.spc.psw &= ~(CV | CH); break;
    case 0xE4: s.spc.setA(sr(s, dp())); sZN(s, sa(s)); break;
    case 0xE5: s.spc.setA(sr(s, sf16(s))); sZN(s, sa(s)); break;
    case 0xE6: s.spc.setA(sr(s, s.spc.x)); sZN(s, sa(s)); break;
    case 0xE7: s.spc.setA(sr(s, idpx())); sZN(s, sa(s)); break;
    case 0xE8: s.spc.setA(sf(s)); sZN(s, sa(s)); break;
    case 0xE9: s.spc.x = sr(s, sf16(s)); sZN(s, s.spc.x); break;
    case 0xEA: { auto [a, b] = bitAddr(); sw(s, a, sr(s, a) ^ (1 << b)); break; }
    case 0xEB: s.spc.setY(sr(s, dp())); sZN(s, s.spc.y()); break;
    case 0xEC: s.spc.setY(sr(s, sf16(s))); sZN(s, s.spc.y()); break;
    case 0xED: s.spc.psw ^= CC; break;
    case 0xEE: s.spc.setY(spull(s)); sZN(s, s.spc.y()); break;
    case 0xEF: s.spc.pc--; break;
    case 0xF0: { std::int8_t r = sf(s); if (s.spc.psw & CZ) s.spc.pc += r; break; }
    case 0xF4: s.spc.setA(sr(s, dpx())); sZN(s, sa(s)); break;
    case 0xF5: s.spc.setA(sr(s, absx())); sZN(s, sa(s)); break;
    case 0xF6: s.spc.setA(sr(s, absy())); sZN(s, sa(s)); break;
    case 0xF7: s.spc.setA(sr(s, idpy())); sZN(s, sa(s)); break;
    case 0xF8: s.spc.x = sr(s, dp()); sZN(s, s.spc.x); break;
    case 0xF9: s.spc.x = sr(s, dpy()); sZN(s, s.spc.x); break;
    case 0xFA: { std::uint16_t d = dp(); sw(s, dp(), sr(s, d)); break; }
    case 0xFB: s.spc.setY(sr(s, dpx())); sZN(s, s.spc.y()); break;
    case 0xFC: s.spc.setY(s.spc.y() + 1); sZN(s, s.spc.y()); break;
    case 0xFD: s.spc.setY(sa(s)); sZN(s, s.spc.y()); break;
    case 0xFE: { std::int8_t r = sf(s); s.spc.setY(s.spc.y() - 1); if (s.spc.y()) s.spc.pc += r; break; }
    case 0xFF: s.spc.pc--; break;
    default: break;
    }
    for (int i = 0; i < 3; i++) if (s.spc.timersOn[i]) {
        s.spc.timerDiv[i] += 4;
        int period = i == 2 ? 16 : 128;
        while (s.spc.timerDiv[i] >= period) {
            s.spc.timerDiv[i] -= period;
            s.spc.timerStage[i]++;
            int tgt = s.spc.timerTarget[i] ? s.spc.timerTarget[i] : 256;
            if (s.spc.timerStage[i] >= tgt) { s.spc.timerStage[i] = 0; s.spc.timerOut[i] = (s.spc.timerOut[i] + 1) & 0x0F; }
        }
    }
    return 2;
}

inline void ApuBridge::tickMasterCycles(unsigned masterCycles){if(nativeStepHook){nativeMasterCycles+=masterCycles;nativeStepHook(*this,masterCycles);}else{fallbackMasterCycles+=masterCycles;spcMasterRemainder+=masterCycles;while(spcMasterRemainder>=42u){spcMasterRemainder-=42u;forja65SpcStep(*this);}}tickDspMasterCycles(masterCycles);}
struct DmaChannel { std::uint8_t dmap{},bbad{},a1b{},dasb{}; std::uint16_t a1t{},das{},a2a{}; std::uint8_t ntrl{}; };
struct NativeReturnFrame { std::uint32_t target{}; bool longCall{}; };
struct CpuTraceEntry { std::uint32_t pc{}; std::uint16_t a{},x{},y{},s{},d{}; std::uint8_t db{},pb{},p{}; bool e{},m8{},x8{},c{}; };
struct HardwareUsage { std::uint64_t romReads{},romNativeReads{},romFallbackReads{},wramReads{},wramWrites{},sramReads{},sramWrites{},ppuReads{},ppuWrites{},ppuNativeReads{},ppuNativeWrites{},ppuFallbackReads{},ppuFallbackWrites{},apuReads{},apuWrites{},ioReads{},ioWrites{},dmaBytes{},dmaNativeBytes{},dmaFallbackBytes{},hdmaBytes{},hdmaNativeBytes{},hdmaFallbackBytes{},cartChipReads{},cartChipWrites{}; };
enum class MapperKind { LoROM, HiROM, ExHiROM };
enum class RomRuntimeMode { Cart, Hybrid, NativeOnly };
enum class PpuRuntimeMode { VirtualRegisters, StateOnlyNativeScanout };
struct NativeRomRegion { std::uint32_t off{}; std::vector<std::uint8_t> data; };
struct NativeRomStore {
  std::uint32_t logicalSize{}; std::uint64_t sourceHash{}; std::vector<NativeRomRegion> regions;
  bool empty()const{return regions.empty();}
  std::uint64_t coverageBytes()const{std::uint64_t n=0;for(const auto&r:regions)n+=r.data.size();return n;}
  double coveragePercent()const{return logicalSize?100.0*(double)coverageBytes()/(double)logicalSize:0.0;}
  bool read(std::size_t off,std::uint8_t&out)const{for(const auto&r:regions)if(off>=r.off&&off<(std::size_t)r.off+r.data.size()){out=r.data[off-r.off];return true;}return false;}
  bool load(const std::string&path){std::ifstream f(path,std::ios::binary);if(!f)return false;char m[4]{};f.read(m,4);if(std::string(m,4)!="F65R")return false;auto r32=[&](){std::uint32_t v{};f.read((char*)&v,4);return v;};auto r64=[&](){std::uint64_t v{};f.read((char*)&v,8);return v;};auto ver=r32();if(ver!=1)return false;logicalSize=r32();sourceHash=r64();auto n=r32();regions.clear();regions.reserve(n);for(std::uint32_t i=0;i<n;i++){NativeRomRegion r;r.off=r32();auto len=r32();r.data.resize(len);if(len)f.read((char*)r.data.data(),len);if(!f)return false;regions.push_back(std::move(r));}std::sort(regions.begin(),regions.end(),[](const auto&a,const auto&b){return a.off<b.off;});return true;}
};
enum class CartChip { None, DSP1, DSP2, DSP3, DSP4, GSU, OBC1, SA1, SDD1, SRTC, SPC7110, ST010_011, ST018, CX4, Custom, Other };
struct ForjaNativeHook {
  std::uint32_t pc{};unsigned(*body)(CpuState&,SnesRuntime&){};
  bool(*guard)(const CpuState&,const SnesRuntime&){};
  int e{-1},m{-1},x{-1};
};
struct SnesRuntime {
  ForjaTrace trace;ForjaRenderer hostRenderer;std::vector<ForjaNativeHook> nativeHooks;
  std::uint32_t traceRoutine{};const char*traceSource{"CPU"};bool nativeCallPending{},nativeReference{},cpuInstructionTraced{};
  std::uint64_t nativeHookCalls{},nativeHookMasterCycles{};
  void registerNativeHook(ForjaNativeHook hook){if(!hook.body||hook.pc>0xFFFFFFu)throw std::invalid_argument("Invalid native hook");for(const auto&h:nativeHooks)if(h.pc==hook.pc&&h.e==hook.e&&h.m==hook.m&&h.x==hook.x)throw std::invalid_argument("Duplicate native hook");nativeHooks.push_back(hook);}
  bool runNativeHook(std::uint32_t pc,CpuState&cpu){if(nativeReference||nativeReturns.empty())return false;
    for(const auto&h:nativeHooks){if((h.pc!=pc&&((h.pc&0xFFFFu)!=(pc&0xFFFFu)||romOffset(h.pc)==(std::size_t)-1||romOffset(h.pc)!=romOffset(pc)))||(h.e>=0&&cpu.e!=bool(h.e))||(h.m>=0&&cpu.m8!=bool(h.m))||(h.x>=0&&cpu.x8!=bool(h.x)))continue;if(h.guard&&!h.guard(cpu,*this))continue;
      const auto stack=cpu.s;const bool emu=cpu.e;const auto depth=nativeReturns.size();const auto ret=nativeReturns.back();
      const auto raw=cpu.peekStack16(*this);const auto bank=ret.longCall?cpu.peekStack8(*this,3u):cpu.pb;
      const auto destination=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu);
      if(destination!=ret.target)throw std::runtime_error("Native hook return-frame mismatch");
      ForjaTraceContext hookContext(traceRoutine,traceSource,pc,"HOST");const auto clocks=h.body(cpu,*this);
      if(cpu.s!=stack||cpu.e!=emu||nativeReturns.size()!=depth||nativeReturns.back().target!=ret.target||nativeReturns.back().longCall!=ret.longCall||dispatchPending||nativeCallPending)throw std::runtime_error("Native hook violated stack/dispatch ABI");
      if(cpu.peekStack16(*this)!=raw||(ret.longCall&&cpu.peekStack8(*this,3u)!=bank))throw std::runtime_error("Native hook modified real return frame");
      cpu.pop16Value(*this);if(ret.longCall)cpu.pop8Value(*this);cpu.pb=bank;popNativeReturn();
      nativeHookCalls++;nativeHookMasterCycles+=clocks;advanceCpuMasterCycles(clocks);
      trace.emit(frameCounter,pc,lastInstructionPc,"native_hook","HOST",pc,clocks,"HOST");return true;
    }return false;
  }
  const char* traceSpace(std::uint32_t address)const{address&=0xFFFFFFu;const auto lo=address&0xFFFFu;if(wramOffset(address)!=(std::size_t)-1)return "WRAM";if(sramOffset(address)!=(std::size_t)-1)return "SRAM";if(cartChipAddress(address))return "CHIP";if(ioBank(address)){if(lo==0x2118||lo==0x2119||lo==0x2139||lo==0x213A)return "VRAM";if(lo==0x2122||lo==0x213B)return "CGRAM";if(lo==0x2104||lo==0x2138)return "OAM";if(lo>=0x2100&&lo<=0x213F)return "PPU";if(lo>=0x2140&&lo<=0x2143)return "APU";if(lo==0x4016||lo==0x4017||(lo>=0x4218&&lo<=0x421F))return "INPUT";if(lo==0x2180)return "WRAM_PORT";if(lo>=0x4300&&lo<=0x437F)return "DMA_REG";if(lo>=0x4200&&lo<=0x421F)return "IO";}return romOffset(address)!=(std::size_t)-1?"ROM":"UNKNOWN";}
  void observeBus(const char*kind,std::uint32_t address,std::uint32_t value){if(!trace.enabled)return;trace.emit(frameCounter,traceRoutine,lastInstructionPc,kind,traceSpace(address),address&0xFFFFFFu,value,traceSource);}
  std::vector<std::uint8_t> ram=std::vector<std::uint8_t>(0x20000); std::vector<std::uint8_t> cart; std::vector<std::uint8_t> sram; std::string sramPath{"save.srm"}; bool sramDirty{}; unsigned romSizeCode{},sramSizeCode{},regionCode{}; CartChip cartChip{CartChip::None}; PpuState ppu; CpuIoState io; ApuBridge apu; DmaChannel dma[8]{}; NativeRomStore nativeRom; std::size_t romLogicalSize{}; RomRuntimeMode romMode{RomRuntimeMode::Cart}; PpuRuntimeMode ppuMode{PpuRuntimeMode::VirtualRegisters}; bool nativeDmaEnabled{},spcCaptureDone{}; std::vector<std::uint8_t> romTouched; std::vector<NativeReturnFrame> nativeReturns; std::array<CpuTraceEntry,256> cpuTrace{}; std::size_t cpuTracePos{},cpuTraceCount{}; bool dispatchPending{},hostFrameReady{}; std::uint32_t dispatchTarget{},dispatchFrom{}; std::uint8_t hdmaActive{},hdmaEnded{}; bool hdmaTransfer[8]{},hdmaEveryLine[8]{},hdmaInitialized[8]{}; std::uint16_t hdmaLines[8]{}; MapperKind mapper{MapperKind::LoROM}; bool stopped{},windowClosed{},irqFiredThisLine{},frameTimingActive{},headless{},framePacingStarted{},cpuNmiInterruptPending{},cpuIrqInterruptPending{},hdmaExecutedThisLine{}; std::uint64_t instructionWatchdogLimit{readInstructionWatchdogLimit()}; std::uint64_t frameCounter{},cpuMasterClock{},cpuInstructionCount{},timingOverflowMasterCycles{},nmiServiceCount{},irqServiceCount{}; unsigned currentScanline{},currentMasterCycle{},fbWidth{256},fbHeight{224},rasterCursorX{},lastInstructionMasterCycles{}; std::uint32_t lastInstructionPc{}; bool interlaceField{},wramRefreshAppliedThisLine{},sceneCaptureDone{}; std::uint64_t dmaStallMasterCycles{},hdmaStallMasterCycles{},wramRefreshStallMasterCycles{},interruptEntryMasterCycles{}; std::vector<std::uint32_t> framebuffer=std::vector<std::uint32_t>(256u*224u,0xFF000000u); HardwareUsage hwUsage{},hwFrameBase{}; std::uint32_t firstRomPc{0xFFFFFFFFu},firstPpuPc{0xFFFFFFFFu},firstApuPc{0xFFFFFFFFu},firstDmaPc{0xFFFFFFFFu},firstHdmaPc{0xFFFFFFFFu}; struct InputFrame{std::uint64_t frame{};std::uint16_t joy1{},joy2{};}; std::vector<InputFrame> inputReplay; std::size_t inputReplayPos{}; std::string inputRecordPath{}; bool replayActive{}; std::chrono::steady_clock::time_point nextPresent{};
#ifdef _WIN32
  HWND hwnd{}; HINSTANCE hinst{};
#endif
  static std::uint64_t readInstructionWatchdogLimit(){const char*w=std::getenv("FORJA65_WATCHDOG_INSTRUCTIONS");return(w&&*w)?std::strtoull(w,nullptr,10):0u;}
  static bool envFlag(const char*name){const char*v=std::getenv(name);return v&&*v&&std::string(v)!="0";}
  static std::string envText(const char*name){const char*v=std::getenv(name);return v?std::string(v):std::string();}
  static bool isPalRegion(unsigned r){return r>=2u&&r<=12u;}
  double hostRefreshHz()const{return isPalRegion(regionCode)?50.0:60.0;}
  void initMigrationModes(const std::string&cartPath){auto rm=envText("FORJA65_ROM_MODE");if(rm=="native")romMode=RomRuntimeMode::NativeOnly;else if(rm=="hybrid")romMode=RomRuntimeMode::Hybrid;else romMode=RomRuntimeMode::Cart;auto pm=envText("FORJA65_PPU_MODE");ppuMode=(pm=="state"||pm=="native"||pm=="strict")?PpuRuntimeMode::StateOnlyNativeScanout:PpuRuntimeMode::VirtualRegisters;auto dm=envText("FORJA65_DMA_MODE");nativeDmaEnabled=(dm=="native"||dm=="auto");auto am=envText("FORJA65_AUDIO_MODE");apu.setNativeDsp(am=="native"||am=="auto");const std::string pack=envText("FORJA65_NATIVE_ROM_PACK").empty()?"assets/native-rom-data.bin":envText("FORJA65_NATIVE_ROM_PACK");if(romMode!=RomRuntimeMode::NativeOnly)loadCart(cartPath);if(romMode!=RomRuntimeMode::Cart){if(!nativeRom.load(pack)&&romMode==RomRuntimeMode::NativeOnly)throw std::runtime_error("native-rom-data.bin nao encontrado/valido: "+pack);if(nativeRom.logicalSize)romLogicalSize=nativeRom.logicalSize;}if(!romLogicalSize)romLogicalSize=cart.size();if(envFlag("FORJA65_ROM_PROFILE"))romTouched.assign(romLogicalSize,0);}
  SnesRuntime()=default; explicit SnesRuntime(const std::string&path,MapperKind m,std::size_t sramBytes=0,unsigned romCode=0,unsigned sramCode=0,CartChip chip=CartChip::None,const std::string&savePath="save.srm",unsigned region=1u,bool forceHeadless=false):sramPath(savePath),romSizeCode(romCode),sramSizeCode(sramCode),regionCode(region),cartChip(chip),mapper(m),headless(forceHeadless||envFlag("FORJA65_HEADLESS")){initMigrationModes(path);initSram(sramBytes);trace.initialize(cartHashHex());nativeReference=envText("FORJA65_EXECUTION")=="reference";initInputTraceFromEnv();if(!headless)initWindow();}
  ~SnesRuntime(){saveSram();saveRomReadProfile();apu.saveDump("forja65-spc-upload.bin");apu.saveManifest("forja65-spc-upload.txt");if(envFlag("FORJA65_AUDIO_DUMP")&&apu.nativeDspReady())apu.saveNativeAudioWav("forja65-native-audio.wav");shutdownWindow();}
  void loadCart(const std::string&path){std::ifstream f(path,std::ios::binary);if(!f)throw std::runtime_error("cart-data.bin nao encontrado: "+path);cart.assign(std::istreambuf_iterator<char>(f),{});if(cart.empty())throw std::runtime_error("cart-data.bin vazio");romLogicalSize=cart.size();}
  void initSram(std::size_t bytes){if(!bytes)return;sram.assign(bytes,0xFFu);std::ifstream f(sramPath,std::ios::binary);if(f)f.read((char*)sram.data(),(std::streamsize)sram.size());}
  void saveSram(){if(sram.empty()||!sramDirty)return;std::ofstream f(sramPath,std::ios::binary|std::ios::trunc);if(f)f.write((const char*)sram.data(),(std::streamsize)sram.size());sramDirty=false;}
  static std::uint64_t hashBytes(const std::uint8_t*p,std::size_t n){std::uint64_t h=1469598103934665603ull;for(std::size_t i=0;i<n;i++){h^=p[i];h*=1099511628211ull;}return h;}
  std::uint64_t cartHashValue()const{return!cart.empty()?hashBytes(cart.data(),cart.size()):nativeRom.sourceHash;}
  std::string cartHashHex()const{std::ostringstream ss;ss<<std::hex<<std::setfill('0')<<std::setw(16)<<cartHashValue();return ss.str();}
  std::uint64_t ramHash()const{return hashBytes(ram.data(),ram.size());}
  void markRomRead(std::size_t off){if(off<romTouched.size())romTouched[off]=1;}
  void saveRomReadProfile(const std::string&path="forja65-rom-read-ranges.txt")const{if(romTouched.empty())return;std::ofstream o(path,std::ios::trunc);if(!o)return;o<<"FORJA65_ROM_READ_RANGES 1\nrom="<<cartHashHex()<<"\nlogical_size="<<romLogicalSize<<"\n";std::size_t i=0,count=0;while(i<romTouched.size()){while(i<romTouched.size()&&!romTouched[i])i++;if(i>=romTouched.size())break;std::size_t b=i;while(i<romTouched.size()&&romTouched[i])i++;std::size_t e=i;o<<"range=0x"<<std::hex<<b<<" length=0x"<<(e-b)<<std::dec<<"\n";count++;}o<<"ranges="<<count<<"\n";}
  bool loadInputReplay(const std::string&path){inputReplay.clear();inputReplayPos=0;std::ifstream in(path);if(!in)return false;std::string line;while(std::getline(in,line)){if(line.empty()||line[0]=='#'||line[0]==';')continue;std::istringstream ss(line);std::string part;InputFrame q{};bool hf=false;while(ss>>part){auto p=part.find('=');if(p==std::string::npos)continue;auto k=part.substr(0,p),v=part.substr(p+1);try{if(k=="frame"){q.frame=std::stoull(v,nullptr,10);hf=true;}else if(k=="joy1")q.joy1=(std::uint16_t)std::stoul(v,nullptr,16);else if(k=="joy2")q.joy2=(std::uint16_t)std::stoul(v,nullptr,16);}catch(...){}}if(hf)inputReplay.push_back(q);}std::sort(inputReplay.begin(),inputReplay.end(),[](const auto&a,const auto&b){return a.frame<b.frame;});replayActive=!inputReplay.empty();return replayActive;}
  void setInputRecordPath(const std::string&path,bool reset=true){inputRecordPath=path;if(reset&&!path.empty()){std::ofstream out(path,std::ios::trunc);if(out)out<<"# FORJA65_INPUT_TRACE 1 rom="<<cartHashHex()<<"\n";}}
  void initInputTraceFromEnv(){if(const char*p=std::getenv("FORJA65_INPUT_REPLAY"))if(*p)loadInputReplay(p);if(const char*p=std::getenv("FORJA65_INPUT_RECORD"))if(*p)setInputRecordPath(p,true);}
  bool applyReplayInput(){if(!replayActive)return false;while(inputReplayPos<inputReplay.size()&&inputReplay[inputReplayPos].frame<frameCounter)inputReplayPos++;if(inputReplayPos>=inputReplay.size()||inputReplay[inputReplayPos].frame!=frameCounter)return true;const auto&q=inputReplay[inputReplayPos++];setJoy1(q.joy1);setJoy2(q.joy2);return true;}
  void recordInputFrame(){if(inputRecordPath.empty())return;std::ofstream out(inputRecordPath,std::ios::app);if(out)out<<"frame="<<frameCounter<<" joy1="<<std::hex<<std::setfill('0')<<std::setw(4)<<(unsigned)io.joy[0]<<" joy2="<<std::setw(4)<<(unsigned)io.joy[1]<<std::dec<<"\n";}
  static HardwareUsage usageDelta(const HardwareUsage&a,const HardwareUsage&b){HardwareUsage d;d.romReads=a.romReads-b.romReads;d.romNativeReads=a.romNativeReads-b.romNativeReads;d.romFallbackReads=a.romFallbackReads-b.romFallbackReads;d.wramReads=a.wramReads-b.wramReads;d.wramWrites=a.wramWrites-b.wramWrites;d.sramReads=a.sramReads-b.sramReads;d.sramWrites=a.sramWrites-b.sramWrites;d.ppuReads=a.ppuReads-b.ppuReads;d.ppuWrites=a.ppuWrites-b.ppuWrites;d.ppuNativeReads=a.ppuNativeReads-b.ppuNativeReads;d.ppuNativeWrites=a.ppuNativeWrites-b.ppuNativeWrites;d.ppuFallbackReads=a.ppuFallbackReads-b.ppuFallbackReads;d.ppuFallbackWrites=a.ppuFallbackWrites-b.ppuFallbackWrites;d.apuReads=a.apuReads-b.apuReads;d.apuWrites=a.apuWrites-b.apuWrites;d.ioReads=a.ioReads-b.ioReads;d.ioWrites=a.ioWrites-b.ioWrites;d.dmaBytes=a.dmaBytes-b.dmaBytes;d.dmaNativeBytes=a.dmaNativeBytes-b.dmaNativeBytes;d.dmaFallbackBytes=a.dmaFallbackBytes-b.dmaFallbackBytes;d.hdmaBytes=a.hdmaBytes-b.hdmaBytes;d.hdmaNativeBytes=a.hdmaNativeBytes-b.hdmaNativeBytes;d.hdmaFallbackBytes=a.hdmaFallbackBytes-b.hdmaFallbackBytes;d.cartChipReads=a.cartChipReads-b.cartChipReads;d.cartChipWrites=a.cartChipWrites-b.cartChipWrites;return d;}
  static void rememberFirst(std::uint32_t&slot,std::uint32_t pc){if(slot==0xFFFFFFFFu)slot=pc&0xFFFFFFu;}
  void appendFrameHash(){if(!envFlag("FORJA65_FRAME_HASHES"))return;std::ofstream out("forja65-frame-hashes.txt",std::ios::app);if(out)out<<"frame="<<frameCounter<<" framebuffer="<<std::hex<<framebufferHash()<<" wram="<<ramHash()<<" pc="<<lastInstructionPc<<std::dec<<"\n";}
  void appendNativeAuditFrame(){if(!envFlag("FORJA65_NATIVE_AUDIT"))return;const bool fresh=!std::filesystem::exists("forja65-native-dependency.csv");std::ofstream out("forja65-native-dependency.csv",std::ios::app);if(!out)return;if(fresh)out<<"frame,rom_reads,rom_native,rom_fallback,wram_reads,wram_writes,sram_reads,sram_writes,ppu_reads,ppu_writes,ppu_native_reads,ppu_native_writes,ppu_fallback_reads,ppu_fallback_writes,apu_reads,apu_writes,io_reads,io_writes,dma_bytes,dma_native,dma_fallback,hdma_bytes,hdma_native,hdma_fallback,cartchip_reads,cartchip_writes,framebuffer_hash,wram_hash,last_pc\n";auto d=usageDelta(hwUsage,hwFrameBase);out<<frameCounter<<','<<d.romReads<<','<<d.romNativeReads<<','<<d.romFallbackReads<<','<<d.wramReads<<','<<d.wramWrites<<','<<d.sramReads<<','<<d.sramWrites<<','<<d.ppuReads<<','<<d.ppuWrites<<','<<d.ppuNativeReads<<','<<d.ppuNativeWrites<<','<<d.ppuFallbackReads<<','<<d.ppuFallbackWrites<<','<<d.apuReads<<','<<d.apuWrites<<','<<d.ioReads<<','<<d.ioWrites<<','<<d.dmaBytes<<','<<d.dmaNativeBytes<<','<<d.dmaFallbackBytes<<','<<d.hdmaBytes<<','<<d.hdmaNativeBytes<<','<<d.hdmaFallbackBytes<<','<<d.cartChipReads<<','<<d.cartChipWrites<<','<<std::hex<<framebufferHash()<<','<<ramHash()<<','<<lastInstructionPc<<std::dec<<"\n";hwFrameBase=hwUsage;}
  void writeNativeDependencyReport(const std::string&path="forja65-native-dependency-report.txt")const{std::ofstream o(path,std::ios::trunc);if(!o)return;auto pc=[&](std::uint32_t v){std::ostringstream q;if(v==0xFFFFFFFFu)q<<"none";else q<<"0x"<<std::hex<<std::setfill('0')<<std::setw(6)<<v;return q.str();};auto romNativeOnly=hwUsage.romReads&&hwUsage.romFallbackReads==0;auto ppuNativeOnly=ppuMode==PpuRuntimeMode::StateOnlyNativeScanout&&hwUsage.ppuFallbackReads==0&&hwUsage.ppuFallbackWrites==0;auto dmaNativeOnly=(hwUsage.dmaBytes+hwUsage.hdmaBytes)>0&&(hwUsage.dmaFallbackBytes+hwUsage.hdmaFallbackBytes)==0;auto apuNative=apu.nativeBackendReady();auto dspNative=apu.nativeDspReady();auto apuFullyNative=apuNative&&apu.fallbackMasterCycles==0&&dspNative;o<<"FORJA65_NATIVE_DEPENDENCY_AUDIT 1\nschema=3\nrom="<<cartHashHex()<<"\nframes="<<frameCounter<<"\ninstructions="<<cpuInstructionCount<<"\nnmi_services="<<nmiServiceCount<<"\nirq_services="<<irqServiceCount<<"\nCPU_AOT=YES\nPPU_STATE_ONLY_NATIVE_SCANOUT="<<(ppuMode==PpuRuntimeMode::StateOnlyNativeScanout?"YES":"NO")<<"\nPPU_NATIVE_ONLY="<<(ppuNativeOnly?"YES":"NO")<<"\nPPU_VIRTUAL_HW="<<((hwUsage.ppuFallbackReads||hwUsage.ppuFallbackWrites)?"YES":"NO")<<"\nDMA_NATIVE_FASTPATH="<<(dmaNativeOnly?"YES":"NO")<<"\nAPU_NATIVE_BACKEND="<<(apuNative?"YES":"NO")<<"\nDSP_NATIVE_BACKEND="<<(dspNative?"YES":"NO")<<"\nAPU_FULLY_NATIVE="<<(apuFullyNative?"YES":"NO")<<"\nAPU_VIRTUAL_HW="<<(apu.fallbackMasterCycles?"YES":"NO")<<"\nDSP_VIRTUAL_HW="<<(!dspNative?"YES":"NO")<<"\nROM_NATIVE_PACK_ONLY="<<(romNativeOnly?"YES":"NO")<<"\nROM_NATIVE_READY="<<((!nativeRom.empty()&&hwUsage.romFallbackReads==0)?"YES":"NO")<<"\nROM_RUNTIME_DATA="<<(hwUsage.romFallbackReads?"YES":"NO")<<"\nCARTCHIP_RUNTIME="<<((hwUsage.cartChipReads||hwUsage.cartChipWrites)?"YES":"NO")<<"\nrom_reads="<<hwUsage.romReads<<"\nrom_native_reads="<<hwUsage.romNativeReads<<"\nrom_fallback_reads="<<hwUsage.romFallbackReads<<"\nnative_rom_pack_bytes="<<nativeRom.coverageBytes()<<"\nnative_rom_pack_coverage_percent="<<std::fixed<<std::setprecision(4)<<nativeRom.coveragePercent()<<std::defaultfloat<<"\nwram_reads="<<hwUsage.wramReads<<"\nwram_writes="<<hwUsage.wramWrites<<"\nppu_reads="<<hwUsage.ppuReads<<"\nppu_writes="<<hwUsage.ppuWrites<<"\nppu_native_reads="<<hwUsage.ppuNativeReads<<"\nppu_native_writes="<<hwUsage.ppuNativeWrites<<"\nppu_fallback_reads="<<hwUsage.ppuFallbackReads<<"\nppu_fallback_writes="<<hwUsage.ppuFallbackWrites<<"\napu_reads="<<hwUsage.apuReads<<"\napu_writes="<<hwUsage.apuWrites<<"\napu_native_master_cycles="<<apu.nativeMasterCycles<<"\napu_fallback_master_cycles="<<apu.fallbackMasterCycles<<"\ndsp_native_samples="<<apu.dspNativeSamples<<"\ndsp_fallback_samples="<<apu.dspFallbackSamples<<"\ndma_bytes="<<hwUsage.dmaBytes<<"\ndma_native_bytes="<<hwUsage.dmaNativeBytes<<"\ndma_fallback_bytes="<<hwUsage.dmaFallbackBytes<<"\nhdma_bytes="<<hwUsage.hdmaBytes<<"\nhdma_native_bytes="<<hwUsage.hdmaNativeBytes<<"\nhdma_fallback_bytes="<<hwUsage.hdmaFallbackBytes<<"\nfirst_rom_pc="<<pc(firstRomPc)<<"\nfirst_ppu_pc="<<pc(firstPpuPc)<<"\nfirst_apu_pc="<<pc(firstApuPc)<<"\nfirst_dma_pc="<<pc(firstDmaPc)<<"\nfirst_hdma_pc="<<pc(firstHdmaPc)<<"\n";}
  static void put16(std::ofstream&o,std::uint16_t v){char b[2]={(char)(v&255u),(char)((v>>8)&255u)};o.write(b,2);} static void put32(std::ofstream&o,std::uint32_t v){char b[4]={(char)(v&255u),(char)((v>>8)&255u),(char)((v>>16)&255u),(char)((v>>24)&255u)};o.write(b,4);}
  static std::uint64_t fileHash(const std::filesystem::path&p){std::ifstream f(p,std::ios::binary);if(!f)return 0;std::uint64_t h=1469598103934665603ull;char buf[4096];while(f){f.read(buf,sizeof buf);auto n=f.gcount();for(std::streamsize i=0;i<n;i++){h^=(std::uint8_t)buf[i];h*=1099511628211ull;}}return h;}
  std::uint64_t framebufferHash()const{std::uint64_t h=1469598103934665603ull;for(auto v:framebuffer){std::uint8_t q[4]={(std::uint8_t)((v>>16)&255u),(std::uint8_t)((v>>8)&255u),(std::uint8_t)(v&255u),(std::uint8_t)((v>>24)&255u)};for(auto b:q){h^=b;h*=1099511628211ull;}}return h;}
  std::uint16_t fixedColor15()const{return(std::uint16_t)((ppu.fixedR&31u)|((ppu.fixedG&31u)<<5)|((ppu.fixedB&31u)<<10));}
  int captureBgBpp(unsigned bg)const{unsigned m=ppu.bgmode&7u;if(m==0)return bg<4?2:0;if(m==1)return bg<2?4:(bg==2?2:0);if(m==2)return bg<2?4:0;if(m==3)return bg==0?8:(bg==1?4:0);if(m==4)return bg==0?8:(bg==1?2:0);if(m==5)return bg==0?4:(bg==1?2:0);if(m==6)return bg==0?4:0;return 0;}
  void captureBgInfo(unsigned bg,std::uint16_t&mapBase,std::uint16_t&charBase,int&bpp,int&mw,int&mh,int&tileSize)const{mapBase=(std::uint16_t)((ppu.bgsc[bg]&0xFCu)<<8);charBase=(std::uint16_t)((ppu.bgnba[bg]&7u)<<12);bpp=captureBgBpp(bg);int sc=ppu.bgsc[bg]&3u;mw=(sc&1)?64:32;mh=(sc&2)?64:32;tileSize=(ppu.bgmode&(0x10u<<bg))?16:8;}
  std::uint16_t vramWord(std::uint16_t wa)const{std::uint32_t b=((std::uint32_t)wa*2u)&0xFFFFu;return(std::uint16_t)(ppu.vram[b]|(ppu.vram[(b+1u)&0xFFFFu]<<8));}
  std::uint8_t captureTilePixel(std::uint32_t a,int y,int x,int bpp)const{std::uint8_t mask=(std::uint8_t)(0x80u>>x);auto pair=[&](std::uint32_t off,int sh){std::uint8_t p0=ppu.vram[(a+y*2u+off)&0xFFFFu],p1=ppu.vram[(a+y*2u+off+1u)&0xFFFFu];return((p0&mask)?(1u<<sh):0u)|((p1&mask)?(2u<<sh):0u);};unsigned v=pair(0,0);if(bpp>=4)v|=pair(16,2);if(bpp>=8){v|=pair(32,4);v|=pair(48,6);}return(std::uint8_t)v;}
  bool writeNativePalette(const std::filesystem::path&p)const{std::ofstream o(p,std::ios::binary|std::ios::trunc);if(!o)return false;o.write("NPAL",4);put16(o,1);put16(o,256);o.write((const char*)ppu.cgram.data(),(std::streamsize)ppu.cgram.size());return(bool)o;}
  bool writeNativeTiles(const std::filesystem::path&p,std::uint16_t charBase,int bpp)const{if(bpp!=2&&bpp!=4&&bpp!=8)return false;std::ofstream o(p,std::ios::binary|std::ios::trunc);if(!o)return false;o.write("NTIL",4);put16(o,1);put16(o,(std::uint16_t)bpp);put32(o,1024);put32(o,8);put32(o,8);put32(o,charBase);std::uint32_t bpt=(std::uint32_t)bpp*8u;std::uint8_t q[64]{};for(std::uint32_t t=0;t<1024;t++){std::uint32_t base=((std::uint32_t)charBase*2u+t*bpt)&0xFFFFu;for(int y=0;y<8;y++)for(int x=0;x<8;x++)q[y*8+x]=captureTilePixel(base,y,x,bpp);o.write((const char*)q,64);}return(bool)o;}
  bool writeNativeMap(const std::filesystem::path&p,std::uint16_t base,int mw,int mh)const{std::ofstream o(p,std::ios::binary|std::ios::trunc);if(!o)return false;o.write("NMAP",4);put16(o,1);put16(o,0);put32(o,(std::uint32_t)mw);put32(o,(std::uint32_t)mh);put32(o,base);for(int y=0;y<mh;y++)for(int x=0;x<mw;x++){int page=0;if(mw==64&&x>=32)page++;if(mh==64&&y>=32)page+=(mw==64?2:1);auto e=vramWord((std::uint16_t)(base+page*0x400+(y&31)*32+(x&31)));put16(o,e);}return(bool)o;}
  bool writeFramePpm(const std::filesystem::path&p)const{std::ofstream o(p,std::ios::binary|std::ios::trunc);if(!o)return false;o<<"P6\n"<<fbWidth<<" "<<fbHeight<<"\n255\n";for(auto v:framebuffer){char b[3]={(char)((v>>16)&255u),(char)((v>>8)&255u),(char)(v&255u)};o.write(b,3);}return(bool)o;}
  std::uint32_t cgramArgb(unsigned index)const{index&=255u;unsigned a=index*2u;std::uint16_t c=(std::uint16_t)(ppu.cgram[a]|(ppu.cgram[(a+1u)&0x1FFu]<<8));auto cv=[](unsigned v){return(std::uint8_t)((v<<3)|(v>>2));};return 0xFF000000u|((std::uint32_t)cv(c&31u)<<16)|((std::uint32_t)cv((c>>5)&31u)<<8)|cv((c>>10)&31u);}
  void objSizes(int&smallSize,int&largeSize)const{static const int S[8]={8,8,8,16,16,32,16,16},L[8]={16,32,64,32,64,64,32,32};unsigned m=(ppu.obsel>>5)&7u;smallSize=S[m];largeSize=L[m];}
  std::uint8_t objPixel4(std::uint32_t a,int y,int x)const{return captureTilePixel(a,y,x,4);}
  bool writeNativeOamLayer(const std::filesystem::path&p,const std::filesystem::path&indexPath)const{const int W=256,H=(int)std::min<unsigned>(239u,visibleLines());std::vector<std::uint32_t>px((std::size_t)W*H,0u);std::ofstream idx(indexPath,std::ios::trunc);if(!idx)return false;idx<<"FORJA65_OAM_SPRITES 1\nobsel="<<(unsigned)ppu.obsel<<"\n";int sm=8,lg=16;objSizes(sm,lg);unsigned drawn=0;for(int sl=127;sl>=0;--sl){int o=sl*4,x=ppu.oam[o],y=ppu.oam[o+1],t=ppu.oam[o+2],at=ppu.oam[o+3],hi=ppu.oam[512+sl/4],sh=(sl&3)*2;x|=((hi>>sh)&1)<<8;if(x>=256)x-=512;int z=((hi>>(sh+1))&1)?lg:sm;bool hf=(at&0x40)!=0,vf=(at&0x80)!=0;int pal=(at>>1)&7;std::uint32_t b1=(ppu.obsel&7u)<<14,b2=b1+(std::uint32_t((ppu.obsel&0x18u)+8u)*0x400u),name=(at&1)?b2:b1;bool any=false;for(int dy=0;dy<z;dy++)for(int dx=0;dx<z;dx++){int sx=hf?z-1-dx:dx,sy=vf?z-1-dy:dy,ut=((((t>>4)+(sy>>3))<<4)|(((t&15)+(sx>>3))&15))&255;int pi=objPixel4((name+(std::uint32_t)ut*32u)&0xFFFFu,sy&7,sx&7);if(!pi)continue;int xx=x+dx,yy=(y+dy)&255;if((unsigned)xx<(unsigned)W&&(unsigned)yy<(unsigned)H){px[(std::size_t)yy*W+xx]=cgramArgb(128u+(unsigned)pal*16u+(unsigned)pi);any=true;}}if(any){idx<<"slot="<<sl<<" x="<<x<<" y="<<y<<" size="<<z<<" tile="<<t<<" attr="<<at<<" hflip="<<(hf?1:0)<<" vflip="<<(vf?1:0)<<"\n";drawn++;}}idx<<"visible_slots="<<drawn<<"\n";idx.close();std::ofstream o(p,std::ios::binary|std::ios::trunc);if(!o)return false;o.write("NSPR",4);put16(o,1);put16(o,0);put16(o,(std::uint16_t)W);put16(o,(std::uint16_t)H);put16(o,0);put16(o,0);put32(o,(std::uint32_t)px.size());for(auto v:px)put32(o,v);return(bool)o;}
  bool captureNativeScene(const std::string&dir,const std::string&name="scene")const{namespace fs=std::filesystem;fs::path out=dir.empty()?fs::path("forja65-scene-capture"):fs::path(dir);std::error_code ec;fs::create_directories(out,ec);if(ec)return false;auto raw=[&](const fs::path&p,const std::vector<std::uint8_t>&v){std::ofstream o(p,std::ios::binary|std::ios::trunc);if(!o)return false;o.write((const char*)v.data(),(std::streamsize)v.size());return(bool)o;};if(!raw(out/"vram.bin",ppu.vram)||!raw(out/"cgram.bin",ppu.cgram)||!raw(out/"oam.bin",ppu.oam)||!writeNativePalette(out/"palette.npal")||!writeFramePpm(out/"preview.ppm")||!writeNativeOamLayer(out/"oam-layer.nspr",out/"oam-sprites.txt"))return false;std::ofstream meta(out/(name+".nscene"),std::ios::trunc);if(!meta)return false;meta<<"NATIVE_SCENE 1\nmode "<<(unsigned)(ppu.bgmode&7u)<<"\nbg3_priority "<<((ppu.bgmode&8u)?1:0)<<"\ntm "<<(unsigned)ppu.tm<<"\nts "<<(unsigned)ppu.ts<<"\ncgwsel "<<(unsigned)ppu.cgwsel<<"\ncgadsub "<<(unsigned)ppu.cgadsub<<"\nfixed_color "<<fixedColor15()<<"\nbrightness "<<(unsigned)ppu.brightness<<"\nbackdrop 0\nviewport "<<fbWidth<<" "<<fbHeight<<"\npalette palette.npal\n";unsigned layers=0;for(unsigned bg=0;bg<4;bg++){std::uint16_t mb=0,cb=0;int bpp=0,mw=0,mh=0,tileSize=8;captureBgInfo(bg,mb,cb,bpp,mw,mh,tileSize);if(!bpp)continue;std::string n="bg"+std::to_string(bg+1),tf=n+".ntiles",mf=n+".nmap";if(!writeNativeTiles(out/tf,cb,bpp)||!writeNativeMap(out/mf,mb,mw,mh))return false;int enabled=((ppu.tm|ppu.ts)&(1u<<bg))?1:0;meta<<"layer "<<n<<" "<<bpp<<" "<<mw<<" "<<mh<<" "<<ppu.scrollX[bg]<<" "<<ppu.scrollY[bg]<<" "<<enabled<<" "<<tf<<" "<<mf<<"\n";meta<<"layer_tile_size "<<n<<" "<<tileSize<<"\n";layers++;}if((ppu.bgmode&7u)==7u)meta<<"mode7_raw 1\n";meta<<"sprites oam-layer.nspr oam-sprites.txt\n";meta<<"source_frame "<<frameCounter<<"\nframebuffer_hash_fnv1a64 "<<std::hex<<framebufferHash()<<std::dec<<"\ncart_hash_fnv1a64 "<<std::hex<<cartHashValue()<<std::dec<<"\n";meta.close();if(!meta)return false;std::vector<fs::path> files={out/"vram.bin",out/"cgram.bin",out/"oam.bin",out/"palette.npal",out/"preview.ppm",out/"oam-layer.nspr",out/"oam-sprites.txt",out/(name+".nscene")};for(unsigned bg=0;bg<4;bg++){if(!captureBgBpp(bg))continue;files.push_back(out/("bg"+std::to_string(bg+1)+".ntiles"));files.push_back(out/("bg"+std::to_string(bg+1)+".nmap"));}std::ofstream man(out/"capture-manifest.txt",std::ios::trunc);if(!man)return false;man<<"FORJA65_SCENE_CAPTURE 1\nsource_frame="<<frameCounter<<"\nppu_mode="<<(unsigned)(ppu.bgmode&7u)<<"\nwidth="<<fbWidth<<"\nheight="<<fbHeight<<"\nlayers="<<layers<<"\nframebuffer_hash_fnv1a64="<<std::hex<<framebufferHash()<<"\ncart_hash_fnv1a64="<<cartHashValue()<<std::dec<<"\n";for(const auto&f:files)man<<"file="<<f.filename().string()<<" size="<<fs::file_size(f,ec)<<" hash_fnv1a64="<<std::hex<<fileHash(f)<<std::dec<<"\n";return(bool)man;}
  bool maybeCaptureNativeScene(){if(sceneCaptureDone)return false;const char*e=std::getenv("FORJA65_CAPTURE_FRAME");if(!e||!*e)return false;std::uint64_t target=std::strtoull(e,nullptr,10);if(frameCounter<target)return false;const char*d=std::getenv("FORJA65_CAPTURE_DIR"),*n=std::getenv("FORJA65_CAPTURE_NAME");std::string dir=(d&&*d)?d:"forja65-scene-capture",name=(n&&*n)?n:("frame-"+std::to_string(frameCounter));if(!captureNativeScene(dir,name))throw std::runtime_error("falha ao exportar captura de cena para "+dir);sceneCaptureDone=true;std::ofstream log("forja65-scene-capture.txt",std::ios::trunc);if(log)log<<"frame="<<frameCounter<<"\ndir="<<dir<<"\nname="<<name<<"\nframebuffer_hash_fnv1a64="<<std::hex<<framebufferHash()<<"\n";if(envFlag("FORJA65_CAPTURE_STOP"))stopped=true;return true;}
  bool maybeCaptureSpcSnapshot(){if(spcCaptureDone)return false;const char*e=std::getenv("FORJA65_CAPTURE_SPC_FRAME");if(!e||!*e)return false;std::uint64_t target=std::strtoull(e,nullptr,10);if(frameCounter<target)return false;const char*d=std::getenv("FORJA65_CAPTURE_SPC_DIR");std::string dir=(d&&*d)?d:"forja65-spc-capture";std::error_code ec;std::filesystem::create_directories(dir,ec);if(ec)throw std::runtime_error("falha ao criar diretorio SPC: "+dir);if(!apu.saveSnapshot((std::filesystem::path(dir)/"spc-ram.bin").string(),(std::filesystem::path(dir)/"spc-capture.txt").string()))throw std::runtime_error("falha ao capturar SPC700");spcCaptureDone=true;std::ofstream log("forja65-spc-capture.log",std::ios::trunc);if(log)log<<"frame="<<frameCounter<<"\ndir="<<dir<<"\nentry=0x"<<std::hex<<apu.spc.pc<<"\n";if(envFlag("FORJA65_CAPTURE_SPC_STOP"))stopped=true;return true;}
  static std::size_t mirrorOffset(std::size_t size,std::size_t off){if(!size)return(std::size_t)-1;if(off<size)return off;std::size_t mask=(std::size_t)1<<(sizeof(std::size_t)*8-1);while(mask&&!(off&mask))mask>>=1;if(!mask)return 0;if(size<=(off&mask))return mirrorOffset(size,off-mask);return mask+mirrorOffset(size-mask,off-mask);}
  std::size_t romOffset(std::uint32_t a)const{unsigned bank=(a>>16)&255,addr=a&0xFFFF;std::size_t off=0;bool full=(bank>=0x40&&bank<=0x7D)||bank>=0xC0;if(mapper==MapperKind::LoROM){if(addr<0x8000&&!full)return(std::size_t)-1;off=((bank&0x7F)<<15)|(addr&0x7FFF);}else if(mapper==MapperKind::HiROM){if(addr<0x8000&&!full)return(std::size_t)-1;off=((bank&0x3F)<<16)|addr;}else{if(addr<0x8000&&!full)return(std::size_t)-1;off=((bank&0x7F)<<16)|addr;if((bank&0x40)==0)off+=0x400000;}return mirrorOffset(romLogicalSize?romLogicalSize:cart.size(),off);}
  bool ioBank(std::uint32_t a)const{unsigned b=(a>>16)&255;return b<=0x3F||(b>=0x80&&b<=0xBF);}
  std::size_t wramOffset(std::uint32_t a)const{unsigned b=(a>>16)&255,lo=a&0xFFFF;if(b==0x7E)return lo;if(b==0x7F)return 0x10000u+lo;if(ioBank(a)&&lo<0x2000)return lo;return(std::size_t)-1;}
  std::size_t sramOffset(std::uint32_t a)const{if(sram.empty())return(std::size_t)-1;unsigned b=(a>>16)&255,lo=a&0xFFFF;if(mapper==MapperKind::LoROM){bool mapped=(b>=0x70&&b<=0x7D)||(b>=0xF0);unsigned hi=(romSizeCode>11u||sramSizeCode>5u)?0x7FFFu:0xFFFFu;if(!mapped||lo>hi)return(std::size_t)-1;std::size_t u=(((a&0xFF0000u)>>1)|(a&0x7FFFu));return u&(sram.size()-1u);}if(mapper==MapperKind::HiROM||mapper==MapperKind::ExHiROM){if(((b>=0x20&&b<=0x3F)||(b>=0xA0&&b<=0xBF))&&lo>=0x6000&&lo<=0x7FFF){std::size_t u=(lo&0x7FFFu)-0x6000u+((a&0x0F0000u)>>3);return u&(sram.size()-1u);}}return(std::size_t)-1;}
  bool cartChipAddress(std::uint32_t a)const{if(cartChip!=CartChip::DSP1)return false;unsigned b=(a>>16)&255,lo=a&0xFFFF;if(mapper==MapperKind::HiROM||mapper==MapperKind::ExHiROM)return((b<=0x1F)||(b>=0x80&&b<=0x9F))&&lo>=0x6000&&lo<=0x7FFF;if(mapper==MapperKind::LoROM){if(romLogicalSize>0x100000u)return((b>=0x60&&b<=0x6F)||(b>=0xE0&&b<=0xEF))&&lo<=0x7FFF;return((b>=0x20&&b<=0x3F)||(b>=0xA0&&b<=0xBF))&&lo>=0x8000;}return false;}
  [[noreturn]] std::uint8_t unresolvedCartChipRead(std::uint32_t a){std::ofstream f("forja65-unresolved-cartchip.txt",std::ios::app);if(f)f<<std::hex<<a<<" read\n";throw std::runtime_error("acesso a coprocessador de cartucho ainda nao recompilado: "+std::to_string(a));}
  [[noreturn]] void unresolvedCartChipWrite(std::uint32_t a,std::uint8_t v){std::ofstream f("forja65-unresolved-cartchip.txt",std::ios::app);if(f)f<<std::hex<<a<<" write="<<(unsigned)v<<"\n";throw std::runtime_error("escrita em coprocessador de cartucho ainda nao recompilada: "+std::to_string(a));}
  void setJoy1(std::uint16_t v){io.joy[0]=v;} void setJoy2(std::uint16_t v){io.joy[1]=v;}
  static constexpr unsigned MASTER_CYCLES_PER_SCANLINE=1364u;
  static constexpr unsigned HBLANK_START_MC=1096u;
  static constexpr unsigned HDMA_START_MC=1106u;
  static constexpr unsigned HBLANK_END_MC=4u;
  static constexpr unsigned RENDER_EVENT_MC=512u; // mantido como referencia/compatibilidade; v0.3.0 rasteriza por segmentos.
  static constexpr unsigned IRQ_TRIGGER_DELAY_MC=14u;
  static constexpr unsigned NMI_TRIGGER_MC=12u;
  static constexpr unsigned WRAM_REFRESH_MC=538u;
  static constexpr unsigned WRAM_REFRESH_CYCLES=40u;
  static constexpr unsigned DMA_SYNC_MC=18u;
  static constexpr std::uint32_t NO_TIMING_ADDR=0xFFFFFFFFu;
  void configureFramebuffer(){fbWidth=ppu.outputWidth();fbHeight=ppu.outputHeight();std::size_t need=(std::size_t)fbWidth*fbHeight;if(framebuffer.size()!=need)framebuffer.assign(need,0xFF000000u);} unsigned visibleLines()const{return ppu.visibleHeight();}
  unsigned busMasterCycles(std::uint32_t a)const{
    a&=0xFFFFFFu;unsigned bank=(a>>16)&0xFFu,lo=a&0xFFFFu;
    if((bank<=0x3Fu)||(bank>=0x80u&&bank<=0xBFu)){
      if(lo<0x2000u)return 8u;
      if(lo<0x4000u)return 6u;
      if(lo<0x4200u)return 12u;
      if(lo<0x6000u)return 6u;
      if(lo<0x8000u)return 8u;
      return(bank>=0x80u&&(io.memsel&1u))?6u:8u;
    }
    if(bank>=0x7Eu&&bank<=0x7Fu)return 8u;
    if(bank>=0xC0u)return(io.memsel&1u)?6u:8u;
    return 8u;
  }
  void setMasterCycle(unsigned mc){currentMasterCycle=mc<MASTER_CYCLES_PER_SCANLINE?mc:MASTER_CYCLES_PER_SCANLINE-1u;ppu.hCounter=(std::uint16_t)((currentMasterCycle/4u)&0x1FFu);io.hblank=(currentMasterCycle<HBLANK_END_MC)||(currentMasterCycle>=HBLANK_START_MC);}
  void advanceCpuMasterCycles(unsigned mc){
    if(!mc)return;
    cpuMasterClock+=mc;lastInstructionMasterCycles+=mc;apu.tickMasterCycles(mc);
    if(!frameTimingActive)beginFrame();
    unsigned remaining=mc;
    while(remaining){
      const unsigned vis=visibleLines(),before=currentMasterCycle;
      const int irqev=irqEventMasterCycle(currentScanline);
      unsigned step=std::min(remaining,MASTER_CYCLES_PER_SCANLINE-before);
      auto clip=[&](unsigned event){if(before<event&&before+step>event)step=event-before;};
      if(!wramRefreshAppliedThisLine)clip(WRAM_REFRESH_MC);
      if(currentScanline<vis){clip(HBLANK_START_MC);if(!hdmaExecutedThisLine)clip(HDMA_START_MC);}
      if(irqev>=0&&!irqFiredThisLine)clip((unsigned)irqev);
      if(currentScanline==vis)clip(NMI_TRIGGER_MC);
      const unsigned target=before+step;remaining-=step;
      if(currentScanline==vis&&before<NMI_TRIGGER_MC&&target>=NMI_TRIGGER_MC){io.nmiPending=true;if(io.nmiEnable)cpuNmiInterruptPending=true;}
      if(currentScanline<vis&&before<HBLANK_START_MC&&target>=HBLANK_START_MC)finishVisibleLine(currentScanline);
      if(target<MASTER_CYCLES_PER_SCANLINE)setMasterCycle(target);else currentMasterCycle=target;
      if(irqev>=0&&!irqFiredThisLine&&before<=(unsigned)irqev&&target>=(unsigned)irqev){io.irqPending=true;cpuIrqInterruptPending=true;irqFiredThisLine=true;}
      if(!wramRefreshAppliedThisLine&&target==WRAM_REFRESH_MC){wramRefreshAppliedThisLine=true;wramRefreshStallMasterCycles+=WRAM_REFRESH_CYCLES;advanceCpuMasterCycles(WRAM_REFRESH_CYCLES);continue;}
      if(currentScanline<vis&&!hdmaExecutedThisLine&&target==HDMA_START_MC){hdmaExecutedThisLine=true;if(hdmaActive)executeHdmaLine();continue;}
      if(target<MASTER_CYCLES_PER_SCANLINE)continue;
      currentScanline++;currentMasterCycle=0;rasterCursorX=0;wramRefreshAppliedThisLine=false;hdmaExecutedThisLine=false;irqFiredThisLine=false;ppu.vCounter=(std::uint16_t)(currentScanline&0x1FFu);setMasterCycle(0);
      if(currentScanline==vis){io.vblank=true;if(io.autoJoypad)pollInput();}
      if(currentScanline>=(isPalRegion(regionCode)?312u:262u)){endVblank();beginFrame();}
    }
  }
  bool cpuEventPending(const CpuState&cpu)const{return cpuNmiInterruptPending||(cpuIrqInterruptPending&&!cpu.i);}
  bool serviceCpuEvents(CpuState&cpu,std::uint32_t resumePc){
    if(cpuNmiInterruptPending){cpuNmiInterruptPending=false;nmiServiceCount++;cpu.enterInterrupt(*this,resumePc,false);addCpuInternalCycles(7u);interruptEntryMasterCycles+=42u;std::uint16_t va=cpu.e?0xFFFAu:0xFFEAu;std::uint16_t dst=(std::uint16_t)(read(va)|(read((va+1u)&0xFFFFu)<<8));requestDispatch((std::uint32_t)dst,0xFFFFF5u);return true;}
    if(cpuIrqInterruptPending&&!cpu.i){irqServiceCount++;cpu.enterInterrupt(*this,resumePc,false);addCpuInternalCycles(7u);interruptEntryMasterCycles+=42u;std::uint16_t va=cpu.e?0xFFFEu:0xFFEEu;std::uint16_t dst=(std::uint16_t)(read(va)|(read((va+1u)&0xFFFFu)<<8));requestDispatch((std::uint32_t)dst,0xFFFFF6u);return true;}
    return false;
  }
  void addCpuInternalCycles(unsigned cycles){advanceCpuMasterCycles(cycles*6u);}
  void advanceCpuInstruction(std::uint32_t pc,unsigned cpuCycles,unsigned fetchBytes,std::uint32_t dataAddr,unsigned dataAccesses,std::uint32_t auxAddr,unsigned auxAccesses,unsigned stackAccesses){
    if(!cpuInstructionTraced||lastInstructionPc!=pc){cpuInstructionCount++;}cpuInstructionTraced=false;lastInstructionPc=pc;lastInstructionMasterCycles=0;
    unsigned mc=cpuCycles*6u,codeSpeed=busMasterCycles(pc);if(codeSpeed>6u)mc+=fetchBytes*(codeSpeed-6u);
    if(dataAddr!=NO_TIMING_ADDR&&dataAccesses){unsigned q=busMasterCycles(dataAddr);if(q>6u)mc+=dataAccesses*(q-6u);}
    if(auxAddr!=NO_TIMING_ADDR&&auxAccesses){unsigned q=busMasterCycles(auxAddr);if(q>6u)mc+=auxAccesses*(q-6u);}
    if(stackAccesses){unsigned q=busMasterCycles(0x000100u);if(q>6u)mc+=stackAccesses*(q-6u);}
    advanceCpuMasterCycles(mc);
  }
  void advanceCpuBlockMove(std::uint32_t pc,std::uint32_t bytes,std::uint8_t srcBank,std::uint8_t dstBank){
    if(!cpuInstructionTraced||lastInstructionPc!=pc){cpuInstructionCount++;}cpuInstructionTraced=false;lastInstructionPc=pc;lastInstructionMasterCycles=0;if(!bytes)bytes=0x10000u;
    unsigned codeSpeed=busMasterCycles(pc),srcSpeed=busMasterCycles(std::uint32_t(srcBank)<<16),dstSpeed=busMasterCycles(std::uint32_t(dstBank)<<16);
    std::uint64_t per=42u+(codeSpeed>6u?codeSpeed-6u:0u)+(srcSpeed>6u?srcSpeed-6u:0u)+(dstSpeed>6u?dstSpeed-6u:0u),total=per*bytes;
    while(total){unsigned q=(unsigned)std::min<std::uint64_t>(total,0xFFFFFFFFu);advanceCpuMasterCycles(q);total-=q;}
  }
  void syncPpuBeforeMutation(){if(frameTimingActive&&currentScanline<visibleLines()&&currentMasterCycle<HBLANK_START_MC)renderVisibleUntilMasterCycle(currentScanline,currentMasterCycle);}
  unsigned irqHMasterCycle()const{unsigned h=io.htime&0x1FFu;unsigned mc=h*4u+IRQ_TRIGGER_DELAY_MC;if(h==0u)mc-=4u;if(h>322u)mc+=2u;if(h>326u)mc+=2u;return mc<MASTER_CYCLES_PER_SCANLINE?mc:MASTER_CYCLES_PER_SCANLINE-1u;}
  int irqEventMasterCycle(unsigned line)const{unsigned v=line&0x1FFu;if(io.hIrqEnable&&io.vIrqEnable)return v==(io.vtime&0x1FFu)?(int)irqHMasterCycle():-1;if(io.hIrqEnable)return(int)irqHMasterCycle();if(io.vIrqEnable)return v==(io.vtime&0x1FFu)?(int)IRQ_TRIGGER_DELAY_MC:-1;return-1;}
  unsigned rasterLogicalXFromMasterCycle(unsigned mc)const{if(mc<=IRQ_TRIGGER_DELAY_MC)return 0u;unsigned x=(mc-IRQ_TRIGGER_DELAY_MC)/4u;return std::min(x,256u);}
  unsigned rasterOutputXFromMasterCycle(unsigned mc)const{unsigned x=rasterLogicalXFromMasterCycle(mc);return fbWidth>=512u?std::min(x*2u,fbWidth):std::min(x,fbWidth);}
  void beginScanline(unsigned line){currentScanline=line;irqFiredThisLine=false;rasterCursorX=0;wramRefreshAppliedThisLine=false;hdmaExecutedThisLine=false;ppu.vCounter=(std::uint16_t)(line&0x1FFu);setMasterCycle(0);setMasterCycle(HBLANK_END_MC);}
  bool fireIrqAt(unsigned line,unsigned mc){if(irqFiredThisLine)return false;int ev=irqEventMasterCycle(line);if(ev<0||mc<(unsigned)ev)return false;currentScanline=line;setMasterCycle((unsigned)ev);irqFiredThisLine=true;io.irqPending=true;cpuIrqInterruptPending=true;return true;}
  bool irqAtScanline(unsigned line){beginScanline(line);int ev=irqEventMasterCycle(line);return ev>=0?fireIrqAt(line,(unsigned)ev):false;}
  void beginFrame(){frameTimingActive=true;io.vblank=false;io.nmiPending=false;io.hblank=true;currentScanline=0;currentMasterCycle=0;wramRefreshAppliedThisLine=false;hdmaExecutedThisLine=false;configureFramebuffer();startHdmaFrame(io.hdmaen);const bool replay=applyReplayInput();if(!replay&&io.autoJoypad)pollInput();recordInputFrame();trace.emit(frameCounter,traceRoutine,lastInstructionPc,"input","INPUT",0,io.joy[0],"INPUT");trace.emit(frameCounter,traceRoutine,lastInstructionPc,"input","INPUT",1,io.joy[1],"INPUT");}
  void renderVisibleUntilMasterCycle(unsigned line,unsigned mc){if(line>=visibleLines())return;currentScanline=line;ppu.vCounter=(std::uint16_t)(line&0x1FFu);unsigned end=rasterOutputXFromMasterCycle(mc);if(end>rasterCursorX){ppu.renderOutputSegment(framebuffer,(int)line,rasterCursorX,end,interlaceField?1u:0u);rasterCursorX=end;}setMasterCycle(mc);}
  void finishVisibleLine(unsigned line){if(line>=visibleLines())return;unsigned end=fbWidth;if(end>rasterCursorX){ppu.renderOutputSegment(framebuffer,(int)line,rasterCursorX,end,interlaceField?1u:0u);rasterCursorX=end;}setMasterCycle(HBLANK_START_MC);}
  void renderVisibleLine(unsigned line){beginScanline(line);finishVisibleLine(line);}
  void beginHblank(){setMasterCycle(HBLANK_START_MC);} void endHblank(){setMasterCycle(HBLANK_END_MC);}
  void beginVblank(unsigned line){io.vblank=true;currentScanline=line;beginScanline(line);setMasterCycle(NMI_TRIGGER_MC);io.nmiPending=true;if(io.nmiEnable)cpuNmiInterruptPending=true;if(io.autoJoypad)pollInput();}
  void beginVblank(){beginVblank(visibleLines());}
  void endVblank(){io.vblank=false;frameTimingActive=false;appendFrameHash();appendNativeAuditFrame();frameCounter++;maybeCaptureSpcSnapshot();maybeCaptureNativeScene();hostFrameReady=true;if(ppu.interlace())interlaceField=!interlaceField;else interlaceField=false;}
  void pollInput(){
#ifdef _WIN32
    std::uint16_t j=0;auto kd=[](int k){return (GetAsyncKeyState(k)&0x8000)!=0;};if(kd('X'))j|=0x8000;if(kd('Z'))j|=0x4000;if(kd(VK_SHIFT))j|=0x2000;if(kd(VK_RETURN))j|=0x1000;if(kd(VK_UP))j|=0x0800;if(kd(VK_DOWN))j|=0x0400;if(kd(VK_LEFT))j|=0x0200;if(kd(VK_RIGHT))j|=0x0100;if(kd('A'))j|=0x0080;if(kd('S'))j|=0x0040;if(kd('Q'))j|=0x0020;if(kd('W'))j|=0x0010;
    XINPUT_STATE xs{};if(XInputGetState(0,&xs)==ERROR_SUCCESS){const auto&g=xs.Gamepad;const auto b=g.wButtons;if((b&XINPUT_GAMEPAD_Y)!=0)j|=0x8000;if((b&XINPUT_GAMEPAD_B)!=0)j|=0x4000;if((b&XINPUT_GAMEPAD_BACK)!=0)j|=0x2000;if((b&XINPUT_GAMEPAD_START)!=0)j|=0x1000;if((b&XINPUT_GAMEPAD_DPAD_UP)!=0||g.sThumbLY>9000)j|=0x0800;if((b&XINPUT_GAMEPAD_DPAD_DOWN)!=0||g.sThumbLY<-9000)j|=0x0400;if((b&XINPUT_GAMEPAD_DPAD_LEFT)!=0||g.sThumbLX<-9000)j|=0x0200;if((b&XINPUT_GAMEPAD_DPAD_RIGHT)!=0||g.sThumbLX>9000)j|=0x0100;if((b&XINPUT_GAMEPAD_X)!=0)j|=0x0080;if((b&XINPUT_GAMEPAD_A)!=0)j|=0x0040;if((b&XINPUT_GAMEPAD_LEFT_SHOULDER)!=0)j|=0x0020;if((b&XINPUT_GAMEPAD_RIGHT_SHOULDER)!=0)j|=0x0010;}setJoy1(j);
#endif
  }
#ifdef _WIN32
  static LRESULT CALLBACK wndProc(HWND h,UINT m,WPARAM w,LPARAM l){if(m==WM_CLOSE){DestroyWindow(h);return 0;}if(m==WM_DESTROY){PostQuitMessage(0);return 0;}return DefWindowProc(h,m,w,l);}
  unsigned bestIntegerScale(unsigned srcW,unsigned srcH)const{
    RECT wa{};SystemParametersInfoW(SPI_GETWORKAREA,0,&wa,0);
    unsigned availW=(unsigned)std::max<LONG>(320,(wa.right-wa.left)-80);
    unsigned availH=(unsigned)std::max<LONG>(240,(wa.bottom-wa.top)-100);
    unsigned sx=srcW?availW/srcW:1u,sy=srcH?availH/srcH:1u;
    return std::max(1u,std::min(8u,std::min(sx,sy)));
  }
  void fitClientToIntegerScale(unsigned srcW,unsigned srcH){
    if(!hwnd)return;unsigned sc=bestIntegerScale(srcW,srcH);
    RECT r{0,0,(LONG)(srcW*sc),(LONG)(srcH*sc)};AdjustWindowRect(&r,WS_OVERLAPPEDWINDOW,FALSE);
    SetWindowPos(hwnd,nullptr,0,0,r.right-r.left,r.bottom-r.top,SWP_NOMOVE|SWP_NOZORDER|SWP_NOACTIVATE);
  }
  void initWindow(){hinst=GetModuleHandle(nullptr);WNDCLASSW wc{};wc.lpfnWndProc=wndProc;wc.hInstance=hinst;wc.lpszClassName=L"Forja65NativeWindow";wc.hCursor=LoadCursor(nullptr,IDC_ARROW);wc.hbrBackground=(HBRUSH)GetStockObject(BLACK_BRUSH);RegisterClassW(&wc);RECT r{0,0,1024,896};AdjustWindowRect(&r,WS_OVERLAPPEDWINDOW,FALSE);hwnd=CreateWindowW(wc.lpszClassName,L"Forja65 Native Port - Integer HD",WS_OVERLAPPEDWINDOW|WS_VISIBLE,CW_USEDEFAULT,CW_USEDEFAULT,r.right-r.left,r.bottom-r.top,nullptr,nullptr,hinst,nullptr);fitClientToIntegerScale(256,224);}
  void shutdownWindow(){if(hwnd&&IsWindow(hwnd))DestroyWindow(hwnd);hwnd=nullptr;}
  void paceHostFrame(){if(headless||envFlag("FORJA65_UNCAPPED"))return;auto now=std::chrono::steady_clock::now();auto step=std::chrono::duration_cast<std::chrono::steady_clock::duration>(std::chrono::duration<double>(1.0/hostRefreshHz()));if(!framePacingStarted){nextPresent=now+step;framePacingStarted=true;}else nextPresent+=step;if(nextPresent<now-std::chrono::milliseconds(250))nextPresent=now+step;std::this_thread::sleep_until(nextPresent);}
  void present(){if(headless){const char*e=std::getenv("FORJA65_HEADLESS_FRAMES");unsigned lim=(e&&*e)?(unsigned)std::strtoul(e,nullptr,10):0u;if(lim&&frameCounter>=lim)stopped=true;return;}MSG msg{};while(PeekMessage(&msg,nullptr,0,0,PM_REMOVE)){if(msg.message==WM_QUIT){windowClosed=true;stopped=true;break;}TranslateMessage(&msg);DispatchMessage(&msg);}if(!hwnd||stopped)return;auto& fb=framebuffer;BITMAPINFO bi{};bi.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);bi.bmiHeader.biWidth=(LONG)fbWidth;bi.bmiHeader.biHeight=-(LONG)fbHeight;bi.bmiHeader.biPlanes=1;bi.bmiHeader.biBitCount=32;bi.bmiHeader.biCompression=BI_RGB;RECT rc{};GetClientRect(hwnd,&rc);int cw=std::max<LONG>(1,rc.right-rc.left),ch=std::max<LONG>(1,rc.bottom-rc.top);int sc=std::max(1,std::min(cw/(int)fbWidth,ch/(int)fbHeight));int dw=(int)fbWidth*sc,dh=(int)fbHeight*sc,dx=(cw-dw)/2,dy=(ch-dh)/2;HDC dc=GetDC(hwnd);HBRUSH black=(HBRUSH)GetStockObject(BLACK_BRUSH);FillRect(dc,&rc,black);SetStretchBltMode(dc,COLORONCOLOR);StretchDIBits(dc,dx,dy,dw,dh,0,0,(int)fbWidth,(int)fbHeight,fb.data(),&bi,DIB_RGB_COLORS,SRCCOPY);ReleaseDC(hwnd,dc);paceHostFrame();}
#else
  void initWindow(){} void shutdownWindow(){} void paceHostFrame(){} void present(){const char*e=std::getenv("FORJA65_HEADLESS_FRAMES");unsigned lim=(e&&*e)?(unsigned)std::strtoul(e,nullptr,10):2u;if(lim&&frameCounter>=lim)stopped=true;}
#endif
  static const std::uint8_t* dmaPattern(std::uint8_t mode,std::size_t& n){static const std::uint8_t p0[]={0};static const std::uint8_t p1[]={0,1};static const std::uint8_t p2[]={0,0};static const std::uint8_t p3[]={0,0,1,1};static const std::uint8_t p4[]={0,1,2,3};static const std::uint8_t p5[]={0,1,0,1};static const std::uint8_t p6[]={0,0};static const std::uint8_t p7[]={0,0,1,1};switch(mode&7){case 0:n=1;return p0;case 1:n=2;return p1;case 2:n=2;return p2;case 3:n=4;return p3;case 4:n=4;return p4;case 5:n=4;return p5;case 6:n=2;return p6;default:n=4;return p7;}}
  std::uint8_t getDmaReg(unsigned ch,unsigned r)const{const auto&d=dma[ch&7];switch(r&0xF){case 0:return d.dmap;case 1:return d.bbad;case 2:return d.a1t&0xFF;case 3:return d.a1t>>8;case 4:return d.a1b;case 5:return d.das&0xFF;case 6:return d.das>>8;case 7:return d.dasb;case 8:return d.a2a&0xFF;case 9:return d.a2a>>8;case 0xA:return d.ntrl;default:return 0;}}
  void setDmaReg(unsigned ch,unsigned r,std::uint8_t v){auto&d=dma[ch&7];switch(r&0xF){case 0:d.dmap=v;break;case 1:d.bbad=v;break;case 2:d.a1t=(d.a1t&0xFF00)|v;break;case 3:d.a1t=(d.a1t&0x00FF)|(std::uint16_t(v)<<8);break;case 4:d.a1b=v;break;case 5:d.das=(d.das&0xFF00)|v;break;case 6:d.das=(d.das&0x00FF)|(std::uint16_t(v)<<8);break;case 7:d.dasb=v;break;case 8:d.a2a=(d.a2a&0xFF00)|v;break;case 9:d.a2a=(d.a2a&0x00FF)|(std::uint16_t(v)<<8);break;case 0xA:d.ntrl=v;break;default:break;}}
  void primeHdmaChannel(unsigned ch){ch&=7u;hdmaLines[ch]=0;hdmaEveryLine[ch]=false;hdmaTransfer[ch]=false;dma[ch].a2a=dma[ch].a1t;dma[ch].ntrl=0;hdmaInitialized[ch]=true;}
  void startHdmaFrame(std::uint8_t mask){io.hdmaen=mask;hdmaEnded=0;hdmaActive=mask;for(unsigned ch=0;ch<8;ch++){hdmaInitialized[ch]=false;hdmaLines[ch]=0;hdmaEveryLine[ch]=false;hdmaTransfer[ch]=false;if(mask&(1u<<ch))primeHdmaChannel(ch);}}
  void setHdmaEnable(std::uint8_t mask){io.hdmaen=mask;std::uint8_t requested=(std::uint8_t)(mask&~hdmaEnded);std::uint8_t newly=(std::uint8_t)(requested&~hdmaActive);for(unsigned ch=0;ch<8;ch++)if((newly&(1u<<ch))&&!hdmaInitialized[ch])primeHdmaChannel(ch);hdmaActive=requested;}
  void initializeHdma(std::uint8_t mask){startHdmaFrame(mask);}
  std::uint8_t ppuPortRead(std::uint16_t lo){hwUsage.ppuReads++;rememberFirst(firstPpuPc,lastInstructionPc);if(ppuMode==PpuRuntimeMode::StateOnlyNativeScanout)hwUsage.ppuNativeReads++;else hwUsage.ppuFallbackReads++;return ppu.read(lo);}
  void ppuPortWrite(std::uint16_t lo,std::uint8_t v){hwUsage.ppuWrites++;rememberFirst(firstPpuPc,lastInstructionPc);if(ppuMode==PpuRuntimeMode::StateOnlyNativeScanout)hwUsage.ppuNativeWrites++;else hwUsage.ppuFallbackWrites++;syncPpuBeforeMutation();ppu.write(lo,v);}
  bool nativeBbusRead(std::uint16_t bbus,std::uint8_t&v){if(bbus>=0x2100u&&bbus<=0x213Fu){v=ppuPortRead(bbus);observeBus("read",bbus,v);return true;}if(bbus>=0x2140u&&bbus<=0x2143u){hwUsage.apuReads++;rememberFirst(firstApuPc,lastInstructionPc);v=apu.read(bbus-0x2140u);observeBus("read",bbus,v);return true;}if(bbus==0x2180u){hwUsage.wramReads++;v=ram[io.wramPortAddr&0x1FFFFu];observeBus("read",bbus,v);io.wramPortAddr=(io.wramPortAddr+1)&0x1FFFFu;return true;}return false;}
  bool nativeBbusWrite(std::uint16_t bbus,std::uint8_t v){if(bbus>=0x2100u&&bbus<=0x213Fu){observeBus("write",bbus,v);ppuPortWrite(bbus,v);return true;}if(bbus>=0x2140u&&bbus<=0x2143u){hwUsage.apuWrites++;rememberFirst(firstApuPc,lastInstructionPc);observeBus("write",bbus,v);apu.write(bbus-0x2140u,v);return true;}if(bbus==0x2180u){observeBus("write",bbus,v);hwUsage.wramWrites++;ram[io.wramPortAddr&0x1FFFFu]=v;io.wramPortAddr=(io.wramPortAddr+1)&0x1FFFFu;return true;}return false;}
  void executeHdmaLine(){hdmaExecutedThisLine=true;ForjaTraceContext context(traceRoutine,traceSource,traceRoutine,"HDMA");if(hdmaActive)trace.emit(frameCounter,traceRoutine,lastInstructionPc,"hdma","DMA_REG",0x420Cu,hdmaActive,"HDMA");advanceCpuMasterCycles(DMA_SYNC_MC);hdmaStallMasterCycles+=DMA_SYNC_MC;rememberFirst(firstHdmaPc,lastInstructionPc);for(unsigned ch=0;ch<8;ch++){if(!(hdmaActive&(1u<<ch)))continue;auto&d=dma[ch];if(hdmaLines[ch]==0){std::uint32_t table=(std::uint32_t(d.a1b)<<16)|d.a2a;std::uint8_t desc=(std::uint8_t)read(table);d.a2a++;if(desc==0){hdmaEnded|=(std::uint8_t)(1u<<ch);hdmaActive&=(std::uint8_t)~(1u<<ch);hdmaTransfer[ch]=false;continue;}hdmaEveryLine[ch]=(desc&0x80u)!=0;hdmaLines[ch]=(desc&0x7Fu)?(desc&0x7Fu):128u;hdmaTransfer[ch]=true;if(d.dmap&0x40){std::uint32_t p=(std::uint32_t(d.a1b)<<16)|d.a2a;d.das=(std::uint16_t)(read(p)|(read(p+1)<<8));d.a2a+=2;}}
    if(hdmaTransfer[ch]){std::size_t pn=0;const auto*pat=dmaPattern(d.dmap,pn);bool indirect=(d.dmap&0x40u)!=0,reverse=(d.dmap&0x80u)!=0;std::uint32_t src=indirect?((std::uint32_t(d.dasb)<<16)|d.das):((std::uint32_t(d.a1b)<<16)|d.a2a);for(std::size_t k=0;k<pn;k++){hwUsage.hdmaBytes++;std::uint16_t bbus=(std::uint16_t)(0x2100u|((d.bbad+pat[k])&0xFFu));bool nativeDone=false;if(reverse){std::uint8_t v=0;if(nativeDmaEnabled&&nativeBbusRead(bbus,v)){write8(src,v);nativeDone=true;}else{v=(std::uint8_t)read(bbus);write8(src,v);}}else{std::uint8_t v=(std::uint8_t)read(src);if(nativeDmaEnabled&&nativeBbusWrite(bbus,v))nativeDone=true;else write8(bbus,v);}if(nativeDone)hwUsage.hdmaNativeBytes++;else hwUsage.hdmaFallbackBytes++;src=(src+1)&0xFFFFFFu;advanceCpuMasterCycles(8u);hdmaStallMasterCycles+=8u;}if(indirect)d.das=(std::uint16_t)src;else d.a2a=(std::uint16_t)src;}
    if(hdmaLines[ch]){hdmaLines[ch]--;}if(hdmaLines[ch]==0)hdmaTransfer[ch]=true;else hdmaTransfer[ch]=hdmaEveryLine[ch];unsigned left=hdmaLines[ch]==128u?0u:(hdmaLines[ch]&0x7Fu);d.ntrl=(std::uint8_t)((hdmaEveryLine[ch]?0x80u:0u)|left);}}
  std::uint32_t read(std::uint32_t a){const auto v=readBus(a);observeBus("read",a,v);return v;}
  std::uint32_t readBus(std::uint32_t a){a&=0xFFFFFF;std::uint16_t lo=a&0xFFFF;if(ioBank(a)){if(lo>=0x2100&&lo<=0x213F)return ppuPortRead(lo);if(lo>=0x2140&&lo<=0x2143){hwUsage.apuReads++;rememberFirst(firstApuPc,lastInstructionPc);return apu.read(lo-0x2140);}hwUsage.ioReads++;if(lo==0x2180){hwUsage.wramReads++;auto v=ram[io.wramPortAddr&0x1FFFFu];io.wramPortAddr=(io.wramPortAddr+1)&0x1FFFFu;return v;}if(lo==0x4016)return io.readJoySerial(0);if(lo==0x4017)return io.readJoySerial(1);if(lo==0x4200)return io.nmitimen;if(lo==0x4201||lo==0x4213)return io.wrio;if(lo==0x420B)return io.mdmaen;if(lo==0x420C)return io.hdmaen;if(lo==0x420D)return io.memsel;if(lo==0x4210){auto v=(std::uint8_t)(io.nmiPending?0x80:0);io.nmiPending=false;return v;}if(lo==0x4211){auto v=(std::uint8_t)(io.irqPending?0x80:0);io.irqPending=false;cpuIrqInterruptPending=false;return v;}if(lo==0x4212)return (io.vblank?0x80:0)|(io.hblank?0x40:0);if(lo==0x4214)return io.quotient&0xFF;if(lo==0x4215)return io.quotient>>8;if(lo==0x4216)return io.remainder&0xFF;if(lo==0x4217)return io.remainder>>8;if(lo>=0x4218&&lo<=0x421F){unsigned p=(lo-0x4218)>>1;return (lo&1)?(io.joy[p]>>8):(io.joy[p]&0xFF);}if(lo>=0x4300&&lo<=0x437F)return getDmaReg((lo-0x4300)>>4,lo&0xF);}auto wo=wramOffset(a);if(wo!=(std::size_t)-1){hwUsage.wramReads++;return ram[wo];}auto so=sramOffset(a);if(so!=(std::size_t)-1){hwUsage.sramReads++;return sram[so];}if(cartChipAddress(a)){hwUsage.cartChipReads++;return unresolvedCartChipRead(a);}auto ro=romOffset(a);if(ro!=(std::size_t)-1){hwUsage.romReads++;rememberFirst(firstRomPc,lastInstructionPc);markRomRead(ro);std::uint8_t nv=0;if(nativeRom.read(ro,nv)){hwUsage.romNativeReads++;return nv;}if(!cart.empty()&&ro<cart.size()){hwUsage.romFallbackReads++;return cart[ro];}std::ofstream miss("forja65-native-rom-missing.txt",std::ios::app);if(miss)miss<<std::hex<<ro<<" snes="<<a<<" pc="<<lastInstructionPc<<"\n";throw std::runtime_error("native ROM pack sem offset 0x"+([&](){std::ostringstream q;q<<std::hex<<ro;return q.str();})());}return 0;}
  std::uint32_t readW(std::uint32_t a,int w){std::uint32_t v=read(a);if(w==16)v|=read((a+1)&0xFFFFFF)<<8;return v;} std::uint32_t read24(std::uint32_t a){return read(a)|(read((a+1)&0xFFFFFF)<<8)|(read((a+2)&0xFFFFFF)<<16);} std::uint16_t read16BankWrap(std::uint32_t a){a&=0xFFFFFFu;auto b=(a&0xFF0000u)|((a+1u)&0xFFFFu);return(std::uint16_t)(read(a)|(read(b)<<8));}
  void executeDma(std::uint8_t mask){ForjaTraceContext context(traceRoutine,traceSource,traceRoutine,"DMA");trace.emit(frameCounter,traceRoutine,lastInstructionPc,"dma","DMA_REG",0x420Bu,mask,"DMA");io.mdmaen=mask;rememberFirst(firstDmaPc,lastInstructionPc);for(unsigned ch=0;ch<8;ch++)if(mask&(1u<<ch)){auto&d=dma[ch];advanceCpuMasterCycles(8u);dmaStallMasterCycles+=8u;std::uint32_t count=d.das?d.das:0x10000u,src=(std::uint32_t(d.a1b)<<16)|d.a1t;bool reverse=d.dmap&0x80,fixed=(d.dmap&0x08)!=0,decrement=(d.dmap&0x10)!=0;std::size_t pn=0;const auto*pat=dmaPattern(d.dmap,pn);for(std::uint32_t k=0;k<count;k++){hwUsage.dmaBytes++;std::uint16_t bbus=(std::uint16_t)(0x2100u|((d.bbad+pat[k%pn])&0xFFu));bool nativeDone=false;if(reverse){std::uint8_t v=0;if(nativeDmaEnabled&&nativeBbusRead(bbus,v)){write8(src,v);nativeDone=true;}else{v=(std::uint8_t)read(bbus);write8(src,v);}}else{auto v=(std::uint8_t)read(src);if(nativeDmaEnabled&&nativeBbusWrite(bbus,v))nativeDone=true;else write8(bbus,v);}if(nativeDone)hwUsage.dmaNativeBytes++;else hwUsage.dmaFallbackBytes++;if(!fixed)src=(src&0xFF0000u)|((src+(decrement?0xFFFFu:1u))&0xFFFFu);advanceCpuMasterCycles(8u);dmaStallMasterCycles+=8u;}d.a1t=src&0xFFFF;d.a1b=(src>>16)&0xFF;d.das=0;}io.mdmaen=0;}
  void write8(std::uint32_t a,std::uint8_t v){observeBus("write",a,v);a&=0xFFFFFF;std::uint16_t lo=a&0xFFFF;if(ioBank(a)){if(lo>=0x2100&&lo<=0x213F){ppuPortWrite(lo,v);return;}if(lo>=0x2140&&lo<=0x2143){hwUsage.apuWrites++;rememberFirst(firstApuPc,lastInstructionPc);apu.write(lo-0x2140,v);return;}hwUsage.ioWrites++;if(lo==0x2180){hwUsage.wramWrites++;ram[io.wramPortAddr&0x1FFFFu]=v;io.wramPortAddr=(io.wramPortAddr+1)&0x1FFFFu;return;}if(lo==0x2181){io.wramPortAddr=(io.wramPortAddr&0x1FF00u)|v;return;}if(lo==0x2182){io.wramPortAddr=(io.wramPortAddr&0x100FFu)|(std::uint32_t(v)<<8);return;}if(lo==0x2183){io.wramPortAddr=(io.wramPortAddr&0x0FFFFu)|(std::uint32_t(v&1u)<<16);return;}if(lo==0x4016){io.setJoyStrobe((v&1u)!=0);return;}if(lo==0x4200){bool enabled=io.nmiEnable;io.setNmitimen(v);if(!(v&0x30u)){io.irqPending=false;cpuIrqInterruptPending=false;}if(!enabled&&io.nmiEnable&&io.nmiPending&&io.vblank)cpuNmiInterruptPending=true;return;}if(lo==0x4201){io.wrio=v;return;}if(lo==0x4202){io.wrmpya=v;return;}if(lo==0x4203){io.multiply(v);return;}if(lo==0x4204){io.wrdiv=(io.wrdiv&0xFF00u)|v;return;}if(lo==0x4205){io.wrdiv=(io.wrdiv&0x00FFu)|(std::uint16_t(v)<<8);return;}if(lo==0x4206){io.divide(v);return;}if(lo==0x4207){io.htime=(io.htime&0x100u)|v;return;}if(lo==0x4208){io.htime=(io.htime&0x0FFu)|((std::uint16_t)(v&1u)<<8);return;}if(lo==0x4209){io.vtime=(io.vtime&0x100u)|v;return;}if(lo==0x420A){io.vtime=(io.vtime&0x0FFu)|((std::uint16_t)(v&1u)<<8);return;}if(lo==0x420B){executeDma(v);return;}if(lo==0x420C){setHdmaEnable(v);return;}if(lo==0x420D){io.memsel=v;return;}if(lo>=0x4300&&lo<=0x437F){setDmaReg((lo-0x4300)>>4,lo&0xF,v);return;}}auto wo=wramOffset(a);if(wo!=(std::size_t)-1){hwUsage.wramWrites++;ram[wo]=v;return;}auto so=sramOffset(a);if(so!=(std::size_t)-1){hwUsage.sramWrites++;sram[so]=v;sramDirty=true;return;}if(cartChipAddress(a)){hwUsage.cartChipWrites++;unresolvedCartChipWrite(a,v);return;}/* ROM e regioes sem RAM sao somente leitura/ignoradas nesta ponte. */}
  void write(std::uint32_t a,std::uint32_t v,int w){write8(a,(std::uint8_t)(v&0xFF));if(w==16)write8((a+1)&0xFFFFFF,(std::uint8_t)((v>>8)&0xFF));}
  void traceInstruction(std::uint32_t pc,const CpuState& cpu,unsigned opcode=256u){
    if(hostFrameReady){hostFrameReady=false;present();if(stopped)throw std::runtime_error("FORJA65_HEADLESS_COMPLETE");}
    lastInstructionPc=pc&0xFFFFFFu; cpuInstructionCount++;cpuInstructionTraced=true;trace.emit(frameCounter,traceRoutine,lastInstructionPc,"instruction","CPU",lastInstructionPc,opcode,traceSource);
    cpuTrace[cpuTracePos]={pc&0xFFFFFFu,cpu.a,cpu.x,cpu.y,cpu.s,cpu.d,cpu.db,cpu.pb,cpu.packP(),cpu.e,cpu.m8,cpu.x8,cpu.c};
    cpuTracePos=(cpuTracePos+1)%cpuTrace.size(); if(cpuTraceCount<cpuTrace.size())cpuTraceCount++;
    if(instructionWatchdogLimit&&cpuInstructionCount>=instructionWatchdogLimit){dumpCpuTrace("instruction-watchdog");throw std::runtime_error("watchdog de instrucoes atingido");}
  }
  void dumpCpuTrace(const std::string& reason)const{
    std::ofstream f("forja65-crash-trace.txt",std::ios::trunc); if(!f)return;
    f<<"FORJA65 RUNTIME TRACE\nreason="<<reason<<"\nframe="<<frameCounter<<" instruction="<<cpuInstructionCount<<" scanline="<<currentScanline<<" master_cycle="<<currentMasterCycle<<"\n";
    f<<std::hex<<"wram_004a_0052="; for(unsigned a=0x4A;a<=0x52;a++)f<<(unsigned)ram[a]<<(a==0x52?'\n':' ');
    f<<"apu_in="<<(unsigned)apu.spc.portOut[0]<<' '<<(unsigned)apu.spc.portOut[1]<<' '<<(unsigned)apu.spc.portOut[2]<<' '<<(unsigned)apu.spc.portOut[3]<<" apu_out="<<(unsigned)apu.spc.portIn[0]<<' '<<(unsigned)apu.spc.portIn[1]<<' '<<(unsigned)apu.spc.portIn[2]<<' '<<(unsigned)apu.spc.portIn[3]<<"\n";
    f<<std::dec<<"native_return_depth="<<nativeReturns.size()<<"\n";
    std::size_t st=(cpuTracePos+cpuTrace.size()-cpuTraceCount)%cpuTrace.size();
    for(std::size_t k=0;k<cpuTraceCount;k++){const auto&e=cpuTrace[(st+k)%cpuTrace.size()];f<<std::hex<<e.pc<<" A="<<e.a<<" X="<<e.x<<" Y="<<e.y<<" S="<<e.s<<" D="<<e.d<<" DB="<<(unsigned)e.db<<" PB="<<(unsigned)e.pb<<" P="<<(unsigned)e.p<<" E="<<e.e<<" M="<<e.m8<<" X8="<<e.x8<<" C="<<e.c<<"\n";}
  }
  void requestDispatch(std::uint32_t target,std::uint32_t from){dispatchPending=true;dispatchTarget=target&0xFFFFFFu;dispatchFrom=from&0xFFFFFFu;}
  void pushNativeReturn(std::uint32_t t,bool longCall){nativeReturns.push_back({t&0xFFFFFFu,longCall});}
  bool nativeReturnMatches(std::uint32_t t,bool longCall)const{return!nativeReturns.empty()&&nativeReturns.back().target==(t&0xFFFFFFu)&&nativeReturns.back().longCall==longCall;}
  void popNativeReturn(){if(!nativeReturns.empty())nativeReturns.pop_back();}
  static bool fileHasExactLine(const std::string&path,const std::string&line){std::ifstream in(path);std::string q;while(std::getline(in,q))if(q==line)return true;return false;}
  void appendRuntimeHint(std::uint32_t pc,std::uint32_t t,const CpuState&cpu,const char*kind){std::ostringstream ss;ss<<"rom="<<cartHashHex()<<" target="<<std::hex<<(t&0xFFFFFFu)<<" from="<<(pc&0xFFFFFFu)<<" kind="<<kind<<" e="<<std::dec<<(cpu.e?1:0)<<" m="<<(cpu.m8?1:0)<<" x="<<(cpu.x8?1:0)<<" c="<<(cpu.c?1:0);const auto line=ss.str();for(const char*path:{"forja65-oracle-hints.txt","forja65-runtime-hints.txt"})if(!fileHasExactLine(path,line)){std::ofstream h(path,std::ios::app);if(h)h<<line<<"\n";}std::ofstream obs("forja65-oracle-observations.log",std::ios::app);if(obs)obs<<line<<" frame="<<frameCounter<<" instruction="<<cpuInstructionCount<<" pb="<<std::hex<<(unsigned)cpu.pb<<" db="<<(unsigned)cpu.db<<" s="<<cpu.s<<" d="<<cpu.d<<"\n";}
  [[noreturn]] void unresolvedReturn(std::uint32_t pc,std::uint32_t t,const CpuState&cpu,const char*kind="STACK-RETURN"){std::ofstream f("forja65-unresolved-returns.txt",std::ios::app);if(f)f<<std::hex<<pc<<" -> "<<t<<"\n";appendRuntimeHint(pc,t,cpu,kind);dumpCpuTrace("unresolved-return");throw std::runtime_error("retorno 65C816 nao corresponde ao frame C++ recompilado");}
  [[noreturn]] void unsupported(std::uint32_t pc,std::uint32_t op){throw std::runtime_error("opcode nao recompilado: pc="+std::to_string(pc)+" op="+std::to_string(op));} [[noreturn]] void partial(std::uint32_t pc,const std::string& what){throw std::runtime_error("recurso parcial em pc="+std::to_string(pc)+": "+what);} [[noreturn]] void unresolvedState(std::uint32_t from,std::uint32_t pc,bool e,bool m,bool x,bool c){std::ofstream f("forja65-unresolved-state.txt",std::ios::app);if(f)f<<std::hex<<from<<" -> "<<pc<<" e="<<e<<" m="<<m<<" x="<<x<<" c="<<c<<"\n";/* legacy runtime hint shape: kind=STATE ; c="<<(c?1:0) */ CpuState observed;observed.e=e;observed.m8=m;observed.x8=x;observed.c=c;observed.pb=(std::uint8_t)(pc>>16);appendRuntimeHint(from,pc,observed,"STATE");dumpCpuTrace("unresolved-state");throw std::runtime_error("estado M/X/C nao recompilado em pc="+std::to_string(pc));} [[noreturn]] void unresolvedFlow(std::uint32_t pc,std::uint32_t target,const CpuState&cpu){appendRuntimeHint(pc,target,cpu,"FLOW");unresolvedFlow(pc,target);} [[noreturn]] void unresolvedFlow(std::uint32_t pc,std::uint32_t target){std::ofstream f("forja65-unresolved-targets.txt",std::ios::app);if(f)f<<std::hex<<pc<<" -> "<<target<<"\n";dumpCpuTrace("unresolved-flow");throw std::runtime_error("fluxo CFG nao resolvido em pc="+std::to_string(pc)+" target="+std::to_string(target));}
};
inline std::uint16_t forja65_read16_bank0(SnesRuntime& hw,std::uint16_t p){return(std::uint16_t)(hw.read(p)|(hw.read((std::uint16_t)(p+1))<<8));}
inline std::uint32_t CpuState::addressDpIndirectX(SnesRuntime& hw,std::uint32_t q)const{std::uint16_t p=(std::uint16_t)(d+q+x),base=forja65_read16_bank0(hw,p);return((std::uint32_t)db<<16)|base;}
inline std::uint32_t CpuState::addressDpIndirect(SnesRuntime& hw,std::uint32_t q)const{std::uint16_t p=(std::uint16_t)(d+q),base=forja65_read16_bank0(hw,p);return((std::uint32_t)db<<16)|base;}
inline std::uint32_t CpuState::addressDpIndirectY(SnesRuntime& hw,std::uint32_t q)const{std::uint16_t p=(std::uint16_t)(d+q),base=forja65_read16_bank0(hw,p);return((std::uint32_t)db<<16)|((base+y)&0xFFFFu);}
inline std::uint32_t CpuState::addressDpLong(SnesRuntime& hw,std::uint32_t q)const{std::uint16_t p=(std::uint16_t)(d+q);return(hw.read(p)|(hw.read((std::uint16_t)(p+1))<<8)|(hw.read((std::uint16_t)(p+2))<<16))&0xFFFFFFu;}
inline std::uint32_t CpuState::addressDpLongY(SnesRuntime& hw,std::uint32_t q)const{return(addressDpLong(hw,q)+y)&0xFFFFFFu;}
inline std::uint32_t CpuState::addressStackIndirectY(SnesRuntime& hw,std::uint32_t q)const{std::uint16_t p=(std::uint16_t)(s+q),base=forja65_read16_bank0(hw,p);return((std::uint32_t)db<<16)|((base+y)&0xFFFFu);}
inline void CpuState::incMem(SnesRuntime& hw,std::uint32_t addr,int w){std::uint32_t mask=w==8?0xFF:0xFFFF,v=(hw.readW(addr,w)+1)&mask;hw.write(addr,v,w);nz((std::uint16_t)v,w);}
inline void CpuState::decMem(SnesRuntime& hw,std::uint32_t addr,int w){std::uint32_t mask=w==8?0xFF:0xFFFF,v=(hw.readW(addr,w)-1)&mask;hw.write(addr,v,w);nz((std::uint16_t)v,w);}
inline void CpuState::aslMem(SnesRuntime& hw,std::uint32_t addr,int w){std::uint32_t mask=w==8?0xFF:0xFFFF,sign=w==8?0x80:0x8000,old=hw.readW(addr,w)&mask;c=(old&sign)!=0;std::uint32_t r=(old<<1)&mask;hw.write(addr,r,w);nz((std::uint16_t)r,w);}
inline void CpuState::lsrMem(SnesRuntime& hw,std::uint32_t addr,int w){std::uint32_t mask=w==8?0xFF:0xFFFF,old=hw.readW(addr,w)&mask;c=(old&1u)!=0;std::uint32_t r=(old>>1)&mask;hw.write(addr,r,w);nz((std::uint16_t)r,w);}
inline void CpuState::rolMem(SnesRuntime& hw,std::uint32_t addr,int w){std::uint32_t mask=w==8?0xFF:0xFFFF,sign=w==8?0x80:0x8000,old=hw.readW(addr,w)&mask,r=((old<<1)|(c?1u:0u))&mask;c=(old&sign)!=0;hw.write(addr,r,w);nz((std::uint16_t)r,w);}
inline void CpuState::rorMem(SnesRuntime& hw,std::uint32_t addr,int w){std::uint32_t mask=w==8?0xFF:0xFFFF,sign=w==8?0x80:0x8000,old=hw.readW(addr,w)&mask,r=((old>>1)|(c?sign:0u))&mask;c=(old&1u)!=0;hw.write(addr,r,w);nz((std::uint16_t)r,w);}
inline void CpuState::tsb(SnesRuntime& hw,std::uint32_t addr,int w){std::uint32_t mask=w==8?0xFF:0xFFFF,mem=hw.readW(addr,w)&mask,av=a&mask;z=(mem&av)==0;hw.write(addr,mem|av,w);}
inline void CpuState::trb(SnesRuntime& hw,std::uint32_t addr,int w){std::uint32_t mask=w==8?0xFF:0xFFFF,mem=hw.readW(addr,w)&mask,av=a&mask;z=(mem&av)==0;hw.write(addr,mem&(~av&mask),w);}
inline void CpuState::push8Value(SnesRuntime& hw,std::uint8_t b){std::uint32_t a=e?(0x100|(s&0xFF)):s;hw.write(a,b,8);s=e?(0x100|((s-1)&0xFF)):(std::uint16_t)(s-1);}
inline std::uint8_t CpuState::peekStack8(SnesRuntime& hw,unsigned depth)const{std::uint16_t sp=e?(std::uint16_t)(0x100|((s+depth)&0xFF)):(std::uint16_t)(s+depth);return(std::uint8_t)hw.read(sp);}
inline std::uint8_t CpuState::pop8Value(SnesRuntime& hw){s=e?(std::uint16_t)(0x100|((s+1)&0xFF)):(std::uint16_t)(s+1);return(std::uint8_t)hw.read(e?(0x100|(s&0xFF)):s);}
inline void CpuState::push16Value(SnesRuntime& hw,std::uint16_t v){push8Value(hw,(std::uint8_t)(v>>8));push8Value(hw,(std::uint8_t)v);}
inline std::uint16_t CpuState::peekStack16(SnesRuntime& hw)const{return(std::uint16_t)(peekStack8(hw,1)|(peekStack8(hw,2)<<8));}
inline std::uint16_t CpuState::pop16Value(SnesRuntime& hw){std::uint16_t lo=pop8Value(hw),hi=pop8Value(hw);return(std::uint16_t)(lo|(hi<<8));}
inline void CpuState::enterInterrupt(SnesRuntime& hw,std::uint32_t resumePc,bool software){resumePc&=0xFFFFFFu;if(!e)push8Value(hw,pb);push16Value(hw,(std::uint16_t)(resumePc&0xFFFFu));std::uint8_t p=packP();if(e){p|=0x20u;if(software)p|=0x10u;else p&=(std::uint8_t)~0x10u;}push8Value(hw,p);i=true;decimalMode=false;pb=0;}
inline std::uint32_t CpuState::returnInterrupt(SnesRuntime& hw){unpackP(pop8Value(hw));std::uint16_t pc=pop16Value(hw);std::uint8_t bank=e?0:pop8Value(hw);pb=e?0:bank;return (std::uint32_t(pb)<<16)|pc;}
inline void CpuState::blockMove(SnesRuntime& hw,std::uint8_t dst,std::uint8_t src,bool dec){db=dst;for(;;){std::uint32_t sa=((std::uint32_t)src<<16)|x,da=((std::uint32_t)dst<<16)|y;hw.write(da,hw.read(sa),8);if(x8){x=(std::uint16_t)((x&0xFF00u)|((x+(dec?-1:1))&0xFFu));y=(std::uint16_t)((y&0xFF00u)|((y+(dec?-1:1))&0xFFu));}else{x=(std::uint16_t)(x+(dec?-1:1));y=(std::uint16_t)(y+(dec?-1:1));}a=(std::uint16_t)(a-1);if(a==0xFFFFu)break;}}
inline void CpuState::push(const std::string& what,SnesRuntime& hw){auto p8=[&](std::uint8_t v){std::uint32_t a=e?(0x100|(s&0xFF)):s;hw.write(a,v,8);s=e?(0x100|((s-1)&0xFF)):(std::uint16_t)(s-1);};auto p16=[&](std::uint16_t v){p8((v>>8)&0xFF);p8(v&0xFF);};if(what=="PHA"){if(m8)p8(a&0xFF);else p16(a);}else if(what=="PHX"){if(x8)p8(x&0xFF);else p16(x);}else if(what=="PHY"){if(x8)p8(y&0xFF);else p16(y);}else if(what=="PHP")p8(packP());else if(what=="PHB")p8(db);else if(what=="PHK")p8(pb);else if(what=="PHD")p16(d);}
inline void CpuState::pop(const std::string& what,SnesRuntime& hw){auto g8=[&](){s=e?(0x100|((s+1)&0xFF)):(std::uint16_t)(s+1);std::uint32_t a=e?(0x100|(s&0xFF)):s;return(std::uint8_t)hw.read(a);};auto g16=[&](){std::uint16_t lo=g8(),hi=g8();return(std::uint16_t)(lo|(hi<<8));};if(what=="PLA"){if(m8)setA(g8(),8);else setA(g16(),16);}else if(what=="PLX"){if(x8)setX(g8(),8);else setX(g16(),16);}else if(what=="PLY"){if(x8)setY(g8(),8);else setY(g16(),16);}else if(what=="PLP")unpackP(g8());else if(what=="PLB"){db=g8();nz(db,8);}else if(what=="PLD"){d=g16();nz(d,16);}}
