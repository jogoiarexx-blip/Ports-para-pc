#include "generated.hpp"
void sub_00850F_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00850Fu: goto L_00850F;
    case 0x008511u: goto L_008511;
    case 0x008512u: goto L_008512;
    case 0x008513u: goto L_008513;
    case 0x008514u: goto L_008514;
    case 0x008515u: goto L_008515;
    case 0x008516u: goto L_008516;
    case 0x008519u: goto L_008519;
    case 0x00851Bu: goto L_00851B;
    case 0x00851Du: goto L_00851D;
    case 0x00851Fu: goto L_00851F;
    case 0x008520u: goto L_008520;
    case 0x008521u: goto L_008521;
    case 0x008524u: goto L_008524;
    case 0x008527u: goto L_008527;
    case 0x008529u: goto L_008529;
    case 0x00852Au: goto L_00852A;
    case 0x00852Bu: goto L_00852B;
    case 0x00852Cu: goto L_00852C;
    case 0x00852Du: goto L_00852D;
    case 0x00852Eu: goto L_00852E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00850F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x850Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x850Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x850Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00850F REP
    cpu.rep(0x20u);
    goto L_008511;
L_008511:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8511u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8511u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8511u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008511 PHA
    cpu.push("PHA", hw);
    goto L_008512;
L_008512:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8512u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8512u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8512u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008512 PHX
    cpu.push("PHX", hw);
    goto L_008513;
L_008513:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8513u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8513u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8513u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008513 PHY
    cpu.push("PHY", hw);
    goto L_008514;
L_008514:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8514u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8514u,cpu,0x0Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8514u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008514 PHD
    cpu.push("PHD", hw);
    goto L_008515;
L_008515:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8515u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8515u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8515u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $008515 PHB
    cpu.push("PHB", hw);
    goto L_008516;
L_008516:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8516u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8516u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8516u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008516 LDA
    cpu.setA(0x0u, 16);
    goto L_008519;
L_008519:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8519u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8519u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8519u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008519 SEP
    cpu.sep(0x20u);
    goto L_00851B;
L_00851B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x851Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x851Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x851Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00851B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00851D;
L_00851D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x851Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x851Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x851Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00851D AND
    cpu.logicAnd(0x7Fu);
    goto L_00851F;
L_00851F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x851Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x851Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x851Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00851F ASL
    cpu.aslA();
    goto L_008520;
L_008520:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8520u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8520u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8520u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008520 TAX
    cpu.transfer("TAX");
    goto L_008521;
L_008521:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8521u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8521u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8521u, 4u, 3u, cpu.address("abs", 0x4211u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008521 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x4211u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008524;
L_008524:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8524u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8524u,cpu,0xFCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8524u, 8u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x852Fu + cpu.x) & 0xFFFFu)), 2u, 2u);
    // $008524 JSR (852F,X) dinamico stack real
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x852Fu+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); cpu.push16Value(hw,0x8526u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8527u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, dst, 0x008524u); }
    goto L_008527;
L_008527:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8527u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8527u,0x008527u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8527u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8527u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008527 REP
    cpu.rep(0x20u);
    goto L_008529;
L_008529:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8529u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8529u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8529u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $008529 PLB
    cpu.pop("PLB", hw);
    goto L_00852A;
L_00852A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x852Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x852Au,cpu,0x2Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x852Au, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00852A PLD
    cpu.pop("PLD", hw);
    goto L_00852B;
L_00852B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x852Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x852Bu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x852Bu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00852B PLY
    cpu.pop("PLY", hw);
    goto L_00852C;
L_00852C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x852Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x852Cu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x852Cu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00852C PLX
    cpu.pop("PLX", hw);
    goto L_00852D;
L_00852D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x852Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x852Du,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x852Du, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00852D PLA
    cpu.pop("PLA", hw);
    goto L_00852E;
L_00852E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x852Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x852Eu,cpu,0x40u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x852Eu, 7u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $00852E RTI stack real
    {auto dst=cpu.returnInterrupt(hw);hw.requestDispatch(dst,0x00852Eu);return;}
}

void sub_60286C_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x602867u: goto L_602867;
    case 0x602869u: goto L_602869;
    case 0x60286Bu: goto L_60286B;
    case 0x60286Cu: goto L_60286C;
    case 0x60286Du: goto L_60286D;
    case 0x60286Fu: goto L_60286F;
    case 0x602870u: goto L_602870;
    case 0x602871u: goto L_602871;
    case 0x602873u: goto L_602873;
    case 0x602875u: goto L_602875;
    case 0x602877u: goto L_602877;
    case 0x602878u: goto L_602878;
    case 0x60287Bu: goto L_60287B;
    case 0x60287Du: goto L_60287D;
    case 0x60287Fu: goto L_60287F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_602867:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x2867u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x2867u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x2867u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $602867 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_602869;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x2867u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x2867u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $602867 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_602869;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x2867u,0x602867u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_602869:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x2869u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x2869u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x2869u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $602869 STA
    hw.write(cpu.addressDpLongY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_60286B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x2869u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x2869u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $602869 STA
    hw.write(cpu.addressDpLongY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_60286B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x2869u,0x602869u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_60286B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x286Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x286Bu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x286Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60286B DEY
    cpu.decReg('Y');
    goto L_60286C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x286Bu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x286Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60286B DEY
    cpu.decReg('Y');
    goto L_60286C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x286Bu,0x60286Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_60286C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x286Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x286Cu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x286Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60286C DEY
    cpu.decReg('Y');
    goto L_60286D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x286Cu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x286Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60286C DEY
    cpu.decReg('Y');
    goto L_60286D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x286Cu,0x60286Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_60286D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x286Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x286Du,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x286Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60286D BPL -> $602867
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_602867; }
    goto L_60286F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x286Du,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x286Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60286D BPL -> $602867
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_602867; }
    goto L_60286F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x286Du,0x60286Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_60286F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x286Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x286Fu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x286Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60286F DEX
    cpu.decReg('X');
    goto L_602870;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x286Fu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x286Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60286F DEX
    cpu.decReg('X');
    goto L_602870;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x286Fu,0x60286Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_602870:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x2870u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x2870u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x2870u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $602870 TXA
    cpu.transfer("TXA");
    goto L_602871;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x2870u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x2870u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $602870 TXA
    cpu.transfer("TXA");
    goto L_602871;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x2870u,0x602870u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_602871:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x2871u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x2871u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x2871u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $602871 BEQ -> $60287F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_60287F; }
    goto L_602873;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x2871u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x2871u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $602871 BEQ -> $60287F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_60287F; }
    goto L_602873;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x2871u,0x602871u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_602873:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x2873u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x2873u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x2873u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $602873 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_602875;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x2873u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x2873u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $602873 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_602875;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x2873u,0x602873u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_602875:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x2875u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x2875u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x2875u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $602875 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_602877;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x2875u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x2875u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $602875 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_602877;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x2875u,0x602875u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_602877:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x2877u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x2877u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x2877u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $602877 CLC
    cpu.setFlag('C', false);
    goto L_602878;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x2877u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x2877u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $602877 CLC
    cpu.setFlag('C', false);
    goto L_602878;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x2877u,0x602877u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_602878:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x2878u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x2878u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x2878u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $602878 ADC
    cpu.adc(0x40u);
    goto L_60287B;
L_60287B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x287Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x287Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x287Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60287B STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_60287D;
L_60287D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x287Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x287Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x287Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $60287D BRA -> $602867
    goto L_602867;
L_60287F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x287Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x287Fu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x287Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $60287F RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x60287Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x60287Fu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x287Fu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x287Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $60287F RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x60287Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x60287Fu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x287Fu,0x60287Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_808421_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808421u: goto L_808421;
    case 0x808422u: goto L_808422;
    case 0x808424u: goto L_808424;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808421:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8421u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8421u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8421u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808421 PLP
    cpu.pop("PLP", hw);
    goto L_808422;
L_808422:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8422u))return;
  // 4 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8422u,cpu,0x91u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8422u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x82u) & 0xFFFFu), 2u, 0u);
    // $808422 STA
    hw.write(cpu.addressDpIndirectY(hw, 0x82u), cpu.a, cpu.m8?8:16);
    goto L_808424;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8422u,cpu,0x91u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8422u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x82u) & 0xFFFFu), 2u, 0u);
    // $808422 STA
    hw.write(cpu.addressDpIndirectY(hw, 0x82u), cpu.a, cpu.m8?8:16);
    goto L_808424;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8422u,cpu,0x91u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8422u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x82u) & 0xFFFFu), 2u, 0u);
    // $808422 STA
    hw.write(cpu.addressDpIndirectY(hw, 0x82u), cpu.a, cpu.m8?8:16);
    goto L_808424;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8422u,cpu,0x91u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8422u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x82u) & 0xFFFFu), 2u, 0u);
    // $808422 STA
    hw.write(cpu.addressDpIndirectY(hw, 0x82u), cpu.a, cpu.m8?8:16);
    goto L_808424;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8422u,0x808422u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_808424:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8424u))return;
  // 4 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8424u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8424u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808424 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808424u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808424u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8424u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8424u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808424 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808424u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808424u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8424u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8424u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808424 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808424u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808424u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8424u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8424u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808424 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808424u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808424u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8424u,0x808424u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80842D_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80842Du: goto L_80842D;
    case 0x80842Fu: goto L_80842F;
    case 0x808433u: goto L_808433;
    case 0x808436u: goto L_808436;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80842D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x842Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x842Du,cpu,0xB2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x842Du, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x8Fu) & 0xFFFFu), 2u, 0u);
    // $80842D LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirect(hw, 0x8Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80842F;
L_80842F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x842Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x842Fu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x842Fu, 6u, 4u, ((0x226B6Bu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80842F STA
    hw.write(((0x226B6Bu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_808433;
L_808433:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8433u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8433u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8433u, 5u + 1u, 3u, cpu.address("absy", 0x9F80u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808433 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x9F80u), cpu.m8?8:16));
    goto L_808436;
L_808436:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8436u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8436u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8436u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808436 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808436u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808436u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8084B3_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8084B3u: goto L_8084B3;
    case 0x8084B7u: goto L_8084B7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8084B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B3u, 8u, 4u, 0x80AB4Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8084B3 JSL -> $80AB4C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x84B6u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x84B7u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AB4Cu, 0x8084B3u); }
    goto L_8084B7;
L_8084B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84B7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84B7u,0x8084B7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B7u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8084B7 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8084B7u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8084B7u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8084B3_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8084B3u: goto L_8084B3;
    case 0x8084B7u: goto L_8084B7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8084B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B3u, 8u, 4u, 0x80AB4Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8084B3 JSL -> $80AB4C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x84B6u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x84B7u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AB4Cu, 0x8084B3u); }
    goto L_8084B7;
L_8084B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84B7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84B7u,0x8084B7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B7u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8084B7 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8084B7u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8084B7u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8084B8_E0M1X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8084B8u: goto L_8084B8;
    case 0x8084BCu: goto L_8084BC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8084B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B8u, 8u, 4u, 0x84BEA5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8084B8 JSL -> $84BEA5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x84BBu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x84BCu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84BEA5u, 0x8084B8u); }
    goto L_8084BC;
L_8084BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84BCu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84BCu,0x8084BCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BCu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8084BC RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8084BCu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8084BCu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8084B8_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8084B8u: goto L_8084B8;
    case 0x8084BCu: goto L_8084BC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8084B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B8u, 8u, 4u, 0x84BEA5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8084B8 JSL -> $84BEA5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x84BBu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x84BCu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84BEA5u, 0x8084B8u); }
    goto L_8084BC;
L_8084BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84BCu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84BCu,0x8084BCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84BCu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84BCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8084BC RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8084BCu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8084BCu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80864B_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80864Bu: goto L_80864B;
    case 0x80864Cu: goto L_80864C;
    case 0x80864Eu: goto L_80864E;
    case 0x808651u: goto L_808651;
    case 0x808654u: goto L_808654;
    case 0x808657u: goto L_808657;
    case 0x80865Au: goto L_80865A;
    case 0x80865Du: goto L_80865D;
    case 0x808660u: goto L_808660;
    case 0x808663u: goto L_808663;
    case 0x808665u: goto L_808665;
    case 0x808668u: goto L_808668;
    case 0x80866Bu: goto L_80866B;
    case 0x80866Eu: goto L_80866E;
    case 0x808670u: goto L_808670;
    case 0x808673u: goto L_808673;
    case 0x808676u: goto L_808676;
    case 0x808678u: goto L_808678;
    case 0x80867Au: goto L_80867A;
    case 0x80867Du: goto L_80867D;
    case 0x808680u: goto L_808680;
    case 0x808683u: goto L_808683;
    case 0x808686u: goto L_808686;
    case 0x808689u: goto L_808689;
    case 0x80868Bu: goto L_80868B;
    case 0x80868Eu: goto L_80868E;
    case 0x808691u: goto L_808691;
    case 0x808694u: goto L_808694;
    case 0x808696u: goto L_808696;
    case 0x808699u: goto L_808699;
    case 0x80869Cu: goto L_80869C;
    case 0x80869Fu: goto L_80869F;
    case 0x8086A1u: goto L_8086A1;
    case 0x8086A4u: goto L_8086A4;
    case 0x8086A7u: goto L_8086A7;
    case 0x8086A9u: goto L_8086A9;
    case 0x8086ACu: goto L_8086AC;
    case 0x8086AFu: goto L_8086AF;
    case 0x8086B2u: goto L_8086B2;
    case 0x8086B5u: goto L_8086B5;
    case 0x8086B8u: goto L_8086B8;
    case 0x8086BBu: goto L_8086BB;
    case 0x8086BEu: goto L_8086BE;
    case 0x8086C1u: goto L_8086C1;
    case 0x8086C3u: goto L_8086C3;
    case 0x8086C6u: goto L_8086C6;
    case 0x8086C9u: goto L_8086C9;
    case 0x8086CBu: goto L_8086CB;
    case 0x8086CEu: goto L_8086CE;
    case 0x8086CFu: goto L_8086CF;
    case 0x8086D0u: goto L_8086D0;
    case 0x8086D1u: goto L_8086D1;
    case 0x8086D2u: goto L_8086D2;
    case 0x8086D3u: goto L_8086D3;
    case 0x8086D4u: goto L_8086D4;
    case 0x8086D5u: goto L_8086D5;
    case 0x8086D6u: goto L_8086D6;
    case 0x8086D9u: goto L_8086D9;
    case 0x8086DBu: goto L_8086DB;
    case 0x8086DDu: goto L_8086DD;
    case 0x8086E0u: goto L_8086E0;
    case 0x8086E4u: goto L_8086E4;
    case 0x8086E6u: goto L_8086E6;
    case 0x8086E8u: goto L_8086E8;
    case 0x8086EBu: goto L_8086EB;
    case 0x8086EDu: goto L_8086ED;
    case 0x8086F0u: goto L_8086F0;
    case 0x8086F2u: goto L_8086F2;
    case 0x8086F3u: goto L_8086F3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80864B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x864Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x864Bu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x864Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80864B PHP
    cpu.push("PHP", hw);
    goto L_80864C;
L_80864C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x864Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x864Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x864Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80864C SEP
    cpu.sep(0x20u);
    goto L_80864E;
L_80864E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x864Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x864Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x864Eu, 4u, 3u, cpu.address("abs", 0x420Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80864E STZ
    hw.write(cpu.address("abs", 0x420Cu), 0, cpu.m8?8:16);
    goto L_808651;
L_808651:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8651u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8651u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8651u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808651 LDX
    cpu.setX(0x0u, 16);
    goto L_808654;
L_808654:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8654u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8654u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8654u, 5u, 3u, cpu.address("abs", 0x2102u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808654 STX
    hw.write(cpu.address("abs", 0x2102u), cpu.x, cpu.x8?8:16);
    goto L_808657;
L_808657:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8657u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8657u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8657u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808657 LDX
    cpu.setX(0x400u, 16);
    goto L_80865A;
L_80865A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x865Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x865Au,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x865Au, 5u, 3u, cpu.address("abs", 0x4370u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80865A STX
    hw.write(cpu.address("abs", 0x4370u), cpu.x, cpu.x8?8:16);
    goto L_80865D;
L_80865D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x865Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x865Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x865Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80865D LDX
    cpu.setX(0x1400u, 16);
    goto L_808660;
L_808660:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8660u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8660u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8660u, 5u, 3u, cpu.address("abs", 0x4372u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808660 STX
    hw.write(cpu.address("abs", 0x4372u), cpu.x, cpu.x8?8:16);
    goto L_808663;
L_808663:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8663u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8663u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8663u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808663 LDA
    cpu.setA(0x80u, 8);
    goto L_808665;
L_808665:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8665u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8665u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8665u, 4u, 3u, cpu.address("abs", 0x4374u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808665 STA
    hw.write(cpu.address("abs", 0x4374u), cpu.a, cpu.m8?8:16);
    goto L_808668;
L_808668:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8668u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8668u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8668u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808668 LDX
    cpu.setX(0x220u, 16);
    goto L_80866B;
L_80866B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x866Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x866Bu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x866Bu, 5u, 3u, cpu.address("abs", 0x4375u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80866B STX
    hw.write(cpu.address("abs", 0x4375u), cpu.x, cpu.x8?8:16);
    goto L_80866E;
L_80866E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x866Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x866Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x866Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80866E LDA
    cpu.setA(0x80u, 8);
    goto L_808670;
L_808670:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8670u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8670u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8670u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808670 STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_808673;
L_808673:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8673u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8673u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8673u, 4u, 3u, cpu.address("abs", 0x0122u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808673 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x122u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808676;
L_808676:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8676u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8676u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8676u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808676 BMI -> $80869C
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80869C; }
    goto L_808678;
L_808678:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8678u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8678u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8678u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808678 BEQ -> $80869C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80869C; }
    goto L_80867A;
L_80867A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x867Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x867Au,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x867Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80867A LDY
    cpu.setY(0x2200u, 16);
    goto L_80867D;
L_80867D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x867Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x867Du,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x867Du, 5u, 3u, cpu.address("abs", 0x4370u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80867D STY
    hw.write(cpu.address("abs", 0x4370u), cpu.y, cpu.x8?8:16);
    goto L_808680;
L_808680:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8680u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8680u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8680u, 4u, 3u, cpu.address("abs", 0x2121u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808680 STZ
    hw.write(cpu.address("abs", 0x2121u), 0, cpu.m8?8:16);
    goto L_808683;
L_808683:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8683u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8683u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8683u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808683 LDY
    cpu.setY(0x1900u, 16);
    goto L_808686;
L_808686:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8686u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8686u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8686u, 5u, 3u, cpu.address("abs", 0x4372u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808686 STY
    hw.write(cpu.address("abs", 0x4372u), cpu.y, cpu.x8?8:16);
    goto L_808689;
L_808689:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8689u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8689u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8689u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808689 LDA
    cpu.setA(0x80u, 8);
    goto L_80868B;
L_80868B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x868Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x868Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x868Bu, 4u, 3u, cpu.address("abs", 0x4374u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80868B STA
    hw.write(cpu.address("abs", 0x4374u), cpu.a, cpu.m8?8:16);
    goto L_80868E;
L_80868E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x868Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x868Eu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x868Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80868E LDY
    cpu.setY(0x200u, 16);
    goto L_808691;
L_808691:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8691u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8691u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8691u, 5u, 3u, cpu.address("abs", 0x4375u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808691 STY
    hw.write(cpu.address("abs", 0x4375u), cpu.y, cpu.x8?8:16);
    goto L_808694;
L_808694:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8694u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8694u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8694u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808694 LDA
    cpu.setA(0x80u, 8);
    goto L_808696;
L_808696:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8696u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8696u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8696u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808696 STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_808699;
L_808699:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8699u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8699u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8699u, 4u, 3u, cpu.address("abs", 0x0122u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808699 STZ
    hw.write(cpu.address("abs", 0x122u), 0, cpu.m8?8:16);
    goto L_80869C;
L_80869C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x869Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x869Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x869Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80869C LDX
    cpu.setX(0x0u, 16);
    goto L_80869F;
L_80869F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x869Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x869Fu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x869Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80869F BRA -> $8086D6
    goto L_8086D6;
L_8086A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A1u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A1u, 4u + 1u, 3u, cpu.address("absx", 0x1800u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086A1 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1800u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8086A4;
L_8086A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A4u, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086A4 STA
    hw.write(cpu.address("abs", 0x2115u), cpu.a, cpu.m8?8:16);
    goto L_8086A7;
L_8086A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A7u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086A7 REP
    cpu.rep(0x20u);
    goto L_8086A9;
L_8086A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A9u, 5u + 1u, 3u, cpu.address("absx", 0x1801u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086A9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1801u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8086AC;
L_8086AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86ACu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86ACu, 5u, 3u, cpu.address("abs", 0x2116u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086AC STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_8086AF;
L_8086AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86AFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86AFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086AF LDA
    cpu.setA(0x1801u, 16);
    goto L_8086B2;
L_8086B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B2u, 5u, 3u, cpu.address("abs", 0x4370u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086B2 STA
    hw.write(cpu.address("abs", 0x4370u), cpu.a, cpu.m8?8:16);
    goto L_8086B5;
L_8086B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B5u, 5u + 1u, 3u, cpu.address("absx", 0x1803u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086B5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1803u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8086B8;
L_8086B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B8u, 5u, 3u, cpu.address("abs", 0x4372u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086B8 STA
    hw.write(cpu.address("abs", 0x4372u), cpu.a, cpu.m8?8:16);
    goto L_8086BB;
L_8086BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BBu, 5u + 1u, 3u, cpu.address("absx", 0x1805u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086BB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1805u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8086BE;
L_8086BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BEu, 5u, 3u, cpu.address("abs", 0x4374u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086BE STA
    hw.write(cpu.address("abs", 0x4374u), cpu.a, cpu.m8?8:16);
    goto L_8086C1;
L_8086C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C1u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086C1 SEP
    cpu.sep(0x20u);
    goto L_8086C3;
L_8086C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C3u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C3u, 4u + 1u, 3u, cpu.address("absx", 0x1807u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086C3 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1807u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8086C6;
L_8086C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C6u, 4u, 3u, cpu.address("abs", 0x4376u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086C6 STA
    hw.write(cpu.address("abs", 0x4376u), cpu.a, cpu.m8?8:16);
    goto L_8086C9;
L_8086C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086C9 LDA
    cpu.setA(0x80u, 8);
    goto L_8086CB;
L_8086CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86CBu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86CBu, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086CB STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_8086CE;
L_8086CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86CEu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86CEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086CE INX
    cpu.inc('X');
    goto L_8086CF;
L_8086CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86CFu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86CFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086CF INX
    cpu.inc('X');
    goto L_8086D0;
L_8086D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D0u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086D0 INX
    cpu.inc('X');
    goto L_8086D1;
L_8086D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D1u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086D1 INX
    cpu.inc('X');
    goto L_8086D2;
L_8086D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D2u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086D2 INX
    cpu.inc('X');
    goto L_8086D3;
L_8086D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D3u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086D3 INX
    cpu.inc('X');
    goto L_8086D4;
L_8086D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D4u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086D4 INX
    cpu.inc('X');
    goto L_8086D5;
L_8086D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D5u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086D5 INX
    cpu.inc('X');
    goto L_8086D6;
L_8086D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D6u,cpu,0xECu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D6u, 5u, 3u, cpu.address("abs", 0x0124u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086D6 CPX
    cpu.compareX(hw.readW(cpu.address("abs", 0x124u), cpu.x8?8:16));
    goto L_8086D9;
L_8086D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D9u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086D9 BCC -> $8086A1
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8086A1; }
    goto L_8086DB;
L_8086DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86DBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86DBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xB4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086DB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xB4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8086DD;
L_8086DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86DDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86DDu, 4u, 3u, cpu.address("abs", 0x420Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086DD STA
    hw.write(cpu.address("abs", 0x420Cu), cpu.a, cpu.m8?8:16);
    goto L_8086E0;
L_8086E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E0u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E0u, 8u, 4u, 0x808B92u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8086E0 JSL -> $808B92 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x86E3u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x86E4u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808B92u, 0x8086E0u); }
    goto L_8086E4;
L_8086E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86E4u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86E4u,0x8086E4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E4u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086E4 REP
    cpu.rep(0x20u);
    goto L_8086E6;
L_8086E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086E6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8086E8;
L_8086E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E8u, 5u, 3u, cpu.address("abs", 0x212Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086E8 STA
    hw.write(cpu.address("abs", 0x212Cu), cpu.a, cpu.m8?8:16);
    goto L_8086EB;
L_8086EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86EBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86EBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086EB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8086ED;
L_8086ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86EDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86EDu, 5u, 3u, cpu.address("abs", 0x212Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086ED STA
    hw.write(cpu.address("abs", 0x212Eu), cpu.a, cpu.m8?8:16);
    goto L_8086F0;
L_8086F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F0u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086F0 SEP
    cpu.sep(0x20u);
    goto L_8086F2;
L_8086F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F2u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F2u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8086F2 PLP
    cpu.pop("PLP", hw);
    goto L_8086F3;
L_8086F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F3u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86F3u,0x8086F3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F3u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8086F3 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8086F3u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8086F3u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_809B54_E0M1X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809B54u: goto L_809B54;
    case 0x809B56u: goto L_809B56;
    case 0x809B57u: goto L_809B57;
    case 0x809B58u: goto L_809B58;
    case 0x809B5Au: goto L_809B5A;
    case 0x809B5Bu: goto L_809B5B;
    case 0x809B5Eu: goto L_809B5E;
    case 0x809B5Fu: goto L_809B5F;
    case 0x809B62u: goto L_809B62;
    case 0x809B63u: goto L_809B63;
    case 0x809B66u: goto L_809B66;
    case 0x809B67u: goto L_809B67;
    case 0x809B6Au: goto L_809B6A;
    case 0x809B6Cu: goto L_809B6C;
    case 0x809B6Fu: goto L_809B6F;
    case 0x809B72u: goto L_809B72;
    case 0x809B75u: goto L_809B75;
    case 0x809B77u: goto L_809B77;
    case 0x809B7Au: goto L_809B7A;
    case 0x809B7Cu: goto L_809B7C;
    case 0x809B7Du: goto L_809B7D;
    case 0x809B7Eu: goto L_809B7E;
    case 0x809B80u: goto L_809B80;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809B54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B54u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B54u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B54 SEP
    cpu.sep(0x20u);
    goto L_809B56;
L_809B56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B56u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B56u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809B56 PLY
    cpu.pop("PLY", hw);
    goto L_809B57;
L_809B57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B57u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B57u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809B57 PLA
    cpu.pop("PLA", hw);
    goto L_809B58;
L_809B58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B58u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B58u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B58 STA
    hw.write(cpu.address("dp", 0x5Du), cpu.a, cpu.m8?8:16);
    goto L_809B5A;
L_809B5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Au,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Au, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809B5A PLX
    cpu.pop("PLX", hw);
    goto L_809B5B;
L_809B5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Bu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Bu, 5u, 3u, cpu.address("abs", 0x4375u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B5B STX
    hw.write(cpu.address("abs", 0x4375u), cpu.x, cpu.x8?8:16);
    goto L_809B5E;
L_809B5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Eu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Eu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809B5E PLX
    cpu.pop("PLX", hw);
    goto L_809B5F;
L_809B5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Fu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Fu, 5u, 3u, cpu.address("abs", 0x2116u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B5F STX
    hw.write(cpu.address("abs", 0x2116u), cpu.x, cpu.x8?8:16);
    goto L_809B62;
L_809B62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B62u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B62u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809B62 PLX
    cpu.pop("PLX", hw);
    goto L_809B63;
L_809B63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B63u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B63u, 5u, 3u, cpu.address("abs", 0x4372u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B63 STX
    hw.write(cpu.address("abs", 0x4372u), cpu.x, cpu.x8?8:16);
    goto L_809B66;
L_809B66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B66u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B66u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809B66 PLA
    cpu.pop("PLA", hw);
    goto L_809B67;
L_809B67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B67u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B67u, 4u, 3u, cpu.address("abs", 0x4374u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B67 STA
    hw.write(cpu.address("abs", 0x4374u), cpu.a, cpu.m8?8:16);
    goto L_809B6A;
L_809B6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B6Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B6Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B6A LDA
    cpu.setA(0x80u, 8);
    goto L_809B6C;
L_809B6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B6Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B6Cu, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B6C STA
    hw.write(cpu.address("abs", 0x2115u), cpu.a, cpu.m8?8:16);
    goto L_809B6F;
L_809B6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B6Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B6Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B6F LDX
    cpu.setX(0x1801u, 16);
    goto L_809B72;
L_809B72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B72u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B72u, 5u, 3u, cpu.address("abs", 0x4370u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B72 STX
    hw.write(cpu.address("abs", 0x4370u), cpu.x, cpu.x8?8:16);
    goto L_809B75;
L_809B75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B75u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B75u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B75 LDA
    cpu.setA(0x80u, 8);
    goto L_809B77;
L_809B77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B77u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B77u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B77 STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_809B7A;
L_809B7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B7Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B7Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B7A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809B7C;
L_809B7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B7Cu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B7Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809B7C PHA
    cpu.push("PHA", hw);
    goto L_809B7D;
L_809B7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B7Du,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B7Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809B7D PHY
    cpu.push("PHY", hw);
    goto L_809B7E;
L_809B7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B7Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B7Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B7E REP
    cpu.rep(0x20u);
    goto L_809B80;
L_809B80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B80u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B80u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809B80 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x809B80u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x809B80u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_809B54_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809B54u: goto L_809B54;
    case 0x809B56u: goto L_809B56;
    case 0x809B57u: goto L_809B57;
    case 0x809B58u: goto L_809B58;
    case 0x809B5Au: goto L_809B5A;
    case 0x809B5Bu: goto L_809B5B;
    case 0x809B5Eu: goto L_809B5E;
    case 0x809B5Fu: goto L_809B5F;
    case 0x809B62u: goto L_809B62;
    case 0x809B63u: goto L_809B63;
    case 0x809B66u: goto L_809B66;
    case 0x809B67u: goto L_809B67;
    case 0x809B6Au: goto L_809B6A;
    case 0x809B6Cu: goto L_809B6C;
    case 0x809B6Fu: goto L_809B6F;
    case 0x809B72u: goto L_809B72;
    case 0x809B75u: goto L_809B75;
    case 0x809B77u: goto L_809B77;
    case 0x809B7Au: goto L_809B7A;
    case 0x809B7Cu: goto L_809B7C;
    case 0x809B7Du: goto L_809B7D;
    case 0x809B7Eu: goto L_809B7E;
    case 0x809B80u: goto L_809B80;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809B54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B54u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B54u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B54 SEP
    cpu.sep(0x20u);
    goto L_809B56;
L_809B56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B56u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B56u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809B56 PLY
    cpu.pop("PLY", hw);
    goto L_809B57;
L_809B57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B57u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B57u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809B57 PLA
    cpu.pop("PLA", hw);
    goto L_809B58;
L_809B58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B58u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B58u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B58 STA
    hw.write(cpu.address("dp", 0x5Du), cpu.a, cpu.m8?8:16);
    goto L_809B5A;
L_809B5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Au,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Au, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809B5A PLX
    cpu.pop("PLX", hw);
    goto L_809B5B;
L_809B5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Bu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Bu, 5u, 3u, cpu.address("abs", 0x4375u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B5B STX
    hw.write(cpu.address("abs", 0x4375u), cpu.x, cpu.x8?8:16);
    goto L_809B5E;
L_809B5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Eu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Eu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809B5E PLX
    cpu.pop("PLX", hw);
    goto L_809B5F;
L_809B5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Fu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Fu, 5u, 3u, cpu.address("abs", 0x2116u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B5F STX
    hw.write(cpu.address("abs", 0x2116u), cpu.x, cpu.x8?8:16);
    goto L_809B62;
L_809B62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B62u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B62u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809B62 PLX
    cpu.pop("PLX", hw);
    goto L_809B63;
L_809B63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B63u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B63u, 5u, 3u, cpu.address("abs", 0x4372u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B63 STX
    hw.write(cpu.address("abs", 0x4372u), cpu.x, cpu.x8?8:16);
    goto L_809B66;
L_809B66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B66u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B66u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809B66 PLA
    cpu.pop("PLA", hw);
    goto L_809B67;
L_809B67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B67u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B67u, 4u, 3u, cpu.address("abs", 0x4374u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B67 STA
    hw.write(cpu.address("abs", 0x4374u), cpu.a, cpu.m8?8:16);
    goto L_809B6A;
L_809B6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B6Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B6Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B6A LDA
    cpu.setA(0x80u, 8);
    goto L_809B6C;
L_809B6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B6Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B6Cu, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B6C STA
    hw.write(cpu.address("abs", 0x2115u), cpu.a, cpu.m8?8:16);
    goto L_809B6F;
L_809B6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B6Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B6Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B6F LDX
    cpu.setX(0x1801u, 16);
    goto L_809B72;
L_809B72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B72u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B72u, 5u, 3u, cpu.address("abs", 0x4370u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B72 STX
    hw.write(cpu.address("abs", 0x4370u), cpu.x, cpu.x8?8:16);
    goto L_809B75;
L_809B75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B75u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B75u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B75 LDA
    cpu.setA(0x80u, 8);
    goto L_809B77;
L_809B77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B77u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B77u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B77 STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_809B7A;
L_809B7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B7Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B7Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B7A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809B7C;
L_809B7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B7Cu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B7Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809B7C PHA
    cpu.push("PHA", hw);
    goto L_809B7D;
L_809B7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B7Du,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B7Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809B7D PHY
    cpu.push("PHY", hw);
    goto L_809B7E;
L_809B7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B7Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B7Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809B7E REP
    cpu.rep(0x20u);
    goto L_809B80;
L_809B80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B80u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B80u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809B80 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x809B80u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x809B80u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80A554_E0M1X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80A554u: goto L_80A554;
    case 0x80A555u: goto L_80A555;
    case 0x80A557u: goto L_80A557;
    case 0x80A55Bu: goto L_80A55B;
    case 0x80A55Eu: goto L_80A55E;
    case 0x80A561u: goto L_80A561;
    case 0x80A562u: goto L_80A562;
    case 0x80A564u: goto L_80A564;
    case 0x80A567u: goto L_80A567;
    case 0x80A569u: goto L_80A569;
    case 0x80A56Cu: goto L_80A56C;
    case 0x80A56Fu: goto L_80A56F;
    case 0x80A571u: goto L_80A571;
    case 0x80A573u: goto L_80A573;
    case 0x80A576u: goto L_80A576;
    case 0x80A579u: goto L_80A579;
    case 0x80A57Cu: goto L_80A57C;
    case 0x80A57Eu: goto L_80A57E;
    case 0x80A581u: goto L_80A581;
    case 0x80A584u: goto L_80A584;
    case 0x80A586u: goto L_80A586;
    case 0x80A588u: goto L_80A588;
    case 0x80A58Bu: goto L_80A58B;
    case 0x80A58Cu: goto L_80A58C;
    case 0x80A590u: goto L_80A590;
    case 0x80A593u: goto L_80A593;
    case 0x80A594u: goto L_80A594;
    case 0x80A597u: goto L_80A597;
    case 0x80A59Au: goto L_80A59A;
    case 0x80A59Cu: goto L_80A59C;
    case 0x80A59Du: goto L_80A59D;
    case 0x80A59Eu: goto L_80A59E;
    case 0x80A5A0u: goto L_80A5A0;
    case 0x80A5A2u: goto L_80A5A2;
    case 0x80A5A5u: goto L_80A5A5;
    case 0x80A5A8u: goto L_80A5A8;
    case 0x80A5ABu: goto L_80A5AB;
    case 0x80A5AEu: goto L_80A5AE;
    case 0x80A5B0u: goto L_80A5B0;
    case 0x80A5B1u: goto L_80A5B1;
    case 0x80A5B2u: goto L_80A5B2;
    case 0x80A5B4u: goto L_80A5B4;
    case 0x80A5B5u: goto L_80A5B5;
    case 0x80A5B8u: goto L_80A5B8;
    case 0x80A5BBu: goto L_80A5BB;
    case 0x80A5BDu: goto L_80A5BD;
    case 0x80A5C0u: goto L_80A5C0;
    case 0x80A5C1u: goto L_80A5C1;
    case 0x80A5C2u: goto L_80A5C2;
    case 0x80A5C5u: goto L_80A5C5;
    case 0x80A5C8u: goto L_80A5C8;
    case 0x80A5CAu: goto L_80A5CA;
    case 0x80A5CBu: goto L_80A5CB;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80A554:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA554u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA554u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA554u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A554 PHP
    cpu.push("PHP", hw);
    goto L_80A555;
L_80A555:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA555u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA555u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA555u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A555 SEP
    cpu.sep(0x20u);
    goto L_80A557;
L_80A557:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA557u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA557u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA557u, 8u, 4u, 0x80A5D1u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A557 JSL -> $80A5D1 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA55Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA55Bu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A5D1u, 0x80A557u); }
    goto L_80A55B;
L_80A55B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA55Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA55Bu,0x80A55Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A55B LDX
    cpu.setX(0x8u, 16);
    goto L_80A55E;
L_80A55E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA55Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Eu, 6u, 3u, cpu.address("abs", 0xA5E0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A55E JSR -> $80A5E0 stack real
    { cpu.push16Value(hw,0xA560u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA561u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA5E0u), 0x80A55Eu); }
    goto L_80A561;
L_80A561:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA561u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA561u,0x80A561u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA561u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA561u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A561 DEX
    cpu.decReg('X');
    goto L_80A562;
L_80A562:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA562u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA562u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA562u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A562 BNE -> $80A55E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80A55E; }
    goto L_80A564;
L_80A564:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA564u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA564u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA564u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A564 LDX
    cpu.setX(0xBBAAu, 16);
    goto L_80A567;
L_80A567:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA567u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA567u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA567u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A567 LDA
    cpu.setA(0xFFu, 8);
    goto L_80A569;
L_80A569:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA569u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA569u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA569u, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A569 STA
    hw.write(cpu.address("abs", 0x2140u), cpu.a, cpu.m8?8:16);
    goto L_80A56C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA569u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA569u, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A569 STA
    hw.write(cpu.address("abs", 0x2140u), cpu.a, cpu.m8?8:16);
    goto L_80A56C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA569u,0x80A569u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A56C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA56Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Cu,cpu,0xECu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Cu, 5u, 3u, cpu.address("abs", 0x2140u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A56C CPX
    cpu.compareX(hw.readW(cpu.address("abs", 0x2140u), cpu.x8?8:16));
    goto L_80A56F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Cu,cpu,0xECu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Cu, 5u, 3u, cpu.address("abs", 0x2140u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A56C CPX
    cpu.compareX(hw.readW(cpu.address("abs", 0x2140u), cpu.x8?8:16));
    goto L_80A56F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA56Cu,0x80A56Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A56F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA56Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A56F BNE -> $80A569
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80A569; }
    goto L_80A571;
L_80A571:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA571u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA571u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA571u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A571 LDA
    cpu.setA(0x2u, 8);
    goto L_80A573;
L_80A573:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA573u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA573u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA573u, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A573 STA
    hw.write(cpu.address("abs", 0x2141u), cpu.a, cpu.m8?8:16);
    goto L_80A576;
L_80A576:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA576u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA576u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA576u, 4u, 3u, cpu.address("abs", 0x2142u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A576 STZ
    hw.write(cpu.address("abs", 0x2142u), 0, cpu.m8?8:16);
    goto L_80A579;
L_80A579:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA579u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA579u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA579u, 4u, 3u, cpu.address("abs", 0x2143u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A579 STA
    hw.write(cpu.address("abs", 0x2143u), cpu.a, cpu.m8?8:16);
    goto L_80A57C;
L_80A57C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA57Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A57C LDA
    cpu.setA(0xCCu, 8);
    goto L_80A57E;
L_80A57E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA57Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Eu, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A57E STA
    hw.write(cpu.address("abs", 0x2140u), cpu.a, cpu.m8?8:16);
    goto L_80A581;
L_80A581:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA581u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA581u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA581u, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A581 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x2140u), cpu.m8?8:16));
    goto L_80A584;
L_80A584:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA584u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA584u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA584u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A584 BNE -> $80A581
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80A581; }
    goto L_80A586;
L_80A586:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA586u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA586u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA586u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A586 LDA
    cpu.setA(0x0u, 8);
    goto L_80A588;
L_80A588:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA588u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA588u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA588u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A588 LDX
    cpu.setX(0x0u, 16);
    goto L_80A58B;
L_80A58B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA58Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Bu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A58B XBA
    cpu.xba();
    goto L_80A58C;
L_80A58C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA58Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Cu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Cu, 5u, 4u, ((0x80A5CCu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A58C LDA
    cpu.loadA(hw.readW(((0x80A5CCu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A590;
L_80A590:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA590u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA590u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA590u, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A590 STA
    hw.write(cpu.address("abs", 0x2141u), cpu.a, cpu.m8?8:16);
    goto L_80A593;
L_80A593:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA593u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA593u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA593u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A593 XBA
    cpu.xba();
    goto L_80A594;
L_80A594:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA594u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA594u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA594u, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A594 STA
    hw.write(cpu.address("abs", 0x2140u), cpu.a, cpu.m8?8:16);
    goto L_80A597;
L_80A597:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA597u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA597u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA597u, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A597 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x2140u), cpu.m8?8:16));
    goto L_80A59A;
L_80A59A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA59Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A59A BNE -> $80A597
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80A597; }
    goto L_80A59C;
L_80A59C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA59Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Cu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A59C INX
    cpu.inc('X');
    goto L_80A59D;
L_80A59D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA59Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Du,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A59D INC
    cpu.inc('A');
    goto L_80A59E;
L_80A59E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA59Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A59E CMP
    cpu.compareA(0x5u);
    goto L_80A5A0;
L_80A5A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A0u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5A0 BCC -> $80A58B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80A58B; }
    goto L_80A5A2;
L_80A5A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A2u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5A2 LDX
    cpu.setX(0xFDBBu, 16);
    goto L_80A5A5;
L_80A5A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A5u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A5u, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5A5 STZ
    hw.write(cpu.address("abs", 0x2141u), 0, cpu.m8?8:16);
    goto L_80A5A8;
L_80A5A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A8u, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5A8 STA
    hw.write(cpu.address("abs", 0x2140u), cpu.a, cpu.m8?8:16);
    goto L_80A5AB;
L_80A5AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5ABu,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5ABu, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5AB CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x2140u), cpu.m8?8:16));
    goto L_80A5AE;
L_80A5AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5AEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5AEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5AE BNE -> $80A5AB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80A5AB; }
    goto L_80A5B0;
L_80A5B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B0u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5B0 INC
    cpu.inc('A');
    goto L_80A5B1;
L_80A5B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B1u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5B1 DEX
    cpu.decReg('X');
    goto L_80A5B2;
L_80A5B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5B2 BNE -> $80A5A5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80A5A5; }
    goto L_80A5B4;
L_80A5B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B4u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B4u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5B4 XBA
    cpu.xba();
    goto L_80A5B5;
L_80A5B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B5u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B5u, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5B5 STZ
    hw.write(cpu.address("abs", 0x2141u), 0, cpu.m8?8:16);
    goto L_80A5B8;
L_80A5B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B8u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B8u, 4u, 3u, cpu.address("abs", 0x2142u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5B8 STZ
    hw.write(cpu.address("abs", 0x2142u), 0, cpu.m8?8:16);
    goto L_80A5BB;
L_80A5BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5BB LDA
    cpu.setA(0x2u, 8);
    goto L_80A5BD;
L_80A5BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BDu, 4u, 3u, cpu.address("abs", 0x2143u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5BD STA
    hw.write(cpu.address("abs", 0x2143u), cpu.a, cpu.m8?8:16);
    goto L_80A5C0;
L_80A5C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C0u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C0u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5C0 XBA
    cpu.xba();
    goto L_80A5C1;
L_80A5C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C1u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5C1 INC
    cpu.inc('A');
    goto L_80A5C2;
L_80A5C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C2u, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5C2 STA
    hw.write(cpu.address("abs", 0x2140u), cpu.a, cpu.m8?8:16);
    goto L_80A5C5;
L_80A5C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C5u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C5u, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5C5 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x2140u), cpu.m8?8:16));
    goto L_80A5C8;
L_80A5C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5C8 BNE -> $80A5C5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80A5C5; }
    goto L_80A5CA;
L_80A5CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CAu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CAu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A5CA PLP
    cpu.pop("PLP", hw);
    goto L_80A5CB;
L_80A5CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5CBu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5CBu,0x80A5CBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CBu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A5CB RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80A5CBu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80A5CBu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80A554_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80A554u: goto L_80A554;
    case 0x80A555u: goto L_80A555;
    case 0x80A557u: goto L_80A557;
    case 0x80A55Bu: goto L_80A55B;
    case 0x80A55Eu: goto L_80A55E;
    case 0x80A561u: goto L_80A561;
    case 0x80A562u: goto L_80A562;
    case 0x80A564u: goto L_80A564;
    case 0x80A567u: goto L_80A567;
    case 0x80A569u: goto L_80A569;
    case 0x80A56Cu: goto L_80A56C;
    case 0x80A56Fu: goto L_80A56F;
    case 0x80A571u: goto L_80A571;
    case 0x80A573u: goto L_80A573;
    case 0x80A576u: goto L_80A576;
    case 0x80A579u: goto L_80A579;
    case 0x80A57Cu: goto L_80A57C;
    case 0x80A57Eu: goto L_80A57E;
    case 0x80A581u: goto L_80A581;
    case 0x80A584u: goto L_80A584;
    case 0x80A586u: goto L_80A586;
    case 0x80A588u: goto L_80A588;
    case 0x80A58Bu: goto L_80A58B;
    case 0x80A58Cu: goto L_80A58C;
    case 0x80A590u: goto L_80A590;
    case 0x80A593u: goto L_80A593;
    case 0x80A594u: goto L_80A594;
    case 0x80A597u: goto L_80A597;
    case 0x80A59Au: goto L_80A59A;
    case 0x80A59Cu: goto L_80A59C;
    case 0x80A59Du: goto L_80A59D;
    case 0x80A59Eu: goto L_80A59E;
    case 0x80A5A0u: goto L_80A5A0;
    case 0x80A5A2u: goto L_80A5A2;
    case 0x80A5A5u: goto L_80A5A5;
    case 0x80A5A8u: goto L_80A5A8;
    case 0x80A5ABu: goto L_80A5AB;
    case 0x80A5AEu: goto L_80A5AE;
    case 0x80A5B0u: goto L_80A5B0;
    case 0x80A5B1u: goto L_80A5B1;
    case 0x80A5B2u: goto L_80A5B2;
    case 0x80A5B4u: goto L_80A5B4;
    case 0x80A5B5u: goto L_80A5B5;
    case 0x80A5B8u: goto L_80A5B8;
    case 0x80A5BBu: goto L_80A5BB;
    case 0x80A5BDu: goto L_80A5BD;
    case 0x80A5C0u: goto L_80A5C0;
    case 0x80A5C1u: goto L_80A5C1;
    case 0x80A5C2u: goto L_80A5C2;
    case 0x80A5C5u: goto L_80A5C5;
    case 0x80A5C8u: goto L_80A5C8;
    case 0x80A5CAu: goto L_80A5CA;
    case 0x80A5CBu: goto L_80A5CB;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80A554:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA554u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA554u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA554u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A554 PHP
    cpu.push("PHP", hw);
    goto L_80A555;
L_80A555:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA555u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA555u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA555u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A555 SEP
    cpu.sep(0x20u);
    goto L_80A557;
L_80A557:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA557u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA557u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA557u, 8u, 4u, 0x80A5D1u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A557 JSL -> $80A5D1 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA55Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA55Bu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A5D1u, 0x80A557u); }
    goto L_80A55B;
L_80A55B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA55Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA55Bu,0x80A55Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A55B LDX
    cpu.setX(0x8u, 16);
    goto L_80A55E;
L_80A55E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA55Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Eu, 6u, 3u, cpu.address("abs", 0xA5E0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A55E JSR -> $80A5E0 stack real
    { cpu.push16Value(hw,0xA560u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA561u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA5E0u), 0x80A55Eu); }
    goto L_80A561;
L_80A561:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA561u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA561u,0x80A561u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA561u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA561u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A561 DEX
    cpu.decReg('X');
    goto L_80A562;
L_80A562:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA562u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA562u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA562u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A562 BNE -> $80A55E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80A55E; }
    goto L_80A564;
L_80A564:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA564u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA564u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA564u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A564 LDX
    cpu.setX(0xBBAAu, 16);
    goto L_80A567;
L_80A567:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA567u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA567u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA567u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A567 LDA
    cpu.setA(0xFFu, 8);
    goto L_80A569;
L_80A569:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA569u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA569u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA569u, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A569 STA
    hw.write(cpu.address("abs", 0x2140u), cpu.a, cpu.m8?8:16);
    goto L_80A56C;
L_80A56C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA56Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Cu,cpu,0xECu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Cu, 5u, 3u, cpu.address("abs", 0x2140u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A56C CPX
    cpu.compareX(hw.readW(cpu.address("abs", 0x2140u), cpu.x8?8:16));
    goto L_80A56F;
L_80A56F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA56Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A56F BNE -> $80A569
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80A569; }
    goto L_80A571;
L_80A571:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA571u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA571u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA571u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A571 LDA
    cpu.setA(0x2u, 8);
    goto L_80A573;
L_80A573:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA573u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA573u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA573u, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A573 STA
    hw.write(cpu.address("abs", 0x2141u), cpu.a, cpu.m8?8:16);
    goto L_80A576;
L_80A576:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA576u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA576u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA576u, 4u, 3u, cpu.address("abs", 0x2142u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A576 STZ
    hw.write(cpu.address("abs", 0x2142u), 0, cpu.m8?8:16);
    goto L_80A579;
L_80A579:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA579u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA579u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA579u, 4u, 3u, cpu.address("abs", 0x2143u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A579 STA
    hw.write(cpu.address("abs", 0x2143u), cpu.a, cpu.m8?8:16);
    goto L_80A57C;
L_80A57C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA57Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A57C LDA
    cpu.setA(0xCCu, 8);
    goto L_80A57E;
L_80A57E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA57Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Eu, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A57E STA
    hw.write(cpu.address("abs", 0x2140u), cpu.a, cpu.m8?8:16);
    goto L_80A581;
L_80A581:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA581u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA581u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA581u, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A581 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x2140u), cpu.m8?8:16));
    goto L_80A584;
L_80A584:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA584u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA584u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA584u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A584 BNE -> $80A581
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80A581; }
    goto L_80A586;
L_80A586:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA586u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA586u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA586u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A586 LDA
    cpu.setA(0x0u, 8);
    goto L_80A588;
L_80A588:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA588u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA588u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA588u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A588 LDX
    cpu.setX(0x0u, 16);
    goto L_80A58B;
L_80A58B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA58Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Bu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A58B XBA
    cpu.xba();
    goto L_80A58C;
L_80A58C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA58Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Cu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Cu, 5u, 4u, ((0x80A5CCu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A58C LDA
    cpu.loadA(hw.readW(((0x80A5CCu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A590;
L_80A590:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA590u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA590u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA590u, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A590 STA
    hw.write(cpu.address("abs", 0x2141u), cpu.a, cpu.m8?8:16);
    goto L_80A593;
L_80A593:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA593u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA593u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA593u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A593 XBA
    cpu.xba();
    goto L_80A594;
L_80A594:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA594u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA594u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA594u, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A594 STA
    hw.write(cpu.address("abs", 0x2140u), cpu.a, cpu.m8?8:16);
    goto L_80A597;
L_80A597:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA597u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA597u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA597u, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A597 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x2140u), cpu.m8?8:16));
    goto L_80A59A;
L_80A59A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA59Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A59A BNE -> $80A597
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80A597; }
    goto L_80A59C;
L_80A59C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA59Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Cu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A59C INX
    cpu.inc('X');
    goto L_80A59D;
L_80A59D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA59Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Du,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A59D INC
    cpu.inc('A');
    goto L_80A59E;
L_80A59E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA59Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A59E CMP
    cpu.compareA(0x5u);
    goto L_80A5A0;
L_80A5A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A0u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5A0 BCC -> $80A58B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80A58B; }
    goto L_80A5A2;
L_80A5A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A2u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5A2 LDX
    cpu.setX(0xFDBBu, 16);
    goto L_80A5A5;
L_80A5A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A5u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A5u, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5A5 STZ
    hw.write(cpu.address("abs", 0x2141u), 0, cpu.m8?8:16);
    goto L_80A5A8;
L_80A5A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A8u, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5A8 STA
    hw.write(cpu.address("abs", 0x2140u), cpu.a, cpu.m8?8:16);
    goto L_80A5AB;
L_80A5AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5ABu,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5ABu, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5AB CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x2140u), cpu.m8?8:16));
    goto L_80A5AE;
L_80A5AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5AEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5AEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5AE BNE -> $80A5AB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80A5AB; }
    goto L_80A5B0;
L_80A5B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B0u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5B0 INC
    cpu.inc('A');
    goto L_80A5B1;
L_80A5B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B1u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5B1 DEX
    cpu.decReg('X');
    goto L_80A5B2;
L_80A5B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5B2 BNE -> $80A5A5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80A5A5; }
    goto L_80A5B4;
L_80A5B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B4u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B4u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5B4 XBA
    cpu.xba();
    goto L_80A5B5;
L_80A5B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B5u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B5u, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5B5 STZ
    hw.write(cpu.address("abs", 0x2141u), 0, cpu.m8?8:16);
    goto L_80A5B8;
L_80A5B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B8u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B8u, 4u, 3u, cpu.address("abs", 0x2142u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5B8 STZ
    hw.write(cpu.address("abs", 0x2142u), 0, cpu.m8?8:16);
    goto L_80A5BB;
L_80A5BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5BB LDA
    cpu.setA(0x2u, 8);
    goto L_80A5BD;
L_80A5BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BDu, 4u, 3u, cpu.address("abs", 0x2143u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5BD STA
    hw.write(cpu.address("abs", 0x2143u), cpu.a, cpu.m8?8:16);
    goto L_80A5C0;
L_80A5C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C0u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C0u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5C0 XBA
    cpu.xba();
    goto L_80A5C1;
L_80A5C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C1u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5C1 INC
    cpu.inc('A');
    goto L_80A5C2;
L_80A5C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C2u, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5C2 STA
    hw.write(cpu.address("abs", 0x2140u), cpu.a, cpu.m8?8:16);
    goto L_80A5C5;
L_80A5C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C5u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C5u, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5C5 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x2140u), cpu.m8?8:16));
    goto L_80A5C8;
L_80A5C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A5C8 BNE -> $80A5C5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80A5C5; }
    goto L_80A5CA;
L_80A5CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CAu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CAu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A5CA PLP
    cpu.pop("PLP", hw);
    goto L_80A5CB;
L_80A5CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5CBu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5CBu,0x80A5CBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CBu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A5CB RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80A5CBu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80A5CBu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80ADF0_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80ADF0u: goto L_80ADF0;
    case 0x80ADF3u: goto L_80ADF3;
    case 0x80ADF5u: goto L_80ADF5;
    case 0x80ADF8u: goto L_80ADF8;
    case 0x80ADFBu: goto L_80ADFB;
    case 0x80ADFDu: goto L_80ADFD;
    case 0x80AE00u: goto L_80AE00;
    case 0x80AE03u: goto L_80AE03;
    case 0x80AE06u: goto L_80AE06;
    case 0x80AE09u: goto L_80AE09;
    case 0x80AE0Cu: goto L_80AE0C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80ADF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADF0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADF0u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADF0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80ADF3;
L_80ADF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADF3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADF3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADF3 BEQ -> $80AE06
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AE06; }
    goto L_80ADF5;
L_80ADF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADF5u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADF5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADF5 LDX
    cpu.setX(0x328u, 16);
    goto L_80ADF8;
L_80ADF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADF8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADF8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADF8 LDA
    cpu.setA(0x3u, 16);
    goto L_80ADFB;
L_80ADFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADFBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADFBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADFB STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80ADFD;
L_80ADFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADFDu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADFDu, 8u, 3u, cpu.address("abs", 0x0986u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADFD INC
    cpu.incMem(hw, cpu.address("abs", 0x986u), cpu.m8?8:16);
    goto L_80AE00;
L_80AE00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE00u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE00u, 6u, 3u, cpu.address("abs", 0xC7F6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AE00 JSR -> $80C7F6 stack real
    { cpu.push16Value(hw,0xAE02u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE03u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC7F6u), 0x80AE00u); }
    goto L_80AE03;
L_80AE03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE03u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE03u,0x80AE03u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE03u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE03u, 6u, 3u, cpu.address("abs", 0xC404u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AE03 JSR -> $80C404 stack real
    { cpu.push16Value(hw,0xAE05u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE06u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC404u), 0x80AE03u); }
    goto L_80AE06;
L_80AE06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE06u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE06u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE06u, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE06 STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80AE09;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE06u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE06u, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE06 STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80AE09;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE06u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE06u, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE06 STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80AE09;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE06u,0x80AE06u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AE09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE09u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE09u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE09u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE09 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AE0C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE09u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE09u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE09 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AE0C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE09u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE09u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE09 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AE0C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE09u,0x80AE09u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AE0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE0Cu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AE0C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AE0Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AE0Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AE0C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AE0Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AE0Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AE0C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AE0Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AE0Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE0Cu,0x80AE0Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80B0F1_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B0F1u: goto L_80B0F1;
    case 0x80B0F4u: goto L_80B0F4;
    case 0x80B0F6u: goto L_80B0F6;
    case 0x80B0F9u: goto L_80B0F9;
    case 0x80B0FCu: goto L_80B0FC;
    case 0x80B0FEu: goto L_80B0FE;
    case 0x80B101u: goto L_80B101;
    case 0x80B104u: goto L_80B104;
    case 0x80B107u: goto L_80B107;
    case 0x80B10Au: goto L_80B10A;
    case 0x80B10Du: goto L_80B10D;
    case 0x80B110u: goto L_80B110;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B0F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0F1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0F1u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0F1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B0F4;
L_80B0F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0F4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0F4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0F4 BEQ -> $80B10A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B10A; }
    goto L_80B0F6;
L_80B0F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0F6u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0F6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0F6 LDX
    cpu.setX(0x3D8u, 16);
    goto L_80B0F9;
L_80B0F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0F9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0F9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0F9 LDA
    cpu.setA(0x2u, 16);
    goto L_80B0FC;
L_80B0FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0FCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0FCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0FC STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80B0FE;
L_80B0FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0FEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0FEu, 5u, 3u, cpu.address("abs", 0x0914u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0FE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x914u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B101;
L_80B101:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB101u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB101u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB101u, 5u, 3u, cpu.address("abs", 0x097Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B101 STA
    hw.write(cpu.address("abs", 0x97Au), cpu.a, cpu.m8?8:16);
    goto L_80B104;
L_80B104:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB104u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB104u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB104u, 8u, 3u, cpu.address("abs", 0x0986u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B104 INC
    cpu.incMem(hw, cpu.address("abs", 0x986u), cpu.m8?8:16);
    goto L_80B107;
L_80B107:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB107u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB107u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB107u, 6u, 3u, cpu.address("abs", 0xC85Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B107 JSR -> $80C85C stack real
    { cpu.push16Value(hw,0xB109u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB10Au,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC85Cu), 0x80B107u); }
    goto L_80B10A;
L_80B10A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB10Au))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Au, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B10A STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B10D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Au, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B10A STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B10D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Au, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B10A STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B10D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB10Au,0x80B10Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B10D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB10Du))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Du,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Du, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B10D INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B110;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Du,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Du, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B10D INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B110;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Du,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Du, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B10D INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B110;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB10Du,0x80B10Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B110:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB110u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB110u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB110u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B110 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B110u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B110u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB110u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB110u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B110 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B110u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B110u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB110u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB110u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B110 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B110u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B110u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB110u,0x80B110u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80B63C_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B63Cu: goto L_80B63C;
    case 0x80B63Fu: goto L_80B63F;
    case 0x80B642u: goto L_80B642;
    case 0x80B644u: goto L_80B644;
    case 0x80B647u: goto L_80B647;
    case 0x80B64Au: goto L_80B64A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B63C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB63Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB63Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB63Cu, 5u, 3u, cpu.address("abs", 0x0137u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B63C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x137u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B63F;
L_80B63F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB63Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB63Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB63Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B63F CMP
    cpu.compareA(0x2u);
    goto L_80B642;
L_80B642:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB642u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB642u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB642u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B642 BCC -> $80B64A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B64A; }
    goto L_80B644;
L_80B644:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB644u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB644u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB644u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B644 LDA
    cpu.setA(0x400u, 16);
    goto L_80B647;
L_80B647:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB647u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB647u,cpu,0x0Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB647u, 8u, 3u, cpu.address("abs", 0x0922u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B647 TSB
    cpu.tsb(hw, cpu.address("abs", 0x922u), cpu.m8?8:16);
    goto L_80B64A;
L_80B64A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB64Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B64A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B64Au);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B64Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80B855_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B855u: goto L_80B855;
    case 0x80B858u: goto L_80B858;
    case 0x80B85Au: goto L_80B85A;
    case 0x80B85Du: goto L_80B85D;
    case 0x80B85Fu: goto L_80B85F;
    case 0x80B862u: goto L_80B862;
    case 0x80B865u: goto L_80B865;
    case 0x80B867u: goto L_80B867;
    case 0x80B86Au: goto L_80B86A;
    case 0x80B86Cu: goto L_80B86C;
    case 0x80B86Eu: goto L_80B86E;
    case 0x80B871u: goto L_80B871;
    case 0x80B874u: goto L_80B874;
    case 0x80B876u: goto L_80B876;
    case 0x80B879u: goto L_80B879;
    case 0x80B87Bu: goto L_80B87B;
    case 0x80B87Eu: goto L_80B87E;
    case 0x80B881u: goto L_80B881;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B855:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB855u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB855u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB855u, 5u, 3u, cpu.address("abs", 0x094Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B855 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x94Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B858;
L_80B858:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB858u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB858u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB858u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B858 BNE -> $80B867
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B867; }
    goto L_80B85A;
L_80B85A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB85Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB85Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB85Au, 5u, 3u, cpu.address("abs", 0x0944u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B85A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x944u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B85D;
L_80B85D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB85Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB85Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB85Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B85D BNE -> $80B867
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B867; }
    goto L_80B85F;
L_80B85F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB85Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB85Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB85Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B85F LDA
    cpu.setA(0x200u, 16);
    goto L_80B862;
L_80B862:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB862u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB862u,cpu,0x0Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB862u, 8u, 3u, cpu.address("abs", 0x0922u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B862 TSB
    cpu.tsb(hw, cpu.address("abs", 0x922u), cpu.m8?8:16);
    goto L_80B865;
L_80B865:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB865u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB865u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB865u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B865 BRA -> $80B881
    goto L_80B881;
L_80B867:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB867u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB867u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB867u, 5u, 3u, cpu.address("abs", 0x0946u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B867 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x946u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B86A;
L_80B86A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB86Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB86Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB86Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B86A BNE -> $80B86E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B86E; }
    goto L_80B86C;
L_80B86C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB86Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB86Cu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB86Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B86C BRA -> $80B881
    goto L_80B881;
L_80B86E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB86Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB86Eu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB86Eu, 8u, 3u, cpu.address("abs", 0x094Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B86E INC
    cpu.incMem(hw, cpu.address("abs", 0x94Au), cpu.m8?8:16);
    goto L_80B871;
L_80B871:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB871u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB871u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB871u, 5u, 3u, cpu.address("abs", 0x0948u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B871 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x948u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B874;
L_80B874:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB874u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB874u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB874u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B874 BNE -> $80B881
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B881; }
    goto L_80B876;
L_80B876:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB876u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB876u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB876u, 5u, 3u, cpu.address("abs", 0x0942u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B876 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x942u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B879;
L_80B879:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB879u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB879u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB879u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B879 BNE -> $80B881
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B881; }
    goto L_80B87B;
L_80B87B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB87Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB87Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB87Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B87B LDA
    cpu.setA(0x100u, 16);
    goto L_80B87E;
L_80B87E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB87Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB87Eu,cpu,0x0Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB87Eu, 8u, 3u, cpu.address("abs", 0x0922u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B87E TSB
    cpu.tsb(hw, cpu.address("abs", 0x922u), cpu.m8?8:16);
    goto L_80B881;
L_80B881:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB881u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB881u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB881u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B881 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B881u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B881u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80BBB7_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80BBB7u: goto L_80BBB7;
    case 0x80BBB8u: goto L_80BBB8;
    case 0x80BBB9u: goto L_80BBB9;
    case 0x80BBBAu: goto L_80BBBA;
    case 0x80BBBDu: goto L_80BBBD;
    case 0x80BBC0u: goto L_80BBC0;
    case 0x80BBC2u: goto L_80BBC2;
    case 0x80BBC5u: goto L_80BBC5;
    case 0x80BBC7u: goto L_80BBC7;
    case 0x80BBCAu: goto L_80BBCA;
    case 0x80BBCCu: goto L_80BBCC;
    case 0x80BBCEu: goto L_80BBCE;
    case 0x80BBCFu: goto L_80BBCF;
    case 0x80BBD0u: goto L_80BBD0;
    case 0x80BBD4u: goto L_80BBD4;
    case 0x80BBD6u: goto L_80BBD6;
    case 0x80BBD9u: goto L_80BBD9;
    case 0x80BBDBu: goto L_80BBDB;
    case 0x80BBDDu: goto L_80BBDD;
    case 0x80BBE0u: goto L_80BBE0;
    case 0x80BBE3u: goto L_80BBE3;
    case 0x80BBE5u: goto L_80BBE5;
    case 0x80BBE7u: goto L_80BBE7;
    case 0x80BBE9u: goto L_80BBE9;
    case 0x80BBEBu: goto L_80BBEB;
    case 0x80BBEEu: goto L_80BBEE;
    case 0x80BBF0u: goto L_80BBF0;
    case 0x80BBF3u: goto L_80BBF3;
    case 0x80BBF6u: goto L_80BBF6;
    case 0x80BBF8u: goto L_80BBF8;
    case 0x80BBF9u: goto L_80BBF9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80BBB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBB7u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBB7u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BBB7 PHB
    cpu.push("PHB", hw);
    goto L_80BBB8;
L_80BBB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBB8u,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBB8u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BBB8 PHK
    cpu.push("PHK", hw);
    goto L_80BBB9;
L_80BBB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBB9u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBB9u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BBB9 PLB
    cpu.pop("PLB", hw);
    goto L_80BBBA;
L_80BBBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBBAu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBBAu, 5u, 3u, cpu.address("abs", 0x096Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBBA LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x96Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BBBD;
L_80BBBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBBDu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBBDu, 5u, 3u, cpu.address("abs", 0x0970u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBBD LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x970u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BBC0;
L_80BBC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBC0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBC0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBC0 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80BBC2;
L_80BBC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBC2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBC2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBC2 LDA
    cpu.setA(0x1Eu, 16);
    goto L_80BBC5;
L_80BBC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBC5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBC5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBC5 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_80BBC7;
L_80BBC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBC7u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBC7u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBC7u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBC7 STZ
    hw.write(cpu.address("abs", 0x958u), 0, cpu.m8?8:16);
    goto L_80BBCA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBC7u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBC7u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBC7 STZ
    hw.write(cpu.address("abs", 0x958u), 0, cpu.m8?8:16);
    goto L_80BBCA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBC7u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBC7u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBC7 STZ
    hw.write(cpu.address("abs", 0x958u), 0, cpu.m8?8:16);
    goto L_80BBCA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBBC7u,0x80BBC7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BBCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBCAu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBCAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBCAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBCA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BBCC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBCAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBCAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBCA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BBCC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBCAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBCAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBCA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BBCC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBBCAu,0x80BBCAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BBCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBCCu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBCCu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBCCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBCC BMI -> $80BBEB
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BBEB; }
    goto L_80BBCE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBCCu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBCCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBCC BMI -> $80BBEB
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BBEB; }
    goto L_80BBCE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBCCu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBCCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBCC BMI -> $80BBEB
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BBEB; }
    goto L_80BBCE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBBCCu,0x80BBCCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BBCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBCEu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBCEu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBCEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBCE INX
    cpu.inc('X');
    goto L_80BBCF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBCEu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBCEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBCE INX
    cpu.inc('X');
    goto L_80BBCF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBCEu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBCEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBCE INX
    cpu.inc('X');
    goto L_80BBCF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBBCEu,0x80BBCEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BBCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBCFu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBCFu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBCFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBCF INX
    cpu.inc('X');
    goto L_80BBD0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBCFu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBCFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBCF INX
    cpu.inc('X');
    goto L_80BBD0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBCFu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBCFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBCF INX
    cpu.inc('X');
    goto L_80BBD0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBBCFu,0x80BBCFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BBD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBD0u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD0u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD0u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBD0 LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BBD4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD0u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD0u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBD0 LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BBD4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD0u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD0u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBD0 LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BBD4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBBD0u,0x80BBD0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BBD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBD4u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBD4 BEQ -> $80BBC7
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BBC7; }
    goto L_80BBD6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBD4 BEQ -> $80BBC7
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BBC7; }
    goto L_80BBD6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBD4 BEQ -> $80BBC7
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BBC7; }
    goto L_80BBD6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBBD4u,0x80BBD4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BBD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBD6u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBD6 CMP
    cpu.compareA(0xFFFFu);
    goto L_80BBD9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBD6 CMP
    cpu.compareA(0xFFFFu);
    goto L_80BBD9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBD6 CMP
    cpu.compareA(0xFFFFu);
    goto L_80BBD9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBBD6u,0x80BBD6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BBD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBD9 BEQ -> $80BBE7
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BBE7; }
    goto L_80BBDB;
L_80BBDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBDBu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBDBu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBDB DEC
    cpu.decMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_80BBDD;
L_80BBDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBDDu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBDDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBDD AND
    cpu.logicAnd(0x300u);
    goto L_80BBE0;
L_80BBE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE0u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE0u, 5u, 3u, cpu.address("abs", 0x097Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBE0 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x97Au), cpu.m8?8:16));
    goto L_80BBE3;
L_80BBE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBE3 BEQ -> $80BBF0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BBF0; }
    goto L_80BBE5;
L_80BBE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE5u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBE5 BRA -> $80BBC7
    goto L_80BBC7;
L_80BBE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE7u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE7u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBE7 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_80BBE9;
L_80BBE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBE9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBE9 BNE -> $80BBC7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BBC7; }
    goto L_80BBEB;
L_80BBEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBEBu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBEBu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBEBu, 8u, 3u, cpu.address("abs", 0x0958u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBEB INC
    cpu.incMem(hw, cpu.address("abs", 0x958u), cpu.m8?8:16);
    goto L_80BBEE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBEBu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBEBu, 8u, 3u, cpu.address("abs", 0x0958u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBEB INC
    cpu.incMem(hw, cpu.address("abs", 0x958u), cpu.m8?8:16);
    goto L_80BBEE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBEBu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBEBu, 8u, 3u, cpu.address("abs", 0x0958u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBEB INC
    cpu.incMem(hw, cpu.address("abs", 0x958u), cpu.m8?8:16);
    goto L_80BBEE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBBEBu,0x80BBEBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BBEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBEEu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBEEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBEEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBEE BRA -> $80BBF8
    goto L_80BBF8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBEEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBEEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBEE BRA -> $80BBF8
    goto L_80BBF8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBEEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBEEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBEE BRA -> $80BBF8
    goto L_80BBF8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBBEEu,0x80BBEEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BBF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF0u, 6u, 3u, cpu.address("abs", 0xBD77u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BBF0 JSR -> $80BD77 stack real
    { cpu.push16Value(hw,0xBBF2u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBBF3u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBD77u), 0x80BBF0u); }
    goto L_80BBF3;
L_80BBF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBF3u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF3u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBF3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BBF6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF3u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBF3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BBF6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF3u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBF3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BBF6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBBF3u,0x80BBF3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BBF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBF6u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBF6 BNE -> $80BBC7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BBC7; }
    goto L_80BBF8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBF6 BNE -> $80BBC7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BBC7; }
    goto L_80BBF8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBF6 BNE -> $80BBC7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BBC7; }
    goto L_80BBF8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBBF6u,0x80BBF6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BBF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBF8u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF8u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF8u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BBF8 PLB
    cpu.pop("PLB", hw);
    goto L_80BBF9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF8u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF8u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BBF8 PLB
    cpu.pop("PLB", hw);
    goto L_80BBF9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF8u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF8u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80BBF8 PLB
    cpu.pop("PLB", hw);
    goto L_80BBF9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBBF8u,0x80BBF8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80BBF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBF9u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BBF9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80BBF9u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80BBF9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BBF9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80BBF9u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80BBF9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BBF9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80BBF9u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80BBF9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBBF9u,0x80BBF9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80D66A_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80D66Au: goto L_80D66A;
    case 0x80D66Cu: goto L_80D66C;
    case 0x80D670u: goto L_80D670;
    case 0x80D673u: goto L_80D673;
    case 0x80D675u: goto L_80D675;
    case 0x80D679u: goto L_80D679;
    case 0x80D67Bu: goto L_80D67B;
    case 0x80D67Eu: goto L_80D67E;
    case 0x80D680u: goto L_80D680;
    case 0x80D682u: goto L_80D682;
    case 0x80D684u: goto L_80D684;
    case 0x80D685u: goto L_80D685;
    case 0x80D686u: goto L_80D686;
    case 0x80D689u: goto L_80D689;
    case 0x80D68Au: goto L_80D68A;
    case 0x80D68Cu: goto L_80D68C;
    case 0x80D690u: goto L_80D690;
    case 0x80D692u: goto L_80D692;
    case 0x80D695u: goto L_80D695;
    case 0x80D697u: goto L_80D697;
    case 0x80D69Au: goto L_80D69A;
    case 0x80D69Cu: goto L_80D69C;
    case 0x80D69Eu: goto L_80D69E;
    case 0x80D6A0u: goto L_80D6A0;
    case 0x80D6A1u: goto L_80D6A1;
    case 0x80D6A2u: goto L_80D6A2;
    case 0x80D6A5u: goto L_80D6A5;
    case 0x80D6A6u: goto L_80D6A6;
    case 0x80D6A9u: goto L_80D6A9;
    case 0x80D6ABu: goto L_80D6AB;
    case 0x80D6AFu: goto L_80D6AF;
    case 0x80D6B1u: goto L_80D6B1;
    case 0x80D6B4u: goto L_80D6B4;
    case 0x80D6B6u: goto L_80D6B6;
    case 0x80D6B9u: goto L_80D6B9;
    case 0x80D6BBu: goto L_80D6BB;
    case 0x80D6BDu: goto L_80D6BD;
    case 0x80D6BFu: goto L_80D6BF;
    case 0x80D6C1u: goto L_80D6C1;
    case 0x80D6C5u: goto L_80D6C5;
    case 0x80D6C8u: goto L_80D6C8;
    case 0x80D6CAu: goto L_80D6CA;
    case 0x80D6CCu: goto L_80D6CC;
    case 0x80D6D0u: goto L_80D6D0;
    case 0x80D6D3u: goto L_80D6D3;
    case 0x80D6D6u: goto L_80D6D6;
    case 0x80D6D8u: goto L_80D6D8;
    case 0x80D6D9u: goto L_80D6D9;
    case 0x80D6DAu: goto L_80D6DA;
    case 0x80D6DDu: goto L_80D6DD;
    case 0x80D6DEu: goto L_80D6DE;
    case 0x80D6E0u: goto L_80D6E0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80D66A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD66Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD66Au,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD66Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D66A STZ
    hw.write(cpu.address("dp", 0x2u), 0, cpu.m8?8:16);
    goto L_80D66C;
L_80D66C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD66Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD66Cu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD66Cu, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D66C LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D670;
L_80D670:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD670u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD670u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD670u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D670 AND
    cpu.logicAnd(0x300u);
    goto L_80D673;
L_80D673:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD673u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD673u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD673u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D673 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80D675;
L_80D675:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD675u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD675u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD675u, 6u, 4u, ((0x7E1FEAu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D675 LDA
    cpu.loadA(hw.readW(((0x7E1FEAu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D679;
L_80D679:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD679u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD679u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD679u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D679 BEQ -> $80D68C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D68C; }
    goto L_80D67B;
L_80D67B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD67Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD67Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD67Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D67B AND
    cpu.logicAnd(0x300u);
    goto L_80D67E;
L_80D67E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD67Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD67Eu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD67Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D67E CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_80D680;
L_80D680:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD680u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD680u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD680u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D680 BNE -> $80D6E0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D6E0; }
    goto L_80D682;
L_80D682:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD682u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD682u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD682u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D682 INC
    cpu.incMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_80D684;
L_80D684:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD684u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD684u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD684u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D684 TXA
    cpu.transfer("TXA");
    goto L_80D685;
L_80D685:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD685u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD685u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD685u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D685 SEC
    cpu.setFlag('C', true);
    goto L_80D686;
L_80D686:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD686u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD686u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD686u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D686 SBC
    cpu.sbc(0x16u);
    goto L_80D689;
L_80D689:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD689u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD689u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD689u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D689 TAX
    cpu.transfer("TAX");
    goto L_80D68A;
L_80D68A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD68Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD68Au,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD68Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D68A BRA -> $80D6A0
    goto L_80D6A0;
L_80D68C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD68Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD68Cu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD68Cu, 6u, 4u, ((0x7E2016u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D68C LDA
    cpu.loadA(hw.readW(((0x7E2016u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D690;
L_80D690:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD690u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD690u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD690u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D690 BEQ -> $80D6E0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D6E0; }
    goto L_80D692;
L_80D692:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD692u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD692u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD692u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D692 CMP
    cpu.compareA(0xFFFFu);
    goto L_80D695;
L_80D695:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD695u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD695u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD695u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D695 BEQ -> $80D6A0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D6A0; }
    goto L_80D697;
L_80D697:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD697u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD697u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD697u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D697 AND
    cpu.logicAnd(0x300u);
    goto L_80D69A;
L_80D69A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD69Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD69Au,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD69Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D69A CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_80D69C;
L_80D69C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD69Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD69Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD69Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D69C BNE -> $80D6A0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D6A0; }
    goto L_80D69E;
L_80D69E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD69Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD69Eu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD69Eu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D69E INC
    cpu.incMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_80D6A0;
L_80D6A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6A0u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6A0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6A0 TXA
    cpu.transfer("TXA");
    goto L_80D6A1;
L_80D6A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6A1u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6A1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6A1 SEC
    cpu.setFlag('C', true);
    goto L_80D6A2;
L_80D6A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6A2u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6A2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6A2 SBC
    cpu.sbc(0x16u);
    goto L_80D6A5;
L_80D6A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6A5u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6A5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6A5 TAX
    cpu.transfer("TAX");
    goto L_80D6A6;
L_80D6A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6A6u,cpu,0xECu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6A6u, 5u, 3u, cpu.address("abs", 0x096Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6A6 CPX
    cpu.compareX(hw.readW(cpu.address("abs", 0x96Eu), cpu.x8?8:16));
    goto L_80D6A9;
L_80D6A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6A9u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6A9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6A9 BCC -> $80D6E0
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80D6E0; }
    goto L_80D6AB;
L_80D6AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6ABu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6ABu, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6AB LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D6AF;
L_80D6AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6AFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6AFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6AF BEQ -> $80D6A0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D6A0; }
    goto L_80D6B1;
L_80D6B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6B1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6B1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6B1 CMP
    cpu.compareA(0xFFFFu);
    goto L_80D6B4;
L_80D6B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6B4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6B4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6B4 BEQ -> $80D6E0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D6E0; }
    goto L_80D6B6;
L_80D6B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6B6u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6B6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6B6 AND
    cpu.logicAnd(0x300u);
    goto L_80D6B9;
L_80D6B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6B9u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6B9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6B9 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_80D6BB;
L_80D6BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6BBu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6BBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6BB BNE -> $80D6E0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D6E0; }
    goto L_80D6BD;
L_80D6BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6BDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6BDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6BD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D6BF;
L_80D6BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6BFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6BFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6BF BNE -> $80D6CC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D6CC; }
    goto L_80D6C1;
L_80D6C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6C1u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6C1u, 6u, 4u, ((0x7E1FEAu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6C1 LDA
    cpu.loadA(hw.readW(((0x7E1FEAu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D6C5;
L_80D6C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6C5u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6C5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6C5 AND
    cpu.logicAnd(0x300u);
    goto L_80D6C8;
L_80D6C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6C8u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6C8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6C8 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_80D6CA;
L_80D6CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6CAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6CAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6CA BNE -> $80D6E0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D6E0; }
    goto L_80D6CC;
L_80D6CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6CCu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6CCu, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6CC LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D6D0;
L_80D6D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D0u, 6u, 3u, cpu.address("abs", 0xD6E1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D6D0 JSR -> $80D6E1 stack real
    { cpu.push16Value(hw,0xD6D2u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD6D3u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD6E1u), 0x80D6D0u); }
    goto L_80D6D3;
L_80D6D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6D3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD6D3u,0x80D6D3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D3u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6D3 BIT
    cpu.bit(0x1u, true);
    goto L_80D6D6;
L_80D6D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6D6 BEQ -> $80D6E0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D6E0; }
    goto L_80D6D8;
L_80D6D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D8u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6D8 TXA
    cpu.transfer("TXA");
    goto L_80D6D9;
L_80D6D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D9u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6D9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6D9 SEC
    cpu.setFlag('C', true);
    goto L_80D6DA;
L_80D6DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6DAu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6DAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6DA SBC
    cpu.sbc(0x16u);
    goto L_80D6DD;
L_80D6DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6DDu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6DDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6DD TAX
    cpu.transfer("TAX");
    goto L_80D6DE;
L_80D6DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6DEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6DEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D6DE BRA -> $80D6CC
    goto L_80D6CC;
L_80D6E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6E0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6E0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D6E0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80D6E0u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80D6E0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_829FC9_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829FC9u: goto L_829FC9;
    case 0x829FCCu: goto L_829FCC;
    case 0x829FCFu: goto L_829FCF;
    case 0x829FD2u: goto L_829FD2;
    case 0x829FD4u: goto L_829FD4;
    case 0x829FD5u: goto L_829FD5;
    case 0x829FD7u: goto L_829FD7;
    case 0x829FD9u: goto L_829FD9;
    case 0x829FDCu: goto L_829FDC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829FC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FC9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FC9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829FC9 LDA
    cpu.setA(0x20u, 16);
    goto L_829FCC;
L_829FCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FCCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FCCu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FCCu, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829FCC LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x135u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829FCF;
L_829FCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FCFu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FCFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829FCF CPX
    cpu.compareX(0x1u);
    goto L_829FD2;
L_829FD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FD2u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FD2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829FD2 BCS -> $829FD5
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_829FD5; }
    goto L_829FD4;
L_829FD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FD4u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FD4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829FD4 LSR
    cpu.lsrA();
    goto L_829FD5;
L_829FD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FD5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FD5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829FD5 STA
    hw.write(cpu.address("dp", 0x6Fu), cpu.a, cpu.m8?8:16);
    goto L_829FD7;
L_829FD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FD7u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FD7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829FD7 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829FD9;
L_829FD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FD9u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FD9u, 9u, 3u, cpu.address("absx", 0x0200u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829FD9 INC
    cpu.incMem(hw, cpu.address("absx", 0x200u), cpu.m8?8:16);
    goto L_829FDC;
L_829FDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FDCu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FDCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829FDC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829FDCu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829FDCu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82AFDE_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82AFDEu: goto L_82AFDE;
    case 0x82AFE1u: goto L_82AFE1;
    case 0x82AFE4u: goto L_82AFE4;
    case 0x82AFE5u: goto L_82AFE5;
    case 0x82AFE6u: goto L_82AFE6;
    case 0x82AFE9u: goto L_82AFE9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82AFDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFDEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFDEu, 5u, 3u, cpu.address("abs", 0x0141u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFDE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x141u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AFE1;
L_82AFE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFE1u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFE1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFE1 AND
    cpu.logicAnd(0xFFu);
    goto L_82AFE4;
L_82AFE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFE4u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFE4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFE4 ASL
    cpu.aslA();
    goto L_82AFE5;
L_82AFE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFE5u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFE5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFE5 TAX
    cpu.transfer("TAX");
    goto L_82AFE6;
L_82AFE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFE6u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFE6u, 5u, 3u, cpu.address("abs", 0xAFEBu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AFE6 PEA
    cpu.push16Value(hw, 0xAFEBu);
    goto L_82AFE9;
L_82AFE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFE9u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFE9u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xAFEFu + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $82AFE9 JMP (AFEF,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xAFEFu+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x82AFE9u); return; }
}

void sub_82B0C6_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B0C6u: goto L_82B0C6;
    case 0x82B0C9u: goto L_82B0C9;
    case 0x82B0CBu: goto L_82B0CB;
    case 0x82B0CEu: goto L_82B0CE;
    case 0x82B0D0u: goto L_82B0D0;
    case 0x82B0D3u: goto L_82B0D3;
    case 0x82B0D5u: goto L_82B0D5;
    case 0x82B0D7u: goto L_82B0D7;
    case 0x82B0DAu: goto L_82B0DA;
    case 0x82B0DCu: goto L_82B0DC;
    case 0x82B0DEu: goto L_82B0DE;
    case 0x82B0E0u: goto L_82B0E0;
    case 0x82B0E3u: goto L_82B0E3;
    case 0x82B0E6u: goto L_82B0E6;
    case 0x82B0E9u: goto L_82B0E9;
    case 0x82B0ECu: goto L_82B0EC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B0C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C6u, 5u, 3u, cpu.address("abs", 0x0176u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0C6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x176u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B0C9;
L_82B0C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0C9 BNE -> $82B0D3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B0D3; }
    goto L_82B0CB;
L_82B0CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0CBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0CBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0CB LDA
    cpu.setA(0x40u, 16);
    goto L_82B0CE;
L_82B0CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0CEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0CEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0CE STA
    hw.write(cpu.address("dp", 0x6Fu), cpu.a, cpu.m8?8:16);
    goto L_82B0D0;
L_82B0D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D0u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D0u, 8u, 3u, cpu.address("abs", 0x0176u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0D0 INC
    cpu.incMem(hw, cpu.address("abs", 0x176u), cpu.m8?8:16);
    goto L_82B0D3;
L_82B0D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0D3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B0D5;
L_82B0D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0D5 BNE -> $82B0E6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B0E6; }
    goto L_82B0D7;
L_82B0D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D7u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D7u, 5u, 3u, cpu.address("abs", 0x0176u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0D7 STZ
    hw.write(cpu.address("abs", 0x176u), 0, cpu.m8?8:16);
    goto L_82B0DA;
L_82B0DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0DAu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0DAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0DA SEP
    cpu.sep(0x20u);
    goto L_82B0DC;
L_82B0DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0DCu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0DCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0DC INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_82B0DE;
L_82B0DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0DEu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0DEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0DE REP
    cpu.rep(0x20u);
    goto L_82B0E0;
L_82B0E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0E0u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0E0u, 5u, 3u, cpu.address("abs", 0x0185u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0E0 STZ
    hw.write(cpu.address("abs", 0x185u), 0, cpu.m8?8:16);
    goto L_82B0E3;
L_82B0E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0E3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0E3u, 6u, 3u, cpu.address("abs", 0xCA80u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B0E3 JSR -> $82CA80 stack real
    { cpu.push16Value(hw,0xB0E5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0E6u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCA80u), 0x82B0E3u); }
    goto L_82B0E6;
L_82B0E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0E6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0E6u,0x82B0E6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0E6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0E6u, 6u, 3u, cpu.address("abs", 0xD5A3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B0E6 JSR -> $82D5A3 stack real
    { cpu.push16Value(hw,0xB0E8u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0E9u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD5A3u), 0x82B0E6u); }
    goto L_82B0E9;
L_82B0E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0E9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0E9u,0x82B0E9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0E9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0E9u, 6u, 3u, cpu.address("abs", 0xCAA5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B0E9 JSR -> $82CAA5 stack real
    { cpu.push16Value(hw,0xB0EBu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0ECu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCAA5u), 0x82B0E9u); }
    goto L_82B0EC;
L_82B0EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0ECu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0ECu,0x82B0ECu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0ECu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0ECu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B0EC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B0ECu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B0ECu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B508_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B508u: goto L_82B508;
    case 0x82B50Au: goto L_82B50A;
    case 0x82B50Cu: goto L_82B50C;
    case 0x82B50Eu: goto L_82B50E;
    case 0x82B511u: goto L_82B511;
    case 0x82B513u: goto L_82B513;
    case 0x82B514u: goto L_82B514;
    case 0x82B517u: goto L_82B517;
    case 0x82B519u: goto L_82B519;
    case 0x82B51Cu: goto L_82B51C;
    case 0x82B51Eu: goto L_82B51E;
    case 0x82B51Fu: goto L_82B51F;
    case 0x82B522u: goto L_82B522;
    case 0x82B524u: goto L_82B524;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B508:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB508u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB508u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB508u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B508 INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_82B50A;
L_82B50A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB50Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Au,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B50A STX
    hw.write(cpu.address("dp", 0x10u), cpu.x, cpu.x8?8:16);
    goto L_82B50C;
L_82B50C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB50Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Cu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B50C STY
    hw.write(cpu.address("dp", 0x12u), cpu.y, cpu.x8?8:16);
    goto L_82B50E;
L_82B50E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB50Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Eu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Eu, 4u + 1u, 3u, cpu.address("absy", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B50E LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x20Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B511;
L_82B511:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB511u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB511u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB511u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B511 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82B513;
L_82B513:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB513u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB513u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB513u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B513 CLC
    cpu.setFlag('C', false);
    goto L_82B514;
L_82B514:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB514u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB514u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB514u, 4u + 1u, 3u, cpu.address("absx", 0x0276u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B514 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x276u), cpu.m8?8:16));
    goto L_82B517;
L_82B517:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB517u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB517u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB517u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B517 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82B519;
L_82B519:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB519u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB519u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB519u, 4u + 1u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B519 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x20Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B51C;
L_82B51C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB51Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB51Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB51Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B51C STA
    hw.write(cpu.address("dp", 0xBu), cpu.a, cpu.m8?8:16);
    goto L_82B51E;
L_82B51E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB51Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB51Eu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB51Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B51E CLC
    cpu.setFlag('C', false);
    goto L_82B51F;
L_82B51F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB51Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB51Fu,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB51Fu, 4u + 1u, 3u, cpu.address("absx", 0x027Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B51F ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x27Eu), cpu.m8?8:16));
    goto L_82B522;
L_82B522:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB522u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB522u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB522u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B522 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_82B524;
L_82B524:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB524u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB524u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB524u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B524 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B524u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B524u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B95B_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B95Bu: goto L_82B95B;
    case 0x82B95Eu: goto L_82B95E;
    case 0x82B960u: goto L_82B960;
    case 0x82B963u: goto L_82B963;
    case 0x82B965u: goto L_82B965;
    case 0x82B968u: goto L_82B968;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B95B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB95Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Bu, 6u, 3u, cpu.address("abs", 0xB98Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B95B JSR -> $82B98E stack real
    { cpu.push16Value(hw,0xB95Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB95Eu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB98Eu), 0x82B95Bu); }
    goto L_82B95E;
L_82B95E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB95Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB95Eu,0x82B95Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Eu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B95E LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B960;
L_82B960:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB960u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB960u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB960u, 6u, 3u, cpu.address("abs", 0xB998u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B960 JSR -> $82B998 stack real
    { cpu.push16Value(hw,0xB962u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB963u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB998u), 0x82B960u); }
    goto L_82B963;
L_82B963:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB963u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB963u,0x82B963u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB963u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB963u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B963 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B965;
L_82B965:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB965u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB965u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB965u, 6u, 3u, cpu.address("abs", 0xB9A2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B965 JSR -> $82B9A2 stack real
    { cpu.push16Value(hw,0xB967u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB968u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB9A2u), 0x82B965u); }
    goto L_82B968;
L_82B968:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB968u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB968u,0x82B968u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB968u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB968u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B968 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B968u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B968u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82BAD1_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82BAD1u: goto L_82BAD1;
    case 0x82BAD4u: goto L_82BAD4;
    case 0x82BAD6u: goto L_82BAD6;
    case 0x82BAD9u: goto L_82BAD9;
    case 0x82BADBu: goto L_82BADB;
    case 0x82BADEu: goto L_82BADE;
    case 0x82BAE1u: goto L_82BAE1;
    case 0x82BAE3u: goto L_82BAE3;
    case 0x82BAE6u: goto L_82BAE6;
    case 0x82BAE7u: goto L_82BAE7;
    case 0x82BAEAu: goto L_82BAEA;
    case 0x82BAEDu: goto L_82BAED;
    case 0x82BAF0u: goto L_82BAF0;
    case 0x82BAF3u: goto L_82BAF3;
    case 0x82BAF6u: goto L_82BAF6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82BAD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAD1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAD1u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BAD1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BAD4;
L_82BAD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAD4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAD4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BAD4 BNE -> $82BAF6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82BAF6; }
    goto L_82BAD6;
L_82BAD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAD6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAD6u, 5u, 3u, cpu.address("abs", 0x02E8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BAD6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2E8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BAD9;
L_82BAD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAD9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAD9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BAD9 BNE -> $82BAF6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82BAF6; }
    goto L_82BADB;
L_82BADB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBADBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBADBu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBADBu, 5u, 3u, cpu.address("abs", 0x0158u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BADB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x158u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BADE;
L_82BADE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBADEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBADEu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBADEu, 5u, 3u, cpu.address("abs", 0x0156u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BADE ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x156u), cpu.m8?8:16));
    goto L_82BAE1;
L_82BAE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAE1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAE1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BAE1 BEQ -> $82BAF6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82BAF6; }
    goto L_82BAE3;
L_82BAE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAE3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAE3u, 5u, 3u, cpu.address("abs", 0x0156u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BAE3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x156u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BAE6;
L_82BAE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAE6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAE6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BAE6 SEC
    cpu.setFlag('C', true);
    goto L_82BAE7;
L_82BAE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAE7u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAE7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BAE7 SBC
    cpu.sbc(0x3E8u);
    goto L_82BAEA;
L_82BAEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAEAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAEAu, 5u, 3u, cpu.address("abs", 0x0156u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BAEA STA
    hw.write(cpu.address("abs", 0x156u), cpu.a, cpu.m8?8:16);
    goto L_82BAED;
L_82BAED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAEDu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAEDu, 5u, 3u, cpu.address("abs", 0x0158u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BAED LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x158u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BAF0;
L_82BAF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAF0u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAF0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BAF0 SBC
    cpu.sbc(0x0u);
    goto L_82BAF3;
L_82BAF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAF3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAF3u, 5u, 3u, cpu.address("abs", 0x0158u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BAF3 STA
    hw.write(cpu.address("abs", 0x158u), cpu.a, cpu.m8?8:16);
    goto L_82BAF6;
L_82BAF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAF6u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAF6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAF6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82BAF6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82BAF6u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82BAF6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAF6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAF6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82BAF6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82BAF6u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82BAF6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBAF6u,0x82BAF6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82C0B2_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82C0B2u: goto L_82C0B2;
    case 0x82C0B5u: goto L_82C0B5;
    case 0x82C0B8u: goto L_82C0B8;
    case 0x82C0BBu: goto L_82C0BB;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82C0B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0B2u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0B2u, 5u, 3u, cpu.address("abs", 0x013Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C0B2 STZ
    hw.write(cpu.address("abs", 0x13Fu), 0, cpu.m8?8:16);
    goto L_82C0B5;
L_82C0B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0B5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0B5u, 6u, 3u, cpu.address("abs", 0xAB61u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C0B5 JSR -> $82AB61 stack real
    { cpu.push16Value(hw,0xC0B7u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC0B8u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAB61u), 0x82C0B5u); }
    goto L_82C0B8;
L_82C0B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0B8u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC0B8u,0x82C0B8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0B8u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0B8u, 8u, 3u, cpu.address("abs", 0x013Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C0B8 INC
    cpu.incMem(hw, cpu.address("abs", 0x13Bu), cpu.m8?8:16);
    goto L_82C0BB;
L_82C0BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0BBu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0BBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C0BB RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C0BBu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C0BBu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82C0E3_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82C0E3u: goto L_82C0E3;
    case 0x82C0E6u: goto L_82C0E6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82C0E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0E3u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0E3u, 5u, 3u, cpu.address("abs", 0x013Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C0E3 STZ
    hw.write(cpu.address("abs", 0x13Bu), 0, cpu.m8?8:16);
    goto L_82C0E6;
L_82C0E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0E6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0E6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C0E6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C0E6u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C0E6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82CAA5_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82CAA5u: goto L_82CAA5;
    case 0x82CAA8u: goto L_82CAA8;
    case 0x82CAABu: goto L_82CAAB;
    case 0x82CAADu: goto L_82CAAD;
    case 0x82CAB0u: goto L_82CAB0;
    case 0x82CAB2u: goto L_82CAB2;
    case 0x82CAB5u: goto L_82CAB5;
    case 0x82CAB9u: goto L_82CAB9;
    case 0x82CABBu: goto L_82CABB;
    case 0x82CABEu: goto L_82CABE;
    case 0x82CAC0u: goto L_82CAC0;
    case 0x82CAC3u: goto L_82CAC3;
    case 0x82CAC5u: goto L_82CAC5;
    case 0x82CAC8u: goto L_82CAC8;
    case 0x82CACAu: goto L_82CACA;
    case 0x82CACEu: goto L_82CACE;
    case 0x82CAD1u: goto L_82CAD1;
    case 0x82CAD4u: goto L_82CAD4;
    case 0x82CAD6u: goto L_82CAD6;
    case 0x82CAD9u: goto L_82CAD9;
    case 0x82CADBu: goto L_82CADB;
    case 0x82CADEu: goto L_82CADE;
    case 0x82CAE2u: goto L_82CAE2;
    case 0x82CAE4u: goto L_82CAE4;
    case 0x82CAE7u: goto L_82CAE7;
    case 0x82CAE9u: goto L_82CAE9;
    case 0x82CAEDu: goto L_82CAED;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82CAA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA5u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA5u, 5u, 3u, cpu.address("abs", 0x02EAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAA5 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2EAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CAA8;
L_82CAA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA8u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA8u, 5u, 3u, cpu.address("abs", 0x03E8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAA8 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x3E8u), cpu.m8?8:16));
    goto L_82CAAB;
L_82CAAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAABu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAAB BEQ -> $82CAB2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CAB2; }
    goto L_82CAAD;
L_82CAAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAADu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAADu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAAD LDX
    cpu.setX(0x36u, 16);
    goto L_82CAB0;
L_82CAB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB0u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAB0 BRA -> $82CAB5
    goto L_82CAB5;
L_82CAB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB2u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAB2 LDX
    cpu.setX(0x34u, 16);
    goto L_82CAB5;
L_82CAB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB5u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB5u, 6u, 4u, ((0x9E8232u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAB5 LDA
    cpu.loadA(hw.readW(((0x9E8232u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CAB9;
L_82CAB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAB9 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82CABB;
L_82CABB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCABBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCABBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCABBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CABB LDA
    cpu.setA(0x9Eu, 16);
    goto L_82CABE;
L_82CABE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCABEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCABEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCABEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CABE STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82CAC0;
L_82CAC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAC0 LDA
    cpu.setA(0x58u, 16);
    goto L_82CAC3;
L_82CAC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAC3 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82CAC5;
L_82CAC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAC5 LDA
    cpu.setA(0x38u, 16);
    goto L_82CAC8;
L_82CAC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAC8 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82CACA;
L_82CACA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCACAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCACAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCACAu, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82CACA JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCACDu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCACEu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x82CACAu); }
    goto L_82CACE;
L_82CACE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCACEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCACEu,0x82CACEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCACEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCACEu, 5u, 3u, cpu.address("abs", 0x03EAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CACE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x3EAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CAD1;
L_82CAD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD1u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD1u, 5u, 3u, cpu.address("abs", 0x02E8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAD1 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x2E8u), cpu.m8?8:16));
    goto L_82CAD4;
L_82CAD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAD4 BEQ -> $82CADB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CADB; }
    goto L_82CAD6;
L_82CAD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD6u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAD6 LDX
    cpu.setX(0x36u, 16);
    goto L_82CAD9;
L_82CAD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD9u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAD9 BRA -> $82CADE
    goto L_82CADE;
L_82CADB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCADBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCADBu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCADBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CADB LDX
    cpu.setX(0x34u, 16);
    goto L_82CADE;
L_82CADE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCADEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCADEu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCADEu, 6u, 4u, ((0x9E8232u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CADE LDA
    cpu.loadA(hw.readW(((0x9E8232u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CAE2;
L_82CAE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAE2 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82CAE4;
L_82CAE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAE4 LDA
    cpu.setA(0xC8u, 16);
    goto L_82CAE7;
L_82CAE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAE7 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82CAE9;
L_82CAE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE9u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE9u, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82CAE9 JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCAECu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCAEDu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x82CAE9u); }
    goto L_82CAED;
L_82CAED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAEDu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCAEDu,0x82CAEDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAEDu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAEDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CAED RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82CAEDu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82CAEDu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82CAA5_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82CAA5u: goto L_82CAA5;
    case 0x82CAA8u: goto L_82CAA8;
    case 0x82CAABu: goto L_82CAAB;
    case 0x82CAADu: goto L_82CAAD;
    case 0x82CAB0u: goto L_82CAB0;
    case 0x82CAB2u: goto L_82CAB2;
    case 0x82CAB5u: goto L_82CAB5;
    case 0x82CAB9u: goto L_82CAB9;
    case 0x82CABBu: goto L_82CABB;
    case 0x82CABEu: goto L_82CABE;
    case 0x82CAC0u: goto L_82CAC0;
    case 0x82CAC3u: goto L_82CAC3;
    case 0x82CAC5u: goto L_82CAC5;
    case 0x82CAC8u: goto L_82CAC8;
    case 0x82CACAu: goto L_82CACA;
    case 0x82CACEu: goto L_82CACE;
    case 0x82CAD1u: goto L_82CAD1;
    case 0x82CAD4u: goto L_82CAD4;
    case 0x82CAD6u: goto L_82CAD6;
    case 0x82CAD9u: goto L_82CAD9;
    case 0x82CADBu: goto L_82CADB;
    case 0x82CADEu: goto L_82CADE;
    case 0x82CAE2u: goto L_82CAE2;
    case 0x82CAE4u: goto L_82CAE4;
    case 0x82CAE7u: goto L_82CAE7;
    case 0x82CAE9u: goto L_82CAE9;
    case 0x82CAEDu: goto L_82CAED;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82CAA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA5u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA5u, 5u, 3u, cpu.address("abs", 0x02EAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAA5 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2EAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CAA8;
L_82CAA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA8u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA8u, 5u, 3u, cpu.address("abs", 0x03E8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAA8 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x3E8u), cpu.m8?8:16));
    goto L_82CAAB;
L_82CAAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAABu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAAB BEQ -> $82CAB2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CAB2; }
    goto L_82CAAD;
L_82CAAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAADu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAADu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAAD LDX
    cpu.setX(0x36u, 16);
    goto L_82CAB0;
L_82CAB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB0u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAB0 BRA -> $82CAB5
    goto L_82CAB5;
L_82CAB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB2u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAB2 LDX
    cpu.setX(0x34u, 16);
    goto L_82CAB5;
L_82CAB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB5u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB5u, 6u, 4u, ((0x9E8232u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAB5 LDA
    cpu.loadA(hw.readW(((0x9E8232u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CAB9;
L_82CAB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAB9 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82CABB;
L_82CABB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCABBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCABBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCABBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CABB LDA
    cpu.setA(0x9Eu, 16);
    goto L_82CABE;
L_82CABE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCABEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCABEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCABEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CABE STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82CAC0;
L_82CAC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAC0 LDA
    cpu.setA(0x58u, 16);
    goto L_82CAC3;
L_82CAC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAC3 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82CAC5;
L_82CAC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAC5 LDA
    cpu.setA(0x38u, 16);
    goto L_82CAC8;
L_82CAC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAC8 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82CACA;
L_82CACA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCACAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCACAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCACAu, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82CACA JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCACDu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCACEu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x82CACAu); }
    goto L_82CACE;
L_82CACE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCACEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCACEu,0x82CACEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCACEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCACEu, 5u, 3u, cpu.address("abs", 0x03EAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CACE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x3EAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CAD1;
L_82CAD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD1u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD1u, 5u, 3u, cpu.address("abs", 0x02E8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAD1 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x2E8u), cpu.m8?8:16));
    goto L_82CAD4;
L_82CAD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAD4 BEQ -> $82CADB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CADB; }
    goto L_82CAD6;
L_82CAD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD6u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAD6 LDX
    cpu.setX(0x36u, 16);
    goto L_82CAD9;
L_82CAD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD9u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAD9 BRA -> $82CADE
    goto L_82CADE;
L_82CADB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCADBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCADBu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCADBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CADB LDX
    cpu.setX(0x34u, 16);
    goto L_82CADE;
L_82CADE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCADEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCADEu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCADEu, 6u, 4u, ((0x9E8232u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CADE LDA
    cpu.loadA(hw.readW(((0x9E8232u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CAE2;
L_82CAE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAE2 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82CAE4;
L_82CAE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAE4 LDA
    cpu.setA(0xC8u, 16);
    goto L_82CAE7;
L_82CAE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CAE7 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82CAE9;
L_82CAE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE9u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE9u, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82CAE9 JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCAECu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCAEDu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x82CAE9u); }
    goto L_82CAED;
L_82CAED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAEDu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCAEDu,0x82CAEDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAEDu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAEDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CAED RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82CAEDu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82CAEDu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82CBDA_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82CBDAu: goto L_82CBDA;
    case 0x82CBDDu: goto L_82CBDD;
    case 0x82CBE0u: goto L_82CBE0;
    case 0x82CBE2u: goto L_82CBE2;
    case 0x82CBE5u: goto L_82CBE5;
    case 0x82CBE7u: goto L_82CBE7;
    case 0x82CBEAu: goto L_82CBEA;
    case 0x82CBECu: goto L_82CBEC;
    case 0x82CBEEu: goto L_82CBEE;
    case 0x82CBF0u: goto L_82CBF0;
    case 0x82CBF3u: goto L_82CBF3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82CBDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBDAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBDAu, 6u, 3u, cpu.address("abs", 0xCC1Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CBDA JSR -> $82CC1A stack real
    { cpu.push16Value(hw,0xCBDCu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCBDDu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCC1Au), 0x82CBDAu); }
    goto L_82CBDD;
L_82CBDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBDDu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCBDDu,0x82CBDDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBDDu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBDDu, 5u, 3u, cpu.address("abs", 0x018Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CBDD LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CBE0;
L_82CBE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBE0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBE0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CBE0 BEQ -> $82CBE7
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CBE7; }
    goto L_82CBE2;
L_82CBE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBE2u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBE2u, 8u, 3u, cpu.address("abs", 0x018Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CBE2 DEC
    cpu.decMem(hw, cpu.address("abs", 0x18Bu), cpu.m8?8:16);
    goto L_82CBE5;
L_82CBE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBE5u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBE5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CBE5 BRA -> $82CBF3
    goto L_82CBF3;
L_82CBE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBE7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBE7u, 5u, 3u, cpu.address("abs", 0x0193u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CBE7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x193u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CBEA;
L_82CBEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBEAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBEAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CBEA BNE -> $82CBF0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CBF0; }
    goto L_82CBEC;
L_82CBEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBECu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBECu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CBEC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CBEE;
L_82CBEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBEEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBEEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CBEE BEQ -> $82CBF3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CBF3; }
    goto L_82CBF0;
L_82CBF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBF0u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBF0u, 8u, 3u, cpu.address("abs", 0x0141u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CBF0 INC
    cpu.incMem(hw, cpu.address("abs", 0x141u), cpu.m8?8:16);
    goto L_82CBF3;
L_82CBF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBF3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBF3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CBF3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82CBF3u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82CBF3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82CC0B_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82CC0Bu: goto L_82CC0B;
    case 0x82CC0Du: goto L_82CC0D;
    case 0x82CC0Fu: goto L_82CC0F;
    case 0x82CC11u: goto L_82CC11;
    case 0x82CC14u: goto L_82CC14;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82CC0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC0Bu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC0Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CC0B SEP
    cpu.sep(0x20u);
    goto L_82CC0D;
L_82CC0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC0Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC0Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x78u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CC0D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x78u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CC0F;
L_82CC0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC0Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC0Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CC0F BNE -> $82CC14
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CC14; }
    goto L_82CC11;
L_82CC11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC11u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC11u, 6u, 3u, cpu.address("abs", 0x0141u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CC11 INC
    cpu.incMem(hw, cpu.address("abs", 0x141u), cpu.m8?8:16);
    goto L_82CC14;
L_82CC14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCC14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCC14u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCC14u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CC14 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82CC14u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82CC14u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82D4F1_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82D4F1u: goto L_82D4F1;
    case 0x82D4F4u: goto L_82D4F4;
    case 0x82D4F6u: goto L_82D4F6;
    case 0x82D4F8u: goto L_82D4F8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82D4F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4F1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4F1u, 6u, 3u, cpu.address("abs", 0xD549u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D4F1 JSR -> $82D549 stack real
    { cpu.push16Value(hw,0xD4F3u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD4F4u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD549u), 0x82D4F1u); }
    goto L_82D4F4;
L_82D4F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4F4u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4F4u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4F4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4F4 SEP
    cpu.sep(0x20u);
    goto L_82D4F6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4F4u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4F4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4F4 SEP
    cpu.sep(0x20u);
    goto L_82D4F6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD4F4u,0x82D4F4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82D4F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4F6u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4F6u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4F6u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4F6 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_82D4F8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4F6u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4F6u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4F6 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_82D4F8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD4F6u,0x82D4F6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82D4F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4F8u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4F8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4F8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D4F8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D4F8u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D4F8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4F8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4F8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D4F8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D4F8u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D4F8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD4F8u,0x82D4F8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82D7C1_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82D7C1u: goto L_82D7C1;
    case 0x82D7C3u: goto L_82D7C3;
    case 0x82D7C6u: goto L_82D7C6;
    case 0x82D7C8u: goto L_82D7C8;
    case 0x82D7CBu: goto L_82D7CB;
    case 0x82D7CCu: goto L_82D7CC;
    case 0x82D7CDu: goto L_82D7CD;
    case 0x82D7D1u: goto L_82D7D1;
    case 0x82D7D3u: goto L_82D7D3;
    case 0x82D7D6u: goto L_82D7D6;
    case 0x82D7D7u: goto L_82D7D7;
    case 0x82D7D8u: goto L_82D7D8;
    case 0x82D7DCu: goto L_82D7DC;
    case 0x82D7DDu: goto L_82D7DD;
    case 0x82D7DFu: goto L_82D7DF;
    case 0x82D7E1u: goto L_82D7E1;
    case 0x82D7E4u: goto L_82D7E4;
    case 0x82D7E6u: goto L_82D7E6;
    case 0x82D7E9u: goto L_82D7E9;
    case 0x82D7ECu: goto L_82D7EC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82D7C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C1u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D7C1 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82D7C3;
L_82D7C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C3u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C3u, 5u + 1u, 3u, cpu.address("absx", 0x0402u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D7C3 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x402u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D7C6;
L_82D7C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C6u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D7C6 BPL -> $82D7D3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82D7D3; }
    goto L_82D7C8;
L_82D7C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7C8u, 5u + 1u, 3u, cpu.address("absx", 0x0404u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D7C8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x404u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D7CB;
L_82D7CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D7CB ASL
    cpu.aslA();
    goto L_82D7CC;
L_82D7CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CCu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D7CC TAX
    cpu.transfer("TAX");
    goto L_82D7CD;
L_82D7CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CDu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7CDu, 6u, 4u, ((0x82D7EDu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D7CD LDA
    cpu.loadA(hw.readW(((0x82D7EDu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D7D1;
L_82D7D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D1u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D7D1 BRA -> $82D7DC
    goto L_82D7DC;
L_82D7D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D3u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D3u, 5u + 1u, 3u, cpu.address("absx", 0x0404u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D7D3 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x404u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D7D6;
L_82D7D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D7D6 ASL
    cpu.aslA();
    goto L_82D7D7;
L_82D7D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D7u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D7D7 TAX
    cpu.transfer("TAX");
    goto L_82D7D8;
L_82D7D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D8u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7D8u, 6u, 4u, ((0x82D7F5u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D7D8 LDA
    cpu.loadA(hw.readW(((0x82D7F5u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D7DC;
L_82D7DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7DCu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7DCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D7DC TAX
    cpu.transfer("TAX");
    goto L_82D7DD;
L_82D7DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7DDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7DDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D7DD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D7DF;
L_82D7DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7DFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7DFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D7DF BNE -> $82D7E6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D7E6; }
    goto L_82D7E1;
L_82D7E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E1u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D7E1 LDY
    cpu.setY(0x4080u, 16);
    goto L_82D7E4;
L_82D7E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E4u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D7E4 BRA -> $82D7E9
    goto L_82D7E9;
L_82D7E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E6u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D7E6 LDY
    cpu.setY(0x4180u, 16);
    goto L_82D7E9;
L_82D7E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7E9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D7E9 LDA
    cpu.setA(0x140u, 16);
    goto L_82D7EC;
L_82D7EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD7ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD7ECu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD7ECu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D7EC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D7ECu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D7ECu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82E04E_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82E04Eu: goto L_82E04E;
    case 0x82E050u: goto L_82E050;
    case 0x82E051u: goto L_82E051;
    case 0x82E053u: goto L_82E053;
    case 0x82E054u: goto L_82E054;
    case 0x82E055u: goto L_82E055;
    case 0x82E057u: goto L_82E057;
    case 0x82E059u: goto L_82E059;
    case 0x82E05Bu: goto L_82E05B;
    case 0x82E05Du: goto L_82E05D;
    case 0x82E060u: goto L_82E060;
    case 0x82E062u: goto L_82E062;
    case 0x82E065u: goto L_82E065;
    case 0x82E067u: goto L_82E067;
    case 0x82E06Au: goto L_82E06A;
    case 0x82E06Cu: goto L_82E06C;
    case 0x82E06Fu: goto L_82E06F;
    case 0x82E072u: goto L_82E072;
    case 0x82E074u: goto L_82E074;
    case 0x82E077u: goto L_82E077;
    case 0x82E079u: goto L_82E079;
    case 0x82E07Cu: goto L_82E07C;
    case 0x82E07Eu: goto L_82E07E;
    case 0x82E080u: goto L_82E080;
    case 0x82E083u: goto L_82E083;
    case 0x82E086u: goto L_82E086;
    case 0x82E089u: goto L_82E089;
    case 0x82E08Cu: goto L_82E08C;
    case 0x82E08Fu: goto L_82E08F;
    case 0x82E092u: goto L_82E092;
    case 0x82E094u: goto L_82E094;
    case 0x82E095u: goto L_82E095;
    case 0x82E096u: goto L_82E096;
    case 0x82E098u: goto L_82E098;
    case 0x82E099u: goto L_82E099;
    case 0x82E09Au: goto L_82E09A;
    case 0x82E09Bu: goto L_82E09B;
    case 0x82E09Du: goto L_82E09D;
    case 0x82E0A0u: goto L_82E0A0;
    case 0x82E0A1u: goto L_82E0A1;
    case 0x82E0A4u: goto L_82E0A4;
    case 0x82E0A6u: goto L_82E0A6;
    case 0x82E0A7u: goto L_82E0A7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82E04E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE04Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE04Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE04Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E04E SEP
    cpu.sep(0x20u);
    goto L_82E050;
L_82E050:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE050u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE050u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE050u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82E050 PHB
    cpu.push("PHB", hw);
    goto L_82E051;
L_82E051:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE051u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE051u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE051u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x69u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E051 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x69u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E053;
L_82E053:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE053u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE053u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE053u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82E053 PHA
    cpu.push("PHA", hw);
    goto L_82E054;
L_82E054:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE054u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE054u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE054u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82E054 PLB
    cpu.pop("PLB", hw);
    goto L_82E055;
L_82E055:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE055u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE055u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE055u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E055 REP
    cpu.rep(0x20u);
    goto L_82E057;
L_82E057:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE057u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE057u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE057u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E057 STZ
    hw.write(cpu.address("dp", 0xCu), 0, cpu.m8?8:16);
    goto L_82E059;
L_82E059:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE059u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE059u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE059u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E059 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82E05B;
L_82E05B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE05Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE05Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE05Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E05B BNE -> $82E062
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E062; }
    goto L_82E05D;
L_82E05D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE05Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE05Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE05Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E05D LDA
    cpu.setA(0x7000u, 16);
    goto L_82E060;
L_82E060:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE060u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE060u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE060u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E060 BRA -> $82E065
    goto L_82E065;
L_82E062:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE062u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE062u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE062u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E062 LDA
    cpu.setA(0x7200u, 16);
    goto L_82E065;
L_82E065:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE065u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE065u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE065u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E065 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82E067;
L_82E067:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE067u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE067u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE067u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E067 LDA
    cpu.setA(0x7Eu, 16);
    goto L_82E06A;
L_82E06A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE06Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E06A STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82E06C;
L_82E06C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE06Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Cu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E06C LDY
    cpu.setY(0x1F8u, 16);
    goto L_82E06F;
L_82E06F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE06Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Fu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE06Fu, 6u, 3u, cpu.address("absx", 0x02FEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E06F STZ
    hw.write(cpu.address("absx", 0x2FEu), 0, cpu.m8?8:16);
    goto L_82E072;
L_82E072:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE072u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE072u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE072u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82E072 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E074;
L_82E074:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE074u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE074u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE074u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E074 CMP
    cpu.compareA(0xFFFFu);
    goto L_82E077;
L_82E077:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE077u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE077u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE077u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E077 BEQ -> $82E099
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E099; }
    goto L_82E079;
L_82E079:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE079u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE079u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE079u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E079 BIT
    cpu.bit(0x8000u, true);
    goto L_82E07C;
L_82E07C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE07Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE07Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE07Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E07C BEQ -> $82E099
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E099; }
    goto L_82E07E;
L_82E07E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE07Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE07Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE07Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E07E STZ
    hw.write(cpu.address("dp", 0x10u), 0, cpu.m8?8:16);
    goto L_82E080;
L_82E080:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE080u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE080u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE080u, 6u, 3u, cpu.address("abs", 0xE0A8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E080 JSR -> $82E0A8 stack real
    { cpu.push16Value(hw,0xE082u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE083u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE0A8u), 0x82E080u); }
    goto L_82E083;
L_82E083:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE083u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE083u,0x82E083u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE083u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE083u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E083 LDA
    cpu.setA(0x2u, 16);
    goto L_82E086;
L_82E086:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE086u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE086u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE086u, 5u, 3u, cpu.address("abs", 0x000Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E086 STA
    hw.write(cpu.address("abs", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_82E089;
L_82E089:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE089u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE089u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE089u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E089 LDA
    cpu.setA(0x1u, 16);
    goto L_82E08C;
L_82E08C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE08Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE08Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE08Cu, 6u, 3u, cpu.address("absx", 0x02FCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E08C STA
    hw.write(cpu.address("absx", 0x2FCu), cpu.a, cpu.m8?8:16);
    goto L_82E08F;
L_82E08F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE08Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE08Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE08Fu, 6u, 3u, cpu.address("abs", 0xDFEFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E08F JSR -> $82DFEF stack real
    { cpu.push16Value(hw,0xE091u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE092u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xDFEFu), 0x82E08Fu); }
    goto L_82E092;
L_82E092:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE092u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE092u,0x82E092u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE092u,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE092u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E092 ASL
    cpu.aslMem(hw, cpu.address("dp", 0x10u), cpu.m8?8:16);
    goto L_82E094;
L_82E094:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE094u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE094u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE094u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E094 TYA
    cpu.transfer("TYA");
    goto L_82E095;
L_82E095:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE095u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE095u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE095u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E095 SEC
    cpu.setFlag('C', true);
    goto L_82E096;
L_82E096:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE096u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE096u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE096u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E096 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_82E098;
L_82E098:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE098u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE098u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE098u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E098 TAY
    cpu.transfer("TAY");
    goto L_82E099;
L_82E099:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE099u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE099u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE099u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E099 DEY
    cpu.decReg('Y');
    goto L_82E09A;
L_82E09A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE09Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE09Au,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE09Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E09A DEY
    cpu.decReg('Y');
    goto L_82E09B;
L_82E09B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE09Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE09Bu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE09Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E09B BPL -> $82E072
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82E072; }
    goto L_82E09D;
L_82E09D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE09Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE09Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE09Du, 5u + 1u, 3u, cpu.address("absx", 0x02FEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E09D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2FEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E0A0;
L_82E0A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0A0u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0A0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0A0 TAY
    cpu.transfer("TAY");
    goto L_82E0A1;
L_82E0A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0A1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0A1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0A1 LDA
    cpu.setA(0xFFFFu, 16);
    goto L_82E0A4;
L_82E0A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0A4u,cpu,0x91u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0A4u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82E0A4 STA
    hw.write(cpu.addressDpIndirectY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82E0A6;
L_82E0A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0A6u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0A6u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82E0A6 PLB
    cpu.pop("PLB", hw);
    goto L_82E0A7;
L_82E0A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0A7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0A7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E0A7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82E0A7u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82E0A7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84874A_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84874Au: goto L_84874A;
    case 0x84874Cu: goto L_84874C;
    case 0x84874Fu: goto L_84874F;
    case 0x848752u: goto L_848752;
    case 0x848755u: goto L_848755;
    case 0x848757u: goto L_848757;
    case 0x84875Au: goto L_84875A;
    case 0x84875Cu: goto L_84875C;
    case 0x84875Fu: goto L_84875F;
    case 0x848761u: goto L_848761;
    case 0x848765u: goto L_848765;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84874A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x874Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x874Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x874Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84874A REP
    cpu.rep(0x20u);
    goto L_84874C;
L_84874C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x874Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x874Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x874Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84874C LDX
    cpu.setX(0x2u, 16);
    goto L_84874F;
L_84874F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x874Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x874Fu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x874Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84874F LDY
    cpu.setY(0x6u, 16);
    goto L_848752;
L_848752:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8752u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8752u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8752u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848752 LDA
    cpu.setA(0x2A86u, 16);
    goto L_848755;
L_848755:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8755u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8755u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8755u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848755 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_848757;
L_848757:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8757u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8757u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8757u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848757 LDA
    cpu.setA(0x7Eu, 16);
    goto L_84875A;
L_84875A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x875Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x875Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x875Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84875A STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_84875C;
L_84875C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x875Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x875Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x875Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84875C LDA
    cpu.setA(0x1C00u, 16);
    goto L_84875F;
L_84875F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x875Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x875Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x875Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84875F STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_848761;
L_848761:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8761u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8761u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8761u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848761 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8764u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8765u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x848761u); }
    goto L_848765;
L_848765:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8765u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8765u,0x848765u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8765u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8765u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848765 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848765u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848765u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_848A16_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848A16u: goto L_848A16;
    case 0x848A18u: goto L_848A18;
    case 0x848A1Bu: goto L_848A1B;
    case 0x848A1Du: goto L_848A1D;
    case 0x848A1Fu: goto L_848A1F;
    case 0x848A21u: goto L_848A21;
    case 0x848A24u: goto L_848A24;
    case 0x848A27u: goto L_848A27;
    case 0x848A2Au: goto L_848A2A;
    case 0x848A2Cu: goto L_848A2C;
    case 0x848A2Fu: goto L_848A2F;
    case 0x848A31u: goto L_848A31;
    case 0x848A34u: goto L_848A34;
    case 0x848A36u: goto L_848A36;
    case 0x848A3Au: goto L_848A3A;
    case 0x848A3Bu: goto L_848A3B;
    case 0x848A3Du: goto L_848A3D;
    case 0x848A40u: goto L_848A40;
    case 0x848A43u: goto L_848A43;
    case 0x848A46u: goto L_848A46;
    case 0x848A48u: goto L_848A48;
    case 0x848A4Bu: goto L_848A4B;
    case 0x848A4Du: goto L_848A4D;
    case 0x848A50u: goto L_848A50;
    case 0x848A52u: goto L_848A52;
    case 0x848A56u: goto L_848A56;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848A16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A16u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A16u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A16 SEP
    cpu.sep(0x20u);
    goto L_848A18;
L_848A18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A18u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A18u, 4u, 3u, cpu.address("abs", 0x062Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A18 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848A1B;
L_848A1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Bu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A1B BIT
    cpu.bit(0x1u, true);
    goto L_848A1D;
L_848A1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A1D BNE -> $848A3B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848A3B; }
    goto L_848A1F;
L_848A1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A1F REP
    cpu.rep(0x20u);
    goto L_848A21;
L_848A21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A21u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A21u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A21 LDX
    cpu.setX(0x2u, 16);
    goto L_848A24;
L_848A24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A24u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A24u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A24 LDY
    cpu.setY(0x6u, 16);
    goto L_848A27;
L_848A27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A27u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A27u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A27 LDA
    cpu.setA(0x2A9Au, 16);
    goto L_848A2A;
L_848A2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A2A STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_848A2C;
L_848A2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A2C LDA
    cpu.setA(0x7Eu, 16);
    goto L_848A2F;
L_848A2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A2F STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_848A31;
L_848A31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A31u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A31u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A31 LDA
    cpu.setA(0x1800u, 16);
    goto L_848A34;
L_848A34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A34u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A34u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A34 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_848A36;
L_848A36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A36u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A36u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848A36 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8A39u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8A3Au,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x848A36u); }
    goto L_848A3A;
L_848A3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A3Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A3Au,0x848A3Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848A3A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848A3Au);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848A3Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_848A3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A3B REP
    cpu.rep(0x20u);
    goto L_848A3D;
L_848A3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A3D LDX
    cpu.setX(0x2u, 16);
    goto L_848A40;
L_848A40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A40u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A40u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A40 LDY
    cpu.setY(0x8u, 16);
    goto L_848A43;
L_848A43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A43u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A43u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A43 LDA
    cpu.setA(0x2AAAu, 16);
    goto L_848A46;
L_848A46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A46u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A46u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A46 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_848A48;
L_848A48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A48u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A48u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A48 LDA
    cpu.setA(0x7Eu, 16);
    goto L_848A4B;
L_848A4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A4Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A4Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A4B STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_848A4D;
L_848A4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A4Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A4Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A4D LDA
    cpu.setA(0x1800u, 16);
    goto L_848A50;
L_848A50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A50u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A50u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A50 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_848A52;
L_848A52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A52u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A52u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848A52 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8A55u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8A56u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x848A52u); }
    goto L_848A56;
L_848A56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A56u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A56u,0x848A56u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A56u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A56u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848A56 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848A56u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848A56u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_848A16_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848A16u: goto L_848A16;
    case 0x848A18u: goto L_848A18;
    case 0x848A1Bu: goto L_848A1B;
    case 0x848A1Du: goto L_848A1D;
    case 0x848A1Fu: goto L_848A1F;
    case 0x848A21u: goto L_848A21;
    case 0x848A24u: goto L_848A24;
    case 0x848A27u: goto L_848A27;
    case 0x848A2Au: goto L_848A2A;
    case 0x848A2Cu: goto L_848A2C;
    case 0x848A2Fu: goto L_848A2F;
    case 0x848A31u: goto L_848A31;
    case 0x848A34u: goto L_848A34;
    case 0x848A36u: goto L_848A36;
    case 0x848A3Au: goto L_848A3A;
    case 0x848A3Bu: goto L_848A3B;
    case 0x848A3Du: goto L_848A3D;
    case 0x848A40u: goto L_848A40;
    case 0x848A43u: goto L_848A43;
    case 0x848A46u: goto L_848A46;
    case 0x848A48u: goto L_848A48;
    case 0x848A4Bu: goto L_848A4B;
    case 0x848A4Du: goto L_848A4D;
    case 0x848A50u: goto L_848A50;
    case 0x848A52u: goto L_848A52;
    case 0x848A56u: goto L_848A56;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848A16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A16u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A16u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A16 SEP
    cpu.sep(0x20u);
    goto L_848A18;
L_848A18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A18u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A18u, 4u, 3u, cpu.address("abs", 0x062Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A18 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848A1B;
L_848A1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Bu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A1B BIT
    cpu.bit(0x1u, true);
    goto L_848A1D;
L_848A1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A1D BNE -> $848A3B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848A3B; }
    goto L_848A1F;
L_848A1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A1Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A1F REP
    cpu.rep(0x20u);
    goto L_848A21;
L_848A21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A21u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A21u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A21 LDX
    cpu.setX(0x2u, 16);
    goto L_848A24;
L_848A24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A24u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A24u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A24 LDY
    cpu.setY(0x6u, 16);
    goto L_848A27;
L_848A27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A27u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A27u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A27 LDA
    cpu.setA(0x2A9Au, 16);
    goto L_848A2A;
L_848A2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A2A STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_848A2C;
L_848A2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A2C LDA
    cpu.setA(0x7Eu, 16);
    goto L_848A2F;
L_848A2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A2Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A2F STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_848A31;
L_848A31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A31u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A31u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A31 LDA
    cpu.setA(0x1800u, 16);
    goto L_848A34;
L_848A34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A34u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A34u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A34 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_848A36;
L_848A36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A36u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A36u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848A36 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8A39u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8A3Au,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x848A36u); }
    goto L_848A3A;
L_848A3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A3Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A3Au,0x848A3Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848A3A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848A3Au);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848A3Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_848A3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A3B REP
    cpu.rep(0x20u);
    goto L_848A3D;
L_848A3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A3D LDX
    cpu.setX(0x2u, 16);
    goto L_848A40;
L_848A40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A40u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A40u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A40 LDY
    cpu.setY(0x8u, 16);
    goto L_848A43;
L_848A43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A43u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A43u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A43 LDA
    cpu.setA(0x2AAAu, 16);
    goto L_848A46;
L_848A46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A46u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A46u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A46 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_848A48;
L_848A48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A48u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A48u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A48 LDA
    cpu.setA(0x7Eu, 16);
    goto L_848A4B;
L_848A4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A4Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A4Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A4B STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_848A4D;
L_848A4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A4Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A4Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A4D LDA
    cpu.setA(0x1800u, 16);
    goto L_848A50;
L_848A50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A50u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A50u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A50 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_848A52;
L_848A52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A52u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A52u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848A52 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8A55u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8A56u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x848A52u); }
    goto L_848A56;
L_848A56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A56u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A56u,0x848A56u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A56u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A56u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848A56 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848A56u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848A56u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_848FEB_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848FEBu: goto L_848FEB;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848FEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEBu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848FEB RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848FEBu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848FEBu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8490E7_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8490E7u: goto L_8490E7;
    case 0x8490E9u: goto L_8490E9;
    case 0x8490ECu: goto L_8490EC;
    case 0x8490EEu: goto L_8490EE;
    case 0x8490F1u: goto L_8490F1;
    case 0x8490F3u: goto L_8490F3;
    case 0x8490F6u: goto L_8490F6;
    case 0x8490F9u: goto L_8490F9;
    case 0x8490FCu: goto L_8490FC;
    case 0x8490FFu: goto L_8490FF;
    case 0x849102u: goto L_849102;
    case 0x849105u: goto L_849105;
    case 0x849108u: goto L_849108;
    case 0x84910Bu: goto L_84910B;
    case 0x84910Eu: goto L_84910E;
    case 0x849110u: goto L_849110;
    case 0x849113u: goto L_849113;
    case 0x849116u: goto L_849116;
    case 0x849119u: goto L_849119;
    case 0x84911Cu: goto L_84911C;
    case 0x84911Fu: goto L_84911F;
    case 0x849121u: goto L_849121;
    case 0x849124u: goto L_849124;
    case 0x849126u: goto L_849126;
    case 0x849129u: goto L_849129;
    case 0x84912Au: goto L_84912A;
    case 0x84912Du: goto L_84912D;
    case 0x84912Eu: goto L_84912E;
    case 0x84912Fu: goto L_84912F;
    case 0x849131u: goto L_849131;
    case 0x849134u: goto L_849134;
    case 0x849136u: goto L_849136;
    case 0x849139u: goto L_849139;
    case 0x84913Au: goto L_84913A;
    case 0x84913Bu: goto L_84913B;
    case 0x84913Eu: goto L_84913E;
    case 0x849141u: goto L_849141;
    case 0x849144u: goto L_849144;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8490E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90E7u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90E7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490E7 REP
    cpu.rep(0x20u);
    goto L_8490E9;
L_8490E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90E9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90E9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490E9 AND
    cpu.logicAnd(0xFFu);
    goto L_8490EC;
L_8490EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90ECu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90ECu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490EC STA
    hw.write(cpu.address("dp", 0x63u), cpu.a, cpu.m8?8:16);
    goto L_8490EE;
L_8490EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90EEu,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90EEu, 8u, 3u, cpu.address("abs", 0x065Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490EE DEC
    cpu.decMem(hw, cpu.address("abs", 0x65Eu), cpu.m8?8:16);
    goto L_8490F1;
L_8490F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90F1u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90F1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490F1 BPL -> $849144
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_849144; }
    goto L_8490F3;
L_8490F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90F3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90F3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490F3 LDA
    cpu.setA(0x7DBAu, 16);
    goto L_8490F6;
L_8490F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90F6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90F6u, 5u, 3u, cpu.address("abs", 0x1904u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490F6 STA
    hw.write(cpu.address("abs", 0x1904u), cpu.a, cpu.m8?8:16);
    goto L_8490F9;
L_8490F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90F9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90F9u, 5u, 3u, cpu.address("abs", 0x1906u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490F9 STA
    hw.write(cpu.address("abs", 0x1906u), cpu.a, cpu.m8?8:16);
    goto L_8490FC;
L_8490FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90FCu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90FCu, 5u, 3u, cpu.address("abs", 0x190Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490FC STA
    hw.write(cpu.address("abs", 0x190Au), cpu.a, cpu.m8?8:16);
    goto L_8490FF;
L_8490FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90FFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90FFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490FF LDA
    cpu.setA(0x4u, 16);
    goto L_849102;
L_849102:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9102u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9102u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9102u, 5u, 3u, cpu.address("abs", 0x065Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849102 STA
    hw.write(cpu.address("abs", 0x65Eu), cpu.a, cpu.m8?8:16);
    goto L_849105;
L_849105:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9105u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9105u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9105u, 8u, 3u, cpu.address("abs", 0x06EBu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849105 INC
    cpu.incMem(hw, cpu.address("abs", 0x6EBu), cpu.m8?8:16);
    goto L_849108;
L_849108:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9108u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9108u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9108u, 5u, 3u, cpu.address("abs", 0x06EBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849108 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6EBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84910B;
L_84910B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x910Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x910Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x910Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84910B CMP
    cpu.compareA(0x4u);
    goto L_84910E;
L_84910E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x910Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x910Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x910Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84910E BCC -> $84911C
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_84911C; }
    goto L_849110;
L_849110:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9110u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9110u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9110u, 5u, 3u, cpu.address("abs", 0x06EDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849110 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6EDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849113;
L_849113:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9113u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9113u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9113u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849113 EOR
    cpu.logicXor(0x1u);
    goto L_849116;
L_849116:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9116u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9116u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9116u, 5u, 3u, cpu.address("abs", 0x06EDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849116 STA
    hw.write(cpu.address("abs", 0x6EDu), cpu.a, cpu.m8?8:16);
    goto L_849119;
L_849119:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9119u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9119u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9119u, 5u, 3u, cpu.address("abs", 0x06EBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849119 STZ
    hw.write(cpu.address("abs", 0x6EBu), 0, cpu.m8?8:16);
    goto L_84911C;
L_84911C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x911Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x911Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x911Cu, 5u, 3u, cpu.address("abs", 0x06EDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84911C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6EDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84911F;
L_84911F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x911Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x911Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x911Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84911F BEQ -> $849126
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_849126; }
    goto L_849121;
L_849121:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9121u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9121u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9121u, 5u, 3u, cpu.address("abs", 0x06EBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849121 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6EBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849124;
L_849124:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9124u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9124u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9124u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849124 BRA -> $84912D
    goto L_84912D;
L_849126:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9126u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9126u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9126u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849126 LDA
    cpu.setA(0x3u, 16);
    goto L_849129;
L_849129:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9129u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9129u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9129u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849129 SEC
    cpu.setFlag('C', true);
    goto L_84912A;
L_84912A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x912Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x912Au,cpu,0xEDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x912Au, 5u, 3u, cpu.address("abs", 0x06EBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84912A SBC
    cpu.sbc(hw.readW(cpu.address("abs", 0x6EBu), cpu.m8?8:16));
    goto L_84912D;
L_84912D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x912Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x912Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x912Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84912D ASL
    cpu.aslA();
    goto L_84912E;
L_84912E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x912Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x912Eu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x912Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84912E TAX
    cpu.transfer("TAX");
    goto L_84912F;
L_84912F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x912Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x912Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x912Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84912F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x63u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849131;
L_849131:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9131u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9131u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9131u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849131 CMP
    cpu.compareA(0x2u);
    goto L_849134;
L_849134:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9134u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9134u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9134u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849134 BCC -> $849139
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_849139; }
    goto L_849136;
L_849136:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9136u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9136u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9136u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849136 LDA
    cpu.setA(0x3u, 16);
    goto L_849139;
L_849139:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9139u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9139u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9139u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849139 ASL
    cpu.aslA();
    goto L_84913A;
L_84913A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x913Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x913Au,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x913Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84913A TAY
    cpu.transfer("TAY");
    goto L_84913B;
L_84913B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x913Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x913Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x913Bu, 5u + 1u, 3u, cpu.address("absx", 0x1918u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84913B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1918u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84913E;
L_84913E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x913Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x913Eu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x913Eu, 6u, 3u, cpu.address("absy", 0x1904u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84913E STA
    hw.write(cpu.address("absy", 0x1904u), cpu.a, cpu.m8?8:16);
    goto L_849141;
L_849141:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9141u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9141u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9141u, 8u, 3u, cpu.address("abs", 0x0122u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849141 INC
    cpu.incMem(hw, cpu.address("abs", 0x122u), cpu.m8?8:16);
    goto L_849144;
L_849144:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9144u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9144u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9144u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849144 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849144u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849144u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84958B_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84958Bu: goto L_84958B;
    case 0x84958Du: goto L_84958D;
    case 0x849590u: goto L_849590;
    case 0x849592u: goto L_849592;
    case 0x849594u: goto L_849594;
    case 0x849597u: goto L_849597;
    case 0x849599u: goto L_849599;
    case 0x84959Cu: goto L_84959C;
    case 0x84959Eu: goto L_84959E;
    case 0x8495A0u: goto L_8495A0;
    case 0x8495A2u: goto L_8495A2;
    case 0x8495A5u: goto L_8495A5;
    case 0x8495A8u: goto L_8495A8;
    case 0x8495ABu: goto L_8495AB;
    case 0x8495AEu: goto L_8495AE;
    case 0x8495B2u: goto L_8495B2;
    case 0x8495B3u: goto L_8495B3;
    case 0x8495B6u: goto L_8495B6;
    case 0x8495B9u: goto L_8495B9;
    case 0x8495BBu: goto L_8495BB;
    case 0x8495BCu: goto L_8495BC;
    case 0x8495BFu: goto L_8495BF;
    case 0x8495C0u: goto L_8495C0;
    case 0x8495C3u: goto L_8495C3;
    case 0x8495C6u: goto L_8495C6;
    case 0x8495C9u: goto L_8495C9;
    case 0x8495CBu: goto L_8495CB;
    case 0x8495CEu: goto L_8495CE;
    case 0x8495D0u: goto L_8495D0;
    case 0x8495D3u: goto L_8495D3;
    case 0x8495D5u: goto L_8495D5;
    case 0x8495D9u: goto L_8495D9;
    case 0x8495DCu: goto L_8495DC;
    case 0x8495DFu: goto L_8495DF;
    case 0x8495E2u: goto L_8495E2;
    case 0x8495E4u: goto L_8495E4;
    case 0x8495E7u: goto L_8495E7;
    case 0x8495E9u: goto L_8495E9;
    case 0x8495ECu: goto L_8495EC;
    case 0x8495EEu: goto L_8495EE;
    case 0x8495F2u: goto L_8495F2;
    case 0x8495F3u: goto L_8495F3;
    case 0x8495F5u: goto L_8495F5;
    case 0x8495F6u: goto L_8495F6;
    case 0x8495F7u: goto L_8495F7;
    case 0x8495F8u: goto L_8495F8;
    case 0x8495FBu: goto L_8495FB;
    case 0x8495FCu: goto L_8495FC;
    case 0x8495FFu: goto L_8495FF;
    case 0x849601u: goto L_849601;
    case 0x849604u: goto L_849604;
    case 0x849606u: goto L_849606;
    case 0x849609u: goto L_849609;
    case 0x84960Du: goto L_84960D;
    case 0x84960Fu: goto L_84960F;
    case 0x849612u: goto L_849612;
    case 0x849614u: goto L_849614;
    case 0x849617u: goto L_849617;
    case 0x849619u: goto L_849619;
    case 0x84961Bu: goto L_84961B;
    case 0x84961Du: goto L_84961D;
    case 0x84961Fu: goto L_84961F;
    case 0x849620u: goto L_849620;
    case 0x849623u: goto L_849623;
    case 0x849625u: goto L_849625;
    case 0x849627u: goto L_849627;
    case 0x84962Au: goto L_84962A;
    case 0x84962Du: goto L_84962D;
    case 0x84962Fu: goto L_84962F;
    case 0x849632u: goto L_849632;
    case 0x849634u: goto L_849634;
    case 0x849636u: goto L_849636;
    case 0x849637u: goto L_849637;
    case 0x84963Au: goto L_84963A;
    case 0x84963Cu: goto L_84963C;
    case 0x84963Du: goto L_84963D;
    case 0x84963Eu: goto L_84963E;
    case 0x849640u: goto L_849640;
    case 0x849641u: goto L_849641;
    case 0x849644u: goto L_849644;
    case 0x849646u: goto L_849646;
    case 0x849648u: goto L_849648;
    case 0x84964Au: goto L_84964A;
    case 0x84964Bu: goto L_84964B;
    case 0x84964Eu: goto L_84964E;
    case 0x849650u: goto L_849650;
    case 0x849651u: goto L_849651;
    case 0x849652u: goto L_849652;
    case 0x849655u: goto L_849655;
    case 0x849657u: goto L_849657;
    case 0x849658u: goto L_849658;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84958B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x958Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x958Bu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x958Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84958B SEP
    cpu.sep(0x20u);
    goto L_84958D;
L_84958D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x958Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x958Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x958Du, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84958D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849590;
L_849590:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9590u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9590u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9590u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849590 BIT
    cpu.bit(0x1u, true);
    goto L_849592;
L_849592:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9592u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9592u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9592u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849592 BNE -> $8495F2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8495F2; }
    goto L_849594;
L_849594:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9594u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9594u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9594u, 4u, 3u, cpu.address("abs", 0x062Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849594 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849597;
L_849597:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9597u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9597u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9597u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849597 BEQ -> $8495F2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8495F2; }
    goto L_849599;
L_849599:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9599u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9599u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9599u, 4u, 3u, cpu.address("abs", 0x06FDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849599 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6FDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84959C;
L_84959C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x959Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x959Cu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x959Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84959C BIT
    cpu.bit(0x1u, true);
    goto L_84959E;
L_84959E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x959Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x959Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x959Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84959E BEQ -> $8495F3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8495F3; }
    goto L_8495A0;
L_8495A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95A0u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95A0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495A0 REP
    cpu.rep(0x20u);
    goto L_8495A2;
L_8495A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95A2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95A2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495A2 LDA
    cpu.setA(0xF0F7u, 16);
    goto L_8495A5;
L_8495A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95A5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95A5u, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495A5 STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_8495A8;
L_8495A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95A8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95A8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495A8 LDA
    cpu.setA(0x8Au, 16);
    goto L_8495AB;
L_8495AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95ABu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95ABu, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495AB STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_8495AE;
L_8495AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95AEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95AEu, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8495AE JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x95B1u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x95B2u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x8495AEu); }
    goto L_8495B2;
L_8495B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x95B2u,0x8495B2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B2u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B2u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8495B2 PHB
    cpu.push("PHB", hw);
    goto L_8495B3;
L_8495B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B3u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495B3 LDX
    cpu.setX(0x8000u, 16);
    goto L_8495B6;
L_8495B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B6u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495B6 LDY
    cpu.setY(0x2800u, 16);
    goto L_8495B9;
L_8495B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495B9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8495BB;
L_8495BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95BBu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495BB DEC
    cpu.decReg('A');
    goto L_8495BC;
L_8495BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95BCu,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0x95BCu, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $8495BC MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_8495BF;
L_8495BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95BFu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95BFu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8495BF PLB
    cpu.pop("PLB", hw);
    goto L_8495C0;
L_8495C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95C0u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95C0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495C0 LDX
    cpu.setX(0x8u, 16);
    goto L_8495C3;
L_8495C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95C3u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95C3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495C3 LDY
    cpu.setY(0x1Cu, 16);
    goto L_8495C6;
L_8495C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95C6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95C6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495C6 LDA
    cpu.setA(0x6384u, 16);
    goto L_8495C9;
L_8495C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95C9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95C9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495C9 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_8495CB;
L_8495CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95CBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95CBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495CB LDA
    cpu.setA(0x7Eu, 16);
    goto L_8495CE;
L_8495CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95CEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95CEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495CE STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_8495D0;
L_8495D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95D0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95D0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495D0 LDA
    cpu.setA(0x6u, 16);
    goto L_8495D3;
L_8495D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95D3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95D3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495D3 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_8495D5;
L_8495D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95D5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95D5u, 8u, 4u, 0x80A85Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8495D5 JSL -> $80A85F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x95D8u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x95D9u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A85Fu, 0x8495D5u); }
    goto L_8495D9;
L_8495D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95D9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x95D9u,0x8495D9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95D9u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95D9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495D9 LDX
    cpu.setX(0x8u, 16);
    goto L_8495DC;
L_8495DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95DCu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95DCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495DC LDY
    cpu.setY(0x1Cu, 16);
    goto L_8495DF;
L_8495DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95DFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95DFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495DF LDA
    cpu.setA(0x6504u, 16);
    goto L_8495E2;
L_8495E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95E2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95E2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495E2 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_8495E4;
L_8495E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95E4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95E4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495E4 LDA
    cpu.setA(0x7Eu, 16);
    goto L_8495E7;
L_8495E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95E7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95E7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495E7 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_8495E9;
L_8495E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95E9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95E9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495E9 LDA
    cpu.setA(0x0u, 16);
    goto L_8495EC;
L_8495EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95ECu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95ECu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495EC STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_8495EE;
L_8495EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95EEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95EEu, 8u, 4u, 0x80A85Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8495EE JSL -> $80A85F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x95F1u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x95F2u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A85Fu, 0x8495EEu); }
    goto L_8495F2;
L_8495F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95F2u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95F2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95F2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8495F2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8495F2u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8495F2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95F2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95F2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8495F2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8495F2u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8495F2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x95F2u,0x8495F2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8495F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95F3u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95F3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495F3 REP
    cpu.rep(0x20u);
    goto L_8495F5;
L_8495F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95F5u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95F5u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8495F5 PHB
    cpu.push("PHB", hw);
    goto L_8495F6;
L_8495F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95F6u,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95F6u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8495F6 PHK
    cpu.push("PHK", hw);
    goto L_8495F7;
L_8495F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95F7u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95F7u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8495F7 PLB
    cpu.pop("PLB", hw);
    goto L_8495F8;
L_8495F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95F8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95F8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495F8 LDA
    cpu.setA(0x2800u, 16);
    goto L_8495FB;
L_8495FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95FBu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95FBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495FB CLC
    cpu.setFlag('C', false);
    goto L_8495FC;
L_8495FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95FCu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95FCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495FC ADC
    cpu.adc(0x2C8u);
    goto L_8495FF;
L_8495FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95FFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95FFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495FF STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_849601;
L_849601:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9601u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9601u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9601u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849601 LDA
    cpu.setA(0x7Eu, 16);
    goto L_849604;
L_849604:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9604u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9604u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9604u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849604 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_849606;
L_849606:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9606u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9606u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9606u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849606 LDX
    cpu.setX(0x0u, 16);
    goto L_849609;
L_849609:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9609u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9609u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9609u, 6u, 4u, ((0x849659u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849609 LDA
    cpu.loadA(hw.readW(((0x849659u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84960D;
L_84960D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x960Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x960Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x960Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84960D STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_84960F;
L_84960F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x960Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x960Fu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x960Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84960F LDY
    cpu.setY(0x0u, 16);
    goto L_849612;
L_849612:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9612u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9612u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9612u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x04u) & 0xFFFFu), 2u, 0u);
    // $849612 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849614;
L_849614:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9614u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9614u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9614u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849614 CMP
    cpu.compareA(0xFFFFu);
    goto L_849617;
L_849617:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9617u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9617u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9617u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849617 BEQ -> $849648
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_849648; }
    goto L_849619;
L_849619:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9619u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9619u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9619u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $849619 STA
    hw.write(cpu.addressDpLongY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84961B;
L_84961B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x961Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x961Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x961Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84961B STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_84961D;
L_84961D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x961Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x961Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x961Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84961D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84961F;
L_84961F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x961Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x961Fu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x961Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84961F SEC
    cpu.setFlag('C', true);
    goto L_849620;
L_849620:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9620u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9620u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9620u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849620 SBC
    cpu.sbc(0x40u);
    goto L_849623;
L_849623:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9623u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9623u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9623u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849623 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_849625;
L_849625:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9625u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9625u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9625u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849625 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849627;
L_849627:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9627u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9627u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9627u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849627 AND
    cpu.logicAnd(0x1FFu);
    goto L_84962A;
L_84962A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x962Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x962Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x962Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84962A CMP
    cpu.compareA(0x130u);
    goto L_84962D;
L_84962D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x962Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x962Du,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x962Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84962D BCS -> $849634
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_849634; }
    goto L_84962F;
L_84962F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x962Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x962Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x962Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84962F LDA
    cpu.setA(0x0u, 16);
    goto L_849632;
L_849632:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9632u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9632u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9632u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849632 BRA -> $84963A
    goto L_84963A;
L_849634:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9634u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9634u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9634u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849634 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849636;
L_849636:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9636u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9636u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9636u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849636 SEC
    cpu.setFlag('C', true);
    goto L_849637;
L_849637:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9637u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9637u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9637u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849637 SBC
    cpu.sbc(0x10u);
    goto L_84963A;
L_84963A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x963Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x963Au,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x963Au, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $84963A STA
    hw.write(cpu.addressDpLongY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84963C;
L_84963C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x963Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x963Cu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x963Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84963C INY
    cpu.inc('Y');
    goto L_84963D;
L_84963D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x963Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x963Du,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x963Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84963D INY
    cpu.inc('Y');
    goto L_84963E;
L_84963E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x963Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x963Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x963Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84963E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849640;
L_849640:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9640u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9640u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9640u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849640 CLC
    cpu.setFlag('C', false);
    goto L_849641;
L_849641:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9641u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9641u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9641u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849641 ADC
    cpu.adc(0x40u);
    goto L_849644;
L_849644:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9644u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9644u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9644u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849644 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_849646;
L_849646:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9646u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9646u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9646u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849646 BRA -> $849612
    goto L_849612;
L_849648:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9648u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9648u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9648u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849648 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84964A;
L_84964A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x964Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x964Au,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x964Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84964A CLC
    cpu.setFlag('C', false);
    goto L_84964B;
L_84964B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x964Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x964Bu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x964Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84964B ADC
    cpu.adc(0x10u);
    goto L_84964E;
L_84964E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x964Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x964Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x964Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84964E STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_849650;
L_849650:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9650u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9650u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9650u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849650 INX
    cpu.inc('X');
    goto L_849651;
L_849651:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9651u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9651u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9651u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849651 INX
    cpu.inc('X');
    goto L_849652;
L_849652:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9652u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9652u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9652u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849652 CPX
    cpu.compareX(0x6u);
    goto L_849655;
L_849655:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9655u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9655u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9655u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849655 BCC -> $849609
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_849609; }
    goto L_849657;
L_849657:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9657u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9657u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9657u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $849657 PLB
    cpu.pop("PLB", hw);
    goto L_849658;
L_849658:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9658u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9658u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9658u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849658 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849658u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849658u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_849943_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849943u: goto L_849943;
    case 0x849945u: goto L_849945;
    case 0x849948u: goto L_849948;
    case 0x84994Au: goto L_84994A;
    case 0x84994Cu: goto L_84994C;
    case 0x84994Fu: goto L_84994F;
    case 0x849950u: goto L_849950;
    case 0x849951u: goto L_849951;
    case 0x849954u: goto L_849954;
    case 0x849957u: goto L_849957;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849943:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9943u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9943u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9943u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849943 SEP
    cpu.sep(0x20u);
    goto L_849945;
L_849945:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9945u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9945u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9945u, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849945 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849948;
L_849948:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9948u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9948u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9948u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849948 AND
    cpu.logicAnd(0x1u);
    goto L_84994A;
L_84994A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x994Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x994Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x994Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84994A REP
    cpu.rep(0x20u);
    goto L_84994C;
L_84994C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x994Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x994Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x994Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84994C AND
    cpu.logicAnd(0xFFu);
    goto L_84994F;
L_84994F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x994Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x994Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x994Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84994F ASL
    cpu.aslA();
    goto L_849950;
L_849950:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9950u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9950u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9950u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849950 TAX
    cpu.transfer("TAX");
    goto L_849951;
L_849951:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9951u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9951u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9951u, 5u, 3u, cpu.address("abs", 0x9956u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849951 PEA
    cpu.push16Value(hw, 0x9956u);
    goto L_849954;
L_849954:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9954u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9954u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9954u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x9958u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $849954 JMP (9958,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x9958u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x849954u); return; }
L_849957:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9957u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9957u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9957u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849957 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849957u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849957u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9957u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9957u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849957 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849957u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849957u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9957u,0x849957u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_849943_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849943u: goto L_849943;
    case 0x849945u: goto L_849945;
    case 0x849948u: goto L_849948;
    case 0x84994Au: goto L_84994A;
    case 0x84994Cu: goto L_84994C;
    case 0x84994Fu: goto L_84994F;
    case 0x849950u: goto L_849950;
    case 0x849951u: goto L_849951;
    case 0x849954u: goto L_849954;
    case 0x849957u: goto L_849957;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849943:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9943u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9943u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9943u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849943 SEP
    cpu.sep(0x20u);
    goto L_849945;
L_849945:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9945u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9945u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9945u, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849945 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849948;
L_849948:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9948u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9948u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9948u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849948 AND
    cpu.logicAnd(0x1u);
    goto L_84994A;
L_84994A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x994Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x994Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x994Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84994A REP
    cpu.rep(0x20u);
    goto L_84994C;
L_84994C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x994Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x994Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x994Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84994C AND
    cpu.logicAnd(0xFFu);
    goto L_84994F;
L_84994F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x994Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x994Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x994Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84994F ASL
    cpu.aslA();
    goto L_849950;
L_849950:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9950u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9950u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9950u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849950 TAX
    cpu.transfer("TAX");
    goto L_849951;
L_849951:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9951u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9951u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9951u, 5u, 3u, cpu.address("abs", 0x9956u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849951 PEA
    cpu.push16Value(hw, 0x9956u);
    goto L_849954;
L_849954:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9954u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9954u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9954u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x9958u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $849954 JMP (9958,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x9958u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x849954u); return; }
L_849957:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9957u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9957u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9957u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849957 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849957u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849957u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9957u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9957u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849957 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849957u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849957u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9957u,0x849957u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_849BAD_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849BADu: goto L_849BAD;
    case 0x849BAFu: goto L_849BAF;
    case 0x849BB2u: goto L_849BB2;
    case 0x849BB4u: goto L_849BB4;
    case 0x849BB6u: goto L_849BB6;
    case 0x849BB9u: goto L_849BB9;
    case 0x849BBAu: goto L_849BBA;
    case 0x849BBBu: goto L_849BBB;
    case 0x849BBEu: goto L_849BBE;
    case 0x849BC1u: goto L_849BC1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849BAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BADu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BADu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BAD SEP
    cpu.sep(0x20u);
    goto L_849BAF;
L_849BAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BAFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BAFu, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BAF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849BB2;
L_849BB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BB2u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BB2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BB2 AND
    cpu.logicAnd(0x1u);
    goto L_849BB4;
L_849BB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BB4u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BB4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BB4 REP
    cpu.rep(0x20u);
    goto L_849BB6;
L_849BB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BB6u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BB6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BB6 AND
    cpu.logicAnd(0xFFu);
    goto L_849BB9;
L_849BB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BB9u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BB9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BB9 ASL
    cpu.aslA();
    goto L_849BBA;
L_849BBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BBAu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BBAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BBA TAX
    cpu.transfer("TAX");
    goto L_849BBB;
L_849BBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BBBu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BBBu, 5u, 3u, cpu.address("abs", 0x9BC0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849BBB PEA
    cpu.push16Value(hw, 0x9BC0u);
    goto L_849BBE;
L_849BBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BBEu,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BBEu, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x9BC2u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $849BBE JMP (9BC2,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x9BC2u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x849BBEu); return; }
L_849BC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BC1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9BC1u,0x849BC1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BC1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BC1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849BC1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849BC1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849BC1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_849BAD_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849BADu: goto L_849BAD;
    case 0x849BAFu: goto L_849BAF;
    case 0x849BB2u: goto L_849BB2;
    case 0x849BB4u: goto L_849BB4;
    case 0x849BB6u: goto L_849BB6;
    case 0x849BB9u: goto L_849BB9;
    case 0x849BBAu: goto L_849BBA;
    case 0x849BBBu: goto L_849BBB;
    case 0x849BBEu: goto L_849BBE;
    case 0x849BC1u: goto L_849BC1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849BAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BADu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BADu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BAD SEP
    cpu.sep(0x20u);
    goto L_849BAF;
L_849BAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BAFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BAFu, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BAF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849BB2;
L_849BB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BB2u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BB2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BB2 AND
    cpu.logicAnd(0x1u);
    goto L_849BB4;
L_849BB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BB4u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BB4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BB4 REP
    cpu.rep(0x20u);
    goto L_849BB6;
L_849BB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BB6u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BB6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BB6 AND
    cpu.logicAnd(0xFFu);
    goto L_849BB9;
L_849BB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BB9u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BB9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BB9 ASL
    cpu.aslA();
    goto L_849BBA;
L_849BBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BBAu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BBAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BBA TAX
    cpu.transfer("TAX");
    goto L_849BBB;
L_849BBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BBBu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BBBu, 5u, 3u, cpu.address("abs", 0x9BC0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849BBB PEA
    cpu.push16Value(hw, 0x9BC0u);
    goto L_849BBE;
L_849BBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BBEu,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BBEu, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x9BC2u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $849BBE JMP (9BC2,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x9BC2u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x849BBEu); return; }
L_849BC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BC1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9BC1u,0x849BC1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BC1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BC1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849BC1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849BC1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849BC1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84C087_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84C087u: goto L_84C087;
    case 0x84C089u: goto L_84C089;
    case 0x84C08Cu: goto L_84C08C;
    case 0x84C08Fu: goto L_84C08F;
    case 0x84C091u: goto L_84C091;
    case 0x84C093u: goto L_84C093;
    case 0x84C096u: goto L_84C096;
    case 0x84C099u: goto L_84C099;
    case 0x84C09Bu: goto L_84C09B;
    case 0x84C09Eu: goto L_84C09E;
    case 0x84C0A0u: goto L_84C0A0;
    case 0x84C0A3u: goto L_84C0A3;
    case 0x84C0A6u: goto L_84C0A6;
    case 0x84C0AAu: goto L_84C0AA;
    case 0x84C0ACu: goto L_84C0AC;
    case 0x84C0AFu: goto L_84C0AF;
    case 0x84C0B1u: goto L_84C0B1;
    case 0x84C0B3u: goto L_84C0B3;
    case 0x84C0B5u: goto L_84C0B5;
    case 0x84C0B8u: goto L_84C0B8;
    case 0x84C0BAu: goto L_84C0BA;
    case 0x84C0BDu: goto L_84C0BD;
    case 0x84C0BFu: goto L_84C0BF;
    case 0x84C0C1u: goto L_84C0C1;
    case 0x84C0C3u: goto L_84C0C3;
    case 0x84C0C5u: goto L_84C0C5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84C087:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC087u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC087u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC087u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C087 REP
    cpu.rep(0x20u);
    goto L_84C089;
L_84C089:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC089u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC089u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC089u, 5u, 3u, cpu.address("abs", 0x060Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C089 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x60Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84C08C;
L_84C08C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC08Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC08Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC08Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C08C CMP
    cpu.compareA(0x6u);
    goto L_84C08F;
L_84C08F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC08Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC08Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC08Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C08F BEQ -> $84C0AC
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_84C0AC; }
    goto L_84C091;
L_84C091:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC091u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC091u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC091u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C091 BCS -> $84C0B1
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_84C0B1; }
    goto L_84C093;
L_84C093:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC093u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC093u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC093u, 6u, 3u, cpu.address("abs", 0xC2C3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84C093 JSR -> $84C2C3 stack real
    { cpu.push16Value(hw,0xC095u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC096u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC2C3u), 0x84C093u); }
    goto L_84C096;
L_84C096:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC096u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC096u,0x84C096u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC096u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC096u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C096 LDA
    cpu.setA(0xAE6Cu, 16);
    goto L_84C099;
L_84C099:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC099u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC099u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC099u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C099 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84C09B;
L_84C09B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC09Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC09Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC09Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C09B LDA
    cpu.setA(0x8Au, 16);
    goto L_84C09E;
L_84C09E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC09Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC09Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC09Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C09E STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_84C0A0;
L_84C0A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0A0u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0A0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C0A0 LDX
    cpu.setX(0x0u, 16);
    goto L_84C0A3;
L_84C0A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0A3u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0A3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C0A3 LDY
    cpu.setY(0x200u, 16);
    goto L_84C0A6;
L_84C0A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0A6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0A6u, 8u, 4u, 0x808BB9u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84C0A6 JSL -> $808BB9 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC0A9u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC0AAu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808BB9u, 0x84C0A6u); }
    goto L_84C0AA;
L_84C0AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0AAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC0AAu,0x84C0AAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0AAu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0AAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C0AA BRA -> $84C0C5
    goto L_84C0C5;
L_84C0AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0ACu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0ACu, 8u, 3u, cpu.address("abs", 0x060Fu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C0AC INC
    cpu.incMem(hw, cpu.address("abs", 0x60Fu), cpu.m8?8:16);
    goto L_84C0AF;
L_84C0AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0AFu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0AFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C0AF BRA -> $84C0C5
    goto L_84C0C5;
L_84C0B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0B1u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0B1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C0B1 SEP
    cpu.sep(0x20u);
    goto L_84C0B3;
L_84C0B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0B3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0B3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C0B3 LDA
    cpu.setA(0x1u, 8);
    goto L_84C0B5;
L_84C0B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0B5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0B5u, 4u, 3u, cpu.address("abs", 0x2105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C0B5 STA
    hw.write(cpu.address("abs", 0x2105u), cpu.a, cpu.m8?8:16);
    goto L_84C0B8;
L_84C0B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0B8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0B8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C0B8 LDA
    cpu.setA(0x6u, 8);
    goto L_84C0BA;
L_84C0BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0BAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0BAu, 4u, 3u, cpu.address("abs", 0x210Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C0BA STA
    hw.write(cpu.address("abs", 0x210Bu), cpu.a, cpu.m8?8:16);
    goto L_84C0BD;
L_84C0BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0BDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0BDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C0BD LDA
    cpu.setA(0x13u, 8);
    goto L_84C0BF;
L_84C0BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0BFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0BFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C0BF STA
    hw.write(cpu.address("dp", 0x7Au), cpu.a, cpu.m8?8:16);
    goto L_84C0C1;
L_84C0C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0C1u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0C1u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C0C1 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_84C0C3;
L_84C0C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0C3u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0C3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C0C3 REP
    cpu.rep(0x20u);
    goto L_84C0C5;
L_84C0C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0C5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0C5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84C0C5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84C0C5u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84C0C5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

