#include "generated.hpp"
void sub_00F2AD_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00F2ADu: goto L_00F2AD;
    case 0x00F2B1u: goto L_00F2B1;
    case 0x00F2B5u: goto L_00F2B5;
    case 0x00F2B9u: goto L_00F2B9;
    case 0x00F2BDu: goto L_00F2BD;
    case 0x00F2C1u: goto L_00F2C1;
    case 0x00F2C5u: goto L_00F2C5;
    case 0x00F2C9u: goto L_00F2C9;
    case 0x00F2CDu: goto L_00F2CD;
    case 0x00F2D1u: goto L_00F2D1;
    case 0x00F2D5u: goto L_00F2D5;
    case 0x00F2D9u: goto L_00F2D9;
    case 0x00F2DDu: goto L_00F2DD;
    case 0x00F2E1u: goto L_00F2E1;
    case 0x00F2E5u: goto L_00F2E5;
    case 0x00F2E9u: goto L_00F2E9;
    case 0x00F2EDu: goto L_00F2ED;
    case 0x00F2F1u: goto L_00F2F1;
    case 0x00F2F5u: goto L_00F2F5;
    case 0x00F2F9u: goto L_00F2F9;
    case 0x00F2FDu: goto L_00F2FD;
    case 0x00F301u: goto L_00F301;
    case 0x00F305u: goto L_00F305;
    case 0x00F309u: goto L_00F309;
    case 0x00F30Du: goto L_00F30D;
    case 0x00F311u: goto L_00F311;
    case 0x00F315u: goto L_00F315;
    case 0x00F319u: goto L_00F319;
    case 0x00F31Du: goto L_00F31D;
    case 0x00F321u: goto L_00F321;
    case 0x00F325u: goto L_00F325;
    case 0x00F329u: goto L_00F329;
    case 0x00F32Du: goto L_00F32D;
    case 0x00F331u: goto L_00F331;
    case 0x00F335u: goto L_00F335;
    case 0x00F339u: goto L_00F339;
    case 0x00F33Du: goto L_00F33D;
    case 0x00F341u: goto L_00F341;
    case 0x00F345u: goto L_00F345;
    case 0x00F349u: goto L_00F349;
    case 0x00F34Du: goto L_00F34D;
    case 0x00F351u: goto L_00F351;
    case 0x00F355u: goto L_00F355;
    case 0x00F359u: goto L_00F359;
    case 0x00F35Du: goto L_00F35D;
    case 0x00F361u: goto L_00F361;
    case 0x00F365u: goto L_00F365;
    case 0x00F369u: goto L_00F369;
    case 0x00F36Du: goto L_00F36D;
    case 0x00F371u: goto L_00F371;
    case 0x00F375u: goto L_00F375;
    case 0x00F379u: goto L_00F379;
    case 0x00F37Du: goto L_00F37D;
    case 0x00F381u: goto L_00F381;
    case 0x00F385u: goto L_00F385;
    case 0x00F389u: goto L_00F389;
    case 0x00F38Du: goto L_00F38D;
    case 0x00F391u: goto L_00F391;
    case 0x00F395u: goto L_00F395;
    case 0x00F399u: goto L_00F399;
    case 0x00F39Du: goto L_00F39D;
    case 0x00F3A1u: goto L_00F3A1;
    case 0x00F3A5u: goto L_00F3A5;
    case 0x00F3A9u: goto L_00F3A9;
    case 0x00F3ADu: goto L_00F3AD;
    case 0x00F3B1u: goto L_00F3B1;
    case 0x00F3B5u: goto L_00F3B5;
    case 0x00F3B9u: goto L_00F3B9;
    case 0x00F3BDu: goto L_00F3BD;
    case 0x00F3C1u: goto L_00F3C1;
    case 0x00F3C5u: goto L_00F3C5;
    case 0x00F3C9u: goto L_00F3C9;
    case 0x00F3CDu: goto L_00F3CD;
    case 0x00F3D1u: goto L_00F3D1;
    case 0x00F3D5u: goto L_00F3D5;
    case 0x00F3D9u: goto L_00F3D9;
    case 0x00F3DDu: goto L_00F3DD;
    case 0x00F3E1u: goto L_00F3E1;
    case 0x00F3E5u: goto L_00F3E5;
    case 0x00F3E9u: goto L_00F3E9;
    case 0x00F3EDu: goto L_00F3ED;
    case 0x00F3F1u: goto L_00F3F1;
    case 0x00F3F5u: goto L_00F3F5;
    case 0x00F3F9u: goto L_00F3F9;
    case 0x00F3FDu: goto L_00F3FD;
    case 0x00F401u: goto L_00F401;
    case 0x00F405u: goto L_00F405;
    case 0x00F409u: goto L_00F409;
    case 0x00F40Du: goto L_00F40D;
    case 0x00F411u: goto L_00F411;
    case 0x00F415u: goto L_00F415;
    case 0x00F419u: goto L_00F419;
    case 0x00F41Du: goto L_00F41D;
    case 0x00F421u: goto L_00F421;
    case 0x00F425u: goto L_00F425;
    case 0x00F429u: goto L_00F429;
    case 0x00F42Du: goto L_00F42D;
    case 0x00F431u: goto L_00F431;
    case 0x00F435u: goto L_00F435;
    case 0x00F439u: goto L_00F439;
    case 0x00F43Du: goto L_00F43D;
    case 0x00F441u: goto L_00F441;
    case 0x00F445u: goto L_00F445;
    case 0x00F449u: goto L_00F449;
    case 0x00F44Du: goto L_00F44D;
    case 0x00F451u: goto L_00F451;
    case 0x00F455u: goto L_00F455;
    case 0x00F459u: goto L_00F459;
    case 0x00F45Du: goto L_00F45D;
    case 0x00F461u: goto L_00F461;
    case 0x00F465u: goto L_00F465;
    case 0x00F469u: goto L_00F469;
    case 0x00F46Du: goto L_00F46D;
    case 0x00F471u: goto L_00F471;
    case 0x00F475u: goto L_00F475;
    case 0x00F479u: goto L_00F479;
    case 0x00F47Du: goto L_00F47D;
    case 0x00F481u: goto L_00F481;
    case 0x00F485u: goto L_00F485;
    case 0x00F489u: goto L_00F489;
    case 0x00F48Du: goto L_00F48D;
    case 0x00F491u: goto L_00F491;
    case 0x00F495u: goto L_00F495;
    case 0x00F499u: goto L_00F499;
    case 0x00F49Du: goto L_00F49D;
    case 0x00F4A1u: goto L_00F4A1;
    case 0x00F4A5u: goto L_00F4A5;
    case 0x00F4A9u: goto L_00F4A9;
    case 0x00F4ADu: goto L_00F4AD;
    case 0x00F4B1u: goto L_00F4B1;
    case 0x00F4B5u: goto L_00F4B5;
    case 0x00F4B9u: goto L_00F4B9;
    case 0x00F4BDu: goto L_00F4BD;
    case 0x00F4C1u: goto L_00F4C1;
    case 0x00F4C5u: goto L_00F4C5;
    case 0x00F4C9u: goto L_00F4C9;
    case 0x00F4CDu: goto L_00F4CD;
    case 0x00F4D1u: goto L_00F4D1;
    case 0x00F4D5u: goto L_00F4D5;
    case 0x00F4D9u: goto L_00F4D9;
    case 0x00F4DDu: goto L_00F4DD;
    case 0x00F4E1u: goto L_00F4E1;
    case 0x00F4E5u: goto L_00F4E5;
    case 0x00F4E9u: goto L_00F4E9;
    case 0x00F4EDu: goto L_00F4ED;
    case 0x00F4F1u: goto L_00F4F1;
    case 0x00F4F5u: goto L_00F4F5;
    case 0x00F4F9u: goto L_00F4F9;
    case 0x00F4FDu: goto L_00F4FD;
    case 0x00F501u: goto L_00F501;
    case 0x00F505u: goto L_00F505;
    case 0x00F509u: goto L_00F509;
    case 0x00F50Du: goto L_00F50D;
    case 0x00F511u: goto L_00F511;
    case 0x00F515u: goto L_00F515;
    case 0x00F519u: goto L_00F519;
    case 0x00F51Du: goto L_00F51D;
    case 0x00F521u: goto L_00F521;
    case 0x00F525u: goto L_00F525;
    case 0x00F529u: goto L_00F529;
    case 0x00F52Du: goto L_00F52D;
    case 0x00F531u: goto L_00F531;
    case 0x00F535u: goto L_00F535;
    case 0x00F539u: goto L_00F539;
    case 0x00F53Du: goto L_00F53D;
    case 0x00F541u: goto L_00F541;
    case 0x00F545u: goto L_00F545;
    case 0x00F549u: goto L_00F549;
    case 0x00F54Du: goto L_00F54D;
    case 0x00F551u: goto L_00F551;
    case 0x00F555u: goto L_00F555;
    case 0x00F559u: goto L_00F559;
    case 0x00F55Du: goto L_00F55D;
    case 0x00F561u: goto L_00F561;
    case 0x00F565u: goto L_00F565;
    case 0x00F569u: goto L_00F569;
    case 0x00F56Du: goto L_00F56D;
    case 0x00F571u: goto L_00F571;
    case 0x00F575u: goto L_00F575;
    case 0x00F579u: goto L_00F579;
    case 0x00F57Du: goto L_00F57D;
    case 0x00F581u: goto L_00F581;
    case 0x00F585u: goto L_00F585;
    case 0x00F589u: goto L_00F589;
    case 0x00F58Du: goto L_00F58D;
    case 0x00F591u: goto L_00F591;
    case 0x00F595u: goto L_00F595;
    case 0x00F599u: goto L_00F599;
    case 0x00F59Du: goto L_00F59D;
    case 0x00F5A1u: goto L_00F5A1;
    case 0x00F5A5u: goto L_00F5A5;
    case 0x00F5A9u: goto L_00F5A9;
    case 0x00F5ADu: goto L_00F5AD;
    case 0x00F5B1u: goto L_00F5B1;
    case 0x00F5B5u: goto L_00F5B5;
    case 0x00F5B9u: goto L_00F5B9;
    case 0x00F5BDu: goto L_00F5BD;
    case 0x00F5C1u: goto L_00F5C1;
    case 0x00F5C5u: goto L_00F5C5;
    case 0x00F5C9u: goto L_00F5C9;
    case 0x00F5CDu: goto L_00F5CD;
    case 0x00F5D1u: goto L_00F5D1;
    case 0x00F5D5u: goto L_00F5D5;
    case 0x00F5D9u: goto L_00F5D9;
    case 0x00F5DDu: goto L_00F5DD;
    case 0x00F5E1u: goto L_00F5E1;
    case 0x00F5E5u: goto L_00F5E5;
    case 0x00F5E9u: goto L_00F5E9;
    case 0x00F5EDu: goto L_00F5ED;
    case 0x00F5F1u: goto L_00F5F1;
    case 0x00F5F5u: goto L_00F5F5;
    case 0x00F5F9u: goto L_00F5F9;
    case 0x00F5FDu: goto L_00F5FD;
    case 0x00F601u: goto L_00F601;
    case 0x00F605u: goto L_00F605;
    case 0x00F609u: goto L_00F609;
    case 0x00F60Du: goto L_00F60D;
    case 0x00F611u: goto L_00F611;
    case 0x00F615u: goto L_00F615;
    case 0x00F619u: goto L_00F619;
    case 0x00F61Du: goto L_00F61D;
    case 0x00F621u: goto L_00F621;
    case 0x00F625u: goto L_00F625;
    case 0x00F629u: goto L_00F629;
    case 0x00F62Du: goto L_00F62D;
    case 0x00F631u: goto L_00F631;
    case 0x00F635u: goto L_00F635;
    case 0x00F639u: goto L_00F639;
    case 0x00F63Du: goto L_00F63D;
    case 0x00F641u: goto L_00F641;
    case 0x00F645u: goto L_00F645;
    case 0x00F649u: goto L_00F649;
    case 0x00F64Du: goto L_00F64D;
    case 0x00F651u: goto L_00F651;
    case 0x00F655u: goto L_00F655;
    case 0x00F659u: goto L_00F659;
    case 0x00F65Du: goto L_00F65D;
    case 0x00F661u: goto L_00F661;
    case 0x00F665u: goto L_00F665;
    case 0x00F669u: goto L_00F669;
    case 0x00F66Du: goto L_00F66D;
    case 0x00F671u: goto L_00F671;
    case 0x00F675u: goto L_00F675;
    case 0x00F679u: goto L_00F679;
    case 0x00F67Du: goto L_00F67D;
    case 0x00F681u: goto L_00F681;
    case 0x00F685u: goto L_00F685;
    case 0x00F689u: goto L_00F689;
    case 0x00F68Du: goto L_00F68D;
    case 0x00F691u: goto L_00F691;
    case 0x00F695u: goto L_00F695;
    case 0x00F699u: goto L_00F699;
    case 0x00F69Du: goto L_00F69D;
    case 0x00F6A1u: goto L_00F6A1;
    case 0x00F6A5u: goto L_00F6A5;
    case 0x00F6A9u: goto L_00F6A9;
    case 0x00F6ADu: goto L_00F6AD;
    case 0x00F6B1u: goto L_00F6B1;
    case 0x00F6B5u: goto L_00F6B5;
    case 0x00F6B9u: goto L_00F6B9;
    case 0x00F6BDu: goto L_00F6BD;
    case 0x00F6C1u: goto L_00F6C1;
    case 0x00F6C5u: goto L_00F6C5;
    case 0x00F6C9u: goto L_00F6C9;
    case 0x00F6CDu: goto L_00F6CD;
    case 0x00F6D1u: goto L_00F6D1;
    case 0x00F6D5u: goto L_00F6D5;
    case 0x00F6D9u: goto L_00F6D9;
    case 0x00F6DDu: goto L_00F6DD;
    case 0x00F6E1u: goto L_00F6E1;
    case 0x00F6E5u: goto L_00F6E5;
    case 0x00F6E9u: goto L_00F6E9;
    case 0x00F6EDu: goto L_00F6ED;
    case 0x00F6F1u: goto L_00F6F1;
    case 0x00F6F5u: goto L_00F6F5;
    case 0x00F6F9u: goto L_00F6F9;
    case 0x00F6FDu: goto L_00F6FD;
    case 0x00F701u: goto L_00F701;
    case 0x00F705u: goto L_00F705;
    case 0x00F709u: goto L_00F709;
    case 0x00F70Du: goto L_00F70D;
    case 0x00F711u: goto L_00F711;
    case 0x00F715u: goto L_00F715;
    case 0x00F719u: goto L_00F719;
    case 0x00F71Du: goto L_00F71D;
    case 0x00F721u: goto L_00F721;
    case 0x00F725u: goto L_00F725;
    case 0x00F729u: goto L_00F729;
    case 0x00F72Du: goto L_00F72D;
    case 0x00F731u: goto L_00F731;
    case 0x00F735u: goto L_00F735;
    case 0x00F739u: goto L_00F739;
    case 0x00F73Du: goto L_00F73D;
    case 0x00F741u: goto L_00F741;
    case 0x00F745u: goto L_00F745;
    case 0x00F749u: goto L_00F749;
    case 0x00F74Du: goto L_00F74D;
    case 0x00F751u: goto L_00F751;
    case 0x00F755u: goto L_00F755;
    case 0x00F759u: goto L_00F759;
    case 0x00F75Du: goto L_00F75D;
    case 0x00F761u: goto L_00F761;
    case 0x00F765u: goto L_00F765;
    case 0x00F769u: goto L_00F769;
    case 0x00F76Du: goto L_00F76D;
    case 0x00F771u: goto L_00F771;
    case 0x00F775u: goto L_00F775;
    case 0x00F779u: goto L_00F779;
    case 0x00F77Du: goto L_00F77D;
    case 0x00F781u: goto L_00F781;
    case 0x00F785u: goto L_00F785;
    case 0x00F789u: goto L_00F789;
    case 0x00F78Du: goto L_00F78D;
    case 0x00F791u: goto L_00F791;
    case 0x00F795u: goto L_00F795;
    case 0x00F799u: goto L_00F799;
    case 0x00F79Du: goto L_00F79D;
    case 0x00F7A1u: goto L_00F7A1;
    case 0x00F7A5u: goto L_00F7A5;
    case 0x00F7A9u: goto L_00F7A9;
    case 0x00F7ADu: goto L_00F7AD;
    case 0x00F7B1u: goto L_00F7B1;
    case 0x00F7B5u: goto L_00F7B5;
    case 0x00F7B9u: goto L_00F7B9;
    case 0x00F7BDu: goto L_00F7BD;
    case 0x00F7C1u: goto L_00F7C1;
    case 0x00F7C5u: goto L_00F7C5;
    case 0x00F7C9u: goto L_00F7C9;
    case 0x00F7CDu: goto L_00F7CD;
    case 0x00F7D1u: goto L_00F7D1;
    case 0x00F7D5u: goto L_00F7D5;
    case 0x00F7D9u: goto L_00F7D9;
    case 0x00F7DDu: goto L_00F7DD;
    case 0x00F7E1u: goto L_00F7E1;
    case 0x00F7E5u: goto L_00F7E5;
    case 0x00F7E9u: goto L_00F7E9;
    case 0x00F7EDu: goto L_00F7ED;
    case 0x00F7F1u: goto L_00F7F1;
    case 0x00F7F5u: goto L_00F7F5;
    case 0x00F7F9u: goto L_00F7F9;
    case 0x00F7FDu: goto L_00F7FD;
    case 0x00F801u: goto L_00F801;
    case 0x00F805u: goto L_00F805;
    case 0x00F809u: goto L_00F809;
    case 0x00F80Du: goto L_00F80D;
    case 0x00F811u: goto L_00F811;
    case 0x00F815u: goto L_00F815;
    case 0x00F819u: goto L_00F819;
    case 0x00F81Du: goto L_00F81D;
    case 0x00F821u: goto L_00F821;
    case 0x00F825u: goto L_00F825;
    case 0x00F829u: goto L_00F829;
    case 0x00F82Du: goto L_00F82D;
    case 0x00F831u: goto L_00F831;
    case 0x00F835u: goto L_00F835;
    case 0x00F839u: goto L_00F839;
    case 0x00F83Du: goto L_00F83D;
    case 0x00F841u: goto L_00F841;
    case 0x00F845u: goto L_00F845;
    case 0x00F849u: goto L_00F849;
    case 0x00F84Du: goto L_00F84D;
    case 0x00F851u: goto L_00F851;
    case 0x00F855u: goto L_00F855;
    case 0x00F859u: goto L_00F859;
    case 0x00F85Du: goto L_00F85D;
    case 0x00F861u: goto L_00F861;
    case 0x00F865u: goto L_00F865;
    case 0x00F869u: goto L_00F869;
    case 0x00F86Du: goto L_00F86D;
    case 0x00F871u: goto L_00F871;
    case 0x00F875u: goto L_00F875;
    case 0x00F879u: goto L_00F879;
    case 0x00F87Du: goto L_00F87D;
    case 0x00F881u: goto L_00F881;
    case 0x00F885u: goto L_00F885;
    case 0x00F889u: goto L_00F889;
    case 0x00F88Du: goto L_00F88D;
    case 0x00F891u: goto L_00F891;
    case 0x00F895u: goto L_00F895;
    case 0x00F899u: goto L_00F899;
    case 0x00F89Du: goto L_00F89D;
    case 0x00F8A1u: goto L_00F8A1;
    case 0x00F8A5u: goto L_00F8A5;
    case 0x00F8A9u: goto L_00F8A9;
    case 0x00F8ADu: goto L_00F8AD;
    case 0x00F8B1u: goto L_00F8B1;
    case 0x00F8B5u: goto L_00F8B5;
    case 0x00F8B9u: goto L_00F8B9;
    case 0x00F8BDu: goto L_00F8BD;
    case 0x00F8C1u: goto L_00F8C1;
    case 0x00F8C5u: goto L_00F8C5;
    case 0x00F8C9u: goto L_00F8C9;
    case 0x00F8CDu: goto L_00F8CD;
    case 0x00F8D1u: goto L_00F8D1;
    case 0x00F8D5u: goto L_00F8D5;
    case 0x00F8D9u: goto L_00F8D9;
    case 0x00F8DDu: goto L_00F8DD;
    case 0x00F8E1u: goto L_00F8E1;
    case 0x00F8E5u: goto L_00F8E5;
    case 0x00F8E9u: goto L_00F8E9;
    case 0x00F8EDu: goto L_00F8ED;
    case 0x00F8F1u: goto L_00F8F1;
    case 0x00F8F5u: goto L_00F8F5;
    case 0x00F8F9u: goto L_00F8F9;
    case 0x00F8FDu: goto L_00F8FD;
    case 0x00F901u: goto L_00F901;
    case 0x00F905u: goto L_00F905;
    case 0x00F909u: goto L_00F909;
    case 0x00F90Du: goto L_00F90D;
    case 0x00F911u: goto L_00F911;
    case 0x00F915u: goto L_00F915;
    case 0x00F919u: goto L_00F919;
    case 0x00F91Du: goto L_00F91D;
    case 0x00F921u: goto L_00F921;
    case 0x00F925u: goto L_00F925;
    case 0x00F929u: goto L_00F929;
    case 0x00F92Du: goto L_00F92D;
    case 0x00F931u: goto L_00F931;
    case 0x00F935u: goto L_00F935;
    case 0x00F939u: goto L_00F939;
    case 0x00F93Du: goto L_00F93D;
    case 0x00F941u: goto L_00F941;
    case 0x00F945u: goto L_00F945;
    case 0x00F949u: goto L_00F949;
    case 0x00F94Du: goto L_00F94D;
    case 0x00F951u: goto L_00F951;
    case 0x00F955u: goto L_00F955;
    case 0x00F959u: goto L_00F959;
    case 0x00F95Du: goto L_00F95D;
    case 0x00F961u: goto L_00F961;
    case 0x00F965u: goto L_00F965;
    case 0x00F969u: goto L_00F969;
    case 0x00F96Du: goto L_00F96D;
    case 0x00F971u: goto L_00F971;
    case 0x00F975u: goto L_00F975;
    case 0x00F979u: goto L_00F979;
    case 0x00F97Du: goto L_00F97D;
    case 0x00F981u: goto L_00F981;
    case 0x00F985u: goto L_00F985;
    case 0x00F989u: goto L_00F989;
    case 0x00F98Du: goto L_00F98D;
    case 0x00F991u: goto L_00F991;
    case 0x00F995u: goto L_00F995;
    case 0x00F999u: goto L_00F999;
    case 0x00F99Du: goto L_00F99D;
    case 0x00F9A1u: goto L_00F9A1;
    case 0x00F9A5u: goto L_00F9A5;
    case 0x00F9A9u: goto L_00F9A9;
    case 0x00F9ADu: goto L_00F9AD;
    case 0x00F9B1u: goto L_00F9B1;
    case 0x00F9B5u: goto L_00F9B5;
    case 0x00F9B9u: goto L_00F9B9;
    case 0x00F9BDu: goto L_00F9BD;
    case 0x00F9C1u: goto L_00F9C1;
    case 0x00F9C5u: goto L_00F9C5;
    case 0x00F9C9u: goto L_00F9C9;
    case 0x00F9CDu: goto L_00F9CD;
    case 0x00F9D1u: goto L_00F9D1;
    case 0x00F9D5u: goto L_00F9D5;
    case 0x00F9D9u: goto L_00F9D9;
    case 0x00F9DDu: goto L_00F9DD;
    case 0x00F9E1u: goto L_00F9E1;
    case 0x00F9E5u: goto L_00F9E5;
    case 0x00F9E9u: goto L_00F9E9;
    case 0x00F9EDu: goto L_00F9ED;
    case 0x00F9F1u: goto L_00F9F1;
    case 0x00F9F5u: goto L_00F9F5;
    case 0x00F9F9u: goto L_00F9F9;
    case 0x00F9FDu: goto L_00F9FD;
    case 0x00FA01u: goto L_00FA01;
    case 0x00FA05u: goto L_00FA05;
    case 0x00FA09u: goto L_00FA09;
    case 0x00FA0Du: goto L_00FA0D;
    case 0x00FA11u: goto L_00FA11;
    case 0x00FA15u: goto L_00FA15;
    case 0x00FA19u: goto L_00FA19;
    case 0x00FA1Du: goto L_00FA1D;
    case 0x00FA21u: goto L_00FA21;
    case 0x00FA25u: goto L_00FA25;
    case 0x00FA29u: goto L_00FA29;
    case 0x00FA2Du: goto L_00FA2D;
    case 0x00FA31u: goto L_00FA31;
    case 0x00FA35u: goto L_00FA35;
    case 0x00FA39u: goto L_00FA39;
    case 0x00FA3Du: goto L_00FA3D;
    case 0x00FA41u: goto L_00FA41;
    case 0x00FA45u: goto L_00FA45;
    case 0x00FA49u: goto L_00FA49;
    case 0x00FA4Du: goto L_00FA4D;
    case 0x00FA51u: goto L_00FA51;
    case 0x00FA55u: goto L_00FA55;
    case 0x00FA59u: goto L_00FA59;
    case 0x00FA5Du: goto L_00FA5D;
    case 0x00FA61u: goto L_00FA61;
    case 0x00FA65u: goto L_00FA65;
    case 0x00FA69u: goto L_00FA69;
    case 0x00FA6Du: goto L_00FA6D;
    case 0x00FA71u: goto L_00FA71;
    case 0x00FA75u: goto L_00FA75;
    case 0x00FA79u: goto L_00FA79;
    case 0x00FA7Du: goto L_00FA7D;
    case 0x00FA81u: goto L_00FA81;
    case 0x00FA85u: goto L_00FA85;
    case 0x00FA89u: goto L_00FA89;
    case 0x00FA8Du: goto L_00FA8D;
    case 0x00FA91u: goto L_00FA91;
    case 0x00FA95u: goto L_00FA95;
    case 0x00FA99u: goto L_00FA99;
    case 0x00FA9Du: goto L_00FA9D;
    case 0x00FAA1u: goto L_00FAA1;
    case 0x00FAA5u: goto L_00FAA5;
    case 0x00FAA9u: goto L_00FAA9;
    case 0x00FAADu: goto L_00FAAD;
    case 0x00FAB1u: goto L_00FAB1;
    case 0x00FAB5u: goto L_00FAB5;
    case 0x00FAB9u: goto L_00FAB9;
    case 0x00FABDu: goto L_00FABD;
    case 0x00FAC1u: goto L_00FAC1;
    case 0x00FAC5u: goto L_00FAC5;
    case 0x00FAC9u: goto L_00FAC9;
    case 0x00FACDu: goto L_00FACD;
    case 0x00FAD1u: goto L_00FAD1;
    case 0x00FAD5u: goto L_00FAD5;
    case 0x00FAD9u: goto L_00FAD9;
    case 0x00FADDu: goto L_00FADD;
    case 0x00FAE1u: goto L_00FAE1;
    case 0x00FAE5u: goto L_00FAE5;
    case 0x00FAE9u: goto L_00FAE9;
    case 0x00FAEDu: goto L_00FAED;
    case 0x00FAF1u: goto L_00FAF1;
    case 0x00FAF5u: goto L_00FAF5;
    case 0x00FAF9u: goto L_00FAF9;
    case 0x00FAFDu: goto L_00FAFD;
    case 0x00FB01u: goto L_00FB01;
    case 0x00FB05u: goto L_00FB05;
    case 0x00FB09u: goto L_00FB09;
    case 0x00FB0Du: goto L_00FB0D;
    case 0x00FB11u: goto L_00FB11;
    case 0x00FB15u: goto L_00FB15;
    case 0x00FB19u: goto L_00FB19;
    case 0x00FB1Du: goto L_00FB1D;
    case 0x00FB21u: goto L_00FB21;
    case 0x00FB25u: goto L_00FB25;
    case 0x00FB29u: goto L_00FB29;
    case 0x00FB2Du: goto L_00FB2D;
    case 0x00FB31u: goto L_00FB31;
    case 0x00FB35u: goto L_00FB35;
    case 0x00FB39u: goto L_00FB39;
    case 0x00FB3Du: goto L_00FB3D;
    case 0x00FB41u: goto L_00FB41;
    case 0x00FB45u: goto L_00FB45;
    case 0x00FB49u: goto L_00FB49;
    case 0x00FB4Du: goto L_00FB4D;
    case 0x00FB51u: goto L_00FB51;
    case 0x00FB55u: goto L_00FB55;
    case 0x00FB59u: goto L_00FB59;
    case 0x00FB5Du: goto L_00FB5D;
    case 0x00FB61u: goto L_00FB61;
    case 0x00FB65u: goto L_00FB65;
    case 0x00FB69u: goto L_00FB69;
    case 0x00FB6Du: goto L_00FB6D;
    case 0x00FB71u: goto L_00FB71;
    case 0x00FB75u: goto L_00FB75;
    case 0x00FB79u: goto L_00FB79;
    case 0x00FB7Du: goto L_00FB7D;
    case 0x00FB81u: goto L_00FB81;
    case 0x00FB85u: goto L_00FB85;
    case 0x00FB89u: goto L_00FB89;
    case 0x00FB8Du: goto L_00FB8D;
    case 0x00FB91u: goto L_00FB91;
    case 0x00FB95u: goto L_00FB95;
    case 0x00FB99u: goto L_00FB99;
    case 0x00FB9Du: goto L_00FB9D;
    case 0x00FBA1u: goto L_00FBA1;
    case 0x00FBA5u: goto L_00FBA5;
    case 0x00FBA9u: goto L_00FBA9;
    case 0x00FBADu: goto L_00FBAD;
    case 0x00FBB1u: goto L_00FBB1;
    case 0x00FBB5u: goto L_00FBB5;
    case 0x00FBB9u: goto L_00FBB9;
    case 0x00FBBDu: goto L_00FBBD;
    case 0x00FBC1u: goto L_00FBC1;
    case 0x00FBC5u: goto L_00FBC5;
    case 0x00FBC9u: goto L_00FBC9;
    case 0x00FBCDu: goto L_00FBCD;
    case 0x00FBD1u: goto L_00FBD1;
    case 0x00FBD5u: goto L_00FBD5;
    case 0x00FBD9u: goto L_00FBD9;
    case 0x00FBDDu: goto L_00FBDD;
    case 0x00FBE1u: goto L_00FBE1;
    case 0x00FBE5u: goto L_00FBE5;
    case 0x00FBE9u: goto L_00FBE9;
    case 0x00FBEDu: goto L_00FBED;
    case 0x00FBF1u: goto L_00FBF1;
    case 0x00FBF5u: goto L_00FBF5;
    case 0x00FBF9u: goto L_00FBF9;
    case 0x00FBFDu: goto L_00FBFD;
    case 0x00FC01u: goto L_00FC01;
    case 0x00FC05u: goto L_00FC05;
    case 0x00FC09u: goto L_00FC09;
    case 0x00FC0Du: goto L_00FC0D;
    case 0x00FC11u: goto L_00FC11;
    case 0x00FC15u: goto L_00FC15;
    case 0x00FC19u: goto L_00FC19;
    case 0x00FC1Du: goto L_00FC1D;
    case 0x00FC21u: goto L_00FC21;
    case 0x00FC25u: goto L_00FC25;
    case 0x00FC29u: goto L_00FC29;
    case 0x00FC2Du: goto L_00FC2D;
    case 0x00FC31u: goto L_00FC31;
    case 0x00FC35u: goto L_00FC35;
    case 0x00FC39u: goto L_00FC39;
    case 0x00FC3Du: goto L_00FC3D;
    case 0x00FC41u: goto L_00FC41;
    case 0x00FC45u: goto L_00FC45;
    case 0x00FC49u: goto L_00FC49;
    case 0x00FC4Du: goto L_00FC4D;
    case 0x00FC51u: goto L_00FC51;
    case 0x00FC55u: goto L_00FC55;
    case 0x00FC59u: goto L_00FC59;
    case 0x00FC5Du: goto L_00FC5D;
    case 0x00FC61u: goto L_00FC61;
    case 0x00FC65u: goto L_00FC65;
    case 0x00FC69u: goto L_00FC69;
    case 0x00FC6Du: goto L_00FC6D;
    case 0x00FC71u: goto L_00FC71;
    case 0x00FC75u: goto L_00FC75;
    case 0x00FC79u: goto L_00FC79;
    case 0x00FC7Du: goto L_00FC7D;
    case 0x00FC81u: goto L_00FC81;
    case 0x00FC85u: goto L_00FC85;
    case 0x00FC89u: goto L_00FC89;
    case 0x00FC8Du: goto L_00FC8D;
    case 0x00FC91u: goto L_00FC91;
    case 0x00FC95u: goto L_00FC95;
    case 0x00FC99u: goto L_00FC99;
    case 0x00FC9Du: goto L_00FC9D;
    case 0x00FCA1u: goto L_00FCA1;
    case 0x00FCA5u: goto L_00FCA5;
    case 0x00FCA9u: goto L_00FCA9;
    case 0x00FCADu: goto L_00FCAD;
    case 0x00FCB1u: goto L_00FCB1;
    case 0x00FCB5u: goto L_00FCB5;
    case 0x00FCB9u: goto L_00FCB9;
    case 0x00FCBDu: goto L_00FCBD;
    case 0x00FCC1u: goto L_00FCC1;
    case 0x00FCC5u: goto L_00FCC5;
    case 0x00FCC9u: goto L_00FCC9;
    case 0x00FCCDu: goto L_00FCCD;
    case 0x00FCD1u: goto L_00FCD1;
    case 0x00FCD5u: goto L_00FCD5;
    case 0x00FCD9u: goto L_00FCD9;
    case 0x00FCDDu: goto L_00FCDD;
    case 0x00FCE1u: goto L_00FCE1;
    case 0x00FCE5u: goto L_00FCE5;
    case 0x00FCE9u: goto L_00FCE9;
    case 0x00FCEDu: goto L_00FCED;
    case 0x00FCF1u: goto L_00FCF1;
    case 0x00FCF5u: goto L_00FCF5;
    case 0x00FCF9u: goto L_00FCF9;
    case 0x00FCFDu: goto L_00FCFD;
    case 0x00FD01u: goto L_00FD01;
    case 0x00FD05u: goto L_00FD05;
    case 0x00FD09u: goto L_00FD09;
    case 0x00FD0Du: goto L_00FD0D;
    case 0x00FD11u: goto L_00FD11;
    case 0x00FD15u: goto L_00FD15;
    case 0x00FD19u: goto L_00FD19;
    case 0x00FD1Du: goto L_00FD1D;
    case 0x00FD21u: goto L_00FD21;
    case 0x00FD25u: goto L_00FD25;
    case 0x00FD29u: goto L_00FD29;
    case 0x00FD2Du: goto L_00FD2D;
    case 0x00FD31u: goto L_00FD31;
    case 0x00FD35u: goto L_00FD35;
    case 0x00FD39u: goto L_00FD39;
    case 0x00FD3Du: goto L_00FD3D;
    case 0x00FD41u: goto L_00FD41;
    case 0x00FD45u: goto L_00FD45;
    case 0x00FD49u: goto L_00FD49;
    case 0x00FD4Du: goto L_00FD4D;
    case 0x00FD51u: goto L_00FD51;
    case 0x00FD55u: goto L_00FD55;
    case 0x00FD59u: goto L_00FD59;
    case 0x00FD5Du: goto L_00FD5D;
    case 0x00FD61u: goto L_00FD61;
    case 0x00FD65u: goto L_00FD65;
    case 0x00FD69u: goto L_00FD69;
    case 0x00FD6Du: goto L_00FD6D;
    case 0x00FD71u: goto L_00FD71;
    case 0x00FD75u: goto L_00FD75;
    case 0x00FD79u: goto L_00FD79;
    case 0x00FD7Du: goto L_00FD7D;
    case 0x00FD81u: goto L_00FD81;
    case 0x00FD85u: goto L_00FD85;
    case 0x00FD89u: goto L_00FD89;
    case 0x00FD8Du: goto L_00FD8D;
    case 0x00FD91u: goto L_00FD91;
    case 0x00FD95u: goto L_00FD95;
    case 0x00FD99u: goto L_00FD99;
    case 0x00FD9Du: goto L_00FD9D;
    case 0x00FDA1u: goto L_00FDA1;
    case 0x00FDA5u: goto L_00FDA5;
    case 0x00FDA9u: goto L_00FDA9;
    case 0x00FDADu: goto L_00FDAD;
    case 0x00FDB1u: goto L_00FDB1;
    case 0x00FDB5u: goto L_00FDB5;
    case 0x00FDB9u: goto L_00FDB9;
    case 0x00FDBDu: goto L_00FDBD;
    case 0x00FDC1u: goto L_00FDC1;
    case 0x00FDC5u: goto L_00FDC5;
    case 0x00FDC9u: goto L_00FDC9;
    case 0x00FDCDu: goto L_00FDCD;
    case 0x00FDD1u: goto L_00FDD1;
    case 0x00FDD5u: goto L_00FDD5;
    case 0x00FDD9u: goto L_00FDD9;
    case 0x00FDDDu: goto L_00FDDD;
    case 0x00FDE1u: goto L_00FDE1;
    case 0x00FDE5u: goto L_00FDE5;
    case 0x00FDE9u: goto L_00FDE9;
    case 0x00FDEDu: goto L_00FDED;
    case 0x00FDF1u: goto L_00FDF1;
    case 0x00FDF5u: goto L_00FDF5;
    case 0x00FDF9u: goto L_00FDF9;
    case 0x00FDFDu: goto L_00FDFD;
    case 0x00FE01u: goto L_00FE01;
    case 0x00FE05u: goto L_00FE05;
    case 0x00FE09u: goto L_00FE09;
    case 0x00FE0Du: goto L_00FE0D;
    case 0x00FE11u: goto L_00FE11;
    case 0x00FE15u: goto L_00FE15;
    case 0x00FE19u: goto L_00FE19;
    case 0x00FE1Du: goto L_00FE1D;
    case 0x00FE21u: goto L_00FE21;
    case 0x00FE25u: goto L_00FE25;
    case 0x00FE29u: goto L_00FE29;
    case 0x00FE2Du: goto L_00FE2D;
    case 0x00FE31u: goto L_00FE31;
    case 0x00FE35u: goto L_00FE35;
    case 0x00FE39u: goto L_00FE39;
    case 0x00FE3Du: goto L_00FE3D;
    case 0x00FE41u: goto L_00FE41;
    case 0x00FE45u: goto L_00FE45;
    case 0x00FE49u: goto L_00FE49;
    case 0x00FE4Du: goto L_00FE4D;
    case 0x00FE51u: goto L_00FE51;
    case 0x00FE55u: goto L_00FE55;
    case 0x00FE59u: goto L_00FE59;
    case 0x00FE5Du: goto L_00FE5D;
    case 0x00FE61u: goto L_00FE61;
    case 0x00FE65u: goto L_00FE65;
    case 0x00FE69u: goto L_00FE69;
    case 0x00FE6Du: goto L_00FE6D;
    case 0x00FE71u: goto L_00FE71;
    case 0x00FE75u: goto L_00FE75;
    case 0x00FE79u: goto L_00FE79;
    case 0x00FE7Du: goto L_00FE7D;
    case 0x00FE81u: goto L_00FE81;
    case 0x00FE85u: goto L_00FE85;
    case 0x00FE89u: goto L_00FE89;
    case 0x00FE8Du: goto L_00FE8D;
    case 0x00FE91u: goto L_00FE91;
    case 0x00FE95u: goto L_00FE95;
    case 0x00FE99u: goto L_00FE99;
    case 0x00FE9Du: goto L_00FE9D;
    case 0x00FEA1u: goto L_00FEA1;
    case 0x00FEA5u: goto L_00FEA5;
    case 0x00FEA9u: goto L_00FEA9;
    case 0x00FEADu: goto L_00FEAD;
    case 0x00FEB1u: goto L_00FEB1;
    case 0x00FEB5u: goto L_00FEB5;
    case 0x00FEB9u: goto L_00FEB9;
    case 0x00FEBDu: goto L_00FEBD;
    case 0x00FEC1u: goto L_00FEC1;
    case 0x00FEC5u: goto L_00FEC5;
    case 0x00FEC9u: goto L_00FEC9;
    case 0x00FECDu: goto L_00FECD;
    case 0x00FED1u: goto L_00FED1;
    case 0x00FED5u: goto L_00FED5;
    case 0x00FED9u: goto L_00FED9;
    case 0x00FEDDu: goto L_00FEDD;
    case 0x00FEE1u: goto L_00FEE1;
    case 0x00FEE5u: goto L_00FEE5;
    case 0x00FEE9u: goto L_00FEE9;
    case 0x00FEEDu: goto L_00FEED;
    case 0x00FEF1u: goto L_00FEF1;
    case 0x00FEF5u: goto L_00FEF5;
    case 0x00FEF9u: goto L_00FEF9;
    case 0x00FEFDu: goto L_00FEFD;
    case 0x00FF01u: goto L_00FF01;
    case 0x00FF05u: goto L_00FF05;
    case 0x00FF09u: goto L_00FF09;
    case 0x00FF0Du: goto L_00FF0D;
    case 0x00FF11u: goto L_00FF11;
    case 0x00FF15u: goto L_00FF15;
    case 0x00FF19u: goto L_00FF19;
    case 0x00FF1Du: goto L_00FF1D;
    case 0x00FF21u: goto L_00FF21;
    case 0x00FF25u: goto L_00FF25;
    case 0x00FF29u: goto L_00FF29;
    case 0x00FF2Du: goto L_00FF2D;
    case 0x00FF31u: goto L_00FF31;
    case 0x00FF35u: goto L_00FF35;
    case 0x00FF39u: goto L_00FF39;
    case 0x00FF3Du: goto L_00FF3D;
    case 0x00FF41u: goto L_00FF41;
    case 0x00FF45u: goto L_00FF45;
    case 0x00FF49u: goto L_00FF49;
    case 0x00FF4Du: goto L_00FF4D;
    case 0x00FF51u: goto L_00FF51;
    case 0x00FF55u: goto L_00FF55;
    case 0x00FF59u: goto L_00FF59;
    case 0x00FF5Du: goto L_00FF5D;
    case 0x00FF61u: goto L_00FF61;
    case 0x00FF65u: goto L_00FF65;
    case 0x00FF69u: goto L_00FF69;
    case 0x00FF6Du: goto L_00FF6D;
    case 0x00FF71u: goto L_00FF71;
    case 0x00FF75u: goto L_00FF75;
    case 0x00FF79u: goto L_00FF79;
    case 0x00FF7Du: goto L_00FF7D;
    case 0x00FF81u: goto L_00FF81;
    case 0x00FF85u: goto L_00FF85;
    case 0x00FF89u: goto L_00FF89;
    case 0x00FF8Du: goto L_00FF8D;
    case 0x00FF91u: goto L_00FF91;
    case 0x00FF95u: goto L_00FF95;
    case 0x00FF99u: goto L_00FF99;
    case 0x00FF9Du: goto L_00FF9D;
    case 0x00FFA1u: goto L_00FFA1;
    case 0x00FFA5u: goto L_00FFA5;
    case 0x00FFA9u: goto L_00FFA9;
    case 0x00FFADu: goto L_00FFAD;
    case 0x00FFAFu: goto L_00FFAF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00F2AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2ADu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2ADu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F2AD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F2B1;
L_00F2B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2B1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2B1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F2B1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F2B5;
L_00F2B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2B5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2B5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F2B5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F2B9;
L_00F2B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2B9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2B9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F2B9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F2BD;
L_00F2BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2BDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2BDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F2BD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F2C1;
L_00F2C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2C1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2C1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F2C1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F2C5;
L_00F2C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2C5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2C5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F2C5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F2C9;
L_00F2C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2C9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2C9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F2C9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F2CD;
L_00F2CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2CDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2CDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F2CD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F2D1;
L_00F2D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2D1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2D1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F2D1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F2D5;
L_00F2D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2D5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2D5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F2D5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F2D9;
L_00F2D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2D9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2D9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F2D9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F2DD;
L_00F2DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2DDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2DDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F2DD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F2E1;
L_00F2E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2E1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2E1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F2E1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F2E5;
L_00F2E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2E5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2E5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F2E5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F2E9;
L_00F2E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2E9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2E9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F2E9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F2ED;
L_00F2ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2EDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2EDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F2ED SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F2F1;
L_00F2F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F2F1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F2F5;
L_00F2F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F2F5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F2F9;
L_00F2F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F2F9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F2FD;
L_00F2FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2FDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2FDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F2FD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F301;
L_00F301:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF301u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF301u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF301u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F301 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F305;
L_00F305:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF305u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF305u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF305u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F305 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F309;
L_00F309:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF309u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF309u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF309u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F309 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F30D;
L_00F30D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF30Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF30Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF30Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F30D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F311;
L_00F311:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF311u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF311u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF311u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F311 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F315;
L_00F315:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF315u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF315u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF315u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F315 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F319;
L_00F319:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF319u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF319u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF319u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F319 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F31D;
L_00F31D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF31Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF31Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF31Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F31D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F321;
L_00F321:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF321u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF321u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF321u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F321 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F325;
L_00F325:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF325u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF325u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF325u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F325 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F329;
L_00F329:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF329u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF329u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF329u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F329 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F32D;
L_00F32D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF32Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF32Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF32Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F32D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F331;
L_00F331:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF331u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF331u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF331u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F331 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F335;
L_00F335:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF335u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF335u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF335u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F335 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F339;
L_00F339:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF339u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF339u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF339u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F339 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F33D;
L_00F33D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF33Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF33Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF33Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F33D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F341;
L_00F341:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF341u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF341u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF341u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F341 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F345;
L_00F345:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF345u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF345u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF345u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F345 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F349;
L_00F349:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF349u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF349u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF349u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F349 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F34D;
L_00F34D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF34Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF34Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF34Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F34D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F351;
L_00F351:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF351u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF351u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF351u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F351 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F355;
L_00F355:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF355u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF355u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF355u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F355 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F359;
L_00F359:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF359u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF359u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF359u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F359 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F35D;
L_00F35D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF35Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF35Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF35Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F35D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F361;
L_00F361:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF361u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF361u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF361u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F361 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F365;
L_00F365:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF365u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF365u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF365u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F365 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F369;
L_00F369:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF369u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF369u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF369u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F369 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F36D;
L_00F36D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF36Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF36Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF36Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F36D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F371;
L_00F371:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF371u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF371u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF371u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F371 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F375;
L_00F375:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF375u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF375u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF375u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F375 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F379;
L_00F379:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF379u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF379u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF379u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F379 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F37D;
L_00F37D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF37Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF37Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF37Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F37D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F381;
L_00F381:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF381u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF381u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF381u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F381 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F385;
L_00F385:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF385u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF385u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF385u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F385 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F389;
L_00F389:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF389u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF389u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF389u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F389 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F38D;
L_00F38D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF38Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF38Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF38Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F38D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F391;
L_00F391:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF391u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF391u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF391u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F391 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F395;
L_00F395:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF395u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF395u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF395u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F395 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F399;
L_00F399:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF399u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF399u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF399u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F399 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F39D;
L_00F39D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF39Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF39Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF39Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F39D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F3A1;
L_00F3A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3A1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3A1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3A1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F3A5;
L_00F3A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3A5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3A5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3A5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F3A9;
L_00F3A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3A9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3A9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3A9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F3AD;
L_00F3AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3ADu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3ADu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3AD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F3B1;
L_00F3B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3B1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3B1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3B1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F3B5;
L_00F3B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3B5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3B5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3B5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F3B9;
L_00F3B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3B9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3B9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3B9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F3BD;
L_00F3BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3BDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3BDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3BD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F3C1;
L_00F3C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3C1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3C1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3C1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F3C5;
L_00F3C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3C5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3C5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3C5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F3C9;
L_00F3C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3C9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3C9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3C9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F3CD;
L_00F3CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3CDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3CDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3CD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F3D1;
L_00F3D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3D1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3D1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3D1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F3D5;
L_00F3D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3D5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3D5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3D5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F3D9;
L_00F3D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3D9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3D9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3D9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F3DD;
L_00F3DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3DDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3DDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3DD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F3E1;
L_00F3E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3E1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3E1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3E1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F3E5;
L_00F3E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3E5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3E5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3E5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F3E9;
L_00F3E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3E9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3E9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3E9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F3ED;
L_00F3ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3EDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3EDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3ED SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F3F1;
L_00F3F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3F1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3F1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3F1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F3F5;
L_00F3F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3F5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3F5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3F5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F3F9;
L_00F3F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3F9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3F9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3F9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F3FD;
L_00F3FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF3FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF3FDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF3FDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F3FD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F401;
L_00F401:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF401u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF401u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF401u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F401 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F405;
L_00F405:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF405u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF405u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF405u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F405 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F409;
L_00F409:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF409u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF409u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF409u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F409 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F40D;
L_00F40D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF40Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF40Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF40Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F40D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F411;
L_00F411:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF411u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF411u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF411u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F411 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F415;
L_00F415:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF415u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF415u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF415u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F415 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F419;
L_00F419:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF419u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF419u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF419u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F419 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F41D;
L_00F41D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF41Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF41Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF41Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F41D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F421;
L_00F421:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF421u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF421u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF421u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F421 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F425;
L_00F425:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF425u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF425u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF425u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F425 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F429;
L_00F429:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF429u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF429u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF429u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F429 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F42D;
L_00F42D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF42Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF42Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF42Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F42D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F431;
L_00F431:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF431u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF431u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF431u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F431 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F435;
L_00F435:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF435u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF435u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF435u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F435 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F439;
L_00F439:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF439u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF439u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF439u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F439 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F43D;
L_00F43D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF43Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF43Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF43Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F43D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F441;
L_00F441:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF441u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF441u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF441u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F441 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F445;
L_00F445:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF445u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF445u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF445u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F445 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F449;
L_00F449:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF449u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF449u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF449u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F449 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F44D;
L_00F44D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF44Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF44Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF44Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F44D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F451;
L_00F451:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF451u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF451u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF451u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F451 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F455;
L_00F455:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF455u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF455u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF455u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F455 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F459;
L_00F459:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF459u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF459u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF459u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F459 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F45D;
L_00F45D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF45Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF45Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF45Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F45D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F461;
L_00F461:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF461u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF461u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF461u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F461 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F465;
L_00F465:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF465u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF465u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF465u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F465 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F469;
L_00F469:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF469u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF469u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF469u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F469 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F46D;
L_00F46D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF46Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF46Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF46Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F46D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F471;
L_00F471:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF471u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF471u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF471u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F471 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F475;
L_00F475:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF475u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF475u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF475u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F475 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F479;
L_00F479:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF479u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF479u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF479u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F479 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F47D;
L_00F47D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF47Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF47Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF47Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F47D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F481;
L_00F481:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF481u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF481u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF481u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F481 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F485;
L_00F485:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF485u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF485u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF485u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F485 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F489;
L_00F489:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF489u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF489u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF489u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F489 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F48D;
L_00F48D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF48Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF48Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF48Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F48D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F491;
L_00F491:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF491u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF491u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF491u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F491 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F495;
L_00F495:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF495u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF495u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF495u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F495 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F499;
L_00F499:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF499u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF499u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF499u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F499 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F49D;
L_00F49D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF49Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF49Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF49Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F49D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F4A1;
L_00F4A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF4A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF4A1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF4A1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F4A1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F4A5;
L_00F4A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF4A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF4A5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF4A5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F4A5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F4A9;
L_00F4A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF4A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF4A9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF4A9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F4A9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F4AD;
L_00F4AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF4ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF4ADu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF4ADu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F4AD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F4B1;
L_00F4B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF4B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF4B1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF4B1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F4B1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F4B5;
L_00F4B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF4B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF4B5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF4B5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F4B5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F4B9;
L_00F4B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF4B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF4B9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF4B9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F4B9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F4BD;
L_00F4BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF4BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF4BDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF4BDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F4BD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F4C1;
L_00F4C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF4C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF4C1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF4C1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F4C1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F4C5;
L_00F4C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF4C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF4C5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF4C5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F4C5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F4C9;
L_00F4C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF4C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF4C9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF4C9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F4C9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F4CD;
L_00F4CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF4CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF4CDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF4CDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F4CD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F4D1;
L_00F4D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF4D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF4D1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF4D1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F4D1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F4D5;
L_00F4D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF4D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF4D5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF4D5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F4D5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F4D9;
L_00F4D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF4D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF4D9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF4D9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F4D9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F4DD;
L_00F4DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF4DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF4DDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF4DDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F4DD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F4E1;
L_00F4E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF4E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF4E1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF4E1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F4E1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F4E5;
L_00F4E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF4E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF4E5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF4E5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F4E5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F4E9;
L_00F4E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF4E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF4E9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF4E9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F4E9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F4ED;
L_00F4ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF4EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF4EDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF4EDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F4ED SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F4F1;
L_00F4F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF4F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF4F1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF4F1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F4F1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F4F5;
L_00F4F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF4F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF4F5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF4F5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F4F5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F4F9;
L_00F4F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF4F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF4F9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF4F9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F4F9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F4FD;
L_00F4FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF4FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF4FDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF4FDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F4FD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F501;
L_00F501:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF501u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF501u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF501u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F501 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F505;
L_00F505:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF505u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF505u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF505u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F505 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F509;
L_00F509:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF509u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF509u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF509u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F509 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F50D;
L_00F50D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF50Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF50Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF50Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F50D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F511;
L_00F511:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF511u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF511u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF511u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F511 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F515;
L_00F515:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF515u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF515u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF515u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F515 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F519;
L_00F519:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF519u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF519u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF519u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F519 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F51D;
L_00F51D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF51Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF51Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF51Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F51D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F521;
L_00F521:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF521u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF521u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF521u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F521 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F525;
L_00F525:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF525u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF525u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF525u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F525 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F529;
L_00F529:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF529u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF529u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF529u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F529 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F52D;
L_00F52D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF52Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF52Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF52Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F52D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F531;
L_00F531:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF531u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF531u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF531u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F531 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F535;
L_00F535:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF535u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF535u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF535u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F535 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F539;
L_00F539:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF539u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF539u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF539u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F539 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F53D;
L_00F53D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF53Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF53Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF53Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F53D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F541;
L_00F541:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF541u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF541u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF541u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F541 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F545;
L_00F545:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF545u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF545u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF545u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F545 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F549;
L_00F549:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF549u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF549u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF549u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F549 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F54D;
L_00F54D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF54Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF54Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF54Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F54D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F551;
L_00F551:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF551u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF551u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF551u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F551 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F555;
L_00F555:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF555u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF555u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF555u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F555 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F559;
L_00F559:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF559u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF559u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF559u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F559 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F55D;
L_00F55D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF55Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF55Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF55Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F55D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F561;
L_00F561:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF561u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF561u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF561u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F561 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F565;
L_00F565:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF565u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF565u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF565u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F565 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F569;
L_00F569:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF569u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF569u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF569u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F569 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F56D;
L_00F56D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF56Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF56Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF56Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F56D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F571;
L_00F571:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF571u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF571u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF571u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F571 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F575;
L_00F575:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF575u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF575u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF575u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F575 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F579;
L_00F579:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF579u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF579u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF579u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F579 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F57D;
L_00F57D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF57Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF57Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF57Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F57D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F581;
L_00F581:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF581u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF581u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF581u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F581 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F585;
L_00F585:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF585u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF585u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF585u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F585 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F589;
L_00F589:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF589u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF589u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF589u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F589 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F58D;
L_00F58D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF58Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF58Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF58Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F58D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F591;
L_00F591:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF591u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF591u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF591u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F591 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F595;
L_00F595:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF595u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF595u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF595u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F595 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F599;
L_00F599:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF599u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF599u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF599u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F599 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F59D;
L_00F59D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF59Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF59Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF59Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F59D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F5A1;
L_00F5A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF5A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF5A1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF5A1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F5A1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F5A5;
L_00F5A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF5A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF5A5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF5A5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F5A5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F5A9;
L_00F5A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF5A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF5A9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF5A9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F5A9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F5AD;
L_00F5AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF5ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF5ADu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF5ADu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F5AD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F5B1;
L_00F5B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF5B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF5B1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF5B1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F5B1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F5B5;
L_00F5B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF5B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF5B5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF5B5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F5B5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F5B9;
L_00F5B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF5B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF5B9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF5B9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F5B9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F5BD;
L_00F5BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF5BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF5BDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF5BDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F5BD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F5C1;
L_00F5C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF5C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF5C1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF5C1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F5C1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F5C5;
L_00F5C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF5C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF5C5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF5C5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F5C5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F5C9;
L_00F5C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF5C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF5C9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF5C9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F5C9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F5CD;
L_00F5CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF5CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF5CDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF5CDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F5CD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F5D1;
L_00F5D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF5D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF5D1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF5D1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F5D1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F5D5;
L_00F5D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF5D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF5D5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF5D5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F5D5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F5D9;
L_00F5D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF5D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF5D9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF5D9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F5D9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F5DD;
L_00F5DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF5DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF5DDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF5DDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F5DD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F5E1;
L_00F5E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF5E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF5E1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF5E1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F5E1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F5E5;
L_00F5E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF5E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF5E5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF5E5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F5E5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F5E9;
L_00F5E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF5E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF5E9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF5E9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F5E9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F5ED;
L_00F5ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF5EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF5EDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF5EDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F5ED SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F5F1;
L_00F5F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF5F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF5F1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF5F1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F5F1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F5F5;
L_00F5F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF5F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF5F5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF5F5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F5F5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F5F9;
L_00F5F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF5F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF5F9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF5F9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F5F9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F5FD;
L_00F5FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF5FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF5FDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF5FDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F5FD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F601;
L_00F601:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF601u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF601u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF601u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F601 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F605;
L_00F605:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF605u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF605u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF605u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F605 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F609;
L_00F609:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF609u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF609u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF609u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F609 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F60D;
L_00F60D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF60Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF60Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF60Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F60D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F611;
L_00F611:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF611u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF611u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF611u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F611 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F615;
L_00F615:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF615u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF615u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF615u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F615 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F619;
L_00F619:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF619u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF619u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF619u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F619 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F61D;
L_00F61D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF61Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF61Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF61Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F61D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F621;
L_00F621:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF621u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF621u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF621u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F621 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F625;
L_00F625:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF625u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF625u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF625u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F625 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F629;
L_00F629:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF629u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF629u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF629u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F629 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F62D;
L_00F62D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF62Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF62Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF62Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F62D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F631;
L_00F631:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF631u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF631u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF631u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F631 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F635;
L_00F635:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF635u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF635u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF635u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F635 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F639;
L_00F639:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF639u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF639u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF639u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F639 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F63D;
L_00F63D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF63Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF63Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF63Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F63D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F641;
L_00F641:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF641u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF641u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF641u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F641 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F645;
L_00F645:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF645u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF645u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF645u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F645 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F649;
L_00F649:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF649u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF649u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF649u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F649 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F64D;
L_00F64D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF64Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF64Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF64Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F64D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F651;
L_00F651:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF651u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF651u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF651u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F651 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F655;
L_00F655:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF655u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF655u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF655u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F655 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F659;
L_00F659:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF659u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF659u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF659u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F659 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F65D;
L_00F65D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF65Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF65Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF65Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F65D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F661;
L_00F661:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF661u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF661u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF661u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F661 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F665;
L_00F665:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF665u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF665u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF665u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F665 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F669;
L_00F669:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF669u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF669u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF669u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F669 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F66D;
L_00F66D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF66Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF66Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF66Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F66D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F671;
L_00F671:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF671u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF671u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF671u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F671 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F675;
L_00F675:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF675u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF675u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF675u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F675 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F679;
L_00F679:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF679u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF679u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF679u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F679 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F67D;
L_00F67D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF67Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF67Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF67Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F67D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F681;
L_00F681:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF681u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF681u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF681u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F681 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F685;
L_00F685:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF685u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF685u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF685u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F685 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F689;
L_00F689:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF689u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF689u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF689u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F689 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F68D;
L_00F68D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF68Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF68Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF68Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F68D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F691;
L_00F691:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF691u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF691u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF691u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F691 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F695;
L_00F695:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF695u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF695u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF695u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F695 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F699;
L_00F699:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF699u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF699u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF699u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F699 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F69D;
L_00F69D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF69Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF69Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF69Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F69D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F6A1;
L_00F6A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6A1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6A1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F6A1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F6A5;
L_00F6A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6A5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6A5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F6A5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F6A9;
L_00F6A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6A9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6A9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F6A9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F6AD;
L_00F6AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6ADu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6ADu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F6AD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F6B1;
L_00F6B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F6B1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F6B5;
L_00F6B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F6B5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F6B9;
L_00F6B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F6B9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F6BD;
L_00F6BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6BDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6BDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F6BD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F6C1;
L_00F6C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F6C1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F6C5;
L_00F6C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F6C5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F6C9;
L_00F6C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F6C9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F6CD;
L_00F6CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6CDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6CDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F6CD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F6D1;
L_00F6D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6D1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6D1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F6D1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F6D5;
L_00F6D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6D5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6D5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F6D5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F6D9;
L_00F6D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6D9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6D9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F6D9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F6DD;
L_00F6DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6DDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6DDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F6DD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F6E1;
L_00F6E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6E1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6E1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F6E1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F6E5;
L_00F6E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6E5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6E5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F6E5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F6E9;
L_00F6E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6E9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6E9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F6E9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F6ED;
L_00F6ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6EDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6EDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F6ED SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F6F1;
L_00F6F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6F1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6F1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F6F1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F6F5;
L_00F6F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6F5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6F5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F6F5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F6F9;
L_00F6F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6F9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6F9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F6F9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F6FD;
L_00F6FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6FDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6FDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F6FD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F701;
L_00F701:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF701u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF701u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF701u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F701 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F705;
L_00F705:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF705u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF705u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF705u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F705 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F709;
L_00F709:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF709u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF709u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF709u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F709 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F70D;
L_00F70D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF70Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF70Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF70Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F70D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F711;
L_00F711:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF711u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF711u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF711u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F711 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F715;
L_00F715:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF715u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF715u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF715u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F715 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F719;
L_00F719:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF719u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF719u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF719u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F719 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F71D;
L_00F71D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF71Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF71Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF71Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F71D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F721;
L_00F721:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF721u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF721u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF721u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F721 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F725;
L_00F725:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF725u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF725u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF725u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F725 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F729;
L_00F729:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF729u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF729u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF729u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F729 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F72D;
L_00F72D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF72Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF72Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF72Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F72D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F731;
L_00F731:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF731u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF731u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF731u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F731 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F735;
L_00F735:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF735u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF735u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF735u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F735 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F739;
L_00F739:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF739u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF739u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF739u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F739 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F73D;
L_00F73D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF73Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF73Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF73Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F73D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F741;
L_00F741:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF741u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF741u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF741u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F741 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F745;
L_00F745:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF745u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF745u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF745u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F745 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F749;
L_00F749:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF749u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF749u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF749u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F749 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F74D;
L_00F74D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF74Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF74Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF74Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F74D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F751;
L_00F751:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF751u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF751u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF751u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F751 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F755;
L_00F755:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF755u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF755u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF755u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F755 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F759;
L_00F759:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF759u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF759u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF759u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F759 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F75D;
L_00F75D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF75Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF75Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF75Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F75D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F761;
L_00F761:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF761u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF761u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF761u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F761 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F765;
L_00F765:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF765u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF765u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF765u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F765 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F769;
L_00F769:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF769u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF769u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF769u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F769 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F76D;
L_00F76D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF76Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF76Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF76Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F76D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F771;
L_00F771:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF771u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF771u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF771u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F771 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F775;
L_00F775:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF775u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF775u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF775u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F775 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F779;
L_00F779:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF779u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF779u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF779u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F779 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F77D;
L_00F77D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF77Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF77Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF77Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F77D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F781;
L_00F781:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF781u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF781u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF781u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F781 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F785;
L_00F785:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF785u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF785u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF785u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F785 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F789;
L_00F789:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF789u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF789u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF789u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F789 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F78D;
L_00F78D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF78Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF78Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F78D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F791;
L_00F791:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF791u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF791u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF791u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F791 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F795;
L_00F795:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF795u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF795u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF795u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F795 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F799;
L_00F799:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF799u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF799u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF799u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F799 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F79D;
L_00F79D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF79Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF79Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F79D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F7A1;
L_00F7A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7A1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7A1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F7A1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F7A5;
L_00F7A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7A5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7A5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F7A5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F7A9;
L_00F7A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7A9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7A9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F7A9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F7AD;
L_00F7AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7ADu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7ADu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F7AD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F7B1;
L_00F7B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F7B1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F7B5;
L_00F7B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F7B5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F7B9;
L_00F7B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F7B9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F7BD;
L_00F7BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7BDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7BDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F7BD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F7C1;
L_00F7C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7C1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7C1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F7C1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F7C5;
L_00F7C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7C5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7C5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F7C5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F7C9;
L_00F7C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7C9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7C9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F7C9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F7CD;
L_00F7CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7CDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7CDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F7CD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F7D1;
L_00F7D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F7D1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F7D5;
L_00F7D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F7D5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F7D9;
L_00F7D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F7D9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F7DD;
L_00F7DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F7DD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F7E1;
L_00F7E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F7E1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F7E5;
L_00F7E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F7E5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F7E9;
L_00F7E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F7E9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F7ED;
L_00F7ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7EDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7EDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F7ED SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F7F1;
L_00F7F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F7F1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F7F5;
L_00F7F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F7F5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F7F9;
L_00F7F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F7F9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F7FD;
L_00F7FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7FDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7FDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F7FD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F801;
L_00F801:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF801u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF801u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF801u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F801 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F805;
L_00F805:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF805u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF805u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF805u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F805 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F809;
L_00F809:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF809u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF809u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF809u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F809 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F80D;
L_00F80D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF80Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF80Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF80Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F80D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F811;
L_00F811:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF811u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF811u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF811u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F811 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F815;
L_00F815:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF815u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF815u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF815u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F815 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F819;
L_00F819:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF819u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF819u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF819u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F819 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F81D;
L_00F81D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF81Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF81Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF81Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F81D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F821;
L_00F821:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF821u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF821u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF821u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F821 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F825;
L_00F825:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF825u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF825u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF825u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F825 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F829;
L_00F829:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF829u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF829u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF829u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F829 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F82D;
L_00F82D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF82Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF82Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF82Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F82D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F831;
L_00F831:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF831u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF831u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF831u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F831 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F835;
L_00F835:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF835u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF835u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF835u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F835 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F839;
L_00F839:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF839u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF839u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF839u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F839 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F83D;
L_00F83D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF83Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF83Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF83Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F83D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F841;
L_00F841:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF841u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF841u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF841u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F841 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F845;
L_00F845:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF845u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF845u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF845u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F845 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F849;
L_00F849:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF849u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF849u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF849u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F849 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F84D;
L_00F84D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF84Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF84Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF84Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F84D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F851;
L_00F851:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF851u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF851u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF851u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F851 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F855;
L_00F855:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF855u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF855u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF855u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F855 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F859;
L_00F859:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF859u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF859u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF859u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F859 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F85D;
L_00F85D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF85Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF85Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF85Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F85D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F861;
L_00F861:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF861u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF861u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF861u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F861 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F865;
L_00F865:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF865u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF865u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF865u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F865 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F869;
L_00F869:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF869u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF869u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF869u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F869 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F86D;
L_00F86D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF86Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F86D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F871;
L_00F871:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF871u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF871u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF871u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F871 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F875;
L_00F875:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF875u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF875u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF875u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F875 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F879;
L_00F879:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF879u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF879u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF879u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F879 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F87D;
L_00F87D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF87Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF87Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF87Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F87D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F881;
L_00F881:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF881u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF881u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF881u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F881 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F885;
L_00F885:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF885u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF885u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF885u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F885 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F889;
L_00F889:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF889u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF889u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF889u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F889 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F88D;
L_00F88D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF88Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF88Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF88Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F88D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F891;
L_00F891:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF891u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF891u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF891u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F891 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F895;
L_00F895:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF895u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF895u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF895u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F895 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F899;
L_00F899:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF899u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF899u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF899u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F899 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F89D;
L_00F89D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF89Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF89Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF89Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F89D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F8A1;
L_00F8A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F8A1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F8A5;
L_00F8A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F8A5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F8A9;
L_00F8A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F8A9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F8AD;
L_00F8AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8ADu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8ADu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F8AD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F8B1;
L_00F8B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F8B1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F8B5;
L_00F8B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F8B5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F8B9;
L_00F8B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F8B9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F8BD;
L_00F8BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8BDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8BDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F8BD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F8C1;
L_00F8C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8C1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8C1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F8C1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F8C5;
L_00F8C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8C5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8C5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F8C5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F8C9;
L_00F8C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8C9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8C9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F8C9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F8CD;
L_00F8CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8CDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8CDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F8CD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F8D1;
L_00F8D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F8D1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F8D5;
L_00F8D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F8D5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F8D9;
L_00F8D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F8D9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F8DD;
L_00F8DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8DDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8DDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F8DD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F8E1;
L_00F8E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8E1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8E1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F8E1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F8E5;
L_00F8E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8E5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8E5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F8E5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F8E9;
L_00F8E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8E9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8E9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F8E9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F8ED;
L_00F8ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8EDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8EDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F8ED SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F8F1;
L_00F8F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8F1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8F1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F8F1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F8F5;
L_00F8F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8F5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8F5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F8F5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F8F9;
L_00F8F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8F9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8F9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F8F9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F8FD;
L_00F8FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8FDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8FDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F8FD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F901;
L_00F901:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF901u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF901u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF901u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F901 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F905;
L_00F905:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF905u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF905u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF905u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F905 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F909;
L_00F909:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF909u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF909u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF909u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F909 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F90D;
L_00F90D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF90Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF90Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF90Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F90D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F911;
L_00F911:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF911u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF911u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF911u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F911 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F915;
L_00F915:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF915u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF915u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF915u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F915 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F919;
L_00F919:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF919u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF919u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF919u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F919 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F91D;
L_00F91D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF91Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF91Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF91Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F91D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F921;
L_00F921:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF921u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF921u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF921u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F921 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F925;
L_00F925:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF925u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF925u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF925u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F925 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F929;
L_00F929:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF929u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF929u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF929u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F929 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F92D;
L_00F92D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF92Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF92Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF92Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F92D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F931;
L_00F931:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF931u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF931u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF931u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F931 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F935;
L_00F935:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF935u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF935u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF935u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F935 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F939;
L_00F939:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF939u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF939u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF939u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F939 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F93D;
L_00F93D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF93Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF93Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF93Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F93D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F941;
L_00F941:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF941u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF941u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF941u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F941 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F945;
L_00F945:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF945u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF945u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF945u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F945 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F949;
L_00F949:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF949u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF949u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF949u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F949 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F94D;
L_00F94D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF94Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF94Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF94Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F94D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F951;
L_00F951:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF951u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF951u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF951u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F951 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F955;
L_00F955:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF955u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF955u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF955u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F955 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F959;
L_00F959:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF959u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF959u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF959u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F959 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F95D;
L_00F95D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF95Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF95Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF95Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F95D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F961;
L_00F961:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF961u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF961u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF961u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F961 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F965;
L_00F965:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF965u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF965u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF965u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F965 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F969;
L_00F969:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF969u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF969u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF969u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F969 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F96D;
L_00F96D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF96Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF96Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF96Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F96D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F971;
L_00F971:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF971u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF971u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF971u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F971 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F975;
L_00F975:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF975u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF975u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF975u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F975 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F979;
L_00F979:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF979u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF979u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF979u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F979 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F97D;
L_00F97D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF97Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF97Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF97Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F97D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F981;
L_00F981:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF981u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF981u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF981u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F981 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F985;
L_00F985:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF985u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF985u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF985u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F985 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F989;
L_00F989:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF989u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF989u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF989u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F989 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F98D;
L_00F98D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF98Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF98Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF98Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F98D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F991;
L_00F991:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF991u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF991u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF991u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F991 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F995;
L_00F995:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF995u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF995u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF995u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F995 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F999;
L_00F999:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF999u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF999u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF999u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F999 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F99D;
L_00F99D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF99Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF99Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF99Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F99D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F9A1;
L_00F9A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF9A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF9A1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF9A1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F9A1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F9A5;
L_00F9A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF9A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF9A5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF9A5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F9A5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F9A9;
L_00F9A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF9A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF9A9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF9A9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F9A9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F9AD;
L_00F9AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF9ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF9ADu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF9ADu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F9AD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F9B1;
L_00F9B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF9B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF9B1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF9B1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F9B1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F9B5;
L_00F9B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF9B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF9B5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF9B5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F9B5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F9B9;
L_00F9B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF9B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF9B9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF9B9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F9B9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F9BD;
L_00F9BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF9BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF9BDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF9BDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F9BD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F9C1;
L_00F9C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF9C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF9C1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF9C1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F9C1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F9C5;
L_00F9C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF9C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF9C5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF9C5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F9C5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F9C9;
L_00F9C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF9C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF9C9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF9C9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F9C9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F9CD;
L_00F9CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF9CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF9CDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF9CDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F9CD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F9D1;
L_00F9D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF9D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF9D1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF9D1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F9D1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F9D5;
L_00F9D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF9D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF9D5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF9D5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F9D5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F9D9;
L_00F9D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF9D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF9D9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF9D9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F9D9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F9DD;
L_00F9DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF9DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF9DDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF9DDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F9DD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F9E1;
L_00F9E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF9E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF9E1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF9E1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F9E1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F9E5;
L_00F9E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF9E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF9E5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF9E5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F9E5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F9E9;
L_00F9E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF9E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF9E9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF9E9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F9E9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F9ED;
L_00F9ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF9EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF9EDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF9EDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F9ED SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F9F1;
L_00F9F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF9F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF9F1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF9F1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F9F1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F9F5;
L_00F9F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF9F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF9F5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF9F5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F9F5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F9F9;
L_00F9F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF9F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF9F9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF9F9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F9F9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00F9FD;
L_00F9FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF9FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF9FDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF9FDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00F9FD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FA01;
L_00FA01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA01u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA01u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FA01 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FA05;
L_00FA05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA05u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA05u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FA05 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FA09;
L_00FA09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA09u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA09u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FA09 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FA0D;
L_00FA0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA0Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA0Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FA0D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FA11;
L_00FA11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA11u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA11u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FA11 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FA15;
L_00FA15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA15u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA15u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FA15 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FA19;
L_00FA19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA19u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA19u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FA19 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FA1D;
L_00FA1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA1Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA1Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FA1D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FA21;
L_00FA21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA21u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA21u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FA21 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FA25;
L_00FA25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA25u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA25u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FA25 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FA29;
L_00FA29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA29u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA29u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FA29 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FA2D;
L_00FA2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA2Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA2Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FA2D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FA31;
L_00FA31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA31u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA31u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FA31 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FA35;
L_00FA35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA35u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA35u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FA35 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FA39;
L_00FA39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA39u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA39u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FA39 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FA3D;
L_00FA3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA3Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA3Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FA3D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FA41;
L_00FA41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA41u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA41u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FA41 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FA45;
L_00FA45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA45u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA45u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FA45 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FA49;
L_00FA49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA49u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA49u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FA49 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FA4D;
L_00FA4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA4Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA4Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FA4D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FA51;
L_00FA51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA51u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA51u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FA51 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FA55;
L_00FA55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA55u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA55u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FA55 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FA59;
L_00FA59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA59u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA59u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FA59 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FA5D;
L_00FA5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA5Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA5Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FA5D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FA61;
L_00FA61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA61u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA61u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FA61 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FA65;
L_00FA65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA65u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA65u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FA65 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FA69;
L_00FA69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA69u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA69u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FA69 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FA6D;
L_00FA6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA6Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA6Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FA6D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FA71;
L_00FA71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA71u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA71u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FA71 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FA75;
L_00FA75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA75u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA75u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FA75 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FA79;
L_00FA79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA79u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA79u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FA79 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FA7D;
L_00FA7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA7Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA7Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FA7D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FA81;
L_00FA81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA81u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA81u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FA81 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FA85;
L_00FA85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA85u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA85u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FA85 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FA89;
L_00FA89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA89u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA89u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FA89 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FA8D;
L_00FA8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA8Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA8Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FA8D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FA91;
L_00FA91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA91u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA91u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FA91 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FA95;
L_00FA95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA95u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA95u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FA95 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FA99;
L_00FA99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA99u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA99u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FA99 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FA9D;
L_00FA9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA9Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA9Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FA9D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FAA1;
L_00FAA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAA1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAA1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FAA1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FAA5;
L_00FAA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAA5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAA5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FAA5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FAA9;
L_00FAA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAA9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAA9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FAA9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FAAD;
L_00FAAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAADu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAADu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FAAD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FAB1;
L_00FAB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAB1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAB1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FAB1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FAB5;
L_00FAB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAB5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAB5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FAB5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FAB9;
L_00FAB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAB9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAB9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FAB9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FABD;
L_00FABD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFABDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFABDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFABDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FABD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FAC1;
L_00FAC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAC1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAC1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FAC1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FAC5;
L_00FAC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAC5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAC5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FAC5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FAC9;
L_00FAC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAC9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAC9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FAC9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FACD;
L_00FACD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFACDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFACDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFACDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FACD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FAD1;
L_00FAD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAD1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAD1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FAD1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FAD5;
L_00FAD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAD5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAD5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FAD5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FAD9;
L_00FAD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAD9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAD9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FAD9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FADD;
L_00FADD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFADDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFADDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFADDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FADD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FAE1;
L_00FAE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAE1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAE1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FAE1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FAE5;
L_00FAE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAE5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAE5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FAE5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FAE9;
L_00FAE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAE9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAE9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FAE9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FAED;
L_00FAED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAEDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAEDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FAED SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FAF1;
L_00FAF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAF1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAF1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FAF1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FAF5;
L_00FAF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAF5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAF5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FAF5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FAF9;
L_00FAF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAF9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAF9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FAF9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FAFD;
L_00FAFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAFDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAFDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FAFD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FB01;
L_00FB01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB01u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB01u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB01 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FB05;
L_00FB05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB05u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB05u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB05 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FB09;
L_00FB09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB09u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB09u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB09 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FB0D;
L_00FB0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB0Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB0Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB0D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FB11;
L_00FB11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB11u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB11u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB11 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FB15;
L_00FB15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB15u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB15u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB15 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FB19;
L_00FB19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB19u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB19u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB19 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FB1D;
L_00FB1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB1D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FB21;
L_00FB21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB21u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB21u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB21 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FB25;
L_00FB25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB25u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB25u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB25 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FB29;
L_00FB29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB29u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB29u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB29 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FB2D;
L_00FB2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB2D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FB31;
L_00FB31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB31u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB31u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB31 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FB35;
L_00FB35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB35u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB35u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB35 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FB39;
L_00FB39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB39u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB39u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB39 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FB3D;
L_00FB3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB3Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB3Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB3D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FB41;
L_00FB41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB41u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB41u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB41 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FB45;
L_00FB45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB45u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB45u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB45 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FB49;
L_00FB49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB49u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB49u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB49 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FB4D;
L_00FB4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB4Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB4Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB4D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FB51;
L_00FB51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB51u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB51u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB51 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FB55;
L_00FB55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB55u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB55u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB55 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FB59;
L_00FB59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB59u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB59u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB59 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FB5D;
L_00FB5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB5Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB5Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB5D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FB61;
L_00FB61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB61u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB61u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB61 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FB65;
L_00FB65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB65u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB65u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB65 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FB69;
L_00FB69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB69u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB69u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB69 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FB6D;
L_00FB6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB6Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB6Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB6D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FB71;
L_00FB71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB71u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB71u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB71 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FB75;
L_00FB75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB75u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB75u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB75 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FB79;
L_00FB79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB79u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB79u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB79 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FB7D;
L_00FB7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB7Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB7Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB7D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FB81;
L_00FB81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB81u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB81u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB81 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FB85;
L_00FB85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB85u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB85u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB85 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FB89;
L_00FB89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB89u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB89u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB89 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FB8D;
L_00FB8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB8Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB8Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB8D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FB91;
L_00FB91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB91u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB91u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB91 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FB95;
L_00FB95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB95u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB95u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB95 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FB99;
L_00FB99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB99u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB99u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB99 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FB9D;
L_00FB9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB9Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB9Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FB9D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FBA1;
L_00FBA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFBA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFBA1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFBA1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FBA1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FBA5;
L_00FBA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFBA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFBA5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFBA5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FBA5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FBA9;
L_00FBA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFBA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFBA9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFBA9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FBA9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FBAD;
L_00FBAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFBADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFBADu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFBADu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FBAD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FBB1;
L_00FBB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFBB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFBB1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFBB1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FBB1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FBB5;
L_00FBB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFBB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFBB5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFBB5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FBB5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FBB9;
L_00FBB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFBB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFBB9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFBB9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FBB9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FBBD;
L_00FBBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFBBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFBBDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFBBDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FBBD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FBC1;
L_00FBC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFBC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFBC1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFBC1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FBC1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FBC5;
L_00FBC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFBC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFBC5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFBC5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FBC5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FBC9;
L_00FBC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFBC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFBC9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFBC9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FBC9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FBCD;
L_00FBCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFBCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFBCDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFBCDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FBCD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FBD1;
L_00FBD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFBD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFBD1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFBD1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FBD1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FBD5;
L_00FBD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFBD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFBD5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFBD5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FBD5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FBD9;
L_00FBD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFBD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFBD9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFBD9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FBD9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FBDD;
L_00FBDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFBDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFBDDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFBDDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FBDD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FBE1;
L_00FBE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFBE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFBE1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFBE1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FBE1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FBE5;
L_00FBE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFBE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFBE5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFBE5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FBE5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FBE9;
L_00FBE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFBE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFBE9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFBE9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FBE9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FBED;
L_00FBED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFBEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFBEDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFBEDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FBED SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FBF1;
L_00FBF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFBF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFBF1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFBF1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FBF1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FBF5;
L_00FBF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFBF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFBF5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFBF5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FBF5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FBF9;
L_00FBF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFBF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFBF9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFBF9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FBF9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FBFD;
L_00FBFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFBFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFBFDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFBFDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FBFD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FC01;
L_00FC01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC01u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC01u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC01 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FC05;
L_00FC05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC05u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC05u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC05 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FC09;
L_00FC09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC09u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC09u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC09 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FC0D;
L_00FC0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC0Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC0Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC0D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FC11;
L_00FC11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC11u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC11u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC11 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FC15;
L_00FC15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC15u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC15u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC15 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FC19;
L_00FC19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC19u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC19u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC19 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FC1D;
L_00FC1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC1Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC1Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC1D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FC21;
L_00FC21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC21u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC21u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC21 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FC25;
L_00FC25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC25u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC25u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC25 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FC29;
L_00FC29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC29u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC29u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC29 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FC2D;
L_00FC2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC2Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC2Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC2D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FC31;
L_00FC31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC31u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC31u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC31 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FC35;
L_00FC35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC35u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC35u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC35 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FC39;
L_00FC39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC39u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC39u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC39 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FC3D;
L_00FC3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC3Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC3Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC3D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FC41;
L_00FC41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC41u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC41u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC41 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FC45;
L_00FC45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC45u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC45u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC45 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FC49;
L_00FC49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC49u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC49u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC49 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FC4D;
L_00FC4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC4Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC4Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC4D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FC51;
L_00FC51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC51u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC51u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC51 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FC55;
L_00FC55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC55u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC55u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC55 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FC59;
L_00FC59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC59u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC59u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC59 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FC5D;
L_00FC5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC5Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC5Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC5D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FC61;
L_00FC61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC61u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC61u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC61 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FC65;
L_00FC65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC65u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC65u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC65 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FC69;
L_00FC69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC69u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC69u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC69 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FC6D;
L_00FC6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC6Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC6Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC6D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FC71;
L_00FC71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC71u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC71u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC71 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FC75;
L_00FC75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC75u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC75u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC75 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FC79;
L_00FC79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC79u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC79u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC79 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FC7D;
L_00FC7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC7Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC7Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC7D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FC81;
L_00FC81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC81u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC81u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC81 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FC85;
L_00FC85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC85u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC85u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC85 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FC89;
L_00FC89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC89u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC89u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC89 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FC8D;
L_00FC8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC8Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC8Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC8D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FC91;
L_00FC91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC91u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC91u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC91 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FC95;
L_00FC95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC95u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC95u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC95 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FC99;
L_00FC99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC99u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC99u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC99 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FC9D;
L_00FC9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC9Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC9Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FC9D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FCA1;
L_00FCA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCA1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCA1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCA1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FCA5;
L_00FCA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCA5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCA5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCA5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FCA9;
L_00FCA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCA9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCA9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCA9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FCAD;
L_00FCAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCADu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCADu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCAD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FCB1;
L_00FCB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCB1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCB1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCB1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FCB5;
L_00FCB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCB5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCB5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCB5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FCB9;
L_00FCB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCB9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCB9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCB9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FCBD;
L_00FCBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCBDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCBDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCBD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FCC1;
L_00FCC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCC1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCC1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCC1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FCC5;
L_00FCC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCC5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCC5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCC5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FCC9;
L_00FCC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCC9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCC9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCC9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FCCD;
L_00FCCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCCDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCCDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCCD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FCD1;
L_00FCD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCD1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCD1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCD1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FCD5;
L_00FCD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCD5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCD5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCD5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FCD9;
L_00FCD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCD9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCD9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCD9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FCDD;
L_00FCDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCDDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCDDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCDD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FCE1;
L_00FCE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCE1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCE1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCE1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FCE5;
L_00FCE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCE5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCE5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCE5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FCE9;
L_00FCE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCE9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCE9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCE9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FCED;
L_00FCED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCEDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCEDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCED SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FCF1;
L_00FCF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCF1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCF1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCF1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FCF5;
L_00FCF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCF5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCF5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCF5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FCF9;
L_00FCF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCF9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCF9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCF9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FCFD;
L_00FCFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCFDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCFDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FCFD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FD01;
L_00FD01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD01u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD01u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD01 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FD05;
L_00FD05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD05u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD05u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD05 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FD09;
L_00FD09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD09u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD09u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD09 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FD0D;
L_00FD0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD0Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD0Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD0D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FD11;
L_00FD11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD11u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD11u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD11 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FD15;
L_00FD15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD15u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD15u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD15 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FD19;
L_00FD19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD19u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD19u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD19 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FD1D;
L_00FD1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD1Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD1Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD1D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FD21;
L_00FD21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD21u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD21u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD21 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FD25;
L_00FD25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD25u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD25u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD25 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FD29;
L_00FD29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD29u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD29u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD29 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FD2D;
L_00FD2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD2Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD2Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD2D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FD31;
L_00FD31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD31u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD31u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD31 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FD35;
L_00FD35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD35u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD35u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD35 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FD39;
L_00FD39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD39u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD39u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD39 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FD3D;
L_00FD3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD3Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD3Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD3D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FD41;
L_00FD41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD41u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD41u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD41 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FD45;
L_00FD45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD45u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD45u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD45 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FD49;
L_00FD49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD49u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD49u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD49 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FD4D;
L_00FD4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD4Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD4Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD4D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FD51;
L_00FD51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD51u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD51u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD51 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FD55;
L_00FD55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD55u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD55u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD55 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FD59;
L_00FD59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD59u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD59u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD59 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FD5D;
L_00FD5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD5Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD5Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD5D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FD61;
L_00FD61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD61u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD61u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD61 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FD65;
L_00FD65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD65u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD65u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD65 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FD69;
L_00FD69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD69u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD69u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD69 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FD6D;
L_00FD6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD6Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD6Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD6D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FD71;
L_00FD71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD71u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD71u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD71 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FD75;
L_00FD75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD75u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD75u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD75 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FD79;
L_00FD79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD79u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD79u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD79 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FD7D;
L_00FD7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD7Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD7Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD7D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FD81;
L_00FD81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD81u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD81u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD81 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FD85;
L_00FD85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD85u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD85u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD85 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FD89;
L_00FD89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD89u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD89u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD89 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FD8D;
L_00FD8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD8Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD8Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD8D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FD91;
L_00FD91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD91u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD91u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD91 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FD95;
L_00FD95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD95u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD95u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD95 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FD99;
L_00FD99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD99u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD99u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD99 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FD9D;
L_00FD9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD9Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD9Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FD9D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FDA1;
L_00FDA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDA1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDA1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDA1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FDA5;
L_00FDA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDA5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDA5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDA5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FDA9;
L_00FDA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDA9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDA9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDA9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FDAD;
L_00FDAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDADu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDADu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDAD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FDB1;
L_00FDB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDB1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDB1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDB1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FDB5;
L_00FDB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDB5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDB5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDB5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FDB9;
L_00FDB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDB9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDB9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDB9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FDBD;
L_00FDBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDBDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDBDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDBD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FDC1;
L_00FDC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDC1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDC1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDC1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FDC5;
L_00FDC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDC5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDC5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDC5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FDC9;
L_00FDC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDC9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDC9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDC9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FDCD;
L_00FDCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDCDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDCDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDCD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FDD1;
L_00FDD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDD1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDD1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDD1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FDD5;
L_00FDD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDD5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDD5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDD5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FDD9;
L_00FDD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDD9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDD9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDD9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FDDD;
L_00FDDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDDDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDDDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDDD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FDE1;
L_00FDE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDE1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDE1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDE1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FDE5;
L_00FDE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDE5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDE5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDE5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FDE9;
L_00FDE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDE9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDE9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDE9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FDED;
L_00FDED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDEDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDEDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDED SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FDF1;
L_00FDF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDF1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDF1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDF1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FDF5;
L_00FDF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDF5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDF5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDF5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FDF9;
L_00FDF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDF9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDF9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDF9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FDFD;
L_00FDFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFDFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFDFDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFDFDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FDFD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FE01;
L_00FE01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE01u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE01u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE01 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FE05;
L_00FE05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE05u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE05u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE05 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FE09;
L_00FE09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE09u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE09u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE09 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FE0D;
L_00FE0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE0Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE0Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE0D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FE11;
L_00FE11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE11u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE11u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE11 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FE15;
L_00FE15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE15u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE15u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE15 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FE19;
L_00FE19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE19u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE19u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE19 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FE1D;
L_00FE1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE1Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE1Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE1D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FE21;
L_00FE21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE21u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE21u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE21 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FE25;
L_00FE25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE25u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE25u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE25 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FE29;
L_00FE29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE29u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE29u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE29 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FE2D;
L_00FE2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE2Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE2Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE2D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FE31;
L_00FE31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE31u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE31u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE31 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FE35;
L_00FE35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE35u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE35u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE35 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FE39;
L_00FE39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE39u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE39u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE39 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FE3D;
L_00FE3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE3Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE3Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE3D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FE41;
L_00FE41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE41u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE41u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE41 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FE45;
L_00FE45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE45u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE45u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE45 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FE49;
L_00FE49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE49u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE49u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE49 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FE4D;
L_00FE4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE4Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE4Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE4D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FE51;
L_00FE51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE51u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE51u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE51 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FE55;
L_00FE55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE55u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE55u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE55 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FE59;
L_00FE59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE59u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE59u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE59 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FE5D;
L_00FE5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE5Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE5Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE5D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FE61;
L_00FE61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE61u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE61u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE61 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FE65;
L_00FE65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE65u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE65u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE65 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FE69;
L_00FE69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE69u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE69u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE69 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FE6D;
L_00FE6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE6Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE6Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE6D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FE71;
L_00FE71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE71u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE71u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE71 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FE75;
L_00FE75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE75u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE75u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE75 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FE79;
L_00FE79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE79u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE79u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE79 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FE7D;
L_00FE7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE7Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE7Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE7D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FE81;
L_00FE81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE81u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE81u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE81 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FE85;
L_00FE85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE85u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE85u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE85 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FE89;
L_00FE89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE89u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE89u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE89 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FE8D;
L_00FE8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE8Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE8Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE8D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FE91;
L_00FE91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE91u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE91u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE91 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FE95;
L_00FE95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE95u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE95u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE95 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FE99;
L_00FE99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE99u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE99u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE99 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FE9D;
L_00FE9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFE9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFE9Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFE9Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FE9D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FEA1;
L_00FEA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEA1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEA1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FEA1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FEA5;
L_00FEA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEA5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEA5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FEA5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FEA9;
L_00FEA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEA9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEA9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FEA9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FEAD;
L_00FEAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEADu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEADu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FEAD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FEB1;
L_00FEB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEB1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEB1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FEB1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FEB5;
L_00FEB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEB5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEB5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FEB5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FEB9;
L_00FEB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEB9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEB9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FEB9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FEBD;
L_00FEBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEBDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEBDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FEBD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FEC1;
L_00FEC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEC1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEC1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FEC1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FEC5;
L_00FEC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEC5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEC5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FEC5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FEC9;
L_00FEC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEC9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEC9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FEC9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FECD;
L_00FECD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFECDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFECDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFECDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FECD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FED1;
L_00FED1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFED1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFED1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFED1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FED1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FED5;
L_00FED5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFED5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFED5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFED5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FED5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FED9;
L_00FED9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFED9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFED9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFED9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FED9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FEDD;
L_00FEDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEDDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEDDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FEDD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FEE1;
L_00FEE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEE1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEE1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FEE1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FEE5;
L_00FEE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEE5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEE5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FEE5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FEE9;
L_00FEE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEE9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEE9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FEE9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FEED;
L_00FEED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEEDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEEDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FEED SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FEF1;
L_00FEF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEF1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEF1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FEF1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FEF5;
L_00FEF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEF5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEF5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FEF5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FEF9;
L_00FEF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEF9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEF9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FEF9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FEFD;
L_00FEFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFEFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFEFDu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFEFDu, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FEFD SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FF01;
L_00FF01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF01u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF01u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FF01 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FF05;
L_00FF05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF05u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF05u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FF05 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FF09;
L_00FF09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF09u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF09u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FF09 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FF0D;
L_00FF0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF0Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF0Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FF0D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FF11;
L_00FF11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF11u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF11u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FF11 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FF15;
L_00FF15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF15u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF15u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FF15 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FF19;
L_00FF19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF19u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF19u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FF19 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FF1D;
L_00FF1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF1Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF1Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FF1D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FF21;
L_00FF21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF21u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF21u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FF21 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FF25;
L_00FF25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF25u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF25u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FF25 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FF29;
L_00FF29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF29u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF29u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FF29 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FF2D;
L_00FF2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF2Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF2Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FF2D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FF31;
L_00FF31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF31u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF31u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FF31 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FF35;
L_00FF35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF35u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF35u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FF35 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FF39;
L_00FF39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF39u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF39u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FF39 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FF3D;
L_00FF3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF3Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF3Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FF3D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FF41;
L_00FF41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF41u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF41u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FF41 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FF45;
L_00FF45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF45u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF45u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FF45 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FF49;
L_00FF49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF49u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF49u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FF49 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FF4D;
L_00FF4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF4Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF4Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FF4D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FF51;
L_00FF51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF51u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF51u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FF51 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FF55;
L_00FF55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF55u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF55u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FF55 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FF59;
L_00FF59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF59u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF59u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FF59 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FF5D;
L_00FF5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF5Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF5Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FF5D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FF61;
L_00FF61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF61u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF61u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FF61 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FF65;
L_00FF65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF65u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF65u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FF65 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FF69;
L_00FF69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF69u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF69u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FF69 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FF6D;
L_00FF6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF6Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF6Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FF6D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FF71;
L_00FF71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF71u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF71u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FF71 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FF75;
L_00FF75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF75u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF75u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FF75 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FF79;
L_00FF79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF79u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF79u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FF79 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FF7D;
L_00FF7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF7Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF7Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FF7D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FF81;
L_00FF81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF81u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF81u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FF81 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FF85;
L_00FF85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF85u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF85u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FF85 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FF89;
L_00FF89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF89u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF89u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FF89 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FF8D;
L_00FF8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF8Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF8Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FF8D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FF91;
L_00FF91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF91u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF91u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FF91 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FF95;
L_00FF95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF95u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF95u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FF95 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FF99;
L_00FF99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF99u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF99u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FF99 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FF9D;
L_00FF9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF9Du,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF9Du, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FF9D SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FFA1;
L_00FFA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFFA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFFA1u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFFA1u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FFA1 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FFA5;
L_00FFA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFFA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFFA5u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFFA5u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FFA5 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FFA9;
L_00FFA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFFA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFFA9u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFFA9u, 6u, 4u, ((0xFFFFFFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FFA9 SBC
    cpu.sbc(hw.readW(((0xFFFFFFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00FFAD;
L_00FFAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFFADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFFADu,cpu,0x96u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFFADu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpy", 0x09u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00FFAD STX
    hw.write(cpu.address("dpy", 0x9u), cpu.x, cpu.x8?8:16);
    goto L_00FFAF;
L_00FFAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFFAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFFAFu,cpu,0x02u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFFAFu, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $00FFAF COP
    hw.partial(0x00FFAFu, "COP"); return;
}

void sub_8083A4_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8083A4u: goto L_8083A4;
    case 0x8083A5u: goto L_8083A5;
    case 0x8083A7u: goto L_8083A7;
    case 0x8083A9u: goto L_8083A9;
    case 0x8083AAu: goto L_8083AA;
    case 0x8083ADu: goto L_8083AD;
    case 0x8083AFu: goto L_8083AF;
    case 0x8083B2u: goto L_8083B2;
    case 0x8083B3u: goto L_8083B3;
    case 0x8083B4u: goto L_8083B4;
    case 0x8083B6u: goto L_8083B6;
    case 0x8083B7u: goto L_8083B7;
    case 0x8083B8u: goto L_8083B8;
    case 0x8083BAu: goto L_8083BA;
    case 0x8083BEu: goto L_8083BE;
    case 0x8083BFu: goto L_8083BF;
    case 0x8083C1u: goto L_8083C1;
    case 0x8083C5u: goto L_8083C5;
    case 0x8083C6u: goto L_8083C6;
    case 0x8083C7u: goto L_8083C7;
    case 0x8083C8u: goto L_8083C8;
    case 0x8083C9u: goto L_8083C9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8083A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A4u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A4u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8083A4 PHP
    cpu.push("PHP", hw);
    goto L_8083A5;
L_8083A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083A5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x46u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8083A7;
L_8083A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A7u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083A7 BMI -> $8083C8
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_8083C8; }
    goto L_8083A9;
L_8083A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A9u,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A9u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8083A9 PHK
    cpu.push("PHK", hw);
    goto L_8083AA;
L_8083AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83AAu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83AAu, 5u, 3u, cpu.address("abs", 0x83C7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8083AA PEA
    cpu.push16Value(hw, 0x83C7u);
    goto L_8083AD;
L_8083AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83ADu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83ADu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083AD REP
    cpu.rep(0x20u);
    goto L_8083AF;
L_8083AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83AFu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83AFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083AF AND
    cpu.logicAnd(0xFFu);
    goto L_8083B2;
L_8083B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B2u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B2u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8083B2 PHA
    cpu.push("PHA", hw);
    goto L_8083B3;
L_8083B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B3u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083B3 ASL
    cpu.aslA();
    goto L_8083B4;
L_8083B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B4u,cpu,0x63u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B4u, 5u, 2u, cpu.addressStack(0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083B4 ADC
    cpu.adc(hw.readW(cpu.addressStack(0x1u), cpu.m8?8:16));
    goto L_8083B6;
L_8083B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B6u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083B6 TAX
    cpu.transfer("TAX");
    goto L_8083B7;
L_8083B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B7u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B7u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8083B7 PLA
    cpu.pop("PLA", hw);
    goto L_8083B8;
L_8083B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B8u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083B8 SEP
    cpu.sep(0x20u);
    goto L_8083BA;
L_8083BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83BAu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83BAu, 5u, 4u, ((0x8083CCu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083BA LDA
    cpu.loadA(hw.readW(((0x8083CCu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8083BE;
L_8083BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83BEu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83BEu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8083BE PHA
    cpu.push("PHA", hw);
    goto L_8083BF;
L_8083BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83BFu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83BFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083BF REP
    cpu.rep(0x20u);
    goto L_8083C1;
L_8083C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C1u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C1u, 6u, 4u, ((0x8083CAu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083C1 LDA
    cpu.loadA(hw.readW(((0x8083CAu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8083C5;
L_8083C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C5u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083C5 DEC
    cpu.decReg('A');
    goto L_8083C6;
L_8083C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C6u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C6u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8083C6 PHA
    cpu.push("PHA", hw);
    goto L_8083C7;
L_8083C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C7u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8083C7 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8083C7u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8083C7u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_8083C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C8u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C8u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8083C8 PLP
    cpu.pop("PLP", hw);
    goto L_8083C9;
L_8083C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C9u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83C9u,0x8083C9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8083C9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8083C9u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8083C9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_808425_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808425u: goto L_808425;
    case 0x808429u: goto L_808429;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808425:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8425u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8425u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8425u, 8u, 4u, 0x82AF3Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808425 JSL -> $82AF3C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8428u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8429u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82AF3Cu, 0x808425u); }
    goto L_808429;
L_808429:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8429u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8429u,0x808429u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8429u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8429u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808429 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808429u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808429u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808425_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808425u: goto L_808425;
    case 0x808429u: goto L_808429;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808425:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8425u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8425u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8425u, 8u, 4u, 0x82AF3Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808425 JSL -> $82AF3C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8428u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8429u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82AF3Cu, 0x808425u); }
    goto L_808429;
L_808429:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8429u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8429u,0x808429u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8429u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8429u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808429 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808429u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808429u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808432_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808432u: goto L_808432;
    case 0x808436u: goto L_808436;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808432:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8432u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8432u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8432u, 8u, 4u, 0x9F80F9u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808432 JSL -> $9F80F9 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8435u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8436u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x9F80F9u, 0x808432u); }
    goto L_808436;
L_808436:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8436u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8436u,0x808436u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8436u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8436u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808436 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808436u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808436u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80A724_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80A724u: goto L_80A724;
    case 0x80A725u: goto L_80A725;
    case 0x80A727u: goto L_80A727;
    case 0x80A729u: goto L_80A729;
    case 0x80A72Bu: goto L_80A72B;
    case 0x80A72Du: goto L_80A72D;
    case 0x80A730u: goto L_80A730;
    case 0x80A732u: goto L_80A732;
    case 0x80A734u: goto L_80A734;
    case 0x80A736u: goto L_80A736;
    case 0x80A738u: goto L_80A738;
    case 0x80A73Bu: goto L_80A73B;
    case 0x80A73Du: goto L_80A73D;
    case 0x80A740u: goto L_80A740;
    case 0x80A742u: goto L_80A742;
    case 0x80A744u: goto L_80A744;
    case 0x80A746u: goto L_80A746;
    case 0x80A748u: goto L_80A748;
    case 0x80A74Au: goto L_80A74A;
    case 0x80A74Cu: goto L_80A74C;
    case 0x80A74Eu: goto L_80A74E;
    case 0x80A750u: goto L_80A750;
    case 0x80A752u: goto L_80A752;
    case 0x80A755u: goto L_80A755;
    case 0x80A757u: goto L_80A757;
    case 0x80A759u: goto L_80A759;
    case 0x80A75Bu: goto L_80A75B;
    case 0x80A75Du: goto L_80A75D;
    case 0x80A760u: goto L_80A760;
    case 0x80A762u: goto L_80A762;
    case 0x80A764u: goto L_80A764;
    case 0x80A766u: goto L_80A766;
    case 0x80A768u: goto L_80A768;
    case 0x80A76Bu: goto L_80A76B;
    case 0x80A76Du: goto L_80A76D;
    case 0x80A76Fu: goto L_80A76F;
    case 0x80A772u: goto L_80A772;
    case 0x80A774u: goto L_80A774;
    case 0x80A776u: goto L_80A776;
    case 0x80A778u: goto L_80A778;
    case 0x80A77Au: goto L_80A77A;
    case 0x80A77Cu: goto L_80A77C;
    case 0x80A77Eu: goto L_80A77E;
    case 0x80A780u: goto L_80A780;
    case 0x80A781u: goto L_80A781;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80A724:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA724u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA724u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA724u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A724 PHP
    cpu.push("PHP", hw);
    goto L_80A725;
L_80A725:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA725u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA725u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA725u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A725 SEP
    cpu.sep(0x20u);
    goto L_80A727;
L_80A727:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA727u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA727u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA727u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A727 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xD9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A729;
L_80A729:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA729u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA729u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA729u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A729 CMP
    cpu.compareA(0xFFu);
    goto L_80A72B;
L_80A72B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA72Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA72Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA72Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A72B BEQ -> $80A74C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80A74C; }
    goto L_80A72D;
L_80A72D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA72Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA72Du,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA72Du, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A72D CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x2140u), cpu.m8?8:16));
    goto L_80A730;
L_80A730:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA730u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA730u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA730u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A730 BNE -> $80A73D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80A73D; }
    goto L_80A732;
L_80A732:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA732u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA732u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA732u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A732 CMP
    cpu.compareA(0x80u);
    goto L_80A734;
L_80A734:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA734u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA734u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA734u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A734 BCS -> $80A73D
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80A73D; }
    goto L_80A736;
L_80A736:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA736u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA736u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA736u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A736 LDA
    cpu.setA(0x80u, 8);
    goto L_80A738;
L_80A738:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA738u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA738u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA738u, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A738 STA
    hw.write(cpu.address("abs", 0x2140u), cpu.a, cpu.m8?8:16);
    goto L_80A73B;
L_80A73B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA73Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA73Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA73Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A73B BRA -> $80A74C
    goto L_80A74C;
L_80A73D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA73Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA73Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA73Du, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A73D STA
    hw.write(cpu.address("abs", 0x2140u), cpu.a, cpu.m8?8:16);
    goto L_80A740;
L_80A740:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA740u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA740u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA740u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A740 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xDAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80A742;
L_80A742:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA742u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA742u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA742u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A742 STX
    hw.write(cpu.address("dp", 0xD9u), cpu.x, cpu.x8?8:16);
    goto L_80A744;
L_80A744:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA744u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA744u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA744u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A744 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A746;
L_80A746:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA746u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA746u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA746u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A746 STA
    hw.write(cpu.address("dp", 0xDBu), cpu.a, cpu.m8?8:16);
    goto L_80A748;
L_80A748:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA748u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA748u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA748u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A748 LDA
    cpu.setA(0xFFu, 8);
    goto L_80A74A;
L_80A74A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA74Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA74Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA74Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A74A STA
    hw.write(cpu.address("dp", 0xDCu), cpu.a, cpu.m8?8:16);
    goto L_80A74C;
L_80A74C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA74Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA74Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA74Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xE2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A74C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xE2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A74E;
L_80A74E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA74Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA74Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA74Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A74E CMP
    cpu.compareA(0xFFu);
    goto L_80A750;
L_80A750:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA750u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA750u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA750u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A750 BEQ -> $80A757
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80A757; }
    goto L_80A752;
L_80A752:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA752u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA752u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA752u, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A752 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x2141u), cpu.m8?8:16));
    goto L_80A755;
L_80A755:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA755u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA755u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA755u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A755 BNE -> $80A768
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80A768; }
    goto L_80A757;
L_80A757:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA757u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA757u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA757u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A757 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A759;
L_80A759:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA759u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA759u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA759u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A759 CMP
    cpu.compareA(0xFFu);
    goto L_80A75B;
L_80A75B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA75Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA75Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA75Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A75B BEQ -> $80A780
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80A780; }
    goto L_80A75D;
L_80A75D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA75Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA75Du,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA75Du, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A75D CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x2141u), cpu.m8?8:16));
    goto L_80A760;
L_80A760:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA760u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA760u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA760u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A760 BNE -> $80A76F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80A76F; }
    goto L_80A762;
L_80A762:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA762u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA762u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA762u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A762 CMP
    cpu.compareA(0x80u);
    goto L_80A764;
L_80A764:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA764u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA764u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA764u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A764 BCS -> $80A76F
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80A76F; }
    goto L_80A766;
L_80A766:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA766u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA766u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA766u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A766 ORA
    cpu.logicOr(0x80u);
    goto L_80A768;
L_80A768:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA768u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA768u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA768u, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A768 STA
    hw.write(cpu.address("abs", 0x2141u), cpu.a, cpu.m8?8:16);
    goto L_80A76B;
L_80A76B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA76Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA76Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA76Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xE2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A76B STA
    hw.write(cpu.address("dp", 0xE2u), cpu.a, cpu.m8?8:16);
    goto L_80A76D;
L_80A76D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA76Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA76Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA76Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A76D BRA -> $80A780
    goto L_80A780;
L_80A76F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA76Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA76Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA76Fu, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A76F STA
    hw.write(cpu.address("abs", 0x2141u), cpu.a, cpu.m8?8:16);
    goto L_80A772;
L_80A772:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA772u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA772u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA772u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xE2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A772 STA
    hw.write(cpu.address("dp", 0xE2u), cpu.a, cpu.m8?8:16);
    goto L_80A774;
L_80A774:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA774u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA774u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA774u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A774 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xDEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80A776;
L_80A776:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA776u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA776u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA776u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A776 STX
    hw.write(cpu.address("dp", 0xDDu), cpu.x, cpu.x8?8:16);
    goto L_80A778;
L_80A778:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA778u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA778u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA778u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xE0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A778 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xE0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A77A;
L_80A77A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA77Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA77Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA77Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A77A STA
    hw.write(cpu.address("dp", 0xDFu), cpu.a, cpu.m8?8:16);
    goto L_80A77C;
L_80A77C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA77Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA77Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA77Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A77C LDA
    cpu.setA(0xFFu, 8);
    goto L_80A77E;
L_80A77E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA77Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA77Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA77Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xE0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A77E STA
    hw.write(cpu.address("dp", 0xE0u), cpu.a, cpu.m8?8:16);
    goto L_80A780;
L_80A780:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA780u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA780u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA780u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A780 PLP
    cpu.pop("PLP", hw);
    goto L_80A781;
L_80A781:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA781u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA781u,0x80A781u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA781u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA781u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A781 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80A781u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80A781u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80AE0D_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AE0Du: goto L_80AE0D;
    case 0x80AE10u: goto L_80AE10;
    case 0x80AE12u: goto L_80AE12;
    case 0x80AE15u: goto L_80AE15;
    case 0x80AE18u: goto L_80AE18;
    case 0x80AE1Au: goto L_80AE1A;
    case 0x80AE1Du: goto L_80AE1D;
    case 0x80AE20u: goto L_80AE20;
    case 0x80AE23u: goto L_80AE23;
    case 0x80AE26u: goto L_80AE26;
    case 0x80AE29u: goto L_80AE29;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AE0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Du, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE0D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AE10;
L_80AE10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE10u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE10u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE10 BEQ -> $80AE23
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AE23; }
    goto L_80AE12;
L_80AE12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE12u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE12u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE12 LDX
    cpu.setX(0x354u, 16);
    goto L_80AE15;
L_80AE15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE15u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE15u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE15 LDA
    cpu.setA(0x2u, 16);
    goto L_80AE18;
L_80AE18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE18u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE18u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE18 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80AE1A;
L_80AE1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Au,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Au, 8u, 3u, cpu.address("abs", 0x0986u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE1A INC
    cpu.incMem(hw, cpu.address("abs", 0x986u), cpu.m8?8:16);
    goto L_80AE1D;
L_80AE1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Du, 6u, 3u, cpu.address("abs", 0xC7F6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AE1D JSR -> $80C7F6 stack real
    { cpu.push16Value(hw,0xAE1Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE20u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC7F6u), 0x80AE1Du); }
    goto L_80AE20;
L_80AE20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE20u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE20u,0x80AE20u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE20u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE20u, 6u, 3u, cpu.address("abs", 0xC404u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AE20 JSR -> $80C404 stack real
    { cpu.push16Value(hw,0xAE22u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE23u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC404u), 0x80AE20u); }
    goto L_80AE23;
L_80AE23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE23u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE23u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE23u, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE23 STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80AE26;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE23u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE23u, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE23 STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80AE26;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE23u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE23u, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE23 STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80AE26;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE23u,0x80AE23u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AE26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE26u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE26u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE26u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE26 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AE29;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE26u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE26u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE26 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AE29;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE26u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE26u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE26 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AE29;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE26u,0x80AE26u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AE29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE29u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE29u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE29u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AE29 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AE29u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AE29u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE29u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE29u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AE29 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AE29u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AE29u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE29u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE29u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AE29 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AE29u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AE29u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE29u,0x80AE29u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80AE0D_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AE0Du: goto L_80AE0D;
    case 0x80AE10u: goto L_80AE10;
    case 0x80AE12u: goto L_80AE12;
    case 0x80AE15u: goto L_80AE15;
    case 0x80AE18u: goto L_80AE18;
    case 0x80AE1Au: goto L_80AE1A;
    case 0x80AE1Du: goto L_80AE1D;
    case 0x80AE20u: goto L_80AE20;
    case 0x80AE23u: goto L_80AE23;
    case 0x80AE26u: goto L_80AE26;
    case 0x80AE29u: goto L_80AE29;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AE0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Du, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE0D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AE10;
L_80AE10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE10u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE10u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE10 BEQ -> $80AE23
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AE23; }
    goto L_80AE12;
L_80AE12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE12u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE12u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE12 LDX
    cpu.setX(0x354u, 16);
    goto L_80AE15;
L_80AE15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE15u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE15u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE15 LDA
    cpu.setA(0x2u, 16);
    goto L_80AE18;
L_80AE18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE18u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE18u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE18 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80AE1A;
L_80AE1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Au,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Au, 8u, 3u, cpu.address("abs", 0x0986u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE1A INC
    cpu.incMem(hw, cpu.address("abs", 0x986u), cpu.m8?8:16);
    goto L_80AE1D;
L_80AE1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Du, 6u, 3u, cpu.address("abs", 0xC7F6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AE1D JSR -> $80C7F6 stack real
    { cpu.push16Value(hw,0xAE1Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE20u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC7F6u), 0x80AE1Du); }
    goto L_80AE20;
L_80AE20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE20u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE20u,0x80AE20u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE20u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE20u, 6u, 3u, cpu.address("abs", 0xC404u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AE20 JSR -> $80C404 stack real
    { cpu.push16Value(hw,0xAE22u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE23u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC404u), 0x80AE20u); }
    goto L_80AE23;
L_80AE23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE23u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE23u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE23u, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE23 STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80AE26;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE23u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE23u, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE23 STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80AE26;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE23u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE23u, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE23 STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80AE26;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE23u,0x80AE23u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AE26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE26u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE26u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE26u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE26 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AE29;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE26u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE26u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE26 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AE29;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE26u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE26u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE26 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AE29;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE26u,0x80AE26u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AE29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE29u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE29u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE29u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AE29 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AE29u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AE29u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE29u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE29u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AE29 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AE29u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AE29u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE29u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE29u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AE29 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AE29u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AE29u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE29u,0x80AE29u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80B111_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B111u: goto L_80B111;
    case 0x80B114u: goto L_80B114;
    case 0x80B116u: goto L_80B116;
    case 0x80B119u: goto L_80B119;
    case 0x80B11Cu: goto L_80B11C;
    case 0x80B11Eu: goto L_80B11E;
    case 0x80B121u: goto L_80B121;
    case 0x80B124u: goto L_80B124;
    case 0x80B127u: goto L_80B127;
    case 0x80B12Au: goto L_80B12A;
    case 0x80B12Du: goto L_80B12D;
    case 0x80B130u: goto L_80B130;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B111:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB111u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB111u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB111u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B111 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B114;
L_80B114:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB114u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB114u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB114u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B114 BEQ -> $80B12A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B12A; }
    goto L_80B116;
L_80B116:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB116u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB116u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB116u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B116 LDX
    cpu.setX(0x3ACu, 16);
    goto L_80B119;
L_80B119:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB119u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB119u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB119u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B119 LDA
    cpu.setA(0x2u, 16);
    goto L_80B11C;
L_80B11C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB11Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB11Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB11Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B11C STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80B11E;
L_80B11E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB11Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB11Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB11Eu, 5u, 3u, cpu.address("abs", 0x0914u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B11E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x914u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B121;
L_80B121:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB121u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB121u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB121u, 5u, 3u, cpu.address("abs", 0x097Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B121 STA
    hw.write(cpu.address("abs", 0x97Au), cpu.a, cpu.m8?8:16);
    goto L_80B124;
L_80B124:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB124u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB124u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB124u, 8u, 3u, cpu.address("abs", 0x0986u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B124 INC
    cpu.incMem(hw, cpu.address("abs", 0x986u), cpu.m8?8:16);
    goto L_80B127;
L_80B127:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB127u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB127u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB127u, 6u, 3u, cpu.address("abs", 0xC85Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B127 JSR -> $80C85C stack real
    { cpu.push16Value(hw,0xB129u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB12Au,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC85Cu), 0x80B127u); }
    goto L_80B12A;
L_80B12A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB12Au))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB12Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB12Au, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B12A STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B12D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB12Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB12Au, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B12A STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B12D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB12Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB12Au, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B12A STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B12D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB12Au,0x80B12Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B12D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB12Du))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB12Du,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB12Du, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B12D INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B130;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB12Du,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB12Du, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B12D INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B130;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB12Du,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB12Du, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B12D INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B130;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB12Du,0x80B12Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B130:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB130u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB130u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB130u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B130 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B130u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B130u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB130u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB130u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B130 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B130u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B130u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB130u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB130u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B130 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B130u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B130u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB130u,0x80B130u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80D1AA_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80D1AAu: goto L_80D1AA;
    case 0x80D1ADu: goto L_80D1AD;
    case 0x80D1B0u: goto L_80D1B0;
    case 0x80D1B2u: goto L_80D1B2;
    case 0x80D1B5u: goto L_80D1B5;
    case 0x80D1B7u: goto L_80D1B7;
    case 0x80D1BAu: goto L_80D1BA;
    case 0x80D1BCu: goto L_80D1BC;
    case 0x80D1BEu: goto L_80D1BE;
    case 0x80D1C2u: goto L_80D1C2;
    case 0x80D1C4u: goto L_80D1C4;
    case 0x80D1C7u: goto L_80D1C7;
    case 0x80D1C9u: goto L_80D1C9;
    case 0x80D1CCu: goto L_80D1CC;
    case 0x80D1CEu: goto L_80D1CE;
    case 0x80D1D0u: goto L_80D1D0;
    case 0x80D1D4u: goto L_80D1D4;
    case 0x80D1D6u: goto L_80D1D6;
    case 0x80D1DAu: goto L_80D1DA;
    case 0x80D1DCu: goto L_80D1DC;
    case 0x80D1E0u: goto L_80D1E0;
    case 0x80D1E2u: goto L_80D1E2;
    case 0x80D1E5u: goto L_80D1E5;
    case 0x80D1E7u: goto L_80D1E7;
    case 0x80D1EAu: goto L_80D1EA;
    case 0x80D1ECu: goto L_80D1EC;
    case 0x80D1EEu: goto L_80D1EE;
    case 0x80D1F2u: goto L_80D1F2;
    case 0x80D1F4u: goto L_80D1F4;
    case 0x80D1F7u: goto L_80D1F7;
    case 0x80D1F9u: goto L_80D1F9;
    case 0x80D1FCu: goto L_80D1FC;
    case 0x80D1FEu: goto L_80D1FE;
    case 0x80D200u: goto L_80D200;
    case 0x80D201u: goto L_80D201;
    case 0x80D202u: goto L_80D202;
    case 0x80D203u: goto L_80D203;
    case 0x80D204u: goto L_80D204;
    case 0x80D205u: goto L_80D205;
    case 0x80D207u: goto L_80D207;
    case 0x80D20Bu: goto L_80D20B;
    case 0x80D20Du: goto L_80D20D;
    case 0x80D211u: goto L_80D211;
    case 0x80D214u: goto L_80D214;
    case 0x80D218u: goto L_80D218;
    case 0x80D21Au: goto L_80D21A;
    case 0x80D21Cu: goto L_80D21C;
    case 0x80D21Eu: goto L_80D21E;
    case 0x80D220u: goto L_80D220;
    case 0x80D222u: goto L_80D222;
    case 0x80D224u: goto L_80D224;
    case 0x80D226u: goto L_80D226;
    case 0x80D22Au: goto L_80D22A;
    case 0x80D22Cu: goto L_80D22C;
    case 0x80D22Fu: goto L_80D22F;
    case 0x80D231u: goto L_80D231;
    case 0x80D234u: goto L_80D234;
    case 0x80D236u: goto L_80D236;
    case 0x80D238u: goto L_80D238;
    case 0x80D23Cu: goto L_80D23C;
    case 0x80D23Eu: goto L_80D23E;
    case 0x80D242u: goto L_80D242;
    case 0x80D244u: goto L_80D244;
    case 0x80D248u: goto L_80D248;
    case 0x80D24Au: goto L_80D24A;
    case 0x80D24Du: goto L_80D24D;
    case 0x80D24Fu: goto L_80D24F;
    case 0x80D252u: goto L_80D252;
    case 0x80D254u: goto L_80D254;
    case 0x80D256u: goto L_80D256;
    case 0x80D25Au: goto L_80D25A;
    case 0x80D25Cu: goto L_80D25C;
    case 0x80D25Fu: goto L_80D25F;
    case 0x80D261u: goto L_80D261;
    case 0x80D264u: goto L_80D264;
    case 0x80D266u: goto L_80D266;
    case 0x80D268u: goto L_80D268;
    case 0x80D269u: goto L_80D269;
    case 0x80D26Au: goto L_80D26A;
    case 0x80D26Du: goto L_80D26D;
    case 0x80D26Fu: goto L_80D26F;
    case 0x80D273u: goto L_80D273;
    case 0x80D275u: goto L_80D275;
    case 0x80D279u: goto L_80D279;
    case 0x80D27Cu: goto L_80D27C;
    case 0x80D280u: goto L_80D280;
    case 0x80D282u: goto L_80D282;
    case 0x80D284u: goto L_80D284;
    case 0x80D286u: goto L_80D286;
    case 0x80D288u: goto L_80D288;
    case 0x80D28Au: goto L_80D28A;
    case 0x80D28Cu: goto L_80D28C;
    case 0x80D28Eu: goto L_80D28E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80D1AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1AAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1AAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1AA AND
    cpu.logicAnd(0x300u);
    goto L_80D1AD;
L_80D1AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1ADu,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1ADu, 5u, 3u, cpu.address("abs", 0x0914u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1AD CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x914u), cpu.m8?8:16));
    goto L_80D1B0;
L_80D1B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1B0 BEQ -> $80D1BA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D1BA; }
    goto L_80D1B2;
L_80D1B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B2u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B2u, 5u, 3u, cpu.address("abs", 0x0916u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1B2 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x916u), cpu.m8?8:16));
    goto L_80D1B5;
L_80D1B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1B5 BEQ -> $80D1BA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D1BA; }
    goto L_80D1B7;
L_80D1B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B7u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B7u, 3u, 3u, cpu.address("abs", 0xD28Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1B7 JMP -> $80D28E
    goto L_80D28E;
L_80D1BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1BAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1BAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1BA STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80D1BC;
L_80D1BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1BCu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1BCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1BC STX
    hw.write(cpu.address("dp", 0x61u), cpu.x, cpu.x8?8:16);
    goto L_80D1BE;
L_80D1BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1BEu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1BEu, 6u, 4u, ((0x7E2002u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1BE LDA
    cpu.loadA(hw.readW(((0x7E2002u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D1C2;
L_80D1C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1C2 BEQ -> $80D226
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D226; }
    goto L_80D1C4;
L_80D1C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C4u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1C4 CMP
    cpu.compareA(0xFFFFu);
    goto L_80D1C7;
L_80D1C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1C7 BEQ -> $80D226
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D226; }
    goto L_80D1C9;
L_80D1C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1C9 AND
    cpu.logicAnd(0x300u);
    goto L_80D1CC;
L_80D1CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1CCu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1CCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1CC CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_80D1CE;
L_80D1CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1CEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1CEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1CE BNE -> $80D226
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D226; }
    goto L_80D1D0;
L_80D1D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D0u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D0u, 6u, 4u, ((0x7E2004u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1D0 LDA
    cpu.loadA(hw.readW(((0x7E2004u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D1D4;
L_80D1D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1D4 BNE -> $80D226
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D226; }
    goto L_80D1D6;
L_80D1D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D6u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D6u, 6u, 4u, ((0x7E2006u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1D6 LDA
    cpu.loadA(hw.readW(((0x7E2006u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D1DA;
L_80D1DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1DAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1DAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1DA BNE -> $80D226
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D226; }
    goto L_80D1DC;
L_80D1DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1DCu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1DCu, 6u, 4u, ((0x7E2008u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1DC LDA
    cpu.loadA(hw.readW(((0x7E2008u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D1E0;
L_80D1E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1E0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1E0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1E0 BEQ -> $80D226
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D226; }
    goto L_80D1E2;
L_80D1E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1E2u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1E2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1E2 CMP
    cpu.compareA(0xFFFFu);
    goto L_80D1E5;
L_80D1E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1E5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1E5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1E5 BEQ -> $80D226
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D226; }
    goto L_80D1E7;
L_80D1E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1E7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1E7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1E7 AND
    cpu.logicAnd(0x300u);
    goto L_80D1EA;
L_80D1EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1EAu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1EAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1EA CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_80D1EC;
L_80D1EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1ECu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1ECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1EC BNE -> $80D226
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D226; }
    goto L_80D1EE;
L_80D1EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1EEu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1EEu, 6u, 4u, ((0x7E200Au + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1EE LDA
    cpu.loadA(hw.readW(((0x7E200Au + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D1F2;
L_80D1F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1F2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1F2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1F2 BEQ -> $80D226
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D226; }
    goto L_80D1F4;
L_80D1F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1F4u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1F4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1F4 CMP
    cpu.compareA(0xFFFFu);
    goto L_80D1F7;
L_80D1F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1F7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1F7 BEQ -> $80D226
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D226; }
    goto L_80D1F9;
L_80D1F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1F9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1F9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1F9 AND
    cpu.logicAnd(0x300u);
    goto L_80D1FC;
L_80D1FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1FCu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1FCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1FC CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_80D1FE;
L_80D1FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1FEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1FEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D1FE BNE -> $80D226
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D226; }
    goto L_80D200;
L_80D200:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD200u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD200u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD200u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D200 TXA
    cpu.transfer("TXA");
    goto L_80D201;
L_80D201:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD201u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD201u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD201u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D201 INC
    cpu.inc('A');
    goto L_80D202;
L_80D202:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD202u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD202u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD202u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D202 INC
    cpu.inc('A');
    goto L_80D203;
L_80D203:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD203u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD203u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD203u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D203 INC
    cpu.inc('A');
    goto L_80D204;
L_80D204:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD204u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD204u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD204u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D204 INC
    cpu.inc('A');
    goto L_80D205;
L_80D205:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD205u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD205u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD205u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D205 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D207;
L_80D207:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD207u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD207u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD207u, 6u, 4u, ((0x7E2444u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D207 STA
    hw.write(((0x7E2444u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D20B;
L_80D20B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD20Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD20Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD20Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D20B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D20D;
L_80D20D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD20Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD20Du,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD20Du, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D20D STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D211;
L_80D211:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD211u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD211u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD211u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D211 LDA
    cpu.setA(0x2u, 16);
    goto L_80D214;
L_80D214:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD214u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD214u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD214u, 6u, 4u, ((0x7E2442u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D214 STA
    hw.write(((0x7E2442u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D218;
L_80D218:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD218u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD218u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD218u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D218 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D21A;
L_80D21A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD21Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD21Au,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD21Au, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D21A INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D21C;
L_80D21C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD21Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD21Cu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD21Cu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D21C INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D21E;
L_80D21E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD21Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD21Eu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD21Eu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D21E INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D220;
L_80D220:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD220u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD220u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD220u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D220 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D222;
L_80D222:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD222u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD222u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD222u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D222 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D224;
L_80D224:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD224u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD224u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD224u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D224 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D226;
L_80D226:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD226u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD226u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD226u, 6u, 4u, ((0x7E2016u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D226 LDA
    cpu.loadA(hw.readW(((0x7E2016u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D22A;
L_80D22A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD22Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD22Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD22Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D22A BEQ -> $80D28E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D28E; }
    goto L_80D22C;
L_80D22C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD22Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD22Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD22Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D22C CMP
    cpu.compareA(0xFFFFu);
    goto L_80D22F;
L_80D22F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD22Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD22Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD22Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D22F BEQ -> $80D28E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D28E; }
    goto L_80D231;
L_80D231:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD231u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD231u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD231u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D231 AND
    cpu.logicAnd(0x300u);
    goto L_80D234;
L_80D234:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD234u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD234u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD234u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D234 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_80D236;
L_80D236:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD236u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD236u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD236u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D236 BNE -> $80D28E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D28E; }
    goto L_80D238;
L_80D238:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD238u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD238u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD238u, 6u, 4u, ((0x7E202Cu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D238 LDA
    cpu.loadA(hw.readW(((0x7E202Cu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D23C;
L_80D23C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD23Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD23Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD23Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D23C BNE -> $80D28E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D28E; }
    goto L_80D23E;
L_80D23E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD23Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD23Eu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD23Eu, 6u, 4u, ((0x7E2042u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D23E LDA
    cpu.loadA(hw.readW(((0x7E2042u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D242;
L_80D242:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD242u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD242u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD242u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D242 BNE -> $80D28E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D28E; }
    goto L_80D244;
L_80D244:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD244u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD244u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD244u, 6u, 4u, ((0x7E2058u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D244 LDA
    cpu.loadA(hw.readW(((0x7E2058u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D248;
L_80D248:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD248u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD248u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD248u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D248 BEQ -> $80D28E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D28E; }
    goto L_80D24A;
L_80D24A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD24Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD24Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD24Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D24A CMP
    cpu.compareA(0xFFFFu);
    goto L_80D24D;
L_80D24D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD24Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD24Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD24Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D24D BEQ -> $80D28E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D28E; }
    goto L_80D24F;
L_80D24F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD24Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD24Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD24Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D24F AND
    cpu.logicAnd(0x300u);
    goto L_80D252;
L_80D252:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD252u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD252u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD252u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D252 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_80D254;
L_80D254:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD254u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD254u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD254u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D254 BNE -> $80D28E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D28E; }
    goto L_80D256;
L_80D256:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD256u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD256u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD256u, 6u, 4u, ((0x7E206Eu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D256 LDA
    cpu.loadA(hw.readW(((0x7E206Eu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D25A;
L_80D25A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD25Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD25Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD25Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D25A BEQ -> $80D28E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D28E; }
    goto L_80D25C;
L_80D25C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD25Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD25Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD25Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D25C CMP
    cpu.compareA(0xFFFFu);
    goto L_80D25F;
L_80D25F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD25Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD25Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD25Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D25F BEQ -> $80D28E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D28E; }
    goto L_80D261;
L_80D261:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD261u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD261u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD261u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D261 AND
    cpu.logicAnd(0x300u);
    goto L_80D264;
L_80D264:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD264u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD264u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD264u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D264 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_80D266;
L_80D266:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD266u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD266u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD266u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D266 BNE -> $80D28E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D28E; }
    goto L_80D268;
L_80D268:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD268u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD268u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD268u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D268 TXA
    cpu.transfer("TXA");
    goto L_80D269;
L_80D269:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD269u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD269u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD269u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D269 CLC
    cpu.setFlag('C', false);
    goto L_80D26A;
L_80D26A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD26Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD26Au,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD26Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D26A ADC
    cpu.adc(0x2Cu);
    goto L_80D26D;
L_80D26D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD26Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD26Du,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD26Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D26D LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D26F;
L_80D26F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD26Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD26Fu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD26Fu, 6u, 4u, ((0x7E2444u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D26F STA
    hw.write(((0x7E2444u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D273;
L_80D273:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD273u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD273u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD273u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D273 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D275;
L_80D275:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD275u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD275u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD275u, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D275 STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D279;
L_80D279:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD279u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD279u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD279u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D279 LDA
    cpu.setA(0x4u, 16);
    goto L_80D27C;
L_80D27C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD27Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD27Cu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD27Cu, 6u, 4u, ((0x7E2442u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D27C STA
    hw.write(((0x7E2442u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D280;
L_80D280:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD280u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD280u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD280u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D280 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D282;
L_80D282:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD282u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD282u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD282u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D282 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D284;
L_80D284:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD284u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD284u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD284u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D284 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D286;
L_80D286:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD286u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD286u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD286u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D286 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D288;
L_80D288:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD288u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD288u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD288u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D288 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D28A;
L_80D28A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD28Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD28Au,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD28Au, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D28A INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80D28C;
L_80D28C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD28Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD28Cu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD28Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D28C LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D28E;
L_80D28E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD28Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD28Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD28Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D28E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80D28Eu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80D28Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82922F_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82922Fu: goto L_82922F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82922F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x922Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x922Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x922Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82922F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82922Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82922Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82A4DF_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82A4DFu: goto L_82A4DF;
    case 0x82A4E2u: goto L_82A4E2;
    case 0x82A4E4u: goto L_82A4E4;
    case 0x82A4E7u: goto L_82A4E7;
    case 0x82A4E9u: goto L_82A4E9;
    case 0x82A4EBu: goto L_82A4EB;
    case 0x82A4EDu: goto L_82A4ED;
    case 0x82A4F1u: goto L_82A4F1;
    case 0x82A4F3u: goto L_82A4F3;
    case 0x82A4F6u: goto L_82A4F6;
    case 0x82A4F7u: goto L_82A4F7;
    case 0x82A4F8u: goto L_82A4F8;
    case 0x82A4FBu: goto L_82A4FB;
    case 0x82A4FDu: goto L_82A4FD;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82A4DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4DFu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4DFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4DF LDX
    cpu.setX(0x0u, 16);
    goto L_82A4E2;
L_82A4E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E2u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E2u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82A4E2 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A4E4;
L_82A4E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4E4 AND
    cpu.logicAnd(0x3FFFu);
    goto L_82A4E7;
L_82A4E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E7u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4E7 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_82A4E9;
L_82A4E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E9u,cpu,0x91u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4E9u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82A4E9 STA
    hw.write(cpu.addressDpIndirectY(hw, 0x67u), cpu.a, cpu.m8?8:16);
    goto L_82A4EB;
L_82A4EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4EBu,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4EBu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82A4EB LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A4ED;
L_82A4ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4EDu,cpu,0x3Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4EDu, 6u, 4u, ((0x82A469u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4ED AND
    cpu.logicAnd(hw.readW(((0x82A469u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_82A4F1;
L_82A4F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4F1 BEQ -> $82A4F6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A4F6; }
    goto L_82A4F3;
L_82A4F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F3u, 6u, 3u, cpu.address("abs", 0xA4FEu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A4F3 JSR -> $82A4FE stack real
    { cpu.push16Value(hw,0xA4F5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA4F6u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA4FEu), 0x82A4F3u); }
    goto L_82A4F6;
L_82A4F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4F6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA4F6u,0x82A4F6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F6u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4F6 INX
    cpu.inc('X');
    goto L_82A4F7;
L_82A4F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F7u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4F7 INX
    cpu.inc('X');
    goto L_82A4F8;
L_82A4F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F8u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4F8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4F8 CPX
    cpu.compareX(0x8u);
    goto L_82A4FB;
L_82A4FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4FBu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4FBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4FB BCC -> $82A4EB
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82A4EB; }
    goto L_82A4FD;
L_82A4FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4FDu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4FDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A4FD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A4FDu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A4FDu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B396_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B396u: goto L_82B396;
    case 0x82B398u: goto L_82B398;
    case 0x82B39Au: goto L_82B39A;
    case 0x82B39Du: goto L_82B39D;
    case 0x82B39Fu: goto L_82B39F;
    case 0x82B3A1u: goto L_82B3A1;
    case 0x82B3A3u: goto L_82B3A3;
    case 0x82B3A5u: goto L_82B3A5;
    case 0x82B3A7u: goto L_82B3A7;
    case 0x82B3A8u: goto L_82B3A8;
    case 0x82B3A9u: goto L_82B3A9;
    case 0x82B3AAu: goto L_82B3AA;
    case 0x82B3ABu: goto L_82B3AB;
    case 0x82B3ACu: goto L_82B3AC;
    case 0x82B3ADu: goto L_82B3AD;
    case 0x82B3AFu: goto L_82B3AF;
    case 0x82B3B1u: goto L_82B3B1;
    case 0x82B3B3u: goto L_82B3B3;
    case 0x82B3B5u: goto L_82B3B5;
    case 0x82B3B7u: goto L_82B3B7;
    case 0x82B3B9u: goto L_82B3B9;
    case 0x82B3BBu: goto L_82B3BB;
    case 0x82B3BEu: goto L_82B3BE;
    case 0x82B3C0u: goto L_82B3C0;
    case 0x82B3C2u: goto L_82B3C2;
    case 0x82B3C3u: goto L_82B3C3;
    case 0x82B3C5u: goto L_82B3C5;
    case 0x82B3C7u: goto L_82B3C7;
    case 0x82B3C9u: goto L_82B3C9;
    case 0x82B3CBu: goto L_82B3CB;
    case 0x82B3CDu: goto L_82B3CD;
    case 0x82B3D0u: goto L_82B3D0;
    case 0x82B3D2u: goto L_82B3D2;
    case 0x82B3D5u: goto L_82B3D5;
    case 0x82B3D7u: goto L_82B3D7;
    case 0x82B3D9u: goto L_82B3D9;
    case 0x82B3DAu: goto L_82B3DA;
    case 0x82B3DBu: goto L_82B3DB;
    case 0x82B3DCu: goto L_82B3DC;
    case 0x82B3DDu: goto L_82B3DD;
    case 0x82B3DEu: goto L_82B3DE;
    case 0x82B3DFu: goto L_82B3DF;
    case 0x82B3E0u: goto L_82B3E0;
    case 0x82B3E1u: goto L_82B3E1;
    case 0x82B3E3u: goto L_82B3E3;
    case 0x82B3E5u: goto L_82B3E5;
    case 0x82B3E8u: goto L_82B3E8;
    case 0x82B3EAu: goto L_82B3EA;
    case 0x82B3ECu: goto L_82B3EC;
    case 0x82B3EDu: goto L_82B3ED;
    case 0x82B3EFu: goto L_82B3EF;
    case 0x82B3F2u: goto L_82B3F2;
    case 0x82B3F4u: goto L_82B3F4;
    case 0x82B3F6u: goto L_82B3F6;
    case 0x82B3F7u: goto L_82B3F7;
    case 0x82B3F9u: goto L_82B3F9;
    case 0x82B3FCu: goto L_82B3FC;
    case 0x82B3FEu: goto L_82B3FE;
    case 0x82B400u: goto L_82B400;
    case 0x82B403u: goto L_82B403;
    case 0x82B405u: goto L_82B405;
    case 0x82B408u: goto L_82B408;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B396:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB396u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB396u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB396u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B396 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B398;
L_82B398:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB398u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB398u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB398u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B398 STZ
    hw.write(cpu.address("dp", 0x5u), 0, cpu.m8?8:16);
    goto L_82B39A;
L_82B39A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB39Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Au, 4u + 1u, 3u, cpu.address("absy", 0x0208u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B39A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x208u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B39D;
L_82B39D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB39Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B39D CMP
    cpu.compareA(0x80u);
    goto L_82B39F;
L_82B39F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB39Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B39F BEQ -> $82B3AF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B3AF; }
    goto L_82B3A1;
L_82B3A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3A1 CMP
    cpu.compareA(0x1u);
    goto L_82B3A3;
L_82B3A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3A3 BNE -> $82B3A7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B3A7; }
    goto L_82B3A5;
L_82B3A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A5u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3A5 INC
    cpu.incMem(hw, cpu.address("dp", 0x5u), cpu.m8?8:16);
    goto L_82B3A7;
L_82B3A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A7u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3A7 INY
    cpu.inc('Y');
    goto L_82B3A8;
L_82B3A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A8u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3A8 INY
    cpu.inc('Y');
    goto L_82B3A9;
L_82B3A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A9u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3A9 INY
    cpu.inc('Y');
    goto L_82B3AA;
L_82B3AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3AAu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3AAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3AA INY
    cpu.inc('Y');
    goto L_82B3AB;
L_82B3AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3ABu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3ABu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3AB INY
    cpu.inc('Y');
    goto L_82B3AC;
L_82B3AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3ACu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3ACu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3AC INY
    cpu.inc('Y');
    goto L_82B3AD;
L_82B3AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3ADu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3ADu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3AD BRA -> $82B39A
    goto L_82B39A;
L_82B3AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3AFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3AFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3AF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B3B1;
L_82B3B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3B1 CMP
    cpu.compareA(0x2u);
    goto L_82B3B3;
L_82B3B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B3u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3B3 BCC -> $82B408
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82B408; }
    goto L_82B3B5;
L_82B3B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B5u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3B5 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B3B7;
L_82B3B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B7u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3B7 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B3B9;
L_82B3B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B9u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3B9 STZ
    hw.write(cpu.address("dp", 0x5u), 0, cpu.m8?8:16);
    goto L_82B3BB;
L_82B3BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BBu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BBu, 4u + 1u, 3u, cpu.address("absy", 0x0208u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3BB LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x208u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B3BE;
L_82B3BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BEu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3BE CMP
    cpu.compareA(0x80u);
    goto L_82B3C0;
L_82B3C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3C0 BNE -> $82B3C3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B3C3; }
    goto L_82B3C2;
L_82B3C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B3C2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B3C2u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B3C2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82B3C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C3u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3C3 CMP
    cpu.compareA(0x1u);
    goto L_82B3C5;
L_82B3C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3C5 BNE -> $82B3D9
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B3D9; }
    goto L_82B3C7;
L_82B3C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3C7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B3C9;
L_82B3C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3C9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3C9 BNE -> $82B3E3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B3E3; }
    goto L_82B3CB;
L_82B3CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3CBu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3CBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3CB STY
    hw.write(cpu.address("dp", 0x6u), cpu.y, cpu.x8?8:16);
    goto L_82B3CD;
L_82B3CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3CDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3CDu, 4u + 1u, 3u, cpu.address("absx", 0x0276u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3CD LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x276u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B3D0;
L_82B3D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3D0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3D0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3D0 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_82B3D2;
L_82B3D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3D2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3D2u, 4u + 1u, 3u, cpu.address("absx", 0x027Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3D2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x27Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B3D5;
L_82B3D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3D5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3D5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3D5 STA
    hw.write(cpu.address("dp", 0x9u), cpu.a, cpu.m8?8:16);
    goto L_82B3D7;
L_82B3D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3D7u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3D7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3D7 INC
    cpu.incMem(hw, cpu.address("dp", 0x5u), cpu.m8?8:16);
    goto L_82B3D9;
L_82B3D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3D9u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3D9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3D9 INY
    cpu.inc('Y');
    goto L_82B3DA;
L_82B3DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3DAu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3DAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3DA INY
    cpu.inc('Y');
    goto L_82B3DB;
L_82B3DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3DBu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3DBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3DB INY
    cpu.inc('Y');
    goto L_82B3DC;
L_82B3DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3DCu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3DCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3DC INY
    cpu.inc('Y');
    goto L_82B3DD;
L_82B3DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3DDu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3DDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3DD INY
    cpu.inc('Y');
    goto L_82B3DE;
L_82B3DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3DEu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3DEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3DE INY
    cpu.inc('Y');
    goto L_82B3DF;
L_82B3DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3DFu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3DFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3DF INX
    cpu.inc('X');
    goto L_82B3E0;
L_82B3E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3E0u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3E0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3E0 INX
    cpu.inc('X');
    goto L_82B3E1;
L_82B3E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3E1u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3E1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3E1 BRA -> $82B3BB
    goto L_82B3BB;
L_82B3E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3E3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3E3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3E3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B3E5;
L_82B3E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3E5u,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3E5u, 4u + 1u, 3u, cpu.address("absx", 0x027Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3E5 CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0x27Eu), cpu.m8?8:16));
    goto L_82B3E8;
L_82B3E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3E8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3E8 BNE -> $82B408
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B408; }
    goto L_82B3EA;
L_82B3EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3EAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3EAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3EA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B3EC;
L_82B3EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3ECu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3ECu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3EC CLC
    cpu.setFlag('C', false);
    goto L_82B3ED;
L_82B3ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3EDu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3EDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3ED ADC
    cpu.adc(0x8u);
    goto L_82B3EF;
L_82B3EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3EFu,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3EFu, 4u + 1u, 3u, cpu.address("absx", 0x0276u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3EF CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0x276u), cpu.m8?8:16));
    goto L_82B3F2;
L_82B3F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3F2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3F2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3F2 BEQ -> $82B3FE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B3FE; }
    goto L_82B3F4;
L_82B3F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3F4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3F4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3F4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B3F6;
L_82B3F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3F6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3F6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3F6 SEC
    cpu.setFlag('C', true);
    goto L_82B3F7;
L_82B3F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3F7u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3F7 SBC
    cpu.sbc(0x8u);
    goto L_82B3F9;
L_82B3F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3F9u,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3F9u, 4u + 1u, 3u, cpu.address("absx", 0x0276u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3F9 CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0x276u), cpu.m8?8:16));
    goto L_82B3FC;
L_82B3FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3FCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3FCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3FC BNE -> $82B408
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B408; }
    goto L_82B3FE;
L_82B3FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3FEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3FEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B3FE LDA
    cpu.setA(0x0u, 8);
    goto L_82B400;
L_82B400:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB400u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB400u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB400u, 5u, 3u, cpu.address("absy", 0x0208u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B400 STA
    hw.write(cpu.address("absy", 0x208u), cpu.a, cpu.m8?8:16);
    goto L_82B403;
L_82B403:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB403u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB403u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB403u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B403 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B405;
L_82B405:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB405u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB405u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB405u, 5u, 3u, cpu.address("absy", 0x0208u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B405 STA
    hw.write(cpu.address("absy", 0x208u), cpu.a, cpu.m8?8:16);
    goto L_82B408;
L_82B408:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB408u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB408u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB408u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B408 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B408u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B408u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B705_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B705u: goto L_82B705;
    case 0x82B707u: goto L_82B707;
    case 0x82B70Au: goto L_82B70A;
    case 0x82B70Cu: goto L_82B70C;
    case 0x82B70Fu: goto L_82B70F;
    case 0x82B711u: goto L_82B711;
    case 0x82B713u: goto L_82B713;
    case 0x82B715u: goto L_82B715;
    case 0x82B718u: goto L_82B718;
    case 0x82B719u: goto L_82B719;
    case 0x82B71Au: goto L_82B71A;
    case 0x82B71Bu: goto L_82B71B;
    case 0x82B71Cu: goto L_82B71C;
    case 0x82B71Fu: goto L_82B71F;
    case 0x82B721u: goto L_82B721;
    case 0x82B723u: goto L_82B723;
    case 0x82B726u: goto L_82B726;
    case 0x82B728u: goto L_82B728;
    case 0x82B729u: goto L_82B729;
    case 0x82B72Bu: goto L_82B72B;
    case 0x82B72Eu: goto L_82B72E;
    case 0x82B731u: goto L_82B731;
    case 0x82B734u: goto L_82B734;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B705:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB705u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB705u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB705u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B705 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B707;
L_82B707:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB707u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB707u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB707u, 9u, 3u, cpu.address("absx", 0x02CAu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B707 DEC
    cpu.decMem(hw, cpu.address("absx", 0x2CAu), cpu.m8?8:16);
    goto L_82B70A;
L_82B70A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB70Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB70Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB70Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B70A BPL -> $82B728
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82B728; }
    goto L_82B70C;
L_82B70C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB70Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB70Cu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB70Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B70C LDY
    cpu.setY(0x0u, 16);
    goto L_82B70F;
L_82B70F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB70Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB70Fu,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB70Fu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82B70F LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B711;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB70Fu,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB70Fu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82B70F LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B711;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB70Fu,0x82B70Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B711:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB711u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB711u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB711u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B711 BMI -> $82B729
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82B729; }
    goto L_82B713;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB711u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB711u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B711 BMI -> $82B729
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82B729; }
    goto L_82B713;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB711u,0x82B711u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B713:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB713u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB713u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB713u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B713 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B715;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB713u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB713u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B713 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B715;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB713u,0x82B713u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B715:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB715u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB715u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB715u, 5u + 1u, 3u, cpu.address("absx", 0x02C8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B715 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2C8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B718;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB715u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB715u, 5u + 1u, 3u, cpu.address("absx", 0x02C8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B715 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2C8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B718;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB715u,0x82B715u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B718:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB718u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB718u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB718u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B718 ASL
    cpu.aslA();
    goto L_82B719;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB718u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB718u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B718 ASL
    cpu.aslA();
    goto L_82B719;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB718u,0x82B718u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B719:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB719u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB719u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB719u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B719 ASL
    cpu.aslA();
    goto L_82B71A;
L_82B71A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB71Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB71Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB71Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B71A ASL
    cpu.aslA();
    goto L_82B71B;
L_82B71B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB71Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB71Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB71Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B71B ASL
    cpu.aslA();
    goto L_82B71C;
L_82B71C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB71Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB71Cu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB71Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B71C ORA
    cpu.logicOr(0x400u);
    goto L_82B71F;
L_82B71F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB71Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB71Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB71Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B71F STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82B721;
L_82B721:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB721u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB721u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB721u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B721 STZ
    hw.write(cpu.address("dp", 0xCu), 0, cpu.m8?8:16);
    goto L_82B723;
L_82B723:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB723u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB723u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB723u, 6u, 3u, cpu.address("abs", 0xB7D9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B723 JSR -> $82B7D9 stack real
    { cpu.push16Value(hw,0xB725u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB726u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB7D9u), 0x82B723u); }
    goto L_82B726;
L_82B726:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB726u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB726u,0x82B726u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB726u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB726u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B726 BRA -> $82B70F
    goto L_82B70F;
L_82B728:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB728u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB728u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB728u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B728 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B728u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B728u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82B729:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB729u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB729u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB729u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B729 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B72B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB729u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB729u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B729 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B72B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB729u,0x82B729u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B72B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB72Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB72Bu,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB72Bu, 9u, 3u, cpu.address("absx", 0x02C8u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B72B INC
    cpu.incMem(hw, cpu.address("absx", 0x2C8u), cpu.m8?8:16);
    goto L_82B72E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB72Bu,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB72Bu, 9u, 3u, cpu.address("absx", 0x02C8u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B72B INC
    cpu.incMem(hw, cpu.address("absx", 0x2C8u), cpu.m8?8:16);
    goto L_82B72E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB72Bu,0x82B72Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B72E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB72Eu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB72Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB72Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B72E LDA
    cpu.setA(0x3u, 16);
    goto L_82B731;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB72Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB72Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B72E LDA
    cpu.setA(0x3u, 16);
    goto L_82B731;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB72Eu,0x82B72Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B731:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB731u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB731u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB731u, 6u, 3u, cpu.address("absx", 0x02CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B731 STA
    hw.write(cpu.address("absx", 0x2CAu), cpu.a, cpu.m8?8:16);
    goto L_82B734;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB731u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB731u, 6u, 3u, cpu.address("absx", 0x02CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B731 STA
    hw.write(cpu.address("absx", 0x2CAu), cpu.a, cpu.m8?8:16);
    goto L_82B734;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB731u,0x82B731u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B734:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB734u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB734u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB734u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B734 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B734u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B734u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB734u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB734u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B734 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B734u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B734u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB734u,0x82B734u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82B921_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B921u: goto L_82B921;
    case 0x82B924u: goto L_82B924;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B921:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB921u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB921u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB921u, 6u, 3u, cpu.address("abs", 0xB9B0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B921 JSR -> $82B9B0 stack real
    { cpu.push16Value(hw,0xB923u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB924u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB9B0u), 0x82B921u); }
    goto L_82B924;
L_82B924:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB924u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB924u,0x82B924u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB924u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB924u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B924 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B924u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B924u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82BF6E_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82BF6Eu: goto L_82BF6E;
    case 0x82BF70u: goto L_82BF70;
    case 0x82BF72u: goto L_82BF72;
    case 0x82BF75u: goto L_82BF75;
    case 0x82BF78u: goto L_82BF78;
    case 0x82BF7Au: goto L_82BF7A;
    case 0x82BF7Du: goto L_82BF7D;
    case 0x82BF80u: goto L_82BF80;
    case 0x82BF82u: goto L_82BF82;
    case 0x82BF84u: goto L_82BF84;
    case 0x82BF86u: goto L_82BF86;
    case 0x82BF89u: goto L_82BF89;
    case 0x82BF8Cu: goto L_82BF8C;
    case 0x82BF8Fu: goto L_82BF8F;
    case 0x82BF92u: goto L_82BF92;
    case 0x82BF94u: goto L_82BF94;
    case 0x82BF96u: goto L_82BF96;
    case 0x82BF98u: goto L_82BF98;
    case 0x82BF9Bu: goto L_82BF9B;
    case 0x82BF9Du: goto L_82BF9D;
    case 0x82BFA0u: goto L_82BFA0;
    case 0x82BFA2u: goto L_82BFA2;
    case 0x82BFA4u: goto L_82BFA4;
    case 0x82BFA6u: goto L_82BFA6;
    case 0x82BFA9u: goto L_82BFA9;
    case 0x82BFABu: goto L_82BFAB;
    case 0x82BFAEu: goto L_82BFAE;
    case 0x82BFB1u: goto L_82BFB1;
    case 0x82BFB4u: goto L_82BFB4;
    case 0x82BFB7u: goto L_82BFB7;
    case 0x82BFBAu: goto L_82BFBA;
    case 0x82BFBCu: goto L_82BFBC;
    case 0x82BFBFu: goto L_82BFBF;
    case 0x82BFC1u: goto L_82BFC1;
    case 0x82BFC4u: goto L_82BFC4;
    case 0x82BFC6u: goto L_82BFC6;
    case 0x82BFC9u: goto L_82BFC9;
    case 0x82BFCBu: goto L_82BFCB;
    case 0x82BFCCu: goto L_82BFCC;
    case 0x82BFCEu: goto L_82BFCE;
    case 0x82BFD0u: goto L_82BFD0;
    case 0x82BFD2u: goto L_82BFD2;
    case 0x82BFD4u: goto L_82BFD4;
    case 0x82BFD5u: goto L_82BFD5;
    case 0x82BFD7u: goto L_82BFD7;
    case 0x82BFDBu: goto L_82BFDB;
    case 0x82BFDDu: goto L_82BFDD;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82BF6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF6Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF6Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF6E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BF70;
L_82BF70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF70u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF70u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF70 BNE -> $82BFCB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82BFCB; }
    goto L_82BF72;
L_82BF72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF72u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF72u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF72 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BF75;
L_82BF75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF75u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF75u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF75 CMP
    cpu.compareA(0x2u);
    goto L_82BF78;
L_82BF78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF78u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF78u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF78 BEQ -> $82BF86
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82BF86; }
    goto L_82BF7A;
L_82BF7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF7Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF7Au, 5u, 3u, cpu.address("abs", 0x02E8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF7A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2E8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BF7D;
L_82BF7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF7Du,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF7Du, 5u, 3u, cpu.address("abs", 0x02EAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF7D ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x2EAu), cpu.m8?8:16));
    goto L_82BF80;
L_82BF80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF80u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF80u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF80 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82BF82;
L_82BF82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF82u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF82u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF82 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BF84;
L_82BF84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF84u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF84u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF84 BRA -> $82BF98
    goto L_82BF98;
L_82BF86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF86u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF86u, 5u, 3u, cpu.address("abs", 0x02E8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF86 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2E8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BF89;
L_82BF89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF89u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF89u, 5u, 3u, cpu.address("abs", 0x02EAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF89 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x2EAu), cpu.m8?8:16));
    goto L_82BF8C;
L_82BF8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF8Cu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF8Cu, 5u, 3u, cpu.address("abs", 0x03E8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF8C ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x3E8u), cpu.m8?8:16));
    goto L_82BF8F;
L_82BF8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF8Fu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF8Fu, 5u, 3u, cpu.address("abs", 0x03EAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF8F ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x3EAu), cpu.m8?8:16));
    goto L_82BF92;
L_82BF92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF92u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF92u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF92 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82BF94;
L_82BF94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF94u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF94u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF94 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BF96;
L_82BF96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF96u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF96u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF96 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xA2u), cpu.m8?8:16));
    goto L_82BF98;
L_82BF98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF98u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF98u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF98 BIT
    cpu.bit(0x1000u, true);
    goto L_82BF9B;
L_82BF9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF9Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF9Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF9B BEQ -> $82BFCB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82BFCB; }
    goto L_82BF9D;
L_82BF9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF9Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF9Du, 5u, 3u, cpu.address("abs", 0x0193u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF9D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x193u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BFA0;
L_82BFA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFA0 BNE -> $82BFCC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82BFCC; }
    goto L_82BFA2;
L_82BFA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFA2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BFA4;
L_82BFA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFA4 BEQ -> $82BFAB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82BFAB; }
    goto L_82BFA6;
L_82BFA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA6u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA6u, 5u, 3u, cpu.address("abs", 0x0139u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFA6 STZ
    hw.write(cpu.address("abs", 0x139u), 0, cpu.m8?8:16);
    goto L_82BFA9;
L_82BFA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA9u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFA9 BRA -> $82BFCB
    goto L_82BFCB;
L_82BFAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFABu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFABu, 5u, 3u, cpu.address("abs", 0x0139u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFAB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x139u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BFAE;
L_82BFAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFAEu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFAEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFAE EOR
    cpu.logicXor(0xFFFFu);
    goto L_82BFB1;
L_82BFB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFB1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFB1u, 5u, 3u, cpu.address("abs", 0x0139u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFB1 STA
    hw.write(cpu.address("abs", 0x139u), cpu.a, cpu.m8?8:16);
    goto L_82BFB4;
L_82BFB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFB4u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFB4u, 8u, 3u, cpu.address("abs", 0x013Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFB4 INC
    cpu.incMem(hw, cpu.address("abs", 0x13Bu), cpu.m8?8:16);
    goto L_82BFB7;
L_82BFB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFB7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFB7u, 5u, 3u, cpu.address("abs", 0x0139u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFB7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x139u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BFBA;
L_82BFBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFBAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFBAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFBA BNE -> $82BFC1
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82BFC1; }
    goto L_82BFBC;
L_82BFBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFBCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFBCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFBC LDA
    cpu.setA(0x82u, 16);
    goto L_82BFBF;
L_82BFBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFBFu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFBFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFBF BRA -> $82BFC4
    goto L_82BFC4;
L_82BFC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFC1 LDA
    cpu.setA(0x81u, 16);
    goto L_82BFC4;
L_82BFC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC4u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFC4 SEP
    cpu.sep(0x20u);
    goto L_82BFC6;
L_82BFC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC6u, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFC6 STA
    hw.write(cpu.address("abs", 0x2140u), cpu.a, cpu.m8?8:16);
    goto L_82BFC9;
L_82BFC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC9u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFC9 REP
    cpu.rep(0x20u);
    goto L_82BFCB;
L_82BFCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFCBu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFCBu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFCBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82BFCB RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82BFCBu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82BFCBu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFCBu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFCBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82BFCB RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82BFCBu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82BFCBu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBFCBu,0x82BFCBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82BFCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFCCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFCCu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFCCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFCC SEP
    cpu.sep(0x20u);
    goto L_82BFCE;
L_82BFCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFCEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFCEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFCE LDA
    cpu.setA(0xCu, 8);
    goto L_82BFD0;
L_82BFD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFD0 STA
    hw.write(cpu.address("dp", 0x49u), cpu.a, cpu.m8?8:16);
    goto L_82BFD2;
L_82BFD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFD2 LDA
    cpu.setA(0x81u, 8);
    goto L_82BFD4;
L_82BFD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD4u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD4u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFD4 XBA
    cpu.xba();
    goto L_82BFD5;
L_82BFD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFD5 LDA
    cpu.setA(0xFu, 8);
    goto L_82BFD7;
L_82BFD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD7u, 8u, 4u, 0x8086F4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82BFD7 JSL -> $8086F4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBFDAu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBFDBu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8086F4u, 0x82BFD7u); }
    goto L_82BFDB;
L_82BFDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFDBu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBFDBu,0x82BFDBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFDBu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFDBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFDB REP
    cpu.rep(0x20u);
    goto L_82BFDD;
L_82BFDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFDDu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFDDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82BFDD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82BFDDu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82BFDDu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82BF6E_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82BF6Eu: goto L_82BF6E;
    case 0x82BF70u: goto L_82BF70;
    case 0x82BF72u: goto L_82BF72;
    case 0x82BF75u: goto L_82BF75;
    case 0x82BF78u: goto L_82BF78;
    case 0x82BF7Au: goto L_82BF7A;
    case 0x82BF7Du: goto L_82BF7D;
    case 0x82BF80u: goto L_82BF80;
    case 0x82BF82u: goto L_82BF82;
    case 0x82BF84u: goto L_82BF84;
    case 0x82BF86u: goto L_82BF86;
    case 0x82BF89u: goto L_82BF89;
    case 0x82BF8Cu: goto L_82BF8C;
    case 0x82BF8Fu: goto L_82BF8F;
    case 0x82BF92u: goto L_82BF92;
    case 0x82BF94u: goto L_82BF94;
    case 0x82BF96u: goto L_82BF96;
    case 0x82BF98u: goto L_82BF98;
    case 0x82BF9Bu: goto L_82BF9B;
    case 0x82BF9Du: goto L_82BF9D;
    case 0x82BFA0u: goto L_82BFA0;
    case 0x82BFA2u: goto L_82BFA2;
    case 0x82BFA4u: goto L_82BFA4;
    case 0x82BFA6u: goto L_82BFA6;
    case 0x82BFA9u: goto L_82BFA9;
    case 0x82BFABu: goto L_82BFAB;
    case 0x82BFAEu: goto L_82BFAE;
    case 0x82BFB1u: goto L_82BFB1;
    case 0x82BFB4u: goto L_82BFB4;
    case 0x82BFB7u: goto L_82BFB7;
    case 0x82BFBAu: goto L_82BFBA;
    case 0x82BFBCu: goto L_82BFBC;
    case 0x82BFBFu: goto L_82BFBF;
    case 0x82BFC1u: goto L_82BFC1;
    case 0x82BFC4u: goto L_82BFC4;
    case 0x82BFC6u: goto L_82BFC6;
    case 0x82BFC9u: goto L_82BFC9;
    case 0x82BFCBu: goto L_82BFCB;
    case 0x82BFCCu: goto L_82BFCC;
    case 0x82BFCEu: goto L_82BFCE;
    case 0x82BFD0u: goto L_82BFD0;
    case 0x82BFD2u: goto L_82BFD2;
    case 0x82BFD4u: goto L_82BFD4;
    case 0x82BFD5u: goto L_82BFD5;
    case 0x82BFD7u: goto L_82BFD7;
    case 0x82BFDBu: goto L_82BFDB;
    case 0x82BFDDu: goto L_82BFDD;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82BF6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF6Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF6Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF6E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BF70;
L_82BF70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF70u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF70u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF70 BNE -> $82BFCB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82BFCB; }
    goto L_82BF72;
L_82BF72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF72u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF72u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF72 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BF75;
L_82BF75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF75u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF75u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF75 CMP
    cpu.compareA(0x2u);
    goto L_82BF78;
L_82BF78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF78u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF78u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF78 BEQ -> $82BF86
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82BF86; }
    goto L_82BF7A;
L_82BF7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF7Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF7Au, 5u, 3u, cpu.address("abs", 0x02E8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF7A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2E8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BF7D;
L_82BF7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF7Du,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF7Du, 5u, 3u, cpu.address("abs", 0x02EAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF7D ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x2EAu), cpu.m8?8:16));
    goto L_82BF80;
L_82BF80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF80u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF80u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF80 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82BF82;
L_82BF82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF82u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF82u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF82 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BF84;
L_82BF84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF84u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF84u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF84 BRA -> $82BF98
    goto L_82BF98;
L_82BF86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF86u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF86u, 5u, 3u, cpu.address("abs", 0x02E8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF86 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2E8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BF89;
L_82BF89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF89u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF89u, 5u, 3u, cpu.address("abs", 0x02EAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF89 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x2EAu), cpu.m8?8:16));
    goto L_82BF8C;
L_82BF8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF8Cu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF8Cu, 5u, 3u, cpu.address("abs", 0x03E8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF8C ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x3E8u), cpu.m8?8:16));
    goto L_82BF8F;
L_82BF8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF8Fu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF8Fu, 5u, 3u, cpu.address("abs", 0x03EAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF8F ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x3EAu), cpu.m8?8:16));
    goto L_82BF92;
L_82BF92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF92u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF92u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF92 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82BF94;
L_82BF94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF94u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF94u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF94 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BF96;
L_82BF96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF96u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF96u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF96 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xA2u), cpu.m8?8:16));
    goto L_82BF98;
L_82BF98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF98u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF98u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF98 BIT
    cpu.bit(0x1000u, true);
    goto L_82BF9B;
L_82BF9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF9Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF9Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF9B BEQ -> $82BFCB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82BFCB; }
    goto L_82BF9D;
L_82BF9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF9Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF9Du, 5u, 3u, cpu.address("abs", 0x0193u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF9D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x193u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BFA0;
L_82BFA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFA0 BNE -> $82BFCC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82BFCC; }
    goto L_82BFA2;
L_82BFA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFA2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BFA4;
L_82BFA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFA4 BEQ -> $82BFAB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82BFAB; }
    goto L_82BFA6;
L_82BFA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA6u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA6u, 5u, 3u, cpu.address("abs", 0x0139u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFA6 STZ
    hw.write(cpu.address("abs", 0x139u), 0, cpu.m8?8:16);
    goto L_82BFA9;
L_82BFA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA9u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFA9 BRA -> $82BFCB
    goto L_82BFCB;
L_82BFAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFABu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFABu, 5u, 3u, cpu.address("abs", 0x0139u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFAB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x139u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BFAE;
L_82BFAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFAEu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFAEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFAE EOR
    cpu.logicXor(0xFFFFu);
    goto L_82BFB1;
L_82BFB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFB1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFB1u, 5u, 3u, cpu.address("abs", 0x0139u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFB1 STA
    hw.write(cpu.address("abs", 0x139u), cpu.a, cpu.m8?8:16);
    goto L_82BFB4;
L_82BFB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFB4u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFB4u, 8u, 3u, cpu.address("abs", 0x013Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFB4 INC
    cpu.incMem(hw, cpu.address("abs", 0x13Bu), cpu.m8?8:16);
    goto L_82BFB7;
L_82BFB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFB7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFB7u, 5u, 3u, cpu.address("abs", 0x0139u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFB7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x139u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BFBA;
L_82BFBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFBAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFBAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFBA BNE -> $82BFC1
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82BFC1; }
    goto L_82BFBC;
L_82BFBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFBCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFBCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFBC LDA
    cpu.setA(0x82u, 16);
    goto L_82BFBF;
L_82BFBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFBFu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFBFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFBF BRA -> $82BFC4
    goto L_82BFC4;
L_82BFC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFC1 LDA
    cpu.setA(0x81u, 16);
    goto L_82BFC4;
L_82BFC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC4u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFC4 SEP
    cpu.sep(0x20u);
    goto L_82BFC6;
L_82BFC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC6u, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFC6 STA
    hw.write(cpu.address("abs", 0x2140u), cpu.a, cpu.m8?8:16);
    goto L_82BFC9;
L_82BFC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC9u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFC9 REP
    cpu.rep(0x20u);
    goto L_82BFCB;
L_82BFCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFCBu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFCBu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFCBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82BFCB RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82BFCBu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82BFCBu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFCBu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFCBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82BFCB RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82BFCBu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82BFCBu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBFCBu,0x82BFCBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82BFCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFCCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFCCu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFCCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFCC SEP
    cpu.sep(0x20u);
    goto L_82BFCE;
L_82BFCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFCEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFCEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFCE LDA
    cpu.setA(0xCu, 8);
    goto L_82BFD0;
L_82BFD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFD0 STA
    hw.write(cpu.address("dp", 0x49u), cpu.a, cpu.m8?8:16);
    goto L_82BFD2;
L_82BFD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFD2 LDA
    cpu.setA(0x81u, 8);
    goto L_82BFD4;
L_82BFD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD4u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD4u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFD4 XBA
    cpu.xba();
    goto L_82BFD5;
L_82BFD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFD5 LDA
    cpu.setA(0xFu, 8);
    goto L_82BFD7;
L_82BFD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD7u, 8u, 4u, 0x8086F4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82BFD7 JSL -> $8086F4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBFDAu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBFDBu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8086F4u, 0x82BFD7u); }
    goto L_82BFDB;
L_82BFDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFDBu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBFDBu,0x82BFDBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFDBu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFDBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFDB REP
    cpu.rep(0x20u);
    goto L_82BFDD;
L_82BFDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFDDu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFDDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82BFDD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82BFDDu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82BFDDu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82BF6E_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82BF6Eu: goto L_82BF6E;
    case 0x82BF70u: goto L_82BF70;
    case 0x82BF72u: goto L_82BF72;
    case 0x82BF75u: goto L_82BF75;
    case 0x82BF78u: goto L_82BF78;
    case 0x82BF7Au: goto L_82BF7A;
    case 0x82BF7Du: goto L_82BF7D;
    case 0x82BF80u: goto L_82BF80;
    case 0x82BF82u: goto L_82BF82;
    case 0x82BF84u: goto L_82BF84;
    case 0x82BF86u: goto L_82BF86;
    case 0x82BF89u: goto L_82BF89;
    case 0x82BF8Cu: goto L_82BF8C;
    case 0x82BF8Fu: goto L_82BF8F;
    case 0x82BF92u: goto L_82BF92;
    case 0x82BF94u: goto L_82BF94;
    case 0x82BF96u: goto L_82BF96;
    case 0x82BF98u: goto L_82BF98;
    case 0x82BF9Bu: goto L_82BF9B;
    case 0x82BF9Du: goto L_82BF9D;
    case 0x82BFA0u: goto L_82BFA0;
    case 0x82BFA2u: goto L_82BFA2;
    case 0x82BFA4u: goto L_82BFA4;
    case 0x82BFA6u: goto L_82BFA6;
    case 0x82BFA9u: goto L_82BFA9;
    case 0x82BFABu: goto L_82BFAB;
    case 0x82BFAEu: goto L_82BFAE;
    case 0x82BFB1u: goto L_82BFB1;
    case 0x82BFB4u: goto L_82BFB4;
    case 0x82BFB7u: goto L_82BFB7;
    case 0x82BFBAu: goto L_82BFBA;
    case 0x82BFBCu: goto L_82BFBC;
    case 0x82BFBFu: goto L_82BFBF;
    case 0x82BFC1u: goto L_82BFC1;
    case 0x82BFC4u: goto L_82BFC4;
    case 0x82BFC6u: goto L_82BFC6;
    case 0x82BFC9u: goto L_82BFC9;
    case 0x82BFCBu: goto L_82BFCB;
    case 0x82BFCCu: goto L_82BFCC;
    case 0x82BFCEu: goto L_82BFCE;
    case 0x82BFD0u: goto L_82BFD0;
    case 0x82BFD2u: goto L_82BFD2;
    case 0x82BFD4u: goto L_82BFD4;
    case 0x82BFD5u: goto L_82BFD5;
    case 0x82BFD7u: goto L_82BFD7;
    case 0x82BFDBu: goto L_82BFDB;
    case 0x82BFDDu: goto L_82BFDD;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82BF6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF6Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF6Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF6E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BF70;
L_82BF70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF70u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF70u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF70 BNE -> $82BFCB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82BFCB; }
    goto L_82BF72;
L_82BF72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF72u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF72u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF72 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BF75;
L_82BF75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF75u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF75u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF75 CMP
    cpu.compareA(0x2u);
    goto L_82BF78;
L_82BF78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF78u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF78u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF78 BEQ -> $82BF86
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82BF86; }
    goto L_82BF7A;
L_82BF7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF7Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF7Au, 5u, 3u, cpu.address("abs", 0x02E8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF7A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2E8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BF7D;
L_82BF7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF7Du,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF7Du, 5u, 3u, cpu.address("abs", 0x02EAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF7D ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x2EAu), cpu.m8?8:16));
    goto L_82BF80;
L_82BF80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF80u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF80u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF80 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82BF82;
L_82BF82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF82u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF82u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF82 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BF84;
L_82BF84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF84u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF84u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF84 BRA -> $82BF98
    goto L_82BF98;
L_82BF86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF86u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF86u, 5u, 3u, cpu.address("abs", 0x02E8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF86 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2E8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BF89;
L_82BF89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF89u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF89u, 5u, 3u, cpu.address("abs", 0x02EAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF89 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x2EAu), cpu.m8?8:16));
    goto L_82BF8C;
L_82BF8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF8Cu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF8Cu, 5u, 3u, cpu.address("abs", 0x03E8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF8C ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x3E8u), cpu.m8?8:16));
    goto L_82BF8F;
L_82BF8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF8Fu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF8Fu, 5u, 3u, cpu.address("abs", 0x03EAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF8F ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x3EAu), cpu.m8?8:16));
    goto L_82BF92;
L_82BF92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF92u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF92u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF92 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82BF94;
L_82BF94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF94u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF94u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF94 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BF96;
L_82BF96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF96u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF96u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF96 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xA2u), cpu.m8?8:16));
    goto L_82BF98;
L_82BF98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF98u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF98u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF98 BIT
    cpu.bit(0x1000u, true);
    goto L_82BF9B;
L_82BF9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF9Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF9Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF9B BEQ -> $82BFCB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82BFCB; }
    goto L_82BF9D;
L_82BF9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF9Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF9Du, 5u, 3u, cpu.address("abs", 0x0193u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BF9D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x193u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BFA0;
L_82BFA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFA0 BNE -> $82BFCC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82BFCC; }
    goto L_82BFA2;
L_82BFA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFA2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BFA4;
L_82BFA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFA4 BEQ -> $82BFAB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82BFAB; }
    goto L_82BFA6;
L_82BFA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA6u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA6u, 5u, 3u, cpu.address("abs", 0x0139u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFA6 STZ
    hw.write(cpu.address("abs", 0x139u), 0, cpu.m8?8:16);
    goto L_82BFA9;
L_82BFA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA9u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFA9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFA9 BRA -> $82BFCB
    goto L_82BFCB;
L_82BFAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFABu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFABu, 5u, 3u, cpu.address("abs", 0x0139u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFAB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x139u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BFAE;
L_82BFAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFAEu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFAEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFAE EOR
    cpu.logicXor(0xFFFFu);
    goto L_82BFB1;
L_82BFB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFB1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFB1u, 5u, 3u, cpu.address("abs", 0x0139u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFB1 STA
    hw.write(cpu.address("abs", 0x139u), cpu.a, cpu.m8?8:16);
    goto L_82BFB4;
L_82BFB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFB4u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFB4u, 8u, 3u, cpu.address("abs", 0x013Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFB4 INC
    cpu.incMem(hw, cpu.address("abs", 0x13Bu), cpu.m8?8:16);
    goto L_82BFB7;
L_82BFB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFB7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFB7u, 5u, 3u, cpu.address("abs", 0x0139u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFB7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x139u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BFBA;
L_82BFBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFBAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFBAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFBA BNE -> $82BFC1
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82BFC1; }
    goto L_82BFBC;
L_82BFBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFBCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFBCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFBC LDA
    cpu.setA(0x82u, 16);
    goto L_82BFBF;
L_82BFBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFBFu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFBFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFBF BRA -> $82BFC4
    goto L_82BFC4;
L_82BFC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFC1 LDA
    cpu.setA(0x81u, 16);
    goto L_82BFC4;
L_82BFC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC4u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFC4 SEP
    cpu.sep(0x20u);
    goto L_82BFC6;
L_82BFC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC6u, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFC6 STA
    hw.write(cpu.address("abs", 0x2140u), cpu.a, cpu.m8?8:16);
    goto L_82BFC9;
L_82BFC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC9u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFC9 REP
    cpu.rep(0x20u);
    goto L_82BFCB;
L_82BFCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFCBu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFCBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82BFCB RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82BFCBu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82BFCBu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82BFCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFCCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFCCu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFCCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFCC SEP
    cpu.sep(0x20u);
    goto L_82BFCE;
L_82BFCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFCEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFCEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFCE LDA
    cpu.setA(0xCu, 8);
    goto L_82BFD0;
L_82BFD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFD0 STA
    hw.write(cpu.address("dp", 0x49u), cpu.a, cpu.m8?8:16);
    goto L_82BFD2;
L_82BFD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFD2 LDA
    cpu.setA(0x81u, 8);
    goto L_82BFD4;
L_82BFD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD4u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD4u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFD4 XBA
    cpu.xba();
    goto L_82BFD5;
L_82BFD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFD5 LDA
    cpu.setA(0xFu, 8);
    goto L_82BFD7;
L_82BFD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFD7u, 8u, 4u, 0x8086F4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82BFD7 JSL -> $8086F4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBFDAu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBFDBu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8086F4u, 0x82BFD7u); }
    goto L_82BFDB;
L_82BFDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFDBu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBFDBu,0x82BFDBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFDBu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFDBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BFDB REP
    cpu.rep(0x20u);
    goto L_82BFDD;
L_82BFDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFDDu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFDDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82BFDD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82BFDDu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82BFDDu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82C0E7_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82C0E7u: goto L_82C0E7;
    case 0x82C0EAu: goto L_82C0EA;
    case 0x82C0EDu: goto L_82C0ED;
    case 0x82C0F0u: goto L_82C0F0;
    case 0x82C0F3u: goto L_82C0F3;
    case 0x82C0F6u: goto L_82C0F6;
    case 0x82C0F9u: goto L_82C0F9;
    case 0x82C0FCu: goto L_82C0FC;
    case 0x82C0FFu: goto L_82C0FF;
    case 0x82C102u: goto L_82C102;
    case 0x82C105u: goto L_82C105;
    case 0x82C109u: goto L_82C109;
    case 0x82C10Cu: goto L_82C10C;
    case 0x82C10Fu: goto L_82C10F;
    case 0x82C111u: goto L_82C111;
    case 0x82C112u: goto L_82C112;
    case 0x82C115u: goto L_82C115;
    case 0x82C119u: goto L_82C119;
    case 0x82C11Cu: goto L_82C11C;
    case 0x82C11Fu: goto L_82C11F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82C0E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0E7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0E7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C0E7 LDA
    cpu.setA(0xE10u, 16);
    goto L_82C0EA;
L_82C0EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0EAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0EAu, 5u, 3u, cpu.address("abs", 0x0195u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C0EA STA
    hw.write(cpu.address("abs", 0x195u), cpu.a, cpu.m8?8:16);
    goto L_82C0ED;
L_82C0ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0EDu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0EDu, 5u, 3u, cpu.address("abs", 0x015Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C0ED STZ
    hw.write(cpu.address("abs", 0x15Au), 0, cpu.m8?8:16);
    goto L_82C0F0;
L_82C0F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F0u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C0F0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C0F3;
L_82C0F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F3u, 5u, 3u, cpu.address("abs", 0x0197u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C0F3 STA
    hw.write(cpu.address("abs", 0x197u), cpu.a, cpu.m8?8:16);
    goto L_82C0F6;
L_82C0F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F6u, 5u, 3u, cpu.address("abs", 0x0137u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C0F6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x137u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C0F9;
L_82C0F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F9u, 5u, 3u, cpu.address("abs", 0x0199u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C0F9 STA
    hw.write(cpu.address("abs", 0x199u), cpu.a, cpu.m8?8:16);
    goto L_82C0FC;
L_82C0FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0FCu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0FCu, 5u, 3u, cpu.address("abs", 0x02CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C0FC LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2CEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C0FF;
L_82C0FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0FFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0FFu, 5u, 3u, cpu.address("abs", 0x019Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C0FF STA
    hw.write(cpu.address("abs", 0x19Bu), cpu.a, cpu.m8?8:16);
    goto L_82C102;
L_82C102:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC102u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC102u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC102u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C102 STZ
    hw.write(cpu.address("abs", 0x135u), 0, cpu.m8?8:16);
    goto L_82C105;
L_82C105:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC105u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC105u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC105u, 8u, 4u, 0x8096A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82C105 JSL -> $8096A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC108u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC109u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8096A3u, 0x82C105u); }
    goto L_82C109;
L_82C109:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC109u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC109u,0x82C109u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC109u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC109u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C109 AND
    cpu.logicAnd(0x3u);
    goto L_82C10C;
L_82C10C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC10Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC10Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC10Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C10C CMP
    cpu.compareA(0x3u);
    goto L_82C10F;
L_82C10F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC10Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC10Fu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC10Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C10F BCC -> $82C112
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82C112; }
    goto L_82C111;
L_82C111:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC111u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC111u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC111u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C111 DEC
    cpu.decReg('A');
    goto L_82C112;
L_82C112:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC112u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC112u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC112u, 5u, 3u, cpu.address("abs", 0x0137u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C112 STA
    hw.write(cpu.address("abs", 0x137u), cpu.a, cpu.m8?8:16);
    goto L_82C115;
L_82C115:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC115u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC115u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC115u, 8u, 4u, 0x8096A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82C115 JSL -> $8096A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC118u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC119u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8096A3u, 0x82C115u); }
    goto L_82C119;
L_82C119:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC119u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC119u,0x82C119u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC119u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC119u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C119 AND
    cpu.logicAnd(0xFu);
    goto L_82C11C;
L_82C11C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC11Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC11Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC11Cu, 5u, 3u, cpu.address("abs", 0x02CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C11C STA
    hw.write(cpu.address("abs", 0x2CEu), cpu.a, cpu.m8?8:16);
    goto L_82C11F;
L_82C11F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC11Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC11Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC11Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C11F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C11Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C11Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82C0E7_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82C0E7u: goto L_82C0E7;
    case 0x82C0EAu: goto L_82C0EA;
    case 0x82C0EDu: goto L_82C0ED;
    case 0x82C0F0u: goto L_82C0F0;
    case 0x82C0F3u: goto L_82C0F3;
    case 0x82C0F6u: goto L_82C0F6;
    case 0x82C0F9u: goto L_82C0F9;
    case 0x82C0FCu: goto L_82C0FC;
    case 0x82C0FFu: goto L_82C0FF;
    case 0x82C102u: goto L_82C102;
    case 0x82C105u: goto L_82C105;
    case 0x82C109u: goto L_82C109;
    case 0x82C10Cu: goto L_82C10C;
    case 0x82C10Fu: goto L_82C10F;
    case 0x82C111u: goto L_82C111;
    case 0x82C112u: goto L_82C112;
    case 0x82C115u: goto L_82C115;
    case 0x82C119u: goto L_82C119;
    case 0x82C11Cu: goto L_82C11C;
    case 0x82C11Fu: goto L_82C11F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82C0E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0E7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0E7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C0E7 LDA
    cpu.setA(0xE10u, 16);
    goto L_82C0EA;
L_82C0EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0EAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0EAu, 5u, 3u, cpu.address("abs", 0x0195u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C0EA STA
    hw.write(cpu.address("abs", 0x195u), cpu.a, cpu.m8?8:16);
    goto L_82C0ED;
L_82C0ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0EDu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0EDu, 5u, 3u, cpu.address("abs", 0x015Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C0ED STZ
    hw.write(cpu.address("abs", 0x15Au), 0, cpu.m8?8:16);
    goto L_82C0F0;
L_82C0F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F0u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C0F0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C0F3;
L_82C0F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F3u, 5u, 3u, cpu.address("abs", 0x0197u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C0F3 STA
    hw.write(cpu.address("abs", 0x197u), cpu.a, cpu.m8?8:16);
    goto L_82C0F6;
L_82C0F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F6u, 5u, 3u, cpu.address("abs", 0x0137u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C0F6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x137u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C0F9;
L_82C0F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0F9u, 5u, 3u, cpu.address("abs", 0x0199u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C0F9 STA
    hw.write(cpu.address("abs", 0x199u), cpu.a, cpu.m8?8:16);
    goto L_82C0FC;
L_82C0FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0FCu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0FCu, 5u, 3u, cpu.address("abs", 0x02CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C0FC LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2CEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C0FF;
L_82C0FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0FFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0FFu, 5u, 3u, cpu.address("abs", 0x019Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C0FF STA
    hw.write(cpu.address("abs", 0x19Bu), cpu.a, cpu.m8?8:16);
    goto L_82C102;
L_82C102:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC102u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC102u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC102u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C102 STZ
    hw.write(cpu.address("abs", 0x135u), 0, cpu.m8?8:16);
    goto L_82C105;
L_82C105:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC105u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC105u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC105u, 8u, 4u, 0x8096A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82C105 JSL -> $8096A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC108u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC109u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8096A3u, 0x82C105u); }
    goto L_82C109;
L_82C109:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC109u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC109u,0x82C109u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC109u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC109u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C109 AND
    cpu.logicAnd(0x3u);
    goto L_82C10C;
L_82C10C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC10Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC10Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC10Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C10C CMP
    cpu.compareA(0x3u);
    goto L_82C10F;
L_82C10F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC10Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC10Fu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC10Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C10F BCC -> $82C112
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82C112; }
    goto L_82C111;
L_82C111:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC111u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC111u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC111u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C111 DEC
    cpu.decReg('A');
    goto L_82C112;
L_82C112:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC112u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC112u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC112u, 5u, 3u, cpu.address("abs", 0x0137u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C112 STA
    hw.write(cpu.address("abs", 0x137u), cpu.a, cpu.m8?8:16);
    goto L_82C115;
L_82C115:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC115u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC115u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC115u, 8u, 4u, 0x8096A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82C115 JSL -> $8096A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC118u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC119u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8096A3u, 0x82C115u); }
    goto L_82C119;
L_82C119:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC119u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC119u,0x82C119u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC119u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC119u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C119 AND
    cpu.logicAnd(0xFu);
    goto L_82C11C;
L_82C11C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC11Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC11Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC11Cu, 5u, 3u, cpu.address("abs", 0x02CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C11C STA
    hw.write(cpu.address("abs", 0x2CEu), cpu.a, cpu.m8?8:16);
    goto L_82C11F;
L_82C11F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC11Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC11Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC11Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C11F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C11Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C11Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82C326_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82C326u: goto L_82C326;
    case 0x82C329u: goto L_82C329;
    case 0x82C32Bu: goto L_82C32B;
    case 0x82C32Eu: goto L_82C32E;
    case 0x82C332u: goto L_82C332;
    case 0x82C334u: goto L_82C334;
    case 0x82C337u: goto L_82C337;
    case 0x82C339u: goto L_82C339;
    case 0x82C33Cu: goto L_82C33C;
    case 0x82C33Eu: goto L_82C33E;
    case 0x82C341u: goto L_82C341;
    case 0x82C343u: goto L_82C343;
    case 0x82C347u: goto L_82C347;
    case 0x82C34Au: goto L_82C34A;
    case 0x82C34Cu: goto L_82C34C;
    case 0x82C34Fu: goto L_82C34F;
    case 0x82C351u: goto L_82C351;
    case 0x82C354u: goto L_82C354;
    case 0x82C356u: goto L_82C356;
    case 0x82C359u: goto L_82C359;
    case 0x82C35Du: goto L_82C35D;
    case 0x82C360u: goto L_82C360;
    case 0x82C362u: goto L_82C362;
    case 0x82C366u: goto L_82C366;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82C326:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC326u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC326u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC326u, 5u, 3u, cpu.address("abs", 0x01AFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C326 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1AFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C329;
L_82C329:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC329u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC329u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC329u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C329 BEQ -> $82C366
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C366; }
    goto L_82C32B;
L_82C32B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC32Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC32Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC32Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C32B LDX
    cpu.setX(0x8u, 16);
    goto L_82C32E;
L_82C32E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC32Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC32Eu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC32Eu, 6u, 4u, ((0x9E8232u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C32E LDA
    cpu.loadA(hw.readW(((0x9E8232u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C332;
L_82C332:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC332u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC332u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC332u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C332 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82C334;
L_82C334:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC334u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC334u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC334u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C334 LDA
    cpu.setA(0x9Eu, 16);
    goto L_82C337;
L_82C337:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC337u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC337u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC337u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C337 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82C339;
L_82C339:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC339u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC339u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC339u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C339 LDA
    cpu.setA(0x5Cu, 16);
    goto L_82C33C;
L_82C33C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC33Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC33Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC33Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C33C STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82C33E;
L_82C33E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC33Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC33Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC33Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C33E LDA
    cpu.setA(0x80u, 16);
    goto L_82C341;
L_82C341:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC341u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC341u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC341u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C341 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82C343;
L_82C343:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC343u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC343u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC343u, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82C343 JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC346u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC347u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x82C343u); }
    goto L_82C347;
L_82C347:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC347u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC347u,0x82C347u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC347u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC347u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C347 LDA
    cpu.setA(0x95FEu, 16);
    goto L_82C34A;
L_82C34A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC34Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC34Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC34Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C34A STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82C34C;
L_82C34C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC34Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC34Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC34Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C34C LDA
    cpu.setA(0x9Eu, 16);
    goto L_82C34F;
L_82C34F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC34Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC34Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC34Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C34F STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82C351;
L_82C351:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC351u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC351u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC351u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C351 LDA
    cpu.setA(0x78u, 16);
    goto L_82C354;
L_82C354:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC354u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC354u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC354u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C354 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82C356;
L_82C356:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC356u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC356u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC356u, 5u, 3u, cpu.address("abs", 0x0177u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C356 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x177u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82C359;
L_82C359:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC359u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC359u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC359u, 6u, 4u, ((0x82C367u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C359 LDA
    cpu.loadA(hw.readW(((0x82C367u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C35D;
L_82C35D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC35Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC35Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC35Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C35D AND
    cpu.logicAnd(0xFFu);
    goto L_82C360;
L_82C360:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC360u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC360u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC360u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C360 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82C362;
L_82C362:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC362u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC362u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC362u, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82C362 JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC365u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC366u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x82C362u); }
    goto L_82C366;
L_82C366:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC366u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC366u,0x82C366u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC366u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC366u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C366 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C366u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C366u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82C326_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82C326u: goto L_82C326;
    case 0x82C329u: goto L_82C329;
    case 0x82C32Bu: goto L_82C32B;
    case 0x82C32Eu: goto L_82C32E;
    case 0x82C332u: goto L_82C332;
    case 0x82C334u: goto L_82C334;
    case 0x82C337u: goto L_82C337;
    case 0x82C339u: goto L_82C339;
    case 0x82C33Cu: goto L_82C33C;
    case 0x82C33Eu: goto L_82C33E;
    case 0x82C341u: goto L_82C341;
    case 0x82C343u: goto L_82C343;
    case 0x82C347u: goto L_82C347;
    case 0x82C34Au: goto L_82C34A;
    case 0x82C34Cu: goto L_82C34C;
    case 0x82C34Fu: goto L_82C34F;
    case 0x82C351u: goto L_82C351;
    case 0x82C354u: goto L_82C354;
    case 0x82C356u: goto L_82C356;
    case 0x82C359u: goto L_82C359;
    case 0x82C35Du: goto L_82C35D;
    case 0x82C360u: goto L_82C360;
    case 0x82C362u: goto L_82C362;
    case 0x82C366u: goto L_82C366;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82C326:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC326u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC326u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC326u, 5u, 3u, cpu.address("abs", 0x01AFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C326 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1AFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C329;
L_82C329:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC329u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC329u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC329u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C329 BEQ -> $82C366
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C366; }
    goto L_82C32B;
L_82C32B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC32Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC32Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC32Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C32B LDX
    cpu.setX(0x8u, 16);
    goto L_82C32E;
L_82C32E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC32Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC32Eu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC32Eu, 6u, 4u, ((0x9E8232u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C32E LDA
    cpu.loadA(hw.readW(((0x9E8232u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C332;
L_82C332:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC332u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC332u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC332u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C332 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82C334;
L_82C334:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC334u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC334u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC334u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C334 LDA
    cpu.setA(0x9Eu, 16);
    goto L_82C337;
L_82C337:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC337u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC337u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC337u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C337 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82C339;
L_82C339:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC339u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC339u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC339u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C339 LDA
    cpu.setA(0x5Cu, 16);
    goto L_82C33C;
L_82C33C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC33Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC33Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC33Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C33C STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82C33E;
L_82C33E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC33Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC33Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC33Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C33E LDA
    cpu.setA(0x80u, 16);
    goto L_82C341;
L_82C341:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC341u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC341u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC341u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C341 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82C343;
L_82C343:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC343u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC343u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC343u, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82C343 JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC346u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC347u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x82C343u); }
    goto L_82C347;
L_82C347:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC347u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC347u,0x82C347u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC347u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC347u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C347 LDA
    cpu.setA(0x95FEu, 16);
    goto L_82C34A;
L_82C34A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC34Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC34Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC34Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C34A STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82C34C;
L_82C34C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC34Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC34Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC34Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C34C LDA
    cpu.setA(0x9Eu, 16);
    goto L_82C34F;
L_82C34F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC34Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC34Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC34Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C34F STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82C351;
L_82C351:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC351u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC351u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC351u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C351 LDA
    cpu.setA(0x78u, 16);
    goto L_82C354;
L_82C354:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC354u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC354u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC354u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C354 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82C356;
L_82C356:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC356u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC356u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC356u, 5u, 3u, cpu.address("abs", 0x0177u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C356 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x177u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82C359;
L_82C359:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC359u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC359u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC359u, 6u, 4u, ((0x82C367u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C359 LDA
    cpu.loadA(hw.readW(((0x82C367u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C35D;
L_82C35D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC35Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC35Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC35Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C35D AND
    cpu.logicAnd(0xFFu);
    goto L_82C360;
L_82C360:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC360u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC360u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC360u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C360 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82C362;
L_82C362:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC362u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC362u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC362u, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82C362 JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC365u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC366u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x82C362u); }
    goto L_82C366;
L_82C366:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC366u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC366u,0x82C366u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC366u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC366u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C366 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C366u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C366u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82DC4D_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82DC4Du: goto L_82DC4D;
    case 0x82DC4Fu: goto L_82DC4F;
    case 0x82DC52u: goto L_82DC52;
    case 0x82DC54u: goto L_82DC54;
    case 0x82DC56u: goto L_82DC56;
    case 0x82DC59u: goto L_82DC59;
    case 0x82DC5Bu: goto L_82DC5B;
    case 0x82DC5Fu: goto L_82DC5F;
    case 0x82DC60u: goto L_82DC60;
    case 0x82DC62u: goto L_82DC62;
    case 0x82DC63u: goto L_82DC63;
    case 0x82DC64u: goto L_82DC64;
    case 0x82DC65u: goto L_82DC65;
    case 0x82DC66u: goto L_82DC66;
    case 0x82DC69u: goto L_82DC69;
    case 0x82DC6Du: goto L_82DC6D;
    case 0x82DC6Fu: goto L_82DC6F;
    case 0x82DC71u: goto L_82DC71;
    case 0x82DC73u: goto L_82DC73;
    case 0x82DC75u: goto L_82DC75;
    case 0x82DC78u: goto L_82DC78;
    case 0x82DC7Au: goto L_82DC7A;
    case 0x82DC7Cu: goto L_82DC7C;
    case 0x82DC7Eu: goto L_82DC7E;
    case 0x82DC81u: goto L_82DC81;
    case 0x82DC82u: goto L_82DC82;
    case 0x82DC84u: goto L_82DC84;
    case 0x82DC88u: goto L_82DC88;
    case 0x82DC8Bu: goto L_82DC8B;
    case 0x82DC8Du: goto L_82DC8D;
    case 0x82DC8Eu: goto L_82DC8E;
    case 0x82DC91u: goto L_82DC91;
    case 0x82DC92u: goto L_82DC92;
    case 0x82DC95u: goto L_82DC95;
    case 0x82DC96u: goto L_82DC96;
    case 0x82DC98u: goto L_82DC98;
    case 0x82DC9Au: goto L_82DC9A;
    case 0x82DC9Cu: goto L_82DC9C;
    case 0x82DC9Fu: goto L_82DC9F;
    case 0x82DCA0u: goto L_82DCA0;
    case 0x82DCA1u: goto L_82DCA1;
    case 0x82DCA3u: goto L_82DCA3;
    case 0x82DCA5u: goto L_82DCA5;
    case 0x82DCA8u: goto L_82DCA8;
    case 0x82DCA9u: goto L_82DCA9;
    case 0x82DCABu: goto L_82DCAB;
    case 0x82DCACu: goto L_82DCAC;
    case 0x82DCB0u: goto L_82DCB0;
    case 0x82DCB2u: goto L_82DCB2;
    case 0x82DCB5u: goto L_82DCB5;
    case 0x82DCB7u: goto L_82DCB7;
    case 0x82DCB9u: goto L_82DCB9;
    case 0x82DCBCu: goto L_82DCBC;
    case 0x82DCBEu: goto L_82DCBE;
    case 0x82DCC0u: goto L_82DCC0;
    case 0x82DCC2u: goto L_82DCC2;
    case 0x82DCC5u: goto L_82DCC5;
    case 0x82DCC8u: goto L_82DCC8;
    case 0x82DCCAu: goto L_82DCCA;
    case 0x82DCCBu: goto L_82DCCB;
    case 0x82DCCCu: goto L_82DCCC;
    case 0x82DCCFu: goto L_82DCCF;
    case 0x82DCD1u: goto L_82DCD1;
    case 0x82DCD3u: goto L_82DCD3;
    case 0x82DCD5u: goto L_82DCD5;
    case 0x82DCD7u: goto L_82DCD7;
    case 0x82DCD9u: goto L_82DCD9;
    case 0x82DCDCu: goto L_82DCDC;
    case 0x82DCDEu: goto L_82DCDE;
    case 0x82DCE0u: goto L_82DCE0;
    case 0x82DCE2u: goto L_82DCE2;
    case 0x82DCE5u: goto L_82DCE5;
    case 0x82DCE7u: goto L_82DCE7;
    case 0x82DCE9u: goto L_82DCE9;
    case 0x82DCEAu: goto L_82DCEA;
    case 0x82DCEBu: goto L_82DCEB;
    case 0x82DCEDu: goto L_82DCED;
    case 0x82DCEFu: goto L_82DCEF;
    case 0x82DCF1u: goto L_82DCF1;
    case 0x82DCF4u: goto L_82DCF4;
    case 0x82DCF6u: goto L_82DCF6;
    case 0x82DCF8u: goto L_82DCF8;
    case 0x82DCFAu: goto L_82DCFA;
    case 0x82DCFCu: goto L_82DCFC;
    case 0x82DCFFu: goto L_82DCFF;
    case 0x82DD01u: goto L_82DD01;
    case 0x82DD04u: goto L_82DD04;
    case 0x82DD07u: goto L_82DD07;
    case 0x82DD0Au: goto L_82DD0A;
    case 0x82DD0Du: goto L_82DD0D;
    case 0x82DD0Eu: goto L_82DD0E;
    case 0x82DD11u: goto L_82DD11;
    case 0x82DD12u: goto L_82DD12;
    case 0x82DD15u: goto L_82DD15;
    case 0x82DD18u: goto L_82DD18;
    case 0x82DD1Au: goto L_82DD1A;
    case 0x82DD1Du: goto L_82DD1D;
    case 0x82DD1Fu: goto L_82DD1F;
    case 0x82DD22u: goto L_82DD22;
    case 0x82DD24u: goto L_82DD24;
    case 0x82DD28u: goto L_82DD28;
    case 0x82DD2Bu: goto L_82DD2B;
    case 0x82DD2Eu: goto L_82DD2E;
    case 0x82DD31u: goto L_82DD31;
    case 0x82DD34u: goto L_82DD34;
    case 0x82DD37u: goto L_82DD37;
    case 0x82DD39u: goto L_82DD39;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82DC4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC4Du,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC4Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC4D STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_82DC4F;
L_82DC4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC4Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC4Fu, 5u, 3u, cpu.address("abs", 0x015Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC4F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x15Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DC52;
L_82DC52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC52u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC52u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC52 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82DC54;
L_82DC54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC54u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC54u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC54u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC54 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82DC56;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC54u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC54u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC54 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82DC56;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC54u,0x82DC54u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82DC56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC56u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC56u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC56u, 5u + 1u, 3u, cpu.address("absx", 0x015Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC56 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DC59;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC56u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC56u, 5u + 1u, 3u, cpu.address("absx", 0x015Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC56 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DC59;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC56u,0x82DC56u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82DC59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC59u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC59u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC59u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC59 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_82DC5B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC59u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC59u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC59 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_82DC5B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC59u,0x82DC59u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82DC5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC5Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC5Bu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC5Bu, 6u, 4u, ((0x82DD46u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC5B LDA
    cpu.loadA(hw.readW(((0x82DD46u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DC5F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC5Bu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC5Bu, 6u, 4u, ((0x82DD46u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC5B LDA
    cpu.loadA(hw.readW(((0x82DD46u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DC5F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC5Bu,0x82DC5Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82DC5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC5Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC5Fu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC5Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC5F TAX
    cpu.transfer("TAX");
    goto L_82DC60;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC5Fu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC5Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC5F TAX
    cpu.transfer("TAX");
    goto L_82DC60;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC5Fu,0x82DC5Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82DC60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC60u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC60u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC60u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC60 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DC62;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC60u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC60u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC60 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DC62;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC60u,0x82DC60u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82DC62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC62u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC62u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC62u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC62 INC
    cpu.inc('A');
    goto L_82DC63;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC62u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC62u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC62 INC
    cpu.inc('A');
    goto L_82DC63;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC62u,0x82DC62u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82DC63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC63u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC63u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC63u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC63 ASL
    cpu.aslA();
    goto L_82DC64;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC63u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC63u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC63 ASL
    cpu.aslA();
    goto L_82DC64;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC63u,0x82DC63u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82DC64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC64u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC64u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC64 ASL
    cpu.aslA();
    goto L_82DC65;
L_82DC65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC65u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC65u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC65 XBA
    cpu.xba();
    goto L_82DC66;
L_82DC66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC66u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC66u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC66 ORA
    cpu.logicOr(0x11u);
    goto L_82DC69;
L_82DC69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC69u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC69u, 6u, 4u, ((0x7E2800u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC69 STA
    hw.write(((0x7E2800u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82DC6D;
L_82DC6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC6Du,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC6Du, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC6D INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_82DC6F;
L_82DC6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC6Fu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC6Fu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC6F INC
    cpu.incMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_82DC71;
L_82DC71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC71u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC71u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC71 DEC
    cpu.decMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_82DC73;
L_82DC73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC73u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC73u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC73 BNE -> $82DC54
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82DC54; }
    goto L_82DC75;
L_82DC75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC75u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC75u, 5u, 3u, cpu.address("abs", 0x015Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC75 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x15Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DC78;
L_82DC78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC78u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC78u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC78 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82DC7A;
L_82DC7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC7Au,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC7Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC7A STZ
    hw.write(cpu.address("dp", 0x61u), 0, cpu.m8?8:16);
    goto L_82DC7C;
L_82DC7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC7Cu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC7Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC7C LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82DC7E;
L_82DC7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC7Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC7Eu, 5u + 1u, 3u, cpu.address("absx", 0x015Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC7E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DC81;
L_82DC81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC81u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC81u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC81 XBA
    cpu.xba();
    goto L_82DC82;
L_82DC82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC82u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC82u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC82 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_82DC84;
L_82DC84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC84u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC84u, 8u, 4u, 0x8096A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82DC84 JSL -> $8096A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDC87u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDC88u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8096A3u, 0x82DC84u); }
    goto L_82DC88;
L_82DC88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC88u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC88u,0x82DC88u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC88u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC88u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC88 AND
    cpu.logicAnd(0xFu);
    goto L_82DC8B;
L_82DC8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC8Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC8Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC8B BEQ -> $82DC98
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82DC98; }
    goto L_82DC8D;
L_82DC8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC8Du,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC8Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC8D TAX
    cpu.transfer("TAX");
    goto L_82DC8E;
L_82DC8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC8Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC8Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC8E LDA
    cpu.setA(0x0u, 16);
    goto L_82DC91;
L_82DC91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC91u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC91u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC91 CLC
    cpu.setFlag('C', false);
    goto L_82DC92;
L_82DC92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC92u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC92u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC92 ADC
    cpu.adc(0x16u);
    goto L_82DC95;
L_82DC95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC95u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC95u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC95 DEX
    cpu.decReg('X');
    goto L_82DC96;
L_82DC96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC96u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC96u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC96 BPL -> $82DC91
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82DC91; }
    goto L_82DC98;
L_82DC98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC98u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC98u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC98 STA
    hw.write(cpu.address("dp", 0x65u), cpu.a, cpu.m8?8:16);
    goto L_82DC9A;
L_82DC9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC9Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC9Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC9A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x52u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DC9C;
L_82DC9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC9Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC9Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC9C AND
    cpu.logicAnd(0x7u);
    goto L_82DC9F;
L_82DC9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC9Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC9Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC9F ASL
    cpu.aslA();
    goto L_82DCA0;
L_82DCA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCA0u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCA0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCA0 CLC
    cpu.setFlag('C', false);
    goto L_82DCA1;
L_82DCA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCA1u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCA1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCA1 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x65u), cpu.m8?8:16));
    goto L_82DCA3;
L_82DCA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCA3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCA3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCA3 STA
    hw.write(cpu.address("dp", 0x65u), cpu.a, cpu.m8?8:16);
    goto L_82DCA5;
L_82DCA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCA5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCA5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCA5 LDA
    cpu.setA(0x1E2u, 16);
    goto L_82DCA8;
L_82DCA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCA8u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCA8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCA8 SEC
    cpu.setFlag('C', true);
    goto L_82DCA9;
L_82DCA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCA9u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCA9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCA9 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x65u), cpu.m8?8:16));
    goto L_82DCAB;
L_82DCAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCABu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCABu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCAB TAX
    cpu.transfer("TAX");
    goto L_82DCAC;
L_82DCAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCACu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCACu, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCAC LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DCB0;
L_82DCB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCB0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCB0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCB0 BEQ -> $82DCCA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82DCCA; }
    goto L_82DCB2;
L_82DCB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCB2u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCB2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCB2 CMP
    cpu.compareA(0xFFFFu);
    goto L_82DCB5;
L_82DCB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCB5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCB5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCB5 BEQ -> $82DCCA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82DCCA; }
    goto L_82DCB7;
L_82DCB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCB7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCB7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCB7 STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_82DCB9;
L_82DCB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCB9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCB9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCB9 AND
    cpu.logicAnd(0x300u);
    goto L_82DCBC;
L_82DCBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCBCu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCBCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCBC CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_82DCBE;
L_82DCBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCBEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCBEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCBE BNE -> $82DCCA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82DCCA; }
    goto L_82DCC0;
L_82DCC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCC0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCC0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCC0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DCC2;
L_82DCC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCC2u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCC2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCC2 AND
    cpu.logicAnd(0xFu);
    goto L_82DCC5;
L_82DCC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCC5u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCC5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCC5 CMP
    cpu.compareA(0xFu);
    goto L_82DCC8;
L_82DCC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCC8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCC8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCC8 BEQ -> $82DCD3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82DCD3; }
    goto L_82DCCA;
L_82DCCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCCAu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCCAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCCA DEX
    cpu.decReg('X');
    goto L_82DCCB;
L_82DCCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCCBu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCCBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCCB DEX
    cpu.decReg('X');
    goto L_82DCCC;
L_82DCCC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCCCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCCCu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCCCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCCC CPX
    cpu.compareX(0x30u);
    goto L_82DCCF;
L_82DCCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCCFu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCCFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCCF BCC -> $82DC84
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82DC84; }
    goto L_82DCD1;
L_82DCD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCD1u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCD1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCD1 BRA -> $82DCAC
    goto L_82DCAC;
L_82DCD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCD3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCD3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCD3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x61u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DCD5;
L_82DCD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCD5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCD5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCD5 STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_82DCD7;
L_82DCD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCD7u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCD7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCD7 STX
    hw.write(cpu.address("dp", 0x63u), cpu.x, cpu.x8?8:16);
    goto L_82DCD9;
L_82DCD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCD9u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCD9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCD9 LDX
    cpu.setX(0x0u, 16);
    goto L_82DCDC;
L_82DCDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCDCu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCDCu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCDC DEC
    cpu.decMem(hw, cpu.address("dp", 0x6u), cpu.m8?8:16);
    goto L_82DCDE;
L_82DCDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCDEu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCDEu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCDE DEC
    cpu.decMem(hw, cpu.address("dp", 0x6u), cpu.m8?8:16);
    goto L_82DCE0;
L_82DCE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCE0u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCE0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCE0 BMI -> $82DCED
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82DCED; }
    goto L_82DCE2;
L_82DCE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCE2u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCE2u, 5u + 1u, 3u, cpu.address("absx", 0x015Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCE2 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x15Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DCE5;
L_82DCE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCE5u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCE5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCE5 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x63u), cpu.m8?8:16));
    goto L_82DCE7;
L_82DCE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCE7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCE7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCE7 BEQ -> $82DCFF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82DCFF; }
    goto L_82DCE9;
L_82DCE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCE9u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCE9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCE9 INX
    cpu.inc('X');
    goto L_82DCEA;
L_82DCEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCEAu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCEAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCEA INX
    cpu.inc('X');
    goto L_82DCEB;
L_82DCEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCEBu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCEBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCEB BRA -> $82DCDC
    goto L_82DCDC;
L_82DCED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCEDu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCEDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCED LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82DCEF;
L_82DCEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCEFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCEFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCEF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x63u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DCF1;
L_82DCF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCF1u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCF1u, 6u, 3u, cpu.address("absx", 0x015Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCF1 STA
    hw.write(cpu.address("absx", 0x15Cu), cpu.a, cpu.m8?8:16);
    goto L_82DCF4;
L_82DCF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCF4u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCF4u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCF4 INC
    cpu.incMem(hw, cpu.address("dp", 0x61u), cpu.m8?8:16);
    goto L_82DCF6;
L_82DCF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCF6u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCF6u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCF6 INC
    cpu.incMem(hw, cpu.address("dp", 0x61u), cpu.m8?8:16);
    goto L_82DCF8;
L_82DCF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCF8u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCF8u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCF8 DEC
    cpu.decMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_82DCFA;
L_82DCFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCFAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCFAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCFA BEQ -> $82DD04
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82DD04; }
    goto L_82DCFC;
L_82DCFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCFCu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCFCu, 3u, 3u, cpu.address("abs", 0xDC7Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCFC JMP -> $82DC7C
    goto L_82DC7C;
L_82DCFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDCFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDCFFu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDCFFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DCFF LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82DD01;
L_82DD01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD01u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD01u, 3u, 3u, cpu.address("abs", 0xDCCAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD01 JMP -> $82DCCA
    goto L_82DCCA;
L_82DD04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD04u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD04u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD04 LDA
    cpu.setA(0x0u, 16);
    goto L_82DD07;
L_82DD07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD07u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD07u, 5u, 3u, cpu.address("abs", 0x013Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD07 STA
    hw.write(cpu.address("abs", 0x13Fu), cpu.a, cpu.m8?8:16);
    goto L_82DD0A;
L_82DD0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD0Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD0Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD0A LDA
    cpu.setA(0x84u, 16);
    goto L_82DD0D;
L_82DD0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD0Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD0Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD0D CLC
    cpu.setFlag('C', false);
    goto L_82DD0E;
L_82DD0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD0Eu,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD0Eu, 5u, 3u, cpu.address("abs", 0x013Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD0E ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x13Fu), cpu.m8?8:16));
    goto L_82DD11;
L_82DD11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD11u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD11u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD11 TAX
    cpu.transfer("TAX");
    goto L_82DD12;
L_82DD12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD12u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD12u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD12 LDY
    cpu.setY(0x0u, 16);
    goto L_82DD15;
L_82DD15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD15u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD15u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD15 LDA
    cpu.setA(0xDD3Au, 16);
    goto L_82DD18;
L_82DD18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD18u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD18u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD18 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82DD1A;
L_82DD1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD1Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD1Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD1A LDA
    cpu.setA(0x82u, 16);
    goto L_82DD1D;
L_82DD1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD1Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD1Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD1D STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82DD1F;
L_82DD1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD1Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD1Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD1F LDA
    cpu.setA(0x3400u, 16);
    goto L_82DD22;
L_82DD22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD22u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD22u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD22 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_82DD24;
L_82DD24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD24u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD24u, 8u, 4u, 0x809BFBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82DD24 JSL -> $809BFB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDD27u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDD28u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809BFBu, 0x82DD24u); }
    goto L_82DD28;
L_82DD28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD28u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDD28u,0x82DD28u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD28u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD28u, 8u, 3u, cpu.address("abs", 0x013Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD28 INC
    cpu.incMem(hw, cpu.address("abs", 0x13Bu), cpu.m8?8:16);
    goto L_82DD2B;
L_82DD2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD2Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD2Bu, 5u, 3u, cpu.address("abs", 0x0170u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD2B STZ
    hw.write(cpu.address("abs", 0x170u), 0, cpu.m8?8:16);
    goto L_82DD2E;
L_82DD2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD2Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD2Eu, 5u, 3u, cpu.address("abs", 0x0174u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD2E STZ
    hw.write(cpu.address("abs", 0x174u), 0, cpu.m8?8:16);
    goto L_82DD31;
L_82DD31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD31u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD31u, 5u, 3u, cpu.address("abs", 0x0172u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD31 STZ
    hw.write(cpu.address("abs", 0x172u), 0, cpu.m8?8:16);
    goto L_82DD34;
L_82DD34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD34u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD34u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD34 LDA
    cpu.setA(0x10u, 16);
    goto L_82DD37;
L_82DD37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD37u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD37u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DD37 STA
    hw.write(cpu.address("dp", 0x6Fu), cpu.a, cpu.m8?8:16);
    goto L_82DD39;
L_82DD39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDD39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDD39u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDD39u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82DD39 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82DD39u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82DD39u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8494D7_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8494D7u: goto L_8494D7;
    case 0x8494D9u: goto L_8494D9;
    case 0x8494DAu: goto L_8494DA;
    case 0x8494DBu: goto L_8494DB;
    case 0x8494DCu: goto L_8494DC;
    case 0x8494DFu: goto L_8494DF;
    case 0x8494E0u: goto L_8494E0;
    case 0x8494E3u: goto L_8494E3;
    case 0x8494E5u: goto L_8494E5;
    case 0x8494E8u: goto L_8494E8;
    case 0x8494EAu: goto L_8494EA;
    case 0x8494ECu: goto L_8494EC;
    case 0x8494EFu: goto L_8494EF;
    case 0x8494F1u: goto L_8494F1;
    case 0x8494F3u: goto L_8494F3;
    case 0x8494F6u: goto L_8494F6;
    case 0x8494F8u: goto L_8494F8;
    case 0x8494FAu: goto L_8494FA;
    case 0x8494FCu: goto L_8494FC;
    case 0x8494FFu: goto L_8494FF;
    case 0x849501u: goto L_849501;
    case 0x849504u: goto L_849504;
    case 0x849505u: goto L_849505;
    case 0x849506u: goto L_849506;
    case 0x849508u: goto L_849508;
    case 0x84950Cu: goto L_84950C;
    case 0x84950Eu: goto L_84950E;
    case 0x849511u: goto L_849511;
    case 0x849513u: goto L_849513;
    case 0x849516u: goto L_849516;
    case 0x849518u: goto L_849518;
    case 0x84951Au: goto L_84951A;
    case 0x84951Cu: goto L_84951C;
    case 0x84951Eu: goto L_84951E;
    case 0x84951Fu: goto L_84951F;
    case 0x849522u: goto L_849522;
    case 0x849524u: goto L_849524;
    case 0x849526u: goto L_849526;
    case 0x849529u: goto L_849529;
    case 0x84952Cu: goto L_84952C;
    case 0x84952Eu: goto L_84952E;
    case 0x849531u: goto L_849531;
    case 0x849533u: goto L_849533;
    case 0x849535u: goto L_849535;
    case 0x849536u: goto L_849536;
    case 0x849539u: goto L_849539;
    case 0x84953Bu: goto L_84953B;
    case 0x84953Cu: goto L_84953C;
    case 0x84953Du: goto L_84953D;
    case 0x84953Fu: goto L_84953F;
    case 0x849540u: goto L_849540;
    case 0x849543u: goto L_849543;
    case 0x849545u: goto L_849545;
    case 0x849547u: goto L_849547;
    case 0x849548u: goto L_849548;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8494D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94D7u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94D7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494D7 REP
    cpu.rep(0x20u);
    goto L_8494D9;
L_8494D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94D9u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94D9u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8494D9 PHB
    cpu.push("PHB", hw);
    goto L_8494DA;
L_8494DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94DAu,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94DAu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8494DA PHK
    cpu.push("PHK", hw);
    goto L_8494DB;
L_8494DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94DBu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94DBu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8494DB PLB
    cpu.pop("PLB", hw);
    goto L_8494DC;
L_8494DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94DCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94DCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494DC LDA
    cpu.setA(0x2800u, 16);
    goto L_8494DF;
L_8494DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94DFu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94DFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494DF CLC
    cpu.setFlag('C', false);
    goto L_8494E0;
L_8494E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94E0u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94E0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494E0 ADC
    cpu.adc(0x146u);
    goto L_8494E3;
L_8494E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94E3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94E3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494E3 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_8494E5;
L_8494E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94E5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94E5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494E5 LDA
    cpu.setA(0x7Eu, 16);
    goto L_8494E8;
L_8494E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94E8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94E8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494E8 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_8494EA;
L_8494EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94EAu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94EAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494EA SEP
    cpu.sep(0x20u);
    goto L_8494EC;
L_8494EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94ECu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94ECu, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494EC LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8494EF;
L_8494EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94EFu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94EFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494EF BIT
    cpu.bit(0x1u, true);
    goto L_8494F1;
L_8494F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94F1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94F1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494F1 BEQ -> $8494FC
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8494FC; }
    goto L_8494F3;
L_8494F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94F3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94F3u, 4u, 3u, cpu.address("abs", 0x062Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494F3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8494F6;
L_8494F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94F6u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94F6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494F6 AND
    cpu.logicAnd(0x1u);
    goto L_8494F8;
L_8494F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94F8u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94F8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494F8 ORA
    cpu.logicOr(0x2u);
    goto L_8494FA;
L_8494FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94FAu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94FAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494FA BRA -> $849501
    goto L_849501;
L_8494FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94FCu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94FCu, 4u, 3u, cpu.address("abs", 0x062Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494FC LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8494FF;
L_8494FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94FFu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94FFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494FF AND
    cpu.logicAnd(0x1u);
    goto L_849501;
L_849501:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9501u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9501u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9501u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849501 LDX
    cpu.setX(0x0u, 16);
    goto L_849504;
L_849504:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9504u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9504u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9504u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849504 ASL
    cpu.aslA();
    goto L_849505;
L_849505:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9505u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9505u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9505u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849505 TAX
    cpu.transfer("TAX");
    goto L_849506;
L_849506:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9506u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9506u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9506u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849506 REP
    cpu.rep(0x20u);
    goto L_849508;
L_849508:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9508u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9508u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9508u, 6u, 4u, ((0x849549u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849508 LDA
    cpu.loadA(hw.readW(((0x849549u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84950C;
L_84950C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x950Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x950Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x950Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84950C STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_84950E;
L_84950E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x950Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x950Eu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x950Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84950E LDY
    cpu.setY(0x0u, 16);
    goto L_849511;
L_849511:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9511u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9511u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9511u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x04u) & 0xFFFFu), 2u, 0u);
    // $849511 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849513;
L_849513:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9513u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9513u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9513u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849513 CMP
    cpu.compareA(0xFFFFu);
    goto L_849516;
L_849516:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9516u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9516u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9516u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849516 BEQ -> $849547
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_849547; }
    goto L_849518;
L_849518:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9518u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9518u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9518u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $849518 STA
    hw.write(cpu.addressDpLongY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84951A;
L_84951A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x951Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x951Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x951Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84951A STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_84951C;
L_84951C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x951Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x951Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x951Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84951C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84951E;
L_84951E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x951Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x951Eu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x951Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84951E SEC
    cpu.setFlag('C', true);
    goto L_84951F;
L_84951F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x951Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x951Fu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x951Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84951F SBC
    cpu.sbc(0x40u);
    goto L_849522;
L_849522:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9522u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9522u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9522u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849522 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_849524;
L_849524:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9524u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9524u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9524u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849524 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849526;
L_849526:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9526u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9526u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9526u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849526 AND
    cpu.logicAnd(0x1FFu);
    goto L_849529;
L_849529:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9529u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9529u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9529u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849529 CMP
    cpu.compareA(0x130u);
    goto L_84952C;
L_84952C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x952Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x952Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x952Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84952C BCS -> $849533
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_849533; }
    goto L_84952E;
L_84952E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x952Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x952Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x952Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84952E LDA
    cpu.setA(0x0u, 16);
    goto L_849531;
L_849531:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9531u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9531u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9531u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849531 BRA -> $849539
    goto L_849539;
L_849533:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9533u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9533u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9533u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849533 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849535;
L_849535:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9535u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9535u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9535u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849535 SEC
    cpu.setFlag('C', true);
    goto L_849536;
L_849536:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9536u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9536u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9536u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849536 SBC
    cpu.sbc(0x10u);
    goto L_849539;
L_849539:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9539u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9539u,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9539u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $849539 STA
    hw.write(cpu.addressDpLongY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84953B;
L_84953B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x953Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x953Bu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x953Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84953B INY
    cpu.inc('Y');
    goto L_84953C;
L_84953C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x953Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x953Cu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x953Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84953C INY
    cpu.inc('Y');
    goto L_84953D;
L_84953D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x953Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x953Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x953Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84953D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84953F;
L_84953F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x953Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x953Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x953Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84953F CLC
    cpu.setFlag('C', false);
    goto L_849540;
L_849540:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9540u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9540u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9540u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849540 ADC
    cpu.adc(0x40u);
    goto L_849543;
L_849543:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9543u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9543u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9543u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849543 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_849545;
L_849545:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9545u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9545u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9545u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849545 BRA -> $849511
    goto L_849511;
L_849547:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9547u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9547u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9547u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $849547 PLB
    cpu.pop("PLB", hw);
    goto L_849548;
L_849548:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9548u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9548u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9548u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849548 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849548u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849548u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_849760_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849760u: goto L_849760;
    case 0x849762u: goto L_849762;
    case 0x849765u: goto L_849765;
    case 0x849768u: goto L_849768;
    case 0x84976Bu: goto L_84976B;
    case 0x84976Du: goto L_84976D;
    case 0x849770u: goto L_849770;
    case 0x849772u: goto L_849772;
    case 0x849775u: goto L_849775;
    case 0x849777u: goto L_849777;
    case 0x84977Bu: goto L_84977B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849760:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9760u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9760u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9760u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849760 REP
    cpu.rep(0x20u);
    goto L_849762;
L_849762:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9762u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9762u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9762u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849762 LDX
    cpu.setX(0x2u, 16);
    goto L_849765;
L_849765:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9765u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9765u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9765u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849765 LDY
    cpu.setY(0x5u, 16);
    goto L_849768;
L_849768:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9768u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9768u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9768u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849768 LDA
    cpu.setA(0x2C08u, 16);
    goto L_84976B;
L_84976B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x976Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x976Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x976Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84976B STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84976D;
L_84976D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x976Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x976Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x976Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84976D LDA
    cpu.setA(0x7Eu, 16);
    goto L_849770;
L_849770:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9770u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9770u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9770u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849770 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_849772;
L_849772:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9772u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9772u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9772u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849772 LDA
    cpu.setA(0x1C00u, 16);
    goto L_849775;
L_849775:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9775u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9775u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9775u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849775 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_849777;
L_849777:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9777u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9777u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9777u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849777 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x977Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x977Bu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x849777u); }
    goto L_84977B;
L_84977B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x977Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x977Bu,0x84977Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x977Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x977Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84977B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84977Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84977Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84B620_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84B620u: goto L_84B620;
    case 0x84B622u: goto L_84B622;
    case 0x84B624u: goto L_84B624;
    case 0x84B625u: goto L_84B625;
    case 0x84B627u: goto L_84B627;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84B620:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB620u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB620u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB620u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xB6u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B620 ROL
    cpu.rolMem(hw, cpu.address("dp", 0xB6u), cpu.m8?8:16);
    goto L_84B622;
L_84B622:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB622u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB622u,cpu,0x57u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB622u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xB6u) & 0xFFFFu), 3u, 0u);
    // $84B622 EOR
    cpu.logicXor(hw.readW(cpu.addressDpLongY(hw, 0xB6u), cpu.m8?8:16));
    goto L_84B624;
L_84B624:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB624u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB624u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB624u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B624 DEY
    cpu.decReg('Y');
    goto L_84B625;
L_84B625:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB625u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB625u,cpu,0xB6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB625u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpy", 0xA9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B625 LDX
    cpu.setX(hw.readW(cpu.address("dpy", 0xA9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_84B627;
L_84B627:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB627u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB627u,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB627u, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $84B627 BRK
    hw.partial(0x84B627u, "BRK"); return;
}

void sub_84B620_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84B620u: goto L_84B620;
    case 0x84B622u: goto L_84B622;
    case 0x84B624u: goto L_84B624;
    case 0x84B625u: goto L_84B625;
    case 0x84B627u: goto L_84B627;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84B620:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB620u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB620u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB620u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xB6u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B620 ROL
    cpu.rolMem(hw, cpu.address("dp", 0xB6u), cpu.m8?8:16);
    goto L_84B622;
L_84B622:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB622u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB622u,cpu,0x57u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB622u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xB6u) & 0xFFFFu), 3u, 0u);
    // $84B622 EOR
    cpu.logicXor(hw.readW(cpu.addressDpLongY(hw, 0xB6u), cpu.m8?8:16));
    goto L_84B624;
L_84B624:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB624u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB624u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB624u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B624 DEY
    cpu.decReg('Y');
    goto L_84B625;
L_84B625:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB625u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB625u,cpu,0xB6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB625u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpy", 0xA9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B625 LDX
    cpu.setX(hw.readW(cpu.address("dpy", 0xA9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_84B627;
L_84B627:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB627u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB627u,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB627u, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $84B627 BRK
    hw.partial(0x84B627u, "BRK"); return;
}

void sub_84BC7A_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84BC7Au: goto L_84BC7A;
    case 0x84BC7Cu: goto L_84BC7C;
    case 0x84BC7Fu: goto L_84BC7F;
    case 0x84BC81u: goto L_84BC81;
    case 0x84BC84u: goto L_84BC84;
    case 0x84BC87u: goto L_84BC87;
    case 0x84BC8Au: goto L_84BC8A;
    case 0x84BC8Du: goto L_84BC8D;
    case 0x84BC90u: goto L_84BC90;
    case 0x84BC92u: goto L_84BC92;
    case 0x84BC95u: goto L_84BC95;
    case 0x84BC98u: goto L_84BC98;
    case 0x84BC9Bu: goto L_84BC9B;
    case 0x84BC9Eu: goto L_84BC9E;
    case 0x84BCA1u: goto L_84BCA1;
    case 0x84BCA4u: goto L_84BCA4;
    case 0x84BCA6u: goto L_84BCA6;
    case 0x84BCA9u: goto L_84BCA9;
    case 0x84BCAAu: goto L_84BCAA;
    case 0x84BCABu: goto L_84BCAB;
    case 0x84BCAEu: goto L_84BCAE;
    case 0x84BCB1u: goto L_84BCB1;
    case 0x84BCB4u: goto L_84BCB4;
    case 0x84BCB5u: goto L_84BCB5;
    case 0x84BCB8u: goto L_84BCB8;
    case 0x84BCB9u: goto L_84BCB9;
    case 0x84BCBAu: goto L_84BCBA;
    case 0x84BCBDu: goto L_84BCBD;
    case 0x84BCC0u: goto L_84BCC0;
    case 0x84BCC2u: goto L_84BCC2;
    case 0x84BCC5u: goto L_84BCC5;
    case 0x84BCC6u: goto L_84BCC6;
    case 0x84BCC9u: goto L_84BCC9;
    case 0x84BCCAu: goto L_84BCCA;
    case 0x84BCCBu: goto L_84BCCB;
    case 0x84BCCEu: goto L_84BCCE;
    case 0x84BCD1u: goto L_84BCD1;
    case 0x84BCD4u: goto L_84BCD4;
    case 0x84BCD5u: goto L_84BCD5;
    case 0x84BCD6u: goto L_84BCD6;
    case 0x84BCD9u: goto L_84BCD9;
    case 0x84BCDCu: goto L_84BCDC;
    case 0x84BCDFu: goto L_84BCDF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84BC7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC7Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC7Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC7A REP
    cpu.rep(0x20u);
    goto L_84BC7C;
L_84BC7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC7Cu,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC7Cu, 8u, 3u, cpu.address("abs", 0x065Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC7C DEC
    cpu.decMem(hw, cpu.address("abs", 0x65Au), cpu.m8?8:16);
    goto L_84BC7F;
L_84BC7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC7Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC7Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC7F BPL -> $84BCDF
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_84BCDF; }
    goto L_84BC81;
L_84BC81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC81u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC81u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC81 LDA
    cpu.setA(0x3u, 16);
    goto L_84BC84;
L_84BC84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC84u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC84u, 5u, 3u, cpu.address("abs", 0x065Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC84 STA
    hw.write(cpu.address("abs", 0x65Au), cpu.a, cpu.m8?8:16);
    goto L_84BC87;
L_84BC87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC87u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC87u, 8u, 3u, cpu.address("abs", 0x06E9u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC87 INC
    cpu.incMem(hw, cpu.address("abs", 0x6E9u), cpu.m8?8:16);
    goto L_84BC8A;
L_84BC8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC8Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC8Au, 5u, 3u, cpu.address("abs", 0x06E9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC8A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6E9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BC8D;
L_84BC8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC8Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC8Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC8D CMP
    cpu.compareA(0x10u);
    goto L_84BC90;
L_84BC90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC90u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC90u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC90 BCC -> $84BCA1
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_84BCA1; }
    goto L_84BC92;
L_84BC92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC92u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC92u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC92 LDA
    cpu.setA(0x1u, 16);
    goto L_84BC95;
L_84BC95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC95u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC95u, 5u, 3u, cpu.address("abs", 0x06E9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC95 STA
    hw.write(cpu.address("abs", 0x6E9u), cpu.a, cpu.m8?8:16);
    goto L_84BC98;
L_84BC98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC98u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC98u, 5u, 3u, cpu.address("abs", 0x06E5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC98 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6E5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BC9B;
L_84BC9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC9Bu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC9Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC9B EOR
    cpu.logicXor(0x1u);
    goto L_84BC9E;
L_84BC9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC9Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC9Eu, 5u, 3u, cpu.address("abs", 0x06E5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC9E STA
    hw.write(cpu.address("abs", 0x6E5u), cpu.a, cpu.m8?8:16);
    goto L_84BCA1;
L_84BCA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA1u, 5u, 3u, cpu.address("abs", 0x06E5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BCA1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6E5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BCA4;
L_84BCA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BCA4 BEQ -> $84BCC2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_84BCC2; }
    goto L_84BCA6;
L_84BCA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA6u, 5u, 3u, cpu.address("abs", 0x06E9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BCA6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6E9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BCA9;
L_84BCA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA9u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCA9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BCA9 ASL
    cpu.aslA();
    goto L_84BCAA;
L_84BCAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCAAu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCAAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BCAA TAY
    cpu.transfer("TAY");
    goto L_84BCAB;
L_84BCAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCABu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCABu, 5u + 1u, 3u, cpu.address("absy", 0x1AC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BCAB LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1AC0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BCAE;
L_84BCAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCAEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCAEu, 5u, 3u, cpu.address("abs", 0x19C2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BCAE STA
    hw.write(cpu.address("abs", 0x19C2u), cpu.a, cpu.m8?8:16);
    goto L_84BCB1;
L_84BCB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCB1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCB1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BCB1 LDA
    cpu.setA(0x10u, 16);
    goto L_84BCB4;
L_84BCB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCB4u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCB4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BCB4 SEC
    cpu.setFlag('C', true);
    goto L_84BCB5;
L_84BCB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCB5u,cpu,0xEDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCB5u, 5u, 3u, cpu.address("abs", 0x06E9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BCB5 SBC
    cpu.sbc(hw.readW(cpu.address("abs", 0x6E9u), cpu.m8?8:16));
    goto L_84BCB8;
L_84BCB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCB8u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCB8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BCB8 ASL
    cpu.aslA();
    goto L_84BCB9;
L_84BCB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCB9u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCB9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BCB9 TAY
    cpu.transfer("TAY");
    goto L_84BCBA;
L_84BCBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCBAu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCBAu, 5u + 1u, 3u, cpu.address("absy", 0x1AC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BCBA LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1AC0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BCBD;
L_84BCBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCBDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCBDu, 5u, 3u, cpu.address("abs", 0x19C4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BCBD STA
    hw.write(cpu.address("abs", 0x19C4u), cpu.a, cpu.m8?8:16);
    goto L_84BCC0;
L_84BCC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC0u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BCC0 BRA -> $84BCDC
    goto L_84BCDC;
L_84BCC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BCC2 LDA
    cpu.setA(0x10u, 16);
    goto L_84BCC5;
L_84BCC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC5u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BCC5 SEC
    cpu.setFlag('C', true);
    goto L_84BCC6;
L_84BCC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC6u,cpu,0xEDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC6u, 5u, 3u, cpu.address("abs", 0x06E9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BCC6 SBC
    cpu.sbc(hw.readW(cpu.address("abs", 0x6E9u), cpu.m8?8:16));
    goto L_84BCC9;
L_84BCC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC9u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCC9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BCC9 ASL
    cpu.aslA();
    goto L_84BCCA;
L_84BCCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCCAu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCCAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BCCA TAY
    cpu.transfer("TAY");
    goto L_84BCCB;
L_84BCCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCCBu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCCBu, 5u + 1u, 3u, cpu.address("absy", 0x1AC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BCCB LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1AC0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BCCE;
L_84BCCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCCEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCCEu, 5u, 3u, cpu.address("abs", 0x19C2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BCCE STA
    hw.write(cpu.address("abs", 0x19C2u), cpu.a, cpu.m8?8:16);
    goto L_84BCD1;
L_84BCD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCD1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCD1u, 5u, 3u, cpu.address("abs", 0x06E9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BCD1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6E9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BCD4;
L_84BCD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCD4u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCD4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BCD4 ASL
    cpu.aslA();
    goto L_84BCD5;
L_84BCD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCD5u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCD5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BCD5 TAY
    cpu.transfer("TAY");
    goto L_84BCD6;
L_84BCD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCD6u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCD6u, 5u + 1u, 3u, cpu.address("absy", 0x1AC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BCD6 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1AC0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BCD9;
L_84BCD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCD9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCD9u, 5u, 3u, cpu.address("abs", 0x19C4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BCD9 STA
    hw.write(cpu.address("abs", 0x19C4u), cpu.a, cpu.m8?8:16);
    goto L_84BCDC;
L_84BCDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCDCu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCDCu, 8u, 3u, cpu.address("abs", 0x0122u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BCDC INC
    cpu.incMem(hw, cpu.address("abs", 0x122u), cpu.m8?8:16);
    goto L_84BCDF;
L_84BCDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCDFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCDFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84BCDF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84BCDFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84BCDFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84BF4A_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84BF4Au: goto L_84BF4A;
    case 0x84BF4Cu: goto L_84BF4C;
    case 0x84BF4Eu: goto L_84BF4E;
    case 0x84BF50u: goto L_84BF50;
    case 0x84BF52u: goto L_84BF52;
    case 0x84BF54u: goto L_84BF54;
    case 0x84BF56u: goto L_84BF56;
    case 0x84BF59u: goto L_84BF59;
    case 0x84BF5Cu: goto L_84BF5C;
    case 0x84BF5Fu: goto L_84BF5F;
    case 0x84BF63u: goto L_84BF63;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84BF4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF4Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF4Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF4A REP
    cpu.rep(0x20u);
    goto L_84BF4C;
L_84BF4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF4Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF4Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF4C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BF4E;
L_84BF4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF4Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF4Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF4E BNE -> $84BF63
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84BF63; }
    goto L_84BF50;
L_84BF50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF50u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF50u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF50 SEP
    cpu.sep(0x20u);
    goto L_84BF52;
L_84BF52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF52u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF52u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF52 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_84BF54;
L_84BF54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF54u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF54u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF54 REP
    cpu.rep(0x20u);
    goto L_84BF56;
L_84BF56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF56u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF56u, 6u, 3u, cpu.address("abs", 0xC2FFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84BF56 JSR -> $84C2FF stack real
    { cpu.push16Value(hw,0xBF58u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBF59u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC2FFu), 0x84BF56u); }
    goto L_84BF59;
L_84BF59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF59u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF59u,0x84BF59u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF59u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF59u, 8u, 3u, cpu.address("abs", 0x0128u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF59 INC
    cpu.incMem(hw, cpu.address("abs", 0x128u), cpu.m8?8:16);
    goto L_84BF5C;
L_84BF5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF5Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF5Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF5C LDA
    cpu.setA(0x3Eu, 16);
    goto L_84BF5F;
L_84BF5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF5Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF5Fu, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84BF5F JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBF62u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBF63u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x84BF5Fu); }
    goto L_84BF63;
L_84BF63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF63u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF63u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF63u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84BF63 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84BF63u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84BF63u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF63u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF63u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84BF63 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84BF63u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84BF63u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF63u,0x84BF63u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_84C228_E0M1X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84C228u: goto L_84C228;
    case 0x84C22Au: goto L_84C22A;
    case 0x84C22Du: goto L_84C22D;
    case 0x84C22Fu: goto L_84C22F;
    case 0x84C232u: goto L_84C232;
    case 0x84C234u: goto L_84C234;
    case 0x84C237u: goto L_84C237;
    case 0x84C23Bu: goto L_84C23B;
    case 0x84C23Du: goto L_84C23D;
    case 0x84C240u: goto L_84C240;
    case 0x84C242u: goto L_84C242;
    case 0x84C246u: goto L_84C246;
    case 0x84C248u: goto L_84C248;
    case 0x84C24Bu: goto L_84C24B;
    case 0x84C24Fu: goto L_84C24F;
    case 0x84C251u: goto L_84C251;
    case 0x84C254u: goto L_84C254;
    case 0x84C256u: goto L_84C256;
    case 0x84C25Au: goto L_84C25A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84C228:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC228u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC228u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC228u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C228 REP
    cpu.rep(0x20u);
    goto L_84C22A;
L_84C22A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC22Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C22A LDA
    cpu.setA(0x93u, 16);
    goto L_84C22D;
L_84C22D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC22Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C22D STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_84C22F;
L_84C22F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC22Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC22Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C22F LDA
    cpu.setA(0x80u, 16);
    goto L_84C232;
L_84C232:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC232u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC232u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC232u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C232 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_84C234;
L_84C234:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC234u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC234u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC234u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C234 LDX
    cpu.setX(0xCu, 16);
    goto L_84C237;
L_84C237:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC237u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC237u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC237u, 6u, 4u, ((0x93835Au + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C237 LDA
    cpu.loadA(hw.readW(((0x93835Au + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84C23B;
L_84C23B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC23Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C23B STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84C23D;
L_84C23D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC23Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC23Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C23D LDA
    cpu.setA(0x88u, 16);
    goto L_84C240;
L_84C240:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC240u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC240u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC240u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C240 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_84C242;
L_84C242:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC242u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC242u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC242u, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84C242 JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC245u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC246u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x84C242u); }
    goto L_84C246;
L_84C246:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC246u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC246u,0x84C246u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC246u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC246u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C246 REP
    cpu.rep(0x20u);
    goto L_84C248;
L_84C248:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC248u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC248u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC248u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C248 LDX
    cpu.setX(0xEu, 16);
    goto L_84C24B;
L_84C24B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC24Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC24Bu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC24Bu, 6u, 4u, ((0x93835Au + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C24B LDA
    cpu.loadA(hw.readW(((0x93835Au + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84C24F;
L_84C24F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC24Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC24Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC24Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C24F STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84C251;
L_84C251:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC251u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC251u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC251u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C251 LDA
    cpu.setA(0x80u, 16);
    goto L_84C254;
L_84C254:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC254u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC254u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC254u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C254 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_84C256;
L_84C256:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC256u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC256u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC256u, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84C256 JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC259u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC25Au,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x84C256u); }
    goto L_84C25A;
L_84C25A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC25Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC25Au,0x84C25Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC25Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC25Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84C25A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84C25Au);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84C25Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_9F9D16_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x9F9D16u: goto L_9F9D16;
    case 0x9F9D18u: goto L_9F9D18;
    case 0x9F9D1Au: goto L_9F9D1A;
    case 0x9F9D1Cu: goto L_9F9D1C;
    case 0x9F9D1Fu: goto L_9F9D1F;
    case 0x9F9D20u: goto L_9F9D20;
    case 0x9F9D21u: goto L_9F9D21;
    case 0x9F9D24u: goto L_9F9D24;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_9F9D16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D16u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D16u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $9F9D16 SEP
    cpu.sep(0x20u);
    goto L_9F9D18;
L_9F9D18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D18u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D18u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $9F9D18 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x49u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_9F9D1A;
L_9F9D1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $9F9D1A REP
    cpu.rep(0x20u);
    goto L_9F9D1C;
L_9F9D1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $9F9D1C AND
    cpu.logicAnd(0xFFu);
    goto L_9F9D1F;
L_9F9D1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $9F9D1F ASL
    cpu.aslA();
    goto L_9F9D20;
L_9F9D20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D20u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D20u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $9F9D20 TAX
    cpu.transfer("TAX");
    goto L_9F9D21;
L_9F9D21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D21u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D21u, 5u, 3u, cpu.address("abs", 0x9D26u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $9F9D21 PEA
    cpu.push16Value(hw, 0x9D26u);
    goto L_9F9D24;
L_9F9D24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D24u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D24u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x9D28u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $9F9D24 JMP (9D28,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x9D28u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x9F9D24u); return; }
}

