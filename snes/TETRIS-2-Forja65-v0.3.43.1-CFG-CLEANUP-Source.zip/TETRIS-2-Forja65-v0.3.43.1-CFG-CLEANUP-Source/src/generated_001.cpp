#include "generated.hpp"
void sub_808345_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808345u: goto L_808345;
    case 0x808349u: goto L_808349;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808345:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8345u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8345u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8345u, 8u, 4u, 0x84BD3Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808345 JSL -> $84BD3E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8348u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8349u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84BD3Eu, 0x808345u); }
    goto L_808349;
L_808349:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8349u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8349u,0x808349u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8349u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8349u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808349 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808349u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808349u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808345_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808345u: goto L_808345;
    case 0x808349u: goto L_808349;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808345:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8345u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8345u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8345u, 8u, 4u, 0x84BD3Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808345 JSL -> $84BD3E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8348u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8349u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84BD3Eu, 0x808345u); }
    goto L_808349;
L_808349:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8349u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8349u,0x808349u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8349u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8349u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808349 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808349u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808349u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80835E_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80835Eu: goto L_80835E;
    case 0x808362u: goto L_808362;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80835E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x835Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x835Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x835Eu, 8u, 4u, 0x82ACB5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80835E JSL -> $82ACB5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8361u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8362u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82ACB5u, 0x80835Eu); }
    goto L_808362;
L_808362:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8362u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8362u,0x808362u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8362u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8362u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808362 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808362u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808362u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80835E_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80835Eu: goto L_80835E;
    case 0x808362u: goto L_808362;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80835E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x835Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x835Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x835Eu, 8u, 4u, 0x82ACB5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80835E JSL -> $82ACB5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8361u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8362u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82ACB5u, 0x80835Eu); }
    goto L_808362;
L_808362:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8362u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8362u,0x808362u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8362u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8362u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808362 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808362u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808362u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_809E59_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809E59u: goto L_809E59;
    case 0x809E5Cu: goto L_809E5C;
    case 0x809E5Eu: goto L_809E5E;
    case 0x809E61u: goto L_809E61;
    case 0x809E64u: goto L_809E64;
    case 0x809E67u: goto L_809E67;
    case 0x809E69u: goto L_809E69;
    case 0x809E6Cu: goto L_809E6C;
    case 0x809E6Eu: goto L_809E6E;
    case 0x809E71u: goto L_809E71;
    case 0x809E73u: goto L_809E73;
    case 0x809E76u: goto L_809E76;
    case 0x809E79u: goto L_809E79;
    case 0x809E7Cu: goto L_809E7C;
    case 0x809E7Eu: goto L_809E7E;
    case 0x809E80u: goto L_809E80;
    case 0x809E81u: goto L_809E81;
    case 0x809E82u: goto L_809E82;
    case 0x809E83u: goto L_809E83;
    case 0x809E84u: goto L_809E84;
    case 0x809E86u: goto L_809E86;
    case 0x809E88u: goto L_809E88;
    case 0x809E8Au: goto L_809E8A;
    case 0x809E8Bu: goto L_809E8B;
    case 0x809E8Cu: goto L_809E8C;
    case 0x809E8Du: goto L_809E8D;
    case 0x809E8Eu: goto L_809E8E;
    case 0x809E8Fu: goto L_809E8F;
    case 0x809E90u: goto L_809E90;
    case 0x809E93u: goto L_809E93;
    case 0x809E94u: goto L_809E94;
    case 0x809E96u: goto L_809E96;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809E59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E59u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E59u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E59 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809E5C;
L_809E5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E5Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E5Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E5C BNE -> $809E96
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_809E96; }
    goto L_809E5E;
L_809E5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E5Eu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E5Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E5E LDY
    cpu.setY(0x40u, 16);
    goto L_809E61;
L_809E61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E61u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E61u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E61 LDX
    cpu.setX(0x168u, 16);
    goto L_809E64;
L_809E64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E64u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E64u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E64 LDA
    cpu.setA(0x1u, 16);
    goto L_809E67;
L_809E67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E67u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E67u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E67 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_809E69;
L_809E69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E69u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E69u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E69 LDA
    cpu.setA(0x9u, 16);
    goto L_809E6C;
L_809E6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E6Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E6Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E6C STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_809E6E;
L_809E6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E6Eu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E6Eu, 5u + 1u, 3u, cpu.address("absy", 0x2000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E6E LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2000u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809E71;
L_809E71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E71u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E71u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E71 BEQ -> $809E7C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_809E7C; }
    goto L_809E73;
L_809E73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E73u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E73u, 6u, 3u, cpu.address("abs", 0x9DADu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809E73 JSR -> $809DAD stack real
    { cpu.push16Value(hw,0x9E75u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9E76u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9DADu), 0x809E73u); }
    goto L_809E76;
L_809E76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E76u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E76u,0x809E76u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E76u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E76u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E76 ORA
    cpu.logicOr(0x2000u);
    goto L_809E79;
L_809E79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E79u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E79u, 6u, 3u, cpu.address("absx", 0x2800u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E79 STA
    hw.write(cpu.address("absx", 0x2800u), cpu.a, cpu.m8?8:16);
    goto L_809E7C;
L_809E7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Cu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Cu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E7C DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_809E7E;
L_809E7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Eu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E7E BMI -> $809E86
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_809E86; }
    goto L_809E80;
L_809E80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E80u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E80u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E80 DEX
    cpu.decReg('X');
    goto L_809E81;
L_809E81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E81u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E81u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E81 DEX
    cpu.decReg('X');
    goto L_809E82;
L_809E82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E82u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E82u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E82 DEY
    cpu.decReg('Y');
    goto L_809E83;
L_809E83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E83u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E83u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E83 DEY
    cpu.decReg('Y');
    goto L_809E84;
L_809E84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E84u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E84u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E84 BRA -> $809E6E
    goto L_809E6E;
L_809E86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E86u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E86u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E86 DEC
    cpu.decMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_809E88;
L_809E88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E88u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E88u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E88 BMI -> $809E96
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_809E96; }
    goto L_809E8A;
L_809E8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Au,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E8A DEY
    cpu.decReg('Y');
    goto L_809E8B;
L_809E8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Bu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E8B DEY
    cpu.decReg('Y');
    goto L_809E8C;
L_809E8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Cu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E8C DEY
    cpu.decReg('Y');
    goto L_809E8D;
L_809E8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Du,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E8D DEY
    cpu.decReg('Y');
    goto L_809E8E;
L_809E8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Eu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E8E TXA
    cpu.transfer("TXA");
    goto L_809E8F;
L_809E8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Fu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E8F SEC
    cpu.setFlag('C', true);
    goto L_809E90;
L_809E90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E90u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E90u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E90 SBC
    cpu.sbc(0x2Eu);
    goto L_809E93;
L_809E93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E93u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E93u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E93 TAX
    cpu.transfer("TAX");
    goto L_809E94;
L_809E94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E94u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E94u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E94 BRA -> $809E69
    goto L_809E69;
L_809E96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E96u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E96u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809E96 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x809E96u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x809E96u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80A21E_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80A21Eu: goto L_80A21E;
    case 0x80A221u: goto L_80A221;
    case 0x80A224u: goto L_80A224;
    case 0x80A227u: goto L_80A227;
    case 0x80A22Au: goto L_80A22A;
    case 0x80A22Eu: goto L_80A22E;
    case 0x80A230u: goto L_80A230;
    case 0x80A232u: goto L_80A232;
    case 0x80A233u: goto L_80A233;
    case 0x80A236u: goto L_80A236;
    case 0x80A239u: goto L_80A239;
    case 0x80A23Cu: goto L_80A23C;
    case 0x80A240u: goto L_80A240;
    case 0x80A243u: goto L_80A243;
    case 0x80A246u: goto L_80A246;
    case 0x80A249u: goto L_80A249;
    case 0x80A24Cu: goto L_80A24C;
    case 0x80A250u: goto L_80A250;
    case 0x80A252u: goto L_80A252;
    case 0x80A254u: goto L_80A254;
    case 0x80A255u: goto L_80A255;
    case 0x80A258u: goto L_80A258;
    case 0x80A25Bu: goto L_80A25B;
    case 0x80A25Eu: goto L_80A25E;
    case 0x80A262u: goto L_80A262;
    case 0x80A265u: goto L_80A265;
    case 0x80A267u: goto L_80A267;
    case 0x80A26Au: goto L_80A26A;
    case 0x80A26Cu: goto L_80A26C;
    case 0x80A26Fu: goto L_80A26F;
    case 0x80A272u: goto L_80A272;
    case 0x80A276u: goto L_80A276;
    case 0x80A279u: goto L_80A279;
    case 0x80A27Cu: goto L_80A27C;
    case 0x80A27Fu: goto L_80A27F;
    case 0x80A282u: goto L_80A282;
    case 0x80A286u: goto L_80A286;
    case 0x80A287u: goto L_80A287;
    case 0x80A28Au: goto L_80A28A;
    case 0x80A28Du: goto L_80A28D;
    case 0x80A28Fu: goto L_80A28F;
    case 0x80A290u: goto L_80A290;
    case 0x80A293u: goto L_80A293;
    case 0x80A294u: goto L_80A294;
    case 0x80A297u: goto L_80A297;
    case 0x80A29Au: goto L_80A29A;
    case 0x80A29Du: goto L_80A29D;
    case 0x80A2A0u: goto L_80A2A0;
    case 0x80A2A4u: goto L_80A2A4;
    case 0x80A2A5u: goto L_80A2A5;
    case 0x80A2A8u: goto L_80A2A8;
    case 0x80A2ABu: goto L_80A2AB;
    case 0x80A2ADu: goto L_80A2AD;
    case 0x80A2AEu: goto L_80A2AE;
    case 0x80A2B1u: goto L_80A2B1;
    case 0x80A2B2u: goto L_80A2B2;
    case 0x80A2B5u: goto L_80A2B5;
    case 0x80A2B8u: goto L_80A2B8;
    case 0x80A2BBu: goto L_80A2BB;
    case 0x80A2BEu: goto L_80A2BE;
    case 0x80A2C2u: goto L_80A2C2;
    case 0x80A2C3u: goto L_80A2C3;
    case 0x80A2C6u: goto L_80A2C6;
    case 0x80A2C9u: goto L_80A2C9;
    case 0x80A2CBu: goto L_80A2CB;
    case 0x80A2CCu: goto L_80A2CC;
    case 0x80A2CFu: goto L_80A2CF;
    case 0x80A2D0u: goto L_80A2D0;
    case 0x80A2D3u: goto L_80A2D3;
    case 0x80A2D7u: goto L_80A2D7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80A21E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA21Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA21Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA21Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A21E LDA
    cpu.setA(0x9022u, 16);
    goto L_80A221;
L_80A221:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA221u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA221u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA221u, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A221 STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_80A224;
L_80A224:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA224u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA224u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA224u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A224 LDA
    cpu.setA(0x8Bu, 16);
    goto L_80A227;
L_80A227:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA227u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA227u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA227u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A227 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_80A22A;
L_80A22A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA22Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA22Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA22Au, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A22A JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA22Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA22Eu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x80A22Au); }
    goto L_80A22E;
L_80A22E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA22Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA22Eu,0x80A22Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA22Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA22Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A22E SEP
    cpu.sep(0x20u);
    goto L_80A230;
L_80A230:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA230u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA230u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA230u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A230 LDA
    cpu.setA(0x7Eu, 8);
    goto L_80A232;
L_80A232:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA232u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA232u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA232u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A232 PHA
    cpu.push("PHA", hw);
    goto L_80A233;
L_80A233:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA233u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA233u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA233u, 5u, 3u, cpu.address("abs", 0x8000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A233 PEA
    cpu.push16Value(hw, 0x8000u);
    goto L_80A236;
L_80A236:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA236u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA236u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA236u, 5u, 3u, cpu.address("abs", 0x6000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A236 PEA
    cpu.push16Value(hw, 0x6000u);
    goto L_80A239;
L_80A239:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA239u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA239u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA239u, 5u, 3u, cpu.address("abs", 0x2000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A239 PEA
    cpu.push16Value(hw, 0x2000u);
    goto L_80A23C;
L_80A23C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA23Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA23Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA23Cu, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A23C JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA23Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA240u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x80A23Cu); }
    goto L_80A240;
L_80A240:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA240u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA240u,0x80A240u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA240u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA240u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A240 LDA
    cpu.setA(0xBB1Eu, 16);
    goto L_80A243;
L_80A243:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA243u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA243u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA243u, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A243 STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_80A246;
L_80A246:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA246u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA246u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA246u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A246 LDA
    cpu.setA(0x9Bu, 16);
    goto L_80A249;
L_80A249:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA249u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA249u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA249u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A249 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_80A24C;
L_80A24C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA24Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA24Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA24Cu, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A24C JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA24Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA250u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x80A24Cu); }
    goto L_80A250;
L_80A250:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA250u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA250u,0x80A250u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA250u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA250u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A250 SEP
    cpu.sep(0x20u);
    goto L_80A252;
L_80A252:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA252u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA252u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA252u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A252 LDA
    cpu.setA(0x7Eu, 8);
    goto L_80A254;
L_80A254:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA254u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA254u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA254u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A254 PHA
    cpu.push("PHA", hw);
    goto L_80A255;
L_80A255:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA255u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA255u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA255u, 5u, 3u, cpu.address("abs", 0x8000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A255 PEA
    cpu.push16Value(hw, 0x8000u);
    goto L_80A258;
L_80A258:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA258u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA258u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA258u, 5u, 3u, cpu.address("abs", 0x2000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A258 PEA
    cpu.push16Value(hw, 0x2000u);
    goto L_80A25B;
L_80A25B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA25Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA25Bu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA25Bu, 5u, 3u, cpu.address("abs", 0x6000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A25B PEA
    cpu.push16Value(hw, 0x6000u);
    goto L_80A25E;
L_80A25E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA25Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA25Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA25Eu, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A25E JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA261u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA262u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x80A25Eu); }
    goto L_80A262;
L_80A262:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA262u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA262u,0x80A262u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA262u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA262u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A262 LDA
    cpu.setA(0x946Cu, 16);
    goto L_80A265;
L_80A265:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA265u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA265u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA265u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A265 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80A267;
L_80A267:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA267u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA267u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA267u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A267 LDA
    cpu.setA(0x8Au, 16);
    goto L_80A26A;
L_80A26A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA26Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA26Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA26Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A26A STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_80A26C;
L_80A26C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA26Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA26Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA26Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A26C LDX
    cpu.setX(0x0u, 16);
    goto L_80A26F;
L_80A26F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA26Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA26Fu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA26Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A26F LDY
    cpu.setY(0x200u, 16);
    goto L_80A272;
L_80A272:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA272u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA272u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA272u, 8u, 4u, 0x808BB9u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A272 JSL -> $808BB9 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA275u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA276u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808BB9u, 0x80A272u); }
    goto L_80A276;
L_80A276:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA276u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA276u,0x80A276u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA276u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA276u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A276 LDA
    cpu.setA(0xBF49u, 16);
    goto L_80A279;
L_80A279:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA279u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA279u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA279u, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A279 STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_80A27C;
L_80A27C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA27Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA27Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA27Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A27C LDA
    cpu.setA(0x8Au, 16);
    goto L_80A27F;
L_80A27F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA27Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA27Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA27Fu, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A27F STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_80A282;
L_80A282:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA282u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA282u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA282u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A282 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA285u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA286u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x80A282u); }
    goto L_80A286;
L_80A286:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA286u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA286u,0x80A286u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA286u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA286u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A286 PHB
    cpu.push("PHB", hw);
    goto L_80A287;
L_80A287:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA287u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA287u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA287u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A287 LDX
    cpu.setX(0x8000u, 16);
    goto L_80A28A;
L_80A28A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA28Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA28Au,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA28Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A28A LDY
    cpu.setY(0x2800u, 16);
    goto L_80A28D;
L_80A28D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA28Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA28Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA28Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A28D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A28F;
L_80A28F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA28Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA28Fu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA28Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A28F DEC
    cpu.decReg('A');
    goto L_80A290;
L_80A290:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA290u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA290u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xA290u, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $80A290 MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_80A293;
L_80A293:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA293u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA293u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA293u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A293 PLB
    cpu.pop("PLB", hw);
    goto L_80A294;
L_80A294:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA294u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA294u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA294u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A294 LDA
    cpu.setA(0xFACDu, 16);
    goto L_80A297;
L_80A297:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA297u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA297u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA297u, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A297 STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_80A29A;
L_80A29A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA29Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA29Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA29Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A29A LDA
    cpu.setA(0x96u, 16);
    goto L_80A29D;
L_80A29D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA29Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA29Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA29Du, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A29D STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_80A2A0;
L_80A2A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2A0u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2A0u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A2A0 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA2A3u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA2A4u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x80A2A0u); }
    goto L_80A2A4;
L_80A2A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2A4u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA2A4u,0x80A2A4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2A4u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2A4u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A2A4 PHB
    cpu.push("PHB", hw);
    goto L_80A2A5;
L_80A2A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2A5u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2A5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A2A5 LDX
    cpu.setX(0x8000u, 16);
    goto L_80A2A8;
L_80A2A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2A8u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2A8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A2A8 LDY
    cpu.setY(0x4000u, 16);
    goto L_80A2AB;
L_80A2AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2ABu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2ABu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A2AB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A2AD;
L_80A2AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2ADu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2ADu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A2AD DEC
    cpu.decReg('A');
    goto L_80A2AE;
L_80A2AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2AEu,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xA2AEu, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $80A2AE MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_80A2B1;
L_80A2B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2B1u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2B1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A2B1 PLB
    cpu.pop("PLB", hw);
    goto L_80A2B2;
L_80A2B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2B2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2B2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A2B2 LDA
    cpu.setA(0x8D5Fu, 16);
    goto L_80A2B5;
L_80A2B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2B5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2B5u, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A2B5 STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_80A2B8;
L_80A2B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2B8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2B8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A2B8 LDA
    cpu.setA(0x89u, 16);
    goto L_80A2BB;
L_80A2BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2BBu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2BBu, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A2BB STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_80A2BE;
L_80A2BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2BEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2BEu, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A2BE JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA2C1u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA2C2u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x80A2BEu); }
    goto L_80A2C2;
L_80A2C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2C2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA2C2u,0x80A2C2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2C2u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2C2u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A2C2 PHB
    cpu.push("PHB", hw);
    goto L_80A2C3;
L_80A2C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2C3u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2C3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A2C3 LDX
    cpu.setX(0x8000u, 16);
    goto L_80A2C6;
L_80A2C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2C6u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2C6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A2C6 LDY
    cpu.setY(0x6000u, 16);
    goto L_80A2C9;
L_80A2C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2C9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2C9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A2C9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A2CB;
L_80A2CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2CBu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2CBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A2CB DEC
    cpu.decReg('A');
    goto L_80A2CC;
L_80A2CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2CCu,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xA2CCu, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $80A2CC MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_80A2CF;
L_80A2CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2CFu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2CFu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A2CF PLB
    cpu.pop("PLB", hw);
    goto L_80A2D0;
L_80A2D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2D0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2D0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A2D0 LDA
    cpu.setA(0xFFFFu, 16);
    goto L_80A2D3;
L_80A2D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2D3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2D3u, 8u, 4u, 0x80A460u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A2D3 JSL -> $80A460 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA2D6u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA2D7u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A460u, 0x80A2D3u); }
    goto L_80A2D7;
L_80A2D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2D7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA2D7u,0x80A2D7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2D7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2D7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A2D7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80A2D7u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80A2D7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80A724_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80A724u: goto L_80A724;
    case 0x80A725u: goto L_80A725;
    case 0x80A727u: goto L_80A727;
    case 0x80A729u: goto L_80A729;
    case 0x80A72Bu: goto L_80A72B;
    case 0x80A72Du: goto L_80A72D;
    case 0x80A730u: goto L_80A730;
    case 0x80A732u: goto L_80A732;
    case 0x80A734u: goto L_80A734;
    case 0x80A736u: goto L_80A736;
    case 0x80A738u: goto L_80A738;
    case 0x80A73Bu: goto L_80A73B;
    case 0x80A73Du: goto L_80A73D;
    case 0x80A740u: goto L_80A740;
    case 0x80A742u: goto L_80A742;
    case 0x80A744u: goto L_80A744;
    case 0x80A746u: goto L_80A746;
    case 0x80A748u: goto L_80A748;
    case 0x80A74Au: goto L_80A74A;
    case 0x80A74Cu: goto L_80A74C;
    case 0x80A74Eu: goto L_80A74E;
    case 0x80A750u: goto L_80A750;
    case 0x80A752u: goto L_80A752;
    case 0x80A755u: goto L_80A755;
    case 0x80A757u: goto L_80A757;
    case 0x80A759u: goto L_80A759;
    case 0x80A75Bu: goto L_80A75B;
    case 0x80A75Du: goto L_80A75D;
    case 0x80A760u: goto L_80A760;
    case 0x80A762u: goto L_80A762;
    case 0x80A764u: goto L_80A764;
    case 0x80A766u: goto L_80A766;
    case 0x80A768u: goto L_80A768;
    case 0x80A76Bu: goto L_80A76B;
    case 0x80A76Du: goto L_80A76D;
    case 0x80A76Fu: goto L_80A76F;
    case 0x80A772u: goto L_80A772;
    case 0x80A774u: goto L_80A774;
    case 0x80A776u: goto L_80A776;
    case 0x80A778u: goto L_80A778;
    case 0x80A77Au: goto L_80A77A;
    case 0x80A77Cu: goto L_80A77C;
    case 0x80A77Eu: goto L_80A77E;
    case 0x80A780u: goto L_80A780;
    case 0x80A781u: goto L_80A781;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80A724:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA724u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA724u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA724u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A724 PHP
    cpu.push("PHP", hw);
    goto L_80A725;
L_80A725:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA725u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA725u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA725u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A725 SEP
    cpu.sep(0x20u);
    goto L_80A727;
L_80A727:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA727u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA727u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA727u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD9u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A727 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xD9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A729;
L_80A729:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA729u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA729u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA729u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A729 CMP
    cpu.compareA(0xFFu);
    goto L_80A72B;
L_80A72B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA72Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA72Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA72Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A72B BEQ -> $80A74C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80A74C; }
    goto L_80A72D;
L_80A72D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA72Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA72Du,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA72Du, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A72D CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x2140u), cpu.m8?8:16));
    goto L_80A730;
L_80A730:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA730u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA730u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA730u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A730 BNE -> $80A73D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80A73D; }
    goto L_80A732;
L_80A732:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA732u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA732u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA732u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A732 CMP
    cpu.compareA(0x80u);
    goto L_80A734;
L_80A734:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA734u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA734u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA734u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A734 BCS -> $80A73D
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80A73D; }
    goto L_80A736;
L_80A736:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA736u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA736u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA736u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A736 LDA
    cpu.setA(0x80u, 8);
    goto L_80A738;
L_80A738:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA738u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA738u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA738u, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A738 STA
    hw.write(cpu.address("abs", 0x2140u), cpu.a, cpu.m8?8:16);
    goto L_80A73B;
L_80A73B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA73Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA73Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA73Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A73B BRA -> $80A74C
    goto L_80A74C;
L_80A73D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA73Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA73Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA73Du, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A73D STA
    hw.write(cpu.address("abs", 0x2140u), cpu.a, cpu.m8?8:16);
    goto L_80A740;
L_80A740:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA740u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA740u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA740u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A740 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xDAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80A742;
L_80A742:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA742u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA742u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA742u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A742 STX
    hw.write(cpu.address("dp", 0xD9u), cpu.x, cpu.x8?8:16);
    goto L_80A744;
L_80A744:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA744u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA744u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA744u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A744 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A746;
L_80A746:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA746u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA746u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA746u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A746 STA
    hw.write(cpu.address("dp", 0xDBu), cpu.a, cpu.m8?8:16);
    goto L_80A748;
L_80A748:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA748u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA748u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA748u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A748 LDA
    cpu.setA(0xFFu, 8);
    goto L_80A74A;
L_80A74A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA74Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA74Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA74Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDCu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A74A STA
    hw.write(cpu.address("dp", 0xDCu), cpu.a, cpu.m8?8:16);
    goto L_80A74C;
L_80A74C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA74Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA74Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA74Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xE2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A74C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xE2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A74E;
L_80A74E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA74Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA74Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA74Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A74E CMP
    cpu.compareA(0xFFu);
    goto L_80A750;
L_80A750:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA750u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA750u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA750u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A750 BEQ -> $80A757
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80A757; }
    goto L_80A752;
L_80A752:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA752u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA752u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA752u, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A752 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x2141u), cpu.m8?8:16));
    goto L_80A755;
L_80A755:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA755u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA755u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA755u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A755 BNE -> $80A768
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80A768; }
    goto L_80A757;
L_80A757:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA757u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA757u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA757u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A757 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A759;
L_80A759:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA759u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA759u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA759u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A759 CMP
    cpu.compareA(0xFFu);
    goto L_80A75B;
L_80A75B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA75Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA75Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA75Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A75B BEQ -> $80A780
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80A780; }
    goto L_80A75D;
L_80A75D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA75Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA75Du,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA75Du, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A75D CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x2141u), cpu.m8?8:16));
    goto L_80A760;
L_80A760:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA760u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA760u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA760u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A760 BNE -> $80A76F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80A76F; }
    goto L_80A762;
L_80A762:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA762u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA762u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA762u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A762 CMP
    cpu.compareA(0x80u);
    goto L_80A764;
L_80A764:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA764u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA764u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA764u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A764 BCS -> $80A76F
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80A76F; }
    goto L_80A766;
L_80A766:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA766u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA766u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA766u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A766 ORA
    cpu.logicOr(0x80u);
    goto L_80A768;
L_80A768:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA768u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA768u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA768u, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A768 STA
    hw.write(cpu.address("abs", 0x2141u), cpu.a, cpu.m8?8:16);
    goto L_80A76B;
L_80A76B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA76Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA76Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA76Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xE2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A76B STA
    hw.write(cpu.address("dp", 0xE2u), cpu.a, cpu.m8?8:16);
    goto L_80A76D;
L_80A76D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA76Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA76Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA76Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A76D BRA -> $80A780
    goto L_80A780;
L_80A76F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA76Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA76Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA76Fu, 4u, 3u, cpu.address("abs", 0x2141u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A76F STA
    hw.write(cpu.address("abs", 0x2141u), cpu.a, cpu.m8?8:16);
    goto L_80A772;
L_80A772:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA772u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA772u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA772u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xE2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A772 STA
    hw.write(cpu.address("dp", 0xE2u), cpu.a, cpu.m8?8:16);
    goto L_80A774;
L_80A774:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA774u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA774u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA774u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A774 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xDEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80A776;
L_80A776:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA776u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA776u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA776u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A776 STX
    hw.write(cpu.address("dp", 0xDDu), cpu.x, cpu.x8?8:16);
    goto L_80A778;
L_80A778:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA778u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA778u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA778u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xE0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A778 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xE0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A77A;
L_80A77A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA77Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA77Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA77Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A77A STA
    hw.write(cpu.address("dp", 0xDFu), cpu.a, cpu.m8?8:16);
    goto L_80A77C;
L_80A77C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA77Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA77Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA77Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A77C LDA
    cpu.setA(0xFFu, 8);
    goto L_80A77E;
L_80A77E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA77Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA77Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA77Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xE0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A77E STA
    hw.write(cpu.address("dp", 0xE0u), cpu.a, cpu.m8?8:16);
    goto L_80A780;
L_80A780:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA780u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA780u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA780u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A780 PLP
    cpu.pop("PLP", hw);
    goto L_80A781;
L_80A781:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA781u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA781u,0x80A781u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA781u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA781u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A781 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80A781u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80A781u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80AFB3_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AFB3u: goto L_80AFB3;
    case 0x80AFB6u: goto L_80AFB6;
    case 0x80AFB8u: goto L_80AFB8;
    case 0x80AFBBu: goto L_80AFBB;
    case 0x80AFBEu: goto L_80AFBE;
    case 0x80AFC1u: goto L_80AFC1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AFB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB3u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFB3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AFB6;
L_80AFB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFB6 BEQ -> $80AFBE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AFBE; }
    goto L_80AFB8;
L_80AFB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB8u, 6u, 3u, cpu.address("abs", 0xC363u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AFB8 JSR -> $80C363 stack real
    { cpu.push16Value(hw,0xAFBAu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAFBBu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC363u), 0x80AFB8u); }
    goto L_80AFBB;
L_80AFBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFBBu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFBBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFBBu, 6u, 3u, cpu.address("abs", 0xBBFAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AFBB JSR -> $80BBFA stack real
    { cpu.push16Value(hw,0xAFBDu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAFBEu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBBFAu), 0x80AFBBu); }
    goto L_80AFBE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFBBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFBBu, 6u, 3u, cpu.address("abs", 0xBBFAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AFBB JSR -> $80BBFA stack real
    { cpu.push16Value(hw,0xAFBDu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAFBEu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBBFAu), 0x80AFBBu); }
    goto L_80AFBE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAFBBu,0x80AFBBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AFBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFBEu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFBEu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFBEu, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFBE INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AFC1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFBEu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFBEu, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFBE INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AFC1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFBEu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFBEu, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AFBE INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AFC1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAFBEu,0x80AFBEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AFC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFC1u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AFC1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AFC1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AFC1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AFC1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AFC1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AFC1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AFC1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AFC1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AFC1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAFC1u,0x80AFC1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80B2F2_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B2F2u: goto L_80B2F2;
    case 0x80B2F5u: goto L_80B2F5;
    case 0x80B2F7u: goto L_80B2F7;
    case 0x80B2FAu: goto L_80B2FA;
    case 0x80B2FCu: goto L_80B2FC;
    case 0x80B2FFu: goto L_80B2FF;
    case 0x80B302u: goto L_80B302;
    case 0x80B305u: goto L_80B305;
    case 0x80B308u: goto L_80B308;
    case 0x80B30Bu: goto L_80B30B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B2F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F2u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F2u, 5u, 3u, cpu.address("abs", 0x0137u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2F2 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x137u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B2F5;
L_80B2F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2F5 BEQ -> $80B305
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B305; }
    goto L_80B2F7;
L_80B2F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F7u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2F7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B2FA;
L_80B2FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2FA BEQ -> $80B305
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B305; }
    goto L_80B2FC;
L_80B2FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FCu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FCu, 8u, 3u, cpu.address("abs", 0x0986u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2FC INC
    cpu.incMem(hw, cpu.address("abs", 0x986u), cpu.m8?8:16);
    goto L_80B2FF;
L_80B2FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FFu, 6u, 3u, cpu.address("abs", 0xD28Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B2FF JSR -> $80D28F stack real
    { cpu.push16Value(hw,0xB301u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB302u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD28Fu), 0x80B2FFu); }
    goto L_80B302;
L_80B302:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB302u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB302u,0x80B302u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB302u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB302u, 6u, 3u, cpu.address("abs", 0xD3BBu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B302 JSR -> $80D3BB stack real
    { cpu.push16Value(hw,0xB304u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB305u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD3BBu), 0x80B302u); }
    goto L_80B305;
L_80B305:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB305u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB305u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB305u, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B305 STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B308;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB305u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB305u, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B305 STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B308;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB305u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB305u, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B305 STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B308;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB305u,0x80B305u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B308:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB308u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB308u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB308u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B308 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B30B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB308u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB308u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B308 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B30B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB308u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB308u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B308 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B30B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB308u,0x80B308u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B30B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB30Bu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B30B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B30Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B30Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B30B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B30Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B30Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B30B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B30Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B30Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB30Bu,0x80B30Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80B4DA_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B4DAu: goto L_80B4DA;
    case 0x80B4DDu: goto L_80B4DD;
    case 0x80B4E0u: goto L_80B4E0;
    case 0x80B4E3u: goto L_80B4E3;
    case 0x80B4E5u: goto L_80B4E5;
    case 0x80B4E8u: goto L_80B4E8;
    case 0x80B4EBu: goto L_80B4EB;
    case 0x80B4EEu: goto L_80B4EE;
    case 0x80B4F0u: goto L_80B4F0;
    case 0x80B4F1u: goto L_80B4F1;
    case 0x80B4F2u: goto L_80B4F2;
    case 0x80B4F4u: goto L_80B4F4;
    case 0x80B4F7u: goto L_80B4F7;
    case 0x80B4F9u: goto L_80B4F9;
    case 0x80B4FBu: goto L_80B4FB;
    case 0x80B4FEu: goto L_80B4FE;
    case 0x80B501u: goto L_80B501;
    case 0x80B504u: goto L_80B504;
    case 0x80B505u: goto L_80B505;
    case 0x80B508u: goto L_80B508;
    case 0x80B50Au: goto L_80B50A;
    case 0x80B50Du: goto L_80B50D;
    case 0x80B50Eu: goto L_80B50E;
    case 0x80B511u: goto L_80B511;
    case 0x80B514u: goto L_80B514;
    case 0x80B516u: goto L_80B516;
    case 0x80B519u: goto L_80B519;
    case 0x80B51Cu: goto L_80B51C;
    case 0x80B51Eu: goto L_80B51E;
    case 0x80B520u: goto L_80B520;
    case 0x80B521u: goto L_80B521;
    case 0x80B522u: goto L_80B522;
    case 0x80B525u: goto L_80B525;
    case 0x80B527u: goto L_80B527;
    case 0x80B529u: goto L_80B529;
    case 0x80B52Au: goto L_80B52A;
    case 0x80B52Bu: goto L_80B52B;
    case 0x80B52Du: goto L_80B52D;
    case 0x80B530u: goto L_80B530;
    case 0x80B532u: goto L_80B532;
    case 0x80B535u: goto L_80B535;
    case 0x80B536u: goto L_80B536;
    case 0x80B539u: goto L_80B539;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B4DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4DAu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4DAu, 5u, 3u, cpu.address("abs", 0x0922u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4DA STZ
    hw.write(cpu.address("abs", 0x922u), 0, cpu.m8?8:16);
    goto L_80B4DD;
L_80B4DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4DDu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4DDu, 5u, 3u, cpu.address("abs", 0x0924u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4DD STZ
    hw.write(cpu.address("abs", 0x924u), 0, cpu.m8?8:16);
    goto L_80B4E0;
L_80B4E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E0u, 5u, 3u, cpu.address("abs", 0x0137u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4E0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x137u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B4E3;
L_80B4E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4E3 BEQ -> $80B50D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B50D; }
    goto L_80B4E5;
L_80B4E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E5u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4E5 LDX
    cpu.setX(0x6u, 16);
    goto L_80B4E8;
L_80B4E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E8u, 5u + 1u, 3u, cpu.address("absx", 0x097Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4E8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x97Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B4EB;
L_80B4EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4EBu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4EBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4EB CMP
    cpu.compareA(0xFFu);
    goto L_80B4EE;
L_80B4EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4EEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4EEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4EE BNE -> $80B4F4
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B4F4; }
    goto L_80B4F0;
L_80B4F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F0u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4F0 DEX
    cpu.decReg('X');
    goto L_80B4F1;
L_80B4F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F1u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4F1 DEX
    cpu.decReg('X');
    goto L_80B4F2;
L_80B4F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F2u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4F2 BRA -> $80B4E8
    goto L_80B4E8;
L_80B4F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F4u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4F4 CMP
    cpu.compareA(0x1u);
    goto L_80B4F7;
L_80B4F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4F7 BNE -> $80B50E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B50E; }
    goto L_80B4F9;
L_80B4F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F9u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4F9 STX
    hw.write(cpu.address("dp", 0x61u), cpu.x, cpu.x8?8:16);
    goto L_80B4FB;
L_80B4FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FBu, 5u + 1u, 3u, cpu.address("absx", 0x0906u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4FB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x906u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B4FE;
L_80B4FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FEu, 5u, 3u, cpu.address("abs", 0x097Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B4FE STA
    hw.write(cpu.address("abs", 0x97Au), cpu.a, cpu.m8?8:16);
    goto L_80B501;
L_80B501:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB501u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB501u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB501u, 5u + 1u, 3u, cpu.address("absx", 0x093Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B501 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x93Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B504;
L_80B504:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB504u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB504u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB504u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B504 TAX
    cpu.transfer("TAX");
    goto L_80B505;
L_80B505:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB505u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB505u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB505u, 6u, 3u, cpu.address("abs", 0xB682u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B505 JSR -> $80B682 stack real
    { cpu.push16Value(hw,0xB507u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB508u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB682u), 0x80B505u); }
    goto L_80B508;
L_80B508:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB508u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB508u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB508u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B508 BCC -> $80B50D
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B50D; }
    goto L_80B50A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB508u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB508u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B508 BCC -> $80B50D
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B50D; }
    goto L_80B50A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB508u,0x80B508u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B50A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB50Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Au, 6u, 3u, cpu.address("abs", 0xB6F6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B50A JSR -> $80B6F6 stack real
    { cpu.push16Value(hw,0xB50Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB50Du,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB6F6u), 0x80B50Au); }
    goto L_80B50D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Au, 6u, 3u, cpu.address("abs", 0xB6F6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B50A JSR -> $80B6F6 stack real
    { cpu.push16Value(hw,0xB50Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB50Du,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB6F6u), 0x80B50Au); }
    goto L_80B50D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB50Au,0x80B50Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B50D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB50Du))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B50D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B50Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B50Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B50D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B50Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B50Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B50D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B50Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B50Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB50Du,0x80B50Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B50E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB50Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Eu, 5u, 3u, cpu.address("abs", 0x0137u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B50E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x137u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B511;
L_80B511:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB511u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB511u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB511u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B511 CMP
    cpu.compareA(0x2u);
    goto L_80B514;
L_80B514:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB514u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB514u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB514u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B514 BCC -> $80B50D
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B50D; }
    goto L_80B516;
L_80B516:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB516u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB516u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB516u, 5u, 3u, cpu.address("abs", 0x0902u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B516 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x902u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B519;
L_80B519:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB519u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB519u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB519u, 5u, 3u, cpu.address("abs", 0x0926u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B519 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x926u), cpu.m8?8:16));
    goto L_80B51C;
L_80B51C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB51Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB51Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB51Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B51C BNE -> $80B50D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B50D; }
    goto L_80B51E;
L_80B51E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB51Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB51Eu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB51Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B51E STX
    hw.write(cpu.address("dp", 0x61u), cpu.x, cpu.x8?8:16);
    goto L_80B520;
L_80B520:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB520u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB520u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB520u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B520 DEX
    cpu.decReg('X');
    goto L_80B521;
L_80B521:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB521u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB521u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB521u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B521 DEX
    cpu.decReg('X');
    goto L_80B522;
L_80B522:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB522u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB522u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB522u, 5u + 1u, 3u, cpu.address("absx", 0x097Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B522 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x97Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B525;
L_80B525:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB525u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB525u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB525u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B525 BNE -> $80B520
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B520; }
    goto L_80B527;
L_80B527:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB527u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB527u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB527u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B527 STX
    hw.write(cpu.address("dp", 0x63u), cpu.x, cpu.x8?8:16);
    goto L_80B529;
L_80B529:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB529u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB529u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB529u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B529 DEX
    cpu.decReg('X');
    goto L_80B52A;
L_80B52A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB52Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB52Au,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB52Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B52A DEX
    cpu.decReg('X');
    goto L_80B52B;
L_80B52B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB52Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB52Bu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB52Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B52B BMI -> $80B536
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80B536; }
    goto L_80B52D;
L_80B52D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB52Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB52Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB52Du, 5u + 1u, 3u, cpu.address("absx", 0x097Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B52D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x97Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B530;
L_80B530:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB530u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB530u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB530u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B530 BNE -> $80B529
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B529; }
    goto L_80B532;
L_80B532:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB532u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB532u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB532u, 6u, 3u, cpu.address("abs", 0xB63Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B532 JSR -> $80B63C stack real
    { cpu.push16Value(hw,0xB534u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB535u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB63Cu), 0x80B532u); }
    goto L_80B535;
L_80B535:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB535u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB535u,0x80B535u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB535u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB535u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B535 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B535u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B535u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80B536:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB536u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB536u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB536u, 6u, 3u, cpu.address("abs", 0xB53Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B536 JSR -> $80B53A stack real
    { cpu.push16Value(hw,0xB538u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB539u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB53Au), 0x80B536u); }
    goto L_80B539;
L_80B539:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB539u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB539u,0x80B539u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB539u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB539u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B539 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B539u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B539u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80B8FF_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B8FFu: goto L_80B8FF;
    case 0x80B901u: goto L_80B901;
    case 0x80B904u: goto L_80B904;
    case 0x80B906u: goto L_80B906;
    case 0x80B909u: goto L_80B909;
    case 0x80B90Cu: goto L_80B90C;
    case 0x80B910u: goto L_80B910;
    case 0x80B912u: goto L_80B912;
    case 0x80B915u: goto L_80B915;
    case 0x80B917u: goto L_80B917;
    case 0x80B919u: goto L_80B919;
    case 0x80B91Bu: goto L_80B91B;
    case 0x80B91Cu: goto L_80B91C;
    case 0x80B91Du: goto L_80B91D;
    case 0x80B920u: goto L_80B920;
    case 0x80B921u: goto L_80B921;
    case 0x80B923u: goto L_80B923;
    case 0x80B924u: goto L_80B924;
    case 0x80B927u: goto L_80B927;
    case 0x80B929u: goto L_80B929;
    case 0x80B92Bu: goto L_80B92B;
    case 0x80B92Cu: goto L_80B92C;
    case 0x80B92Eu: goto L_80B92E;
    case 0x80B92Fu: goto L_80B92F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B8FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B8FF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B901;
L_80B901:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB901u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB901u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB901u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B901 CMP
    cpu.compareA(0x60u);
    goto L_80B904;
L_80B904:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB904u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB904u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB904u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B904 BCC -> $80B92E
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B92E; }
    goto L_80B906;
L_80B906:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB906u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB906u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB906u, 5u, 3u, cpu.address("abs", 0x091Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B906 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x91Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B909;
L_80B909:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB909u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB909u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB909u, 5u + 1u, 3u, cpu.address("absy", 0x093Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B909 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0x93Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B90C;
L_80B90C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB90Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB90Cu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB90Cu, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B90C LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B910;
L_80B910:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB910u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB910u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB910u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B910 BNE -> $80B92E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B92E; }
    goto L_80B912;
L_80B912:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB912u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB912u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB912u, 5u, 3u, cpu.address("abs", 0x091Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B912 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x91Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B915;
L_80B915:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB915u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB915u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB915u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B915 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16));
    goto L_80B917;
L_80B917:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB917u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB917u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB917u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B917 BEQ -> $80B92B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B92B; }
    goto L_80B919;
L_80B919:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB919u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB919u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB919u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B919 BCC -> $80B92E
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B92E; }
    goto L_80B91B;
L_80B91B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB91Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Bu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B91B TXA
    cpu.transfer("TXA");
    goto L_80B91C;
L_80B91C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB91Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Cu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B91C CLC
    cpu.setFlag('C', false);
    goto L_80B91D;
L_80B91D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB91Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Du,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB91Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B91D ADC
    cpu.adc(0x16u);
    goto L_80B920;
L_80B920:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB920u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB920u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB920u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B920 TAX
    cpu.transfer("TAX");
    goto L_80B921;
L_80B921:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB921u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB921u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB921u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B921 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B923;
L_80B923:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB923u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB923u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB923u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B923 CLC
    cpu.setFlag('C', false);
    goto L_80B924;
L_80B924:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB924u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB924u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB924u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B924 ADC
    cpu.adc(0x8u);
    goto L_80B927;
L_80B927:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB927u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB927u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB927u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B927 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_80B929;
L_80B929:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB929u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB929u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB929u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B929 BRA -> $80B90C
    goto L_80B90C;
L_80B92B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB92Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Bu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B92B SEC
    cpu.setFlag('C', true);
    goto L_80B92C;
L_80B92C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB92Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Cu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B92C BRA -> $80B92F
    goto L_80B92F;
L_80B92E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB92Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Eu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B92E CLC
    cpu.setFlag('C', false);
    goto L_80B92F;
L_80B92F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB92Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B92F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B92Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B92Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB92Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B92F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B92Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B92Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB92Fu,0x80B92Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82942B_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82942Bu: goto L_82942B;
    case 0x82942Eu: goto L_82942E;
    case 0x829430u: goto L_829430;
    case 0x829432u: goto L_829432;
    case 0x829434u: goto L_829434;
    case 0x829436u: goto L_829436;
    case 0x829438u: goto L_829438;
    case 0x829439u: goto L_829439;
    case 0x82943Bu: goto L_82943B;
    case 0x82943Fu: goto L_82943F;
    case 0x829441u: goto L_829441;
    case 0x829442u: goto L_829442;
    case 0x829445u: goto L_829445;
    case 0x829448u: goto L_829448;
    case 0x829449u: goto L_829449;
    case 0x82944Au: goto L_82944A;
    case 0x82944Du: goto L_82944D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82942B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x942Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x942Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x942Bu, 5u, 3u, cpu.address("abs", 0x0193u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82942B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x193u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82942E;
L_82942E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x942Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x942Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x942Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82942E BEQ -> $829442
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_829442; }
    goto L_829430;
L_829430:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9430u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9430u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9430u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829430 SEP
    cpu.sep(0x20u);
    goto L_829432;
L_829432:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9432u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9432u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9432u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829432 LDA
    cpu.setA(0xCu, 8);
    goto L_829434;
L_829434:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9434u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9434u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9434u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829434 STA
    hw.write(cpu.address("dp", 0x49u), cpu.a, cpu.m8?8:16);
    goto L_829436;
L_829436:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9436u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9436u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9436u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829436 LDA
    cpu.setA(0x81u, 8);
    goto L_829438;
L_829438:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9438u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9438u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9438u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829438 XBA
    cpu.xba();
    goto L_829439;
L_829439:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9439u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9439u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9439u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829439 LDA
    cpu.setA(0xFu, 8);
    goto L_82943B;
L_82943B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x943Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x943Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x943Bu, 8u, 4u, 0x8086F4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82943B JSL -> $8086F4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x943Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x943Fu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8086F4u, 0x82943Bu); }
    goto L_82943F;
L_82943F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x943Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x943Fu,0x82943Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x943Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x943Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82943F REP
    cpu.rep(0x20u);
    goto L_829441;
L_829441:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9441u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9441u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9441u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829441 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829441u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829441u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_829442:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9442u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9442u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9442u, 5u, 3u, cpu.address("abs", 0x0176u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829442 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x176u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829445;
L_829445:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9445u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9445u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9445u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829445 AND
    cpu.logicAnd(0xFFu);
    goto L_829448;
L_829448:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9448u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9448u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9448u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829448 ASL
    cpu.aslA();
    goto L_829449;
L_829449:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9449u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9449u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9449u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829449 TAX
    cpu.transfer("TAX");
    goto L_82944A;
L_82944A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x944Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x944Au,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x944Au, 5u, 3u, cpu.address("abs", 0x944Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82944A PEA
    cpu.push16Value(hw, 0x944Fu);
    goto L_82944D;
L_82944D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x944Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x944Du,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x944Du, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x9451u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $82944D JMP (9451,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x9451u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x82944Du); return; }
}

void sub_829F53_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829F53u: goto L_829F53;
    case 0x829F56u: goto L_829F56;
    case 0x829F58u: goto L_829F58;
    case 0x829F5Bu: goto L_829F5B;
    case 0x829F5Du: goto L_829F5D;
    case 0x829F5Fu: goto L_829F5F;
    case 0x829F61u: goto L_829F61;
    case 0x829F63u: goto L_829F63;
    case 0x829F65u: goto L_829F65;
    case 0x829F68u: goto L_829F68;
    case 0x829F6Bu: goto L_829F6B;
    case 0x829F6Du: goto L_829F6D;
    case 0x829F70u: goto L_829F70;
    case 0x829F72u: goto L_829F72;
    case 0x829F75u: goto L_829F75;
    case 0x829F78u: goto L_829F78;
    case 0x829F7Bu: goto L_829F7B;
    case 0x829F7Cu: goto L_829F7C;
    case 0x829F7Fu: goto L_829F7F;
    case 0x829F82u: goto L_829F82;
    case 0x829F85u: goto L_829F85;
    case 0x829F87u: goto L_829F87;
    case 0x829F8Au: goto L_829F8A;
    case 0x829F8Du: goto L_829F8D;
    case 0x829F8Fu: goto L_829F8F;
    case 0x829F90u: goto L_829F90;
    case 0x829F92u: goto L_829F92;
    case 0x829F94u: goto L_829F94;
    case 0x829F97u: goto L_829F97;
    case 0x829F98u: goto L_829F98;
    case 0x829F9Bu: goto L_829F9B;
    case 0x829F9Eu: goto L_829F9E;
    case 0x829FA0u: goto L_829FA0;
    case 0x829FA3u: goto L_829FA3;
    case 0x829FA6u: goto L_829FA6;
    case 0x829FA8u: goto L_829FA8;
    case 0x829FA9u: goto L_829FA9;
    case 0x829FABu: goto L_829FAB;
    case 0x829FAEu: goto L_829FAE;
    case 0x829FB0u: goto L_829FB0;
    case 0x829FB3u: goto L_829FB3;
    case 0x829FB7u: goto L_829FB7;
    case 0x829FB9u: goto L_829FB9;
    case 0x829FBAu: goto L_829FBA;
    case 0x829FBDu: goto L_829FBD;
    case 0x829FC0u: goto L_829FC0;
    case 0x829FC2u: goto L_829FC2;
    case 0x829FC5u: goto L_829FC5;
    case 0x829FC8u: goto L_829FC8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829F53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F53u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F53u, 6u, 3u, cpu.address("abs", 0xBAD1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829F53 JSR -> $82BAD1 stack real
    { cpu.push16Value(hw,0x9F55u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9F56u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBAD1u), 0x829F53u); }
    goto L_829F56;
L_829F56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F56u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F56u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F56u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F56 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829F58;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F56u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F56u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F56 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829F58;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F56u,0x829F56u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829F58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F58u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F58u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F58u, 5u + 1u, 3u, cpu.address("absx", 0x02E8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F58 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2E8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829F5B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F58u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F58u, 5u + 1u, 3u, cpu.address("absx", 0x02E8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F58 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2E8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829F5B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F58u,0x829F58u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829F5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F5Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F5Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F5Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F5B BEQ -> $829F65
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_829F65; }
    goto L_829F5D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F5Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F5Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F5B BEQ -> $829F65
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_829F65; }
    goto L_829F5D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F5Bu,0x829F5Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829F5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F5Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F5Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F5Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F5D SEP
    cpu.sep(0x20u);
    goto L_829F5F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F5Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F5Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F5D SEP
    cpu.sep(0x20u);
    goto L_829F5F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F5Du,0x829F5Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829F5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F5Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F5Fu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F5Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F5F INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_829F61;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F5Fu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F5Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F5F INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_829F61;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F5Fu,0x829F5Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829F61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F61u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F61u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F61u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F61 REP
    cpu.rep(0x20u);
    goto L_829F63;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F61u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F61u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F61 REP
    cpu.rep(0x20u);
    goto L_829F63;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F61u,0x829F61u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829F63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F63u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F63u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F63u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F63 BRA -> $829F7C
    goto L_829F7C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F63u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F63u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F63 BRA -> $829F7C
    goto L_829F7C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F63u,0x829F63u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829F65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F65u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F65u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F65u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F65 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829F68;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F65u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F65u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F65 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829F68;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F65u,0x829F65u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829F68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F68u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F68u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F68u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F68 CMP
    cpu.compareA(0x1u);
    goto L_829F6B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F68u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F68u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F68 CMP
    cpu.compareA(0x1u);
    goto L_829F6B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F68u,0x829F68u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829F6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F6Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F6Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F6B BNE -> $829F7C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829F7C; }
    goto L_829F6D;
L_829F6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F6Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F6Du, 5u, 3u, cpu.address("abs", 0x0802u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F6D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x802u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829F70;
L_829F70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F70u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F70u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F70 BPL -> $829F7C
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_829F7C; }
    goto L_829F72;
L_829F72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F72u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F72u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F72 LDA
    cpu.setA(0xDu, 16);
    goto L_829F75;
L_829F75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F75u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F75u, 6u, 3u, cpu.address("absx", 0x0200u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F75 STA
    hw.write(cpu.address("absx", 0x200u), cpu.a, cpu.m8?8:16);
    goto L_829F78;
L_829F78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F78u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F78u, 9u, 3u, cpu.address("absx", 0x0422u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F78 INC
    cpu.incMem(hw, cpu.address("absx", 0x422u), cpu.m8?8:16);
    goto L_829F7B;
L_829F7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F7Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F7Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829F7B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829F7Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829F7Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_829F7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F7Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F7Cu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F7Cu, 6u, 3u, cpu.address("absx", 0x0200u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F7C STZ
    hw.write(cpu.address("absx", 0x200u), 0, cpu.m8?8:16);
    goto L_829F7F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F7Cu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F7Cu, 6u, 3u, cpu.address("absx", 0x0200u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F7C STZ
    hw.write(cpu.address("absx", 0x200u), 0, cpu.m8?8:16);
    goto L_829F7F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F7Cu,0x829F7Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829F7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F7Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F7Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F7Fu, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F7F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829F82;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F7Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F7Fu, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F7F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829F82;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F7Fu,0x829F7Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829F82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F82u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F82u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F82u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F82 CMP
    cpu.compareA(0x2u);
    goto L_829F85;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F82u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F82u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F82 CMP
    cpu.compareA(0x2u);
    goto L_829F85;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F82u,0x829F82u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829F85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F85u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F85u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F85 BCC -> $829FC8
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_829FC8; }
    goto L_829F87;
L_829F87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F87u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F87u, 5u + 1u, 3u, cpu.address("absx", 0x02F6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F87 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2F6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829F8A;
L_829F8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F8Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F8Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F8A CMP
    cpu.compareA(0x2u);
    goto L_829F8D;
L_829F8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F8Du,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F8Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F8D BCC -> $829FC8
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_829FC8; }
    goto L_829F8F;
L_829F8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F8Fu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F8Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F8F DEC
    cpu.decReg('A');
    goto L_829F90;
L_829F90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F90u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F90u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F90 STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_829F92;
L_829F92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F92u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F92u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F92 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829F94;
L_829F94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F94u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F94u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F94 EOR
    cpu.logicXor(0x100u);
    goto L_829F97;
L_829F97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F97u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F97u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F97 TAX
    cpu.transfer("TAX");
    goto L_829F98;
L_829F98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F98u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F98u, 5u, 3u, cpu.address("abs", 0x02E8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F98 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2E8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829F9B;
L_829F9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F9Bu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F9Bu, 5u, 3u, cpu.address("abs", 0x03E8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F9B ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x3E8u), cpu.m8?8:16));
    goto L_829F9E;
L_829F9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F9Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F9Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F9E BNE -> $829FB7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829FB7; }
    goto L_829FA0;
L_829FA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FA0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FA0u, 5u + 1u, 3u, cpu.address("absx", 0x040Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829FA0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x40Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829FA3;
L_829FA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FA3u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FA3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829FA3 CMP
    cpu.compareA(0x4u);
    goto L_829FA6;
L_829FA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FA6u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FA6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829FA6 BCS -> $829FB7
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_829FB7; }
    goto L_829FA8;
L_829FA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FA8u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FA8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829FA8 TXA
    cpu.transfer("TXA");
    goto L_829FA9;
L_829FA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FA9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FA9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829FA9 BNE -> $829FB0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829FB0; }
    goto L_829FAB;
L_829FAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FABu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FABu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829FAB LDA
    cpu.setA(0x31u, 16);
    goto L_829FAE;
L_829FAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FAEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FAEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829FAE BRA -> $829FB3
    goto L_829FB3;
L_829FB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FB0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FB0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829FB0 LDA
    cpu.setA(0x30u, 16);
    goto L_829FB3;
L_829FB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FB3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FB3u, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829FB3 JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9FB6u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9FB7u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x829FB3u); }
    goto L_829FB7;
L_829FB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FB7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9FB7u,0x829FB7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FB7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FB7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829FB7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829FB9;
L_829FB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FB9u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FB9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829FB9 CLC
    cpu.setFlag('C', false);
    goto L_829FBA;
L_829FBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FBAu,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FBAu, 5u + 1u, 3u, cpu.address("absx", 0x040Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829FBA ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x40Eu), cpu.m8?8:16));
    goto L_829FBD;
L_829FBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FBDu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FBDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829FBD CMP
    cpu.compareA(0x5u);
    goto L_829FC0;
L_829FC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FC0u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FC0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829FC0 BCC -> $829FC5
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_829FC5; }
    goto L_829FC2;
L_829FC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FC2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FC2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829FC2 LDA
    cpu.setA(0x4u, 16);
    goto L_829FC5;
L_829FC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FC5u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FC5u, 6u, 3u, cpu.address("absx", 0x040Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829FC5 STA
    hw.write(cpu.address("absx", 0x40Eu), cpu.a, cpu.m8?8:16);
    goto L_829FC8;
L_829FC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FC8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FC8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829FC8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829FC8u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829FC8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82A481_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82A481u: goto L_82A481;
    case 0x82A482u: goto L_82A482;
    case 0x82A483u: goto L_82A483;
    case 0x82A485u: goto L_82A485;
    case 0x82A486u: goto L_82A486;
    case 0x82A487u: goto L_82A487;
    case 0x82A488u: goto L_82A488;
    case 0x82A48Cu: goto L_82A48C;
    case 0x82A48Du: goto L_82A48D;
    case 0x82A491u: goto L_82A491;
    case 0x82A493u: goto L_82A493;
    case 0x82A496u: goto L_82A496;
    case 0x82A498u: goto L_82A498;
    case 0x82A49Bu: goto L_82A49B;
    case 0x82A49Du: goto L_82A49D;
    case 0x82A49Fu: goto L_82A49F;
    case 0x82A4A1u: goto L_82A4A1;
    case 0x82A4A4u: goto L_82A4A4;
    case 0x82A4A6u: goto L_82A4A6;
    case 0x82A4A9u: goto L_82A4A9;
    case 0x82A4ABu: goto L_82A4AB;
    case 0x82A4ADu: goto L_82A4AD;
    case 0x82A4B0u: goto L_82A4B0;
    case 0x82A4B2u: goto L_82A4B2;
    case 0x82A4B5u: goto L_82A4B5;
    case 0x82A4B7u: goto L_82A4B7;
    case 0x82A4B9u: goto L_82A4B9;
    case 0x82A4BBu: goto L_82A4BB;
    case 0x82A4BFu: goto L_82A4BF;
    case 0x82A4C1u: goto L_82A4C1;
    case 0x82A4C3u: goto L_82A4C3;
    case 0x82A4C5u: goto L_82A4C5;
    case 0x82A4C9u: goto L_82A4C9;
    case 0x82A4CBu: goto L_82A4CB;
    case 0x82A4CEu: goto L_82A4CE;
    case 0x82A4D0u: goto L_82A4D0;
    case 0x82A4D2u: goto L_82A4D2;
    case 0x82A4D3u: goto L_82A4D3;
    case 0x82A4D4u: goto L_82A4D4;
    case 0x82A4D7u: goto L_82A4D7;
    case 0x82A4D9u: goto L_82A4D9;
    case 0x82A4DAu: goto L_82A4DA;
    case 0x82A4DCu: goto L_82A4DC;
    case 0x82A4DDu: goto L_82A4DD;
    case 0x82A4DEu: goto L_82A4DE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82A481:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA481u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA481u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA481u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A481 PHY
    cpu.push("PHY", hw);
    goto L_82A482;
L_82A482:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA482u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA482u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA482u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A482 PHX
    cpu.push("PHX", hw);
    goto L_82A483;
L_82A483:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA483u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA483u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA483u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A483 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A485;
L_82A485:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA485u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA485u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA485u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A485 PHA
    cpu.push("PHA", hw);
    goto L_82A486;
L_82A486:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA486u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA486u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA486u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A486 TYA
    cpu.transfer("TYA");
    goto L_82A487;
L_82A487:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA487u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA487u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA487u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A487 CLC
    cpu.setFlag('C', false);
    goto L_82A488;
L_82A488:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA488u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA488u,cpu,0x7Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA488u, 6u, 4u, ((0x82A471u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A488 ADC
    cpu.adc(hw.readW(((0x82A471u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_82A48C;
L_82A48C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA48Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Cu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A48C TAY
    cpu.transfer("TAY");
    goto L_82A48D;
L_82A48D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA48Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Du,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA48Du, 6u, 4u, ((0x82A479u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A48D LDA
    cpu.loadA(hw.readW(((0x82A479u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A491;
L_82A491:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA491u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA491u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA491u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A491 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_82A493;
L_82A493:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA493u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA493u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA493u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A493 LDX
    cpu.setX(0x0u, 16);
    goto L_82A496;
L_82A496:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA496u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA496u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA496u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82A496 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A498;
L_82A498:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA498u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA498u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA498u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A498 BIT
    cpu.bit(0x4u, true);
    goto L_82A49B;
L_82A49B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA49Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA49Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA49Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A49B BNE -> $82A4BB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A4BB; }
    goto L_82A49D;
L_82A49D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA49Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA49Du,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA49Du, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82A49D LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A49F;
L_82A49F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA49Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA49Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA49Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A49F BEQ -> $82A4BB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A4BB; }
    goto L_82A4A1;
L_82A4A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A1u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4A1 BIT
    cpu.bit(0x6000u, true);
    goto L_82A4A4;
L_82A4A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4A4 BEQ -> $82A4AD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A4AD; }
    goto L_82A4A6;
L_82A4A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4A6 LDA
    cpu.setA(0x4000u, 16);
    goto L_82A4A9;
L_82A4A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4A9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4A9 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82A4AB;
L_82A4AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4ABu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4ABu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4AB BRA -> $82A4D9
    goto L_82A4D9;
L_82A4AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4ADu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4ADu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4AD BIT
    cpu.bit(0x8000u, true);
    goto L_82A4B0;
L_82A4B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4B0 BNE -> $82A4BB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A4BB; }
    goto L_82A4B2;
L_82A4B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B2u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4B2 BIT
    cpu.bit(0x30Fu, true);
    goto L_82A4B5;
L_82A4B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4B5 BEQ -> $82A4BB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A4BB; }
    goto L_82A4B7;
L_82A4B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B7u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4B7 STZ
    hw.write(cpu.address("dp", 0xAu), 0, cpu.m8?8:16);
    goto L_82A4B9;
L_82A4B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B9u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4B9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4B9 BRA -> $82A4D9
    goto L_82A4D9;
L_82A4BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4BBu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4BBu, 6u, 4u, ((0x82A469u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4BB LDA
    cpu.loadA(hw.readW(((0x82A469u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A4BF;
L_82A4BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4BFu,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4BFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4BF BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), false);
    goto L_82A4C1;
L_82A4C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4C1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4C1 BNE -> $82A4D2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A4D2; }
    goto L_82A4C3;
L_82A4C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4C3u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4C3u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82A4C3 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A4C5;
L_82A4C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4C5u,cpu,0x3Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4C5u, 6u, 4u, ((0x82A469u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4C5 AND
    cpu.logicAnd(hw.readW(((0x82A469u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_82A4C9;
L_82A4C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4C9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4C9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4C9 BEQ -> $82A4D2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A4D2; }
    goto L_82A4CB;
L_82A4CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4CBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4CBu, 6u, 3u, cpu.address("abs", 0xA481u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A4CB JSR -> $82A481 stack real
    { cpu.push16Value(hw,0xA4CDu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA4CEu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA481u), 0x82A4CBu); }
    goto L_82A4CE;
L_82A4CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4CEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA4CEu,0x82A4CEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4CEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4CEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4CE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A4D0;
L_82A4D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4D0u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4D0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4D0 BPL -> $82A4D9
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82A4D9; }
    goto L_82A4D2;
L_82A4D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4D2u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4D2 INX
    cpu.inc('X');
    goto L_82A4D3;
L_82A4D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4D3u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4D3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4D3 INX
    cpu.inc('X');
    goto L_82A4D4;
L_82A4D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4D4u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4D4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4D4 CPX
    cpu.compareX(0x8u);
    goto L_82A4D7;
L_82A4D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4D7u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4D7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4D7 BCC -> $82A4BB
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82A4BB; }
    goto L_82A4D9;
L_82A4D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4D9u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4D9u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A4D9 PLA
    cpu.pop("PLA", hw);
    goto L_82A4DA;
L_82A4DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4DAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4DAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A4DA STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_82A4DC;
L_82A4DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4DCu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4DCu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A4DC PLX
    cpu.pop("PLX", hw);
    goto L_82A4DD;
L_82A4DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4DDu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4DDu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A4DD PLY
    cpu.pop("PLY", hw);
    goto L_82A4DE;
L_82A4DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA4DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA4DEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA4DEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A4DE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A4DEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A4DEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82AD60_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82AD60u: goto L_82AD60;
    case 0x82AD63u: goto L_82AD63;
    case 0x82AD66u: goto L_82AD66;
    case 0x82AD69u: goto L_82AD69;
    case 0x82AD6Cu: goto L_82AD6C;
    case 0x82AD70u: goto L_82AD70;
    case 0x82AD72u: goto L_82AD72;
    case 0x82AD74u: goto L_82AD74;
    case 0x82AD75u: goto L_82AD75;
    case 0x82AD78u: goto L_82AD78;
    case 0x82AD7Bu: goto L_82AD7B;
    case 0x82AD7Eu: goto L_82AD7E;
    case 0x82AD82u: goto L_82AD82;
    case 0x82AD83u: goto L_82AD83;
    case 0x82AD86u: goto L_82AD86;
    case 0x82AD89u: goto L_82AD89;
    case 0x82AD8Cu: goto L_82AD8C;
    case 0x82AD8Fu: goto L_82AD8F;
    case 0x82AD90u: goto L_82AD90;
    case 0x82AD93u: goto L_82AD93;
    case 0x82AD95u: goto L_82AD95;
    case 0x82AD98u: goto L_82AD98;
    case 0x82AD9Au: goto L_82AD9A;
    case 0x82AD9Du: goto L_82AD9D;
    case 0x82ADA0u: goto L_82ADA0;
    case 0x82ADA4u: goto L_82ADA4;
    case 0x82ADA7u: goto L_82ADA7;
    case 0x82ADAAu: goto L_82ADAA;
    case 0x82ADADu: goto L_82ADAD;
    case 0x82ADB0u: goto L_82ADB0;
    case 0x82ADB4u: goto L_82ADB4;
    case 0x82ADB5u: goto L_82ADB5;
    case 0x82ADB8u: goto L_82ADB8;
    case 0x82ADBBu: goto L_82ADBB;
    case 0x82ADBDu: goto L_82ADBD;
    case 0x82ADBEu: goto L_82ADBE;
    case 0x82ADC1u: goto L_82ADC1;
    case 0x82ADC2u: goto L_82ADC2;
    case 0x82ADC5u: goto L_82ADC5;
    case 0x82ADC8u: goto L_82ADC8;
    case 0x82ADCBu: goto L_82ADCB;
    case 0x82ADCEu: goto L_82ADCE;
    case 0x82ADD2u: goto L_82ADD2;
    case 0x82ADD3u: goto L_82ADD3;
    case 0x82ADD6u: goto L_82ADD6;
    case 0x82ADD9u: goto L_82ADD9;
    case 0x82ADDBu: goto L_82ADDB;
    case 0x82ADDCu: goto L_82ADDC;
    case 0x82ADDFu: goto L_82ADDF;
    case 0x82ADE0u: goto L_82ADE0;
    case 0x82ADE3u: goto L_82ADE3;
    case 0x82ADE6u: goto L_82ADE6;
    case 0x82ADE9u: goto L_82ADE9;
    case 0x82ADECu: goto L_82ADEC;
    case 0x82ADF0u: goto L_82ADF0;
    case 0x82ADF1u: goto L_82ADF1;
    case 0x82ADF4u: goto L_82ADF4;
    case 0x82ADF7u: goto L_82ADF7;
    case 0x82ADF9u: goto L_82ADF9;
    case 0x82ADFAu: goto L_82ADFA;
    case 0x82ADFDu: goto L_82ADFD;
    case 0x82ADFEu: goto L_82ADFE;
    case 0x82AE01u: goto L_82AE01;
    case 0x82AE04u: goto L_82AE04;
    case 0x82AE07u: goto L_82AE07;
    case 0x82AE0Au: goto L_82AE0A;
    case 0x82AE0Du: goto L_82AE0D;
    case 0x82AE0Fu: goto L_82AE0F;
    case 0x82AE11u: goto L_82AE11;
    case 0x82AE12u: goto L_82AE12;
    case 0x82AE15u: goto L_82AE15;
    case 0x82AE18u: goto L_82AE18;
    case 0x82AE1Bu: goto L_82AE1B;
    case 0x82AE1Fu: goto L_82AE1F;
    case 0x82AE21u: goto L_82AE21;
    case 0x82AE23u: goto L_82AE23;
    case 0x82AE24u: goto L_82AE24;
    case 0x82AE27u: goto L_82AE27;
    case 0x82AE2Au: goto L_82AE2A;
    case 0x82AE2Du: goto L_82AE2D;
    case 0x82AE31u: goto L_82AE31;
    case 0x82AE33u: goto L_82AE33;
    case 0x82AE35u: goto L_82AE35;
    case 0x82AE36u: goto L_82AE36;
    case 0x82AE39u: goto L_82AE39;
    case 0x82AE3Cu: goto L_82AE3C;
    case 0x82AE3Fu: goto L_82AE3F;
    case 0x82AE43u: goto L_82AE43;
    case 0x82AE46u: goto L_82AE46;
    case 0x82AE4Au: goto L_82AE4A;
    case 0x82AE4Eu: goto L_82AE4E;
    case 0x82AE50u: goto L_82AE50;
    case 0x82AE53u: goto L_82AE53;
    case 0x82AE56u: goto L_82AE56;
    case 0x82AE58u: goto L_82AE58;
    case 0x82AE5Bu: goto L_82AE5B;
    case 0x82AE5Du: goto L_82AE5D;
    case 0x82AE60u: goto L_82AE60;
    case 0x82AE62u: goto L_82AE62;
    case 0x82AE65u: goto L_82AE65;
    case 0x82AE68u: goto L_82AE68;
    case 0x82AE6Bu: goto L_82AE6B;
    case 0x82AE6Du: goto L_82AE6D;
    case 0x82AE70u: goto L_82AE70;
    case 0x82AE73u: goto L_82AE73;
    case 0x82AE76u: goto L_82AE76;
    case 0x82AE78u: goto L_82AE78;
    case 0x82AE7Bu: goto L_82AE7B;
    case 0x82AE7Du: goto L_82AE7D;
    case 0x82AE81u: goto L_82AE81;
    case 0x82AE84u: goto L_82AE84;
    case 0x82AE88u: goto L_82AE88;
    case 0x82AE8Cu: goto L_82AE8C;
    case 0x82AE8Fu: goto L_82AE8F;
    case 0x82AE92u: goto L_82AE92;
    case 0x82AE94u: goto L_82AE94;
    case 0x82AE97u: goto L_82AE97;
    case 0x82AE9Bu: goto L_82AE9B;
    case 0x82AE9Eu: goto L_82AE9E;
    case 0x82AEA2u: goto L_82AEA2;
    case 0x82AEA6u: goto L_82AEA6;
    case 0x82AEA9u: goto L_82AEA9;
    case 0x82AEACu: goto L_82AEAC;
    case 0x82AEAFu: goto L_82AEAF;
    case 0x82AEB2u: goto L_82AEB2;
    case 0x82AEB5u: goto L_82AEB5;
    case 0x82AEB8u: goto L_82AEB8;
    case 0x82AEBAu: goto L_82AEBA;
    case 0x82AEBCu: goto L_82AEBC;
    case 0x82AEBFu: goto L_82AEBF;
    case 0x82AEC1u: goto L_82AEC1;
    case 0x82AEC4u: goto L_82AEC4;
    case 0x82AEC6u: goto L_82AEC6;
    case 0x82AEC8u: goto L_82AEC8;
    case 0x82AECAu: goto L_82AECA;
    case 0x82AECBu: goto L_82AECB;
    case 0x82AECDu: goto L_82AECD;
    case 0x82AED1u: goto L_82AED1;
    case 0x82AED3u: goto L_82AED3;
    case 0x82AED4u: goto L_82AED4;
    case 0x82AED6u: goto L_82AED6;
    case 0x82AEDAu: goto L_82AEDA;
    case 0x82AEDDu: goto L_82AEDD;
    case 0x82AEDFu: goto L_82AEDF;
    case 0x82AEE2u: goto L_82AEE2;
    case 0x82AEE5u: goto L_82AEE5;
    case 0x82AEE9u: goto L_82AEE9;
    case 0x82AEEBu: goto L_82AEEB;
    case 0x82AEEFu: goto L_82AEEF;
    case 0x82AEF3u: goto L_82AEF3;
    case 0x82AEF5u: goto L_82AEF5;
    case 0x82AEF9u: goto L_82AEF9;
    case 0x82AEFCu: goto L_82AEFC;
    case 0x82AEFEu: goto L_82AEFE;
    case 0x82AF00u: goto L_82AF00;
    case 0x82AF04u: goto L_82AF04;
    case 0x82AF08u: goto L_82AF08;
    case 0x82AF0Au: goto L_82AF0A;
    case 0x82AF0Cu: goto L_82AF0C;
    case 0x82AF10u: goto L_82AF10;
    case 0x82AF14u: goto L_82AF14;
    case 0x82AF16u: goto L_82AF16;
    case 0x82AF18u: goto L_82AF18;
    case 0x82AF1Au: goto L_82AF1A;
    case 0x82AF1Cu: goto L_82AF1C;
    case 0x82AF1Fu: goto L_82AF1F;
    case 0x82AF21u: goto L_82AF21;
    case 0x82AF23u: goto L_82AF23;
    case 0x82AF25u: goto L_82AF25;
    case 0x82AF29u: goto L_82AF29;
    case 0x82AF2Du: goto L_82AF2D;
    case 0x82AF2Fu: goto L_82AF2F;
    case 0x82AF31u: goto L_82AF31;
    case 0x82AF35u: goto L_82AF35;
    case 0x82AF39u: goto L_82AF39;
    case 0x82AF3Bu: goto L_82AF3B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82AD60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD60u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD60u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD60 LDA
    cpu.setA(0x8000u, 16);
    goto L_82AD63;
L_82AD63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD63u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD63u, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD63 STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_82AD66;
L_82AD66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD66u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD66u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD66 LDA
    cpu.setA(0x8Au, 16);
    goto L_82AD69;
L_82AD69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD69u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD69u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD69 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_82AD6C;
L_82AD6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD6Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD6Cu, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AD6C JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAD6Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAD70u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x82AD6Cu); }
    goto L_82AD70;
L_82AD70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD70u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD70u,0x82AD70u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD70u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD70u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD70 SEP
    cpu.sep(0x20u);
    goto L_82AD72;
L_82AD72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD72u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD72u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD72 LDA
    cpu.setA(0x7Eu, 8);
    goto L_82AD74;
L_82AD74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD74u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD74u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82AD74 PHA
    cpu.push("PHA", hw);
    goto L_82AD75;
L_82AD75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD75u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD75u, 5u, 3u, cpu.address("abs", 0x8000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AD75 PEA
    cpu.push16Value(hw, 0x8000u);
    goto L_82AD78;
L_82AD78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD78u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD78u, 5u, 3u, cpu.address("abs", 0x4000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AD78 PEA
    cpu.push16Value(hw, 0x4000u);
    goto L_82AD7B;
L_82AD7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Bu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Bu, 5u, 3u, cpu.address("abs", 0x1000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AD7B PEA
    cpu.push16Value(hw, 0x1000u);
    goto L_82AD7E;
L_82AD7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD7Eu, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AD7E JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAD81u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAD82u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x82AD7Eu); }
    goto L_82AD82;
L_82AD82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD82u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD82u,0x82AD82u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD82u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD82u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82AD82 PHB
    cpu.push("PHB", hw);
    goto L_82AD83;
L_82AD83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD83u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD83u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD83 LDX
    cpu.setX(0x8000u, 16);
    goto L_82AD86;
L_82AD86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD86u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD86u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD86 LDY
    cpu.setY(0x0u, 16);
    goto L_82AD89;
L_82AD89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD89u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD89u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD89 LDA
    cpu.setA(0xA3Eu, 16);
    goto L_82AD8C;
L_82AD8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Cu,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xAD8Cu, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Fu);
    // $82AD8C MVN
    cpu.blockMove(hw, 0x7Fu, 0x7Eu, false);
    goto L_82AD8F;
L_82AD8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Fu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD8Fu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82AD8F PLB
    cpu.pop("PLB", hw);
    goto L_82AD90;
L_82AD90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD90u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD90u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD90 LDA
    cpu.setA(0x866Cu, 16);
    goto L_82AD93;
L_82AD93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD93u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD93u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD93 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82AD95;
L_82AD95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD95u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD95u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD95 LDA
    cpu.setA(0x8Au, 16);
    goto L_82AD98;
L_82AD98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD98u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD98u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD98 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82AD9A;
L_82AD9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD9A LDX
    cpu.setX(0x0u, 16);
    goto L_82AD9D;
L_82AD9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Du,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AD9D LDY
    cpu.setY(0x200u, 16);
    goto L_82ADA0;
L_82ADA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA0u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA0u, 8u, 4u, 0x808BB9u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82ADA0 JSL -> $808BB9 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xADA3u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xADA4u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808BB9u, 0x82ADA0u); }
    goto L_82ADA4;
L_82ADA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADA4u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADA4u,0x82ADA4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADA4 LDA
    cpu.setA(0xA3EBu, 16);
    goto L_82ADA7;
L_82ADA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA7u, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADA7 STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_82ADAA;
L_82ADAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADAAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADAAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADAA LDA
    cpu.setA(0x8Bu, 16);
    goto L_82ADAD;
L_82ADAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADADu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADADu, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADAD STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_82ADB0;
L_82ADB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB0u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB0u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82ADB0 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xADB3u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xADB4u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x82ADB0u); }
    goto L_82ADB4;
L_82ADB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB4u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADB4u,0x82ADB4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB4u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB4u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82ADB4 PHB
    cpu.push("PHB", hw);
    goto L_82ADB5;
L_82ADB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB5u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADB5 LDX
    cpu.setX(0x8000u, 16);
    goto L_82ADB8;
L_82ADB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB8u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADB8 LDY
    cpu.setY(0x2800u, 16);
    goto L_82ADBB;
L_82ADBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADBBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADBBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADBB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82ADBD;
L_82ADBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADBDu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADBDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADBD DEC
    cpu.decReg('A');
    goto L_82ADBE;
L_82ADBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADBEu,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xADBEu, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $82ADBE MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_82ADC1;
L_82ADC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC1u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82ADC1 PLB
    cpu.pop("PLB", hw);
    goto L_82ADC2;
L_82ADC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADC2 LDA
    cpu.setA(0xA746u, 16);
    goto L_82ADC5;
L_82ADC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC5u, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADC5 STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_82ADC8;
L_82ADC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADC8 LDA
    cpu.setA(0x8Bu, 16);
    goto L_82ADCB;
L_82ADCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADCBu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADCBu, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADCB STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_82ADCE;
L_82ADCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADCEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADCEu, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82ADCE JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xADD1u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xADD2u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x82ADCEu); }
    goto L_82ADD2;
L_82ADD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADD2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADD2u,0x82ADD2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD2u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD2u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82ADD2 PHB
    cpu.push("PHB", hw);
    goto L_82ADD3;
L_82ADD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD3u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADD3 LDX
    cpu.setX(0x8000u, 16);
    goto L_82ADD6;
L_82ADD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD6u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADD6 LDY
    cpu.setY(0x4000u, 16);
    goto L_82ADD9;
L_82ADD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADD9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82ADDB;
L_82ADDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADDBu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADDBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADDB DEC
    cpu.decReg('A');
    goto L_82ADDC;
L_82ADDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADDCu,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xADDCu, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $82ADDC MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_82ADDF;
L_82ADDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADDFu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADDFu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82ADDF PLB
    cpu.pop("PLB", hw);
    goto L_82ADE0;
L_82ADE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADE0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADE0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADE0 LDA
    cpu.setA(0x840Bu, 16);
    goto L_82ADE3;
L_82ADE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADE3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADE3u, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADE3 STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_82ADE6;
L_82ADE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADE6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADE6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADE6 LDA
    cpu.setA(0x89u, 16);
    goto L_82ADE9;
L_82ADE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADE9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADE9u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADE9 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_82ADEC;
L_82ADEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADECu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADECu, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82ADEC JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xADEFu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xADF0u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x82ADECu); }
    goto L_82ADF0;
L_82ADF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADF0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADF0u,0x82ADF0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADF0u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADF0u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82ADF0 PHB
    cpu.push("PHB", hw);
    goto L_82ADF1;
L_82ADF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADF1u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADF1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADF1 LDX
    cpu.setX(0x8000u, 16);
    goto L_82ADF4;
L_82ADF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADF4u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADF4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADF4 LDY
    cpu.setY(0x6000u, 16);
    goto L_82ADF7;
L_82ADF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADF7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADF7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADF7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82ADF9;
L_82ADF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADF9u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADF9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ADF9 DEC
    cpu.decReg('A');
    goto L_82ADFA;
L_82ADFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADFAu,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xADFAu, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $82ADFA MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_82ADFD;
L_82ADFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADFDu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADFDu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82ADFD PLB
    cpu.pop("PLB", hw);
    goto L_82ADFE;
L_82ADFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADFEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADFEu, 6u, 3u, cpu.address("abs", 0xCAEEu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82ADFE JSR -> $82CAEE stack real
    { cpu.push16Value(hw,0xAE00u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE01u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCAEEu), 0x82ADFEu); }
    goto L_82AE01;
L_82AE01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE01u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE01u,0x82AE01u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE01u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE01u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE01 LDX
    cpu.setX(0x0u, 16);
    goto L_82AE04;
L_82AE04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE04u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE04u, 6u, 3u, cpu.address("abs", 0xCB5Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AE04 JSR -> $82CB5F stack real
    { cpu.push16Value(hw,0xAE06u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE07u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCB5Fu), 0x82AE04u); }
    goto L_82AE07;
L_82AE07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE07u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE07u,0x82AE07u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE07u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE07u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE07 LDX
    cpu.setX(0x100u, 16);
    goto L_82AE0A;
L_82AE0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Au, 6u, 3u, cpu.address("abs", 0xCB5Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AE0A JSR -> $82CB5F stack real
    { cpu.push16Value(hw,0xAE0Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE0Du,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCB5Fu), 0x82AE0Au); }
    goto L_82AE0D;
L_82AE0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE0Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE0Du,0x82AE0Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE0D SEP
    cpu.sep(0x20u);
    goto L_82AE0F;
L_82AE0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE0Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE0F LDA
    cpu.setA(0x7Eu, 8);
    goto L_82AE11;
L_82AE11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE11u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE11u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82AE11 PHA
    cpu.push("PHA", hw);
    goto L_82AE12;
L_82AE12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE12u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE12u, 5u, 3u, cpu.address("abs", 0x2800u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AE12 PEA
    cpu.push16Value(hw, 0x2800u);
    goto L_82AE15;
L_82AE15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE15u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE15u, 5u, 3u, cpu.address("abs", 0x5000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AE15 PEA
    cpu.push16Value(hw, 0x5000u);
    goto L_82AE18;
L_82AE18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE18u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE18u, 5u, 3u, cpu.address("abs", 0x0800u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AE18 PEA
    cpu.push16Value(hw, 0x800u);
    goto L_82AE1B;
L_82AE1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Bu, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AE1B JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAE1Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE1Fu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x82AE1Bu); }
    goto L_82AE1F;
L_82AE1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE1Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE1Fu,0x82AE1Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE1Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE1F SEP
    cpu.sep(0x20u);
    goto L_82AE21;
L_82AE21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE21u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE21u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE21 LDA
    cpu.setA(0x7Eu, 8);
    goto L_82AE23;
L_82AE23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE23u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE23u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82AE23 PHA
    cpu.push("PHA", hw);
    goto L_82AE24;
L_82AE24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE24u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE24u, 5u, 3u, cpu.address("abs", 0x4000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AE24 PEA
    cpu.push16Value(hw, 0x4000u);
    goto L_82AE27;
L_82AE27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE27u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE27u, 5u, 3u, cpu.address("abs", 0x5800u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AE27 PEA
    cpu.push16Value(hw, 0x5800u);
    goto L_82AE2A;
L_82AE2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE2Au,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE2Au, 5u, 3u, cpu.address("abs", 0x0800u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AE2A PEA
    cpu.push16Value(hw, 0x800u);
    goto L_82AE2D;
L_82AE2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE2Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE2Du, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AE2D JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAE30u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE31u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x82AE2Du); }
    goto L_82AE31;
L_82AE31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE31u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE31u,0x82AE31u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE31u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE31u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE31 SEP
    cpu.sep(0x20u);
    goto L_82AE33;
L_82AE33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE33u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE33u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE33 LDA
    cpu.setA(0x7Eu, 8);
    goto L_82AE35;
L_82AE35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE35u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE35u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82AE35 PHA
    cpu.push("PHA", hw);
    goto L_82AE36;
L_82AE36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE36u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE36u, 5u, 3u, cpu.address("abs", 0x6000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AE36 PEA
    cpu.push16Value(hw, 0x6000u);
    goto L_82AE39;
L_82AE39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE39u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE39u, 5u, 3u, cpu.address("abs", 0x5C00u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AE39 PEA
    cpu.push16Value(hw, 0x5C00u);
    goto L_82AE3C;
L_82AE3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Cu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Cu, 5u, 3u, cpu.address("abs", 0x0800u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AE3C PEA
    cpu.push16Value(hw, 0x800u);
    goto L_82AE3F;
L_82AE3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Fu, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AE3F JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAE42u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE43u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x82AE3Fu); }
    goto L_82AE43;
L_82AE43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE43u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE43u,0x82AE43u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE43u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE43u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE43 LDA
    cpu.setA(0xFFFFu, 16);
    goto L_82AE46;
L_82AE46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE46u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE46u, 8u, 4u, 0x80A460u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AE46 JSL -> $80A460 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAE49u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE4Au,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A460u, 0x82AE46u); }
    goto L_82AE4A;
L_82AE4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE4Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE4Au,0x82AE4Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Au, 8u, 4u, 0x80A4A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AE4A JSL -> $80A4A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAE4Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE4Eu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A4A3u, 0x82AE4Au); }
    goto L_82AE4E;
L_82AE4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE4Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE4Eu,0x82AE4Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE4E SEP
    cpu.sep(0x20u);
    goto L_82AE50;
L_82AE50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE50u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE50u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE50 LDX
    cpu.setX(0x2000u, 16);
    goto L_82AE53;
L_82AE53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE53u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE53u, 5u, 3u, cpu.address("abs", 0x2181u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE53 STX
    hw.write(cpu.address("abs", 0x2181u), cpu.x, cpu.x8?8:16);
    goto L_82AE56;
L_82AE56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE56u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE56u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE56 LDA
    cpu.setA(0x0u, 8);
    goto L_82AE58;
L_82AE58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE58u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE58u, 4u, 3u, cpu.address("abs", 0x2183u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE58 STA
    hw.write(cpu.address("abs", 0x2183u), cpu.a, cpu.m8?8:16);
    goto L_82AE5B;
L_82AE5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE5B LDA
    cpu.setA(0x8u, 8);
    goto L_82AE5D;
L_82AE5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Du, 4u, 3u, cpu.address("abs", 0x4370u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE5D STA
    hw.write(cpu.address("abs", 0x4370u), cpu.a, cpu.m8?8:16);
    goto L_82AE60;
L_82AE60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE60u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE60u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE60 LDA
    cpu.setA(0x80u, 8);
    goto L_82AE62;
L_82AE62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE62u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE62u, 4u, 3u, cpu.address("abs", 0x4371u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE62 STA
    hw.write(cpu.address("abs", 0x4371u), cpu.a, cpu.m8?8:16);
    goto L_82AE65;
L_82AE65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE65u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE65u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE65 LDX
    cpu.setX(0x8D46u, 16);
    goto L_82AE68;
L_82AE68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE68u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE68u, 5u, 3u, cpu.address("abs", 0x4372u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE68 STX
    hw.write(cpu.address("abs", 0x4372u), cpu.x, cpu.x8?8:16);
    goto L_82AE6B;
L_82AE6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE6B LDA
    cpu.setA(0x80u, 8);
    goto L_82AE6D;
L_82AE6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Du, 4u, 3u, cpu.address("abs", 0x4374u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE6D STA
    hw.write(cpu.address("abs", 0x4374u), cpu.a, cpu.m8?8:16);
    goto L_82AE70;
L_82AE70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE70u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE70u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE70 LDX
    cpu.setX(0x800u, 16);
    goto L_82AE73;
L_82AE73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE73u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE73u, 5u, 3u, cpu.address("abs", 0x4375u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE73 STX
    hw.write(cpu.address("abs", 0x4375u), cpu.x, cpu.x8?8:16);
    goto L_82AE76;
L_82AE76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE76u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE76u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE76 LDA
    cpu.setA(0x80u, 8);
    goto L_82AE78;
L_82AE78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE78u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE78u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE78 STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_82AE7B;
L_82AE7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE7Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE7Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE7B REP
    cpu.rep(0x20u);
    goto L_82AE7D;
L_82AE7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE7Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE7Du, 8u, 4u, 0x809C0Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AE7D JSL -> $809C0C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAE80u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE81u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809C0Cu, 0x82AE7Du); }
    goto L_82AE81;
L_82AE81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE81u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE81u,0x82AE81u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE81u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE81u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE81 LDX
    cpu.setX(0x0u, 16);
    goto L_82AE84;
L_82AE84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE84u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE84u, 8u, 4u, 0x848000u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AE84 JSL -> $848000 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAE87u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE88u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848000u, 0x82AE84u); }
    goto L_82AE88;
L_82AE88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE88u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE88u,0x82AE88u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE88u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE88u, 8u, 4u, 0x809C3Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AE88 JSL -> $809C3A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAE8Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE8Cu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809C3Au, 0x82AE88u); }
    goto L_82AE8C;
L_82AE8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE8Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE8Cu,0x82AE8Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE8Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE8Cu, 5u, 3u, cpu.address("abs", 0x02CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE8C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2CEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AE8F;
L_82AE8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE8Fu,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE8Fu, 5u, 3u, cpu.address("abs", 0x03CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE8F CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x3CEu), cpu.m8?8:16));
    goto L_82AE92;
L_82AE92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE92u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE92u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE92 BEQ -> $82AEA2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82AEA2; }
    goto L_82AE94;
L_82AE94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE94u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE94u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE94 LDA
    cpu.setA(0x220u, 16);
    goto L_82AE97;
L_82AE97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE97u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE97u, 8u, 4u, 0x809CC1u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AE97 JSL -> $809CC1 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAE9Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE9Bu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809CC1u, 0x82AE97u); }
    goto L_82AE9B;
L_82AE9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE9Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE9Bu,0x82AE9Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE9Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE9Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AE9B LDX
    cpu.setX(0x100u, 16);
    goto L_82AE9E;
L_82AE9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE9Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE9Eu, 8u, 4u, 0x848000u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AE9E JSL -> $848000 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAEA1u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAEA2u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848000u, 0x82AE9Eu); }
    goto L_82AEA2;
L_82AEA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEA2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAEA2u,0x82AEA2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA2u, 8u, 4u, 0x809C69u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AEA2 JSL -> $809C69 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAEA5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAEA6u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809C69u, 0x82AEA2u); }
    goto L_82AEA6;
L_82AEA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEA6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAEA6u,0x82AEA6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA6u, 6u, 3u, cpu.address("abs", 0xCD0Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AEA6 JSR -> $82CD0D stack real
    { cpu.push16Value(hw,0xAEA8u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAEA9u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCD0Du), 0x82AEA6u); }
    goto L_82AEA9;
L_82AEA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEA9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAEA9u,0x82AEA9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA9u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA9u, 5u, 3u, cpu.address("abs", 0x0148u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEA9 STZ
    hw.write(cpu.address("abs", 0x148u), 0, cpu.m8?8:16);
    goto L_82AEAC;
L_82AEAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEACu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEACu, 5u, 3u, cpu.address("abs", 0x0141u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEAC STZ
    hw.write(cpu.address("abs", 0x141u), 0, cpu.m8?8:16);
    goto L_82AEAF;
L_82AEAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEAFu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEAFu, 5u, 3u, cpu.address("abs", 0x018Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEAF STZ
    hw.write(cpu.address("abs", 0x18Fu), 0, cpu.m8?8:16);
    goto L_82AEB2;
L_82AEB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB2u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB2u, 5u, 3u, cpu.address("abs", 0x0191u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEB2 STZ
    hw.write(cpu.address("abs", 0x191u), 0, cpu.m8?8:16);
    goto L_82AEB5;
L_82AEB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB5u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB5u, 5u, 3u, cpu.address("abs", 0x0193u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEB5 STZ
    hw.write(cpu.address("abs", 0x193u), 0, cpu.m8?8:16);
    goto L_82AEB8;
L_82AEB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB8u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEB8 SEP
    cpu.sep(0x20u);
    goto L_82AEBA;
L_82AEBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEBA LDA
    cpu.setA(0x2u, 8);
    goto L_82AEBC;
L_82AEBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBCu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBCu, 4u, 3u, cpu.address("abs", 0x2130u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEBC STA
    hw.write(cpu.address("abs", 0x2130u), cpu.a, cpu.m8?8:16);
    goto L_82AEBF;
L_82AEBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEBF LDA
    cpu.setA(0x53u, 8);
    goto L_82AEC1;
L_82AEC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC1u, 4u, 3u, cpu.address("abs", 0x2131u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEC1 STA
    hw.write(cpu.address("abs", 0x2131u), cpu.a, cpu.m8?8:16);
    goto L_82AEC4;
L_82AEC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC4u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEC4 STZ
    hw.write(cpu.address("dp", 0x47u), 0, cpu.m8?8:16);
    goto L_82AEC6;
L_82AEC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC6u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEC6 STZ
    hw.write(cpu.address("dp", 0x49u), 0, cpu.m8?8:16);
    goto L_82AEC8;
L_82AEC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEC8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEC8 LDA
    cpu.setA(0xC3u, 8);
    goto L_82AECA;
L_82AECA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAECAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAECAu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAECAu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AECA XBA
    cpu.xba();
    goto L_82AECB;
L_82AECB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAECBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAECBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAECBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AECB LDA
    cpu.setA(0x0u, 8);
    goto L_82AECD;
L_82AECD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAECDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAECDu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAECDu, 8u, 4u, 0x8086F4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AECD JSL -> $8086F4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAED0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAED1u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8086F4u, 0x82AECDu); }
    goto L_82AED1;
L_82AED1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAED1u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAED1u,0x82AED1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAED1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAED1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AED1 LDA
    cpu.setA(0xC3u, 8);
    goto L_82AED3;
L_82AED3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAED3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAED3u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAED3u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AED3 XBA
    cpu.xba();
    goto L_82AED4;
L_82AED4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAED4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAED4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAED4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AED4 LDA
    cpu.setA(0xF1u, 8);
    goto L_82AED6;
L_82AED6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAED6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAED6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAED6u, 8u, 4u, 0x808700u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AED6 JSL -> $808700 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAED9u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAEDAu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808700u, 0x82AED6u); }
    goto L_82AEDA;
L_82AEDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEDAu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAEDAu,0x82AEDAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEDAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEDAu, 4u, 3u, cpu.address("abs", 0x018Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEDA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x18Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AEDD;
L_82AEDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEDDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEDDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEDD BNE -> $82AEF9
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82AEF9; }
    goto L_82AEDF;
L_82AEDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEDFu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEDFu, 6u, 3u, cpu.address("abs", 0x018Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEDF INC
    cpu.incMem(hw, cpu.address("abs", 0x18Du), cpu.m8?8:16);
    goto L_82AEE2;
L_82AEE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE2u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE2u, 5u, 3u, cpu.address("abs", 0x014Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEE2 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x14Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82AEE5;
L_82AEE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE5u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE5u, 5u, 4u, ((0x9E9569u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEE5 LDA
    cpu.loadA(hw.readW(((0x9E9569u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AEE9;
L_82AEE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEE9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEE9 BEQ -> $82AEF5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82AEF5; }
    goto L_82AEEB;
L_82AEEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEEBu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEEBu, 8u, 4u, 0x80A6BDu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AEEB JSL -> $80A6BD stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAEEEu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAEEFu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6BDu, 0x82AEEBu); }
    goto L_82AEEF;
L_82AEEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEEFu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAEEFu,0x82AEEFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEEFu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEEFu, 8u, 4u, 0x80A6A5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AEEF JSL -> $80A6A5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAEF2u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAEF3u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6A5u, 0x82AEEFu); }
    goto L_82AEF3;
L_82AEF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEF3u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAEF3u,0x82AEF3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF3u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEF3 BRA -> $82AEF9
    goto L_82AEF9;
L_82AEF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF5u, 8u, 4u, 0x80A5D1u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AEF5 JSL -> $80A5D1 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAEF8u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAEF9u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A5D1u, 0x82AEF5u); }
    goto L_82AEF9;
L_82AEF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEF9u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAEF9u,0x82AEF9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF9u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEF9u, 6u, 3u, cpu.address("abs", 0x014Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEF9 INC
    cpu.incMem(hw, cpu.address("abs", 0x14Au), cpu.m8?8:16);
    goto L_82AEFC;
L_82AEFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFCu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEFC BRA -> $82AEFE
    goto L_82AEFE;
L_82AEFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEFEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AEFE LDA
    cpu.setA(0xAAu, 8);
    goto L_82AF00;
L_82AF00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF00u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF00u, 5u, 4u, 0x700000u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF00 STA
    hw.write(0x700000u, cpu.a, cpu.m8?8:16);
    goto L_82AF04;
L_82AF04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF04u,cpu,0xCFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF04u, 5u, 4u, 0x700000u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF04 CMP
    cpu.compareA(hw.readW(0x700000u, cpu.m8?8:16));
    goto L_82AF08;
L_82AF08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF08u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF08u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF08 BNE -> $82AF1C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82AF1C; }
    goto L_82AF0A;
L_82AF0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF0Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF0Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF0A LDA
    cpu.setA(0x55u, 8);
    goto L_82AF0C;
L_82AF0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF0Cu,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF0Cu, 5u, 4u, 0x700000u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF0C STA
    hw.write(0x700000u, cpu.a, cpu.m8?8:16);
    goto L_82AF10;
L_82AF10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF10u,cpu,0xCFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF10u, 5u, 4u, 0x700000u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF10 CMP
    cpu.compareA(hw.readW(0x700000u, cpu.m8?8:16));
    goto L_82AF14;
L_82AF14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF14u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF14u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF14 BNE -> $82AF1C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82AF1C; }
    goto L_82AF16;
L_82AF16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF16u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF16u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF16 LDA
    cpu.setA(0x84u, 8);
    goto L_82AF18;
L_82AF18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF18u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF18u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF18 STA
    hw.write(cpu.address("dp", 0x46u), cpu.a, cpu.m8?8:16);
    goto L_82AF1A;
L_82AF1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Au,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF1A BRA -> $82AF3B
    goto L_82AF3B;
L_82AF1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Cu, 4u, 3u, cpu.address("abs", 0x213Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF1C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x213Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AF1F;
L_82AF1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Fu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF1Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF1F BIT
    cpu.bit(0x10u, true);
    goto L_82AF21;
L_82AF21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF21u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF21u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF21 BNE -> $82AF16
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82AF16; }
    goto L_82AF23;
L_82AF23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF23u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF23u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF23 LDA
    cpu.setA(0xAAu, 8);
    goto L_82AF25;
L_82AF25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF25u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF25u, 5u, 4u, 0x80FFC0u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF25 STA
    hw.write(0x80FFC0u, cpu.a, cpu.m8?8:16);
    goto L_82AF29;
L_82AF29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF29u,cpu,0xCFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF29u, 5u, 4u, 0x80FFC0u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF29 CMP
    cpu.compareA(hw.readW(0x80FFC0u, cpu.m8?8:16));
    goto L_82AF2D;
L_82AF2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF2Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF2Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF2D BNE -> $82AF3B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82AF3B; }
    goto L_82AF2F;
L_82AF2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF2Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF2Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF2F LDA
    cpu.setA(0x55u, 8);
    goto L_82AF31;
L_82AF31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF31u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF31u, 5u, 4u, 0x80FFC0u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF31 STA
    hw.write(0x80FFC0u, cpu.a, cpu.m8?8:16);
    goto L_82AF35;
L_82AF35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF35u,cpu,0xCFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF35u, 5u, 4u, 0x80FFC0u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF35 CMP
    cpu.compareA(hw.readW(0x80FFC0u, cpu.m8?8:16));
    goto L_82AF39;
L_82AF39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF39u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF39u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF39 BEQ -> $82AF16
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82AF16; }
    goto L_82AF3B;
L_82AF3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Bu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AF3B RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82AF3Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82AF3Bu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82AF3C_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82AF3Cu: goto L_82AF3C;
    case 0x82AF3Eu: goto L_82AF3E;
    case 0x82AF40u: goto L_82AF40;
    case 0x82AF42u: goto L_82AF42;
    case 0x82AF44u: goto L_82AF44;
    case 0x82AF46u: goto L_82AF46;
    case 0x82AF48u: goto L_82AF48;
    case 0x82AF4Bu: goto L_82AF4B;
    case 0x82AF4Cu: goto L_82AF4C;
    case 0x82AF4Du: goto L_82AF4D;
    case 0x82AF50u: goto L_82AF50;
    case 0x82AF53u: goto L_82AF53;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82AF3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF3C SEP
    cpu.sep(0x20u);
    goto L_82AF3E;
L_82AF3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF3E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x47u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AF40;
L_82AF40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF40u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF40u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF40 BPL -> $82AF53
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82AF53; }
    goto L_82AF42;
L_82AF42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF42u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF42u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF42 AND
    cpu.logicAnd(0x7Fu);
    goto L_82AF44;
L_82AF44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF44u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF44u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF44 STA
    hw.write(cpu.address("dp", 0x47u), cpu.a, cpu.m8?8:16);
    goto L_82AF46;
L_82AF46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF46u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF46u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF46 REP
    cpu.rep(0x20u);
    goto L_82AF48;
L_82AF48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF48u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF48u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF48 AND
    cpu.logicAnd(0xFFu);
    goto L_82AF4B;
L_82AF4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF4B ASL
    cpu.aslA();
    goto L_82AF4C;
L_82AF4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Cu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF4C TAX
    cpu.transfer("TAX");
    goto L_82AF4D;
L_82AF4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Du,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Du, 5u, 3u, cpu.address("abs", 0xAF52u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AF4D PEA
    cpu.push16Value(hw, 0xAF52u);
    goto L_82AF50;
L_82AF50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF50u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF50u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xAF54u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $82AF50 JMP (AF54,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xAF54u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x82AF50u); return; }
L_82AF53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF53u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF53u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AF53 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82AF53u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82AF53u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82AF3C_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82AF3Cu: goto L_82AF3C;
    case 0x82AF3Eu: goto L_82AF3E;
    case 0x82AF40u: goto L_82AF40;
    case 0x82AF42u: goto L_82AF42;
    case 0x82AF44u: goto L_82AF44;
    case 0x82AF46u: goto L_82AF46;
    case 0x82AF48u: goto L_82AF48;
    case 0x82AF4Bu: goto L_82AF4B;
    case 0x82AF4Cu: goto L_82AF4C;
    case 0x82AF4Du: goto L_82AF4D;
    case 0x82AF50u: goto L_82AF50;
    case 0x82AF53u: goto L_82AF53;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82AF3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF3C SEP
    cpu.sep(0x20u);
    goto L_82AF3E;
L_82AF3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF3Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF3E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x47u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AF40;
L_82AF40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF40u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF40u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF40 BPL -> $82AF53
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82AF53; }
    goto L_82AF42;
L_82AF42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF42u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF42u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF42 AND
    cpu.logicAnd(0x7Fu);
    goto L_82AF44;
L_82AF44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF44u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF44u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF44 STA
    hw.write(cpu.address("dp", 0x47u), cpu.a, cpu.m8?8:16);
    goto L_82AF46;
L_82AF46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF46u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF46u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF46 REP
    cpu.rep(0x20u);
    goto L_82AF48;
L_82AF48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF48u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF48u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF48 AND
    cpu.logicAnd(0xFFu);
    goto L_82AF4B;
L_82AF4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF4B ASL
    cpu.aslA();
    goto L_82AF4C;
L_82AF4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Cu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AF4C TAX
    cpu.transfer("TAX");
    goto L_82AF4D;
L_82AF4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Du,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF4Du, 5u, 3u, cpu.address("abs", 0xAF52u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AF4D PEA
    cpu.push16Value(hw, 0xAF52u);
    goto L_82AF50;
L_82AF50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF50u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF50u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xAF54u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $82AF50 JMP (AF54,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xAF54u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x82AF50u); return; }
L_82AF53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF53u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF53u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82AF53 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82AF53u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82AF53u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82AFD2_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82AFD2u: goto L_82AFD2;
    case 0x82AFD5u: goto L_82AFD5;
    case 0x82AFD7u: goto L_82AFD7;
    case 0x82AFD9u: goto L_82AFD9;
    case 0x82AFDBu: goto L_82AFDB;
    case 0x82AFDDu: goto L_82AFDD;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82AFD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD2u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD2u, 8u, 3u, cpu.address("abs", 0x014Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFD2 INC
    cpu.incMem(hw, cpu.address("abs", 0x14Au), cpu.m8?8:16);
    goto L_82AFD5;
L_82AFD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD5u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFD5 SEP
    cpu.sep(0x20u);
    goto L_82AFD7;
L_82AFD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFD7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AFD9;
L_82AFD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFD9 BNE -> $82AFDD
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82AFDD; }
    goto L_82AFDB;
L_82AFDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFDBu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFDBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFDB INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_82AFDD;
L_82AFDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFDDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFDDu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFDDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AFDD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82AFDDu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82AFDDu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82BD2B_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82BD2Bu: goto L_82BD2B;
    case 0x82BD2Eu: goto L_82BD2E;
    case 0x82BD31u: goto L_82BD31;
    case 0x82BD34u: goto L_82BD34;
    case 0x82BD37u: goto L_82BD37;
    case 0x82BD3Au: goto L_82BD3A;
    case 0x82BD3Du: goto L_82BD3D;
    case 0x82BD40u: goto L_82BD40;
    case 0x82BD43u: goto L_82BD43;
    case 0x82BD46u: goto L_82BD46;
    case 0x82BD49u: goto L_82BD49;
    case 0x82BD4Cu: goto L_82BD4C;
    case 0x82BD4Fu: goto L_82BD4F;
    case 0x82BD52u: goto L_82BD52;
    case 0x82BD55u: goto L_82BD55;
    case 0x82BD58u: goto L_82BD58;
    case 0x82BD5Bu: goto L_82BD5B;
    case 0x82BD5Eu: goto L_82BD5E;
    case 0x82BD61u: goto L_82BD61;
    case 0x82BD64u: goto L_82BD64;
    case 0x82BD67u: goto L_82BD67;
    case 0x82BD6Au: goto L_82BD6A;
    case 0x82BD6Du: goto L_82BD6D;
    case 0x82BD70u: goto L_82BD70;
    case 0x82BD73u: goto L_82BD73;
    case 0x82BD76u: goto L_82BD76;
    case 0x82BD79u: goto L_82BD79;
    case 0x82BD7Cu: goto L_82BD7C;
    case 0x82BD7Fu: goto L_82BD7F;
    case 0x82BD82u: goto L_82BD82;
    case 0x82BD85u: goto L_82BD85;
    case 0x82BD88u: goto L_82BD88;
    case 0x82BD8Bu: goto L_82BD8B;
    case 0x82BD8Eu: goto L_82BD8E;
    case 0x82BD91u: goto L_82BD91;
    case 0x82BD94u: goto L_82BD94;
    case 0x82BD97u: goto L_82BD97;
    case 0x82BD9Au: goto L_82BD9A;
    case 0x82BD9Du: goto L_82BD9D;
    case 0x82BDA0u: goto L_82BDA0;
    case 0x82BDA3u: goto L_82BDA3;
    case 0x82BDA6u: goto L_82BDA6;
    case 0x82BDA9u: goto L_82BDA9;
    case 0x82BDACu: goto L_82BDAC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82BD2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD2Bu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD2Bu, 6u, 3u, cpu.address("absx", 0x0200u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD2B STZ
    hw.write(cpu.address("absx", 0x200u), 0, cpu.m8?8:16);
    goto L_82BD2E;
L_82BD2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD2Eu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD2Eu, 6u, 3u, cpu.address("absx", 0x02BCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD2E STZ
    hw.write(cpu.address("absx", 0x2BCu), 0, cpu.m8?8:16);
    goto L_82BD31;
L_82BD31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD31u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD31u, 6u, 3u, cpu.address("absx", 0x02BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD31 STZ
    hw.write(cpu.address("absx", 0x2BEu), 0, cpu.m8?8:16);
    goto L_82BD34;
L_82BD34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD34u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD34u, 6u, 3u, cpu.address("absx", 0x02C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD34 STZ
    hw.write(cpu.address("absx", 0x2C0u), 0, cpu.m8?8:16);
    goto L_82BD37;
L_82BD37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD37u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD37u, 6u, 3u, cpu.address("absx", 0x02C2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD37 STZ
    hw.write(cpu.address("absx", 0x2C2u), 0, cpu.m8?8:16);
    goto L_82BD3A;
L_82BD3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD3Au,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD3Au, 6u, 3u, cpu.address("absx", 0x02C4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD3A STZ
    hw.write(cpu.address("absx", 0x2C4u), 0, cpu.m8?8:16);
    goto L_82BD3D;
L_82BD3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD3Du,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD3Du, 6u, 3u, cpu.address("absx", 0x02C6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD3D STZ
    hw.write(cpu.address("absx", 0x2C6u), 0, cpu.m8?8:16);
    goto L_82BD40;
L_82BD40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD40u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD40u, 6u, 3u, cpu.address("absx", 0x02E8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD40 STZ
    hw.write(cpu.address("absx", 0x2E8u), 0, cpu.m8?8:16);
    goto L_82BD43;
L_82BD43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD43u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD43u, 6u, 3u, cpu.address("absx", 0x0420u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD43 STZ
    hw.write(cpu.address("absx", 0x420u), 0, cpu.m8?8:16);
    goto L_82BD46;
L_82BD46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD46u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD46u, 6u, 3u, cpu.address("absx", 0x02EAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD46 STZ
    hw.write(cpu.address("absx", 0x2EAu), 0, cpu.m8?8:16);
    goto L_82BD49;
L_82BD49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD49u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD49u, 6u, 3u, cpu.address("absx", 0x0422u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD49 STZ
    hw.write(cpu.address("absx", 0x422u), 0, cpu.m8?8:16);
    goto L_82BD4C;
L_82BD4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD4Cu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD4Cu, 6u, 3u, cpu.address("absx", 0x02ECu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD4C STZ
    hw.write(cpu.address("absx", 0x2ECu), 0, cpu.m8?8:16);
    goto L_82BD4F;
L_82BD4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD4Fu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD4Fu, 6u, 3u, cpu.address("absx", 0x02EEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD4F STZ
    hw.write(cpu.address("absx", 0x2EEu), 0, cpu.m8?8:16);
    goto L_82BD52;
L_82BD52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD52u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD52u, 6u, 3u, cpu.address("absx", 0x02F0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD52 STZ
    hw.write(cpu.address("absx", 0x2F0u), 0, cpu.m8?8:16);
    goto L_82BD55;
L_82BD55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD55u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD55u, 6u, 3u, cpu.address("absx", 0x02A0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD55 STZ
    hw.write(cpu.address("absx", 0x2A0u), 0, cpu.m8?8:16);
    goto L_82BD58;
L_82BD58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD58u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD58u, 6u, 3u, cpu.address("absx", 0x02E6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD58 STZ
    hw.write(cpu.address("absx", 0x2E6u), 0, cpu.m8?8:16);
    goto L_82BD5B;
L_82BD5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD5Bu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD5Bu, 6u, 3u, cpu.address("absx", 0x02E2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD5B STZ
    hw.write(cpu.address("absx", 0x2E2u), 0, cpu.m8?8:16);
    goto L_82BD5E;
L_82BD5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD5Eu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD5Eu, 6u, 3u, cpu.address("absx", 0x02E4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD5E STZ
    hw.write(cpu.address("absx", 0x2E4u), 0, cpu.m8?8:16);
    goto L_82BD61;
L_82BD61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD61u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD61u, 6u, 3u, cpu.address("absx", 0x0222u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD61 STZ
    hw.write(cpu.address("absx", 0x222u), 0, cpu.m8?8:16);
    goto L_82BD64;
L_82BD64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD64u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD64u, 6u, 3u, cpu.address("absx", 0x0400u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD64 STZ
    hw.write(cpu.address("absx", 0x400u), 0, cpu.m8?8:16);
    goto L_82BD67;
L_82BD67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD67u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD67u, 6u, 3u, cpu.address("absx", 0x0402u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD67 STZ
    hw.write(cpu.address("absx", 0x402u), 0, cpu.m8?8:16);
    goto L_82BD6A;
L_82BD6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD6Au,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD6Au, 6u, 3u, cpu.address("absx", 0x0404u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD6A STZ
    hw.write(cpu.address("absx", 0x404u), 0, cpu.m8?8:16);
    goto L_82BD6D;
L_82BD6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD6Du,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD6Du, 6u, 3u, cpu.address("absx", 0x0406u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD6D STZ
    hw.write(cpu.address("absx", 0x406u), 0, cpu.m8?8:16);
    goto L_82BD70;
L_82BD70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD70u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD70u, 6u, 3u, cpu.address("absx", 0x0408u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD70 STZ
    hw.write(cpu.address("absx", 0x408u), 0, cpu.m8?8:16);
    goto L_82BD73;
L_82BD73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD73u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD73u, 6u, 3u, cpu.address("absx", 0x040Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD73 STZ
    hw.write(cpu.address("absx", 0x40Au), 0, cpu.m8?8:16);
    goto L_82BD76;
L_82BD76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD76u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD76u, 6u, 3u, cpu.address("absx", 0x0416u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD76 STZ
    hw.write(cpu.address("absx", 0x416u), 0, cpu.m8?8:16);
    goto L_82BD79;
L_82BD79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD79u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD79u, 6u, 3u, cpu.address("absx", 0x0418u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD79 STZ
    hw.write(cpu.address("absx", 0x418u), 0, cpu.m8?8:16);
    goto L_82BD7C;
L_82BD7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD7Cu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD7Cu, 6u, 3u, cpu.address("absx", 0x041Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD7C STZ
    hw.write(cpu.address("absx", 0x41Au), 0, cpu.m8?8:16);
    goto L_82BD7F;
L_82BD7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD7Fu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD7Fu, 6u, 3u, cpu.address("absx", 0x041Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD7F STZ
    hw.write(cpu.address("absx", 0x41Cu), 0, cpu.m8?8:16);
    goto L_82BD82;
L_82BD82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD82u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD82u, 6u, 3u, cpu.address("absx", 0x0414u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD82 STZ
    hw.write(cpu.address("absx", 0x414u), 0, cpu.m8?8:16);
    goto L_82BD85;
L_82BD85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD85u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD85u, 6u, 3u, cpu.address("absx", 0x040Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD85 STZ
    hw.write(cpu.address("absx", 0x40Eu), 0, cpu.m8?8:16);
    goto L_82BD88;
L_82BD88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD88u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD88u, 6u, 3u, cpu.address("absx", 0x0410u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD88 STZ
    hw.write(cpu.address("absx", 0x410u), 0, cpu.m8?8:16);
    goto L_82BD8B;
L_82BD8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Bu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Bu, 6u, 3u, cpu.address("absx", 0x0412u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD8B STZ
    hw.write(cpu.address("absx", 0x412u), 0, cpu.m8?8:16);
    goto L_82BD8E;
L_82BD8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Eu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Eu, 6u, 3u, cpu.address("absx", 0x040Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD8E STZ
    hw.write(cpu.address("absx", 0x40Au), 0, cpu.m8?8:16);
    goto L_82BD91;
L_82BD91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD91u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD91u, 6u, 3u, cpu.address("absx", 0x0442u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD91 STZ
    hw.write(cpu.address("absx", 0x442u), 0, cpu.m8?8:16);
    goto L_82BD94;
L_82BD94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD94u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD94u, 6u, 3u, cpu.address("absx", 0x0444u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD94 STZ
    hw.write(cpu.address("absx", 0x444u), 0, cpu.m8?8:16);
    goto L_82BD97;
L_82BD97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD97u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD97u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD97 LDA
    cpu.setA(0xFFFFu, 16);
    goto L_82BD9A;
L_82BD9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD9Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD9Au, 6u, 3u, cpu.address("absx", 0x0208u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD9A STA
    hw.write(cpu.address("absx", 0x208u), cpu.a, cpu.m8?8:16);
    goto L_82BD9D;
L_82BD9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD9Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD9Du, 6u, 3u, cpu.address("absx", 0x020Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD9D STA
    hw.write(cpu.address("absx", 0x20Eu), cpu.a, cpu.m8?8:16);
    goto L_82BDA0;
L_82BDA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA0u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA0u, 6u, 3u, cpu.address("absx", 0x0214u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BDA0 STA
    hw.write(cpu.address("absx", 0x214u), cpu.a, cpu.m8?8:16);
    goto L_82BDA3;
L_82BDA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA3u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA3u, 6u, 3u, cpu.address("absx", 0x021Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BDA3 STA
    hw.write(cpu.address("absx", 0x21Au), cpu.a, cpu.m8?8:16);
    goto L_82BDA6;
L_82BDA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BDA6 LDA
    cpu.setA(0x8080u, 16);
    goto L_82BDA9;
L_82BDA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA9u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA9u, 6u, 3u, cpu.address("absx", 0x0220u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BDA9 STA
    hw.write(cpu.address("absx", 0x220u), cpu.a, cpu.m8?8:16);
    goto L_82BDAC;
L_82BDAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDACu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDACu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82BDAC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82BDACu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82BDACu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82BD2B_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82BD2Bu: goto L_82BD2B;
    case 0x82BD2Eu: goto L_82BD2E;
    case 0x82BD31u: goto L_82BD31;
    case 0x82BD34u: goto L_82BD34;
    case 0x82BD37u: goto L_82BD37;
    case 0x82BD3Au: goto L_82BD3A;
    case 0x82BD3Du: goto L_82BD3D;
    case 0x82BD40u: goto L_82BD40;
    case 0x82BD43u: goto L_82BD43;
    case 0x82BD46u: goto L_82BD46;
    case 0x82BD49u: goto L_82BD49;
    case 0x82BD4Cu: goto L_82BD4C;
    case 0x82BD4Fu: goto L_82BD4F;
    case 0x82BD52u: goto L_82BD52;
    case 0x82BD55u: goto L_82BD55;
    case 0x82BD58u: goto L_82BD58;
    case 0x82BD5Bu: goto L_82BD5B;
    case 0x82BD5Eu: goto L_82BD5E;
    case 0x82BD61u: goto L_82BD61;
    case 0x82BD64u: goto L_82BD64;
    case 0x82BD67u: goto L_82BD67;
    case 0x82BD6Au: goto L_82BD6A;
    case 0x82BD6Du: goto L_82BD6D;
    case 0x82BD70u: goto L_82BD70;
    case 0x82BD73u: goto L_82BD73;
    case 0x82BD76u: goto L_82BD76;
    case 0x82BD79u: goto L_82BD79;
    case 0x82BD7Cu: goto L_82BD7C;
    case 0x82BD7Fu: goto L_82BD7F;
    case 0x82BD82u: goto L_82BD82;
    case 0x82BD85u: goto L_82BD85;
    case 0x82BD88u: goto L_82BD88;
    case 0x82BD8Bu: goto L_82BD8B;
    case 0x82BD8Eu: goto L_82BD8E;
    case 0x82BD91u: goto L_82BD91;
    case 0x82BD94u: goto L_82BD94;
    case 0x82BD97u: goto L_82BD97;
    case 0x82BD9Au: goto L_82BD9A;
    case 0x82BD9Du: goto L_82BD9D;
    case 0x82BDA0u: goto L_82BDA0;
    case 0x82BDA3u: goto L_82BDA3;
    case 0x82BDA6u: goto L_82BDA6;
    case 0x82BDA9u: goto L_82BDA9;
    case 0x82BDACu: goto L_82BDAC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82BD2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD2Bu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD2Bu, 6u, 3u, cpu.address("absx", 0x0200u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD2B STZ
    hw.write(cpu.address("absx", 0x200u), 0, cpu.m8?8:16);
    goto L_82BD2E;
L_82BD2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD2Eu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD2Eu, 6u, 3u, cpu.address("absx", 0x02BCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD2E STZ
    hw.write(cpu.address("absx", 0x2BCu), 0, cpu.m8?8:16);
    goto L_82BD31;
L_82BD31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD31u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD31u, 6u, 3u, cpu.address("absx", 0x02BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD31 STZ
    hw.write(cpu.address("absx", 0x2BEu), 0, cpu.m8?8:16);
    goto L_82BD34;
L_82BD34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD34u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD34u, 6u, 3u, cpu.address("absx", 0x02C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD34 STZ
    hw.write(cpu.address("absx", 0x2C0u), 0, cpu.m8?8:16);
    goto L_82BD37;
L_82BD37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD37u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD37u, 6u, 3u, cpu.address("absx", 0x02C2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD37 STZ
    hw.write(cpu.address("absx", 0x2C2u), 0, cpu.m8?8:16);
    goto L_82BD3A;
L_82BD3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD3Au,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD3Au, 6u, 3u, cpu.address("absx", 0x02C4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD3A STZ
    hw.write(cpu.address("absx", 0x2C4u), 0, cpu.m8?8:16);
    goto L_82BD3D;
L_82BD3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD3Du,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD3Du, 6u, 3u, cpu.address("absx", 0x02C6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD3D STZ
    hw.write(cpu.address("absx", 0x2C6u), 0, cpu.m8?8:16);
    goto L_82BD40;
L_82BD40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD40u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD40u, 6u, 3u, cpu.address("absx", 0x02E8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD40 STZ
    hw.write(cpu.address("absx", 0x2E8u), 0, cpu.m8?8:16);
    goto L_82BD43;
L_82BD43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD43u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD43u, 6u, 3u, cpu.address("absx", 0x0420u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD43 STZ
    hw.write(cpu.address("absx", 0x420u), 0, cpu.m8?8:16);
    goto L_82BD46;
L_82BD46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD46u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD46u, 6u, 3u, cpu.address("absx", 0x02EAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD46 STZ
    hw.write(cpu.address("absx", 0x2EAu), 0, cpu.m8?8:16);
    goto L_82BD49;
L_82BD49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD49u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD49u, 6u, 3u, cpu.address("absx", 0x0422u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD49 STZ
    hw.write(cpu.address("absx", 0x422u), 0, cpu.m8?8:16);
    goto L_82BD4C;
L_82BD4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD4Cu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD4Cu, 6u, 3u, cpu.address("absx", 0x02ECu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD4C STZ
    hw.write(cpu.address("absx", 0x2ECu), 0, cpu.m8?8:16);
    goto L_82BD4F;
L_82BD4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD4Fu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD4Fu, 6u, 3u, cpu.address("absx", 0x02EEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD4F STZ
    hw.write(cpu.address("absx", 0x2EEu), 0, cpu.m8?8:16);
    goto L_82BD52;
L_82BD52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD52u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD52u, 6u, 3u, cpu.address("absx", 0x02F0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD52 STZ
    hw.write(cpu.address("absx", 0x2F0u), 0, cpu.m8?8:16);
    goto L_82BD55;
L_82BD55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD55u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD55u, 6u, 3u, cpu.address("absx", 0x02A0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD55 STZ
    hw.write(cpu.address("absx", 0x2A0u), 0, cpu.m8?8:16);
    goto L_82BD58;
L_82BD58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD58u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD58u, 6u, 3u, cpu.address("absx", 0x02E6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD58 STZ
    hw.write(cpu.address("absx", 0x2E6u), 0, cpu.m8?8:16);
    goto L_82BD5B;
L_82BD5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD5Bu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD5Bu, 6u, 3u, cpu.address("absx", 0x02E2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD5B STZ
    hw.write(cpu.address("absx", 0x2E2u), 0, cpu.m8?8:16);
    goto L_82BD5E;
L_82BD5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD5Eu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD5Eu, 6u, 3u, cpu.address("absx", 0x02E4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD5E STZ
    hw.write(cpu.address("absx", 0x2E4u), 0, cpu.m8?8:16);
    goto L_82BD61;
L_82BD61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD61u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD61u, 6u, 3u, cpu.address("absx", 0x0222u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD61 STZ
    hw.write(cpu.address("absx", 0x222u), 0, cpu.m8?8:16);
    goto L_82BD64;
L_82BD64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD64u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD64u, 6u, 3u, cpu.address("absx", 0x0400u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD64 STZ
    hw.write(cpu.address("absx", 0x400u), 0, cpu.m8?8:16);
    goto L_82BD67;
L_82BD67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD67u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD67u, 6u, 3u, cpu.address("absx", 0x0402u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD67 STZ
    hw.write(cpu.address("absx", 0x402u), 0, cpu.m8?8:16);
    goto L_82BD6A;
L_82BD6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD6Au,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD6Au, 6u, 3u, cpu.address("absx", 0x0404u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD6A STZ
    hw.write(cpu.address("absx", 0x404u), 0, cpu.m8?8:16);
    goto L_82BD6D;
L_82BD6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD6Du,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD6Du, 6u, 3u, cpu.address("absx", 0x0406u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD6D STZ
    hw.write(cpu.address("absx", 0x406u), 0, cpu.m8?8:16);
    goto L_82BD70;
L_82BD70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD70u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD70u, 6u, 3u, cpu.address("absx", 0x0408u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD70 STZ
    hw.write(cpu.address("absx", 0x408u), 0, cpu.m8?8:16);
    goto L_82BD73;
L_82BD73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD73u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD73u, 6u, 3u, cpu.address("absx", 0x040Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD73 STZ
    hw.write(cpu.address("absx", 0x40Au), 0, cpu.m8?8:16);
    goto L_82BD76;
L_82BD76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD76u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD76u, 6u, 3u, cpu.address("absx", 0x0416u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD76 STZ
    hw.write(cpu.address("absx", 0x416u), 0, cpu.m8?8:16);
    goto L_82BD79;
L_82BD79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD79u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD79u, 6u, 3u, cpu.address("absx", 0x0418u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD79 STZ
    hw.write(cpu.address("absx", 0x418u), 0, cpu.m8?8:16);
    goto L_82BD7C;
L_82BD7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD7Cu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD7Cu, 6u, 3u, cpu.address("absx", 0x041Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD7C STZ
    hw.write(cpu.address("absx", 0x41Au), 0, cpu.m8?8:16);
    goto L_82BD7F;
L_82BD7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD7Fu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD7Fu, 6u, 3u, cpu.address("absx", 0x041Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD7F STZ
    hw.write(cpu.address("absx", 0x41Cu), 0, cpu.m8?8:16);
    goto L_82BD82;
L_82BD82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD82u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD82u, 6u, 3u, cpu.address("absx", 0x0414u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD82 STZ
    hw.write(cpu.address("absx", 0x414u), 0, cpu.m8?8:16);
    goto L_82BD85;
L_82BD85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD85u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD85u, 6u, 3u, cpu.address("absx", 0x040Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD85 STZ
    hw.write(cpu.address("absx", 0x40Eu), 0, cpu.m8?8:16);
    goto L_82BD88;
L_82BD88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD88u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD88u, 6u, 3u, cpu.address("absx", 0x0410u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD88 STZ
    hw.write(cpu.address("absx", 0x410u), 0, cpu.m8?8:16);
    goto L_82BD8B;
L_82BD8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Bu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Bu, 6u, 3u, cpu.address("absx", 0x0412u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD8B STZ
    hw.write(cpu.address("absx", 0x412u), 0, cpu.m8?8:16);
    goto L_82BD8E;
L_82BD8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Eu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD8Eu, 6u, 3u, cpu.address("absx", 0x040Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD8E STZ
    hw.write(cpu.address("absx", 0x40Au), 0, cpu.m8?8:16);
    goto L_82BD91;
L_82BD91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD91u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD91u, 6u, 3u, cpu.address("absx", 0x0442u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD91 STZ
    hw.write(cpu.address("absx", 0x442u), 0, cpu.m8?8:16);
    goto L_82BD94;
L_82BD94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD94u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD94u, 6u, 3u, cpu.address("absx", 0x0444u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD94 STZ
    hw.write(cpu.address("absx", 0x444u), 0, cpu.m8?8:16);
    goto L_82BD97;
L_82BD97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD97u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD97u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD97 LDA
    cpu.setA(0xFFFFu, 16);
    goto L_82BD9A;
L_82BD9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD9Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD9Au, 6u, 3u, cpu.address("absx", 0x0208u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD9A STA
    hw.write(cpu.address("absx", 0x208u), cpu.a, cpu.m8?8:16);
    goto L_82BD9D;
L_82BD9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD9Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD9Du, 6u, 3u, cpu.address("absx", 0x020Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BD9D STA
    hw.write(cpu.address("absx", 0x20Eu), cpu.a, cpu.m8?8:16);
    goto L_82BDA0;
L_82BDA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA0u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA0u, 6u, 3u, cpu.address("absx", 0x0214u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BDA0 STA
    hw.write(cpu.address("absx", 0x214u), cpu.a, cpu.m8?8:16);
    goto L_82BDA3;
L_82BDA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA3u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA3u, 6u, 3u, cpu.address("absx", 0x021Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BDA3 STA
    hw.write(cpu.address("absx", 0x21Au), cpu.a, cpu.m8?8:16);
    goto L_82BDA6;
L_82BDA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BDA6 LDA
    cpu.setA(0x8080u, 16);
    goto L_82BDA9;
L_82BDA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA9u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDA9u, 6u, 3u, cpu.address("absx", 0x0220u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BDA9 STA
    hw.write(cpu.address("absx", 0x220u), cpu.a, cpu.m8?8:16);
    goto L_82BDAC;
L_82BDAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDACu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDACu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82BDAC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82BDACu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82BDACu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82BDAD_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82BDADu: goto L_82BDAD;
    case 0x82BDB0u: goto L_82BDB0;
    case 0x82BDB3u: goto L_82BDB3;
    case 0x82BDB6u: goto L_82BDB6;
    case 0x82BDB9u: goto L_82BDB9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82BDAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDADu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDADu, 5u, 3u, cpu.address("abs", 0x0139u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BDAD STZ
    hw.write(cpu.address("abs", 0x139u), 0, cpu.m8?8:16);
    goto L_82BDB0;
L_82BDB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB0u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB0u, 5u, 3u, cpu.address("abs", 0x0177u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BDB0 STZ
    hw.write(cpu.address("abs", 0x177u), 0, cpu.m8?8:16);
    goto L_82BDB3;
L_82BDB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB3u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB3u, 5u, 3u, cpu.address("abs", 0x013Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BDB3 STZ
    hw.write(cpu.address("abs", 0x13Bu), 0, cpu.m8?8:16);
    goto L_82BDB6;
L_82BDB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB6u, 5u, 3u, cpu.address("abs", 0x013Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BDB6 STA
    hw.write(cpu.address("abs", 0x13Du), cpu.a, cpu.m8?8:16);
    goto L_82BDB9;
L_82BDB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBDB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBDB9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82BDB9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82BDB9u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82BDB9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82C622_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82C622u: goto L_82C622;
    case 0x82C625u: goto L_82C625;
    case 0x82C628u: goto L_82C628;
    case 0x82C62Cu: goto L_82C62C;
    case 0x82C62Du: goto L_82C62D;
    case 0x82C62Eu: goto L_82C62E;
    case 0x82C630u: goto L_82C630;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82C622:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC622u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC622u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC622u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C622 LDX
    cpu.setX(0x1F8u, 16);
    goto L_82C625;
L_82C625:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC625u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC625u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC625u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C625 LDA
    cpu.setA(0x0u, 16);
    goto L_82C628;
L_82C628:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC628u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC628u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC628u, 6u, 4u, ((0x7E2220u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C628 STA
    hw.write(((0x7E2220u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82C62C;
L_82C62C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC62Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC62Cu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC62Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C62C DEX
    cpu.decReg('X');
    goto L_82C62D;
L_82C62D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC62Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC62Du,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC62Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C62D DEX
    cpu.decReg('X');
    goto L_82C62E;
L_82C62E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC62Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC62Eu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC62Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C62E BPL -> $82C628
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82C628; }
    goto L_82C630;
L_82C630:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC630u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC630u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC630u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C630 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C630u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C630u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8486AC_E0M1X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8486ACu: goto L_8486AC;
    case 0x8486AEu: goto L_8486AE;
    case 0x8486B1u: goto L_8486B1;
    case 0x8486B3u: goto L_8486B3;
    case 0x8486B5u: goto L_8486B5;
    case 0x8486B7u: goto L_8486B7;
    case 0x8486B9u: goto L_8486B9;
    case 0x8486BCu: goto L_8486BC;
    case 0x8486BEu: goto L_8486BE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8486AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86ACu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86ACu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486AC SEP
    cpu.sep(0x20u);
    goto L_8486AE;
L_8486AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86AEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86AEu, 4u, 3u, cpu.address("abs", 0x062Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486AE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8486B1;
L_8486B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486B1 BNE -> $8486B7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8486B7; }
    goto L_8486B3;
L_8486B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486B3 LDA
    cpu.setA(0x86u, 8);
    goto L_8486B5;
L_8486B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B5u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486B5 BRA -> $8486B9
    goto L_8486B9;
L_8486B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486B7 LDA
    cpu.setA(0x87u, 8);
    goto L_8486B9;
L_8486B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B9u, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486B9 STA
    hw.write(cpu.address("abs", 0x2140u), cpu.a, cpu.m8?8:16);
    goto L_8486BC;
L_8486BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BCu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486BC REP
    cpu.rep(0x20u);
    goto L_8486BE;
L_8486BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8486BE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8486BEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8486BEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8486AC_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8486ACu: goto L_8486AC;
    case 0x8486AEu: goto L_8486AE;
    case 0x8486B1u: goto L_8486B1;
    case 0x8486B3u: goto L_8486B3;
    case 0x8486B5u: goto L_8486B5;
    case 0x8486B7u: goto L_8486B7;
    case 0x8486B9u: goto L_8486B9;
    case 0x8486BCu: goto L_8486BC;
    case 0x8486BEu: goto L_8486BE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8486AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86ACu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86ACu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486AC SEP
    cpu.sep(0x20u);
    goto L_8486AE;
L_8486AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86AEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86AEu, 4u, 3u, cpu.address("abs", 0x062Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486AE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8486B1;
L_8486B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486B1 BNE -> $8486B7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8486B7; }
    goto L_8486B3;
L_8486B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486B3 LDA
    cpu.setA(0x86u, 8);
    goto L_8486B5;
L_8486B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B5u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486B5 BRA -> $8486B9
    goto L_8486B9;
L_8486B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486B7 LDA
    cpu.setA(0x87u, 8);
    goto L_8486B9;
L_8486B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B9u, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486B9 STA
    hw.write(cpu.address("abs", 0x2140u), cpu.a, cpu.m8?8:16);
    goto L_8486BC;
L_8486BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BCu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486BC REP
    cpu.rep(0x20u);
    goto L_8486BE;
L_8486BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8486BE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8486BEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8486BEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8486C3_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8486C3u: goto L_8486C3;
    case 0x8486C5u: goto L_8486C5;
    case 0x8486C8u: goto L_8486C8;
    case 0x8486CAu: goto L_8486CA;
    case 0x8486CBu: goto L_8486CB;
    case 0x8486CEu: goto L_8486CE;
    case 0x8486D0u: goto L_8486D0;
    case 0x8486D1u: goto L_8486D1;
    case 0x8486D2u: goto L_8486D2;
    case 0x8486D4u: goto L_8486D4;
    case 0x8486D5u: goto L_8486D5;
    case 0x8486D7u: goto L_8486D7;
    case 0x8486DAu: goto L_8486DA;
    case 0x8486DCu: goto L_8486DC;
    case 0x8486DEu: goto L_8486DE;
    case 0x8486E1u: goto L_8486E1;
    case 0x8486E4u: goto L_8486E4;
    case 0x8486E6u: goto L_8486E6;
    case 0x8486E8u: goto L_8486E8;
    case 0x8486EAu: goto L_8486EA;
    case 0x8486EBu: goto L_8486EB;
    case 0x8486EDu: goto L_8486ED;
    case 0x8486F1u: goto L_8486F1;
    case 0x8486F3u: goto L_8486F3;
    case 0x8486F6u: goto L_8486F6;
    case 0x8486F9u: goto L_8486F9;
    case 0x8486FCu: goto L_8486FC;
    case 0x8486FFu: goto L_8486FF;
    case 0x848703u: goto L_848703;
    case 0x848704u: goto L_848704;
    case 0x848707u: goto L_848707;
    case 0x84870Au: goto L_84870A;
    case 0x84870Cu: goto L_84870C;
    case 0x84870Du: goto L_84870D;
    case 0x848710u: goto L_848710;
    case 0x848711u: goto L_848711;
    case 0x848712u: goto L_848712;
    case 0x848714u: goto L_848714;
    case 0x848718u: goto L_848718;
    case 0x84871Bu: goto L_84871B;
    case 0x84871Eu: goto L_84871E;
    case 0x848722u: goto L_848722;
    case 0x848724u: goto L_848724;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8486C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C3u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486C3 SEP
    cpu.sep(0x20u);
    goto L_8486C5;
L_8486C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C5u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C5u, 4u, 3u, cpu.address("abs", 0x062Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486C5 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8486C8;
L_8486C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486C8 AND
    cpu.logicAnd(0x1u);
    goto L_8486CA;
L_8486CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86CAu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86CAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486CA TAX
    cpu.transfer("TAX");
    goto L_8486CB;
L_8486CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86CBu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86CBu, 4u, 3u, cpu.address("abs", 0x062Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486CB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8486CE;
L_8486CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86CEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86CEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486CE BEQ -> $8486D7
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8486D7; }
    goto L_8486D0;
L_8486D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D0u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486D0 TXA
    cpu.transfer("TXA");
    goto L_8486D1;
L_8486D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D1u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486D1 CLC
    cpu.setFlag('C', false);
    goto L_8486D2;
L_8486D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D2u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486D2 ADC
    cpu.adc(0x2u);
    goto L_8486D4;
L_8486D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D4u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486D4 TAX
    cpu.transfer("TAX");
    goto L_8486D5;
L_8486D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D5u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486D5 BRA -> $848712
    goto L_848712;
L_8486D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D7u, 4u, 3u, cpu.address("abs", 0x062Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486D7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8486DA;
L_8486DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86DAu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86DAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486DA BIT
    cpu.bit(0x1u, true);
    goto L_8486DC;
L_8486DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86DCu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86DCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486DC BEQ -> $848712
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848712; }
    goto L_8486DE;
L_8486DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86DEu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86DEu, 6u, 3u, cpu.address("abs", 0x062Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486DE INC
    cpu.incMem(hw, cpu.address("abs", 0x62Fu), cpu.m8?8:16);
    goto L_8486E1;
L_8486E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E1u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E1u, 4u, 3u, cpu.address("abs", 0x062Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486E1 STZ
    hw.write(cpu.address("abs", 0x62Au), 0, cpu.m8?8:16);
    goto L_8486E4;
L_8486E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E4u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486E4 STZ
    hw.write(cpu.address("dp", 0x49u), 0, cpu.m8?8:16);
    goto L_8486E6;
L_8486E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E6u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486E6 SEP
    cpu.sep(0x20u);
    goto L_8486E8;
L_8486E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486E8 LDA
    cpu.setA(0xC1u, 8);
    goto L_8486EA;
L_8486EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86EAu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86EAu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486EA XBA
    cpu.xba();
    goto L_8486EB;
L_8486EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86EBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86EBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486EB LDA
    cpu.setA(0xF5u, 8);
    goto L_8486ED;
L_8486ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86EDu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86EDu, 8u, 4u, 0x808700u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8486ED JSL -> $808700 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x86F0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x86F1u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808700u, 0x8486EDu); }
    goto L_8486F1;
L_8486F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F1u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86F1u,0x8486F1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F1u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486F1 REP
    cpu.rep(0x20u);
    goto L_8486F3;
L_8486F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486F3 LDA
    cpu.setA(0xEE68u, 16);
    goto L_8486F6;
L_8486F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F6u, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486F6 STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_8486F9;
L_8486F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486F9 LDA
    cpu.setA(0x8Au, 16);
    goto L_8486FC;
L_8486FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86FCu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86FCu, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486FC STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_8486FF;
L_8486FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86FFu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86FFu, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8486FF JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8702u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8703u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x8486FFu); }
    goto L_848703;
L_848703:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8703u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8703u,0x848703u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8703u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8703u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $848703 PHB
    cpu.push("PHB", hw);
    goto L_848704;
L_848704:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8704u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8704u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8704u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848704 LDX
    cpu.setX(0x8000u, 16);
    goto L_848707;
L_848707:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8707u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8707u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8707u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848707 LDY
    cpu.setY(0x2800u, 16);
    goto L_84870A;
L_84870A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x870Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x870Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x870Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84870A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84870C;
L_84870C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x870Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x870Cu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x870Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84870C DEC
    cpu.decReg('A');
    goto L_84870D;
L_84870D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x870Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x870Du,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0x870Du, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $84870D MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_848710;
L_848710:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8710u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8710u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8710u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $848710 PLB
    cpu.pop("PLB", hw);
    goto L_848711;
L_848711:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8711u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8711u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8711u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848711 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848711u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848711u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_848712:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8712u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8712u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8712u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848712 SEP
    cpu.sep(0x20u);
    goto L_848714;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8712u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8712u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848712 SEP
    cpu.sep(0x20u);
    goto L_848714;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8712u,0x848712u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848714:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8714u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8714u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8714u, 5u, 4u, ((0x848729u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848714 LDA
    cpu.loadA(hw.readW(((0x848729u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848718;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8714u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8714u, 5u, 4u, ((0x848729u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848714 LDA
    cpu.loadA(hw.readW(((0x848729u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848718;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8714u,0x848714u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848718:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8718u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8718u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8718u, 4u, 3u, cpu.address("abs", 0x0135u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848718 STA
    hw.write(cpu.address("abs", 0x135u), cpu.a, cpu.m8?8:16);
    goto L_84871B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8718u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8718u, 4u, 3u, cpu.address("abs", 0x0135u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848718 STA
    hw.write(cpu.address("abs", 0x135u), cpu.a, cpu.m8?8:16);
    goto L_84871B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8718u,0x848718u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84871B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x871Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x871Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x871Bu, 4u, 3u, cpu.address("abs", 0x0136u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84871B STZ
    hw.write(cpu.address("abs", 0x136u), 0, cpu.m8?8:16);
    goto L_84871E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x871Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x871Bu, 4u, 3u, cpu.address("abs", 0x0136u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84871B STZ
    hw.write(cpu.address("abs", 0x136u), 0, cpu.m8?8:16);
    goto L_84871E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x871Bu,0x84871Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84871E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x871Eu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x871Eu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x871Eu, 5u, 4u, ((0x848725u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84871E LDA
    cpu.loadA(hw.readW(((0x848725u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848722;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x871Eu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x871Eu, 5u, 4u, ((0x848725u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84871E LDA
    cpu.loadA(hw.readW(((0x848725u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848722;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x871Eu,0x84871Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848722:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8722u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8722u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8722u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848722 STA
    hw.write(cpu.address("dp", 0x46u), cpu.a, cpu.m8?8:16);
    goto L_848724;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8722u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8722u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848722 STA
    hw.write(cpu.address("dp", 0x46u), cpu.a, cpu.m8?8:16);
    goto L_848724;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8722u,0x848722u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_848724:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8724u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8724u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8724u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848724 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848724u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848724u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8724u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8724u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848724 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848724u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848724u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8724u,0x848724u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_84872D_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84872Du: goto L_84872D;
    case 0x84872Fu: goto L_84872F;
    case 0x848732u: goto L_848732;
    case 0x848734u: goto L_848734;
    case 0x848735u: goto L_848735;
    case 0x848739u: goto L_848739;
    case 0x84873Cu: goto L_84873C;
    case 0x84873Fu: goto L_84873F;
    case 0x848743u: goto L_848743;
    case 0x848745u: goto L_848745;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84872D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x872Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x872Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x872Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84872D SEP
    cpu.sep(0x20u);
    goto L_84872F;
L_84872F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x872Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x872Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x872Fu, 4u, 3u, cpu.address("abs", 0x062Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84872F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848732;
L_848732:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8732u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8732u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8732u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848732 AND
    cpu.logicAnd(0x1u);
    goto L_848734;
L_848734:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8734u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8734u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8734u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848734 TAX
    cpu.transfer("TAX");
    goto L_848735;
L_848735:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8735u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8735u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8735u, 5u, 4u, ((0x848748u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848735 LDA
    cpu.loadA(hw.readW(((0x848748u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848739;
L_848739:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8739u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8739u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8739u, 4u, 3u, cpu.address("abs", 0x0135u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848739 STA
    hw.write(cpu.address("abs", 0x135u), cpu.a, cpu.m8?8:16);
    goto L_84873C;
L_84873C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x873Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x873Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x873Cu, 4u, 3u, cpu.address("abs", 0x0136u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84873C STZ
    hw.write(cpu.address("abs", 0x136u), 0, cpu.m8?8:16);
    goto L_84873F;
L_84873F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x873Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x873Fu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x873Fu, 5u, 4u, ((0x848746u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84873F LDA
    cpu.loadA(hw.readW(((0x848746u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848743;
L_848743:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8743u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8743u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8743u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848743 STA
    hw.write(cpu.address("dp", 0x46u), cpu.a, cpu.m8?8:16);
    goto L_848745;
L_848745:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8745u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8745u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8745u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848745 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848745u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848745u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84872D_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84872Du: goto L_84872D;
    case 0x84872Fu: goto L_84872F;
    case 0x848732u: goto L_848732;
    case 0x848734u: goto L_848734;
    case 0x848735u: goto L_848735;
    case 0x848739u: goto L_848739;
    case 0x84873Cu: goto L_84873C;
    case 0x84873Fu: goto L_84873F;
    case 0x848743u: goto L_848743;
    case 0x848745u: goto L_848745;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84872D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x872Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x872Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x872Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84872D SEP
    cpu.sep(0x20u);
    goto L_84872F;
L_84872F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x872Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x872Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x872Fu, 4u, 3u, cpu.address("abs", 0x062Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84872F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848732;
L_848732:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8732u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8732u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8732u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848732 AND
    cpu.logicAnd(0x1u);
    goto L_848734;
L_848734:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8734u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8734u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8734u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848734 TAX
    cpu.transfer("TAX");
    goto L_848735;
L_848735:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8735u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8735u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8735u, 5u, 4u, ((0x848748u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848735 LDA
    cpu.loadA(hw.readW(((0x848748u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848739;
L_848739:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8739u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8739u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8739u, 4u, 3u, cpu.address("abs", 0x0135u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848739 STA
    hw.write(cpu.address("abs", 0x135u), cpu.a, cpu.m8?8:16);
    goto L_84873C;
L_84873C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x873Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x873Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x873Cu, 4u, 3u, cpu.address("abs", 0x0136u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84873C STZ
    hw.write(cpu.address("abs", 0x136u), 0, cpu.m8?8:16);
    goto L_84873F;
L_84873F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x873Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x873Fu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x873Fu, 5u, 4u, ((0x848746u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84873F LDA
    cpu.loadA(hw.readW(((0x848746u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848743;
L_848743:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8743u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8743u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8743u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848743 STA
    hw.write(cpu.address("dp", 0x46u), cpu.a, cpu.m8?8:16);
    goto L_848745;
L_848745:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8745u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8745u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8745u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848745 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848745u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848745u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_849010_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849010u: goto L_849010;
    case 0x849012u: goto L_849012;
    case 0x849015u: goto L_849015;
    case 0x849018u: goto L_849018;
    case 0x849019u: goto L_849019;
    case 0x84901Bu: goto L_84901B;
    case 0x84901Fu: goto L_84901F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849010:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9010u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9010u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9010u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849010 REP
    cpu.rep(0x20u);
    goto L_849012;
L_849012:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9012u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9012u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9012u, 5u, 3u, cpu.address("abs", 0x062Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849012 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849015;
L_849015:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9015u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9015u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9015u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849015 AND
    cpu.logicAnd(0x1u);
    goto L_849018;
L_849018:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9018u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9018u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9018u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849018 TAX
    cpu.transfer("TAX");
    goto L_849019;
L_849019:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9019u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9019u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9019u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849019 SEP
    cpu.sep(0x20u);
    goto L_84901B;
L_84901B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x901Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x901Bu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x901Bu, 5u, 4u, ((0x849020u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84901B LDA
    cpu.loadA(hw.readW(((0x849020u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84901F;
L_84901F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x901Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x901Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x901Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84901F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84901Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84901Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_849010_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849010u: goto L_849010;
    case 0x849012u: goto L_849012;
    case 0x849015u: goto L_849015;
    case 0x849018u: goto L_849018;
    case 0x849019u: goto L_849019;
    case 0x84901Bu: goto L_84901B;
    case 0x84901Fu: goto L_84901F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849010:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9010u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9010u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9010u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849010 REP
    cpu.rep(0x20u);
    goto L_849012;
L_849012:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9012u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9012u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9012u, 5u, 3u, cpu.address("abs", 0x062Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849012 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849015;
L_849015:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9015u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9015u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9015u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849015 AND
    cpu.logicAnd(0x1u);
    goto L_849018;
L_849018:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9018u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9018u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9018u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849018 TAX
    cpu.transfer("TAX");
    goto L_849019;
L_849019:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9019u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9019u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9019u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849019 SEP
    cpu.sep(0x20u);
    goto L_84901B;
L_84901B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x901Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x901Bu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x901Bu, 5u, 4u, ((0x849020u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84901B LDA
    cpu.loadA(hw.readW(((0x849020u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84901F;
L_84901F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x901Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x901Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x901Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84901F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84901Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84901Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_849957_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849957u: goto L_849957;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849957:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9957u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9957u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9957u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849957 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849957u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849957u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_849957_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849957u: goto L_849957;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849957:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9957u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9957u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9957u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849957 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849957u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849957u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_849A4C_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849A4Cu: goto L_849A4C;
    case 0x849A4Eu: goto L_849A4E;
    case 0x849A51u: goto L_849A51;
    case 0x849A53u: goto L_849A53;
    case 0x849A56u: goto L_849A56;
    case 0x849A58u: goto L_849A58;
    case 0x849A5Au: goto L_849A5A;
    case 0x849A5Du: goto L_849A5D;
    case 0x849A5Eu: goto L_849A5E;
    case 0x849A5Fu: goto L_849A5F;
    case 0x849A62u: goto L_849A62;
    case 0x849A65u: goto L_849A65;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849A4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A4Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A4Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A4C REP
    cpu.rep(0x20u);
    goto L_849A4E;
L_849A4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A4Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A4Eu, 5u, 3u, cpu.address("abs", 0x06F7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A4E STZ
    hw.write(cpu.address("abs", 0x6F7u), 0, cpu.m8?8:16);
    goto L_849A51;
L_849A51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A51u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A51u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A51 SEP
    cpu.sep(0x20u);
    goto L_849A53;
L_849A53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A53u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A53u, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A53 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849A56;
L_849A56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A56u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A56u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A56 AND
    cpu.logicAnd(0x1u);
    goto L_849A58;
L_849A58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A58u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A58u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A58 REP
    cpu.rep(0x20u);
    goto L_849A5A;
L_849A5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A5Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A5Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A5A AND
    cpu.logicAnd(0xFFu);
    goto L_849A5D;
L_849A5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A5Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A5Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A5D ASL
    cpu.aslA();
    goto L_849A5E;
L_849A5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A5Eu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A5Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A5E TAX
    cpu.transfer("TAX");
    goto L_849A5F;
L_849A5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A5Fu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A5Fu, 5u, 3u, cpu.address("abs", 0x9A64u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849A5F PEA
    cpu.push16Value(hw, 0x9A64u);
    goto L_849A62;
L_849A62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A62u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A62u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x9A66u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $849A62 JMP (9A66,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x9A66u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x849A62u); return; }
L_849A65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A65u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9A65u,0x849A65u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A65u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A65u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849A65 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849A65u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849A65u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_849A4C_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849A4Cu: goto L_849A4C;
    case 0x849A4Eu: goto L_849A4E;
    case 0x849A51u: goto L_849A51;
    case 0x849A53u: goto L_849A53;
    case 0x849A56u: goto L_849A56;
    case 0x849A58u: goto L_849A58;
    case 0x849A5Au: goto L_849A5A;
    case 0x849A5Du: goto L_849A5D;
    case 0x849A5Eu: goto L_849A5E;
    case 0x849A5Fu: goto L_849A5F;
    case 0x849A62u: goto L_849A62;
    case 0x849A65u: goto L_849A65;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849A4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A4Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A4Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A4C REP
    cpu.rep(0x20u);
    goto L_849A4E;
L_849A4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A4Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A4Eu, 5u, 3u, cpu.address("abs", 0x06F7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A4E STZ
    hw.write(cpu.address("abs", 0x6F7u), 0, cpu.m8?8:16);
    goto L_849A51;
L_849A51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A51u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A51u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A51 SEP
    cpu.sep(0x20u);
    goto L_849A53;
L_849A53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A53u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A53u, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A53 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849A56;
L_849A56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A56u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A56u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A56 AND
    cpu.logicAnd(0x1u);
    goto L_849A58;
L_849A58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A58u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A58u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A58 REP
    cpu.rep(0x20u);
    goto L_849A5A;
L_849A5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A5Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A5Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A5A AND
    cpu.logicAnd(0xFFu);
    goto L_849A5D;
L_849A5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A5Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A5Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A5D ASL
    cpu.aslA();
    goto L_849A5E;
L_849A5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A5Eu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A5Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A5E TAX
    cpu.transfer("TAX");
    goto L_849A5F;
L_849A5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A5Fu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A5Fu, 5u, 3u, cpu.address("abs", 0x9A64u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849A5F PEA
    cpu.push16Value(hw, 0x9A64u);
    goto L_849A62;
L_849A62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A62u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A62u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x9A66u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $849A62 JMP (9A66,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x9A66u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x849A62u); return; }
L_849A65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A65u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9A65u,0x849A65u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A65u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A65u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849A65 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849A65u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849A65u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_849BC6_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849BC6u: goto L_849BC6;
    case 0x849BC8u: goto L_849BC8;
    case 0x849BCBu: goto L_849BCB;
    case 0x849BCEu: goto L_849BCE;
    case 0x849BCFu: goto L_849BCF;
    case 0x849BD0u: goto L_849BD0;
    case 0x849BDEu: goto L_849BDE;
    case 0x849BE0u: goto L_849BE0;
    case 0x849BE3u: goto L_849BE3;
    case 0x849BE5u: goto L_849BE5;
    case 0x849BE8u: goto L_849BE8;
    case 0x849BEAu: goto L_849BEA;
    case 0x849BECu: goto L_849BEC;
    case 0x849BEFu: goto L_849BEF;
    case 0x849BF1u: goto L_849BF1;
    case 0x849BF4u: goto L_849BF4;
    case 0x849BF6u: goto L_849BF6;
    case 0x849BF9u: goto L_849BF9;
    case 0x849BFCu: goto L_849BFC;
    case 0x849BFFu: goto L_849BFF;
    case 0x849C01u: goto L_849C01;
    case 0x849C04u: goto L_849C04;
    case 0x849C07u: goto L_849C07;
    case 0x849C09u: goto L_849C09;
    case 0x849C0Cu: goto L_849C0C;
    case 0x849C0Du: goto L_849C0D;
    case 0x849C0Fu: goto L_849C0F;
    case 0x849C12u: goto L_849C12;
    case 0x849C14u: goto L_849C14;
    case 0x849C16u: goto L_849C16;
    case 0x849C1Au: goto L_849C1A;
    case 0x849C1Cu: goto L_849C1C;
    case 0x849C1Eu: goto L_849C1E;
    case 0x849C22u: goto L_849C22;
    case 0x849C24u: goto L_849C24;
    case 0x849C28u: goto L_849C28;
    case 0x849C2Cu: goto L_849C2C;
    case 0x849C30u: goto L_849C30;
    case 0x849C32u: goto L_849C32;
    case 0x849C36u: goto L_849C36;
    case 0x849C38u: goto L_849C38;
    case 0x849C3Au: goto L_849C3A;
    case 0x849C3Du: goto L_849C3D;
    case 0x849C41u: goto L_849C41;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849BC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BC6u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BC6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BC6 REP
    cpu.rep(0x20u);
    goto L_849BC8;
L_849BC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BC8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BC8u, 5u, 3u, cpu.address("abs", 0x062Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BC8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849BCB;
L_849BCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BCBu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BCBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BCB AND
    cpu.logicAnd(0x1u);
    goto L_849BCE;
L_849BCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BCEu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BCEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BCE ASL
    cpu.aslA();
    goto L_849BCF;
L_849BCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BCFu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BCFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BCF TAX
    cpu.transfer("TAX");
    goto L_849BD0;
L_849BD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BD0u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BD0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BD0 BRA -> $849BDE
    goto L_849BDE;
L_849BDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BDEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BDEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BDE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849BE0;
L_849BE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BE0u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BE0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BE0 BIT
    cpu.bit(0x200u, true);
    goto L_849BE3;
L_849BE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BE3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BE3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BE3 BNE -> $849BEC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_849BEC; }
    goto L_849BE5;
L_849BE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BE5u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BE5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BE5 BIT
    cpu.bit(0x100u, true);
    goto L_849BE8;
L_849BE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BE8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BE8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BE8 BNE -> $849BF6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_849BF6; }
    goto L_849BEA;
L_849BEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BEAu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BEAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BEA BRA -> $849C41
    goto L_849C41;
L_849BEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BECu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BECu, 9u, 3u, cpu.address("absx", 0x064Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BEC DEC
    cpu.decMem(hw, cpu.address("absx", 0x64Bu), cpu.m8?8:16);
    goto L_849BEF;
L_849BEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BEFu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BEFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BEF BPL -> $849C09
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_849C09; }
    goto L_849BF1;
L_849BF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF1u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF1u, 6u, 3u, cpu.address("absx", 0x064Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BF1 STZ
    hw.write(cpu.address("absx", 0x64Bu), 0, cpu.m8?8:16);
    goto L_849BF4;
L_849BF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF4u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BF4 BRA -> $849C41
    goto L_849C41;
L_849BF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF6u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF6u, 9u, 3u, cpu.address("absx", 0x064Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BF6 INC
    cpu.incMem(hw, cpu.address("absx", 0x64Bu), cpu.m8?8:16);
    goto L_849BF9;
L_849BF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BF9u, 5u + 1u, 3u, cpu.address("absx", 0x064Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BF9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x64Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849BFC;
L_849BFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFCu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BFC CMP
    cpu.compareA(0x5u);
    goto L_849BFF;
L_849BFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFFu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BFFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849BFF BCC -> $849C09
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_849C09; }
    goto L_849C01;
L_849C01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C01u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C01u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C01 LDA
    cpu.setA(0x4u, 16);
    goto L_849C04;
L_849C04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C04u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C04u, 6u, 3u, cpu.address("absx", 0x064Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C04 STA
    hw.write(cpu.address("absx", 0x64Bu), cpu.a, cpu.m8?8:16);
    goto L_849C07;
L_849C07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C07u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C07u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C07 BRA -> $849C41
    goto L_849C41;
L_849C09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C09u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C09u, 5u + 1u, 3u, cpu.address("absx", 0x064Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C09 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x64Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849C0C;
L_849C0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Cu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C0C TAX
    cpu.transfer("TAX");
    goto L_849C0D;
L_849C0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C0D SEP
    cpu.sep(0x20u);
    goto L_849C0F;
L_849C0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Fu, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C0F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849C12;
L_849C12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C12u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C12u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C12 BIT
    cpu.bit(0x1u, true);
    goto L_849C14;
L_849C14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C14u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C14u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C14 BNE -> $849C1C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_849C1C; }
    goto L_849C16;
L_849C16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C16u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C16u, 5u, 4u, ((0x9E9564u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C16 LDA
    cpu.loadA(hw.readW(((0x9E9564u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849C1A;
L_849C1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Au,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C1A BRA -> $849C22
    goto L_849C22;
L_849C1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C1C SEP
    cpu.sep(0x20u);
    goto L_849C1E;
L_849C1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Eu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Eu, 5u, 4u, ((0x9E9569u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C1E LDA
    cpu.loadA(hw.readW(((0x9E9569u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849C22;
L_849C22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C22u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C22u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C22 BEQ -> $849C32
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_849C32; }
    goto L_849C24;
L_849C24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C24u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C24u, 8u, 4u, 0x80A6BDu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849C24 JSL -> $80A6BD stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9C27u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9C28u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6BDu, 0x849C24u); }
    goto L_849C28;
L_849C28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C28u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C28u,0x849C28u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C28u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C28u, 8u, 4u, 0x80A6A5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849C28 JSL -> $80A6A5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9C2Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9C2Cu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6A5u, 0x849C28u); }
    goto L_849C2C;
L_849C2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C2Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C2Cu,0x849C2Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C2Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C2Cu, 8u, 4u, 0x808D2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849C2C JSL -> $808D2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9C2Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9C30u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D2Fu, 0x849C2Cu); }
    goto L_849C30;
L_849C30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C30u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C30u,0x849C30u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C30u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C30u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C30 BRA -> $849C38
    goto L_849C38;
L_849C32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C32u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C32u, 8u, 4u, 0x80A5D1u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849C32 JSL -> $80A5D1 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9C35u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9C36u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A5D1u, 0x849C32u); }
    goto L_849C36;
L_849C36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C36u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C36u,0x849C36u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C36u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C36u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C36 BRA -> $849C38
    goto L_849C38;
L_849C38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C38u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C38u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C38 REP
    cpu.rep(0x20u);
    goto L_849C3A;
L_849C3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C3Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C3Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C3A LDA
    cpu.setA(0x7u, 16);
    goto L_849C3D;
L_849C3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C3Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C3Du, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849C3D JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9C40u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9C41u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x849C3Du); }
    goto L_849C41;
L_849C41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C41u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C41u,0x849C41u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C41u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C41u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849C41 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849C41u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849C41u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84B6B9_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84B6B9u: goto L_84B6B9;
    case 0x84B6BBu: goto L_84B6BB;
    case 0x84B6BEu: goto L_84B6BE;
    case 0x84B6C0u: goto L_84B6C0;
    case 0x84B6C3u: goto L_84B6C3;
    case 0x84B6C5u: goto L_84B6C5;
    case 0x84B6C8u: goto L_84B6C8;
    case 0x84B6CAu: goto L_84B6CA;
    case 0x84B6CDu: goto L_84B6CD;
    case 0x84B6CFu: goto L_84B6CF;
    case 0x84B6D2u: goto L_84B6D2;
    case 0x84B6D5u: goto L_84B6D5;
    case 0x84B6D6u: goto L_84B6D6;
    case 0x84B6D7u: goto L_84B6D7;
    case 0x84B6DBu: goto L_84B6DB;
    case 0x84B6DDu: goto L_84B6DD;
    case 0x84B6DFu: goto L_84B6DF;
    case 0x84B6E2u: goto L_84B6E2;
    case 0x84B6E3u: goto L_84B6E3;
    case 0x84B6E4u: goto L_84B6E4;
    case 0x84B6E8u: goto L_84B6E8;
    case 0x84B6EAu: goto L_84B6EA;
    case 0x84B6EEu: goto L_84B6EE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84B6B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B9u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6B9 REP
    cpu.rep(0x20u);
    goto L_84B6BB;
L_84B6BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6BB LDA
    cpu.setA(0x9Eu, 16);
    goto L_84B6BE;
L_84B6BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6BE STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_84B6C0;
L_84B6C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6C0 LDA
    cpu.setA(0x89u, 16);
    goto L_84B6C3;
L_84B6C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6C3 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_84B6C5;
L_84B6C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6C5 LDA
    cpu.setA(0x80u, 16);
    goto L_84B6C8;
L_84B6C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6C8 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_84B6CA;
L_84B6CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CAu, 5u, 3u, cpu.address("abs", 0x01A5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6CA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1A5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B6CD;
L_84B6CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6CD BNE -> $84B6DF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84B6DF; }
    goto L_84B6CF;
L_84B6CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CFu, 5u, 3u, cpu.address("abs", 0x062Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6CF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B6D2;
L_84B6D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D2u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6D2 AND
    cpu.logicAnd(0xFFu);
    goto L_84B6D5;
L_84B6D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6D5 ASL
    cpu.aslA();
    goto L_84B6D6;
L_84B6D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D6u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6D6 TAX
    cpu.transfer("TAX");
    goto L_84B6D7;
L_84B6D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D7u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D7u, 6u, 4u, ((0x9E8868u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6D7 LDA
    cpu.loadA(hw.readW(((0x9E8868u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B6DB;
L_84B6DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6DB STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84B6DD;
L_84B6DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DDu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6DD BRA -> $84B6EA
    goto L_84B6EA;
L_84B6DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DFu, 5u, 3u, cpu.address("abs", 0x01A9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6DF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1A9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B6E2;
L_84B6E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6E2 ASL
    cpu.aslA();
    goto L_84B6E3;
L_84B6E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E3u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6E3 TAX
    cpu.transfer("TAX");
    goto L_84B6E4;
L_84B6E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E4u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E4u, 6u, 4u, ((0x9E8868u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6E4 LDA
    cpu.loadA(hw.readW(((0x9E8868u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B6E8;
L_84B6E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6E8 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84B6EA;
L_84B6EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EAu, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B6EA JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB6EDu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB6EEu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x84B6EAu); }
    goto L_84B6EE;
L_84B6EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6EEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB6EEu,0x84B6EEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B6EE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84B6EEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84B6EEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84B6B9_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84B6B9u: goto L_84B6B9;
    case 0x84B6BBu: goto L_84B6BB;
    case 0x84B6BEu: goto L_84B6BE;
    case 0x84B6C0u: goto L_84B6C0;
    case 0x84B6C3u: goto L_84B6C3;
    case 0x84B6C5u: goto L_84B6C5;
    case 0x84B6C8u: goto L_84B6C8;
    case 0x84B6CAu: goto L_84B6CA;
    case 0x84B6CDu: goto L_84B6CD;
    case 0x84B6CFu: goto L_84B6CF;
    case 0x84B6D2u: goto L_84B6D2;
    case 0x84B6D5u: goto L_84B6D5;
    case 0x84B6D6u: goto L_84B6D6;
    case 0x84B6D7u: goto L_84B6D7;
    case 0x84B6DBu: goto L_84B6DB;
    case 0x84B6DDu: goto L_84B6DD;
    case 0x84B6DFu: goto L_84B6DF;
    case 0x84B6E2u: goto L_84B6E2;
    case 0x84B6E3u: goto L_84B6E3;
    case 0x84B6E4u: goto L_84B6E4;
    case 0x84B6E8u: goto L_84B6E8;
    case 0x84B6EAu: goto L_84B6EA;
    case 0x84B6EEu: goto L_84B6EE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84B6B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B9u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6B9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6B9 REP
    cpu.rep(0x20u);
    goto L_84B6BB;
L_84B6BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6BB LDA
    cpu.setA(0x9Eu, 16);
    goto L_84B6BE;
L_84B6BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6BEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6BE STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_84B6C0;
L_84B6C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6C0 LDA
    cpu.setA(0x89u, 16);
    goto L_84B6C3;
L_84B6C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6C3 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_84B6C5;
L_84B6C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6C5 LDA
    cpu.setA(0x80u, 16);
    goto L_84B6C8;
L_84B6C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6C8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6C8 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_84B6CA;
L_84B6CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CAu, 5u, 3u, cpu.address("abs", 0x01A5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6CA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1A5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B6CD;
L_84B6CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6CD BNE -> $84B6DF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84B6DF; }
    goto L_84B6CF;
L_84B6CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6CFu, 5u, 3u, cpu.address("abs", 0x062Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6CF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B6D2;
L_84B6D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D2u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6D2 AND
    cpu.logicAnd(0xFFu);
    goto L_84B6D5;
L_84B6D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6D5 ASL
    cpu.aslA();
    goto L_84B6D6;
L_84B6D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D6u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6D6 TAX
    cpu.transfer("TAX");
    goto L_84B6D7;
L_84B6D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D7u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D7u, 6u, 4u, ((0x9E8868u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6D7 LDA
    cpu.loadA(hw.readW(((0x9E8868u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B6DB;
L_84B6DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6DB STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84B6DD;
L_84B6DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DDu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6DD BRA -> $84B6EA
    goto L_84B6EA;
L_84B6DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DFu, 5u, 3u, cpu.address("abs", 0x01A9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6DF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1A9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B6E2;
L_84B6E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6E2 ASL
    cpu.aslA();
    goto L_84B6E3;
L_84B6E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E3u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6E3 TAX
    cpu.transfer("TAX");
    goto L_84B6E4;
L_84B6E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E4u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E4u, 6u, 4u, ((0x9E8868u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6E4 LDA
    cpu.loadA(hw.readW(((0x9E8868u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B6E8;
L_84B6E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B6E8 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84B6EA;
L_84B6EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EAu, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B6EA JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB6EDu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB6EEu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x84B6EAu); }
    goto L_84B6EE;
L_84B6EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6EEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB6EEu,0x84B6EEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B6EE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84B6EEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84B6EEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84BCE0_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84BCE0u: goto L_84BCE0;
    case 0x84BCE2u: goto L_84BCE2;
    case 0x84BCE5u: goto L_84BCE5;
    case 0x84BCE7u: goto L_84BCE7;
    case 0x84BCEAu: goto L_84BCEA;
    case 0x84BCECu: goto L_84BCEC;
    case 0x84BCEFu: goto L_84BCEF;
    case 0x84BCF2u: goto L_84BCF2;
    case 0x84BCF5u: goto L_84BCF5;
    case 0x84BCF8u: goto L_84BCF8;
    case 0x84BCFBu: goto L_84BCFB;
    case 0x84BCFEu: goto L_84BCFE;
    case 0x84BD01u: goto L_84BD01;
    case 0x84BD04u: goto L_84BD04;
    case 0x84BD07u: goto L_84BD07;
    case 0x84BD09u: goto L_84BD09;
    case 0x84BD0Cu: goto L_84BD0C;
    case 0x84BD0Fu: goto L_84BD0F;
    case 0x84BD12u: goto L_84BD12;
    case 0x84BD15u: goto L_84BD15;
    case 0x84BD18u: goto L_84BD18;
    case 0x84BD1Au: goto L_84BD1A;
    case 0x84BD1Du: goto L_84BD1D;
    case 0x84BD1Fu: goto L_84BD1F;
    case 0x84BD22u: goto L_84BD22;
    case 0x84BD23u: goto L_84BD23;
    case 0x84BD26u: goto L_84BD26;
    case 0x84BD27u: goto L_84BD27;
    case 0x84BD28u: goto L_84BD28;
    case 0x84BD2Au: goto L_84BD2A;
    case 0x84BD2Du: goto L_84BD2D;
    case 0x84BD2Fu: goto L_84BD2F;
    case 0x84BD32u: goto L_84BD32;
    case 0x84BD33u: goto L_84BD33;
    case 0x84BD34u: goto L_84BD34;
    case 0x84BD37u: goto L_84BD37;
    case 0x84BD3Au: goto L_84BD3A;
    case 0x84BD3Du: goto L_84BD3D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84BCE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCE0u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCE0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BCE0 REP
    cpu.rep(0x20u);
    goto L_84BCE2;
L_84BCE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCE2u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCE2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BCE2 AND
    cpu.logicAnd(0xFFu);
    goto L_84BCE5;
L_84BCE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCE5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCE5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BCE5 STA
    hw.write(cpu.address("dp", 0x63u), cpu.a, cpu.m8?8:16);
    goto L_84BCE7;
L_84BCE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCE7u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCE7u, 8u, 3u, cpu.address("abs", 0x065Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BCE7 DEC
    cpu.decMem(hw, cpu.address("abs", 0x65Eu), cpu.m8?8:16);
    goto L_84BCEA;
L_84BCEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCEAu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCEAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BCEA BPL -> $84BD3D
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_84BD3D; }
    goto L_84BCEC;
L_84BCEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCECu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCECu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BCEC LDA
    cpu.setA(0x7DBAu, 16);
    goto L_84BCEF;
L_84BCEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCEFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCEFu, 5u, 3u, cpu.address("abs", 0x1904u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BCEF STA
    hw.write(cpu.address("abs", 0x1904u), cpu.a, cpu.m8?8:16);
    goto L_84BCF2;
L_84BCF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF2u, 5u, 3u, cpu.address("abs", 0x1906u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BCF2 STA
    hw.write(cpu.address("abs", 0x1906u), cpu.a, cpu.m8?8:16);
    goto L_84BCF5;
L_84BCF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF5u, 5u, 3u, cpu.address("abs", 0x190Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BCF5 STA
    hw.write(cpu.address("abs", 0x190Au), cpu.a, cpu.m8?8:16);
    goto L_84BCF8;
L_84BCF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCF8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BCF8 LDA
    cpu.setA(0x4u, 16);
    goto L_84BCFB;
L_84BCFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCFBu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCFBu, 5u, 3u, cpu.address("abs", 0x065Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BCFB STA
    hw.write(cpu.address("abs", 0x65Eu), cpu.a, cpu.m8?8:16);
    goto L_84BCFE;
L_84BCFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBCFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBCFEu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBCFEu, 8u, 3u, cpu.address("abs", 0x06EBu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BCFE INC
    cpu.incMem(hw, cpu.address("abs", 0x6EBu), cpu.m8?8:16);
    goto L_84BD01;
L_84BD01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD01u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD01u, 5u, 3u, cpu.address("abs", 0x06EBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BD01 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6EBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BD04;
L_84BD04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD04u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD04u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BD04 CMP
    cpu.compareA(0x4u);
    goto L_84BD07;
L_84BD07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD07u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD07u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BD07 BCC -> $84BD15
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_84BD15; }
    goto L_84BD09;
L_84BD09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD09u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD09u, 5u, 3u, cpu.address("abs", 0x06EDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BD09 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6EDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BD0C;
L_84BD0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD0Cu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD0Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BD0C EOR
    cpu.logicXor(0x1u);
    goto L_84BD0F;
L_84BD0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD0Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD0Fu, 5u, 3u, cpu.address("abs", 0x06EDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BD0F STA
    hw.write(cpu.address("abs", 0x6EDu), cpu.a, cpu.m8?8:16);
    goto L_84BD12;
L_84BD12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD12u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD12u, 5u, 3u, cpu.address("abs", 0x06EBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BD12 STZ
    hw.write(cpu.address("abs", 0x6EBu), 0, cpu.m8?8:16);
    goto L_84BD15;
L_84BD15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD15u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD15u, 5u, 3u, cpu.address("abs", 0x06EDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BD15 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6EDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BD18;
L_84BD18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD18u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD18u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BD18 BEQ -> $84BD1F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_84BD1F; }
    goto L_84BD1A;
L_84BD1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD1Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD1Au, 5u, 3u, cpu.address("abs", 0x06EBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BD1A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6EBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BD1D;
L_84BD1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD1Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD1Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BD1D BRA -> $84BD26
    goto L_84BD26;
L_84BD1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD1Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD1Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BD1F LDA
    cpu.setA(0x3u, 16);
    goto L_84BD22;
L_84BD22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD22u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD22u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BD22 SEC
    cpu.setFlag('C', true);
    goto L_84BD23;
L_84BD23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD23u,cpu,0xEDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD23u, 5u, 3u, cpu.address("abs", 0x06EBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BD23 SBC
    cpu.sbc(hw.readW(cpu.address("abs", 0x6EBu), cpu.m8?8:16));
    goto L_84BD26;
L_84BD26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD26u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD26u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BD26 ASL
    cpu.aslA();
    goto L_84BD27;
L_84BD27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD27u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD27u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BD27 TAX
    cpu.transfer("TAX");
    goto L_84BD28;
L_84BD28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD28u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD28u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BD28 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x63u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BD2A;
L_84BD2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD2Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD2Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BD2A CMP
    cpu.compareA(0x2u);
    goto L_84BD2D;
L_84BD2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD2Du,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD2Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BD2D BCC -> $84BD32
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_84BD32; }
    goto L_84BD2F;
L_84BD2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD2Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD2Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BD2F LDA
    cpu.setA(0x3u, 16);
    goto L_84BD32;
L_84BD32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD32u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD32u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BD32 ASL
    cpu.aslA();
    goto L_84BD33;
L_84BD33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD33u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD33u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BD33 TAY
    cpu.transfer("TAY");
    goto L_84BD34;
L_84BD34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD34u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD34u, 5u + 1u, 3u, cpu.address("absx", 0x1918u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BD34 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1918u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BD37;
L_84BD37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD37u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD37u, 6u, 3u, cpu.address("absy", 0x1904u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BD37 STA
    hw.write(cpu.address("absy", 0x1904u), cpu.a, cpu.m8?8:16);
    goto L_84BD3A;
L_84BD3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD3Au,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD3Au, 8u, 3u, cpu.address("abs", 0x0122u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BD3A INC
    cpu.incMem(hw, cpu.address("abs", 0x122u), cpu.m8?8:16);
    goto L_84BD3D;
L_84BD3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD3Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD3Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84BD3D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84BD3Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84BD3Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84BEB7_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84BEB7u: goto L_84BEB7;
    case 0x84BEB9u: goto L_84BEB9;
    case 0x84BEBAu: goto L_84BEBA;
    case 0x84BEBDu: goto L_84BEBD;
    case 0x84BEBFu: goto L_84BEBF;
    case 0x84BEC0u: goto L_84BEC0;
    case 0x84BEC4u: goto L_84BEC4;
    case 0x84BEC8u: goto L_84BEC8;
    case 0x84BECBu: goto L_84BECB;
    case 0x84BECDu: goto L_84BECD;
    case 0x84BECFu: goto L_84BECF;
    case 0x84BED1u: goto L_84BED1;
    case 0x84BED3u: goto L_84BED3;
    case 0x84BED5u: goto L_84BED5;
    case 0x84BED7u: goto L_84BED7;
    case 0x84BEDAu: goto L_84BEDA;
    case 0x84BEDCu: goto L_84BEDC;
    case 0x84BEDEu: goto L_84BEDE;
    case 0x84BEE0u: goto L_84BEE0;
    case 0x84BEE2u: goto L_84BEE2;
    case 0x84BEE4u: goto L_84BEE4;
    case 0x84BEE6u: goto L_84BEE6;
    case 0x84BEE8u: goto L_84BEE8;
    case 0x84BEE9u: goto L_84BEE9;
    case 0x84BEEBu: goto L_84BEEB;
    case 0x84BEEFu: goto L_84BEEF;
    case 0x84BEF1u: goto L_84BEF1;
    case 0x84BEF4u: goto L_84BEF4;
    case 0x84BEF7u: goto L_84BEF7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84BEB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB7u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xBEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEB7 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xBEu), cpu.m8?8:16));
    goto L_84BEB9;
L_84BEB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB9u,cpu,0xF8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEB9 SED
    cpu.setFlag('D', true);
    goto L_84BEBA;
L_84BEBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEBAu,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEBAu, 5u + 1u, 3u, cpu.address("absy", 0xBF4Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEBA LDX
    cpu.setX(hw.readW(cpu.address("absy", 0xBF4Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_84BEBD;
L_84BEBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEBDu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEBDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEBD STZ
    hw.write(cpu.address("dp", 0xBFu), 0, cpu.m8?8:16);
    goto L_84BEBF;
L_84BEBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEBFu,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEBFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEBF TDC
    cpu.tdc();
    goto L_84BEC0;
L_84BEC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC0u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC0u, 6u, 4u, ((0xC7BFB3u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEC0 LDA
    cpu.loadA(hw.readW(((0xC7BFB3u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BEC4;
L_84BEC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC4u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC4u, 6u, 4u, ((0x20BFE2u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEC4 LDA
    cpu.loadA(hw.readW(((0x20BFE2u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BEC8;
L_84BEC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC8u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEC8 CPY
    cpu.compareY(0xC031u);
    goto L_84BECB;
L_84BECB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBECBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBECBu,cpu,0x43u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBECBu, 5u, 2u, cpu.addressStack(0xC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BECB EOR
    cpu.logicXor(hw.readW(cpu.addressStack(0xC0u), cpu.m8?8:16));
    goto L_84BECD;
L_84BECD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBECDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBECDu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBECDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BECD STZ
    hw.write(cpu.address("dp", 0xC0u), 0, cpu.m8?8:16);
    goto L_84BECF;
L_84BECF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBECFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBECFu,cpu,0x87u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBECFu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xC0u) & 0xFFFFu), 3u, 0u);
    // $84BECF STA
    hw.write(cpu.addressDpLong(hw, 0xC0u), cpu.a, cpu.m8?8:16);
    goto L_84BED1;
L_84BED1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBED1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBED1u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBED1u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BED1 DEC
    cpu.decMem(hw, cpu.address("dp", 0xC0u), cpu.m8?8:16);
    goto L_84BED3;
L_84BED3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBED3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBED3u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBED3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BED3 SEP
    cpu.sep(0xC0u);
    goto L_84BED5;
L_84BED5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBED5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBED5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBED5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BED5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BED7;
L_84BED7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBED7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBED7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBED7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BED7 AND
    cpu.logicAnd(0xFFu);
    goto L_84BEDA;
L_84BEDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEDAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEDAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEDA BNE -> $84BEF7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84BEF7; }
    goto L_84BEDC;
L_84BEDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEDCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEDCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEDC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BEDE;
L_84BEDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEDEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEDEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEDE BEQ -> $84BEF1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_84BEF1; }
    goto L_84BEE0;
L_84BEE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE0u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEE0 SEP
    cpu.sep(0x20u);
    goto L_84BEE2;
L_84BEE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEE2 LDA
    cpu.setA(0xAu, 8);
    goto L_84BEE4;
L_84BEE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEE4 STA
    hw.write(cpu.address("dp", 0x49u), cpu.a, cpu.m8?8:16);
    goto L_84BEE6;
L_84BEE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEE6 LDA
    cpu.setA(0x81u, 8);
    goto L_84BEE8;
L_84BEE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE8u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE8u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEE8 XBA
    cpu.xba();
    goto L_84BEE9;
L_84BEE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEE9 LDA
    cpu.setA(0xFu, 8);
    goto L_84BEEB;
L_84BEEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEEBu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEEBu, 8u, 4u, 0x8086F4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84BEEB JSL -> $8086F4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBEEEu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBEEFu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8086F4u, 0x84BEEBu); }
    goto L_84BEEF;
L_84BEEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEEFu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBEEFu,0x84BEEFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEEFu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEEFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEEF REP
    cpu.rep(0x20u);
    goto L_84BEF1;
L_84BEF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEF1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEF1u, 6u, 3u, cpu.address("abs", 0xC1FCu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84BEF1 JSR -> $84C1FC stack real
    { cpu.push16Value(hw,0xBEF3u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBEF4u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC1FCu), 0x84BEF1u); }
    goto L_84BEF4;
L_84BEF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEF4u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBEF4u,0x84BEF4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEF4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEF4u, 6u, 3u, cpu.address("abs", 0xC1B3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84BEF4 JSR -> $84C1B3 stack real
    { cpu.push16Value(hw,0xBEF6u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBEF7u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC1B3u), 0x84BEF4u); }
    goto L_84BEF7;
L_84BEF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEF7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBEF7u,0x84BEF7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEF7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEF7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84BEF7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84BEF7u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84BEF7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84BEB7_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84BEB7u: goto L_84BEB7;
    case 0x84BEB9u: goto L_84BEB9;
    case 0x84BEBAu: goto L_84BEBA;
    case 0x84BEBDu: goto L_84BEBD;
    case 0x84BEBFu: goto L_84BEBF;
    case 0x84BEC0u: goto L_84BEC0;
    case 0x84BEC4u: goto L_84BEC4;
    case 0x84BEC8u: goto L_84BEC8;
    case 0x84BECBu: goto L_84BECB;
    case 0x84BECDu: goto L_84BECD;
    case 0x84BECFu: goto L_84BECF;
    case 0x84BED1u: goto L_84BED1;
    case 0x84BED3u: goto L_84BED3;
    case 0x84BED5u: goto L_84BED5;
    case 0x84BED7u: goto L_84BED7;
    case 0x84BEDAu: goto L_84BEDA;
    case 0x84BEDCu: goto L_84BEDC;
    case 0x84BEDEu: goto L_84BEDE;
    case 0x84BEE0u: goto L_84BEE0;
    case 0x84BEE2u: goto L_84BEE2;
    case 0x84BEE4u: goto L_84BEE4;
    case 0x84BEE6u: goto L_84BEE6;
    case 0x84BEE8u: goto L_84BEE8;
    case 0x84BEE9u: goto L_84BEE9;
    case 0x84BEEBu: goto L_84BEEB;
    case 0x84BEEFu: goto L_84BEEF;
    case 0x84BEF1u: goto L_84BEF1;
    case 0x84BEF4u: goto L_84BEF4;
    case 0x84BEF7u: goto L_84BEF7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84BEB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB7u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0xBEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEB7 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xBEu), cpu.m8?8:16));
    goto L_84BEB9;
L_84BEB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB9u,cpu,0xF8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEB9 SED
    cpu.setFlag('D', true);
    goto L_84BEBA;
L_84BEBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEBAu,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEBAu, 5u + 1u, 3u, cpu.address("absy", 0xBF4Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEBA LDX
    cpu.setX(hw.readW(cpu.address("absy", 0xBF4Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_84BEBD;
L_84BEBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEBDu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEBDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEBD STZ
    hw.write(cpu.address("dp", 0xBFu), 0, cpu.m8?8:16);
    goto L_84BEBF;
L_84BEBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEBFu,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEBFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEBF TDC
    cpu.tdc();
    goto L_84BEC0;
L_84BEC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC0u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC0u, 6u, 4u, ((0xC7BFB3u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEC0 LDA
    cpu.loadA(hw.readW(((0xC7BFB3u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BEC4;
L_84BEC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC4u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC4u, 6u, 4u, ((0x20BFE2u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEC4 LDA
    cpu.loadA(hw.readW(((0x20BFE2u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BEC8;
L_84BEC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC8u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEC8 CPY
    cpu.compareY(0xC031u);
    goto L_84BECB;
L_84BECB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBECBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBECBu,cpu,0x43u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBECBu, 5u, 2u, cpu.addressStack(0xC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BECB EOR
    cpu.logicXor(hw.readW(cpu.addressStack(0xC0u), cpu.m8?8:16));
    goto L_84BECD;
L_84BECD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBECDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBECDu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBECDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BECD STZ
    hw.write(cpu.address("dp", 0xC0u), 0, cpu.m8?8:16);
    goto L_84BECF;
L_84BECF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBECFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBECFu,cpu,0x87u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBECFu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xC0u) & 0xFFFFu), 3u, 0u);
    // $84BECF STA
    hw.write(cpu.addressDpLong(hw, 0xC0u), cpu.a, cpu.m8?8:16);
    goto L_84BED1;
L_84BED1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBED1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBED1u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBED1u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BED1 DEC
    cpu.decMem(hw, cpu.address("dp", 0xC0u), cpu.m8?8:16);
    goto L_84BED3;
L_84BED3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBED3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBED3u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBED3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BED3 SEP
    cpu.sep(0xC0u);
    goto L_84BED5;
L_84BED5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBED5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBED5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBED5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BED5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BED7;
L_84BED7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBED7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBED7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBED7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BED7 AND
    cpu.logicAnd(0xFFu);
    goto L_84BEDA;
L_84BEDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEDAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEDAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEDA BNE -> $84BEF7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84BEF7; }
    goto L_84BEDC;
L_84BEDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEDCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEDCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEDC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BEDE;
L_84BEDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEDEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEDEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEDE BEQ -> $84BEF1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_84BEF1; }
    goto L_84BEE0;
L_84BEE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE0u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEE0 SEP
    cpu.sep(0x20u);
    goto L_84BEE2;
L_84BEE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEE2 LDA
    cpu.setA(0xAu, 8);
    goto L_84BEE4;
L_84BEE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEE4 STA
    hw.write(cpu.address("dp", 0x49u), cpu.a, cpu.m8?8:16);
    goto L_84BEE6;
L_84BEE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEE6 LDA
    cpu.setA(0x81u, 8);
    goto L_84BEE8;
L_84BEE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE8u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE8u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEE8 XBA
    cpu.xba();
    goto L_84BEE9;
L_84BEE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEE9 LDA
    cpu.setA(0xFu, 8);
    goto L_84BEEB;
L_84BEEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEEBu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEEBu, 8u, 4u, 0x8086F4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84BEEB JSL -> $8086F4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBEEEu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBEEFu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8086F4u, 0x84BEEBu); }
    goto L_84BEEF;
L_84BEEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEEFu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBEEFu,0x84BEEFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEEFu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEEFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEEF REP
    cpu.rep(0x20u);
    goto L_84BEF1;
L_84BEF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEF1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEF1u, 6u, 3u, cpu.address("abs", 0xC1FCu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84BEF1 JSR -> $84C1FC stack real
    { cpu.push16Value(hw,0xBEF3u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBEF4u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC1FCu), 0x84BEF1u); }
    goto L_84BEF4;
L_84BEF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEF4u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBEF4u,0x84BEF4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEF4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEF4u, 6u, 3u, cpu.address("abs", 0xC1B3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84BEF4 JSR -> $84C1B3 stack real
    { cpu.push16Value(hw,0xBEF6u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBEF7u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC1B3u), 0x84BEF4u); }
    goto L_84BEF7;
L_84BEF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEF7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBEF7u,0x84BEF7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEF7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEF7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84BEF7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84BEF7u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84BEF7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84C25B_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84C25Bu: goto L_84C25B;
    case 0x84C25Du: goto L_84C25D;
    case 0x84C260u: goto L_84C260;
    case 0x84C262u: goto L_84C262;
    case 0x84C265u: goto L_84C265;
    case 0x84C267u: goto L_84C267;
    case 0x84C26Au: goto L_84C26A;
    case 0x84C26Cu: goto L_84C26C;
    case 0x84C26Fu: goto L_84C26F;
    case 0x84C273u: goto L_84C273;
    case 0x84C275u: goto L_84C275;
    case 0x84C279u: goto L_84C279;
    case 0x84C27Bu: goto L_84C27B;
    case 0x84C27Du: goto L_84C27D;
    case 0x84C280u: goto L_84C280;
    case 0x84C282u: goto L_84C282;
    case 0x84C285u: goto L_84C285;
    case 0x84C288u: goto L_84C288;
    case 0x84C28Bu: goto L_84C28B;
    case 0x84C28Eu: goto L_84C28E;
    case 0x84C290u: goto L_84C290;
    case 0x84C293u: goto L_84C293;
    case 0x84C296u: goto L_84C296;
    case 0x84C298u: goto L_84C298;
    case 0x84C29Bu: goto L_84C29B;
    case 0x84C29Du: goto L_84C29D;
    case 0x84C2A0u: goto L_84C2A0;
    case 0x84C2A4u: goto L_84C2A4;
    case 0x84C2A6u: goto L_84C2A6;
    case 0x84C2AAu: goto L_84C2AA;
    case 0x84C2ACu: goto L_84C2AC;
    case 0x84C2AFu: goto L_84C2AF;
    case 0x84C2B1u: goto L_84C2B1;
    case 0x84C2B4u: goto L_84C2B4;
    case 0x84C2B7u: goto L_84C2B7;
    case 0x84C2BAu: goto L_84C2BA;
    case 0x84C2BDu: goto L_84C2BD;
    case 0x84C2BFu: goto L_84C2BF;
    case 0x84C2C2u: goto L_84C2C2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84C25B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC25Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC25Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC25Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C25B REP
    cpu.rep(0x20u);
    goto L_84C25D;
L_84C25D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC25Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC25Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC25Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C25D LDA
    cpu.setA(0x93u, 16);
    goto L_84C260;
L_84C260:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC260u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC260u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC260u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C260 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_84C262;
L_84C262:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC262u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC262u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC262u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C262 LDA
    cpu.setA(0xB0u, 16);
    goto L_84C265;
L_84C265:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC265u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC265u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC265u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C265 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_84C267;
L_84C267:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC267u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC267u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC267u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C267 LDA
    cpu.setA(0x68u, 16);
    goto L_84C26A;
L_84C26A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC26Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC26Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC26Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C26A STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_84C26C;
L_84C26C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC26Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC26Cu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC26Cu, 5u, 3u, cpu.address("abs", 0x06F9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C26C LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x6F9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_84C26F;
L_84C26F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC26Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC26Fu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC26Fu, 6u, 4u, ((0x9385BEu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C26F LDA
    cpu.loadA(hw.readW(((0x9385BEu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84C273;
L_84C273:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC273u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC273u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC273u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C273 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84C275;
L_84C275:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC275u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC275u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC275u, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84C275 JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC278u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC279u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x84C275u); }
    goto L_84C279;
L_84C279:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC279u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC279u,0x84C279u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC279u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC279u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C279 REP
    cpu.rep(0x20u);
    goto L_84C27B;
L_84C27B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC27Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C27B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84C27D;
L_84C27D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC27Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C27D AND
    cpu.logicAnd(0x7u);
    goto L_84C280;
L_84C280:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC280u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC280u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC280u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C280 BNE -> $84C293
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84C293; }
    goto L_84C282;
L_84C282:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC282u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC282u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC282u, 8u, 3u, cpu.address("abs", 0x06F9u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C282 INC
    cpu.incMem(hw, cpu.address("abs", 0x6F9u), cpu.m8?8:16);
    goto L_84C285;
L_84C285:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC285u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC285u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC285u, 8u, 3u, cpu.address("abs", 0x06F9u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C285 INC
    cpu.incMem(hw, cpu.address("abs", 0x6F9u), cpu.m8?8:16);
    goto L_84C288;
L_84C288:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC288u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC288u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC288u, 5u, 3u, cpu.address("abs", 0x06F9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C288 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6F9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84C28B;
L_84C28B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC28Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC28Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC28Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C28B CMP
    cpu.compareA(0x6u);
    goto L_84C28E;
L_84C28E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC28Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC28Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC28Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C28E BCC -> $84C293
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_84C293; }
    goto L_84C290;
L_84C290:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC290u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC290u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC290u, 5u, 3u, cpu.address("abs", 0x06F9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C290 STZ
    hw.write(cpu.address("abs", 0x6F9u), 0, cpu.m8?8:16);
    goto L_84C293;
L_84C293:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC293u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC293u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC293u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C293 LDA
    cpu.setA(0x28u, 16);
    goto L_84C296;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC293u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC293u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C293 LDA
    cpu.setA(0x28u, 16);
    goto L_84C296;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC293u,0x84C293u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84C296:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC296u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC296u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC296u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C296 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_84C298;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC296u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC296u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C296 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_84C298;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC296u,0x84C296u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84C298:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC298u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC298u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC298u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C298 LDA
    cpu.setA(0x60u, 16);
    goto L_84C29B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC298u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC298u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C298 LDA
    cpu.setA(0x60u, 16);
    goto L_84C29B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC298u,0x84C298u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84C29B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC29Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC29Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC29Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C29B STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_84C29D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC29Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC29Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C29B STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_84C29D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC29Bu,0x84C29Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84C29D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC29Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC29Du,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC29Du, 5u, 3u, cpu.address("abs", 0x06FBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C29D LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x6FBu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_84C2A0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC29Du,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC29Du, 5u, 3u, cpu.address("abs", 0x06FBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C29D LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x6FBu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_84C2A0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC29Du,0x84C29Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84C2A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2A0u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2A0u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2A0u, 6u, 4u, ((0x9385C4u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2A0 LDA
    cpu.loadA(hw.readW(((0x9385C4u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84C2A4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2A0u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2A0u, 6u, 4u, ((0x9385C4u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2A0 LDA
    cpu.loadA(hw.readW(((0x9385C4u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84C2A4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC2A0u,0x84C2A0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84C2A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2A4u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2A4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2A4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2A4 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84C2A6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2A4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2A4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2A4 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84C2A6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC2A4u,0x84C2A4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84C2A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2A6u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2A6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2A6u, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84C2A6 JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC2A9u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC2AAu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x84C2A6u); }
    goto L_84C2AA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2A6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2A6u, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84C2A6 JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC2A9u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC2AAu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x84C2A6u); }
    goto L_84C2AA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC2A6u,0x84C2A6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84C2AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2AAu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2AAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2AAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2AA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84C2AC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2AAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2AAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2AA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84C2AC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC2AAu,0x84C2AAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84C2AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2ACu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2ACu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2ACu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2AC AND
    cpu.logicAnd(0x1Fu);
    goto L_84C2AF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2ACu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2ACu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2AC AND
    cpu.logicAnd(0x1Fu);
    goto L_84C2AF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC2ACu,0x84C2ACu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84C2AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2AFu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2AFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2AFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2AF BNE -> $84C2C2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84C2C2; }
    goto L_84C2B1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2AFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2AFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2AF BNE -> $84C2C2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84C2C2; }
    goto L_84C2B1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC2AFu,0x84C2AFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84C2B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2B1u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2B1u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2B1u, 8u, 3u, cpu.address("abs", 0x06FBu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2B1 INC
    cpu.incMem(hw, cpu.address("abs", 0x6FBu), cpu.m8?8:16);
    goto L_84C2B4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2B1u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2B1u, 8u, 3u, cpu.address("abs", 0x06FBu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2B1 INC
    cpu.incMem(hw, cpu.address("abs", 0x6FBu), cpu.m8?8:16);
    goto L_84C2B4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC2B1u,0x84C2B1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84C2B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2B4u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2B4u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2B4u, 8u, 3u, cpu.address("abs", 0x06FBu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2B4 INC
    cpu.incMem(hw, cpu.address("abs", 0x6FBu), cpu.m8?8:16);
    goto L_84C2B7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2B4u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2B4u, 8u, 3u, cpu.address("abs", 0x06FBu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2B4 INC
    cpu.incMem(hw, cpu.address("abs", 0x6FBu), cpu.m8?8:16);
    goto L_84C2B7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC2B4u,0x84C2B4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84C2B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2B7u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2B7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2B7u, 5u, 3u, cpu.address("abs", 0x06FBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2B7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6FBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84C2BA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2B7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2B7u, 5u, 3u, cpu.address("abs", 0x06FBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2B7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6FBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84C2BA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC2B7u,0x84C2B7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84C2BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2BAu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2BAu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2BAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2BA CMP
    cpu.compareA(0x6u);
    goto L_84C2BD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2BAu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2BAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2BA CMP
    cpu.compareA(0x6u);
    goto L_84C2BD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC2BAu,0x84C2BAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84C2BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2BDu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2BDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2BD BCC -> $84C2C2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_84C2C2; }
    goto L_84C2BF;
L_84C2BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2BFu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2BFu, 5u, 3u, cpu.address("abs", 0x06FBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2BF STZ
    hw.write(cpu.address("abs", 0x6FBu), 0, cpu.m8?8:16);
    goto L_84C2C2;
L_84C2C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2C2u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2C2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2C2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84C2C2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84C2C2u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84C2C2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2C2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2C2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84C2C2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84C2C2u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84C2C2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC2C2u,0x84C2C2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_84C25B_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84C25Bu: goto L_84C25B;
    case 0x84C25Du: goto L_84C25D;
    case 0x84C260u: goto L_84C260;
    case 0x84C262u: goto L_84C262;
    case 0x84C265u: goto L_84C265;
    case 0x84C267u: goto L_84C267;
    case 0x84C26Au: goto L_84C26A;
    case 0x84C26Cu: goto L_84C26C;
    case 0x84C26Fu: goto L_84C26F;
    case 0x84C273u: goto L_84C273;
    case 0x84C275u: goto L_84C275;
    case 0x84C279u: goto L_84C279;
    case 0x84C27Bu: goto L_84C27B;
    case 0x84C27Du: goto L_84C27D;
    case 0x84C280u: goto L_84C280;
    case 0x84C282u: goto L_84C282;
    case 0x84C285u: goto L_84C285;
    case 0x84C288u: goto L_84C288;
    case 0x84C28Bu: goto L_84C28B;
    case 0x84C28Eu: goto L_84C28E;
    case 0x84C290u: goto L_84C290;
    case 0x84C293u: goto L_84C293;
    case 0x84C296u: goto L_84C296;
    case 0x84C298u: goto L_84C298;
    case 0x84C29Bu: goto L_84C29B;
    case 0x84C29Du: goto L_84C29D;
    case 0x84C2A0u: goto L_84C2A0;
    case 0x84C2A4u: goto L_84C2A4;
    case 0x84C2A6u: goto L_84C2A6;
    case 0x84C2AAu: goto L_84C2AA;
    case 0x84C2ACu: goto L_84C2AC;
    case 0x84C2AFu: goto L_84C2AF;
    case 0x84C2B1u: goto L_84C2B1;
    case 0x84C2B4u: goto L_84C2B4;
    case 0x84C2B7u: goto L_84C2B7;
    case 0x84C2BAu: goto L_84C2BA;
    case 0x84C2BDu: goto L_84C2BD;
    case 0x84C2BFu: goto L_84C2BF;
    case 0x84C2C2u: goto L_84C2C2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84C25B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC25Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC25Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC25Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C25B REP
    cpu.rep(0x20u);
    goto L_84C25D;
L_84C25D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC25Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC25Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC25Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C25D LDA
    cpu.setA(0x93u, 16);
    goto L_84C260;
L_84C260:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC260u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC260u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC260u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C260 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_84C262;
L_84C262:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC262u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC262u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC262u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C262 LDA
    cpu.setA(0xB0u, 16);
    goto L_84C265;
L_84C265:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC265u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC265u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC265u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C265 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_84C267;
L_84C267:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC267u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC267u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC267u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C267 LDA
    cpu.setA(0x68u, 16);
    goto L_84C26A;
L_84C26A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC26Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC26Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC26Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C26A STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_84C26C;
L_84C26C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC26Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC26Cu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC26Cu, 5u, 3u, cpu.address("abs", 0x06F9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C26C LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x6F9u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_84C26F;
L_84C26F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC26Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC26Fu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC26Fu, 6u, 4u, ((0x9385BEu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C26F LDA
    cpu.loadA(hw.readW(((0x9385BEu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84C273;
L_84C273:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC273u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC273u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC273u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C273 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84C275;
L_84C275:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC275u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC275u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC275u, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84C275 JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC278u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC279u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x84C275u); }
    goto L_84C279;
L_84C279:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC279u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC279u,0x84C279u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC279u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC279u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C279 REP
    cpu.rep(0x20u);
    goto L_84C27B;
L_84C27B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC27Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C27B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84C27D;
L_84C27D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC27Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C27D AND
    cpu.logicAnd(0x7u);
    goto L_84C280;
L_84C280:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC280u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC280u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC280u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C280 BNE -> $84C293
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84C293; }
    goto L_84C282;
L_84C282:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC282u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC282u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC282u, 8u, 3u, cpu.address("abs", 0x06F9u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C282 INC
    cpu.incMem(hw, cpu.address("abs", 0x6F9u), cpu.m8?8:16);
    goto L_84C285;
L_84C285:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC285u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC285u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC285u, 8u, 3u, cpu.address("abs", 0x06F9u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C285 INC
    cpu.incMem(hw, cpu.address("abs", 0x6F9u), cpu.m8?8:16);
    goto L_84C288;
L_84C288:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC288u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC288u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC288u, 5u, 3u, cpu.address("abs", 0x06F9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C288 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6F9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84C28B;
L_84C28B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC28Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC28Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC28Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C28B CMP
    cpu.compareA(0x6u);
    goto L_84C28E;
L_84C28E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC28Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC28Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC28Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C28E BCC -> $84C293
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_84C293; }
    goto L_84C290;
L_84C290:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC290u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC290u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC290u, 5u, 3u, cpu.address("abs", 0x06F9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C290 STZ
    hw.write(cpu.address("abs", 0x6F9u), 0, cpu.m8?8:16);
    goto L_84C293;
L_84C293:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC293u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC293u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC293u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C293 LDA
    cpu.setA(0x28u, 16);
    goto L_84C296;
L_84C296:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC296u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC296u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC296u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C296 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_84C298;
L_84C298:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC298u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC298u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC298u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C298 LDA
    cpu.setA(0x60u, 16);
    goto L_84C29B;
L_84C29B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC29Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC29Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC29Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C29B STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_84C29D;
L_84C29D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC29Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC29Du,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC29Du, 5u, 3u, cpu.address("abs", 0x06FBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C29D LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x6FBu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_84C2A0;
L_84C2A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2A0u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2A0u, 6u, 4u, ((0x9385C4u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2A0 LDA
    cpu.loadA(hw.readW(((0x9385C4u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84C2A4;
L_84C2A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2A4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2A4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2A4 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84C2A6;
L_84C2A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2A6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2A6u, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84C2A6 JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC2A9u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC2AAu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x84C2A6u); }
    goto L_84C2AA;
L_84C2AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2AAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC2AAu,0x84C2AAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2AAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2AAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2AA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84C2AC;
L_84C2AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2ACu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2ACu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2AC AND
    cpu.logicAnd(0x1Fu);
    goto L_84C2AF;
L_84C2AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2AFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2AFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2AF BNE -> $84C2C2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84C2C2; }
    goto L_84C2B1;
L_84C2B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2B1u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2B1u, 8u, 3u, cpu.address("abs", 0x06FBu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2B1 INC
    cpu.incMem(hw, cpu.address("abs", 0x6FBu), cpu.m8?8:16);
    goto L_84C2B4;
L_84C2B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2B4u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2B4u, 8u, 3u, cpu.address("abs", 0x06FBu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2B4 INC
    cpu.incMem(hw, cpu.address("abs", 0x6FBu), cpu.m8?8:16);
    goto L_84C2B7;
L_84C2B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2B7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2B7u, 5u, 3u, cpu.address("abs", 0x06FBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2B7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6FBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84C2BA;
L_84C2BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2BAu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2BAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2BA CMP
    cpu.compareA(0x6u);
    goto L_84C2BD;
L_84C2BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2BDu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2BDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2BD BCC -> $84C2C2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_84C2C2; }
    goto L_84C2BF;
L_84C2BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2BFu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2BFu, 5u, 3u, cpu.address("abs", 0x06FBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2BF STZ
    hw.write(cpu.address("abs", 0x6FBu), 0, cpu.m8?8:16);
    goto L_84C2C2;
L_84C2C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2C2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2C2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84C2C2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84C2C2u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84C2C2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

