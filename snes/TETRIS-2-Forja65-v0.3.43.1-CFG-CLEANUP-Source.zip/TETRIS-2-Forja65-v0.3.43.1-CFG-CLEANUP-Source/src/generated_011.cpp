#include "generated.hpp"
void sub_20C290_E0M1X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x20C27Bu: goto L_20C27B;
    case 0x20C27Cu: goto L_20C27C;
    case 0x20C27Du: goto L_20C27D;
    case 0x20C281u: goto L_20C281;
    case 0x20C283u: goto L_20C283;
    case 0x20C285u: goto L_20C285;
    case 0x20C289u: goto L_20C289;
    case 0x20C28Cu: goto L_20C28C;
    case 0x20C28Eu: goto L_20C28E;
    case 0x20C290u: goto L_20C290;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_20C27B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC27Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Bu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20C27B DEX
    cpu.decReg('X');
    goto L_20C27C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Bu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20C27B DEX
    cpu.decReg('X');
    goto L_20C27C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC27Bu,0x20C27Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_20C27C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC27Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Cu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20C27C DEX
    cpu.decReg('X');
    goto L_20C27D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Cu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20C27C DEX
    cpu.decReg('X');
    goto L_20C27D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC27Cu,0x20C27Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_20C27D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC27Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Du,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Du, 5u, 4u, ((0x7E2016u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20C27D LDA
    cpu.loadA(hw.readW(((0x7E2016u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_20C281;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Du,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Du, 5u, 4u, ((0x7E2016u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20C27D LDA
    cpu.loadA(hw.readW(((0x7E2016u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_20C281;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC27Du,0x20C27Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_20C281:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC281u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC281u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC281u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20C281 BEQ -> $20C28E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_20C28E; }
    goto L_20C283;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC281u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC281u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20C281 BEQ -> $20C28E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_20C28E; }
    goto L_20C283;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC281u,0x20C281u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_20C283:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC283u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC283u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC283u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20C283 CMP
    cpu.compareA(0xFFu);
    goto L_20C285;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC283u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC283u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20C283 CMP
    cpu.compareA(0xFFu);
    goto L_20C285;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC283u,0x20C283u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_20C285:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC285u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC285u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC285u, 5u, 4u, ((0xA50AF0u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20C285 SBC
    cpu.sbc(hw.readW(((0xA50AF0u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_20C289;
L_20C289:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC289u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC289u,cpu,0x1Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC289u, 7u, 3u, cpu.address("absx", 0x06D0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20C289 ASL
    cpu.aslMem(hw, cpu.address("absx", 0x6D0u), cpu.m8?8:16);
    goto L_20C28C;
L_20C28C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC28Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC28Cu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC28Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20C28C BRA -> $20C27B
    goto L_20C27B;
L_20C28E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC28Eu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC28Eu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC28Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20C28E INC
    cpu.incMem(hw, cpu.address("dp", 0x1Eu), cpu.m8?8:16);
    goto L_20C290;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC28Eu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC28Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20C28E INC
    cpu.incMem(hw, cpu.address("dp", 0x1Eu), cpu.m8?8:16);
    goto L_20C290;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC28Eu,0x20C28Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_20C290:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC290u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC290u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC290u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20C290 BRA -> $20C27B
    goto L_20C27B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC290u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC290u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20C290 BRA -> $20C27B
    goto L_20C27B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC290u,0x20C290u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_20C290_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x20C27Bu: goto L_20C27B;
    case 0x20C27Cu: goto L_20C27C;
    case 0x20C27Du: goto L_20C27D;
    case 0x20C281u: goto L_20C281;
    case 0x20C283u: goto L_20C283;
    case 0x20C285u: goto L_20C285;
    case 0x20C289u: goto L_20C289;
    case 0x20C28Cu: goto L_20C28C;
    case 0x20C28Eu: goto L_20C28E;
    case 0x20C290u: goto L_20C290;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_20C27B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC27Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Bu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20C27B DEX
    cpu.decReg('X');
    goto L_20C27C;
L_20C27C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC27Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Cu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20C27C DEX
    cpu.decReg('X');
    goto L_20C27D;
L_20C27D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC27Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Du,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Du, 5u, 4u, ((0x7E2016u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20C27D LDA
    cpu.loadA(hw.readW(((0x7E2016u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_20C281;
L_20C281:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC281u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC281u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC281u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20C281 BEQ -> $20C28E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_20C28E; }
    goto L_20C283;
L_20C283:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC283u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC283u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC283u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20C283 CMP
    cpu.compareA(0xFFu);
    goto L_20C285;
L_20C285:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC285u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC285u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC285u, 5u, 4u, ((0xA50AF0u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20C285 SBC
    cpu.sbc(hw.readW(((0xA50AF0u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_20C289;
L_20C289:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC289u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC289u,cpu,0x1Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC289u, 7u, 3u, cpu.address("absx", 0x06D0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20C289 ASL
    cpu.aslMem(hw, cpu.address("absx", 0x6D0u), cpu.m8?8:16);
    goto L_20C28C;
L_20C28C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC28Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC28Cu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC28Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20C28C BRA -> $20C27B
    goto L_20C27B;
L_20C28E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC28Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC28Eu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC28Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20C28E INC
    cpu.incMem(hw, cpu.address("dp", 0x1Eu), cpu.m8?8:16);
    goto L_20C290;
L_20C290:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC290u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC290u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC290u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20C290 BRA -> $20C27B
    goto L_20C27B;
}

void sub_6082A7_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x6082A7u: goto L_6082A7;
    case 0x6082A8u: goto L_6082A8;
    case 0x6082AAu: goto L_6082AA;
    case 0x6082ACu: goto L_6082AC;
    case 0x6082AEu: goto L_6082AE;
    case 0x6082B0u: goto L_6082B0;
    case 0x6082B2u: goto L_6082B2;
    case 0x6082B4u: goto L_6082B4;
    case 0x6082B6u: goto L_6082B6;
    case 0x6082B8u: goto L_6082B8;
    case 0x6082BAu: goto L_6082BA;
    case 0x6082BCu: goto L_6082BC;
    case 0x6082BEu: goto L_6082BE;
    case 0x6082C0u: goto L_6082C0;
    case 0x6082C2u: goto L_6082C2;
    case 0x6082C4u: goto L_6082C4;
    case 0x6082C6u: goto L_6082C6;
    case 0x6082C9u: goto L_6082C9;
    case 0x6082CCu: goto L_6082CC;
    case 0x6082CEu: goto L_6082CE;
    case 0x6082D0u: goto L_6082D0;
    case 0x6082D2u: goto L_6082D2;
    case 0x6082D4u: goto L_6082D4;
    case 0x6082D6u: goto L_6082D6;
    case 0x6082D8u: goto L_6082D8;
    case 0x6082DAu: goto L_6082DA;
    case 0x6082DBu: goto L_6082DB;
    case 0x6082DEu: goto L_6082DE;
    case 0x6082E0u: goto L_6082E0;
    case 0x6082E3u: goto L_6082E3;
    case 0x6082E4u: goto L_6082E4;
    case 0x6082E5u: goto L_6082E5;
    case 0x6082E7u: goto L_6082E7;
    case 0x6082E8u: goto L_6082E8;
    case 0x6082E9u: goto L_6082E9;
    case 0x6082EBu: goto L_6082EB;
    case 0x6082EFu: goto L_6082EF;
    case 0x6082F0u: goto L_6082F0;
    case 0x6082F2u: goto L_6082F2;
    case 0x6082F6u: goto L_6082F6;
    case 0x6082F7u: goto L_6082F7;
    case 0x6082F8u: goto L_6082F8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_6082A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82A7u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82A7u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $6082A7 PHP
    cpu.push("PHP", hw);
    goto L_6082A8;
L_6082A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82A8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82A8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6082A8 REP
    cpu.rep(0x20u);
    goto L_6082AA;
L_6082AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82AAu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82AAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6082AA STZ
    hw.write(cpu.address("dp", 0x7Au), 0, cpu.m8?8:16);
    goto L_6082AC;
L_6082AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82ACu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82ACu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6082AC STZ
    hw.write(cpu.address("dp", 0x7Cu), 0, cpu.m8?8:16);
    goto L_6082AE;
L_6082AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82AEu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82AEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6082AE STZ
    hw.write(cpu.address("dp", 0x7Eu), 0, cpu.m8?8:16);
    goto L_6082B0;
L_6082B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82B0u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82B0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6082B0 STZ
    hw.write(cpu.address("dp", 0x80u), 0, cpu.m8?8:16);
    goto L_6082B2;
L_6082B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82B2u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82B2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6082B2 STZ
    hw.write(cpu.address("dp", 0x82u), 0, cpu.m8?8:16);
    goto L_6082B4;
L_6082B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82B4u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82B4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x84u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6082B4 STZ
    hw.write(cpu.address("dp", 0x84u), 0, cpu.m8?8:16);
    goto L_6082B6;
L_6082B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82B6u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82B6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x86u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6082B6 STZ
    hw.write(cpu.address("dp", 0x86u), 0, cpu.m8?8:16);
    goto L_6082B8;
L_6082B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82B8u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82B8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6082B8 STZ
    hw.write(cpu.address("dp", 0x88u), 0, cpu.m8?8:16);
    goto L_6082BA;
L_6082BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82BAu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82BAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x92u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6082BA STZ
    hw.write(cpu.address("dp", 0x92u), 0, cpu.m8?8:16);
    goto L_6082BC;
L_6082BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82BCu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82BCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6082BC STZ
    hw.write(cpu.address("dp", 0x94u), 0, cpu.m8?8:16);
    goto L_6082BE;
L_6082BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82BEu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82BEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6082BE SEP
    cpu.sep(0x20u);
    goto L_6082C0;
L_6082C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C0u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x78u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6082C0 STZ
    hw.write(cpu.address("dp", 0x78u), 0, cpu.m8?8:16);
    goto L_6082C2;
L_6082C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C2u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6082C2 STZ
    hw.write(cpu.address("dp", 0x77u), 0, cpu.m8?8:16);
    goto L_6082C4;
L_6082C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C4u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6082C4 STZ
    hw.write(cpu.address("dp", 0x75u), 0, cpu.m8?8:16);
    goto L_6082C6;
L_6082C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C6u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C6u, 4u, 3u, cpu.address("abs", 0x0128u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6082C6 STZ
    hw.write(cpu.address("abs", 0x128u), 0, cpu.m8?8:16);
    goto L_6082C9;
L_6082C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C9u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C9u, 4u, 3u, cpu.address("abs", 0x012Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6082C9 STZ
    hw.write(cpu.address("abs", 0x12Eu), 0, cpu.m8?8:16);
    goto L_6082CC;
L_6082CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82CCu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82CCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6082CC STZ
    hw.write(cpu.address("dp", 0x49u), 0, cpu.m8?8:16);
    goto L_6082CE;
L_6082CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82CEu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82CEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6082CE STZ
    hw.write(cpu.address("dp", 0x47u), 0, cpu.m8?8:16);
    goto L_6082D0;
L_6082D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82D0u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82D0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6082D0 STZ
    hw.write(cpu.address("dp", 0x4Au), 0, cpu.m8?8:16);
    goto L_6082D2;
L_6082D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82D2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82D2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6082D2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x46u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_6082D4;
L_6082D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82D4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82D4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6082D4 AND
    cpu.logicAnd(0x7Fu);
    goto L_6082D6;
L_6082D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82D6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82D6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6082D6 STA
    hw.write(cpu.address("dp", 0x46u), cpu.a, cpu.m8?8:16);
    goto L_6082D8;
L_6082D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82D8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82D8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x48u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6082D8 STA
    hw.write(cpu.address("dp", 0x48u), cpu.a, cpu.m8?8:16);
    goto L_6082DA;
L_6082DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82DAu,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82DAu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $6082DA PHK
    cpu.push("PHK", hw);
    goto L_6082DB;
L_6082DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82DBu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82DBu, 5u, 3u, cpu.address("abs", 0x82F8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $6082DB PEA
    cpu.push16Value(hw, 0x82F8u);
    goto L_6082DE;
L_6082DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82DEu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82DEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6082DE REP
    cpu.rep(0x20u);
    goto L_6082E0;
L_6082E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E0u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6082E0 AND
    cpu.logicAnd(0xFFu);
    goto L_6082E3;
L_6082E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E3u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E3u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $6082E3 PHA
    cpu.push("PHA", hw);
    goto L_6082E4;
L_6082E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E4u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6082E4 ASL
    cpu.aslA();
    goto L_6082E5;
L_6082E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E5u,cpu,0x63u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E5u, 5u, 2u, cpu.addressStack(0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6082E5 ADC
    cpu.adc(hw.readW(cpu.addressStack(0x1u), cpu.m8?8:16));
    goto L_6082E7;
L_6082E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E7u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6082E7 TAX
    cpu.transfer("TAX");
    goto L_6082E8;
L_6082E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E8u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E8u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $6082E8 PLA
    cpu.pop("PLA", hw);
    goto L_6082E9;
L_6082E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6082E9 SEP
    cpu.sep(0x20u);
    goto L_6082EB;
L_6082EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82EBu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82EBu, 5u, 4u, ((0x8082FDu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6082EB LDA
    cpu.loadA(hw.readW(((0x8082FDu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_6082EF;
L_6082EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82EFu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82EFu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $6082EF PHA
    cpu.push("PHA", hw);
    goto L_6082F0;
L_6082F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F0u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6082F0 REP
    cpu.rep(0x20u);
    goto L_6082F2;
L_6082F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F2u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F2u, 6u, 4u, ((0x8082FBu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6082F2 LDA
    cpu.loadA(hw.readW(((0x8082FBu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_6082F6;
L_6082F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F6u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $6082F6 DEC
    cpu.decReg('A');
    goto L_6082F7;
L_6082F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F7u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F7u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $6082F7 PHA
    cpu.push("PHA", hw);
    goto L_6082F8;
L_6082F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F8u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $6082F8 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x6082F8u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x6082F8u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808084_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808069u: goto L_808069;
    case 0x80806Bu: goto L_80806B;
    case 0x80806Fu: goto L_80806F;
    case 0x808073u: goto L_808073;
    case 0x808076u: goto L_808076;
    case 0x808078u: goto L_808078;
    case 0x80807Bu: goto L_80807B;
    case 0x80807Cu: goto L_80807C;
    case 0x80807Eu: goto L_80807E;
    case 0x808080u: goto L_808080;
    case 0x808083u: goto L_808083;
    case 0x808084u: goto L_808084;
    case 0x808085u: goto L_808085;
    case 0x808089u: goto L_808089;
    case 0x80808Du: goto L_80808D;
    case 0x808090u: goto L_808090;
    case 0x808093u: goto L_808093;
    case 0x808095u: goto L_808095;
    case 0x808099u: goto L_808099;
    case 0x80809Du: goto L_80809D;
    case 0x8080A1u: goto L_8080A1;
    case 0x8080A3u: goto L_8080A3;
    case 0x8080A6u: goto L_8080A6;
    case 0x8080A8u: goto L_8080A8;
    case 0x8080AAu: goto L_8080AA;
    case 0x8080AEu: goto L_8080AE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808069:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8069u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8069u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8069u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808069 SEP
    cpu.sep(0x24u);
    goto L_80806B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8069u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8069u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808069 SEP
    cpu.sep(0x24u);
    goto L_80806B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8069u,0x808069u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80806B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x806Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x806Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x806Bu, 8u, 4u, 0x808556u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80806B JSL -> $808556 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x806Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x806Fu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808556u, 0x80806Bu); }
    goto L_80806F;
L_80806F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x806Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x806Fu,0x80806Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x806Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x806Fu, 8u, 4u, 0x808572u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80806F JSL -> $808572 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8072u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8073u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808572u, 0x80806Fu); }
    goto L_808073;
L_808073:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8073u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8073u,0x808073u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8073u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8073u, 4u, 3u, cpu.address("abs", 0x420Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808073 STZ
    hw.write(cpu.address("abs", 0x420Cu), 0, cpu.m8?8:16);
    goto L_808076;
L_808076:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8076u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8076u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8076u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xB4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808076 STZ
    hw.write(cpu.address("dp", 0xB4u), 0, cpu.m8?8:16);
    goto L_808078;
L_808078:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8078u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8078u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8078u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808078 LDX
    cpu.setX(0x1FF0u, 16);
    goto L_80807B;
L_80807B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x807Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x807Bu,cpu,0x9Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x807Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80807B TXS
    cpu.transfer("TXS");
    goto L_80807C;
L_80807C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x807Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x807Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x807Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80807C STZ
    hw.write(cpu.address("dp", 0x96u), 0, cpu.m8?8:16);
    goto L_80807E;
L_80807E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x807Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x807Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x807Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80807E STZ
    hw.write(cpu.address("dp", 0x97u), 0, cpu.m8?8:16);
    goto L_808080;
L_808080:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8080u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8080u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8080u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808080 LDX
    cpu.setX(0x200u, 16);
    goto L_808083;
L_808083:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8083u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8083u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8083u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808083 STX
    hw.write(cpu.address("dp", 0x98u), cpu.x, cpu.x8?8:16);
    goto L_808085;
L_808084:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8084u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8084u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8084u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808084 TYA
    cpu.transfer("TYA");
    goto L_808085;
L_808085:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8085u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8085u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8085u, 8u, 4u, 0x808ADEu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808085 JSL -> $808ADE stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8088u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8089u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808ADEu, 0x808085u); }
    goto L_808089;
L_808089:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8089u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8089u,0x808089u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8089u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8089u, 8u, 4u, 0x808B92u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808089 JSL -> $808B92 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x808Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x808Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808B92u, 0x808089u); }
    goto L_80808D;
L_80808D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x808Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x808Du,0x80808Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x808Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x808Du, 6u, 3u, cpu.address("abs", 0x82A7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80808D JSR -> $8082A7 stack real
    { cpu.push16Value(hw,0x808Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8090u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x82A7u), 0x80808Du); }
    goto L_808090;
L_808090:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8090u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8090u,0x808090u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8090u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8090u, 6u, 3u, cpu.address("abs", 0x85ADu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808090 JSR -> $8085AD stack real
    { cpu.push16Value(hw,0x8092u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8093u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x85ADu), 0x808090u); }
    goto L_808093;
L_808093:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8093u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8093u,0x808093u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8093u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8093u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808093 STZ
    hw.write(cpu.address("dp", 0x4Bu), 0, cpu.m8?8:16);
    goto L_808095;
L_808095:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8095u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8095u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8095u, 8u, 4u, 0x808547u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808095 JSL -> $808547 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8098u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8099u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808547u, 0x808095u); }
    goto L_808099;
L_808099:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8099u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8099u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8099u, 8u, 4u, 0x808D03u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808099 JSL -> $808D03 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x809Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x809Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D03u, 0x808099u); }
    goto L_80809D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8099u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8099u, 8u, 4u, 0x808D03u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808099 JSL -> $808D03 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x809Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x809Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D03u, 0x808099u); }
    goto L_80809D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8099u,0x808099u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80809D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x809Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x809Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x809Du, 8u, 4u, 0x8096A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80809D JSL -> $8096A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80A0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80A1u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8096A3u, 0x80809Du); }
    goto L_8080A1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x809Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x809Du, 8u, 4u, 0x8096A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80809D JSL -> $8096A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80A0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80A1u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8096A3u, 0x80809Du); }
    goto L_8080A1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x809Du,0x80809Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8080A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80A1u,0x8080A1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A1u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A1 SEP
    cpu.sep(0x20u);
    goto L_8080A3;
L_8080A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A3u, 6u, 3u, cpu.address("abs", 0x83A4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8080A3 JSR -> $8083A4 stack real
    { cpu.push16Value(hw,0x80A5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80A6u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x83A4u), 0x8080A3u); }
    goto L_8080A6;
L_8080A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A6u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x46u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8080A8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x46u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8080A8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80A6u,0x8080A6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8080A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A8u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A8u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A8 BPL -> $808099
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808099; }
    goto L_8080AA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A8u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A8 BPL -> $808099
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808099; }
    goto L_8080AA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80A8u,0x8080A8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8080AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80AAu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu, 8u, 4u, 0x808556u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080AA JSL -> $808556 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80ADu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80AEu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808556u, 0x8080AAu); }
    goto L_8080AE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu, 8u, 4u, 0x808556u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080AA JSL -> $808556 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80ADu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80AEu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808556u, 0x8080AAu); }
    goto L_8080AE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80AAu,0x8080AAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8080AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80AEu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080AE BRA -> $808069
    goto L_808069;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080AE BRA -> $808069
    goto L_808069;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80AEu,0x8080AEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_8082FB_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8082FBu: goto L_8082FB;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8082FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82FBu,cpu,0x40u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82FBu, 7u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $8082FB RTI stack real
    {auto dst=cpu.returnInterrupt(hw);hw.requestDispatch(dst,0x8082FBu);return;}
}

void sub_808368_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808368u: goto L_808368;
    case 0x80836Cu: goto L_80836C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808368:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8368u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8368u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8368u, 8u, 4u, 0x848C63u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808368 JSL -> $848C63 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x836Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x836Cu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848C63u, 0x808368u); }
    goto L_80836C;
L_80836C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x836Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x836Cu,0x80836Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x836Cu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x836Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80836C RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80836Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80836Cu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808368_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808368u: goto L_808368;
    case 0x80836Cu: goto L_80836C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808368:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8368u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8368u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8368u, 8u, 4u, 0x848C63u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808368 JSL -> $848C63 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x836Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x836Cu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848C63u, 0x808368u); }
    goto L_80836C;
L_80836C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x836Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x836Cu,0x80836Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x836Cu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x836Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80836C RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80836Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80836Cu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8084CF_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8084CFu: goto L_8084CF;
    case 0x8084D1u: goto L_8084D1;
    case 0x8084D3u: goto L_8084D3;
    case 0x8084D7u: goto L_8084D7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8084CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84CFu,cpu,0x53u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84CFu, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.s + 0x84u) & 0xFFFFu), 2u, 0u);
    // $8084CF EOR
    cpu.logicXor(hw.readW(cpu.addressStackIndirectY(hw, 0x84u), cpu.m8?8:16));
    goto L_8084D1;
L_8084D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84D1u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84D1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8084D1 STY
    hw.write(cpu.address("dp", 0x6Bu), cpu.y, cpu.x8?8:16);
    goto L_8084D3;
L_8084D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84D3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84D3u, 8u, 4u, 0x848EC7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8084D3 JSL -> $848EC7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x84D6u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x84D7u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848EC7u, 0x8084D3u); }
    goto L_8084D7;
L_8084D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84D7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x84D7u,0x8084D7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84D7u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84D7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8084D7 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8084D7u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8084D7u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808572_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808572u: goto L_808572;
    case 0x808573u: goto L_808573;
    case 0x808575u: goto L_808575;
    case 0x808577u: goto L_808577;
    case 0x808579u: goto L_808579;
    case 0x80857Bu: goto L_80857B;
    case 0x80857Eu: goto L_80857E;
    case 0x80857Fu: goto L_80857F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808572:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8572u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8572u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8572u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808572 PHP
    cpu.push("PHP", hw);
    goto L_808573;
L_808573:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8573u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8573u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8573u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808573 SEP
    cpu.sep(0x20u);
    goto L_808575;
L_808575:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8575u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8575u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8575u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808575 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x74u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808577;
L_808577:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8577u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8577u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8577u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808577 ORA
    cpu.logicOr(0x80u);
    goto L_808579;
L_808579:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8579u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8579u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8579u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x74u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808579 STA
    hw.write(cpu.address("dp", 0x74u), cpu.a, cpu.m8?8:16);
    goto L_80857B;
L_80857B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x857Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x857Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x857Bu, 4u, 3u, cpu.address("abs", 0x2100u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80857B STA
    hw.write(cpu.address("abs", 0x2100u), cpu.a, cpu.m8?8:16);
    goto L_80857E;
L_80857E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x857Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x857Eu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x857Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80857E PLP
    cpu.pop("PLP", hw);
    goto L_80857F;
L_80857F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x857Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x857Fu,0x80857Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x857Fu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x857Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80857F RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80857Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80857Fu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808886_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808886u: goto L_808886;
    case 0x808887u: goto L_808887;
    case 0x808889u: goto L_808889;
    case 0x80888Au: goto L_80888A;
    case 0x80888Cu: goto L_80888C;
    case 0x80888Du: goto L_80888D;
    case 0x80888Eu: goto L_80888E;
    case 0x80888Fu: goto L_80888F;
    case 0x808891u: goto L_808891;
    case 0x808893u: goto L_808893;
    case 0x808896u: goto L_808896;
    case 0x808898u: goto L_808898;
    case 0x808899u: goto L_808899;
    case 0x80889Bu: goto L_80889B;
    case 0x80889Du: goto L_80889D;
    case 0x80889Fu: goto L_80889F;
    case 0x8088A1u: goto L_8088A1;
    case 0x8088A3u: goto L_8088A3;
    case 0x8088A6u: goto L_8088A6;
    case 0x8088A8u: goto L_8088A8;
    case 0x8088AAu: goto L_8088AA;
    case 0x8088ABu: goto L_8088AB;
    case 0x8088ACu: goto L_8088AC;
    case 0x8088ADu: goto L_8088AD;
    case 0x8088AEu: goto L_8088AE;
    case 0x8088B0u: goto L_8088B0;
    case 0x8088B3u: goto L_8088B3;
    case 0x8088B5u: goto L_8088B5;
    case 0x8088B7u: goto L_8088B7;
    case 0x8088B8u: goto L_8088B8;
    case 0x8088BBu: goto L_8088BB;
    case 0x8088BCu: goto L_8088BC;
    case 0x8088BEu: goto L_8088BE;
    case 0x8088C1u: goto L_8088C1;
    case 0x8088C2u: goto L_8088C2;
    case 0x8088C3u: goto L_8088C3;
    case 0x8088C5u: goto L_8088C5;
    case 0x8088C6u: goto L_8088C6;
    case 0x8088C7u: goto L_8088C7;
    case 0x8088C8u: goto L_8088C8;
    case 0x8088C9u: goto L_8088C9;
    case 0x8088CAu: goto L_8088CA;
    case 0x8088CBu: goto L_8088CB;
    case 0x8088CCu: goto L_8088CC;
    case 0x8088CEu: goto L_8088CE;
    case 0x8088D1u: goto L_8088D1;
    case 0x8088D2u: goto L_8088D2;
    case 0x8088D4u: goto L_8088D4;
    case 0x8088D7u: goto L_8088D7;
    case 0x8088DBu: goto L_8088DB;
    case 0x8088DFu: goto L_8088DF;
    case 0x8088E2u: goto L_8088E2;
    case 0x8088E3u: goto L_8088E3;
    case 0x8088E4u: goto L_8088E4;
    case 0x8088E7u: goto L_8088E7;
    case 0x8088E8u: goto L_8088E8;
    case 0x8088EAu: goto L_8088EA;
    case 0x8088EBu: goto L_8088EB;
    case 0x8088EEu: goto L_8088EE;
    case 0x8088F1u: goto L_8088F1;
    case 0x8088F2u: goto L_8088F2;
    case 0x8088F4u: goto L_8088F4;
    case 0x8088F7u: goto L_8088F7;
    case 0x8088F9u: goto L_8088F9;
    case 0x8088FBu: goto L_8088FB;
    case 0x8088FDu: goto L_8088FD;
    case 0x8088FFu: goto L_8088FF;
    case 0x808902u: goto L_808902;
    case 0x808904u: goto L_808904;
    case 0x808906u: goto L_808906;
    case 0x808909u: goto L_808909;
    case 0x80890Au: goto L_80890A;
    case 0x80890Bu: goto L_80890B;
    case 0x80890Cu: goto L_80890C;
    case 0x80890Du: goto L_80890D;
    case 0x80890Eu: goto L_80890E;
    case 0x80890Fu: goto L_80890F;
    case 0x808910u: goto L_808910;
    case 0x808911u: goto L_808911;
    case 0x808912u: goto L_808912;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808886:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8886u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8886u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8886u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808886 PHP
    cpu.push("PHP", hw);
    goto L_808887;
L_808887:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8887u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8887u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8887u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808887 SEP
    cpu.sep(0x20u);
    goto L_808889;
L_808889:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8889u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8889u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8889u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808889 PHB
    cpu.push("PHB", hw);
    goto L_80888A;
L_80888A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x888Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x888Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x888Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80888A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80888C;
L_80888C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x888Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x888Cu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x888Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80888C PHA
    cpu.push("PHA", hw);
    goto L_80888D;
L_80888D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x888Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x888Du,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x888Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80888D PLB
    cpu.pop("PLB", hw);
    goto L_80888E;
L_80888E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x888Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x888Eu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x888Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80888E PHX
    cpu.push("PHX", hw);
    goto L_80888F;
L_80888F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x888Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x888Fu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x888Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80888F LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x96u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_808891;
L_808891:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8891u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8891u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8891u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808891 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_808893;
L_808893:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8893u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8893u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8893u, 4u + 1u, 3u, cpu.address("absy", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808893 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808896;
L_808896:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8896u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8896u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8896u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808896 BMI -> $8088A8
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_8088A8; }
    goto L_808898;
L_808898:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8898u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8898u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8898u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808898 ASL
    cpu.aslA();
    goto L_808899;
L_808899:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8899u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8899u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8899u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808899 STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_80889B;
L_80889B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x889Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x889Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x889Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80889B BEQ -> $80889F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80889F; }
    goto L_80889D;
L_80889D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x889Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x889Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x889Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80889D LDA
    cpu.setA(0x8u, 8);
    goto L_80889F;
L_80889F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x889Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x889Fu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x889Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80889F EOR
    cpu.logicXor(0xF0u);
    goto L_8088A1;
L_8088A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88A1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88A1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088A1 STA
    hw.write(cpu.address("dp", 0x7u), cpu.a, cpu.m8?8:16);
    goto L_8088A3;
L_8088A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88A3u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88A3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088A3 CPX
    cpu.compareX(0x200u);
    goto L_8088A6;
L_8088A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88A6u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88A6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088A6 BCC -> $8088AE
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8088AE; }
    goto L_8088A8;
L_8088A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88A8u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88A8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088A8 STX
    hw.write(cpu.address("dp", 0x96u), cpu.x, cpu.x8?8:16);
    goto L_8088AA;
L_8088AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88AAu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88AAu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8088AA PLX
    cpu.pop("PLX", hw);
    goto L_8088AB;
L_8088AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88ABu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88ABu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8088AB PLB
    cpu.pop("PLB", hw);
    goto L_8088AC;
L_8088AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88ACu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88ACu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8088AC PLP
    cpu.pop("PLP", hw);
    goto L_8088AD;
L_8088AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88ADu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x88ADu,0x8088ADu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88ADu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88ADu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8088AD RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8088ADu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8088ADu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_8088AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88AEu,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88AEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088AE BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16), false);
    goto L_8088B0;
L_8088B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88B0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88B0u, 4u + 1u, 3u, cpu.address("absy", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088B0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8088B3;
L_8088B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88B3u,cpu,0x50u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88B3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088B3 BVC -> $8088BB
    if (!cpu.v) { hw.addCpuInternalCycles(1u); goto L_8088BB; }
    goto L_8088B5;
L_8088B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88B5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88B5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088B5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8088B7;
L_8088B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88B7u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88B7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088B7 SEC
    cpu.setFlag('C', true);
    goto L_8088B8;
L_8088B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88B8u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88B8u, 4u + 1u, 3u, cpu.address("absy", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088B8 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x1u), cpu.m8?8:16));
    goto L_8088BB;
L_8088BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88BBu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088BB CLC
    cpu.setFlag('C', false);
    goto L_8088BC;
L_8088BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88BCu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88BCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088BC ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16));
    goto L_8088BE;
L_8088BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88BEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88BEu, 5u, 3u, cpu.address("absx", 0x1400u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088BE STA
    hw.write(cpu.address("absx", 0x1400u), cpu.a, cpu.m8?8:16);
    goto L_8088C1;
L_8088C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C1u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8088C1 PHX
    cpu.push("PHX", hw);
    goto L_8088C2;
L_8088C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C2u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C2u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8088C2 PHY
    cpu.push("PHY", hw);
    goto L_8088C3;
L_8088C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C3u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088C3 REP
    cpu.rep(0x20u);
    goto L_8088C5;
L_8088C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C5u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088C5 TXA
    cpu.transfer("TXA");
    goto L_8088C6;
L_8088C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C6u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088C6 LSR
    cpu.lsrA();
    goto L_8088C7;
L_8088C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C7u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088C7 LSR
    cpu.lsrA();
    goto L_8088C8;
L_8088C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C8u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088C8 LSR
    cpu.lsrA();
    goto L_8088C9;
L_8088C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88C9u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88C9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088C9 LSR
    cpu.lsrA();
    goto L_8088CA;
L_8088CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88CAu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88CAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088CA TAY
    cpu.transfer("TAY");
    goto L_8088CB;
L_8088CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88CBu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88CBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088CB TXA
    cpu.transfer("TXA");
    goto L_8088CC;
L_8088CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88CCu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88CCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088CC ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x6u), cpu.m8?8:16));
    goto L_8088CE;
L_8088CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88CEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88CEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088CE AND
    cpu.logicAnd(0xFu);
    goto L_8088D1;
L_8088D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88D1u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88D1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088D1 TAX
    cpu.transfer("TAX");
    goto L_8088D2;
L_8088D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88D2u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88D2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088D2 SEP
    cpu.sep(0x20u);
    goto L_8088D4;
L_8088D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88D4u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88D4u, 4u + 1u, 3u, cpu.address("absy", 0x1600u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088D4 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1600u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8088D7;
L_8088D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88D7u,cpu,0x3Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88D7u, 5u, 4u, ((0x80886Eu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088D7 AND
    cpu.logicAnd(hw.readW(((0x80886Eu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_8088DB;
L_8088DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88DBu,cpu,0x1Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88DBu, 5u, 4u, ((0x80885Eu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088DB ORA
    cpu.logicOr(hw.readW(((0x80885Eu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_8088DF;
L_8088DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88DFu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88DFu, 5u, 3u, cpu.address("absy", 0x1600u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088DF STA
    hw.write(cpu.address("absy", 0x1600u), cpu.a, cpu.m8?8:16);
    goto L_8088E2;
L_8088E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E2u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E2u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8088E2 PLY
    cpu.pop("PLY", hw);
    goto L_8088E3;
L_8088E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E3u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E3u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8088E3 PLX
    cpu.pop("PLX", hw);
    goto L_8088E4;
L_8088E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E4u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E4u, 4u + 1u, 3u, cpu.address("absy", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088E4 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8088E7;
L_8088E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E7u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088E7 CLC
    cpu.setFlag('C', false);
    goto L_8088E8;
L_8088E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88E8u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88E8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088E8 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_8088EA;
L_8088EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88EAu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88EAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088EA DEC
    cpu.decReg('A');
    goto L_8088EB;
L_8088EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88EBu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88EBu, 5u, 3u, cpu.address("absx", 0x1401u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088EB STA
    hw.write(cpu.address("absx", 0x1401u), cpu.a, cpu.m8?8:16);
    goto L_8088EE;
L_8088EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88EEu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88EEu, 4u + 1u, 3u, cpu.address("absy", 0x0003u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088EE LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8088F1;
L_8088F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F1u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088F1 CLC
    cpu.setFlag('C', false);
    goto L_8088F2;
L_8088F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F2u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088F2 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_8088F4;
L_8088F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F4u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F4u, 5u, 3u, cpu.address("absx", 0x1402u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088F4 STA
    hw.write(cpu.address("absx", 0x1402u), cpu.a, cpu.m8?8:16);
    goto L_8088F7;
L_8088F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088F7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8088F9;
L_8088F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88F9u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088F9 BCC -> $8088FD
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8088FD; }
    goto L_8088FB;
L_8088FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88FBu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88FBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088FB ORA
    cpu.logicOr(0x1u);
    goto L_8088FD;
L_8088FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88FDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88FDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088FD STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_8088FF;
L_8088FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x88FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x88FFu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x88FFu, 4u + 1u, 3u, cpu.address("absy", 0x0004u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8088FF LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808902;
L_808902:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8902u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8902u,cpu,0x45u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8902u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808902 EOR
    cpu.logicXor(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16));
    goto L_808904;
L_808904:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8904u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8904u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8904u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808904 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x6u), cpu.m8?8:16));
    goto L_808906;
L_808906:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8906u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8906u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8906u, 5u, 3u, cpu.address("absx", 0x1403u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808906 STA
    hw.write(cpu.address("absx", 0x1403u), cpu.a, cpu.m8?8:16);
    goto L_808909;
L_808909:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8909u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8909u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8909u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808909 INX
    cpu.inc('X');
    goto L_80890A;
L_80890A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Au,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80890A INX
    cpu.inc('X');
    goto L_80890B;
L_80890B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Bu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80890B INX
    cpu.inc('X');
    goto L_80890C;
L_80890C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Cu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80890C INX
    cpu.inc('X');
    goto L_80890D;
L_80890D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Du,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80890D INY
    cpu.inc('Y');
    goto L_80890E;
L_80890E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Eu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80890E INY
    cpu.inc('Y');
    goto L_80890F;
L_80890F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80890F INY
    cpu.inc('Y');
    goto L_808910;
L_808910:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8910u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8910u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8910u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808910 INY
    cpu.inc('Y');
    goto L_808911;
L_808911:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8911u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8911u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8911u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808911 INY
    cpu.inc('Y');
    goto L_808912;
L_808912:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8912u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8912u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8912u, 3u, 3u, cpu.address("abs", 0x8893u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808912 JMP -> $808893
    goto L_808893;
}

void sub_808B4C_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808B4Cu: goto L_808B4C;
    case 0x808B4Du: goto L_808B4D;
    case 0x808B4Eu: goto L_808B4E;
    case 0x808B50u: goto L_808B50;
    case 0x808B54u: goto L_808B54;
    case 0x808B57u: goto L_808B57;
    case 0x808B59u: goto L_808B59;
    case 0x808B5Cu: goto L_808B5C;
    case 0x808B5Du: goto L_808B5D;
    case 0x808B5Eu: goto L_808B5E;
    case 0x808B60u: goto L_808B60;
    case 0x808B63u: goto L_808B63;
    case 0x808B64u: goto L_808B64;
    case 0x808B65u: goto L_808B65;
    case 0x808B67u: goto L_808B67;
    case 0x808B6Au: goto L_808B6A;
    case 0x808B6Bu: goto L_808B6B;
    case 0x808B6Cu: goto L_808B6C;
    case 0x808B6Eu: goto L_808B6E;
    case 0x808B71u: goto L_808B71;
    case 0x808B73u: goto L_808B73;
    case 0x808B74u: goto L_808B74;
    case 0x808B77u: goto L_808B77;
    case 0x808B79u: goto L_808B79;
    case 0x808B7Au: goto L_808B7A;
    case 0x808B7Bu: goto L_808B7B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808B4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B4Cu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B4Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808B4C PHP
    cpu.push("PHP", hw);
    goto L_808B4D;
L_808B4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B4Du,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B4Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808B4D PHY
    cpu.push("PHY", hw);
    goto L_808B4E;
L_808B4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B4Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B4Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808B4E REP
    cpu.rep(0x20u);
    goto L_808B50;
L_808B50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B50u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B50u, 8u, 4u, 0x808B7Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808B50 JSL -> $808B7C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8B53u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8B54u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808B7Cu, 0x808B50u); }
    goto L_808B54;
L_808B54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B54u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B54u,0x808B54u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B54u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B54u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808B54 LDY
    cpu.setY(0x0u, 16);
    goto L_808B57;
L_808B57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B57u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B57u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $808B57 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808B59;
L_808B59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B59u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B59u, 6u, 3u, cpu.address("absx", 0x1800u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808B59 STA
    hw.write(cpu.address("absx", 0x1800u), cpu.a, cpu.m8?8:16);
    goto L_808B5C;
L_808B5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B5Cu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B5Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808B5C INY
    cpu.inc('Y');
    goto L_808B5D;
L_808B5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B5Du,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B5Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808B5D INY
    cpu.inc('Y');
    goto L_808B5E;
L_808B5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B5Eu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B5Eu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $808B5E LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808B60;
L_808B60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B60u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B60u, 6u, 3u, cpu.address("absx", 0x1802u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808B60 STA
    hw.write(cpu.address("absx", 0x1802u), cpu.a, cpu.m8?8:16);
    goto L_808B63;
L_808B63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B63u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B63u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808B63 INY
    cpu.inc('Y');
    goto L_808B64;
L_808B64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B64u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B64u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808B64 INY
    cpu.inc('Y');
    goto L_808B65;
L_808B65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B65u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B65u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $808B65 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808B67;
L_808B67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B67u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B67u, 6u, 3u, cpu.address("absx", 0x1804u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808B67 STA
    hw.write(cpu.address("absx", 0x1804u), cpu.a, cpu.m8?8:16);
    goto L_808B6A;
L_808B6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Au,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808B6A INY
    cpu.inc('Y');
    goto L_808B6B;
L_808B6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Bu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808B6B INY
    cpu.inc('Y');
    goto L_808B6C;
L_808B6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Cu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Cu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $808B6C LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808B6E;
L_808B6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B6Eu, 6u, 3u, cpu.address("absx", 0x1806u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808B6E STA
    hw.write(cpu.address("absx", 0x1806u), cpu.a, cpu.m8?8:16);
    goto L_808B71;
L_808B71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B71u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B71u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808B71 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808B73;
L_808B73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B73u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B73u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808B73 CLC
    cpu.setFlag('C', false);
    goto L_808B74;
L_808B74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B74u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B74u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808B74 ADC
    cpu.adc(0x8u);
    goto L_808B77;
L_808B77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B77u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B77u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808B77 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_808B79;
L_808B79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B79u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B79u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808B79 PLY
    cpu.pop("PLY", hw);
    goto L_808B7A;
L_808B7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Au,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808B7A PLP
    cpu.pop("PLP", hw);
    goto L_808B7B;
L_808B7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B7Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8B7Bu,0x808B7Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Bu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B7Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808B7B RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808B7Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808B7Bu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_809FF0_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809FF0u: goto L_809FF0;
    case 0x809FF3u: goto L_809FF3;
    case 0x809FF6u: goto L_809FF6;
    case 0x809FF9u: goto L_809FF9;
    case 0x809FFCu: goto L_809FFC;
    case 0x80A000u: goto L_80A000;
    case 0x80A002u: goto L_80A002;
    case 0x80A004u: goto L_80A004;
    case 0x80A005u: goto L_80A005;
    case 0x80A008u: goto L_80A008;
    case 0x80A00Bu: goto L_80A00B;
    case 0x80A00Eu: goto L_80A00E;
    case 0x80A012u: goto L_80A012;
    case 0x80A015u: goto L_80A015;
    case 0x80A018u: goto L_80A018;
    case 0x80A01Bu: goto L_80A01B;
    case 0x80A01Eu: goto L_80A01E;
    case 0x80A022u: goto L_80A022;
    case 0x80A024u: goto L_80A024;
    case 0x80A026u: goto L_80A026;
    case 0x80A027u: goto L_80A027;
    case 0x80A02Au: goto L_80A02A;
    case 0x80A02Du: goto L_80A02D;
    case 0x80A030u: goto L_80A030;
    case 0x80A034u: goto L_80A034;
    case 0x80A037u: goto L_80A037;
    case 0x80A039u: goto L_80A039;
    case 0x80A03Cu: goto L_80A03C;
    case 0x80A03Eu: goto L_80A03E;
    case 0x80A041u: goto L_80A041;
    case 0x80A044u: goto L_80A044;
    case 0x80A048u: goto L_80A048;
    case 0x80A04Bu: goto L_80A04B;
    case 0x80A04Eu: goto L_80A04E;
    case 0x80A051u: goto L_80A051;
    case 0x80A054u: goto L_80A054;
    case 0x80A058u: goto L_80A058;
    case 0x80A059u: goto L_80A059;
    case 0x80A05Cu: goto L_80A05C;
    case 0x80A05Fu: goto L_80A05F;
    case 0x80A061u: goto L_80A061;
    case 0x80A062u: goto L_80A062;
    case 0x80A065u: goto L_80A065;
    case 0x80A066u: goto L_80A066;
    case 0x80A069u: goto L_80A069;
    case 0x80A06Cu: goto L_80A06C;
    case 0x80A06Fu: goto L_80A06F;
    case 0x80A072u: goto L_80A072;
    case 0x80A076u: goto L_80A076;
    case 0x80A077u: goto L_80A077;
    case 0x80A07Au: goto L_80A07A;
    case 0x80A07Du: goto L_80A07D;
    case 0x80A07Fu: goto L_80A07F;
    case 0x80A080u: goto L_80A080;
    case 0x80A083u: goto L_80A083;
    case 0x80A084u: goto L_80A084;
    case 0x80A087u: goto L_80A087;
    case 0x80A08Au: goto L_80A08A;
    case 0x80A08Du: goto L_80A08D;
    case 0x80A090u: goto L_80A090;
    case 0x80A094u: goto L_80A094;
    case 0x80A095u: goto L_80A095;
    case 0x80A098u: goto L_80A098;
    case 0x80A09Bu: goto L_80A09B;
    case 0x80A09Du: goto L_80A09D;
    case 0x80A09Eu: goto L_80A09E;
    case 0x80A0A1u: goto L_80A0A1;
    case 0x80A0A2u: goto L_80A0A2;
    case 0x80A0A5u: goto L_80A0A5;
    case 0x80A0A9u: goto L_80A0A9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809FF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FF0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FF0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809FF0 LDA
    cpu.setA(0x91EEu, 16);
    goto L_809FF3;
L_809FF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FF3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FF3u, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809FF3 STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_809FF6;
L_809FF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FF6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FF6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809FF6 LDA
    cpu.setA(0x8Cu, 16);
    goto L_809FF9;
L_809FF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FF9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FF9u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809FF9 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_809FFC;
L_809FFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFCu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FFCu, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809FFC JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9FFFu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA000u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x809FFCu); }
    goto L_80A000;
L_80A000:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA000u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA000u,0x80A000u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA000u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA000u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A000 SEP
    cpu.sep(0x20u);
    goto L_80A002;
L_80A002:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA002u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA002u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA002u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A002 LDA
    cpu.setA(0x7Eu, 8);
    goto L_80A004;
L_80A004:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA004u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA004u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA004u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A004 PHA
    cpu.push("PHA", hw);
    goto L_80A005;
L_80A005:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA005u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA005u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA005u, 5u, 3u, cpu.address("abs", 0x8000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A005 PEA
    cpu.push16Value(hw, 0x8000u);
    goto L_80A008;
L_80A008:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA008u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA008u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA008u, 5u, 3u, cpu.address("abs", 0x6000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A008 PEA
    cpu.push16Value(hw, 0x6000u);
    goto L_80A00B;
L_80A00B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA00Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA00Bu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA00Bu, 5u, 3u, cpu.address("abs", 0x2000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A00B PEA
    cpu.push16Value(hw, 0x2000u);
    goto L_80A00E;
L_80A00E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA00Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA00Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA00Eu, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A00E JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA011u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA012u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x80A00Eu); }
    goto L_80A012;
L_80A012:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA012u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA012u,0x80A012u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA012u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA012u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A012 LDA
    cpu.setA(0x8000u, 16);
    goto L_80A015;
L_80A015:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA015u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA015u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA015u, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A015 STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_80A018;
L_80A018:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA018u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA018u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA018u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A018 LDA
    cpu.setA(0x9Cu, 16);
    goto L_80A01B;
L_80A01B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA01Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA01Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA01Bu, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A01B STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_80A01E;
L_80A01E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA01Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA01Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA01Eu, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A01E JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA021u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA022u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x80A01Eu); }
    goto L_80A022;
L_80A022:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA022u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA022u,0x80A022u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA022u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA022u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A022 SEP
    cpu.sep(0x20u);
    goto L_80A024;
L_80A024:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA024u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA024u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA024u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A024 LDA
    cpu.setA(0x7Eu, 8);
    goto L_80A026;
L_80A026:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA026u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA026u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA026u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A026 PHA
    cpu.push("PHA", hw);
    goto L_80A027;
L_80A027:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA027u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA027u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA027u, 5u, 3u, cpu.address("abs", 0x8000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A027 PEA
    cpu.push16Value(hw, 0x8000u);
    goto L_80A02A;
L_80A02A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA02Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA02Au,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA02Au, 5u, 3u, cpu.address("abs", 0x2000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A02A PEA
    cpu.push16Value(hw, 0x2000u);
    goto L_80A02D;
L_80A02D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA02Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA02Du,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA02Du, 5u, 3u, cpu.address("abs", 0x6000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A02D PEA
    cpu.push16Value(hw, 0x6000u);
    goto L_80A030;
L_80A030:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA030u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA030u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA030u, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A030 JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA033u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA034u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x80A030u); }
    goto L_80A034;
L_80A034:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA034u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA034u,0x80A034u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA034u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA034u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A034 LDA
    cpu.setA(0x906Cu, 16);
    goto L_80A037;
L_80A037:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA037u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA037u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA037u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A037 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80A039;
L_80A039:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA039u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA039u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA039u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A039 LDA
    cpu.setA(0x8Au, 16);
    goto L_80A03C;
L_80A03C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA03Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA03Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA03Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A03C STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_80A03E;
L_80A03E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA03Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA03Eu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA03Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A03E LDX
    cpu.setX(0x0u, 16);
    goto L_80A041;
L_80A041:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA041u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA041u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA041u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A041 LDY
    cpu.setY(0x200u, 16);
    goto L_80A044;
L_80A044:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA044u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA044u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA044u, 8u, 4u, 0x808BB9u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A044 JSL -> $808BB9 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA047u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA048u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808BB9u, 0x80A044u); }
    goto L_80A048;
L_80A048:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA048u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA048u,0x80A048u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA048u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA048u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A048 LDA
    cpu.setA(0xBBBEu, 16);
    goto L_80A04B;
L_80A04B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA04Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA04Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA04Bu, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A04B STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_80A04E;
L_80A04E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA04Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA04Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA04Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A04E LDA
    cpu.setA(0x8Au, 16);
    goto L_80A051;
L_80A051:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA051u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA051u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA051u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A051 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_80A054;
L_80A054:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA054u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA054u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA054u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A054 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA057u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA058u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x80A054u); }
    goto L_80A058;
L_80A058:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA058u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA058u,0x80A058u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA058u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA058u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A058 PHB
    cpu.push("PHB", hw);
    goto L_80A059;
L_80A059:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA059u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA059u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA059u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A059 LDX
    cpu.setX(0x8000u, 16);
    goto L_80A05C;
L_80A05C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA05Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA05Cu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA05Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A05C LDY
    cpu.setY(0x2800u, 16);
    goto L_80A05F;
L_80A05F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA05Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA05Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA05Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A05F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A061;
L_80A061:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA061u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA061u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA061u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A061 DEC
    cpu.decReg('A');
    goto L_80A062;
L_80A062:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA062u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA062u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xA062u, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $80A062 MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_80A065;
L_80A065:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA065u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA065u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA065u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A065 PLB
    cpu.pop("PLB", hw);
    goto L_80A066;
L_80A066:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA066u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA066u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA066u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A066 LDA
    cpu.setA(0xB76Au, 16);
    goto L_80A069;
L_80A069:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA069u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA069u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA069u, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A069 STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_80A06C;
L_80A06C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA06Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA06Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA06Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A06C LDA
    cpu.setA(0x8Bu, 16);
    goto L_80A06F;
L_80A06F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA06Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA06Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA06Fu, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A06F STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_80A072;
L_80A072:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA072u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA072u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA072u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A072 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA075u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA076u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x80A072u); }
    goto L_80A076;
L_80A076:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA076u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA076u,0x80A076u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA076u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA076u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A076 PHB
    cpu.push("PHB", hw);
    goto L_80A077;
L_80A077:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA077u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA077u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA077u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A077 LDX
    cpu.setX(0x8000u, 16);
    goto L_80A07A;
L_80A07A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA07Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA07Au,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA07Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A07A LDY
    cpu.setY(0x4000u, 16);
    goto L_80A07D;
L_80A07D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA07Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA07Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA07Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A07D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A07F;
L_80A07F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA07Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA07Fu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA07Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A07F DEC
    cpu.decReg('A');
    goto L_80A080;
L_80A080:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA080u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA080u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xA080u, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $80A080 MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_80A083;
L_80A083:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA083u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA083u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA083u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A083 PLB
    cpu.pop("PLB", hw);
    goto L_80A084;
L_80A084:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA084u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA084u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA084u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A084 LDA
    cpu.setA(0x89D5u, 16);
    goto L_80A087;
L_80A087:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA087u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA087u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA087u, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A087 STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_80A08A;
L_80A08A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA08Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA08Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA08Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A08A LDA
    cpu.setA(0x89u, 16);
    goto L_80A08D;
L_80A08D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA08Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA08Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA08Du, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A08D STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_80A090;
L_80A090:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA090u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA090u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA090u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A090 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA093u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA094u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x80A090u); }
    goto L_80A094;
L_80A094:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA094u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA094u,0x80A094u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA094u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA094u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A094 PHB
    cpu.push("PHB", hw);
    goto L_80A095;
L_80A095:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA095u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA095u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA095u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A095 LDX
    cpu.setX(0x8000u, 16);
    goto L_80A098;
L_80A098:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA098u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA098u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA098u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A098 LDY
    cpu.setY(0x6000u, 16);
    goto L_80A09B;
L_80A09B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA09Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA09Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA09Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A09B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A09D;
L_80A09D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA09Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA09Du,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA09Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A09D DEC
    cpu.decReg('A');
    goto L_80A09E;
L_80A09E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA09Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA09Eu,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xA09Eu, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $80A09E MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_80A0A1;
L_80A0A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0A1u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0A1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A0A1 PLB
    cpu.pop("PLB", hw);
    goto L_80A0A2;
L_80A0A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0A2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0A2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A0A2 LDA
    cpu.setA(0xFFFFu, 16);
    goto L_80A0A5;
L_80A0A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0A5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0A5u, 8u, 4u, 0x80A460u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A0A5 JSL -> $80A460 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA0A8u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA0A9u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A460u, 0x80A0A5u); }
    goto L_80A0A9;
L_80A0A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0A9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA0A9u,0x80A0A9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0A9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0A9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A0A9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80A0A9u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80A0A9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80AE2A_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AE2Au: goto L_80AE2A;
    case 0x80AE2Du: goto L_80AE2D;
    case 0x80AE2Fu: goto L_80AE2F;
    case 0x80AE32u: goto L_80AE32;
    case 0x80AE35u: goto L_80AE35;
    case 0x80AE37u: goto L_80AE37;
    case 0x80AE3Au: goto L_80AE3A;
    case 0x80AE3Du: goto L_80AE3D;
    case 0x80AE40u: goto L_80AE40;
    case 0x80AE43u: goto L_80AE43;
    case 0x80AE46u: goto L_80AE46;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AE2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE2Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE2Au, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE2A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AE2D;
L_80AE2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE2Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE2Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE2D BEQ -> $80AE40
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AE40; }
    goto L_80AE2F;
L_80AE2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE2Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE2Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE2F LDX
    cpu.setX(0x41Au, 16);
    goto L_80AE32;
L_80AE32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE32u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE32u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE32 LDA
    cpu.setA(0x3u, 16);
    goto L_80AE35;
L_80AE35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE35u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE35u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE35 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80AE37;
L_80AE37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE37u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE37u, 8u, 3u, cpu.address("abs", 0x0986u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE37 INC
    cpu.incMem(hw, cpu.address("abs", 0x986u), cpu.m8?8:16);
    goto L_80AE3A;
L_80AE3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Au, 6u, 3u, cpu.address("abs", 0xC7F6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AE3A JSR -> $80C7F6 stack real
    { cpu.push16Value(hw,0xAE3Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE3Du,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC7F6u), 0x80AE3Au); }
    goto L_80AE3D;
L_80AE3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE3Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE3Du,0x80AE3Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Du, 6u, 3u, cpu.address("abs", 0xC404u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AE3D JSR -> $80C404 stack real
    { cpu.push16Value(hw,0xAE3Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE40u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC404u), 0x80AE3Du); }
    goto L_80AE40;
L_80AE40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE40u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE40u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE40u, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE40 STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80AE43;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE40u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE40u, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE40 STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80AE43;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE40u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE40u, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE40 STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80AE43;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE40u,0x80AE40u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AE43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE43u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE43u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE43u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE43 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AE46;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE43u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE43u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE43 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AE46;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE43u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE43u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE43 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AE46;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE43u,0x80AE43u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AE46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE46u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE46u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE46u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AE46 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AE46u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AE46u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE46u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE46u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AE46 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AE46u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AE46u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE46u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE46u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AE46 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AE46u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AE46u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE46u,0x80AE46u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_8292D4_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8292D4u: goto L_8292D4;
    case 0x8292D7u: goto L_8292D7;
    case 0x8292D9u: goto L_8292D9;
    case 0x8292DCu: goto L_8292DC;
    case 0x8292DFu: goto L_8292DF;
    case 0x8292E2u: goto L_8292E2;
    case 0x8292E5u: goto L_8292E5;
    case 0x8292E8u: goto L_8292E8;
    case 0x8292EAu: goto L_8292EA;
    case 0x8292ECu: goto L_8292EC;
    case 0x8292EEu: goto L_8292EE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8292D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92D4u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92D4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292D4 LDX
    cpu.setX(0x0u, 16);
    goto L_8292D7;
L_8292D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92D7u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92D7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292D7 STX
    hw.write(cpu.address("dp", 0x5Bu), cpu.x, cpu.x8?8:16);
    goto L_8292D9;
L_8292D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92D9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92D9u, 6u, 3u, cpu.address("abs", 0xA92Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8292D9 JSR -> $82A92A stack real
    { cpu.push16Value(hw,0x92DBu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x92DCu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA92Au), 0x8292D9u); }
    goto L_8292DC;
L_8292DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92DCu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92DCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92DCu, 6u, 3u, cpu.address("abs", 0xD2E6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8292DC JSR -> $82D2E6 stack real
    { cpu.push16Value(hw,0x92DEu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x92DFu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD2E6u), 0x8292DCu); }
    goto L_8292DF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92DCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92DCu, 6u, 3u, cpu.address("abs", 0xD2E6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8292DC JSR -> $82D2E6 stack real
    { cpu.push16Value(hw,0x92DEu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x92DFu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD2E6u), 0x8292DCu); }
    goto L_8292DF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x92DCu,0x8292DCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8292DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92DFu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x92DFu,0x8292DFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92DFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92DFu, 6u, 3u, cpu.address("abs", 0xA5D0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8292DF JSR -> $82A5D0 stack real
    { cpu.push16Value(hw,0x92E1u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x92E2u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA5D0u), 0x8292DFu); }
    goto L_8292E2;
L_8292E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92E2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x92E2u,0x8292E2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92E2u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92E2u, 8u, 3u, cpu.address("abs", 0x02E6u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292E2 INC
    cpu.incMem(hw, cpu.address("abs", 0x2E6u), cpu.m8?8:16);
    goto L_8292E5;
L_8292E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92E5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92E5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292E5 LDA
    cpu.setA(0x80u, 16);
    goto L_8292E8;
L_8292E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92E8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92E8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292E8 STA
    hw.write(cpu.address("dp", 0x6Fu), cpu.a, cpu.m8?8:16);
    goto L_8292EA;
L_8292EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92EAu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92EAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292EA SEP
    cpu.sep(0x20u);
    goto L_8292EC;
L_8292EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92ECu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92ECu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8292EC INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_8292EE;
L_8292EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92EEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92EEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8292EE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8292EEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8292EEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_829B0B_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829B0Bu: goto L_829B0B;
    case 0x829B0Eu: goto L_829B0E;
    case 0x829B0Fu: goto L_829B0F;
    case 0x829B12u: goto L_829B12;
    case 0x829B14u: goto L_829B14;
    case 0x829B17u: goto L_829B17;
    case 0x829B19u: goto L_829B19;
    case 0x829B1Du: goto L_829B1D;
    case 0x829B1Fu: goto L_829B1F;
    case 0x829B22u: goto L_829B22;
    case 0x829B24u: goto L_829B24;
    case 0x829B27u: goto L_829B27;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829B0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B0Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B0Bu, 5u, 3u, cpu.address("abs", 0x02D0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B0B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2D0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829B0E;
L_829B0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B0Eu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B0Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B0E SEC
    cpu.setFlag('C', true);
    goto L_829B0F;
L_829B0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B0Fu,cpu,0xEDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B0Fu, 5u, 3u, cpu.address("abs", 0x02D4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B0F SBC
    cpu.sbc(hw.readW(cpu.address("abs", 0x2D4u), cpu.m8?8:16));
    goto L_829B12;
L_829B12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B12u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B12u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B12 STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_829B14;
L_829B14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B14u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B14u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B14 LDA
    cpu.setA(0x3E8u, 16);
    goto L_829B17;
L_829B17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B17u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B17u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B17 STA
    hw.write(cpu.address("dp", 0x38u), cpu.a, cpu.m8?8:16);
    goto L_829B19;
L_829B19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B19u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B19u, 8u, 4u, 0x809472u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829B19 JSL -> $809472 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9B1Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9B1Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809472u, 0x829B19u); }
    goto L_829B1D;
L_829B1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B1Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9B1Du,0x829B1Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B1Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B1Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B1D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829B1F;
L_829B1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B1Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B1Fu, 5u, 3u, cpu.address("abs", 0x0156u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B1F STA
    hw.write(cpu.address("abs", 0x156u), cpu.a, cpu.m8?8:16);
    goto L_829B22;
L_829B22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B22u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B22u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B22 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x38u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829B24;
L_829B24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B24u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B24u, 5u, 3u, cpu.address("abs", 0x0158u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B24 STA
    hw.write(cpu.address("abs", 0x158u), cpu.a, cpu.m8?8:16);
    goto L_829B27;
L_829B27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B27u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B27u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829B27 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829B27u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829B27u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_829B0B_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829B0Bu: goto L_829B0B;
    case 0x829B0Eu: goto L_829B0E;
    case 0x829B0Fu: goto L_829B0F;
    case 0x829B12u: goto L_829B12;
    case 0x829B14u: goto L_829B14;
    case 0x829B17u: goto L_829B17;
    case 0x829B19u: goto L_829B19;
    case 0x829B1Du: goto L_829B1D;
    case 0x829B1Fu: goto L_829B1F;
    case 0x829B22u: goto L_829B22;
    case 0x829B24u: goto L_829B24;
    case 0x829B27u: goto L_829B27;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829B0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B0Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B0Bu, 5u, 3u, cpu.address("abs", 0x02D0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B0B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2D0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829B0E;
L_829B0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B0Eu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B0Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B0E SEC
    cpu.setFlag('C', true);
    goto L_829B0F;
L_829B0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B0Fu,cpu,0xEDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B0Fu, 5u, 3u, cpu.address("abs", 0x02D4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B0F SBC
    cpu.sbc(hw.readW(cpu.address("abs", 0x2D4u), cpu.m8?8:16));
    goto L_829B12;
L_829B12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B12u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B12u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B12 STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_829B14;
L_829B14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B14u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B14u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B14 LDA
    cpu.setA(0x3E8u, 16);
    goto L_829B17;
L_829B17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B17u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B17u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B17 STA
    hw.write(cpu.address("dp", 0x38u), cpu.a, cpu.m8?8:16);
    goto L_829B19;
L_829B19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B19u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B19u, 8u, 4u, 0x809472u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829B19 JSL -> $809472 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9B1Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9B1Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809472u, 0x829B19u); }
    goto L_829B1D;
L_829B1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B1Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9B1Du,0x829B1Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B1Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B1Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B1D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829B1F;
L_829B1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B1Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B1Fu, 5u, 3u, cpu.address("abs", 0x0156u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B1F STA
    hw.write(cpu.address("abs", 0x156u), cpu.a, cpu.m8?8:16);
    goto L_829B22;
L_829B22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B22u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B22u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B22 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x38u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829B24;
L_829B24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B24u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B24u, 5u, 3u, cpu.address("abs", 0x0158u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B24 STA
    hw.write(cpu.address("abs", 0x158u), cpu.a, cpu.m8?8:16);
    goto L_829B27;
L_829B27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B27u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B27u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829B27 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829B27u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829B27u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82A560_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82A560u: goto L_82A560;
    case 0x82A562u: goto L_82A562;
    case 0x82A563u: goto L_82A563;
    case 0x82A565u: goto L_82A565;
    case 0x82A566u: goto L_82A566;
    case 0x82A567u: goto L_82A567;
    case 0x82A569u: goto L_82A569;
    case 0x82A56Bu: goto L_82A56B;
    case 0x82A56Cu: goto L_82A56C;
    case 0x82A56Fu: goto L_82A56F;
    case 0x82A571u: goto L_82A571;
    case 0x82A574u: goto L_82A574;
    case 0x82A576u: goto L_82A576;
    case 0x82A578u: goto L_82A578;
    case 0x82A57Bu: goto L_82A57B;
    case 0x82A57Du: goto L_82A57D;
    case 0x82A57Fu: goto L_82A57F;
    case 0x82A582u: goto L_82A582;
    case 0x82A584u: goto L_82A584;
    case 0x82A585u: goto L_82A585;
    case 0x82A586u: goto L_82A586;
    case 0x82A588u: goto L_82A588;
    case 0x82A589u: goto L_82A589;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82A560:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA560u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA560u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA560u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A560 SEP
    cpu.sep(0x20u);
    goto L_82A562;
L_82A562:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA562u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA562u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA562u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82A562 PHB
    cpu.push("PHB", hw);
    goto L_82A563;
L_82A563:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA563u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA563u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA563u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x69u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A563 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x69u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A565;
L_82A565:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA565u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA565u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA565u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82A565 PHA
    cpu.push("PHA", hw);
    goto L_82A566;
L_82A566:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA566u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA566u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA566u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82A566 PLB
    cpu.pop("PLB", hw);
    goto L_82A567;
L_82A567:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA567u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA567u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA567u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A567 REP
    cpu.rep(0x20u);
    goto L_82A569;
L_82A569:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA569u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA569u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA569u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x67u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A569 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A56B;
L_82A56B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA56Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A56B CLC
    cpu.setFlag('C', false);
    goto L_82A56C;
L_82A56C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA56Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A56C ADC
    cpu.adc(0x16u);
    goto L_82A56F;
L_82A56F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA56Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A56F STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82A571;
L_82A571:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA571u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA571u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA571u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A571 LDY
    cpu.setY(0x1F8u, 16);
    goto L_82A574;
L_82A574:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA574u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA574u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA574u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82A574 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A576;
L_82A576:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA576u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA576u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA576u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A576 BPL -> $82A584
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82A584; }
    goto L_82A578;
L_82A578:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA578u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA578u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA578u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A578 CMP
    cpu.compareA(0xFFFFu);
    goto L_82A57B;
L_82A57B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA57Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A57B BEQ -> $82A584
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A584; }
    goto L_82A57D;
L_82A57D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA57Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Du,cpu,0x91u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Du, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82A57D STA
    hw.write(cpu.addressDpIndirectY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82A57F;
L_82A57F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA57Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A57F LDA
    cpu.setA(0x0u, 16);
    goto L_82A582;
L_82A582:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA582u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA582u,cpu,0x91u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA582u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82A582 STA
    hw.write(cpu.addressDpIndirectY(hw, 0x67u), cpu.a, cpu.m8?8:16);
    goto L_82A584;
L_82A584:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA584u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA584u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA584u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A584 DEY
    cpu.decReg('Y');
    goto L_82A585;
L_82A585:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA585u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA585u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA585u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A585 DEY
    cpu.decReg('Y');
    goto L_82A586;
L_82A586:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA586u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA586u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA586u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A586 BPL -> $82A574
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82A574; }
    goto L_82A588;
L_82A588:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA588u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA588u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA588u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82A588 PLB
    cpu.pop("PLB", hw);
    goto L_82A589;
L_82A589:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA589u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA589u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA589u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A589 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A589u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A589u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82A84E_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82A84Eu: goto L_82A84E;
    case 0x82A850u: goto L_82A850;
    case 0x82A853u: goto L_82A853;
    case 0x82A855u: goto L_82A855;
    case 0x82A858u: goto L_82A858;
    case 0x82A85Au: goto L_82A85A;
    case 0x82A85Du: goto L_82A85D;
    case 0x82A85Fu: goto L_82A85F;
    case 0x82A863u: goto L_82A863;
    case 0x82A865u: goto L_82A865;
    case 0x82A868u: goto L_82A868;
    case 0x82A869u: goto L_82A869;
    case 0x82A86Au: goto L_82A86A;
    case 0x82A86Eu: goto L_82A86E;
    case 0x82A86Fu: goto L_82A86F;
    case 0x82A871u: goto L_82A871;
    case 0x82A874u: goto L_82A874;
    case 0x82A876u: goto L_82A876;
    case 0x82A877u: goto L_82A877;
    case 0x82A87Au: goto L_82A87A;
    case 0x82A87Cu: goto L_82A87C;
    case 0x82A87Fu: goto L_82A87F;
    case 0x82A882u: goto L_82A882;
    case 0x82A884u: goto L_82A884;
    case 0x82A887u: goto L_82A887;
    case 0x82A889u: goto L_82A889;
    case 0x82A88Cu: goto L_82A88C;
    case 0x82A88Du: goto L_82A88D;
    case 0x82A88Fu: goto L_82A88F;
    case 0x82A892u: goto L_82A892;
    case 0x82A894u: goto L_82A894;
    case 0x82A897u: goto L_82A897;
    case 0x82A898u: goto L_82A898;
    case 0x82A899u: goto L_82A899;
    case 0x82A89Du: goto L_82A89D;
    case 0x82A8A0u: goto L_82A8A0;
    case 0x82A8A3u: goto L_82A8A3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82A84E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA84Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA84Eu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA84Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A84E LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A850;
L_82A850:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA850u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA850u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA850u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A850 LDA
    cpu.setA(0x0u, 16);
    goto L_82A853;
L_82A853:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA853u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA853u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA853u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x37u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A853 STA
    hw.write(cpu.address("dp", 0x37u), cpu.a, cpu.m8?8:16);
    goto L_82A855;
L_82A855:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA855u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA855u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA855u, 5u + 1u, 3u, cpu.address("absy", 0x02A0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A855 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2A0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A858;
L_82A858:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA858u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA858u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA858u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A858 STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_82A85A;
L_82A85A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA85Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A85A LDA
    cpu.setA(0xFu, 16);
    goto L_82A85D;
L_82A85D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA85Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x39u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A85D STA
    hw.write(cpu.address("dp", 0x39u), cpu.a, cpu.m8?8:16);
    goto L_82A85F;
L_82A85F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA85Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Fu, 8u, 4u, 0x809436u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82A85F JSL -> $809436 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA862u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA863u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809436u, 0x82A85Fu); }
    goto L_82A863;
L_82A863:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA863u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA863u,0x82A863u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA863u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA863u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A863 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A865;
L_82A865:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA865u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA865u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA865u, 5u + 1u, 3u, cpu.address("absy", 0x02A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A865 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2A2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A868;
L_82A868:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA868u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA868u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA868u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A868 ASL
    cpu.aslA();
    goto L_82A869;
L_82A869:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA869u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA869u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA869u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A869 TAX
    cpu.transfer("TAX");
    goto L_82A86A;
L_82A86A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA86Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA86Au,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA86Au, 6u, 4u, ((0x82A8D4u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A86A LDA
    cpu.loadA(hw.readW(((0x82A8D4u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A86E;
L_82A86E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA86Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA86Eu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA86Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A86E CLC
    cpu.setFlag('C', false);
    goto L_82A86F;
L_82A86F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA86Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA86Fu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA86Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A86F ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16));
    goto L_82A871;
L_82A871:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA871u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA871u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA871u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A871 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x135u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A874;
L_82A874:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA874u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA874u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA874u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A874 BNE -> $82A87A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A87A; }
    goto L_82A876;
L_82A876:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA876u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA876u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA876u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A876 CLC
    cpu.setFlag('C', false);
    goto L_82A877;
L_82A877:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA877u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA877u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA877u, 5u + 1u, 3u, cpu.address("absy", 0x02D2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A877 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x2D2u), cpu.m8?8:16));
    goto L_82A87A;
L_82A87A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA87Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A87A STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_82A87C;
L_82A87C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA87Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Cu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Cu, 6u, 3u, cpu.address("absy", 0x02A4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A87C STA
    hw.write(cpu.address("absy", 0x2A4u), cpu.a, cpu.m8?8:16);
    goto L_82A87F;
L_82A87F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA87Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Fu, 5u + 1u, 3u, cpu.address("absy", 0x0410u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A87F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x410u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A882;
L_82A882:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA882u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA882u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA882u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A882 BEQ -> $82A889
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A889; }
    goto L_82A884;
L_82A884:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA884u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA884u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA884u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A884 LDA
    cpu.setA(0xBu, 16);
    goto L_82A887;
L_82A887:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA887u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA887u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA887u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A887 BRA -> $82A88C
    goto L_82A88C;
L_82A889:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA889u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA889u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA889u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A889 LDA
    cpu.setA(0x0u, 16);
    goto L_82A88C;
L_82A88C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA88Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Cu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A88C CLC
    cpu.setFlag('C', false);
    goto L_82A88D;
L_82A88D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA88Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Du,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A88D ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16));
    goto L_82A88F;
L_82A88F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA88Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A88F CMP
    cpu.compareA(0x18u);
    goto L_82A892;
L_82A892:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA892u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA892u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA892u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A892 BCC -> $82A897
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82A897; }
    goto L_82A894;
L_82A894:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA894u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA894u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA894u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A894 LDA
    cpu.setA(0x17u, 16);
    goto L_82A897;
L_82A897:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA897u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA897u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA897u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A897 ASL
    cpu.aslA();
    goto L_82A898;
L_82A898:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA898u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA898u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA898u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A898 TAX
    cpu.transfer("TAX");
    goto L_82A899;
L_82A899:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA899u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA899u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA899u, 6u, 4u, ((0x82A8A4u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A899 LDA
    cpu.loadA(hw.readW(((0x82A8A4u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A89D;
L_82A89D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA89Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA89Du,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA89Du, 6u, 3u, cpu.address("absy", 0x029Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A89D STA
    hw.write(cpu.address("absy", 0x29Cu), cpu.a, cpu.m8?8:16);
    goto L_82A8A0;
L_82A8A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A0u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A0u, 6u, 3u, cpu.address("absy", 0x029Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8A0 STA
    hw.write(cpu.address("absy", 0x29Eu), cpu.a, cpu.m8?8:16);
    goto L_82A8A3;
L_82A8A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A8A3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A8A3u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A8A3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82A84E_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82A84Eu: goto L_82A84E;
    case 0x82A850u: goto L_82A850;
    case 0x82A853u: goto L_82A853;
    case 0x82A855u: goto L_82A855;
    case 0x82A858u: goto L_82A858;
    case 0x82A85Au: goto L_82A85A;
    case 0x82A85Du: goto L_82A85D;
    case 0x82A85Fu: goto L_82A85F;
    case 0x82A863u: goto L_82A863;
    case 0x82A865u: goto L_82A865;
    case 0x82A868u: goto L_82A868;
    case 0x82A869u: goto L_82A869;
    case 0x82A86Au: goto L_82A86A;
    case 0x82A86Eu: goto L_82A86E;
    case 0x82A86Fu: goto L_82A86F;
    case 0x82A871u: goto L_82A871;
    case 0x82A874u: goto L_82A874;
    case 0x82A876u: goto L_82A876;
    case 0x82A877u: goto L_82A877;
    case 0x82A87Au: goto L_82A87A;
    case 0x82A87Cu: goto L_82A87C;
    case 0x82A87Fu: goto L_82A87F;
    case 0x82A882u: goto L_82A882;
    case 0x82A884u: goto L_82A884;
    case 0x82A887u: goto L_82A887;
    case 0x82A889u: goto L_82A889;
    case 0x82A88Cu: goto L_82A88C;
    case 0x82A88Du: goto L_82A88D;
    case 0x82A88Fu: goto L_82A88F;
    case 0x82A892u: goto L_82A892;
    case 0x82A894u: goto L_82A894;
    case 0x82A897u: goto L_82A897;
    case 0x82A898u: goto L_82A898;
    case 0x82A899u: goto L_82A899;
    case 0x82A89Du: goto L_82A89D;
    case 0x82A8A0u: goto L_82A8A0;
    case 0x82A8A3u: goto L_82A8A3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82A84E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA84Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA84Eu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA84Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A84E LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A850;
L_82A850:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA850u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA850u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA850u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A850 LDA
    cpu.setA(0x0u, 16);
    goto L_82A853;
L_82A853:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA853u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA853u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA853u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x37u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A853 STA
    hw.write(cpu.address("dp", 0x37u), cpu.a, cpu.m8?8:16);
    goto L_82A855;
L_82A855:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA855u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA855u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA855u, 5u + 1u, 3u, cpu.address("absy", 0x02A0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A855 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2A0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A858;
L_82A858:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA858u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA858u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA858u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A858 STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_82A85A;
L_82A85A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA85Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A85A LDA
    cpu.setA(0xFu, 16);
    goto L_82A85D;
L_82A85D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA85Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x39u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A85D STA
    hw.write(cpu.address("dp", 0x39u), cpu.a, cpu.m8?8:16);
    goto L_82A85F;
L_82A85F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA85Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA85Fu, 8u, 4u, 0x809436u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82A85F JSL -> $809436 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA862u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA863u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809436u, 0x82A85Fu); }
    goto L_82A863;
L_82A863:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA863u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA863u,0x82A863u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA863u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA863u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A863 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A865;
L_82A865:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA865u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA865u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA865u, 5u + 1u, 3u, cpu.address("absy", 0x02A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A865 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2A2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A868;
L_82A868:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA868u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA868u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA868u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A868 ASL
    cpu.aslA();
    goto L_82A869;
L_82A869:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA869u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA869u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA869u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A869 TAX
    cpu.transfer("TAX");
    goto L_82A86A;
L_82A86A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA86Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA86Au,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA86Au, 6u, 4u, ((0x82A8D4u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A86A LDA
    cpu.loadA(hw.readW(((0x82A8D4u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A86E;
L_82A86E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA86Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA86Eu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA86Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A86E CLC
    cpu.setFlag('C', false);
    goto L_82A86F;
L_82A86F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA86Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA86Fu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA86Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A86F ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16));
    goto L_82A871;
L_82A871:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA871u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA871u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA871u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A871 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x135u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A874;
L_82A874:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA874u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA874u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA874u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A874 BNE -> $82A87A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A87A; }
    goto L_82A876;
L_82A876:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA876u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA876u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA876u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A876 CLC
    cpu.setFlag('C', false);
    goto L_82A877;
L_82A877:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA877u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA877u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA877u, 5u + 1u, 3u, cpu.address("absy", 0x02D2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A877 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x2D2u), cpu.m8?8:16));
    goto L_82A87A;
L_82A87A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA87Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A87A STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_82A87C;
L_82A87C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA87Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Cu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Cu, 6u, 3u, cpu.address("absy", 0x02A4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A87C STA
    hw.write(cpu.address("absy", 0x2A4u), cpu.a, cpu.m8?8:16);
    goto L_82A87F;
L_82A87F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA87Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA87Fu, 5u + 1u, 3u, cpu.address("absy", 0x0410u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A87F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x410u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A882;
L_82A882:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA882u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA882u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA882u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A882 BEQ -> $82A889
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A889; }
    goto L_82A884;
L_82A884:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA884u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA884u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA884u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A884 LDA
    cpu.setA(0xBu, 16);
    goto L_82A887;
L_82A887:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA887u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA887u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA887u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A887 BRA -> $82A88C
    goto L_82A88C;
L_82A889:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA889u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA889u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA889u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A889 LDA
    cpu.setA(0x0u, 16);
    goto L_82A88C;
L_82A88C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA88Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Cu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A88C CLC
    cpu.setFlag('C', false);
    goto L_82A88D;
L_82A88D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA88Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Du,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A88D ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16));
    goto L_82A88F;
L_82A88F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA88Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA88Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A88F CMP
    cpu.compareA(0x18u);
    goto L_82A892;
L_82A892:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA892u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA892u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA892u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A892 BCC -> $82A897
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82A897; }
    goto L_82A894;
L_82A894:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA894u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA894u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA894u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A894 LDA
    cpu.setA(0x17u, 16);
    goto L_82A897;
L_82A897:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA897u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA897u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA897u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A897 ASL
    cpu.aslA();
    goto L_82A898;
L_82A898:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA898u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA898u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA898u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A898 TAX
    cpu.transfer("TAX");
    goto L_82A899;
L_82A899:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA899u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA899u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA899u, 6u, 4u, ((0x82A8A4u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A899 LDA
    cpu.loadA(hw.readW(((0x82A8A4u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A89D;
L_82A89D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA89Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA89Du,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA89Du, 6u, 3u, cpu.address("absy", 0x029Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A89D STA
    hw.write(cpu.address("absy", 0x29Cu), cpu.a, cpu.m8?8:16);
    goto L_82A8A0;
L_82A8A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A0u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A0u, 6u, 3u, cpu.address("absy", 0x029Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8A0 STA
    hw.write(cpu.address("absy", 0x29Eu), cpu.a, cpu.m8?8:16);
    goto L_82A8A3;
L_82A8A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8A3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A8A3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A8A3u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A8A3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82A8DA_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82A8DAu: goto L_82A8DA;
    case 0x82A8DCu: goto L_82A8DC;
    case 0x82A8DEu: goto L_82A8DE;
    case 0x82A8E1u: goto L_82A8E1;
    case 0x82A8E2u: goto L_82A8E2;
    case 0x82A8E4u: goto L_82A8E4;
    case 0x82A8E7u: goto L_82A8E7;
    case 0x82A8E9u: goto L_82A8E9;
    case 0x82A8ECu: goto L_82A8EC;
    case 0x82A8EEu: goto L_82A8EE;
    case 0x82A8F0u: goto L_82A8F0;
    case 0x82A8F2u: goto L_82A8F2;
    case 0x82A8F4u: goto L_82A8F4;
    case 0x82A8F7u: goto L_82A8F7;
    case 0x82A8F9u: goto L_82A8F9;
    case 0x82A8FCu: goto L_82A8FC;
    case 0x82A8FFu: goto L_82A8FF;
    case 0x82A902u: goto L_82A902;
    case 0x82A903u: goto L_82A903;
    case 0x82A906u: goto L_82A906;
    case 0x82A908u: goto L_82A908;
    case 0x82A90Bu: goto L_82A90B;
    case 0x82A90Du: goto L_82A90D;
    case 0x82A90Eu: goto L_82A90E;
    case 0x82A911u: goto L_82A911;
    case 0x82A913u: goto L_82A913;
    case 0x82A916u: goto L_82A916;
    case 0x82A919u: goto L_82A919;
    case 0x82A91Cu: goto L_82A91C;
    case 0x82A91Du: goto L_82A91D;
    case 0x82A920u: goto L_82A920;
    case 0x82A923u: goto L_82A923;
    case 0x82A926u: goto L_82A926;
    case 0x82A929u: goto L_82A929;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82A8DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DAu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8DA LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A8DC;
L_82A8DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8DC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A8DE;
L_82A8DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8DE AND
    cpu.logicAnd(0x4040u);
    goto L_82A8E1;
L_82A8E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8E1 ASL
    cpu.aslA();
    goto L_82A8E2;
L_82A8E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E2u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E2u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA8u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8E2 TSB
    cpu.tsb(hw, cpu.address("dp", 0xA8u), cpu.m8?8:16);
    goto L_82A8E4;
L_82A8E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E4u, 5u + 1u, 3u, cpu.address("absx", 0x0410u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8E4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x410u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A8E7;
L_82A8E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8E7 BEQ -> $82A8F0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A8F0; }
    goto L_82A8E9;
L_82A8E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8E9 LDA
    cpu.setA(0x400u, 16);
    goto L_82A8EC;
L_82A8EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8ECu,cpu,0x14u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8ECu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA8u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8EC TRB
    cpu.trb(hw, cpu.address("dp", 0xA8u), cpu.m8?8:16);
    goto L_82A8EE;
L_82A8EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8EEu,cpu,0x14u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8EEu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xAAu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8EE TRB
    cpu.trb(hw, cpu.address("dp", 0xAAu), cpu.m8?8:16);
    goto L_82A8F0;
L_82A8F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xAAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8F0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A8F2;
L_82A8F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xACu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8F2 STA
    hw.write(cpu.address("dp", 0xACu), cpu.a, cpu.m8?8:16);
    goto L_82A8F4;
L_82A8F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8F4 AND
    cpu.logicAnd(0x300u);
    goto L_82A8F7;
L_82A8F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8F7 BNE -> $82A903
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A903; }
    goto L_82A8F9;
L_82A8F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8F9 LDA
    cpu.setA(0x0u, 16);
    goto L_82A8FC;
L_82A8FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FCu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FCu, 6u, 3u, cpu.address("absx", 0x0202u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8FC STA
    hw.write(cpu.address("absx", 0x202u), cpu.a, cpu.m8?8:16);
    goto L_82A8FF;
L_82A8FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FFu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FFu, 6u, 3u, cpu.address("absx", 0x0204u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8FF STA
    hw.write(cpu.address("absx", 0x204u), cpu.a, cpu.m8?8:16);
    goto L_82A902;
L_82A902:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA902u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA902u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA902u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A902 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A902u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A902u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82A903:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA903u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA903u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA903u, 9u, 3u, cpu.address("absx", 0x0202u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A903 DEC
    cpu.decMem(hw, cpu.address("absx", 0x202u), cpu.m8?8:16);
    goto L_82A906;
L_82A906:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA906u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA906u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA906u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A906 BMI -> $82A90E
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82A90E; }
    goto L_82A908;
L_82A908:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA908u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA908u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA908u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A908 LDA
    cpu.setA(0x300u, 16);
    goto L_82A90B;
L_82A90B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA90Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Bu,cpu,0x14u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Bu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xAAu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A90B TRB
    cpu.trb(hw, cpu.address("dp", 0xAAu), cpu.m8?8:16);
    goto L_82A90D;
L_82A90D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA90Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A90D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A90Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A90Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82A90E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA90Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Eu, 5u + 1u, 3u, cpu.address("absx", 0x0204u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A90E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x204u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A911;
L_82A911:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA911u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA911u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA911u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A911 BNE -> $82A91D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A91D; }
    goto L_82A913;
L_82A913:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA913u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA913u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA913u, 9u, 3u, cpu.address("absx", 0x0204u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A913 INC
    cpu.incMem(hw, cpu.address("absx", 0x204u), cpu.m8?8:16);
    goto L_82A916;
L_82A916:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA916u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA916u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA916u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A916 LDA
    cpu.setA(0xBu, 16);
    goto L_82A919;
L_82A919:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA919u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA919u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA919u, 6u, 3u, cpu.address("absx", 0x0202u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A919 STA
    hw.write(cpu.address("absx", 0x202u), cpu.a, cpu.m8?8:16);
    goto L_82A91C;
L_82A91C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA91Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A91C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A91Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A91Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82A91D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA91Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A91D LDA
    cpu.setA(0x2u, 16);
    goto L_82A920;
L_82A920:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA920u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA920u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA920u, 6u, 3u, cpu.address("absx", 0x0202u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A920 STA
    hw.write(cpu.address("absx", 0x202u), cpu.a, cpu.m8?8:16);
    goto L_82A923;
L_82A923:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA923u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA923u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA923u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A923 LDA
    cpu.setA(0x2u, 16);
    goto L_82A926;
L_82A926:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA926u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA926u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA926u, 6u, 3u, cpu.address("absx", 0x0204u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A926 STA
    hw.write(cpu.address("absx", 0x204u), cpu.a, cpu.m8?8:16);
    goto L_82A929;
L_82A929:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA929u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA929u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA929u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A929 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A929u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A929u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82A8DA_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82A8DAu: goto L_82A8DA;
    case 0x82A8DCu: goto L_82A8DC;
    case 0x82A8DEu: goto L_82A8DE;
    case 0x82A8E1u: goto L_82A8E1;
    case 0x82A8E2u: goto L_82A8E2;
    case 0x82A8E4u: goto L_82A8E4;
    case 0x82A8E7u: goto L_82A8E7;
    case 0x82A8E9u: goto L_82A8E9;
    case 0x82A8ECu: goto L_82A8EC;
    case 0x82A8EEu: goto L_82A8EE;
    case 0x82A8F0u: goto L_82A8F0;
    case 0x82A8F2u: goto L_82A8F2;
    case 0x82A8F4u: goto L_82A8F4;
    case 0x82A8F7u: goto L_82A8F7;
    case 0x82A8F9u: goto L_82A8F9;
    case 0x82A8FCu: goto L_82A8FC;
    case 0x82A8FFu: goto L_82A8FF;
    case 0x82A902u: goto L_82A902;
    case 0x82A903u: goto L_82A903;
    case 0x82A906u: goto L_82A906;
    case 0x82A908u: goto L_82A908;
    case 0x82A90Bu: goto L_82A90B;
    case 0x82A90Du: goto L_82A90D;
    case 0x82A90Eu: goto L_82A90E;
    case 0x82A911u: goto L_82A911;
    case 0x82A913u: goto L_82A913;
    case 0x82A916u: goto L_82A916;
    case 0x82A919u: goto L_82A919;
    case 0x82A91Cu: goto L_82A91C;
    case 0x82A91Du: goto L_82A91D;
    case 0x82A920u: goto L_82A920;
    case 0x82A923u: goto L_82A923;
    case 0x82A926u: goto L_82A926;
    case 0x82A929u: goto L_82A929;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82A8DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DAu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8DA LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A8DC;
L_82A8DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8DC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A8DE;
L_82A8DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8DE AND
    cpu.logicAnd(0x4040u);
    goto L_82A8E1;
L_82A8E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8E1 ASL
    cpu.aslA();
    goto L_82A8E2;
L_82A8E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E2u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E2u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA8u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8E2 TSB
    cpu.tsb(hw, cpu.address("dp", 0xA8u), cpu.m8?8:16);
    goto L_82A8E4;
L_82A8E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E4u, 5u + 1u, 3u, cpu.address("absx", 0x0410u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8E4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x410u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A8E7;
L_82A8E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8E7 BEQ -> $82A8F0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A8F0; }
    goto L_82A8E9;
L_82A8E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8E9 LDA
    cpu.setA(0x400u, 16);
    goto L_82A8EC;
L_82A8EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8ECu,cpu,0x14u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8ECu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA8u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8EC TRB
    cpu.trb(hw, cpu.address("dp", 0xA8u), cpu.m8?8:16);
    goto L_82A8EE;
L_82A8EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8EEu,cpu,0x14u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8EEu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xAAu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8EE TRB
    cpu.trb(hw, cpu.address("dp", 0xAAu), cpu.m8?8:16);
    goto L_82A8F0;
L_82A8F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xAAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8F0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A8F2;
L_82A8F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xACu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8F2 STA
    hw.write(cpu.address("dp", 0xACu), cpu.a, cpu.m8?8:16);
    goto L_82A8F4;
L_82A8F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8F4 AND
    cpu.logicAnd(0x300u);
    goto L_82A8F7;
L_82A8F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8F7 BNE -> $82A903
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A903; }
    goto L_82A8F9;
L_82A8F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8F9 LDA
    cpu.setA(0x0u, 16);
    goto L_82A8FC;
L_82A8FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FCu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FCu, 6u, 3u, cpu.address("absx", 0x0202u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8FC STA
    hw.write(cpu.address("absx", 0x202u), cpu.a, cpu.m8?8:16);
    goto L_82A8FF;
L_82A8FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FFu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FFu, 6u, 3u, cpu.address("absx", 0x0204u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8FF STA
    hw.write(cpu.address("absx", 0x204u), cpu.a, cpu.m8?8:16);
    goto L_82A902;
L_82A902:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA902u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA902u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA902u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A902 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A902u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A902u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82A903:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA903u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA903u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA903u, 9u, 3u, cpu.address("absx", 0x0202u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A903 DEC
    cpu.decMem(hw, cpu.address("absx", 0x202u), cpu.m8?8:16);
    goto L_82A906;
L_82A906:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA906u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA906u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA906u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A906 BMI -> $82A90E
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82A90E; }
    goto L_82A908;
L_82A908:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA908u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA908u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA908u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A908 LDA
    cpu.setA(0x300u, 16);
    goto L_82A90B;
L_82A90B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA90Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Bu,cpu,0x14u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Bu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xAAu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A90B TRB
    cpu.trb(hw, cpu.address("dp", 0xAAu), cpu.m8?8:16);
    goto L_82A90D;
L_82A90D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA90Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A90D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A90Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A90Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82A90E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA90Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Eu, 5u + 1u, 3u, cpu.address("absx", 0x0204u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A90E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x204u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A911;
L_82A911:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA911u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA911u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA911u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A911 BNE -> $82A91D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A91D; }
    goto L_82A913;
L_82A913:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA913u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA913u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA913u, 9u, 3u, cpu.address("absx", 0x0204u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A913 INC
    cpu.incMem(hw, cpu.address("absx", 0x204u), cpu.m8?8:16);
    goto L_82A916;
L_82A916:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA916u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA916u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA916u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A916 LDA
    cpu.setA(0xBu, 16);
    goto L_82A919;
L_82A919:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA919u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA919u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA919u, 6u, 3u, cpu.address("absx", 0x0202u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A919 STA
    hw.write(cpu.address("absx", 0x202u), cpu.a, cpu.m8?8:16);
    goto L_82A91C;
L_82A91C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA91Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A91C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A91Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A91Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82A91D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA91Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A91D LDA
    cpu.setA(0x2u, 16);
    goto L_82A920;
L_82A920:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA920u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA920u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA920u, 6u, 3u, cpu.address("absx", 0x0202u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A920 STA
    hw.write(cpu.address("absx", 0x202u), cpu.a, cpu.m8?8:16);
    goto L_82A923;
L_82A923:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA923u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA923u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA923u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A923 LDA
    cpu.setA(0x2u, 16);
    goto L_82A926;
L_82A926:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA926u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA926u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA926u, 6u, 3u, cpu.address("absx", 0x0204u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A926 STA
    hw.write(cpu.address("absx", 0x204u), cpu.a, cpu.m8?8:16);
    goto L_82A929;
L_82A929:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA929u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA929u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA929u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A929 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A929u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A929u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82A8DA_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82A8DAu: goto L_82A8DA;
    case 0x82A8DCu: goto L_82A8DC;
    case 0x82A8DEu: goto L_82A8DE;
    case 0x82A8E1u: goto L_82A8E1;
    case 0x82A8E2u: goto L_82A8E2;
    case 0x82A8E4u: goto L_82A8E4;
    case 0x82A8E7u: goto L_82A8E7;
    case 0x82A8E9u: goto L_82A8E9;
    case 0x82A8ECu: goto L_82A8EC;
    case 0x82A8EEu: goto L_82A8EE;
    case 0x82A8F0u: goto L_82A8F0;
    case 0x82A8F2u: goto L_82A8F2;
    case 0x82A8F4u: goto L_82A8F4;
    case 0x82A8F7u: goto L_82A8F7;
    case 0x82A8F9u: goto L_82A8F9;
    case 0x82A8FCu: goto L_82A8FC;
    case 0x82A8FFu: goto L_82A8FF;
    case 0x82A902u: goto L_82A902;
    case 0x82A903u: goto L_82A903;
    case 0x82A906u: goto L_82A906;
    case 0x82A908u: goto L_82A908;
    case 0x82A90Bu: goto L_82A90B;
    case 0x82A90Du: goto L_82A90D;
    case 0x82A90Eu: goto L_82A90E;
    case 0x82A911u: goto L_82A911;
    case 0x82A913u: goto L_82A913;
    case 0x82A916u: goto L_82A916;
    case 0x82A919u: goto L_82A919;
    case 0x82A91Cu: goto L_82A91C;
    case 0x82A91Du: goto L_82A91D;
    case 0x82A920u: goto L_82A920;
    case 0x82A923u: goto L_82A923;
    case 0x82A926u: goto L_82A926;
    case 0x82A929u: goto L_82A929;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82A8DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DAu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8DA LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A8DC;
L_82A8DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8DC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A8DE;
L_82A8DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8DE AND
    cpu.logicAnd(0x4040u);
    goto L_82A8E1;
L_82A8E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8E1 ASL
    cpu.aslA();
    goto L_82A8E2;
L_82A8E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E2u,cpu,0x04u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E2u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA8u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8E2 TSB
    cpu.tsb(hw, cpu.address("dp", 0xA8u), cpu.m8?8:16);
    goto L_82A8E4;
L_82A8E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E4u, 5u + 1u, 3u, cpu.address("absx", 0x0410u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8E4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x410u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A8E7;
L_82A8E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8E7 BEQ -> $82A8F0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A8F0; }
    goto L_82A8E9;
L_82A8E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8E9 LDA
    cpu.setA(0x400u, 16);
    goto L_82A8EC;
L_82A8EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8ECu,cpu,0x14u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8ECu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA8u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8EC TRB
    cpu.trb(hw, cpu.address("dp", 0xA8u), cpu.m8?8:16);
    goto L_82A8EE;
L_82A8EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8EEu,cpu,0x14u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8EEu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xAAu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8EE TRB
    cpu.trb(hw, cpu.address("dp", 0xAAu), cpu.m8?8:16);
    goto L_82A8F0;
L_82A8F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xAAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8F0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A8F2;
L_82A8F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xACu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8F2 STA
    hw.write(cpu.address("dp", 0xACu), cpu.a, cpu.m8?8:16);
    goto L_82A8F4;
L_82A8F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8F4 AND
    cpu.logicAnd(0x300u);
    goto L_82A8F7;
L_82A8F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8F7 BNE -> $82A903
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A903; }
    goto L_82A8F9;
L_82A8F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8F9 LDA
    cpu.setA(0x0u, 16);
    goto L_82A8FC;
L_82A8FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FCu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FCu, 6u, 3u, cpu.address("absx", 0x0202u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8FC STA
    hw.write(cpu.address("absx", 0x202u), cpu.a, cpu.m8?8:16);
    goto L_82A8FF;
L_82A8FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FFu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FFu, 6u, 3u, cpu.address("absx", 0x0204u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A8FF STA
    hw.write(cpu.address("absx", 0x204u), cpu.a, cpu.m8?8:16);
    goto L_82A902;
L_82A902:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA902u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA902u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA902u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A902 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A902u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A902u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82A903:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA903u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA903u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA903u, 9u, 3u, cpu.address("absx", 0x0202u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A903 DEC
    cpu.decMem(hw, cpu.address("absx", 0x202u), cpu.m8?8:16);
    goto L_82A906;
L_82A906:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA906u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA906u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA906u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A906 BMI -> $82A90E
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82A90E; }
    goto L_82A908;
L_82A908:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA908u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA908u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA908u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A908 LDA
    cpu.setA(0x300u, 16);
    goto L_82A90B;
L_82A90B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA90Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Bu,cpu,0x14u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Bu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xAAu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A90B TRB
    cpu.trb(hw, cpu.address("dp", 0xAAu), cpu.m8?8:16);
    goto L_82A90D;
L_82A90D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA90Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A90D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A90Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A90Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82A90E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA90Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Eu, 5u + 1u, 3u, cpu.address("absx", 0x0204u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A90E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x204u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A911;
L_82A911:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA911u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA911u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA911u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A911 BNE -> $82A91D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A91D; }
    goto L_82A913;
L_82A913:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA913u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA913u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA913u, 9u, 3u, cpu.address("absx", 0x0204u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A913 INC
    cpu.incMem(hw, cpu.address("absx", 0x204u), cpu.m8?8:16);
    goto L_82A916;
L_82A916:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA916u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA916u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA916u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A916 LDA
    cpu.setA(0xBu, 16);
    goto L_82A919;
L_82A919:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA919u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA919u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA919u, 6u, 3u, cpu.address("absx", 0x0202u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A919 STA
    hw.write(cpu.address("absx", 0x202u), cpu.a, cpu.m8?8:16);
    goto L_82A91C;
L_82A91C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA91Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A91C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A91Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A91Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82A91D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA91Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A91D LDA
    cpu.setA(0x2u, 16);
    goto L_82A920;
L_82A920:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA920u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA920u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA920u, 6u, 3u, cpu.address("absx", 0x0202u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A920 STA
    hw.write(cpu.address("absx", 0x202u), cpu.a, cpu.m8?8:16);
    goto L_82A923;
L_82A923:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA923u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA923u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA923u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A923 LDA
    cpu.setA(0x2u, 16);
    goto L_82A926;
L_82A926:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA926u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA926u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA926u, 6u, 3u, cpu.address("absx", 0x0204u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A926 STA
    hw.write(cpu.address("absx", 0x204u), cpu.a, cpu.m8?8:16);
    goto L_82A929;
L_82A929:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA929u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA929u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA929u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A929 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A929u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A929u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B82E_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B82Eu: goto L_82B82E;
    case 0x82B831u: goto L_82B831;
    case 0x82B832u: goto L_82B832;
    case 0x82B833u: goto L_82B833;
    case 0x82B834u: goto L_82B834;
    case 0x82B836u: goto L_82B836;
    case 0x82B837u: goto L_82B837;
    case 0x82B83Au: goto L_82B83A;
    case 0x82B83Du: goto L_82B83D;
    case 0x82B840u: goto L_82B840;
    case 0x82B843u: goto L_82B843;
    case 0x82B846u: goto L_82B846;
    case 0x82B848u: goto L_82B848;
    case 0x82B84Au: goto L_82B84A;
    case 0x82B84Du: goto L_82B84D;
    case 0x82B84Fu: goto L_82B84F;
    case 0x82B851u: goto L_82B851;
    case 0x82B854u: goto L_82B854;
    case 0x82B857u: goto L_82B857;
    case 0x82B85Au: goto L_82B85A;
    case 0x82B85Du: goto L_82B85D;
    case 0x82B860u: goto L_82B860;
    case 0x82B861u: goto L_82B861;
    case 0x82B862u: goto L_82B862;
    case 0x82B863u: goto L_82B863;
    case 0x82B864u: goto L_82B864;
    case 0x82B867u: goto L_82B867;
    case 0x82B86Au: goto L_82B86A;
    case 0x82B86Cu: goto L_82B86C;
    case 0x82B86Du: goto L_82B86D;
    case 0x82B86Eu: goto L_82B86E;
    case 0x82B870u: goto L_82B870;
    case 0x82B873u: goto L_82B873;
    case 0x82B876u: goto L_82B876;
    case 0x82B879u: goto L_82B879;
    case 0x82B87Bu: goto L_82B87B;
    case 0x82B87Cu: goto L_82B87C;
    case 0x82B87Eu: goto L_82B87E;
    case 0x82B880u: goto L_82B880;
    case 0x82B882u: goto L_82B882;
    case 0x82B884u: goto L_82B884;
    case 0x82B887u: goto L_82B887;
    case 0x82B889u: goto L_82B889;
    case 0x82B88Cu: goto L_82B88C;
    case 0x82B88Du: goto L_82B88D;
    case 0x82B88Fu: goto L_82B88F;
    case 0x82B892u: goto L_82B892;
    case 0x82B894u: goto L_82B894;
    case 0x82B897u: goto L_82B897;
    case 0x82B899u: goto L_82B899;
    case 0x82B89Du: goto L_82B89D;
    case 0x82B89Fu: goto L_82B89F;
    case 0x82B8A1u: goto L_82B8A1;
    case 0x82B8A3u: goto L_82B8A3;
    case 0x82B8A5u: goto L_82B8A5;
    case 0x82B8A7u: goto L_82B8A7;
    case 0x82B8A8u: goto L_82B8A8;
    case 0x82B8ABu: goto L_82B8AB;
    case 0x82B8ACu: goto L_82B8AC;
    case 0x82B8AEu: goto L_82B8AE;
    case 0x82B8B1u: goto L_82B8B1;
    case 0x82B8B3u: goto L_82B8B3;
    case 0x82B8B5u: goto L_82B8B5;
    case 0x82B8B8u: goto L_82B8B8;
    case 0x82B8BAu: goto L_82B8BA;
    case 0x82B8BDu: goto L_82B8BD;
    case 0x82B8BEu: goto L_82B8BE;
    case 0x82B8C0u: goto L_82B8C0;
    case 0x82B8C3u: goto L_82B8C3;
    case 0x82B8C6u: goto L_82B8C6;
    case 0x82B8C9u: goto L_82B8C9;
    case 0x82B8CCu: goto L_82B8CC;
    case 0x82B8CFu: goto L_82B8CF;
    case 0x82B8D2u: goto L_82B8D2;
    case 0x82B8D4u: goto L_82B8D4;
    case 0x82B8D7u: goto L_82B8D7;
    case 0x82B8D8u: goto L_82B8D8;
    case 0x82B8DBu: goto L_82B8DB;
    case 0x82B8DCu: goto L_82B8DC;
    case 0x82B8DFu: goto L_82B8DF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B82E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB82Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB82Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB82Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B82E AND
    cpu.logicAnd(0x300u);
    goto L_82B831;
L_82B831:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB831u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB831u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB831u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B831 XBA
    cpu.xba();
    goto L_82B832;
L_82B832:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB832u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB832u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB832u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B832 DEC
    cpu.decReg('A');
    goto L_82B833;
L_82B833:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB833u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB833u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB833u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B833 ASL
    cpu.aslA();
    goto L_82B834;
L_82B834:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB834u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB834u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB834u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B834 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16));
    goto L_82B836;
L_82B836:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB836u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB836u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB836u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B836 TAX
    cpu.transfer("TAX");
    goto L_82B837;
L_82B837:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB837u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB837u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB837u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B837 LDA
    cpu.setA(0x8080u, 16);
    goto L_82B83A;
L_82B83A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB83Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB83Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB83Au, 6u, 3u, cpu.address("absx", 0x02BCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B83A STA
    hw.write(cpu.address("absx", 0x2BCu), cpu.a, cpu.m8?8:16);
    goto L_82B83D;
L_82B83D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB83Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB83Du,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB83Du, 6u, 3u, cpu.address("absx", 0x02C2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B83D STZ
    hw.write(cpu.address("absx", 0x2C2u), 0, cpu.m8?8:16);
    goto L_82B840;
L_82B840:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB840u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB840u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB840u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B840 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B843;
L_82B843:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB843u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB843u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB843u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B843 CMP
    cpu.compareA(0x2u);
    goto L_82B846;
L_82B846:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB846u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB846u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB846u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B846 BCS -> $82B86D
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82B86D; }
    goto L_82B848;
L_82B848:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB848u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB848u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB848u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B848 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B84A;
L_82B84A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB84Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB84Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB84Au, 5u + 1u, 3u, cpu.address("absx", 0x02DCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B84A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2DCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B84D;
L_82B84D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB84Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB84Du,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB84Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B84D BPL -> $82B861
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82B861; }
    goto L_82B84F;
L_82B84F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB84Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB84Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB84Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B84F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B851;
L_82B851:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB851u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB851u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB851u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B851 AND
    cpu.logicAnd(0x300u);
    goto L_82B854;
L_82B854:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB854u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB854u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB854u, 6u, 3u, cpu.address("absx", 0x02DCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B854 STA
    hw.write(cpu.address("absx", 0x2DCu), cpu.a, cpu.m8?8:16);
    goto L_82B857;
L_82B857:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB857u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB857u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB857u, 6u, 3u, cpu.address("absx", 0x02ECu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B857 STA
    hw.write(cpu.address("absx", 0x2ECu), cpu.a, cpu.m8?8:16);
    goto L_82B85A;
L_82B85A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB85Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB85Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB85Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B85A LDA
    cpu.setA(0x2u, 16);
    goto L_82B85D;
L_82B85D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB85Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB85Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB85Du, 6u, 3u, cpu.address("absx", 0x02D6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B85D STA
    hw.write(cpu.address("absx", 0x2D6u), cpu.a, cpu.m8?8:16);
    goto L_82B860;
L_82B860:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB860u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB860u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB860u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B860 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B860u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B860u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82B861:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB861u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB861u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB861u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B861 INX
    cpu.inc('X');
    goto L_82B862;
L_82B862:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB862u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB862u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB862u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B862 INX
    cpu.inc('X');
    goto L_82B863;
L_82B863:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB863u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB863u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB863u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B863 TXA
    cpu.transfer("TXA");
    goto L_82B864;
L_82B864:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB864u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB864u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB864u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B864 AND
    cpu.logicAnd(0xFFu);
    goto L_82B867;
L_82B867:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB867u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB867u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB867u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B867 CPX
    cpu.compareX(0x6u);
    goto L_82B86A;
L_82B86A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB86Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB86Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB86Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B86A BCC -> $82B84A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82B84A; }
    goto L_82B86C;
L_82B86C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB86Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB86Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB86Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B86C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B86Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B86Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82B86D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB86Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB86Du,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB86Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B86D PHX
    cpu.push("PHX", hw);
    goto L_82B86E;
L_82B86E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB86Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB86Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB86Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B86E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B870;
L_82B870:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB870u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB870u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB870u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B870 AND
    cpu.logicAnd(0x300u);
    goto L_82B873;
L_82B873:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB873u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB873u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB873u, 6u, 3u, cpu.address("abs", 0xC754u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B873 JSR -> $82C754 stack real
    { cpu.push16Value(hw,0xB875u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB876u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC754u), 0x82B873u); }
    goto L_82B876;
L_82B876:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB876u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB876u,0x82B876u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB876u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB876u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B876 CMP
    cpu.compareA(0xFFFFu);
    goto L_82B879;
L_82B879:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB879u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB879u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB879u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B879 BNE -> $82B87E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B87E; }
    goto L_82B87B;
L_82B87B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB87Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB87Bu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB87Bu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B87B PLX
    cpu.pop("PLX", hw);
    goto L_82B87C;
L_82B87C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB87Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB87Cu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB87Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B87C BRA -> $82B8D2
    goto L_82B8D2;
L_82B87E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB87Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB87Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB87Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B87E STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_82B880;
L_82B880:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB880u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB880u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB880u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B880 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B882;
L_82B882:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB882u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB882u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB882u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B882 BNE -> $82B889
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B889; }
    goto L_82B884;
L_82B884:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB884u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB884u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB884u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B884 LDA
    cpu.setA(0x0u, 16);
    goto L_82B887;
L_82B887:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB887u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB887u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB887u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B887 BRA -> $82B88C
    goto L_82B88C;
L_82B889:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB889u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB889u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB889u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B889 LDA
    cpu.setA(0x220u, 16);
    goto L_82B88C;
L_82B88C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB88Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB88Cu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB88Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B88C CLC
    cpu.setFlag('C', false);
    goto L_82B88D;
L_82B88D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB88Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB88Du,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB88Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B88D ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16));
    goto L_82B88F;
L_82B88F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB88Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB88Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB88Fu, 6u, 3u, cpu.address("absx", 0x02AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B88F STA
    hw.write(cpu.address("absx", 0x2AAu), cpu.a, cpu.m8?8:16);
    goto L_82B892;
L_82B892:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB892u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB892u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB892u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B892 STZ
    hw.write(cpu.address("dp", 0x38u), 0, cpu.m8?8:16);
    goto L_82B894;
L_82B894:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB894u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB894u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB894u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B894 LDA
    cpu.setA(0x16u, 16);
    goto L_82B897;
L_82B897:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB897u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB897u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB897u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x39u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B897 STA
    hw.write(cpu.address("dp", 0x39u), cpu.a, cpu.m8?8:16);
    goto L_82B899;
L_82B899:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB899u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB899u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB899u, 8u, 4u, 0x809436u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B899 JSL -> $809436 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB89Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB89Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809436u, 0x82B899u); }
    goto L_82B89D;
L_82B89D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB89Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB89Du,0x82B89Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB89Du,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB89Du, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B89D ASL
    cpu.aslMem(hw, cpu.address("dp", 0x36u), cpu.m8?8:16);
    goto L_82B89F;
L_82B89F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB89Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB89Fu,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB89Fu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B89F ASL
    cpu.aslMem(hw, cpu.address("dp", 0x36u), cpu.m8?8:16);
    goto L_82B8A1;
L_82B8A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8A1u,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8A1u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8A1 ASL
    cpu.aslMem(hw, cpu.address("dp", 0x36u), cpu.m8?8:16);
    goto L_82B8A3;
L_82B8A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8A3u,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8A3u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8A3 ASL
    cpu.aslMem(hw, cpu.address("dp", 0x3Bu), cpu.m8?8:16);
    goto L_82B8A5;
L_82B8A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8A5u,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8A5u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8A5 ASL
    cpu.aslMem(hw, cpu.address("dp", 0x3Bu), cpu.m8?8:16);
    goto L_82B8A7;
L_82B8A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8A7u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8A7u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B8A7 PLX
    cpu.pop("PLX", hw);
    goto L_82B8A8;
L_82B8A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8A8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8A8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8A8 LDA
    cpu.setA(0x1Cu, 16);
    goto L_82B8AB;
L_82B8AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8ABu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8ABu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8AB CLC
    cpu.setFlag('C', false);
    goto L_82B8AC;
L_82B8AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8ACu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8ACu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8AC ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16));
    goto L_82B8AE;
L_82B8AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8AEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8AEu, 6u, 3u, cpu.address("absx", 0x02B6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8AE STA
    hw.write(cpu.address("absx", 0x2B6u), cpu.a, cpu.m8?8:16);
    goto L_82B8B1;
L_82B8B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8B1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8B1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8B1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B8B3;
L_82B8B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8B3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8B3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8B3 BNE -> $82B8BA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B8BA; }
    goto L_82B8B5;
L_82B8B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8B5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8B5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8B5 LDA
    cpu.setA(0xCu, 16);
    goto L_82B8B8;
L_82B8B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8B8u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8B8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8B8 BRA -> $82B8BD
    goto L_82B8BD;
L_82B8BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8BAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8BAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8BA LDA
    cpu.setA(0x9Cu, 16);
    goto L_82B8BD;
L_82B8BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8BDu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8BDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8BD CLC
    cpu.setFlag('C', false);
    goto L_82B8BE;
L_82B8BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8BEu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8BEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8BE ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x3Bu), cpu.m8?8:16));
    goto L_82B8C0;
L_82B8C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8C0u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8C0u, 6u, 3u, cpu.address("absx", 0x02B0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8C0 STA
    hw.write(cpu.address("absx", 0x2B0u), cpu.a, cpu.m8?8:16);
    goto L_82B8C3;
L_82B8C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8C3u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8C3u, 6u, 3u, cpu.address("absx", 0x02BCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8C3 STZ
    hw.write(cpu.address("absx", 0x2BCu), 0, cpu.m8?8:16);
    goto L_82B8C6;
L_82B8C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8C6u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8C6u, 6u, 3u, cpu.address("absx", 0x02C2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8C6 STZ
    hw.write(cpu.address("absx", 0x2C2u), 0, cpu.m8?8:16);
    goto L_82B8C9;
L_82B8C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8C9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8C9u, 5u + 1u, 3u, cpu.address("absx", 0x0418u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8C9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x418u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B8CC;
L_82B8CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8CCu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8CCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8CC ORA
    cpu.logicOr(0x8000u);
    goto L_82B8CF;
L_82B8CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8CFu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8CFu, 6u, 3u, cpu.address("absx", 0x0418u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8CF STA
    hw.write(cpu.address("absx", 0x418u), cpu.a, cpu.m8?8:16);
    goto L_82B8D2;
L_82B8D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D2u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8D2 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B8D4;
L_82B8D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D4u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D4u, 9u, 3u, cpu.address("absx", 0x0402u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8D4 DEC
    cpu.decMem(hw, cpu.address("absx", 0x402u), cpu.m8?8:16);
    goto L_82B8D7;
L_82B8D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D7u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8D7 TXA
    cpu.transfer("TXA");
    goto L_82B8D8;
L_82B8D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D8u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8D8 EOR
    cpu.logicXor(0x100u);
    goto L_82B8DB;
L_82B8DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DBu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8DB TAX
    cpu.transfer("TAX");
    goto L_82B8DC;
L_82B8DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DCu,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DCu, 9u, 3u, cpu.address("absx", 0x0402u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8DC INC
    cpu.incMem(hw, cpu.address("absx", 0x402u), cpu.m8?8:16);
    goto L_82B8DF;
L_82B8DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B8DF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B8DFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B8DFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B82E_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B82Eu: goto L_82B82E;
    case 0x82B831u: goto L_82B831;
    case 0x82B832u: goto L_82B832;
    case 0x82B833u: goto L_82B833;
    case 0x82B834u: goto L_82B834;
    case 0x82B836u: goto L_82B836;
    case 0x82B837u: goto L_82B837;
    case 0x82B83Au: goto L_82B83A;
    case 0x82B83Du: goto L_82B83D;
    case 0x82B840u: goto L_82B840;
    case 0x82B843u: goto L_82B843;
    case 0x82B846u: goto L_82B846;
    case 0x82B848u: goto L_82B848;
    case 0x82B84Au: goto L_82B84A;
    case 0x82B84Du: goto L_82B84D;
    case 0x82B84Fu: goto L_82B84F;
    case 0x82B851u: goto L_82B851;
    case 0x82B854u: goto L_82B854;
    case 0x82B857u: goto L_82B857;
    case 0x82B85Au: goto L_82B85A;
    case 0x82B85Du: goto L_82B85D;
    case 0x82B860u: goto L_82B860;
    case 0x82B861u: goto L_82B861;
    case 0x82B862u: goto L_82B862;
    case 0x82B863u: goto L_82B863;
    case 0x82B864u: goto L_82B864;
    case 0x82B867u: goto L_82B867;
    case 0x82B86Au: goto L_82B86A;
    case 0x82B86Cu: goto L_82B86C;
    case 0x82B86Du: goto L_82B86D;
    case 0x82B86Eu: goto L_82B86E;
    case 0x82B870u: goto L_82B870;
    case 0x82B873u: goto L_82B873;
    case 0x82B876u: goto L_82B876;
    case 0x82B879u: goto L_82B879;
    case 0x82B87Bu: goto L_82B87B;
    case 0x82B87Cu: goto L_82B87C;
    case 0x82B87Eu: goto L_82B87E;
    case 0x82B880u: goto L_82B880;
    case 0x82B882u: goto L_82B882;
    case 0x82B884u: goto L_82B884;
    case 0x82B887u: goto L_82B887;
    case 0x82B889u: goto L_82B889;
    case 0x82B88Cu: goto L_82B88C;
    case 0x82B88Du: goto L_82B88D;
    case 0x82B88Fu: goto L_82B88F;
    case 0x82B892u: goto L_82B892;
    case 0x82B894u: goto L_82B894;
    case 0x82B897u: goto L_82B897;
    case 0x82B899u: goto L_82B899;
    case 0x82B89Du: goto L_82B89D;
    case 0x82B89Fu: goto L_82B89F;
    case 0x82B8A1u: goto L_82B8A1;
    case 0x82B8A3u: goto L_82B8A3;
    case 0x82B8A5u: goto L_82B8A5;
    case 0x82B8A7u: goto L_82B8A7;
    case 0x82B8A8u: goto L_82B8A8;
    case 0x82B8ABu: goto L_82B8AB;
    case 0x82B8ACu: goto L_82B8AC;
    case 0x82B8AEu: goto L_82B8AE;
    case 0x82B8B1u: goto L_82B8B1;
    case 0x82B8B3u: goto L_82B8B3;
    case 0x82B8B5u: goto L_82B8B5;
    case 0x82B8B8u: goto L_82B8B8;
    case 0x82B8BAu: goto L_82B8BA;
    case 0x82B8BDu: goto L_82B8BD;
    case 0x82B8BEu: goto L_82B8BE;
    case 0x82B8C0u: goto L_82B8C0;
    case 0x82B8C3u: goto L_82B8C3;
    case 0x82B8C6u: goto L_82B8C6;
    case 0x82B8C9u: goto L_82B8C9;
    case 0x82B8CCu: goto L_82B8CC;
    case 0x82B8CFu: goto L_82B8CF;
    case 0x82B8D2u: goto L_82B8D2;
    case 0x82B8D4u: goto L_82B8D4;
    case 0x82B8D7u: goto L_82B8D7;
    case 0x82B8D8u: goto L_82B8D8;
    case 0x82B8DBu: goto L_82B8DB;
    case 0x82B8DCu: goto L_82B8DC;
    case 0x82B8DFu: goto L_82B8DF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B82E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB82Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB82Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB82Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B82E AND
    cpu.logicAnd(0x300u);
    goto L_82B831;
L_82B831:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB831u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB831u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB831u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B831 XBA
    cpu.xba();
    goto L_82B832;
L_82B832:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB832u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB832u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB832u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B832 DEC
    cpu.decReg('A');
    goto L_82B833;
L_82B833:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB833u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB833u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB833u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B833 ASL
    cpu.aslA();
    goto L_82B834;
L_82B834:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB834u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB834u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB834u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B834 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16));
    goto L_82B836;
L_82B836:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB836u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB836u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB836u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B836 TAX
    cpu.transfer("TAX");
    goto L_82B837;
L_82B837:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB837u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB837u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB837u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B837 LDA
    cpu.setA(0x8080u, 16);
    goto L_82B83A;
L_82B83A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB83Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB83Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB83Au, 6u, 3u, cpu.address("absx", 0x02BCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B83A STA
    hw.write(cpu.address("absx", 0x2BCu), cpu.a, cpu.m8?8:16);
    goto L_82B83D;
L_82B83D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB83Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB83Du,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB83Du, 6u, 3u, cpu.address("absx", 0x02C2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B83D STZ
    hw.write(cpu.address("absx", 0x2C2u), 0, cpu.m8?8:16);
    goto L_82B840;
L_82B840:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB840u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB840u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB840u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B840 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B843;
L_82B843:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB843u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB843u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB843u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B843 CMP
    cpu.compareA(0x2u);
    goto L_82B846;
L_82B846:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB846u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB846u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB846u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B846 BCS -> $82B86D
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82B86D; }
    goto L_82B848;
L_82B848:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB848u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB848u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB848u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B848 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B84A;
L_82B84A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB84Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB84Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB84Au, 5u + 1u, 3u, cpu.address("absx", 0x02DCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B84A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2DCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B84D;
L_82B84D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB84Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB84Du,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB84Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B84D BPL -> $82B861
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82B861; }
    goto L_82B84F;
L_82B84F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB84Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB84Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB84Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B84F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B851;
L_82B851:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB851u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB851u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB851u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B851 AND
    cpu.logicAnd(0x300u);
    goto L_82B854;
L_82B854:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB854u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB854u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB854u, 6u, 3u, cpu.address("absx", 0x02DCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B854 STA
    hw.write(cpu.address("absx", 0x2DCu), cpu.a, cpu.m8?8:16);
    goto L_82B857;
L_82B857:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB857u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB857u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB857u, 6u, 3u, cpu.address("absx", 0x02ECu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B857 STA
    hw.write(cpu.address("absx", 0x2ECu), cpu.a, cpu.m8?8:16);
    goto L_82B85A;
L_82B85A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB85Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB85Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB85Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B85A LDA
    cpu.setA(0x2u, 16);
    goto L_82B85D;
L_82B85D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB85Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB85Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB85Du, 6u, 3u, cpu.address("absx", 0x02D6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B85D STA
    hw.write(cpu.address("absx", 0x2D6u), cpu.a, cpu.m8?8:16);
    goto L_82B860;
L_82B860:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB860u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB860u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB860u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B860 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B860u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B860u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82B861:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB861u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB861u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB861u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B861 INX
    cpu.inc('X');
    goto L_82B862;
L_82B862:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB862u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB862u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB862u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B862 INX
    cpu.inc('X');
    goto L_82B863;
L_82B863:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB863u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB863u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB863u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B863 TXA
    cpu.transfer("TXA");
    goto L_82B864;
L_82B864:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB864u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB864u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB864u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B864 AND
    cpu.logicAnd(0xFFu);
    goto L_82B867;
L_82B867:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB867u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB867u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB867u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B867 CPX
    cpu.compareX(0x6u);
    goto L_82B86A;
L_82B86A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB86Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB86Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB86Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B86A BCC -> $82B84A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82B84A; }
    goto L_82B86C;
L_82B86C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB86Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB86Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB86Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B86C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B86Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B86Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82B86D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB86Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB86Du,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB86Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B86D PHX
    cpu.push("PHX", hw);
    goto L_82B86E;
L_82B86E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB86Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB86Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB86Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B86E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B870;
L_82B870:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB870u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB870u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB870u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B870 AND
    cpu.logicAnd(0x300u);
    goto L_82B873;
L_82B873:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB873u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB873u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB873u, 6u, 3u, cpu.address("abs", 0xC754u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B873 JSR -> $82C754 stack real
    { cpu.push16Value(hw,0xB875u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB876u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC754u), 0x82B873u); }
    goto L_82B876;
L_82B876:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB876u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB876u,0x82B876u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB876u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB876u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B876 CMP
    cpu.compareA(0xFFFFu);
    goto L_82B879;
L_82B879:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB879u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB879u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB879u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B879 BNE -> $82B87E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B87E; }
    goto L_82B87B;
L_82B87B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB87Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB87Bu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB87Bu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B87B PLX
    cpu.pop("PLX", hw);
    goto L_82B87C;
L_82B87C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB87Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB87Cu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB87Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B87C BRA -> $82B8D2
    goto L_82B8D2;
L_82B87E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB87Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB87Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB87Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B87E STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_82B880;
L_82B880:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB880u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB880u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB880u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B880 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B882;
L_82B882:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB882u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB882u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB882u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B882 BNE -> $82B889
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B889; }
    goto L_82B884;
L_82B884:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB884u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB884u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB884u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B884 LDA
    cpu.setA(0x0u, 16);
    goto L_82B887;
L_82B887:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB887u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB887u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB887u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B887 BRA -> $82B88C
    goto L_82B88C;
L_82B889:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB889u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB889u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB889u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B889 LDA
    cpu.setA(0x220u, 16);
    goto L_82B88C;
L_82B88C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB88Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB88Cu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB88Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B88C CLC
    cpu.setFlag('C', false);
    goto L_82B88D;
L_82B88D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB88Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB88Du,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB88Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B88D ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16));
    goto L_82B88F;
L_82B88F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB88Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB88Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB88Fu, 6u, 3u, cpu.address("absx", 0x02AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B88F STA
    hw.write(cpu.address("absx", 0x2AAu), cpu.a, cpu.m8?8:16);
    goto L_82B892;
L_82B892:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB892u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB892u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB892u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B892 STZ
    hw.write(cpu.address("dp", 0x38u), 0, cpu.m8?8:16);
    goto L_82B894;
L_82B894:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB894u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB894u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB894u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B894 LDA
    cpu.setA(0x16u, 16);
    goto L_82B897;
L_82B897:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB897u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB897u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB897u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x39u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B897 STA
    hw.write(cpu.address("dp", 0x39u), cpu.a, cpu.m8?8:16);
    goto L_82B899;
L_82B899:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB899u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB899u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB899u, 8u, 4u, 0x809436u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B899 JSL -> $809436 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB89Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB89Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809436u, 0x82B899u); }
    goto L_82B89D;
L_82B89D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB89Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB89Du,0x82B89Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB89Du,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB89Du, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B89D ASL
    cpu.aslMem(hw, cpu.address("dp", 0x36u), cpu.m8?8:16);
    goto L_82B89F;
L_82B89F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB89Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB89Fu,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB89Fu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B89F ASL
    cpu.aslMem(hw, cpu.address("dp", 0x36u), cpu.m8?8:16);
    goto L_82B8A1;
L_82B8A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8A1u,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8A1u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8A1 ASL
    cpu.aslMem(hw, cpu.address("dp", 0x36u), cpu.m8?8:16);
    goto L_82B8A3;
L_82B8A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8A3u,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8A3u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8A3 ASL
    cpu.aslMem(hw, cpu.address("dp", 0x3Bu), cpu.m8?8:16);
    goto L_82B8A5;
L_82B8A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8A5u,cpu,0x06u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8A5u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8A5 ASL
    cpu.aslMem(hw, cpu.address("dp", 0x3Bu), cpu.m8?8:16);
    goto L_82B8A7;
L_82B8A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8A7u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8A7u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B8A7 PLX
    cpu.pop("PLX", hw);
    goto L_82B8A8;
L_82B8A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8A8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8A8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8A8 LDA
    cpu.setA(0x1Cu, 16);
    goto L_82B8AB;
L_82B8AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8ABu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8ABu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8AB CLC
    cpu.setFlag('C', false);
    goto L_82B8AC;
L_82B8AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8ACu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8ACu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8AC ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16));
    goto L_82B8AE;
L_82B8AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8AEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8AEu, 6u, 3u, cpu.address("absx", 0x02B6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8AE STA
    hw.write(cpu.address("absx", 0x2B6u), cpu.a, cpu.m8?8:16);
    goto L_82B8B1;
L_82B8B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8B1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8B1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8B1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B8B3;
L_82B8B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8B3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8B3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8B3 BNE -> $82B8BA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B8BA; }
    goto L_82B8B5;
L_82B8B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8B5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8B5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8B5 LDA
    cpu.setA(0xCu, 16);
    goto L_82B8B8;
L_82B8B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8B8u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8B8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8B8 BRA -> $82B8BD
    goto L_82B8BD;
L_82B8BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8BAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8BAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8BA LDA
    cpu.setA(0x9Cu, 16);
    goto L_82B8BD;
L_82B8BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8BDu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8BDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8BD CLC
    cpu.setFlag('C', false);
    goto L_82B8BE;
L_82B8BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8BEu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8BEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8BE ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x3Bu), cpu.m8?8:16));
    goto L_82B8C0;
L_82B8C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8C0u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8C0u, 6u, 3u, cpu.address("absx", 0x02B0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8C0 STA
    hw.write(cpu.address("absx", 0x2B0u), cpu.a, cpu.m8?8:16);
    goto L_82B8C3;
L_82B8C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8C3u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8C3u, 6u, 3u, cpu.address("absx", 0x02BCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8C3 STZ
    hw.write(cpu.address("absx", 0x2BCu), 0, cpu.m8?8:16);
    goto L_82B8C6;
L_82B8C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8C6u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8C6u, 6u, 3u, cpu.address("absx", 0x02C2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8C6 STZ
    hw.write(cpu.address("absx", 0x2C2u), 0, cpu.m8?8:16);
    goto L_82B8C9;
L_82B8C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8C9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8C9u, 5u + 1u, 3u, cpu.address("absx", 0x0418u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8C9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x418u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B8CC;
L_82B8CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8CCu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8CCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8CC ORA
    cpu.logicOr(0x8000u);
    goto L_82B8CF;
L_82B8CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8CFu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8CFu, 6u, 3u, cpu.address("absx", 0x0418u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8CF STA
    hw.write(cpu.address("absx", 0x418u), cpu.a, cpu.m8?8:16);
    goto L_82B8D2;
L_82B8D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D2u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8D2 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B8D4;
L_82B8D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D4u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D4u, 9u, 3u, cpu.address("absx", 0x0402u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8D4 DEC
    cpu.decMem(hw, cpu.address("absx", 0x402u), cpu.m8?8:16);
    goto L_82B8D7;
L_82B8D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D7u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8D7 TXA
    cpu.transfer("TXA");
    goto L_82B8D8;
L_82B8D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D8u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8D8 EOR
    cpu.logicXor(0x100u);
    goto L_82B8DB;
L_82B8DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DBu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8DB TAX
    cpu.transfer("TAX");
    goto L_82B8DC;
L_82B8DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DCu,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DCu, 9u, 3u, cpu.address("absx", 0x0402u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B8DC INC
    cpu.incMem(hw, cpu.address("absx", 0x402u), cpu.m8?8:16);
    goto L_82B8DF;
L_82B8DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B8DF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B8DFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B8DFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82C25D_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82C25Du: goto L_82C25D;
    case 0x82C25Fu: goto L_82C25F;
    case 0x82C261u: goto L_82C261;
    case 0x82C264u: goto L_82C264;
    case 0x82C266u: goto L_82C266;
    case 0x82C269u: goto L_82C269;
    case 0x82C26Bu: goto L_82C26B;
    case 0x82C26Eu: goto L_82C26E;
    case 0x82C270u: goto L_82C270;
    case 0x82C273u: goto L_82C273;
    case 0x82C275u: goto L_82C275;
    case 0x82C278u: goto L_82C278;
    case 0x82C27Bu: goto L_82C27B;
    case 0x82C27Cu: goto L_82C27C;
    case 0x82C27Fu: goto L_82C27F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82C25D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC25Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC25Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC25Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C25D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C25F;
L_82C25F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC25Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC25Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC25Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C25F BNE -> $82C27F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C27F; }
    goto L_82C261;
L_82C261:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC261u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC261u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC261u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C261 LDA
    cpu.setA(0x1u, 16);
    goto L_82C264;
L_82C264:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC264u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC264u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC264u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C264 STA
    hw.write(cpu.address("dp", 0x6Fu), cpu.a, cpu.m8?8:16);
    goto L_82C266;
L_82C266:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC266u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC266u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC266u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C266 LDA
    cpu.setA(0xC369u, 16);
    goto L_82C269;
L_82C269:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC269u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC269u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC269u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C269 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82C26B;
L_82C26B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC26Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC26Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC26Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C26B LDA
    cpu.setA(0x82u, 16);
    goto L_82C26E;
L_82C26E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC26Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC26Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC26Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C26E STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82C270;
L_82C270:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC270u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC270u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC270u, 6u, 3u, cpu.address("abs", 0xC303u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C270 JSR -> $82C303 stack real
    { cpu.push16Value(hw,0xC272u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC273u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC303u), 0x82C270u); }
    goto L_82C273;
L_82C273:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC273u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC273u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC273u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C273 BCC -> $82C27C
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82C27C; }
    goto L_82C275;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC273u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC273u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C273 BCC -> $82C27C
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82C27C; }
    goto L_82C275;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC273u,0x82C273u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C275:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC275u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC275u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC275u, 8u, 3u, cpu.address("abs", 0x0176u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C275 INC
    cpu.incMem(hw, cpu.address("abs", 0x176u), cpu.m8?8:16);
    goto L_82C278;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC275u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC275u, 8u, 3u, cpu.address("abs", 0x0176u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C275 INC
    cpu.incMem(hw, cpu.address("abs", 0x176u), cpu.m8?8:16);
    goto L_82C278;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC275u,0x82C275u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C278:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC278u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC278u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC278u, 5u, 3u, cpu.address("abs", 0x02CCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C278 STZ
    hw.write(cpu.address("abs", 0x2CCu), 0, cpu.m8?8:16);
    goto L_82C27B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC278u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC278u, 5u, 3u, cpu.address("abs", 0x02CCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C278 STZ
    hw.write(cpu.address("abs", 0x2CCu), 0, cpu.m8?8:16);
    goto L_82C27B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC278u,0x82C278u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C27B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC27Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C27B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C27Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C27Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C27B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C27Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C27Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC27Bu,0x82C27Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C27C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC27Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Cu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Cu, 8u, 3u, cpu.address("abs", 0x02CCu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C27C INC
    cpu.incMem(hw, cpu.address("abs", 0x2CCu), cpu.m8?8:16);
    goto L_82C27F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Cu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Cu, 8u, 3u, cpu.address("abs", 0x02CCu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C27C INC
    cpu.incMem(hw, cpu.address("abs", 0x2CCu), cpu.m8?8:16);
    goto L_82C27F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC27Cu,0x82C27Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C27F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC27Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C27F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C27Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C27Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C27F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C27Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C27Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC27Fu,0x82C27Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82E0A8_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82E0A8u: goto L_82E0A8;
    case 0x82E0AAu: goto L_82E0AA;
    case 0x82E0ABu: goto L_82E0AB;
    case 0x82E0ACu: goto L_82E0AC;
    case 0x82E0AEu: goto L_82E0AE;
    case 0x82E0B1u: goto L_82E0B1;
    case 0x82E0B3u: goto L_82E0B3;
    case 0x82E0B6u: goto L_82E0B6;
    case 0x82E0B8u: goto L_82E0B8;
    case 0x82E0BAu: goto L_82E0BA;
    case 0x82E0BCu: goto L_82E0BC;
    case 0x82E0BEu: goto L_82E0BE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82E0A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0A8u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0A8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0A8 STY
    hw.write(cpu.address("dp", 0x63u), cpu.y, cpu.x8?8:16);
    goto L_82E0AA;
L_82E0AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0AAu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0AAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0AA DEY
    cpu.decReg('Y');
    goto L_82E0AB;
L_82E0AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0ABu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0ABu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0AB DEY
    cpu.decReg('Y');
    goto L_82E0AC;
L_82E0AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0ACu,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0ACu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82E0AC LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E0AE;
L_82E0AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0AEu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0AEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0AE CMP
    cpu.compareA(0xFFFFu);
    goto L_82E0B1;
L_82E0B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0B1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0B1 BEQ -> $82E0BC
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E0BC; }
    goto L_82E0B3;
L_82E0B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0B3u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0B3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0B3 BIT
    cpu.bit(0x8000u, true);
    goto L_82E0B6;
L_82E0B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0B6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0B6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0B6 BEQ -> $82E0BC
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E0BC; }
    goto L_82E0B8;
L_82E0B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0B8u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0B8u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0B8 INC
    cpu.incMem(hw, cpu.address("dp", 0x10u), cpu.m8?8:16);
    goto L_82E0BA;
L_82E0BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0BAu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0BAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0BA BRA -> $82E0AA
    goto L_82E0AA;
L_82E0BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0BCu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0BCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0BC LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82E0BE;
L_82E0BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0BEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0BEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E0BE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82E0BEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82E0BEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82E379_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82E379u: goto L_82E379;
    case 0x82E37Bu: goto L_82E37B;
    case 0x82E37Eu: goto L_82E37E;
    case 0x82E380u: goto L_82E380;
    case 0x82E382u: goto L_82E382;
    case 0x82E384u: goto L_82E384;
    case 0x82E386u: goto L_82E386;
    case 0x82E389u: goto L_82E389;
    case 0x82E38Bu: goto L_82E38B;
    case 0x82E38Du: goto L_82E38D;
    case 0x82E38Eu: goto L_82E38E;
    case 0x82E391u: goto L_82E391;
    case 0x82E393u: goto L_82E393;
    case 0x82E395u: goto L_82E395;
    case 0x82E398u: goto L_82E398;
    case 0x82E39Au: goto L_82E39A;
    case 0x82E39Cu: goto L_82E39C;
    case 0x82E39Eu: goto L_82E39E;
    case 0x82E3A0u: goto L_82E3A0;
    case 0x82E3A3u: goto L_82E3A3;
    case 0x82E3A5u: goto L_82E3A5;
    case 0x82E3A7u: goto L_82E3A7;
    case 0x82E3A8u: goto L_82E3A8;
    case 0x82E3ABu: goto L_82E3AB;
    case 0x82E3ADu: goto L_82E3AD;
    case 0x82E3AFu: goto L_82E3AF;
    case 0x82E3B2u: goto L_82E3B2;
    case 0x82E3B4u: goto L_82E3B4;
    case 0x82E3B6u: goto L_82E3B6;
    case 0x82E3B8u: goto L_82E3B8;
    case 0x82E3BAu: goto L_82E3BA;
    case 0x82E3BDu: goto L_82E3BD;
    case 0x82E3BFu: goto L_82E3BF;
    case 0x82E3C1u: goto L_82E3C1;
    case 0x82E3C2u: goto L_82E3C2;
    case 0x82E3C5u: goto L_82E3C5;
    case 0x82E3C7u: goto L_82E3C7;
    case 0x82E3C9u: goto L_82E3C9;
    case 0x82E3CCu: goto L_82E3CC;
    case 0x82E3CEu: goto L_82E3CE;
    case 0x82E3D0u: goto L_82E3D0;
    case 0x82E3D2u: goto L_82E3D2;
    case 0x82E3D4u: goto L_82E3D4;
    case 0x82E3D7u: goto L_82E3D7;
    case 0x82E3D9u: goto L_82E3D9;
    case 0x82E3DBu: goto L_82E3DB;
    case 0x82E3DCu: goto L_82E3DC;
    case 0x82E3DFu: goto L_82E3DF;
    case 0x82E3E1u: goto L_82E3E1;
    case 0x82E3E3u: goto L_82E3E3;
    case 0x82E3E6u: goto L_82E3E6;
    case 0x82E3E8u: goto L_82E3E8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82E379:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE379u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE379u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE379u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82E379 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E37B;
L_82E37B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE37Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE37Bu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE37Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E37B ORA
    cpu.logicOr(0x4000u);
    goto L_82E37E;
L_82E37E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE37Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE37Eu,cpu,0x91u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE37Eu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82E37E STA
    hw.write(cpu.addressDpIndirectY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82E380;
L_82E380:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE380u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE380u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE380u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E380 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E382;
L_82E382:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE382u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE382u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE382u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E382 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_82E384;
L_82E384:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE384u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE384u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE384u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82E384 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E386;
L_82E386:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE386u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE386u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE386u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E386 BIT
    cpu.bit(0x1u, true);
    goto L_82E389;
L_82E389:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE389u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE389u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE389u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E389 BEQ -> $82E39A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E39A; }
    goto L_82E38B;
L_82E38B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE38Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE38Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE38Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E38B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E38D;
L_82E38D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE38Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE38Du,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE38Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E38D SEC
    cpu.setFlag('C', true);
    goto L_82E38E;
L_82E38E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE38Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE38Eu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE38Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E38E SBC
    cpu.sbc(0x16u);
    goto L_82E391;
L_82E391:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE391u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE391u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE391u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E391 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82E393;
L_82E393:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE393u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE393u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE393u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82E393 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E395;
L_82E395:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE395u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE395u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE395u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E395 ORA
    cpu.logicOr(0x4000u);
    goto L_82E398;
L_82E398:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE398u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE398u,cpu,0x91u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE398u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82E398 STA
    hw.write(cpu.addressDpIndirectY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82E39A;
L_82E39A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE39Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE39Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE39Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E39A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E39C;
L_82E39C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE39Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE39Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE39Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E39C STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82E39E;
L_82E39E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE39Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE39Eu,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE39Eu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82E39E LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E3A0;
L_82E3A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A0u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3A0 BIT
    cpu.bit(0x2u, true);
    goto L_82E3A3;
L_82E3A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3A3 BEQ -> $82E3B4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E3B4; }
    goto L_82E3A5;
L_82E3A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3A5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E3A7;
L_82E3A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A7u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3A7 SEC
    cpu.setFlag('C', true);
    goto L_82E3A8;
L_82E3A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A8u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3A8 SBC
    cpu.sbc(0x2u);
    goto L_82E3AB;
L_82E3AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3ABu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3ABu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3AB STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82E3AD;
L_82E3AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3ADu,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3ADu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82E3AD LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E3AF;
L_82E3AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3AFu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3AFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3AF ORA
    cpu.logicOr(0x4000u);
    goto L_82E3B2;
L_82E3B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B2u,cpu,0x91u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B2u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82E3B2 STA
    hw.write(cpu.addressDpIndirectY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82E3B4;
L_82E3B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3B4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E3B6;
L_82E3B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3B6 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82E3B8;
L_82E3B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B8u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3B8u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82E3B8 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E3BA;
L_82E3BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BAu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3BA BIT
    cpu.bit(0x4u, true);
    goto L_82E3BD;
L_82E3BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3BD BEQ -> $82E3CE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E3CE; }
    goto L_82E3BF;
L_82E3BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BFu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3BFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3BF LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E3C1;
L_82E3C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C1u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3C1 CLC
    cpu.setFlag('C', false);
    goto L_82E3C2;
L_82E3C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C2u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3C2 ADC
    cpu.adc(0x16u);
    goto L_82E3C5;
L_82E3C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3C5 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82E3C7;
L_82E3C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C7u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C7u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82E3C7 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E3C9;
L_82E3C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C9u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3C9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3C9 ORA
    cpu.logicOr(0x4000u);
    goto L_82E3CC;
L_82E3CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3CCu,cpu,0x91u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3CCu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82E3CC STA
    hw.write(cpu.addressDpIndirectY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82E3CE;
L_82E3CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3CEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3CEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3CE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E3D0;
L_82E3D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3D0 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82E3D2;
L_82E3D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D2u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D2u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82E3D2 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E3D4;
L_82E3D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D4u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3D4 BIT
    cpu.bit(0x8u, true);
    goto L_82E3D7;
L_82E3D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3D7 BEQ -> $82E3E8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E3E8; }
    goto L_82E3D9;
L_82E3D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3D9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3D9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E3DB;
L_82E3DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DBu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3DB CLC
    cpu.setFlag('C', false);
    goto L_82E3DC;
L_82E3DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DCu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3DC ADC
    cpu.adc(0x2u);
    goto L_82E3DF;
L_82E3DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3DFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3DF STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82E3E1;
L_82E3E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E1u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E1u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82E3E1 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E3E3;
L_82E3E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E3u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3E3 ORA
    cpu.logicOr(0x4000u);
    goto L_82E3E6;
L_82E3E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E6u,cpu,0x91u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E6u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82E3E6 STA
    hw.write(cpu.addressDpIndirectY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82E3E8;
L_82E3E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3E8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E3E8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82E3E8u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82E3E8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84848C_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84848Cu: goto L_84848C;
    case 0x84848Eu: goto L_84848E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84848C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x848Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x848Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x848Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84848C REP
    cpu.rep(0x20u);
    goto L_84848E;
L_84848E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x848Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x848Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x848Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84848E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84848Eu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84848Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84848C_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84848Cu: goto L_84848C;
    case 0x84848Eu: goto L_84848E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84848C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x848Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x848Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x848Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84848C REP
    cpu.rep(0x20u);
    goto L_84848E;
L_84848E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x848Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x848Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x848Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84848E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84848Eu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84848Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84869B_E0M1X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84869Bu: goto L_84869B;
    case 0x84869Du: goto L_84869D;
    case 0x84869Fu: goto L_84869F;
    case 0x8486A1u: goto L_8486A1;
    case 0x8486A4u: goto L_8486A4;
    case 0x8486A5u: goto L_8486A5;
    case 0x8486A6u: goto L_8486A6;
    case 0x8486A9u: goto L_8486A9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84869B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x869Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x869Bu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x869Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84869B SEP
    cpu.sep(0x20u);
    goto L_84869D;
L_84869D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x869Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x869Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x869Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84869D AND
    cpu.logicAnd(0x1u);
    goto L_84869F;
L_84869F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x869Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x869Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x869Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84869F REP
    cpu.rep(0x20u);
    goto L_8486A1;
L_8486A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A1u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486A1 AND
    cpu.logicAnd(0xFFu);
    goto L_8486A4;
L_8486A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A4u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486A4 ASL
    cpu.aslA();
    goto L_8486A5;
L_8486A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A5u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486A5 TAX
    cpu.transfer("TAX");
    goto L_8486A6;
L_8486A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A6u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A6u, 5u, 3u, cpu.address("abs", 0x86ABu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8486A6 PEA
    cpu.push16Value(hw, 0x86ABu);
    goto L_8486A9;
L_8486A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A9u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A9u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x86BFu + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $8486A9 JMP (86BF,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x86BFu+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x8486A9u); return; }
}

void sub_84869B_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84869Bu: goto L_84869B;
    case 0x84869Du: goto L_84869D;
    case 0x84869Fu: goto L_84869F;
    case 0x8486A1u: goto L_8486A1;
    case 0x8486A4u: goto L_8486A4;
    case 0x8486A5u: goto L_8486A5;
    case 0x8486A6u: goto L_8486A6;
    case 0x8486A9u: goto L_8486A9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84869B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x869Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x869Bu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x869Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84869B SEP
    cpu.sep(0x20u);
    goto L_84869D;
L_84869D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x869Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x869Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x869Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84869D AND
    cpu.logicAnd(0x1u);
    goto L_84869F;
L_84869F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x869Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x869Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x869Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84869F REP
    cpu.rep(0x20u);
    goto L_8486A1;
L_8486A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A1u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486A1 AND
    cpu.logicAnd(0xFFu);
    goto L_8486A4;
L_8486A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A4u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486A4 ASL
    cpu.aslA();
    goto L_8486A5;
L_8486A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A5u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486A5 TAX
    cpu.transfer("TAX");
    goto L_8486A6;
L_8486A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A6u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A6u, 5u, 3u, cpu.address("abs", 0x86ABu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8486A6 PEA
    cpu.push16Value(hw, 0x86ABu);
    goto L_8486A9;
L_8486A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A9u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A9u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x86BFu + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $8486A9 JMP (86BF,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x86BFu+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x8486A9u); return; }
}

void sub_8487A2_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8487A2u: goto L_8487A2;
    case 0x8487A4u: goto L_8487A4;
    case 0x8487A7u: goto L_8487A7;
    case 0x8487AAu: goto L_8487AA;
    case 0x8487ADu: goto L_8487AD;
    case 0x8487AFu: goto L_8487AF;
    case 0x8487B2u: goto L_8487B2;
    case 0x8487B4u: goto L_8487B4;
    case 0x8487B7u: goto L_8487B7;
    case 0x8487B9u: goto L_8487B9;
    case 0x8487BDu: goto L_8487BD;
    case 0x8487C0u: goto L_8487C0;
    case 0x8487C3u: goto L_8487C3;
    case 0x8487C6u: goto L_8487C6;
    case 0x8487C8u: goto L_8487C8;
    case 0x8487CBu: goto L_8487CB;
    case 0x8487CDu: goto L_8487CD;
    case 0x8487D0u: goto L_8487D0;
    case 0x8487D2u: goto L_8487D2;
    case 0x8487D6u: goto L_8487D6;
    case 0x8487D8u: goto L_8487D8;
    case 0x8487DBu: goto L_8487DB;
    case 0x8487DDu: goto L_8487DD;
    case 0x8487DFu: goto L_8487DF;
    case 0x8487E2u: goto L_8487E2;
    case 0x8487E3u: goto L_8487E3;
    case 0x8487E4u: goto L_8487E4;
    case 0x8487E7u: goto L_8487E7;
    case 0x8487EAu: goto L_8487EA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8487A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A2u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487A2 REP
    cpu.rep(0x20u);
    goto L_8487A4;
L_8487A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A4u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487A4 LDX
    cpu.setX(0x2u, 16);
    goto L_8487A7;
L_8487A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A7u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487A7 LDY
    cpu.setY(0x3u, 16);
    goto L_8487AA;
L_8487AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87AAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87AAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487AA LDA
    cpu.setA(0x2A9Au, 16);
    goto L_8487AD;
L_8487AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87ADu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87ADu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487AD STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_8487AF;
L_8487AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87AFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87AFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487AF LDA
    cpu.setA(0x7Eu, 16);
    goto L_8487B2;
L_8487B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487B2 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_8487B4;
L_8487B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487B4 LDA
    cpu.setA(0x1000u, 16);
    goto L_8487B7;
L_8487B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487B7 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_8487B9;
L_8487B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B9u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B9u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8487B9 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x87BCu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x87BDu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x8487B9u); }
    goto L_8487BD;
L_8487BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87BDu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x87BDu,0x8487BDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87BDu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87BDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487BD LDX
    cpu.setX(0x2u, 16);
    goto L_8487C0;
L_8487C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C0u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487C0 LDY
    cpu.setY(0x8u, 16);
    goto L_8487C3;
L_8487C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487C3 LDA
    cpu.setA(0x2AA8u, 16);
    goto L_8487C6;
L_8487C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487C6 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_8487C8;
L_8487C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487C8 LDA
    cpu.setA(0x7Eu, 16);
    goto L_8487CB;
L_8487CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87CBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87CBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487CB STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_8487CD;
L_8487CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87CDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87CDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487CD LDA
    cpu.setA(0x1400u, 16);
    goto L_8487D0;
L_8487D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487D0 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_8487D2;
L_8487D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D2u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8487D2 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x87D5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x87D6u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x8487D2u); }
    goto L_8487D6;
L_8487D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x87D6u,0x8487D6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D6u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487D6 SEP
    cpu.sep(0x20u);
    goto L_8487D8;
L_8487D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D8u, 4u, 3u, cpu.address("abs", 0x06FDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487D8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6FDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8487DB;
L_8487DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DBu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487DB AND
    cpu.logicAnd(0x1u);
    goto L_8487DD;
L_8487DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487DD REP
    cpu.rep(0x20u);
    goto L_8487DF;
L_8487DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DFu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487DF AND
    cpu.logicAnd(0xFFu);
    goto L_8487E2;
L_8487E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487E2 ASL
    cpu.aslA();
    goto L_8487E3;
L_8487E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E3u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487E3 TAX
    cpu.transfer("TAX");
    goto L_8487E4;
L_8487E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E4u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E4u, 5u, 3u, cpu.address("abs", 0x87E9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8487E4 PEA
    cpu.push16Value(hw, 0x87E9u);
    goto L_8487E7;
L_8487E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E7u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E7u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x87EBu + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $8487E7 JMP (87EB,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x87EBu+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x8487E7u); return; }
L_8487EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87EAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x87EAu,0x8487EAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87EAu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87EAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8487EA RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8487EAu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8487EAu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8487A2_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8487A2u: goto L_8487A2;
    case 0x8487A4u: goto L_8487A4;
    case 0x8487A7u: goto L_8487A7;
    case 0x8487AAu: goto L_8487AA;
    case 0x8487ADu: goto L_8487AD;
    case 0x8487AFu: goto L_8487AF;
    case 0x8487B2u: goto L_8487B2;
    case 0x8487B4u: goto L_8487B4;
    case 0x8487B7u: goto L_8487B7;
    case 0x8487B9u: goto L_8487B9;
    case 0x8487BDu: goto L_8487BD;
    case 0x8487C0u: goto L_8487C0;
    case 0x8487C3u: goto L_8487C3;
    case 0x8487C6u: goto L_8487C6;
    case 0x8487C8u: goto L_8487C8;
    case 0x8487CBu: goto L_8487CB;
    case 0x8487CDu: goto L_8487CD;
    case 0x8487D0u: goto L_8487D0;
    case 0x8487D2u: goto L_8487D2;
    case 0x8487D6u: goto L_8487D6;
    case 0x8487D8u: goto L_8487D8;
    case 0x8487DBu: goto L_8487DB;
    case 0x8487DDu: goto L_8487DD;
    case 0x8487DFu: goto L_8487DF;
    case 0x8487E2u: goto L_8487E2;
    case 0x8487E3u: goto L_8487E3;
    case 0x8487E4u: goto L_8487E4;
    case 0x8487E7u: goto L_8487E7;
    case 0x8487EAu: goto L_8487EA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8487A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A2u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487A2 REP
    cpu.rep(0x20u);
    goto L_8487A4;
L_8487A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A4u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487A4 LDX
    cpu.setX(0x2u, 16);
    goto L_8487A7;
L_8487A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A7u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487A7 LDY
    cpu.setY(0x3u, 16);
    goto L_8487AA;
L_8487AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87AAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87AAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487AA LDA
    cpu.setA(0x2A9Au, 16);
    goto L_8487AD;
L_8487AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87ADu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87ADu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487AD STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_8487AF;
L_8487AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87AFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87AFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487AF LDA
    cpu.setA(0x7Eu, 16);
    goto L_8487B2;
L_8487B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487B2 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_8487B4;
L_8487B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487B4 LDA
    cpu.setA(0x1000u, 16);
    goto L_8487B7;
L_8487B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487B7 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_8487B9;
L_8487B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B9u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B9u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8487B9 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x87BCu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x87BDu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x8487B9u); }
    goto L_8487BD;
L_8487BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87BDu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x87BDu,0x8487BDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87BDu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87BDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487BD LDX
    cpu.setX(0x2u, 16);
    goto L_8487C0;
L_8487C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C0u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487C0 LDY
    cpu.setY(0x8u, 16);
    goto L_8487C3;
L_8487C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487C3 LDA
    cpu.setA(0x2AA8u, 16);
    goto L_8487C6;
L_8487C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487C6 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_8487C8;
L_8487C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487C8 LDA
    cpu.setA(0x7Eu, 16);
    goto L_8487CB;
L_8487CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87CBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87CBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487CB STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_8487CD;
L_8487CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87CDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87CDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487CD LDA
    cpu.setA(0x1400u, 16);
    goto L_8487D0;
L_8487D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487D0 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_8487D2;
L_8487D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D2u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8487D2 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x87D5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x87D6u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x8487D2u); }
    goto L_8487D6;
L_8487D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x87D6u,0x8487D6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D6u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487D6 SEP
    cpu.sep(0x20u);
    goto L_8487D8;
L_8487D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D8u, 4u, 3u, cpu.address("abs", 0x06FDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487D8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6FDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8487DB;
L_8487DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DBu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487DB AND
    cpu.logicAnd(0x1u);
    goto L_8487DD;
L_8487DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487DD REP
    cpu.rep(0x20u);
    goto L_8487DF;
L_8487DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DFu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487DF AND
    cpu.logicAnd(0xFFu);
    goto L_8487E2;
L_8487E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487E2 ASL
    cpu.aslA();
    goto L_8487E3;
L_8487E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E3u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487E3 TAX
    cpu.transfer("TAX");
    goto L_8487E4;
L_8487E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E4u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E4u, 5u, 3u, cpu.address("abs", 0x87E9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8487E4 PEA
    cpu.push16Value(hw, 0x87E9u);
    goto L_8487E7;
L_8487E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E7u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E7u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x87EBu + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $8487E7 JMP (87EB,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x87EBu+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x8487E7u); return; }
L_8487EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87EAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x87EAu,0x8487EAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87EAu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87EAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8487EA RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8487EAu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8487EAu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8487A2_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8487A2u: goto L_8487A2;
    case 0x8487A4u: goto L_8487A4;
    case 0x8487A7u: goto L_8487A7;
    case 0x8487AAu: goto L_8487AA;
    case 0x8487ADu: goto L_8487AD;
    case 0x8487AFu: goto L_8487AF;
    case 0x8487B2u: goto L_8487B2;
    case 0x8487B4u: goto L_8487B4;
    case 0x8487B7u: goto L_8487B7;
    case 0x8487B9u: goto L_8487B9;
    case 0x8487BDu: goto L_8487BD;
    case 0x8487C0u: goto L_8487C0;
    case 0x8487C3u: goto L_8487C3;
    case 0x8487C6u: goto L_8487C6;
    case 0x8487C8u: goto L_8487C8;
    case 0x8487CBu: goto L_8487CB;
    case 0x8487CDu: goto L_8487CD;
    case 0x8487D0u: goto L_8487D0;
    case 0x8487D2u: goto L_8487D2;
    case 0x8487D6u: goto L_8487D6;
    case 0x8487D8u: goto L_8487D8;
    case 0x8487DBu: goto L_8487DB;
    case 0x8487DDu: goto L_8487DD;
    case 0x8487DFu: goto L_8487DF;
    case 0x8487E2u: goto L_8487E2;
    case 0x8487E3u: goto L_8487E3;
    case 0x8487E4u: goto L_8487E4;
    case 0x8487E7u: goto L_8487E7;
    case 0x8487EAu: goto L_8487EA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8487A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A2u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487A2 REP
    cpu.rep(0x20u);
    goto L_8487A4;
L_8487A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A4u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487A4 LDX
    cpu.setX(0x2u, 16);
    goto L_8487A7;
L_8487A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A7u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487A7 LDY
    cpu.setY(0x3u, 16);
    goto L_8487AA;
L_8487AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87AAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87AAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487AA LDA
    cpu.setA(0x2A9Au, 16);
    goto L_8487AD;
L_8487AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87ADu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87ADu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487AD STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_8487AF;
L_8487AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87AFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87AFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487AF LDA
    cpu.setA(0x7Eu, 16);
    goto L_8487B2;
L_8487B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487B2 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_8487B4;
L_8487B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487B4 LDA
    cpu.setA(0x1000u, 16);
    goto L_8487B7;
L_8487B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487B7 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_8487B9;
L_8487B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B9u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B9u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8487B9 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x87BCu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x87BDu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x8487B9u); }
    goto L_8487BD;
L_8487BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87BDu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x87BDu,0x8487BDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87BDu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87BDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487BD LDX
    cpu.setX(0x2u, 16);
    goto L_8487C0;
L_8487C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C0u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487C0 LDY
    cpu.setY(0x8u, 16);
    goto L_8487C3;
L_8487C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487C3 LDA
    cpu.setA(0x2AA8u, 16);
    goto L_8487C6;
L_8487C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487C6 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_8487C8;
L_8487C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487C8 LDA
    cpu.setA(0x7Eu, 16);
    goto L_8487CB;
L_8487CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87CBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87CBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487CB STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_8487CD;
L_8487CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87CDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87CDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487CD LDA
    cpu.setA(0x1400u, 16);
    goto L_8487D0;
L_8487D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487D0 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_8487D2;
L_8487D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D2u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8487D2 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x87D5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x87D6u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x8487D2u); }
    goto L_8487D6;
L_8487D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x87D6u,0x8487D6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D6u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487D6 SEP
    cpu.sep(0x20u);
    goto L_8487D8;
L_8487D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D8u, 4u, 3u, cpu.address("abs", 0x06FDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487D8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6FDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8487DB;
L_8487DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DBu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487DB AND
    cpu.logicAnd(0x1u);
    goto L_8487DD;
L_8487DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487DD REP
    cpu.rep(0x20u);
    goto L_8487DF;
L_8487DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DFu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487DF AND
    cpu.logicAnd(0xFFu);
    goto L_8487E2;
L_8487E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487E2 ASL
    cpu.aslA();
    goto L_8487E3;
L_8487E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E3u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8487E3 TAX
    cpu.transfer("TAX");
    goto L_8487E4;
L_8487E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E4u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E4u, 5u, 3u, cpu.address("abs", 0x87E9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8487E4 PEA
    cpu.push16Value(hw, 0x87E9u);
    goto L_8487E7;
L_8487E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E7u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E7u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x87EBu + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $8487E7 JMP (87EB,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x87EBu+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x8487E7u); return; }
L_8487EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87EAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x87EAu,0x8487EAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87EAu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87EAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8487EA RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8487EAu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8487EAu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_848A98_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848A98u: goto L_848A98;
    case 0x848A9Au: goto L_848A9A;
    case 0x848A9Du: goto L_848A9D;
    case 0x848A9Fu: goto L_848A9F;
    case 0x848AA1u: goto L_848AA1;
    case 0x848AA3u: goto L_848AA3;
    case 0x848AA6u: goto L_848AA6;
    case 0x848AA9u: goto L_848AA9;
    case 0x848AACu: goto L_848AAC;
    case 0x848AAEu: goto L_848AAE;
    case 0x848AB1u: goto L_848AB1;
    case 0x848AB3u: goto L_848AB3;
    case 0x848AB6u: goto L_848AB6;
    case 0x848AB8u: goto L_848AB8;
    case 0x848ABCu: goto L_848ABC;
    case 0x848ABDu: goto L_848ABD;
    case 0x848ABFu: goto L_848ABF;
    case 0x848AC2u: goto L_848AC2;
    case 0x848AC5u: goto L_848AC5;
    case 0x848AC8u: goto L_848AC8;
    case 0x848ACAu: goto L_848ACA;
    case 0x848ACDu: goto L_848ACD;
    case 0x848ACFu: goto L_848ACF;
    case 0x848AD2u: goto L_848AD2;
    case 0x848AD4u: goto L_848AD4;
    case 0x848AD8u: goto L_848AD8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848A98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A98u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A98u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A98 SEP
    cpu.sep(0x20u);
    goto L_848A9A;
L_848A9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Au, 4u, 3u, cpu.address("abs", 0x062Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A9A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848A9D;
L_848A9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Du,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A9D BIT
    cpu.bit(0x1u, true);
    goto L_848A9F;
L_848A9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A9F BNE -> $848ABD
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848ABD; }
    goto L_848AA1;
L_848AA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA1u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AA1 REP
    cpu.rep(0x20u);
    goto L_848AA3;
L_848AA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA3u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AA3 LDX
    cpu.setX(0x2u, 16);
    goto L_848AA6;
L_848AA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA6u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AA6 LDY
    cpu.setY(0x6u, 16);
    goto L_848AA9;
L_848AA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AA9 LDA
    cpu.setA(0x2D9Au, 16);
    goto L_848AAC;
L_848AAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AACu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AACu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AAC STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_848AAE;
L_848AAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AAEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AAEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AAE LDA
    cpu.setA(0x7Eu, 16);
    goto L_848AB1;
L_848AB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AB1 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_848AB3;
L_848AB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AB3 LDA
    cpu.setA(0x1800u, 16);
    goto L_848AB6;
L_848AB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AB6 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_848AB8;
L_848AB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB8u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848AB8 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8ABBu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8ABCu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x848AB8u); }
    goto L_848ABC;
L_848ABC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ABCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8ABCu,0x848ABCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ABCu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ABCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848ABC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848ABCu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848ABCu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_848ABD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ABDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ABDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ABDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848ABD REP
    cpu.rep(0x20u);
    goto L_848ABF;
L_848ABF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ABFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ABFu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ABFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848ABF LDX
    cpu.setX(0x2u, 16);
    goto L_848AC2;
L_848AC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AC2u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AC2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AC2 LDY
    cpu.setY(0x7u, 16);
    goto L_848AC5;
L_848AC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AC5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AC5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AC5 LDA
    cpu.setA(0x2DACu, 16);
    goto L_848AC8;
L_848AC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AC8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AC8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AC8 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_848ACA;
L_848ACA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ACAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ACAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ACAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848ACA LDA
    cpu.setA(0x7Eu, 16);
    goto L_848ACD;
L_848ACD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ACDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ACDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ACDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848ACD STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_848ACF;
L_848ACF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ACFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ACFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ACFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848ACF LDA
    cpu.setA(0x1800u, 16);
    goto L_848AD2;
L_848AD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AD2 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_848AD4;
L_848AD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD4u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD4u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848AD4 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8AD7u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8AD8u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x848AD4u); }
    goto L_848AD8;
L_848AD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AD8u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8AD8u,0x848AD8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848AD8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848AD8u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848AD8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_848A98_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848A98u: goto L_848A98;
    case 0x848A9Au: goto L_848A9A;
    case 0x848A9Du: goto L_848A9D;
    case 0x848A9Fu: goto L_848A9F;
    case 0x848AA1u: goto L_848AA1;
    case 0x848AA3u: goto L_848AA3;
    case 0x848AA6u: goto L_848AA6;
    case 0x848AA9u: goto L_848AA9;
    case 0x848AACu: goto L_848AAC;
    case 0x848AAEu: goto L_848AAE;
    case 0x848AB1u: goto L_848AB1;
    case 0x848AB3u: goto L_848AB3;
    case 0x848AB6u: goto L_848AB6;
    case 0x848AB8u: goto L_848AB8;
    case 0x848ABCu: goto L_848ABC;
    case 0x848ABDu: goto L_848ABD;
    case 0x848ABFu: goto L_848ABF;
    case 0x848AC2u: goto L_848AC2;
    case 0x848AC5u: goto L_848AC5;
    case 0x848AC8u: goto L_848AC8;
    case 0x848ACAu: goto L_848ACA;
    case 0x848ACDu: goto L_848ACD;
    case 0x848ACFu: goto L_848ACF;
    case 0x848AD2u: goto L_848AD2;
    case 0x848AD4u: goto L_848AD4;
    case 0x848AD8u: goto L_848AD8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848A98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A98u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A98u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A98 SEP
    cpu.sep(0x20u);
    goto L_848A9A;
L_848A9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Au, 4u, 3u, cpu.address("abs", 0x062Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A9A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848A9D;
L_848A9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Du,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A9D BIT
    cpu.bit(0x1u, true);
    goto L_848A9F;
L_848A9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A9F BNE -> $848ABD
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848ABD; }
    goto L_848AA1;
L_848AA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA1u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AA1 REP
    cpu.rep(0x20u);
    goto L_848AA3;
L_848AA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA3u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AA3 LDX
    cpu.setX(0x2u, 16);
    goto L_848AA6;
L_848AA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA6u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AA6 LDY
    cpu.setY(0x6u, 16);
    goto L_848AA9;
L_848AA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AA9 LDA
    cpu.setA(0x2D9Au, 16);
    goto L_848AAC;
L_848AAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AACu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AACu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AAC STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_848AAE;
L_848AAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AAEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AAEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AAE LDA
    cpu.setA(0x7Eu, 16);
    goto L_848AB1;
L_848AB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AB1 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_848AB3;
L_848AB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AB3 LDA
    cpu.setA(0x1800u, 16);
    goto L_848AB6;
L_848AB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AB6 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_848AB8;
L_848AB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AB8u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848AB8 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8ABBu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8ABCu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x848AB8u); }
    goto L_848ABC;
L_848ABC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ABCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8ABCu,0x848ABCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ABCu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ABCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848ABC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848ABCu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848ABCu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_848ABD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ABDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ABDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ABDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848ABD REP
    cpu.rep(0x20u);
    goto L_848ABF;
L_848ABF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ABFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ABFu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ABFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848ABF LDX
    cpu.setX(0x2u, 16);
    goto L_848AC2;
L_848AC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AC2u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AC2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AC2 LDY
    cpu.setY(0x7u, 16);
    goto L_848AC5;
L_848AC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AC5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AC5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AC5 LDA
    cpu.setA(0x2DACu, 16);
    goto L_848AC8;
L_848AC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AC8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AC8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AC8 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_848ACA;
L_848ACA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ACAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ACAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ACAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848ACA LDA
    cpu.setA(0x7Eu, 16);
    goto L_848ACD;
L_848ACD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ACDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ACDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ACDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848ACD STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_848ACF;
L_848ACF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ACFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ACFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ACFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848ACF LDA
    cpu.setA(0x1800u, 16);
    goto L_848AD2;
L_848AD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848AD2 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_848AD4;
L_848AD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD4u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD4u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848AD4 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8AD7u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8AD8u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x848AD4u); }
    goto L_848AD8;
L_848AD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AD8u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8AD8u,0x848AD8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848AD8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848AD8u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848AD8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_849974_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849974u: goto L_849974;
    case 0x849976u: goto L_849976;
    case 0x849979u: goto L_849979;
    case 0x84997Bu: goto L_84997B;
    case 0x84997Du: goto L_84997D;
    case 0x849980u: goto L_849980;
    case 0x849983u: goto L_849983;
    case 0x849986u: goto L_849986;
    case 0x849989u: goto L_849989;
    case 0x84998Bu: goto L_84998B;
    case 0x84998Du: goto L_84998D;
    case 0x84998Fu: goto L_84998F;
    case 0x849992u: goto L_849992;
    case 0x849994u: goto L_849994;
    case 0x849997u: goto L_849997;
    case 0x84999Au: goto L_84999A;
    case 0x84999Cu: goto L_84999C;
    case 0x84999Eu: goto L_84999E;
    case 0x8499A0u: goto L_8499A0;
    case 0x8499A3u: goto L_8499A3;
    case 0x8499A6u: goto L_8499A6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849974:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9974u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9974u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9974u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849974 SEP
    cpu.sep(0x20u);
    goto L_849976;
L_849976:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9976u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9976u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9976u, 4u, 3u, cpu.address("abs", 0x062Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849976 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849979;
L_849979:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9979u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9979u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9979u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849979 BIT
    cpu.bit(0x1u, true);
    goto L_84997B;
L_84997B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x997Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x997Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x997Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84997B BNE -> $84998B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84998B; }
    goto L_84997D;
L_84997D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x997Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x997Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x997Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84997D LDX
    cpu.setX(0x8u, 16);
    goto L_849980;
L_849980:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9980u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9980u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9980u, 6u, 3u, cpu.address("abs", 0x99A7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849980 JSR -> $8499A7 stack real
    { cpu.push16Value(hw,0x9982u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9983u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x99A7u), 0x849980u); }
    goto L_849983;
L_849983:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9983u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9983u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9983u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849983 LDX
    cpu.setX(0x4u, 16);
    goto L_849986;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9983u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9983u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849983 LDX
    cpu.setX(0x4u, 16);
    goto L_849986;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9983u,0x849983u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849986:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9986u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9986u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9986u, 6u, 3u, cpu.address("abs", 0x9A15u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849986 JSR -> $849A15 stack real
    { cpu.push16Value(hw,0x9988u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9989u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9A15u), 0x849986u); }
    goto L_849989;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9986u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9986u, 6u, 3u, cpu.address("abs", 0x9A15u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849986 JSR -> $849A15 stack real
    { cpu.push16Value(hw,0x9988u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9989u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9A15u), 0x849986u); }
    goto L_849989;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9986u,0x849986u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849989:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9989u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9989u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9989u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849989 BRA -> $8499A6
    goto L_8499A6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9989u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9989u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849989 BRA -> $8499A6
    goto L_8499A6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9989u,0x849989u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84998B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x998Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x998Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x998Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84998B REP
    cpu.rep(0x20u);
    goto L_84998D;
L_84998D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x998Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x998Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x998Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84998D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84998F;
L_84998F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x998Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x998Fu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x998Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84998F BIT
    cpu.bit(0x30u, true);
    goto L_849992;
L_849992:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9992u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9992u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9992u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849992 BNE -> $84999A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84999A; }
    goto L_849994;
L_849994:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9994u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9994u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9994u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849994 LDX
    cpu.setX(0xAu, 16);
    goto L_849997;
L_849997:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9997u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9997u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9997u, 6u, 3u, cpu.address("abs", 0x99A7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849997 JSR -> $8499A7 stack real
    { cpu.push16Value(hw,0x9999u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x999Au,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x99A7u), 0x849997u); }
    goto L_84999A;
L_84999A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x999Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x999Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x999Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84999A REP
    cpu.rep(0x20u);
    goto L_84999C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x999Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x999Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84999A REP
    cpu.rep(0x20u);
    goto L_84999C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x999Au,0x84999Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84999C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x999Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x999Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x999Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84999C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84999E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x999Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x999Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84999C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84999E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x999Cu,0x84999Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84999E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x999Eu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x999Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x999Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84999E STA
    hw.write(cpu.address("dp", 0xA2u), cpu.a, cpu.m8?8:16);
    goto L_8499A0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x999Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x999Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84999E STA
    hw.write(cpu.address("dp", 0xA2u), cpu.a, cpu.m8?8:16);
    goto L_8499A0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x999Eu,0x84999Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8499A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99A0u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99A0u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99A0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8499A0 LDX
    cpu.setX(0x6u, 16);
    goto L_8499A3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99A0u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99A0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8499A0 LDX
    cpu.setX(0x6u, 16);
    goto L_8499A3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x99A0u,0x8499A0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8499A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99A3u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99A3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99A3u, 6u, 3u, cpu.address("abs", 0x9A15u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8499A3 JSR -> $849A15 stack real
    { cpu.push16Value(hw,0x99A5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x99A6u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9A15u), 0x8499A3u); }
    goto L_8499A6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99A3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99A3u, 6u, 3u, cpu.address("abs", 0x9A15u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8499A3 JSR -> $849A15 stack real
    { cpu.push16Value(hw,0x99A5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x99A6u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9A15u), 0x8499A3u); }
    goto L_8499A6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x99A3u,0x8499A3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8499A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99A6u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99A6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99A6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8499A6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8499A6u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8499A6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99A6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99A6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8499A6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8499A6u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8499A6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x99A6u,0x8499A6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_849974_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849974u: goto L_849974;
    case 0x849976u: goto L_849976;
    case 0x849979u: goto L_849979;
    case 0x84997Bu: goto L_84997B;
    case 0x84997Du: goto L_84997D;
    case 0x849980u: goto L_849980;
    case 0x849983u: goto L_849983;
    case 0x849986u: goto L_849986;
    case 0x849989u: goto L_849989;
    case 0x84998Bu: goto L_84998B;
    case 0x84998Du: goto L_84998D;
    case 0x84998Fu: goto L_84998F;
    case 0x849992u: goto L_849992;
    case 0x849994u: goto L_849994;
    case 0x849997u: goto L_849997;
    case 0x84999Au: goto L_84999A;
    case 0x84999Cu: goto L_84999C;
    case 0x84999Eu: goto L_84999E;
    case 0x8499A0u: goto L_8499A0;
    case 0x8499A3u: goto L_8499A3;
    case 0x8499A6u: goto L_8499A6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849974:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9974u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9974u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9974u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849974 SEP
    cpu.sep(0x20u);
    goto L_849976;
L_849976:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9976u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9976u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9976u, 4u, 3u, cpu.address("abs", 0x062Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849976 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849979;
L_849979:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9979u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9979u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9979u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849979 BIT
    cpu.bit(0x1u, true);
    goto L_84997B;
L_84997B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x997Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x997Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x997Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84997B BNE -> $84998B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84998B; }
    goto L_84997D;
L_84997D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x997Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x997Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x997Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84997D LDX
    cpu.setX(0x8u, 16);
    goto L_849980;
L_849980:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9980u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9980u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9980u, 6u, 3u, cpu.address("abs", 0x99A7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849980 JSR -> $8499A7 stack real
    { cpu.push16Value(hw,0x9982u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9983u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x99A7u), 0x849980u); }
    goto L_849983;
L_849983:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9983u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9983u,0x849983u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9983u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9983u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849983 LDX
    cpu.setX(0x4u, 16);
    goto L_849986;
L_849986:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9986u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9986u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9986u, 6u, 3u, cpu.address("abs", 0x9A15u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849986 JSR -> $849A15 stack real
    { cpu.push16Value(hw,0x9988u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9989u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9A15u), 0x849986u); }
    goto L_849989;
L_849989:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9989u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9989u,0x849989u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9989u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9989u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849989 BRA -> $8499A6
    goto L_8499A6;
L_84998B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x998Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x998Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x998Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84998B REP
    cpu.rep(0x20u);
    goto L_84998D;
L_84998D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x998Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x998Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x998Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84998D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84998F;
L_84998F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x998Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x998Fu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x998Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84998F BIT
    cpu.bit(0x30u, true);
    goto L_849992;
L_849992:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9992u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9992u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9992u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849992 BNE -> $84999A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84999A; }
    goto L_849994;
L_849994:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9994u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9994u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9994u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849994 LDX
    cpu.setX(0xAu, 16);
    goto L_849997;
L_849997:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9997u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9997u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9997u, 6u, 3u, cpu.address("abs", 0x99A7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849997 JSR -> $8499A7 stack real
    { cpu.push16Value(hw,0x9999u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x999Au,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x99A7u), 0x849997u); }
    goto L_84999A;
L_84999A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x999Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x999Au,0x84999Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x999Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x999Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84999A REP
    cpu.rep(0x20u);
    goto L_84999C;
L_84999C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x999Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x999Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x999Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84999C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84999E;
L_84999E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x999Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x999Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x999Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84999E STA
    hw.write(cpu.address("dp", 0xA2u), cpu.a, cpu.m8?8:16);
    goto L_8499A0;
L_8499A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99A0u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99A0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8499A0 LDX
    cpu.setX(0x6u, 16);
    goto L_8499A3;
L_8499A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99A3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99A3u, 6u, 3u, cpu.address("abs", 0x9A15u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8499A3 JSR -> $849A15 stack real
    { cpu.push16Value(hw,0x99A5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x99A6u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9A15u), 0x8499A3u); }
    goto L_8499A6;
L_8499A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99A6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x99A6u,0x8499A6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99A6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99A6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8499A6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8499A6u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8499A6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_849EF1_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849EF1u: goto L_849EF1;
    case 0x849EF3u: goto L_849EF3;
    case 0x849EF4u: goto L_849EF4;
    case 0x849EF5u: goto L_849EF5;
    case 0x849EF9u: goto L_849EF9;
    case 0x849EFBu: goto L_849EFB;
    case 0x849EFEu: goto L_849EFE;
    case 0x849F00u: goto L_849F00;
    case 0x849F02u: goto L_849F02;
    case 0x849F04u: goto L_849F04;
    case 0x849F08u: goto L_849F08;
    case 0x849F0Au: goto L_849F0A;
    case 0x849F0Cu: goto L_849F0C;
    case 0x849F10u: goto L_849F10;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849EF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF1u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849EF1 REP
    cpu.rep(0x20u);
    goto L_849EF3;
L_849EF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF3u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849EF3 ASL
    cpu.aslA();
    goto L_849EF4;
L_849EF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF4u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849EF4 TAX
    cpu.transfer("TAX");
    goto L_849EF5;
L_849EF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF5u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF5u, 6u, 4u, ((0x938000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849EF5 LDA
    cpu.loadA(hw.readW(((0x938000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849EF9;
L_849EF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849EF9 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_849EFB;
L_849EFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849EFB LDA
    cpu.setA(0x93u, 16);
    goto L_849EFE;
L_849EFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849EFE STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_849F00;
L_849F00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F00u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F00u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849F00 STZ
    hw.write(cpu.address("dp", 0x3u), 0, cpu.m8?8:16);
    goto L_849F02;
L_849F02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F02u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F02u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849F02 STZ
    hw.write(cpu.address("dp", 0x4u), 0, cpu.m8?8:16);
    goto L_849F04;
L_849F04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F04u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F04u, 6u, 4u, ((0x849F11u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849F04 LDA
    cpu.loadA(hw.readW(((0x849F11u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849F08;
L_849F08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F08u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F08u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849F08 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_849F0A;
L_849F0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Au,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849F0A STY
    hw.write(cpu.address("dp", 0xCu), cpu.y, cpu.x8?8:16);
    goto L_849F0C;
L_849F0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Cu, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849F0C JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9F0Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9F10u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x849F0Cu); }
    goto L_849F10;
L_849F10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F10u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F10u,0x849F10u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F10u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F10u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849F10 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849F10u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849F10u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84B657_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84B657u: goto L_84B657;
    case 0x84B65Au: goto L_84B65A;
    case 0x84B65Cu: goto L_84B65C;
    case 0x84B65Fu: goto L_84B65F;
    case 0x84B661u: goto L_84B661;
    case 0x84B663u: goto L_84B663;
    case 0x84B667u: goto L_84B667;
    case 0x84B66Au: goto L_84B66A;
    case 0x84B66Cu: goto L_84B66C;
    case 0x84B66Fu: goto L_84B66F;
    case 0x84B671u: goto L_84B671;
    case 0x84B673u: goto L_84B673;
    case 0x84B677u: goto L_84B677;
    case 0x84B67Au: goto L_84B67A;
    case 0x84B67Cu: goto L_84B67C;
    case 0x84B67Fu: goto L_84B67F;
    case 0x84B681u: goto L_84B681;
    case 0x84B683u: goto L_84B683;
    case 0x84B687u: goto L_84B687;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84B657:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB657u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB657u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB657u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B657 LDA
    cpu.setA(0x800u, 16);
    goto L_84B65A;
L_84B65A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB65Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB65Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB65Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B65A STA
    hw.write(cpu.address("dp", 0xD3u), cpu.a, cpu.m8?8:16);
    goto L_84B65C;
L_84B65C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB65Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB65Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB65Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B65C LDA
    cpu.setA(0x2C86u, 16);
    goto L_84B65F;
L_84B65F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB65Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB65Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB65Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xCDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B65F STA
    hw.write(cpu.address("dp", 0xCDu), cpu.a, cpu.m8?8:16);
    goto L_84B661;
L_84B661:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB661u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB661u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB661u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B661 STA
    hw.write(cpu.address("dp", 0xC9u), cpu.a, cpu.m8?8:16);
    goto L_84B663;
L_84B663:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB663u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB663u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB663u, 8u, 4u, 0x808F30u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B663 JSL -> $808F30 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB666u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB667u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808F30u, 0x84B663u); }
    goto L_84B667;
L_84B667:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB667u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB667u,0x84B667u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB667u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB667u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B667 LDA
    cpu.setA(0x1C00u, 16);
    goto L_84B66A;
L_84B66A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB66Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B66A STA
    hw.write(cpu.address("dp", 0xD3u), cpu.a, cpu.m8?8:16);
    goto L_84B66C;
L_84B66C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB66Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B66C LDA
    cpu.setA(0x2C98u, 16);
    goto L_84B66F;
L_84B66F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB66Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xCDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B66F STA
    hw.write(cpu.address("dp", 0xCDu), cpu.a, cpu.m8?8:16);
    goto L_84B671;
L_84B671:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB671u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB671u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB671u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B671 STA
    hw.write(cpu.address("dp", 0xC9u), cpu.a, cpu.m8?8:16);
    goto L_84B673;
L_84B673:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB673u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB673u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB673u, 8u, 4u, 0x808F30u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B673 JSL -> $808F30 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB676u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB677u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808F30u, 0x84B673u); }
    goto L_84B677;
L_84B677:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB677u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB677u,0x84B677u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB677u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB677u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B677 LDA
    cpu.setA(0x800u, 16);
    goto L_84B67A;
L_84B67A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB67Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB67Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB67Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B67A STA
    hw.write(cpu.address("dp", 0xD3u), cpu.a, cpu.m8?8:16);
    goto L_84B67C;
L_84B67C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB67Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB67Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB67Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B67C LDA
    cpu.setA(0x2CAAu, 16);
    goto L_84B67F;
L_84B67F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB67Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB67Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB67Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xCDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B67F STA
    hw.write(cpu.address("dp", 0xCDu), cpu.a, cpu.m8?8:16);
    goto L_84B681;
L_84B681:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB681u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB681u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB681u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B681 STA
    hw.write(cpu.address("dp", 0xC9u), cpu.a, cpu.m8?8:16);
    goto L_84B683;
L_84B683:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB683u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB683u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB683u, 8u, 4u, 0x808F30u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B683 JSL -> $808F30 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB686u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB687u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808F30u, 0x84B683u); }
    goto L_84B687;
L_84B687:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB687u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB687u,0x84B687u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB687u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB687u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B687 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84B687u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84B687u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84B657_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84B657u: goto L_84B657;
    case 0x84B65Au: goto L_84B65A;
    case 0x84B65Cu: goto L_84B65C;
    case 0x84B65Fu: goto L_84B65F;
    case 0x84B661u: goto L_84B661;
    case 0x84B663u: goto L_84B663;
    case 0x84B667u: goto L_84B667;
    case 0x84B66Au: goto L_84B66A;
    case 0x84B66Cu: goto L_84B66C;
    case 0x84B66Fu: goto L_84B66F;
    case 0x84B671u: goto L_84B671;
    case 0x84B673u: goto L_84B673;
    case 0x84B677u: goto L_84B677;
    case 0x84B67Au: goto L_84B67A;
    case 0x84B67Cu: goto L_84B67C;
    case 0x84B67Fu: goto L_84B67F;
    case 0x84B681u: goto L_84B681;
    case 0x84B683u: goto L_84B683;
    case 0x84B687u: goto L_84B687;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84B657:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB657u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB657u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB657u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B657 LDA
    cpu.setA(0x800u, 16);
    goto L_84B65A;
L_84B65A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB65Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB65Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB65Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B65A STA
    hw.write(cpu.address("dp", 0xD3u), cpu.a, cpu.m8?8:16);
    goto L_84B65C;
L_84B65C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB65Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB65Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB65Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B65C LDA
    cpu.setA(0x2C86u, 16);
    goto L_84B65F;
L_84B65F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB65Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB65Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB65Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xCDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B65F STA
    hw.write(cpu.address("dp", 0xCDu), cpu.a, cpu.m8?8:16);
    goto L_84B661;
L_84B661:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB661u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB661u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB661u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B661 STA
    hw.write(cpu.address("dp", 0xC9u), cpu.a, cpu.m8?8:16);
    goto L_84B663;
L_84B663:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB663u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB663u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB663u, 8u, 4u, 0x808F30u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B663 JSL -> $808F30 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB666u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB667u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808F30u, 0x84B663u); }
    goto L_84B667;
L_84B667:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB667u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB667u,0x84B667u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB667u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB667u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B667 LDA
    cpu.setA(0x1C00u, 16);
    goto L_84B66A;
L_84B66A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB66Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B66A STA
    hw.write(cpu.address("dp", 0xD3u), cpu.a, cpu.m8?8:16);
    goto L_84B66C;
L_84B66C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB66Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B66C LDA
    cpu.setA(0x2C98u, 16);
    goto L_84B66F;
L_84B66F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB66Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xCDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B66F STA
    hw.write(cpu.address("dp", 0xCDu), cpu.a, cpu.m8?8:16);
    goto L_84B671;
L_84B671:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB671u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB671u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB671u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B671 STA
    hw.write(cpu.address("dp", 0xC9u), cpu.a, cpu.m8?8:16);
    goto L_84B673;
L_84B673:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB673u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB673u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB673u, 8u, 4u, 0x808F30u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B673 JSL -> $808F30 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB676u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB677u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808F30u, 0x84B673u); }
    goto L_84B677;
L_84B677:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB677u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB677u,0x84B677u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB677u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB677u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B677 LDA
    cpu.setA(0x800u, 16);
    goto L_84B67A;
L_84B67A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB67Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB67Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB67Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B67A STA
    hw.write(cpu.address("dp", 0xD3u), cpu.a, cpu.m8?8:16);
    goto L_84B67C;
L_84B67C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB67Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB67Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB67Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B67C LDA
    cpu.setA(0x2CAAu, 16);
    goto L_84B67F;
L_84B67F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB67Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB67Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB67Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xCDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B67F STA
    hw.write(cpu.address("dp", 0xCDu), cpu.a, cpu.m8?8:16);
    goto L_84B681;
L_84B681:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB681u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB681u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB681u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B681 STA
    hw.write(cpu.address("dp", 0xC9u), cpu.a, cpu.m8?8:16);
    goto L_84B683;
L_84B683:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB683u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB683u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB683u, 8u, 4u, 0x808F30u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B683 JSL -> $808F30 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB686u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB687u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808F30u, 0x84B683u); }
    goto L_84B687;
L_84B687:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB687u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB687u,0x84B687u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB687u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB687u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B687 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84B687u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84B687u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84B8CA_E0M1X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84B8CAu: goto L_84B8CA;
    case 0x84B8CCu: goto L_84B8CC;
    case 0x84B8CFu: goto L_84B8CF;
    case 0x84B8D1u: goto L_84B8D1;
    case 0x84B8D4u: goto L_84B8D4;
    case 0x84B8D7u: goto L_84B8D7;
    case 0x84B8DAu: goto L_84B8DA;
    case 0x84B8DDu: goto L_84B8DD;
    case 0x84B8DFu: goto L_84B8DF;
    case 0x84B8E2u: goto L_84B8E2;
    case 0x84B8E5u: goto L_84B8E5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84B8CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8CAu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8CAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B8CA REP
    cpu.rep(0x20u);
    goto L_84B8CC;
L_84B8CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8CCu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8CCu, 5u, 3u, cpu.address("abs", 0x065Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B8CC LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x65Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B8CF;
L_84B8CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8CFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8CFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B8CF BNE -> $84B8DF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84B8DF; }
    goto L_84B8D1;
L_84B8D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B8D1 LDA
    cpu.setA(0x4u, 16);
    goto L_84B8D4;
L_84B8D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D4u, 5u, 3u, cpu.address("abs", 0x065Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B8D4 STA
    hw.write(cpu.address("abs", 0x65Cu), cpu.a, cpu.m8?8:16);
    goto L_84B8D7;
L_84B8D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D7u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D7u, 8u, 3u, cpu.address("abs", 0x0084u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B8D7 DEC
    cpu.decMem(hw, cpu.address("abs", 0x84u), cpu.m8?8:16);
    goto L_84B8DA;
L_84B8DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DAu,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DAu, 8u, 3u, cpu.address("abs", 0x0082u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B8DA DEC
    cpu.decMem(hw, cpu.address("abs", 0x82u), cpu.m8?8:16);
    goto L_84B8DD;
L_84B8DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DDu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B8DD BRA -> $84B8E2
    goto L_84B8E2;
L_84B8DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DFu,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DFu, 8u, 3u, cpu.address("abs", 0x065Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B8DF DEC
    cpu.decMem(hw, cpu.address("abs", 0x65Cu), cpu.m8?8:16);
    goto L_84B8E2;
L_84B8E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E2u, 6u, 3u, cpu.address("abs", 0xB86Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B8E2 JSR -> $84B86A stack real
    { cpu.push16Value(hw,0xB8E4u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB8E5u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB86Au), 0x84B8E2u); }
    goto L_84B8E5;
L_84B8E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8E5u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB8E5u,0x84B8E5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B8E5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84B8E5u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84B8E5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84B8CA_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84B8CAu: goto L_84B8CA;
    case 0x84B8CCu: goto L_84B8CC;
    case 0x84B8CFu: goto L_84B8CF;
    case 0x84B8D1u: goto L_84B8D1;
    case 0x84B8D4u: goto L_84B8D4;
    case 0x84B8D7u: goto L_84B8D7;
    case 0x84B8DAu: goto L_84B8DA;
    case 0x84B8DDu: goto L_84B8DD;
    case 0x84B8DFu: goto L_84B8DF;
    case 0x84B8E2u: goto L_84B8E2;
    case 0x84B8E5u: goto L_84B8E5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84B8CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8CAu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8CAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B8CA REP
    cpu.rep(0x20u);
    goto L_84B8CC;
L_84B8CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8CCu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8CCu, 5u, 3u, cpu.address("abs", 0x065Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B8CC LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x65Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B8CF;
L_84B8CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8CFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8CFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B8CF BNE -> $84B8DF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84B8DF; }
    goto L_84B8D1;
L_84B8D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B8D1 LDA
    cpu.setA(0x4u, 16);
    goto L_84B8D4;
L_84B8D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D4u, 5u, 3u, cpu.address("abs", 0x065Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B8D4 STA
    hw.write(cpu.address("abs", 0x65Cu), cpu.a, cpu.m8?8:16);
    goto L_84B8D7;
L_84B8D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D7u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D7u, 8u, 3u, cpu.address("abs", 0x0084u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B8D7 DEC
    cpu.decMem(hw, cpu.address("abs", 0x84u), cpu.m8?8:16);
    goto L_84B8DA;
L_84B8DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DAu,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DAu, 8u, 3u, cpu.address("abs", 0x0082u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B8DA DEC
    cpu.decMem(hw, cpu.address("abs", 0x82u), cpu.m8?8:16);
    goto L_84B8DD;
L_84B8DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DDu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B8DD BRA -> $84B8E2
    goto L_84B8E2;
L_84B8DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DFu,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DFu, 8u, 3u, cpu.address("abs", 0x065Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B8DF DEC
    cpu.decMem(hw, cpu.address("abs", 0x65Cu), cpu.m8?8:16);
    goto L_84B8E2;
L_84B8E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E2u, 6u, 3u, cpu.address("abs", 0xB86Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B8E2 JSR -> $84B86A stack real
    { cpu.push16Value(hw,0xB8E4u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB8E5u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB86Au), 0x84B8E2u); }
    goto L_84B8E5;
L_84B8E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8E5u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB8E5u,0x84B8E5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B8E5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84B8E5u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84B8E5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84BBF7_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84BBF7u: goto L_84BBF7;
    case 0x84BBF9u: goto L_84BBF9;
    case 0x84BBFCu: goto L_84BBFC;
    case 0x84BBFEu: goto L_84BBFE;
    case 0x84BC01u: goto L_84BC01;
    case 0x84BC04u: goto L_84BC04;
    case 0x84BC07u: goto L_84BC07;
    case 0x84BC0Au: goto L_84BC0A;
    case 0x84BC0Du: goto L_84BC0D;
    case 0x84BC0Fu: goto L_84BC0F;
    case 0x84BC12u: goto L_84BC12;
    case 0x84BC15u: goto L_84BC15;
    case 0x84BC18u: goto L_84BC18;
    case 0x84BC1Bu: goto L_84BC1B;
    case 0x84BC1Eu: goto L_84BC1E;
    case 0x84BC21u: goto L_84BC21;
    case 0x84BC23u: goto L_84BC23;
    case 0x84BC26u: goto L_84BC26;
    case 0x84BC27u: goto L_84BC27;
    case 0x84BC28u: goto L_84BC28;
    case 0x84BC2Bu: goto L_84BC2B;
    case 0x84BC2Eu: goto L_84BC2E;
    case 0x84BC31u: goto L_84BC31;
    case 0x84BC32u: goto L_84BC32;
    case 0x84BC35u: goto L_84BC35;
    case 0x84BC36u: goto L_84BC36;
    case 0x84BC37u: goto L_84BC37;
    case 0x84BC3Au: goto L_84BC3A;
    case 0x84BC3Du: goto L_84BC3D;
    case 0x84BC3Fu: goto L_84BC3F;
    case 0x84BC42u: goto L_84BC42;
    case 0x84BC43u: goto L_84BC43;
    case 0x84BC46u: goto L_84BC46;
    case 0x84BC47u: goto L_84BC47;
    case 0x84BC48u: goto L_84BC48;
    case 0x84BC4Bu: goto L_84BC4B;
    case 0x84BC4Eu: goto L_84BC4E;
    case 0x84BC51u: goto L_84BC51;
    case 0x84BC52u: goto L_84BC52;
    case 0x84BC53u: goto L_84BC53;
    case 0x84BC56u: goto L_84BC56;
    case 0x84BC59u: goto L_84BC59;
    case 0x84BC5Cu: goto L_84BC5C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84BBF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF7u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BBF7 REP
    cpu.rep(0x20u);
    goto L_84BBF9;
L_84BBF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF9u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBF9u, 8u, 3u, cpu.address("abs", 0x0658u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BBF9 DEC
    cpu.decMem(hw, cpu.address("abs", 0x658u), cpu.m8?8:16);
    goto L_84BBFC;
L_84BBFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBFCu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBFCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BBFC BPL -> $84BC5C
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_84BC5C; }
    goto L_84BBFE;
L_84BBFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBFEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBFEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BBFE LDA
    cpu.setA(0x3u, 16);
    goto L_84BC01;
L_84BC01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC01u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC01u, 5u, 3u, cpu.address("abs", 0x0658u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC01 STA
    hw.write(cpu.address("abs", 0x658u), cpu.a, cpu.m8?8:16);
    goto L_84BC04;
L_84BC04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC04u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC04u, 8u, 3u, cpu.address("abs", 0x06F5u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC04 INC
    cpu.incMem(hw, cpu.address("abs", 0x6F5u), cpu.m8?8:16);
    goto L_84BC07;
L_84BC07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC07u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC07u, 5u, 3u, cpu.address("abs", 0x06F5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC07 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6F5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BC0A;
L_84BC0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC0A CMP
    cpu.compareA(0x10u);
    goto L_84BC0D;
L_84BC0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Du,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC0D BCC -> $84BC1E
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_84BC1E; }
    goto L_84BC0F;
L_84BC0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC0Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC0F LDA
    cpu.setA(0x1u, 16);
    goto L_84BC12;
L_84BC12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC12u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC12u, 5u, 3u, cpu.address("abs", 0x06F5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC12 STA
    hw.write(cpu.address("abs", 0x6F5u), cpu.a, cpu.m8?8:16);
    goto L_84BC15;
L_84BC15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC15u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC15u, 5u, 3u, cpu.address("abs", 0x06F1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC15 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6F1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BC18;
L_84BC18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC18u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC18u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC18 EOR
    cpu.logicXor(0x1u);
    goto L_84BC1B;
L_84BC1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Bu, 5u, 3u, cpu.address("abs", 0x06F1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC1B STA
    hw.write(cpu.address("abs", 0x6F1u), cpu.a, cpu.m8?8:16);
    goto L_84BC1E;
L_84BC1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC1Eu, 5u, 3u, cpu.address("abs", 0x06F1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC1E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6F1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BC21;
L_84BC21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC21u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC21u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC21 BEQ -> $84BC3F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_84BC3F; }
    goto L_84BC23;
L_84BC23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC23u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC23u, 5u, 3u, cpu.address("abs", 0x06F5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC23 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6F5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BC26;
L_84BC26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC26u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC26u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC26 ASL
    cpu.aslA();
    goto L_84BC27;
L_84BC27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC27u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC27u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC27 TAY
    cpu.transfer("TAY");
    goto L_84BC28;
L_84BC28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC28u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC28u, 5u + 1u, 3u, cpu.address("absy", 0x1AE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC28 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1AE0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BC2B;
L_84BC2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Bu, 5u, 3u, cpu.address("abs", 0x19E2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC2B STA
    hw.write(cpu.address("abs", 0x19E2u), cpu.a, cpu.m8?8:16);
    goto L_84BC2E;
L_84BC2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC2Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC2E LDA
    cpu.setA(0x10u, 16);
    goto L_84BC31;
L_84BC31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC31u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC31u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC31 SEC
    cpu.setFlag('C', true);
    goto L_84BC32;
L_84BC32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC32u,cpu,0xEDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC32u, 5u, 3u, cpu.address("abs", 0x06F5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC32 SBC
    cpu.sbc(hw.readW(cpu.address("abs", 0x6F5u), cpu.m8?8:16));
    goto L_84BC35;
L_84BC35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC35u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC35u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC35 ASL
    cpu.aslA();
    goto L_84BC36;
L_84BC36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC36u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC36u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC36 TAY
    cpu.transfer("TAY");
    goto L_84BC37;
L_84BC37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC37u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC37u, 5u + 1u, 3u, cpu.address("absy", 0x1AE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC37 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1AE0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BC3A;
L_84BC3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC3Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC3Au, 5u, 3u, cpu.address("abs", 0x19E4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC3A STA
    hw.write(cpu.address("abs", 0x19E4u), cpu.a, cpu.m8?8:16);
    goto L_84BC3D;
L_84BC3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC3Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC3Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC3D BRA -> $84BC59
    goto L_84BC59;
L_84BC3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC3Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC3Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC3F LDA
    cpu.setA(0x10u, 16);
    goto L_84BC42;
L_84BC42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC42u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC42u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC42 SEC
    cpu.setFlag('C', true);
    goto L_84BC43;
L_84BC43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC43u,cpu,0xEDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC43u, 5u, 3u, cpu.address("abs", 0x06F5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC43 SBC
    cpu.sbc(hw.readW(cpu.address("abs", 0x6F5u), cpu.m8?8:16));
    goto L_84BC46;
L_84BC46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC46u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC46u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC46 ASL
    cpu.aslA();
    goto L_84BC47;
L_84BC47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC47u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC47u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC47 TAY
    cpu.transfer("TAY");
    goto L_84BC48;
L_84BC48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC48u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC48u, 5u + 1u, 3u, cpu.address("absy", 0x1AE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC48 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1AE0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BC4B;
L_84BC4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC4Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC4Bu, 5u, 3u, cpu.address("abs", 0x19E2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC4B STA
    hw.write(cpu.address("abs", 0x19E2u), cpu.a, cpu.m8?8:16);
    goto L_84BC4E;
L_84BC4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC4Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC4Eu, 5u, 3u, cpu.address("abs", 0x06F5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC4E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6F5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BC51;
L_84BC51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC51u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC51u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC51 ASL
    cpu.aslA();
    goto L_84BC52;
L_84BC52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC52u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC52u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC52 TAY
    cpu.transfer("TAY");
    goto L_84BC53;
L_84BC53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC53u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC53u, 5u + 1u, 3u, cpu.address("absy", 0x1AE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC53 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1AE0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BC56;
L_84BC56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC56u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC56u, 5u, 3u, cpu.address("abs", 0x19E4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC56 STA
    hw.write(cpu.address("abs", 0x19E4u), cpu.a, cpu.m8?8:16);
    goto L_84BC59;
L_84BC59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC59u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC59u, 8u, 3u, cpu.address("abs", 0x0122u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BC59 INC
    cpu.incMem(hw, cpu.address("abs", 0x122u), cpu.m8?8:16);
    goto L_84BC5C;
L_84BC5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBC5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBC5Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBC5Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84BC5C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84BC5Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84BC5Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84C197_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84C197u: goto L_84C197;
    case 0x84C199u: goto L_84C199;
    case 0x84C19Au: goto L_84C19A;
    case 0x84C19Du: goto L_84C19D;
    case 0x84C1A0u: goto L_84C1A0;
    case 0x84C1A3u: goto L_84C1A3;
    case 0x84C1A6u: goto L_84C1A6;
    case 0x84C1A9u: goto L_84C1A9;
    case 0x84C1ABu: goto L_84C1AB;
    case 0x84C1AEu: goto L_84C1AE;
    case 0x84C1B1u: goto L_84C1B1;
    case 0x84C1B2u: goto L_84C1B2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84C197:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC197u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC197u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC197u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C197 REP
    cpu.rep(0x20u);
    goto L_84C199;
L_84C199:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC199u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC199u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC199u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C199 CLC
    cpu.setFlag('C', false);
    goto L_84C19A;
L_84C19A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC19Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC19Au,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC19Au, 8u, 3u, cpu.address("abs", 0x0112u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C19A INC
    cpu.incMem(hw, cpu.address("abs", 0x112u), cpu.m8?8:16);
    goto L_84C19D;
L_84C19D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC19Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC19Du,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC19Du, 8u, 3u, cpu.address("abs", 0x0112u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C19D INC
    cpu.incMem(hw, cpu.address("abs", 0x112u), cpu.m8?8:16);
    goto L_84C1A0;
L_84C1A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A0u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A0u, 8u, 3u, cpu.address("abs", 0x0112u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C1A0 INC
    cpu.incMem(hw, cpu.address("abs", 0x112u), cpu.m8?8:16);
    goto L_84C1A3;
L_84C1A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A3u, 5u, 3u, cpu.address("abs", 0x0112u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C1A3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x112u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84C1A6;
L_84C1A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C1A6 CMP
    cpu.compareA(0x100u);
    goto L_84C1A9;
L_84C1A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A9u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C1A9 BCC -> $84C1B2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_84C1B2; }
    goto L_84C1AB;
L_84C1AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1ABu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1ABu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C1AB LDA
    cpu.setA(0x100u, 16);
    goto L_84C1AE;
L_84C1AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1AEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1AEu, 5u, 3u, cpu.address("abs", 0x0112u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C1AE STA
    hw.write(cpu.address("abs", 0x112u), cpu.a, cpu.m8?8:16);
    goto L_84C1B1;
L_84C1B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1B1u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C1B1 SEC
    cpu.setFlag('C', true);
    goto L_84C1B2;
L_84C1B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1B2u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1B2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1B2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84C1B2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84C1B2u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84C1B2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1B2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1B2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84C1B2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84C1B2u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84C1B2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC1B2u,0x84C1B2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_84C197_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84C197u: goto L_84C197;
    case 0x84C199u: goto L_84C199;
    case 0x84C19Au: goto L_84C19A;
    case 0x84C19Du: goto L_84C19D;
    case 0x84C1A0u: goto L_84C1A0;
    case 0x84C1A3u: goto L_84C1A3;
    case 0x84C1A6u: goto L_84C1A6;
    case 0x84C1A9u: goto L_84C1A9;
    case 0x84C1ABu: goto L_84C1AB;
    case 0x84C1AEu: goto L_84C1AE;
    case 0x84C1B1u: goto L_84C1B1;
    case 0x84C1B2u: goto L_84C1B2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84C197:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC197u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC197u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC197u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C197 REP
    cpu.rep(0x20u);
    goto L_84C199;
L_84C199:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC199u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC199u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC199u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C199 CLC
    cpu.setFlag('C', false);
    goto L_84C19A;
L_84C19A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC19Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC19Au,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC19Au, 8u, 3u, cpu.address("abs", 0x0112u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C19A INC
    cpu.incMem(hw, cpu.address("abs", 0x112u), cpu.m8?8:16);
    goto L_84C19D;
L_84C19D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC19Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC19Du,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC19Du, 8u, 3u, cpu.address("abs", 0x0112u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C19D INC
    cpu.incMem(hw, cpu.address("abs", 0x112u), cpu.m8?8:16);
    goto L_84C1A0;
L_84C1A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A0u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A0u, 8u, 3u, cpu.address("abs", 0x0112u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C1A0 INC
    cpu.incMem(hw, cpu.address("abs", 0x112u), cpu.m8?8:16);
    goto L_84C1A3;
L_84C1A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A3u, 5u, 3u, cpu.address("abs", 0x0112u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C1A3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x112u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84C1A6;
L_84C1A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C1A6 CMP
    cpu.compareA(0x100u);
    goto L_84C1A9;
L_84C1A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A9u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C1A9 BCC -> $84C1B2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_84C1B2; }
    goto L_84C1AB;
L_84C1AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1ABu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1ABu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C1AB LDA
    cpu.setA(0x100u, 16);
    goto L_84C1AE;
L_84C1AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1AEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1AEu, 5u, 3u, cpu.address("abs", 0x0112u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C1AE STA
    hw.write(cpu.address("abs", 0x112u), cpu.a, cpu.m8?8:16);
    goto L_84C1B1;
L_84C1B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1B1u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C1B1 SEC
    cpu.setFlag('C', true);
    goto L_84C1B2;
L_84C1B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1B2u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1B2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1B2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84C1B2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84C1B2u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84C1B2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1B2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1B2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84C1B2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84C1B2u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84C1B2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC1B2u,0x84C1B2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_84C2FF_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84C2FFu: goto L_84C2FF;
    case 0x84C301u: goto L_84C301;
    case 0x84C304u: goto L_84C304;
    case 0x84C307u: goto L_84C307;
    case 0x84C30Au: goto L_84C30A;
    case 0x84C30Du: goto L_84C30D;
    case 0x84C310u: goto L_84C310;
    case 0x84C313u: goto L_84C313;
    case 0x84C316u: goto L_84C316;
    case 0x84C319u: goto L_84C319;
    case 0x84C31Cu: goto L_84C31C;
    case 0x84C31Eu: goto L_84C31E;
    case 0x84C321u: goto L_84C321;
    case 0x84C322u: goto L_84C322;
    case 0x84C324u: goto L_84C324;
    case 0x84C326u: goto L_84C326;
    case 0x84C329u: goto L_84C329;
    case 0x84C32Bu: goto L_84C32B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84C2FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2FFu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2FFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2FF REP
    cpu.rep(0x20u);
    goto L_84C301;
L_84C301:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC301u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC301u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC301u, 5u, 3u, cpu.address("abs", 0x0128u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C301 STZ
    hw.write(cpu.address("abs", 0x128u), 0, cpu.m8?8:16);
    goto L_84C304;
L_84C304:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC304u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC304u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC304u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C304 LDA
    cpu.setA(0x10u, 16);
    goto L_84C307;
L_84C307:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC307u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC307u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC307u, 5u, 3u, cpu.address("abs", 0x012Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C307 STA
    hw.write(cpu.address("abs", 0x12Au), cpu.a, cpu.m8?8:16);
    goto L_84C30A;
L_84C30A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC30Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC30Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC30Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C30A LDA
    cpu.setA(0x10u, 16);
    goto L_84C30D;
L_84C30D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC30Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC30Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC30Du, 5u, 3u, cpu.address("abs", 0x0130u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C30D STA
    hw.write(cpu.address("abs", 0x130u), cpu.a, cpu.m8?8:16);
    goto L_84C310;
L_84C310:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC310u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC310u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC310u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C310 LDA
    cpu.setA(0x100u, 16);
    goto L_84C313;
L_84C313:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC313u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC313u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC313u, 5u, 3u, cpu.address("abs", 0x012Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C313 STA
    hw.write(cpu.address("abs", 0x12Cu), cpu.a, cpu.m8?8:16);
    goto L_84C316;
L_84C316:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC316u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC316u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC316u, 5u, 3u, cpu.address("abs", 0x012Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C316 STZ
    hw.write(cpu.address("abs", 0x12Eu), 0, cpu.m8?8:16);
    goto L_84C319;
L_84C319:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC319u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC319u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC319u, 5u, 3u, cpu.address("abs", 0x012Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C319 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x12Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84C31C;
L_84C31C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC31Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC31Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC31Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C31C STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_84C31E;
L_84C31E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC31Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC31Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC31Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C31E LDA
    cpu.setA(0x10u, 16);
    goto L_84C321;
L_84C321:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC321u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC321u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC321u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C321 SEC
    cpu.setFlag('C', true);
    goto L_84C322;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC321u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC321u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C321 SEC
    cpu.setFlag('C', true);
    goto L_84C322;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC321u,0x84C321u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84C322:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC322u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC322u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC322u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C322 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16));
    goto L_84C324;
L_84C324:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC324u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC324u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC324u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C324 BMI -> $84C32B
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_84C32B; }
    goto L_84C326;
L_84C326:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC326u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC326u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC326u, 8u, 3u, cpu.address("abs", 0x012Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C326 INC
    cpu.incMem(hw, cpu.address("abs", 0x12Eu), cpu.m8?8:16);
    goto L_84C329;
L_84C329:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC329u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC329u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC329u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C329 BRA -> $84C321
    goto L_84C321;
L_84C32B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC32Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC32Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC32Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84C32B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84C32Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84C32Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84C2FF_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84C2FFu: goto L_84C2FF;
    case 0x84C301u: goto L_84C301;
    case 0x84C304u: goto L_84C304;
    case 0x84C307u: goto L_84C307;
    case 0x84C30Au: goto L_84C30A;
    case 0x84C30Du: goto L_84C30D;
    case 0x84C310u: goto L_84C310;
    case 0x84C313u: goto L_84C313;
    case 0x84C316u: goto L_84C316;
    case 0x84C319u: goto L_84C319;
    case 0x84C31Cu: goto L_84C31C;
    case 0x84C31Eu: goto L_84C31E;
    case 0x84C321u: goto L_84C321;
    case 0x84C322u: goto L_84C322;
    case 0x84C324u: goto L_84C324;
    case 0x84C326u: goto L_84C326;
    case 0x84C329u: goto L_84C329;
    case 0x84C32Bu: goto L_84C32B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84C2FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2FFu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2FFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C2FF REP
    cpu.rep(0x20u);
    goto L_84C301;
L_84C301:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC301u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC301u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC301u, 5u, 3u, cpu.address("abs", 0x0128u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C301 STZ
    hw.write(cpu.address("abs", 0x128u), 0, cpu.m8?8:16);
    goto L_84C304;
L_84C304:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC304u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC304u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC304u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C304 LDA
    cpu.setA(0x10u, 16);
    goto L_84C307;
L_84C307:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC307u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC307u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC307u, 5u, 3u, cpu.address("abs", 0x012Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C307 STA
    hw.write(cpu.address("abs", 0x12Au), cpu.a, cpu.m8?8:16);
    goto L_84C30A;
L_84C30A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC30Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC30Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC30Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C30A LDA
    cpu.setA(0x10u, 16);
    goto L_84C30D;
L_84C30D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC30Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC30Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC30Du, 5u, 3u, cpu.address("abs", 0x0130u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C30D STA
    hw.write(cpu.address("abs", 0x130u), cpu.a, cpu.m8?8:16);
    goto L_84C310;
L_84C310:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC310u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC310u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC310u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C310 LDA
    cpu.setA(0x100u, 16);
    goto L_84C313;
L_84C313:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC313u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC313u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC313u, 5u, 3u, cpu.address("abs", 0x012Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C313 STA
    hw.write(cpu.address("abs", 0x12Cu), cpu.a, cpu.m8?8:16);
    goto L_84C316;
L_84C316:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC316u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC316u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC316u, 5u, 3u, cpu.address("abs", 0x012Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C316 STZ
    hw.write(cpu.address("abs", 0x12Eu), 0, cpu.m8?8:16);
    goto L_84C319;
L_84C319:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC319u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC319u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC319u, 5u, 3u, cpu.address("abs", 0x012Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C319 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x12Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84C31C;
L_84C31C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC31Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC31Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC31Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C31C STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_84C31E;
L_84C31E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC31Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC31Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC31Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C31E LDA
    cpu.setA(0x10u, 16);
    goto L_84C321;
L_84C321:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC321u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC321u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC321u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C321 SEC
    cpu.setFlag('C', true);
    goto L_84C322;
L_84C322:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC322u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC322u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC322u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C322 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16));
    goto L_84C324;
L_84C324:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC324u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC324u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC324u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C324 BMI -> $84C32B
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_84C32B; }
    goto L_84C326;
L_84C326:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC326u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC326u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC326u, 8u, 3u, cpu.address("abs", 0x012Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C326 INC
    cpu.incMem(hw, cpu.address("abs", 0x12Eu), cpu.m8?8:16);
    goto L_84C329;
L_84C329:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC329u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC329u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC329u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C329 BRA -> $84C321
    goto L_84C321;
L_84C32B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC32Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC32Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC32Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84C32B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84C32Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84C32Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_F6E572_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xF6E52Au: goto L_F6E52A;
    case 0xF6E572u: goto L_F6E572;
    case 0xF6E575u: goto L_F6E575;
    case 0xF6E578u: goto L_F6E578;
    case 0xF6E57Au: goto L_F6E57A;
    case 0xF6E57Du: goto L_F6E57D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_F6E52A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE52Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE52Au,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE52Au, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x6C54u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $F6E52A JMP (6C54,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x6C54u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0xF6E52Au); return; }
L_F6E572:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE572u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE572u,cpu,0xFDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE572u, 5u + 1u, 3u, cpu.address("absx", 0xFDFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $F6E572 SBC
    cpu.sbc(hw.readW(cpu.address("absx", 0xFDFCu), cpu.m8?8:16));
    goto L_F6E575;
L_F6E575:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE575u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE575u,cpu,0xFDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE575u, 5u + 1u, 3u, cpu.address("absx", 0x8EA5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $F6E575 SBC
    cpu.sbc(hw.readW(cpu.address("absx", 0x8EA5u), cpu.m8?8:16));
    goto L_F6E578;
L_F6E578:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE578u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE578u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE578u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $F6E578 BNE -> $F6E52A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_F6E52A; }
    goto L_F6E57A;
L_F6E57A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE57Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE57Au,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE57Au, 5u, 3u, cpu.address("abs", 0x2050u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $F6E57A ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x2050u), cpu.m8?8:16));
    goto L_F6E57D;
L_F6E57D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE57Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE57Du,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE57Du, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $F6E57D BRK
    hw.partial(0xF6E57Du, "BRK"); return;
}

