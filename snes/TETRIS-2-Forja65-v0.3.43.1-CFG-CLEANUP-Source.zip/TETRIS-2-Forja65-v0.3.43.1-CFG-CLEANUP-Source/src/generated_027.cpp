#include "generated.hpp"
void sub_008002_E1M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x008002u: goto L_008002;
    case 0x008003u: goto L_008003;
    case 0x008004u: goto L_008004;
    case 0x008005u: goto L_008005;
    case 0x008006u: goto L_008006;
    case 0x008008u: goto L_008008;
    case 0x00800Au: goto L_00800A;
    case 0x80800Eu: goto L_80800E;
    case 0x80800Fu: goto L_80800F;
    case 0x808010u: goto L_808010;
    case 0x808012u: goto L_808012;
    case 0x808013u: goto L_808013;
    case 0x808014u: goto L_808014;
    case 0x808015u: goto L_808015;
    case 0x808016u: goto L_808016;
    case 0x808019u: goto L_808019;
    case 0x80801Cu: goto L_80801C;
    case 0x80801Fu: goto L_80801F;
    case 0x808022u: goto L_808022;
    case 0x808024u: goto L_808024;
    case 0x808027u: goto L_808027;
    case 0x808029u: goto L_808029;
    case 0x80802Cu: goto L_80802C;
    case 0x80802Fu: goto L_80802F;
    case 0x808030u: goto L_808030;
    case 0x808031u: goto L_808031;
    case 0x808033u: goto L_808033;
    case 0x808036u: goto L_808036;
    case 0x808039u: goto L_808039;
    case 0x80803Au: goto L_80803A;
    case 0x80803Bu: goto L_80803B;
    case 0x80803Du: goto L_80803D;
    case 0x808040u: goto L_808040;
    case 0x808041u: goto L_808041;
    case 0x808043u: goto L_808043;
    case 0x808046u: goto L_808046;
    case 0x808049u: goto L_808049;
    case 0x80804Bu: goto L_80804B;
    case 0x80804Eu: goto L_80804E;
    case 0x808050u: goto L_808050;
    case 0x808053u: goto L_808053;
    case 0x808055u: goto L_808055;
    case 0x808057u: goto L_808057;
    case 0x808059u: goto L_808059;
    case 0x80805Bu: goto L_80805B;
    case 0x80805Fu: goto L_80805F;
    case 0x808061u: goto L_808061;
    case 0x808065u: goto L_808065;
    case 0x808069u: goto L_808069;
    case 0x80806Bu: goto L_80806B;
    case 0x80806Fu: goto L_80806F;
    case 0x808073u: goto L_808073;
    case 0x808076u: goto L_808076;
    case 0x808078u: goto L_808078;
    case 0x80807Bu: goto L_80807B;
    case 0x80807Cu: goto L_80807C;
    case 0x80807Eu: goto L_80807E;
    case 0x808080u: goto L_808080;
    case 0x808083u: goto L_808083;
    case 0x808085u: goto L_808085;
    case 0x808089u: goto L_808089;
    case 0x80808Du: goto L_80808D;
    case 0x808090u: goto L_808090;
    case 0x808093u: goto L_808093;
    case 0x808095u: goto L_808095;
    case 0x808099u: goto L_808099;
    case 0x80809Du: goto L_80809D;
    case 0x8080A1u: goto L_8080A1;
    case 0x8080A3u: goto L_8080A3;
    case 0x8080A6u: goto L_8080A6;
    case 0x8080A8u: goto L_8080A8;
    case 0x8080AAu: goto L_8080AA;
    case 0x8080AEu: goto L_8080AE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_008002:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8002u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8002u,cpu,0x78u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8002u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008002 SEI
    cpu.setFlag('I', true);
    goto L_008003;
L_008003:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8003u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8003u,cpu,0xD8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8003u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008003 CLD
    cpu.setFlag('D', false);
    goto L_008004;
L_008004:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8004u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8004u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8004u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008004 CLC
    cpu.setFlag('C', false);
    goto L_008005;
L_008005:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8005u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8005u,cpu,0xFBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8005u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008005 XCE
    cpu.xce();
    goto L_008006;
L_008006:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8006u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8006u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8006u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008006 REP
    cpu.rep(0x10u);
    goto L_008008;
L_008008:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8008u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8008u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8008u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008008 SEP
    cpu.sep(0x20u);
    goto L_00800A;
L_00800A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x800Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x800Au,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x800Au, 4u, 4u, 0x80800Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00800A JML -> $80800E
    cpu.pb=0x80u; // JML troca o Program Bank mesmo em goto local recompilado
    goto L_80800E;
L_80800E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x800Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x800Eu,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x800Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80800E PHK
    cpu.push("PHK", hw);
    goto L_80800F;
L_80800F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x800Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x800Fu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x800Fu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80800F PLB
    cpu.pop("PLB", hw);
    goto L_808010;
L_808010:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8010u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8010u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8010u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808010 LDA
    cpu.setA(0x0u, 8);
    goto L_808012;
L_808012:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8012u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8012u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8012u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808012 PHA
    cpu.push("PHA", hw);
    goto L_808013;
L_808013:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8013u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8013u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8013u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808013 PHA
    cpu.push("PHA", hw);
    goto L_808014;
L_808014:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8014u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8014u,cpu,0x2Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8014u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808014 PLD
    cpu.pop("PLD", hw);
    goto L_808015;
L_808015:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8015u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8015u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8015u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808015 INC
    cpu.inc('A');
    goto L_808016;
L_808016:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8016u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8016u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8016u, 4u, 3u, cpu.address("abs", 0x420Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808016 STA
    hw.write(cpu.address("abs", 0x420Du), cpu.a, cpu.m8?8:16);
    goto L_808019;
L_808019:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8019u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8019u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8019u, 4u, 3u, cpu.address("abs", 0x4200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808019 STZ
    hw.write(cpu.address("abs", 0x4200u), 0, cpu.m8?8:16);
    goto L_80801C;
L_80801C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x801Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x801Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x801Cu, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80801C STZ
    hw.write(cpu.address("abs", 0x420Bu), 0, cpu.m8?8:16);
    goto L_80801F;
L_80801F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x801Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x801Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x801Fu, 4u, 3u, cpu.address("abs", 0x420Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80801F STZ
    hw.write(cpu.address("abs", 0x420Cu), 0, cpu.m8?8:16);
    goto L_808022;
L_808022:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8022u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8022u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8022u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808022 LDA
    cpu.setA(0x80u, 8);
    goto L_808024;
L_808024:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8024u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8024u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8024u, 4u, 3u, cpu.address("abs", 0x2100u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808024 STA
    hw.write(cpu.address("abs", 0x2100u), cpu.a, cpu.m8?8:16);
    goto L_808027;
L_808027:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8027u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8027u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8027u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808027 REP
    cpu.rep(0x20u);
    goto L_808029;
L_808029:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8029u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8029u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8029u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808029 LDX
    cpu.setX(0x16FEu, 16);
    goto L_80802C;
L_80802C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x802Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x802Cu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x802Cu, 6u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80802C STZ
    hw.write(cpu.address("absx", 0x0u), 0, cpu.m8?8:16);
    goto L_80802F;
L_80802F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x802Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x802Fu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x802Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80802F DEX
    cpu.decReg('X');
    goto L_808030;
L_808030:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8030u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8030u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8030u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808030 DEX
    cpu.decReg('X');
    goto L_808031;
L_808031:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8031u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8031u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8031u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808031 BPL -> $80802C
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80802C; }
    goto L_808033;
L_808033:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8033u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8033u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8033u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808033 LDX
    cpu.setX(0x7FEu, 16);
    goto L_808036;
L_808036:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8036u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8036u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8036u, 6u, 3u, cpu.address("absx", 0x1800u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808036 STZ
    hw.write(cpu.address("absx", 0x1800u), 0, cpu.m8?8:16);
    goto L_808039;
L_808039:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8039u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8039u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8039u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808039 DEX
    cpu.decReg('X');
    goto L_80803A;
L_80803A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x803Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x803Au,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x803Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80803A DEX
    cpu.decReg('X');
    goto L_80803B;
L_80803B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x803Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x803Bu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x803Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80803B BPL -> $808036
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808036; }
    goto L_80803D;
L_80803D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x803Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x803Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x803Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80803D LDX
    cpu.setX(0x1FF0u, 16);
    goto L_808040;
L_808040:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8040u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8040u,cpu,0x9Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8040u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808040 TXS
    cpu.transfer("TXS");
    goto L_808041;
L_808041:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8041u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8041u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8041u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808041 REP
    cpu.rep(0x20u);
    goto L_808043;
L_808043:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8043u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8043u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8043u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808043 LDA
    cpu.setA(0x1u, 16);
    goto L_808046;
L_808046:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8046u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8046u,cpu,0x0Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8046u, 8u, 3u, cpu.address("abs", 0x019Fu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808046 TSB
    cpu.tsb(hw, cpu.address("abs", 0x19Fu), cpu.m8?8:16);
    goto L_808049;
L_808049:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8049u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8049u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8049u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808049 SEP
    cpu.sep(0x20u);
    goto L_80804B;
L_80804B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x804Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x804Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x804Bu, 6u, 3u, cpu.address("abs", 0x8111u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80804B JSR -> $808111 stack real
    { cpu.push16Value(hw,0x804Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x804Eu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8111u), 0x80804Bu); }
    goto L_80804E;
L_80804E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x804Eu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x804Eu,0x80804Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x804Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x804Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80804E SEP
    cpu.sep(0x20u);
    goto L_808050;
L_808050:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8050u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8050u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8050u, 4u, 3u, cpu.address("abs", 0x213Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808050 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x213Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808053;
L_808053:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8053u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8053u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8053u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808053 BIT
    cpu.bit(0x10u, true);
    goto L_808055;
L_808055:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8055u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8055u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8055u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808055 BEQ -> $80805B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80805B; }
    goto L_808057;
L_808057:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8057u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8057u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8057u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808057 LDA
    cpu.setA(0x83u, 8);
    goto L_808059;
L_808059:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8059u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8059u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8059u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808059 BRA -> $80805F
    goto L_80805F;
L_80805B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x805Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x805Bu,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x805Bu, 5u, 4u, 0x808000u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80805B LDA
    cpu.loadA(hw.readW(0x808000u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80805F;
L_80805F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x805Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x805Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x805Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80805F STA
    hw.write(cpu.address("dp", 0x46u), cpu.a, cpu.m8?8:16);
    goto L_808061;
L_808061:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8061u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8061u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8061u, 8u, 4u, 0x808580u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808061 JSL -> $808580 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8064u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8065u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808580u, 0x808061u); }
    goto L_808065;
L_808065:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8065u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8065u,0x808065u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8065u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8065u, 8u, 4u, 0x82BB9Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808065 JSL -> $82BB9A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8068u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8069u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82BB9Au, 0x808065u); }
    goto L_808069;
L_808069:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8069u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8069u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8069u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808069 SEP
    cpu.sep(0x24u);
    goto L_80806B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8069u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8069u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808069 SEP
    cpu.sep(0x24u);
    goto L_80806B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8069u,0x808069u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80806B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x806Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x806Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x806Bu, 8u, 4u, 0x808556u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80806B JSL -> $808556 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x806Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x806Fu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808556u, 0x80806Bu); }
    goto L_80806F;
L_80806F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x806Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x806Fu,0x80806Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x806Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x806Fu, 8u, 4u, 0x808572u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80806F JSL -> $808572 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8072u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8073u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808572u, 0x80806Fu); }
    goto L_808073;
L_808073:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8073u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8073u,0x808073u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8073u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8073u, 4u, 3u, cpu.address("abs", 0x420Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808073 STZ
    hw.write(cpu.address("abs", 0x420Cu), 0, cpu.m8?8:16);
    goto L_808076;
L_808076:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8076u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8076u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8076u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xB4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808076 STZ
    hw.write(cpu.address("dp", 0xB4u), 0, cpu.m8?8:16);
    goto L_808078;
L_808078:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8078u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8078u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8078u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808078 LDX
    cpu.setX(0x1FF0u, 16);
    goto L_80807B;
L_80807B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x807Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x807Bu,cpu,0x9Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x807Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80807B TXS
    cpu.transfer("TXS");
    goto L_80807C;
L_80807C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x807Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x807Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x807Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80807C STZ
    hw.write(cpu.address("dp", 0x96u), 0, cpu.m8?8:16);
    goto L_80807E;
L_80807E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x807Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x807Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x807Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80807E STZ
    hw.write(cpu.address("dp", 0x97u), 0, cpu.m8?8:16);
    goto L_808080;
L_808080:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8080u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8080u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8080u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808080 LDX
    cpu.setX(0x200u, 16);
    goto L_808083;
L_808083:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8083u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8083u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8083u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808083 STX
    hw.write(cpu.address("dp", 0x98u), cpu.x, cpu.x8?8:16);
    goto L_808085;
L_808085:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8085u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8085u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8085u, 8u, 4u, 0x808ADEu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808085 JSL -> $808ADE stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8088u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8089u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808ADEu, 0x808085u); }
    goto L_808089;
L_808089:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8089u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8089u,0x808089u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8089u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8089u, 8u, 4u, 0x808B92u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808089 JSL -> $808B92 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x808Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x808Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808B92u, 0x808089u); }
    goto L_80808D;
L_80808D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x808Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x808Du,0x80808Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x808Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x808Du, 6u, 3u, cpu.address("abs", 0x82A7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80808D JSR -> $8082A7 stack real
    { cpu.push16Value(hw,0x808Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8090u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x82A7u), 0x80808Du); }
    goto L_808090;
L_808090:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8090u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8090u,0x808090u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8090u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8090u, 6u, 3u, cpu.address("abs", 0x85ADu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808090 JSR -> $8085AD stack real
    { cpu.push16Value(hw,0x8092u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8093u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x85ADu), 0x808090u); }
    goto L_808093;
L_808093:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8093u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8093u,0x808093u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8093u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8093u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808093 STZ
    hw.write(cpu.address("dp", 0x4Bu), 0, cpu.m8?8:16);
    goto L_808095;
L_808095:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8095u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8095u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8095u, 8u, 4u, 0x808547u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808095 JSL -> $808547 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8098u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8099u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808547u, 0x808095u); }
    goto L_808099;
L_808099:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8099u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8099u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8099u, 8u, 4u, 0x808D03u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808099 JSL -> $808D03 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x809Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x809Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D03u, 0x808099u); }
    goto L_80809D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8099u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8099u, 8u, 4u, 0x808D03u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808099 JSL -> $808D03 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x809Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x809Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D03u, 0x808099u); }
    goto L_80809D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8099u,0x808099u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80809D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x809Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x809Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x809Du, 8u, 4u, 0x8096A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80809D JSL -> $8096A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80A0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80A1u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8096A3u, 0x80809Du); }
    goto L_8080A1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x809Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x809Du, 8u, 4u, 0x8096A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80809D JSL -> $8096A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80A0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80A1u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8096A3u, 0x80809Du); }
    goto L_8080A1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x809Du,0x80809Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8080A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80A1u,0x8080A1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A1u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A1 SEP
    cpu.sep(0x20u);
    goto L_8080A3;
L_8080A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A3u, 6u, 3u, cpu.address("abs", 0x83A4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8080A3 JSR -> $8083A4 stack real
    { cpu.push16Value(hw,0x80A5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80A6u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x83A4u), 0x8080A3u); }
    goto L_8080A6;
L_8080A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A6u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x46u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8080A8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x46u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8080A8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80A6u,0x8080A6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8080A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A8u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A8u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A8 BPL -> $808099
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808099; }
    goto L_8080AA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A8u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A8 BPL -> $808099
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808099; }
    goto L_8080AA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80A8u,0x8080A8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8080AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80AAu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu, 8u, 4u, 0x808556u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080AA JSL -> $808556 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80ADu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80AEu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808556u, 0x8080AAu); }
    goto L_8080AE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu, 8u, 4u, 0x808556u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080AA JSL -> $808556 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80ADu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80AEu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808556u, 0x8080AAu); }
    goto L_8080AE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80AAu,0x8080AAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8080AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80AEu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080AE BRA -> $808069
    goto L_808069;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080AE BRA -> $808069
    goto L_808069;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80AEu,0x8080AEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_808090_E0M1X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808069u: goto L_808069;
    case 0x80806Bu: goto L_80806B;
    case 0x80806Fu: goto L_80806F;
    case 0x808073u: goto L_808073;
    case 0x808076u: goto L_808076;
    case 0x808078u: goto L_808078;
    case 0x80807Bu: goto L_80807B;
    case 0x80807Cu: goto L_80807C;
    case 0x80807Eu: goto L_80807E;
    case 0x808080u: goto L_808080;
    case 0x808083u: goto L_808083;
    case 0x808085u: goto L_808085;
    case 0x808089u: goto L_808089;
    case 0x80808Du: goto L_80808D;
    case 0x808090u: goto L_808090;
    case 0x808093u: goto L_808093;
    case 0x808095u: goto L_808095;
    case 0x808099u: goto L_808099;
    case 0x80809Du: goto L_80809D;
    case 0x8080A1u: goto L_8080A1;
    case 0x8080A3u: goto L_8080A3;
    case 0x8080A6u: goto L_8080A6;
    case 0x8080A8u: goto L_8080A8;
    case 0x8080AAu: goto L_8080AA;
    case 0x8080AEu: goto L_8080AE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808069:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8069u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8069u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8069u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808069 SEP
    cpu.sep(0x24u);
    goto L_80806B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8069u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8069u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808069 SEP
    cpu.sep(0x24u);
    goto L_80806B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8069u,0x808069u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80806B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x806Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x806Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x806Bu, 8u, 4u, 0x808556u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80806B JSL -> $808556 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x806Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x806Fu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808556u, 0x80806Bu); }
    goto L_80806F;
L_80806F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x806Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x806Fu,0x80806Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x806Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x806Fu, 8u, 4u, 0x808572u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80806F JSL -> $808572 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8072u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8073u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808572u, 0x80806Fu); }
    goto L_808073;
L_808073:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8073u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8073u,0x808073u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8073u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8073u, 4u, 3u, cpu.address("abs", 0x420Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808073 STZ
    hw.write(cpu.address("abs", 0x420Cu), 0, cpu.m8?8:16);
    goto L_808076;
L_808076:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8076u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8076u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8076u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xB4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808076 STZ
    hw.write(cpu.address("dp", 0xB4u), 0, cpu.m8?8:16);
    goto L_808078;
L_808078:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8078u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8078u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8078u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808078 LDX
    cpu.setX(0x1FF0u, 16);
    goto L_80807B;
L_80807B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x807Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x807Bu,cpu,0x9Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x807Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80807B TXS
    cpu.transfer("TXS");
    goto L_80807C;
L_80807C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x807Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x807Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x807Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80807C STZ
    hw.write(cpu.address("dp", 0x96u), 0, cpu.m8?8:16);
    goto L_80807E;
L_80807E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x807Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x807Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x807Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80807E STZ
    hw.write(cpu.address("dp", 0x97u), 0, cpu.m8?8:16);
    goto L_808080;
L_808080:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8080u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8080u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8080u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808080 LDX
    cpu.setX(0x200u, 16);
    goto L_808083;
L_808083:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8083u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8083u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8083u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808083 STX
    hw.write(cpu.address("dp", 0x98u), cpu.x, cpu.x8?8:16);
    goto L_808085;
L_808085:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8085u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8085u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8085u, 8u, 4u, 0x808ADEu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808085 JSL -> $808ADE stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8088u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8089u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808ADEu, 0x808085u); }
    goto L_808089;
L_808089:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8089u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8089u,0x808089u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8089u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8089u, 8u, 4u, 0x808B92u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808089 JSL -> $808B92 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x808Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x808Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808B92u, 0x808089u); }
    goto L_80808D;
L_80808D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x808Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x808Du,0x80808Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x808Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x808Du, 6u, 3u, cpu.address("abs", 0x82A7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80808D JSR -> $8082A7 stack real
    { cpu.push16Value(hw,0x808Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8090u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x82A7u), 0x80808Du); }
    goto L_808090;
L_808090:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8090u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8090u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8090u, 6u, 3u, cpu.address("abs", 0x85ADu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808090 JSR -> $8085AD stack real
    { cpu.push16Value(hw,0x8092u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8093u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x85ADu), 0x808090u); }
    goto L_808093;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8090u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8090u, 6u, 3u, cpu.address("abs", 0x85ADu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808090 JSR -> $8085AD stack real
    { cpu.push16Value(hw,0x8092u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8093u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x85ADu), 0x808090u); }
    goto L_808093;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8090u,0x808090u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_808093:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8093u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8093u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8093u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808093 STZ
    hw.write(cpu.address("dp", 0x4Bu), 0, cpu.m8?8:16);
    goto L_808095;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8093u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8093u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808093 STZ
    hw.write(cpu.address("dp", 0x4Bu), 0, cpu.m8?8:16);
    goto L_808095;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8093u,0x808093u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_808095:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8095u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8095u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8095u, 8u, 4u, 0x808547u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808095 JSL -> $808547 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8098u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8099u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808547u, 0x808095u); }
    goto L_808099;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8095u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8095u, 8u, 4u, 0x808547u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808095 JSL -> $808547 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8098u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8099u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808547u, 0x808095u); }
    goto L_808099;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8095u,0x808095u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_808099:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8099u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8099u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8099u, 8u, 4u, 0x808D03u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808099 JSL -> $808D03 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x809Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x809Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D03u, 0x808099u); }
    goto L_80809D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8099u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8099u, 8u, 4u, 0x808D03u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808099 JSL -> $808D03 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x809Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x809Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D03u, 0x808099u); }
    goto L_80809D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8099u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8099u, 8u, 4u, 0x808D03u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808099 JSL -> $808D03 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x809Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x809Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D03u, 0x808099u); }
    goto L_80809D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8099u,0x808099u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80809D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x809Du))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x809Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x809Du, 8u, 4u, 0x8096A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80809D JSL -> $8096A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80A0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80A1u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8096A3u, 0x80809Du); }
    goto L_8080A1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x809Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x809Du, 8u, 4u, 0x8096A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80809D JSL -> $8096A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80A0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80A1u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8096A3u, 0x80809Du); }
    goto L_8080A1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x809Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x809Du, 8u, 4u, 0x8096A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80809D JSL -> $8096A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80A0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80A1u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8096A3u, 0x80809Du); }
    goto L_8080A1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x809Du,0x80809Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8080A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80A1u,0x8080A1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A1u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A1 SEP
    cpu.sep(0x20u);
    goto L_8080A3;
L_8080A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A3u, 6u, 3u, cpu.address("abs", 0x83A4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8080A3 JSR -> $8083A4 stack real
    { cpu.push16Value(hw,0x80A5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80A6u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x83A4u), 0x8080A3u); }
    goto L_8080A6;
L_8080A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A6u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x46u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8080A8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x46u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8080A8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80A6u,0x8080A6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8080A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A8u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A8u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A8 BPL -> $808099
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808099; }
    goto L_8080AA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A8u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A8 BPL -> $808099
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808099; }
    goto L_8080AA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80A8u,0x8080A8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8080AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80AAu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu, 8u, 4u, 0x808556u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080AA JSL -> $808556 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80ADu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80AEu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808556u, 0x8080AAu); }
    goto L_8080AE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu, 8u, 4u, 0x808556u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080AA JSL -> $808556 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80ADu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80AEu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808556u, 0x8080AAu); }
    goto L_8080AE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80AAu,0x8080AAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8080AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80AEu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080AE BRA -> $808069
    goto L_808069;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080AE BRA -> $808069
    goto L_808069;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80AEu,0x8080AEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_808090_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808069u: goto L_808069;
    case 0x80806Bu: goto L_80806B;
    case 0x80806Fu: goto L_80806F;
    case 0x808073u: goto L_808073;
    case 0x808076u: goto L_808076;
    case 0x808078u: goto L_808078;
    case 0x80807Bu: goto L_80807B;
    case 0x80807Cu: goto L_80807C;
    case 0x80807Eu: goto L_80807E;
    case 0x808080u: goto L_808080;
    case 0x808083u: goto L_808083;
    case 0x808085u: goto L_808085;
    case 0x808089u: goto L_808089;
    case 0x80808Du: goto L_80808D;
    case 0x808090u: goto L_808090;
    case 0x808093u: goto L_808093;
    case 0x808095u: goto L_808095;
    case 0x808099u: goto L_808099;
    case 0x80809Du: goto L_80809D;
    case 0x8080A1u: goto L_8080A1;
    case 0x8080A3u: goto L_8080A3;
    case 0x8080A6u: goto L_8080A6;
    case 0x8080A8u: goto L_8080A8;
    case 0x8080AAu: goto L_8080AA;
    case 0x8080AEu: goto L_8080AE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808069:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8069u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8069u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8069u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808069 SEP
    cpu.sep(0x24u);
    goto L_80806B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8069u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8069u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808069 SEP
    cpu.sep(0x24u);
    goto L_80806B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8069u,0x808069u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80806B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x806Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x806Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x806Bu, 8u, 4u, 0x808556u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80806B JSL -> $808556 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x806Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x806Fu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808556u, 0x80806Bu); }
    goto L_80806F;
L_80806F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x806Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x806Fu,0x80806Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x806Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x806Fu, 8u, 4u, 0x808572u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80806F JSL -> $808572 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8072u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8073u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808572u, 0x80806Fu); }
    goto L_808073;
L_808073:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8073u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8073u,0x808073u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8073u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8073u, 4u, 3u, cpu.address("abs", 0x420Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808073 STZ
    hw.write(cpu.address("abs", 0x420Cu), 0, cpu.m8?8:16);
    goto L_808076;
L_808076:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8076u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8076u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8076u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xB4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808076 STZ
    hw.write(cpu.address("dp", 0xB4u), 0, cpu.m8?8:16);
    goto L_808078;
L_808078:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8078u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8078u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8078u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808078 LDX
    cpu.setX(0x1FF0u, 16);
    goto L_80807B;
L_80807B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x807Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x807Bu,cpu,0x9Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x807Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80807B TXS
    cpu.transfer("TXS");
    goto L_80807C;
L_80807C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x807Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x807Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x807Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80807C STZ
    hw.write(cpu.address("dp", 0x96u), 0, cpu.m8?8:16);
    goto L_80807E;
L_80807E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x807Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x807Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x807Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80807E STZ
    hw.write(cpu.address("dp", 0x97u), 0, cpu.m8?8:16);
    goto L_808080;
L_808080:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8080u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8080u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8080u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808080 LDX
    cpu.setX(0x200u, 16);
    goto L_808083;
L_808083:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8083u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8083u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8083u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808083 STX
    hw.write(cpu.address("dp", 0x98u), cpu.x, cpu.x8?8:16);
    goto L_808085;
L_808085:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8085u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8085u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8085u, 8u, 4u, 0x808ADEu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808085 JSL -> $808ADE stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8088u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8089u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808ADEu, 0x808085u); }
    goto L_808089;
L_808089:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8089u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8089u,0x808089u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8089u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8089u, 8u, 4u, 0x808B92u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808089 JSL -> $808B92 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x808Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x808Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808B92u, 0x808089u); }
    goto L_80808D;
L_80808D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x808Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x808Du,0x80808Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x808Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x808Du, 6u, 3u, cpu.address("abs", 0x82A7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80808D JSR -> $8082A7 stack real
    { cpu.push16Value(hw,0x808Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8090u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x82A7u), 0x80808Du); }
    goto L_808090;
L_808090:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8090u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8090u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8090u, 6u, 3u, cpu.address("abs", 0x85ADu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808090 JSR -> $8085AD stack real
    { cpu.push16Value(hw,0x8092u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8093u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x85ADu), 0x808090u); }
    goto L_808093;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8090u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8090u, 6u, 3u, cpu.address("abs", 0x85ADu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808090 JSR -> $8085AD stack real
    { cpu.push16Value(hw,0x8092u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8093u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x85ADu), 0x808090u); }
    goto L_808093;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8090u,0x808090u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_808093:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8093u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8093u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8093u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808093 STZ
    hw.write(cpu.address("dp", 0x4Bu), 0, cpu.m8?8:16);
    goto L_808095;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8093u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8093u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808093 STZ
    hw.write(cpu.address("dp", 0x4Bu), 0, cpu.m8?8:16);
    goto L_808095;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8093u,0x808093u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_808095:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8095u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8095u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8095u, 8u, 4u, 0x808547u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808095 JSL -> $808547 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8098u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8099u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808547u, 0x808095u); }
    goto L_808099;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8095u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8095u, 8u, 4u, 0x808547u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808095 JSL -> $808547 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8098u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8099u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808547u, 0x808095u); }
    goto L_808099;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8095u,0x808095u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_808099:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8099u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8099u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8099u, 8u, 4u, 0x808D03u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808099 JSL -> $808D03 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x809Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x809Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D03u, 0x808099u); }
    goto L_80809D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8099u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8099u, 8u, 4u, 0x808D03u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808099 JSL -> $808D03 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x809Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x809Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D03u, 0x808099u); }
    goto L_80809D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8099u,0x808099u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80809D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x809Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x809Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x809Du, 8u, 4u, 0x8096A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80809D JSL -> $8096A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80A0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80A1u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8096A3u, 0x80809Du); }
    goto L_8080A1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x809Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x809Du, 8u, 4u, 0x8096A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80809D JSL -> $8096A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80A0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80A1u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8096A3u, 0x80809Du); }
    goto L_8080A1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x809Du,0x80809Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8080A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80A1u,0x8080A1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A1u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A1 SEP
    cpu.sep(0x20u);
    goto L_8080A3;
L_8080A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A3u, 6u, 3u, cpu.address("abs", 0x83A4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8080A3 JSR -> $8083A4 stack real
    { cpu.push16Value(hw,0x80A5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80A6u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x83A4u), 0x8080A3u); }
    goto L_8080A6;
L_8080A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A6u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x46u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8080A8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x46u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8080A8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80A6u,0x8080A6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8080A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A8u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A8u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A8 BPL -> $808099
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808099; }
    goto L_8080AA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A8u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A8 BPL -> $808099
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808099; }
    goto L_8080AA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80A8u,0x8080A8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8080AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80AAu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu, 8u, 4u, 0x808556u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080AA JSL -> $808556 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80ADu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80AEu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808556u, 0x8080AAu); }
    goto L_8080AE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu, 8u, 4u, 0x808556u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080AA JSL -> $808556 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80ADu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80AEu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808556u, 0x8080AAu); }
    goto L_8080AE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80AAu,0x8080AAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8080AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80AEu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080AE BRA -> $808069
    goto L_808069;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080AE BRA -> $808069
    goto L_808069;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80AEu,0x8080AEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_8082A7_E0M0X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8082A7u: goto L_8082A7;
    case 0x8082A8u: goto L_8082A8;
    case 0x8082AAu: goto L_8082AA;
    case 0x8082ACu: goto L_8082AC;
    case 0x8082AEu: goto L_8082AE;
    case 0x8082B0u: goto L_8082B0;
    case 0x8082B2u: goto L_8082B2;
    case 0x8082B4u: goto L_8082B4;
    case 0x8082B6u: goto L_8082B6;
    case 0x8082B8u: goto L_8082B8;
    case 0x8082BAu: goto L_8082BA;
    case 0x8082BCu: goto L_8082BC;
    case 0x8082BEu: goto L_8082BE;
    case 0x8082C0u: goto L_8082C0;
    case 0x8082C2u: goto L_8082C2;
    case 0x8082C4u: goto L_8082C4;
    case 0x8082C6u: goto L_8082C6;
    case 0x8082C9u: goto L_8082C9;
    case 0x8082CCu: goto L_8082CC;
    case 0x8082CEu: goto L_8082CE;
    case 0x8082D0u: goto L_8082D0;
    case 0x8082D2u: goto L_8082D2;
    case 0x8082D4u: goto L_8082D4;
    case 0x8082D6u: goto L_8082D6;
    case 0x8082D8u: goto L_8082D8;
    case 0x8082DAu: goto L_8082DA;
    case 0x8082DBu: goto L_8082DB;
    case 0x8082DEu: goto L_8082DE;
    case 0x8082E0u: goto L_8082E0;
    case 0x8082E3u: goto L_8082E3;
    case 0x8082E4u: goto L_8082E4;
    case 0x8082E5u: goto L_8082E5;
    case 0x8082E7u: goto L_8082E7;
    case 0x8082E8u: goto L_8082E8;
    case 0x8082E9u: goto L_8082E9;
    case 0x8082EBu: goto L_8082EB;
    case 0x8082EFu: goto L_8082EF;
    case 0x8082F0u: goto L_8082F0;
    case 0x8082F2u: goto L_8082F2;
    case 0x8082F6u: goto L_8082F6;
    case 0x8082F7u: goto L_8082F7;
    case 0x8082F8u: goto L_8082F8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8082A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82A7u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82A7u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8082A7 PHP
    cpu.push("PHP", hw);
    goto L_8082A8;
L_8082A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82A8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82A8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082A8 REP
    cpu.rep(0x20u);
    goto L_8082AA;
L_8082AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82AAu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82AAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082AA STZ
    hw.write(cpu.address("dp", 0x7Au), 0, cpu.m8?8:16);
    goto L_8082AC;
L_8082AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82ACu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82ACu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082AC STZ
    hw.write(cpu.address("dp", 0x7Cu), 0, cpu.m8?8:16);
    goto L_8082AE;
L_8082AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82AEu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82AEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082AE STZ
    hw.write(cpu.address("dp", 0x7Eu), 0, cpu.m8?8:16);
    goto L_8082B0;
L_8082B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82B0u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82B0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082B0 STZ
    hw.write(cpu.address("dp", 0x80u), 0, cpu.m8?8:16);
    goto L_8082B2;
L_8082B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82B2u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82B2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082B2 STZ
    hw.write(cpu.address("dp", 0x82u), 0, cpu.m8?8:16);
    goto L_8082B4;
L_8082B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82B4u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82B4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x84u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082B4 STZ
    hw.write(cpu.address("dp", 0x84u), 0, cpu.m8?8:16);
    goto L_8082B6;
L_8082B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82B6u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82B6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x86u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082B6 STZ
    hw.write(cpu.address("dp", 0x86u), 0, cpu.m8?8:16);
    goto L_8082B8;
L_8082B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82B8u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82B8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082B8 STZ
    hw.write(cpu.address("dp", 0x88u), 0, cpu.m8?8:16);
    goto L_8082BA;
L_8082BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82BAu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82BAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x92u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082BA STZ
    hw.write(cpu.address("dp", 0x92u), 0, cpu.m8?8:16);
    goto L_8082BC;
L_8082BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82BCu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82BCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082BC STZ
    hw.write(cpu.address("dp", 0x94u), 0, cpu.m8?8:16);
    goto L_8082BE;
L_8082BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82BEu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82BEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082BE SEP
    cpu.sep(0x20u);
    goto L_8082C0;
L_8082C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C0u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x78u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082C0 STZ
    hw.write(cpu.address("dp", 0x78u), 0, cpu.m8?8:16);
    goto L_8082C2;
L_8082C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C2u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082C2 STZ
    hw.write(cpu.address("dp", 0x77u), 0, cpu.m8?8:16);
    goto L_8082C4;
L_8082C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C4u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082C4 STZ
    hw.write(cpu.address("dp", 0x75u), 0, cpu.m8?8:16);
    goto L_8082C6;
L_8082C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C6u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C6u, 4u, 3u, cpu.address("abs", 0x0128u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082C6 STZ
    hw.write(cpu.address("abs", 0x128u), 0, cpu.m8?8:16);
    goto L_8082C9;
L_8082C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82C9u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82C9u, 4u, 3u, cpu.address("abs", 0x012Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082C9 STZ
    hw.write(cpu.address("abs", 0x12Eu), 0, cpu.m8?8:16);
    goto L_8082CC;
L_8082CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82CCu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82CCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082CC STZ
    hw.write(cpu.address("dp", 0x49u), 0, cpu.m8?8:16);
    goto L_8082CE;
L_8082CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82CEu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82CEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x47u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082CE STZ
    hw.write(cpu.address("dp", 0x47u), 0, cpu.m8?8:16);
    goto L_8082D0;
L_8082D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82D0u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82D0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082D0 STZ
    hw.write(cpu.address("dp", 0x4Au), 0, cpu.m8?8:16);
    goto L_8082D2;
L_8082D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82D2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82D2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082D2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x46u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8082D4;
L_8082D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82D4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82D4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082D4 AND
    cpu.logicAnd(0x7Fu);
    goto L_8082D6;
L_8082D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82D6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82D6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082D6 STA
    hw.write(cpu.address("dp", 0x46u), cpu.a, cpu.m8?8:16);
    goto L_8082D8;
L_8082D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82D8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82D8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x48u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082D8 STA
    hw.write(cpu.address("dp", 0x48u), cpu.a, cpu.m8?8:16);
    goto L_8082DA;
L_8082DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82DAu,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82DAu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8082DA PHK
    cpu.push("PHK", hw);
    goto L_8082DB;
L_8082DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82DBu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82DBu, 5u, 3u, cpu.address("abs", 0x82F8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8082DB PEA
    cpu.push16Value(hw, 0x82F8u);
    goto L_8082DE;
L_8082DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82DEu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82DEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082DE REP
    cpu.rep(0x20u);
    goto L_8082E0;
L_8082E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E0u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082E0 AND
    cpu.logicAnd(0xFFu);
    goto L_8082E3;
L_8082E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E3u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E3u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8082E3 PHA
    cpu.push("PHA", hw);
    goto L_8082E4;
L_8082E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E4u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082E4 ASL
    cpu.aslA();
    goto L_8082E5;
L_8082E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E5u,cpu,0x63u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E5u, 5u, 2u, cpu.addressStack(0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082E5 ADC
    cpu.adc(hw.readW(cpu.addressStack(0x1u), cpu.m8?8:16));
    goto L_8082E7;
L_8082E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E7u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082E7 TAX
    cpu.transfer("TAX");
    goto L_8082E8;
L_8082E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E8u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E8u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8082E8 PLA
    cpu.pop("PLA", hw);
    goto L_8082E9;
L_8082E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82E9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82E9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082E9 SEP
    cpu.sep(0x20u);
    goto L_8082EB;
L_8082EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82EBu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82EBu, 5u, 4u, ((0x8082FDu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082EB LDA
    cpu.loadA(hw.readW(((0x8082FDu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8082EF;
L_8082EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82EFu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82EFu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8082EF PHA
    cpu.push("PHA", hw);
    goto L_8082F0;
L_8082F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F0u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082F0 REP
    cpu.rep(0x20u);
    goto L_8082F2;
L_8082F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F2u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F2u, 6u, 4u, ((0x8082FBu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082F2 LDA
    cpu.loadA(hw.readW(((0x8082FBu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8082F6;
L_8082F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F6u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8082F6 DEC
    cpu.decReg('A');
    goto L_8082F7;
L_8082F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F7u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F7u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8082F7 PHA
    cpu.push("PHA", hw);
    goto L_8082F8;
L_8082F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F8u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8082F8 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8082F8u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8082F8u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808442_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808442u: goto L_808442;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808442:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8442u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8442u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8442u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808442 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808442u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808442u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808442_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808442u: goto L_808442;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808442:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8442u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8442u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8442u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808442 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808442u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808442u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808443_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808443u: goto L_808443;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808443:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8443u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8443u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8443u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808443 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808443u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808443u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808700_E0M1X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808700u: goto L_808700;
    case 0x808701u: goto L_808701;
    case 0x808703u: goto L_808703;
    case 0x808705u: goto L_808705;
    case 0x808706u: goto L_808706;
    case 0x808708u: goto L_808708;
    case 0x80870Au: goto L_80870A;
    case 0x80870Bu: goto L_80870B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808700:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8700u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8700u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8700u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808700 PHP
    cpu.push("PHP", hw);
    goto L_808701;
L_808701:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8701u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8701u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8701u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808701 SEP
    cpu.sep(0x20u);
    goto L_808703;
L_808703:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8703u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8703u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8703u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808703 STA
    hw.write(cpu.address("dp", 0x77u), cpu.a, cpu.m8?8:16);
    goto L_808705;
L_808705:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8705u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8705u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8705u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808705 XBA
    cpu.xba();
    goto L_808706;
L_808706:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8706u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8706u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8706u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x78u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808706 STA
    hw.write(cpu.address("dp", 0x78u), cpu.a, cpu.m8?8:16);
    goto L_808708;
L_808708:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8708u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8708u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8708u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x79u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808708 STZ
    hw.write(cpu.address("dp", 0x79u), 0, cpu.m8?8:16);
    goto L_80870A;
L_80870A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x870Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x870Au,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x870Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80870A PLP
    cpu.pop("PLP", hw);
    goto L_80870B;
L_80870B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x870Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x870Bu,0x80870Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x870Bu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x870Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80870B RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80870Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80870Bu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808700_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808700u: goto L_808700;
    case 0x808701u: goto L_808701;
    case 0x808703u: goto L_808703;
    case 0x808705u: goto L_808705;
    case 0x808706u: goto L_808706;
    case 0x808708u: goto L_808708;
    case 0x80870Au: goto L_80870A;
    case 0x80870Bu: goto L_80870B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808700:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8700u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8700u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8700u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808700 PHP
    cpu.push("PHP", hw);
    goto L_808701;
L_808701:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8701u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8701u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8701u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808701 SEP
    cpu.sep(0x20u);
    goto L_808703;
L_808703:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8703u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8703u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8703u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x77u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808703 STA
    hw.write(cpu.address("dp", 0x77u), cpu.a, cpu.m8?8:16);
    goto L_808705;
L_808705:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8705u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8705u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8705u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808705 XBA
    cpu.xba();
    goto L_808706;
L_808706:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8706u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8706u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8706u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x78u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808706 STA
    hw.write(cpu.address("dp", 0x78u), cpu.a, cpu.m8?8:16);
    goto L_808708;
L_808708:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8708u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8708u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8708u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x79u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808708 STZ
    hw.write(cpu.address("dp", 0x79u), 0, cpu.m8?8:16);
    goto L_80870A;
L_80870A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x870Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x870Au,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x870Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80870A PLP
    cpu.pop("PLP", hw);
    goto L_80870B;
L_80870B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x870Bu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x870Bu,0x80870Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x870Bu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x870Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80870B RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80870Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80870Bu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808ADE_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808ADEu: goto L_808ADE;
    case 0x808AE0u: goto L_808AE0;
    case 0x808AE2u: goto L_808AE2;
    case 0x808AE4u: goto L_808AE4;
    case 0x808AE7u: goto L_808AE7;
    case 0x808AE8u: goto L_808AE8;
    case 0x808AE9u: goto L_808AE9;
    case 0x808AEAu: goto L_808AEA;
    case 0x808AEBu: goto L_808AEB;
    case 0x808AEDu: goto L_808AED;
    case 0x808AEFu: goto L_808AEF;
    case 0x808AF1u: goto L_808AF1;
    case 0x808AF3u: goto L_808AF3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808ADE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ADEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ADEu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ADEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808ADE LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x96u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_808AE0;
L_808AE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE0u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AE0 BRA -> $808AEB
    goto L_808AEB;
L_808AE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AE2 LDA
    cpu.setA(0xE0u, 8);
    goto L_808AE4;
L_808AE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE4u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE4u, 5u, 3u, cpu.address("absx", 0x1401u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AE4 STA
    hw.write(cpu.address("absx", 0x1401u), cpu.a, cpu.m8?8:16);
    goto L_808AE7;
L_808AE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE7u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AE7 INX
    cpu.inc('X');
    goto L_808AE8;
L_808AE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE8u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AE8 INX
    cpu.inc('X');
    goto L_808AE9;
L_808AE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE9u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AE9 INX
    cpu.inc('X');
    goto L_808AEA;
L_808AEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AEAu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AEAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AEA INX
    cpu.inc('X');
    goto L_808AEB;
L_808AEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AEBu,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AEBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AEB CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0x98u), cpu.x8?8:16));
    goto L_808AED;
L_808AED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AEDu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AEDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AED BCC -> $808AE2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_808AE2; }
    goto L_808AEF;
L_808AEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AEFu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AEFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AEF LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x96u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_808AF1;
L_808AF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF1u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AF1 STX
    hw.write(cpu.address("dp", 0x98u), cpu.x, cpu.x8?8:16);
    goto L_808AF3;
L_808AF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF3u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808AF3 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808AF3u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808AF3u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808B92_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808B92u: goto L_808B92;
    case 0x808B95u: goto L_808B95;
    case 0x808B98u: goto L_808B98;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808B92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B92u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B92u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808B92 LDX
    cpu.setX(0x0u, 16);
    goto L_808B95;
L_808B95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B95u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B95u, 5u, 3u, cpu.address("abs", 0x0124u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808B95 STX
    hw.write(cpu.address("abs", 0x124u), cpu.x, cpu.x8?8:16);
    goto L_808B98;
L_808B98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B98u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B98u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808B98 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808B98u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808B98u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_809315_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809315u: goto L_809315;
    case 0x809316u: goto L_809316;
    case 0x809318u: goto L_809318;
    case 0x80931Au: goto L_80931A;
    case 0x80931Cu: goto L_80931C;
    case 0x80931Eu: goto L_80931E;
    case 0x80931Fu: goto L_80931F;
    case 0x809322u: goto L_809322;
    case 0x809324u: goto L_809324;
    case 0x809326u: goto L_809326;
    case 0x809328u: goto L_809328;
    case 0x80932Au: goto L_80932A;
    case 0x80932Cu: goto L_80932C;
    case 0x80932Du: goto L_80932D;
    case 0x809330u: goto L_809330;
    case 0x809332u: goto L_809332;
    case 0x809334u: goto L_809334;
    case 0x809336u: goto L_809336;
    case 0x809338u: goto L_809338;
    case 0x80933Au: goto L_80933A;
    case 0x80933Bu: goto L_80933B;
    case 0x80933Eu: goto L_80933E;
    case 0x809340u: goto L_809340;
    case 0x809342u: goto L_809342;
    case 0x809344u: goto L_809344;
    case 0x809346u: goto L_809346;
    case 0x809348u: goto L_809348;
    case 0x809349u: goto L_809349;
    case 0x80934Cu: goto L_80934C;
    case 0x80934Eu: goto L_80934E;
    case 0x809350u: goto L_809350;
    case 0x809352u: goto L_809352;
    case 0x809354u: goto L_809354;
    case 0x809356u: goto L_809356;
    case 0x809358u: goto L_809358;
    case 0x80935Au: goto L_80935A;
    case 0x80935Bu: goto L_80935B;
    case 0x80935Du: goto L_80935D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809315:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9315u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9315u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9315u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809315 PHP
    cpu.push("PHP", hw);
    goto L_809316;
L_809316:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9316u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9316u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9316u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809316 STZ
    hw.write(cpu.address("dp", 0x3Au), 0, cpu.m8?8:16);
    goto L_809318;
L_809318:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9318u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9318u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9318u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809318 STZ
    hw.write(cpu.address("dp", 0x3Cu), 0, cpu.m8?8:16);
    goto L_80931A;
L_80931A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x931Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x931Au,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x931Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80931A STZ
    hw.write(cpu.address("dp", 0x3Du), 0, cpu.m8?8:16);
    goto L_80931C;
L_80931C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x931Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x931Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x931Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80931C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80931E;
L_80931E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x931Eu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x931Eu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x931Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80931E SEC
    cpu.setFlag('C', true);
    goto L_80931F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x931Eu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x931Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80931E SEC
    cpu.setFlag('C', true);
    goto L_80931F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x931Eu,0x80931Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80931F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x931Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x931Fu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x931Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80931F SBC
    cpu.sbc(0x2710u);
    goto L_809322;
L_809322:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9322u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9322u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9322u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809322 BCC -> $80932A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80932A; }
    goto L_809324;
L_809324:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9324u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9324u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9324u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809324 INC
    cpu.incMem(hw, cpu.address("dp", 0x3Eu), cpu.m8?8:16);
    goto L_809326;
L_809326:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9326u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9326u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9326u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809326 STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_809328;
L_809328:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9328u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9328u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9328u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809328 BRA -> $80931E
    goto L_80931E;
L_80932A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x932Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x932Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x932Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80932A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80932C;
L_80932C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x932Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x932Cu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x932Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80932C SEC
    cpu.setFlag('C', true);
    goto L_80932D;
L_80932D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x932Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x932Du,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x932Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80932D SBC
    cpu.sbc(0x3E8u);
    goto L_809330;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x932Du,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x932Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80932D SBC
    cpu.sbc(0x3E8u);
    goto L_809330;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x932Du,0x80932Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809330:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9330u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9330u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9330u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809330 BCC -> $809338
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_809338; }
    goto L_809332;
L_809332:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9332u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9332u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9332u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Du), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809332 INC
    cpu.incMem(hw, cpu.address("dp", 0x3Du), cpu.m8?8:16);
    goto L_809334;
L_809334:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9334u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9334u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9334u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809334 STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_809336;
L_809336:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9336u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9336u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9336u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809336 BRA -> $80932D
    goto L_80932D;
L_809338:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9338u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9338u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9338u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809338 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80933A;
L_80933A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x933Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x933Au,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x933Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80933A SEC
    cpu.setFlag('C', true);
    goto L_80933B;
L_80933B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x933Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x933Bu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x933Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80933B SBC
    cpu.sbc(0x64u);
    goto L_80933E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x933Bu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x933Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80933B SBC
    cpu.sbc(0x64u);
    goto L_80933E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x933Bu,0x80933Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80933E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x933Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x933Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x933Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80933E BCC -> $809346
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_809346; }
    goto L_809340;
L_809340:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9340u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9340u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9340u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809340 INC
    cpu.incMem(hw, cpu.address("dp", 0x3Cu), cpu.m8?8:16);
    goto L_809342;
L_809342:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9342u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9342u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9342u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809342 STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_809344;
L_809344:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9344u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9344u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9344u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809344 BRA -> $80933B
    goto L_80933B;
L_809346:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9346u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9346u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9346u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809346 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809348;
L_809348:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9348u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9348u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9348u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809348 SEC
    cpu.setFlag('C', true);
    goto L_809349;
L_809349:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9349u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9349u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9349u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809349 SBC
    cpu.sbc(0xAu);
    goto L_80934C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9349u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9349u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809349 SBC
    cpu.sbc(0xAu);
    goto L_80934C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9349u,0x809349u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80934C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x934Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x934Cu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x934Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80934C BCC -> $809354
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_809354; }
    goto L_80934E;
L_80934E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x934Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x934Eu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x934Eu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80934E INC
    cpu.incMem(hw, cpu.address("dp", 0x3Bu), cpu.m8?8:16);
    goto L_809350;
L_809350:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9350u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9350u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9350u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809350 STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_809352;
L_809352:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9352u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9352u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9352u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809352 BRA -> $809349
    goto L_809349;
L_809354:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9354u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9354u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9354u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809354 SEP
    cpu.sep(0x20u);
    goto L_809356;
L_809356:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9356u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9356u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9356u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809356 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809358;
L_809358:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9358u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9358u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9358u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809358 STA
    hw.write(cpu.address("dp", 0x3Au), cpu.a, cpu.m8?8:16);
    goto L_80935A;
L_80935A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x935Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x935Au,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x935Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80935A PLP
    cpu.pop("PLP", hw);
    goto L_80935B;
L_80935B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x935Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x935Bu,0x80935Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x935Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x935Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80935B REP
    cpu.rep(0x20u);
    goto L_80935D;
L_80935D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x935Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x935Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x935Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80935D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80935Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80935Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_809315_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809315u: goto L_809315;
    case 0x809316u: goto L_809316;
    case 0x809318u: goto L_809318;
    case 0x80931Au: goto L_80931A;
    case 0x80931Cu: goto L_80931C;
    case 0x80931Eu: goto L_80931E;
    case 0x80931Fu: goto L_80931F;
    case 0x809322u: goto L_809322;
    case 0x809324u: goto L_809324;
    case 0x809326u: goto L_809326;
    case 0x809328u: goto L_809328;
    case 0x80932Au: goto L_80932A;
    case 0x80932Cu: goto L_80932C;
    case 0x80932Du: goto L_80932D;
    case 0x809330u: goto L_809330;
    case 0x809332u: goto L_809332;
    case 0x809334u: goto L_809334;
    case 0x809336u: goto L_809336;
    case 0x809338u: goto L_809338;
    case 0x80933Au: goto L_80933A;
    case 0x80933Bu: goto L_80933B;
    case 0x80933Eu: goto L_80933E;
    case 0x809340u: goto L_809340;
    case 0x809342u: goto L_809342;
    case 0x809344u: goto L_809344;
    case 0x809346u: goto L_809346;
    case 0x809348u: goto L_809348;
    case 0x809349u: goto L_809349;
    case 0x80934Cu: goto L_80934C;
    case 0x80934Eu: goto L_80934E;
    case 0x809350u: goto L_809350;
    case 0x809352u: goto L_809352;
    case 0x809354u: goto L_809354;
    case 0x809356u: goto L_809356;
    case 0x809358u: goto L_809358;
    case 0x80935Au: goto L_80935A;
    case 0x80935Bu: goto L_80935B;
    case 0x80935Du: goto L_80935D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809315:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9315u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9315u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9315u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809315 PHP
    cpu.push("PHP", hw);
    goto L_809316;
L_809316:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9316u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9316u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9316u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809316 STZ
    hw.write(cpu.address("dp", 0x3Au), 0, cpu.m8?8:16);
    goto L_809318;
L_809318:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9318u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9318u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9318u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809318 STZ
    hw.write(cpu.address("dp", 0x3Cu), 0, cpu.m8?8:16);
    goto L_80931A;
L_80931A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x931Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x931Au,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x931Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80931A STZ
    hw.write(cpu.address("dp", 0x3Du), 0, cpu.m8?8:16);
    goto L_80931C;
L_80931C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x931Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x931Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x931Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80931C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80931E;
L_80931E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x931Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x931Eu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x931Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80931E SEC
    cpu.setFlag('C', true);
    goto L_80931F;
L_80931F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x931Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x931Fu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x931Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80931F SBC
    cpu.sbc(0x2710u);
    goto L_809322;
L_809322:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9322u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9322u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9322u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809322 BCC -> $80932A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80932A; }
    goto L_809324;
L_809324:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9324u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9324u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9324u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809324 INC
    cpu.incMem(hw, cpu.address("dp", 0x3Eu), cpu.m8?8:16);
    goto L_809326;
L_809326:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9326u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9326u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9326u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809326 STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_809328;
L_809328:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9328u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9328u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9328u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809328 BRA -> $80931E
    goto L_80931E;
L_80932A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x932Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x932Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x932Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80932A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80932C;
L_80932C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x932Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x932Cu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x932Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80932C SEC
    cpu.setFlag('C', true);
    goto L_80932D;
L_80932D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x932Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x932Du,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x932Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80932D SBC
    cpu.sbc(0x3E8u);
    goto L_809330;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x932Du,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x932Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80932D SBC
    cpu.sbc(0x3E8u);
    goto L_809330;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x932Du,0x80932Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809330:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9330u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9330u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9330u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809330 BCC -> $809338
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_809338; }
    goto L_809332;
L_809332:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9332u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9332u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9332u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Du), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809332 INC
    cpu.incMem(hw, cpu.address("dp", 0x3Du), cpu.m8?8:16);
    goto L_809334;
L_809334:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9334u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9334u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9334u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809334 STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_809336;
L_809336:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9336u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9336u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9336u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809336 BRA -> $80932D
    goto L_80932D;
L_809338:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9338u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9338u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9338u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809338 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80933A;
L_80933A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x933Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x933Au,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x933Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80933A SEC
    cpu.setFlag('C', true);
    goto L_80933B;
L_80933B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x933Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x933Bu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x933Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80933B SBC
    cpu.sbc(0x64u);
    goto L_80933E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x933Bu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x933Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80933B SBC
    cpu.sbc(0x64u);
    goto L_80933E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x933Bu,0x80933Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80933E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x933Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x933Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x933Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80933E BCC -> $809346
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_809346; }
    goto L_809340;
L_809340:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9340u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9340u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9340u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809340 INC
    cpu.incMem(hw, cpu.address("dp", 0x3Cu), cpu.m8?8:16);
    goto L_809342;
L_809342:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9342u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9342u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9342u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809342 STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_809344;
L_809344:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9344u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9344u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9344u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809344 BRA -> $80933B
    goto L_80933B;
L_809346:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9346u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9346u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9346u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809346 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809348;
L_809348:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9348u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9348u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9348u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809348 SEC
    cpu.setFlag('C', true);
    goto L_809349;
L_809349:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9349u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9349u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9349u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809349 SBC
    cpu.sbc(0xAu);
    goto L_80934C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9349u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9349u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809349 SBC
    cpu.sbc(0xAu);
    goto L_80934C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9349u,0x809349u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80934C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x934Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x934Cu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x934Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80934C BCC -> $809354
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_809354; }
    goto L_80934E;
L_80934E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x934Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x934Eu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x934Eu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80934E INC
    cpu.incMem(hw, cpu.address("dp", 0x3Bu), cpu.m8?8:16);
    goto L_809350;
L_809350:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9350u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9350u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9350u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809350 STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_809352;
L_809352:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9352u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9352u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9352u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809352 BRA -> $809349
    goto L_809349;
L_809354:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9354u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9354u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9354u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809354 SEP
    cpu.sep(0x20u);
    goto L_809356;
L_809356:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9356u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9356u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9356u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809356 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809358;
L_809358:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9358u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9358u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9358u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809358 STA
    hw.write(cpu.address("dp", 0x3Au), cpu.a, cpu.m8?8:16);
    goto L_80935A;
L_80935A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x935Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x935Au,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x935Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80935A PLP
    cpu.pop("PLP", hw);
    goto L_80935B;
L_80935B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x935Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x935Bu,0x80935Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x935Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x935Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80935B REP
    cpu.rep(0x20u);
    goto L_80935D;
L_80935D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x935Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x935Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x935Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80935D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80935Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80935Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_809DFA_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809DFAu: goto L_809DFA;
    case 0x809DFDu: goto L_809DFD;
    case 0x809DFEu: goto L_809DFE;
    case 0x809DFFu: goto L_809DFF;
    case 0x809E00u: goto L_809E00;
    case 0x809E01u: goto L_809E01;
    case 0x809E04u: goto L_809E04;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809DFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DFAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DFAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809DFA AND
    cpu.logicAnd(0xC0u);
    goto L_809DFD;
L_809DFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DFDu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DFDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809DFD ASL
    cpu.aslA();
    goto L_809DFE;
L_809DFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DFEu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DFEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809DFE ASL
    cpu.aslA();
    goto L_809DFF;
L_809DFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9DFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9DFFu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9DFFu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809DFF XBA
    cpu.xba();
    goto L_809E00;
L_809E00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E00u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E00u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E00 CLC
    cpu.setFlag('C', false);
    goto L_809E01;
L_809E01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E01u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E01u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E01 ADC
    cpu.adc(0x12u);
    goto L_809E04;
L_809E04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E04u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E04u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809E04 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x809E04u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x809E04u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80B01F_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B01Fu: goto L_80B01F;
    case 0x80B022u: goto L_80B022;
    case 0x80B024u: goto L_80B024;
    case 0x80B027u: goto L_80B027;
    case 0x80B02Au: goto L_80B02A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B01F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB01Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Fu, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B01F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B022;
L_80B022:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB022u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB022u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB022u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B022 BEQ -> $80B027
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B027; }
    goto L_80B024;
L_80B024:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB024u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB024u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB024u, 6u, 3u, cpu.address("abs", 0xCC90u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B024 JSR -> $80CC90 stack real
    { cpu.push16Value(hw,0xB026u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB027u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCC90u), 0x80B024u); }
    goto L_80B027;
L_80B027:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB027u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB027u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB027u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B027 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B02A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB027u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB027u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B027 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B02A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB027u,0x80B027u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B02A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB02Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB02Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB02Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B02A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B02Au);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B02Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB02Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB02Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B02A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B02Au);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B02Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB02Au,0x80B02Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80B882_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B882u: goto L_80B882;
    case 0x80B885u: goto L_80B885;
    case 0x80B887u: goto L_80B887;
    case 0x80B88Au: goto L_80B88A;
    case 0x80B88Cu: goto L_80B88C;
    case 0x80B88Fu: goto L_80B88F;
    case 0x80B892u: goto L_80B892;
    case 0x80B894u: goto L_80B894;
    case 0x80B897u: goto L_80B897;
    case 0x80B899u: goto L_80B899;
    case 0x80B89Bu: goto L_80B89B;
    case 0x80B89Eu: goto L_80B89E;
    case 0x80B8A1u: goto L_80B8A1;
    case 0x80B8A3u: goto L_80B8A3;
    case 0x80B8A6u: goto L_80B8A6;
    case 0x80B8A8u: goto L_80B8A8;
    case 0x80B8ABu: goto L_80B8AB;
    case 0x80B8AEu: goto L_80B8AE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B882:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB882u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB882u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB882u, 5u, 3u, cpu.address("abs", 0x0948u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B882 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x948u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B885;
L_80B885:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB885u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB885u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB885u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B885 BNE -> $80B894
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B894; }
    goto L_80B887;
L_80B887:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB887u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB887u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB887u, 5u, 3u, cpu.address("abs", 0x0942u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B887 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x942u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B88A;
L_80B88A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB88Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB88Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB88Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B88A BNE -> $80B894
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B894; }
    goto L_80B88C;
L_80B88C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB88Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB88Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB88Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B88C LDA
    cpu.setA(0x100u, 16);
    goto L_80B88F;
L_80B88F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB88Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB88Fu,cpu,0x0Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB88Fu, 8u, 3u, cpu.address("abs", 0x0922u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B88F TSB
    cpu.tsb(hw, cpu.address("abs", 0x922u), cpu.m8?8:16);
    goto L_80B892;
L_80B892:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB892u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB892u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB892u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B892 BRA -> $80B8AE
    goto L_80B8AE;
L_80B894:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB894u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB894u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB894u, 5u, 3u, cpu.address("abs", 0x0946u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B894 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x946u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B897;
L_80B897:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB897u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB897u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB897u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B897 BNE -> $80B89B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B89B; }
    goto L_80B899;
L_80B899:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB899u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB899u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB899u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B899 BRA -> $80B8AE
    goto L_80B8AE;
L_80B89B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB89Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB89Bu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB89Bu, 8u, 3u, cpu.address("abs", 0x0948u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B89B INC
    cpu.incMem(hw, cpu.address("abs", 0x948u), cpu.m8?8:16);
    goto L_80B89E;
L_80B89E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB89Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB89Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB89Eu, 5u, 3u, cpu.address("abs", 0x094Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B89E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x94Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B8A1;
L_80B8A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8A1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8A1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B8A1 BNE -> $80B8AE
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B8AE; }
    goto L_80B8A3;
L_80B8A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8A3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8A3u, 5u, 3u, cpu.address("abs", 0x0944u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B8A3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x944u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B8A6;
L_80B8A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8A6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8A6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B8A6 BNE -> $80B8AE
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B8AE; }
    goto L_80B8A8;
L_80B8A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8A8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8A8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B8A8 LDA
    cpu.setA(0x200u, 16);
    goto L_80B8AB;
L_80B8AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8ABu,cpu,0x0Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8ABu, 8u, 3u, cpu.address("abs", 0x0922u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B8AB TSB
    cpu.tsb(hw, cpu.address("abs", 0x922u), cpu.m8?8:16);
    goto L_80B8AE;
L_80B8AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8AEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8AEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B8AE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B8AEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B8AEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80C067_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80C067u: goto L_80C067;
    case 0x80C06Au: goto L_80C06A;
    case 0x80C06Du: goto L_80C06D;
    case 0x80C06Fu: goto L_80C06F;
    case 0x80C070u: goto L_80C070;
    case 0x80C073u: goto L_80C073;
    case 0x80C074u: goto L_80C074;
    case 0x80C075u: goto L_80C075;
    case 0x80C076u: goto L_80C076;
    case 0x80C077u: goto L_80C077;
    case 0x80C078u: goto L_80C078;
    case 0x80C07Au: goto L_80C07A;
    case 0x80C07Du: goto L_80C07D;
    case 0x80C07Eu: goto L_80C07E;
    case 0x80C07Fu: goto L_80C07F;
    case 0x80C080u: goto L_80C080;
    case 0x80C081u: goto L_80C081;
    case 0x80C083u: goto L_80C083;
    case 0x80C084u: goto L_80C084;
    case 0x80C087u: goto L_80C087;
    case 0x80C088u: goto L_80C088;
    case 0x80C08Bu: goto L_80C08B;
    case 0x80C08Cu: goto L_80C08C;
    case 0x80C08Fu: goto L_80C08F;
    case 0x80C092u: goto L_80C092;
    case 0x80C094u: goto L_80C094;
    case 0x80C096u: goto L_80C096;
    case 0x80C099u: goto L_80C099;
    case 0x80C09Au: goto L_80C09A;
    case 0x80C09Du: goto L_80C09D;
    case 0x80C0A0u: goto L_80C0A0;
    case 0x80C0A2u: goto L_80C0A2;
    case 0x80C0A3u: goto L_80C0A3;
    case 0x80C0A5u: goto L_80C0A5;
    case 0x80C0A6u: goto L_80C0A6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80C067:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC067u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC067u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC067u, 5u, 3u, cpu.address("abs", 0x0904u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C067 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x904u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C06A;
L_80C06A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC06Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC06Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC06Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C06A CMP
    cpu.compareA(0x6u);
    goto L_80C06D;
L_80C06D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC06Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC06Du,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC06Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C06D BCC -> $80C0A2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C0A2; }
    goto L_80C06F;
L_80C06F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC06Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC06Fu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC06Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C06F SEC
    cpu.setFlag('C', true);
    goto L_80C070;
L_80C070:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC070u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC070u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC070u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C070 SBC
    cpu.sbc(0x6u);
    goto L_80C073;
L_80C073:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC073u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC073u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC073u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C073 ASL
    cpu.aslA();
    goto L_80C074;
L_80C074:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC074u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC074u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC074u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C074 ASL
    cpu.aslA();
    goto L_80C075;
L_80C075:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC075u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC075u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC075u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C075 ASL
    cpu.aslA();
    goto L_80C076;
L_80C076:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC076u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC076u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC076u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C076 ASL
    cpu.aslA();
    goto L_80C077;
L_80C077:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC077u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC077u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC077u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C077 ASL
    cpu.aslA();
    goto L_80C078;
L_80C078:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC078u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC078u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC078u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C078 STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_80C07A;
L_80C07A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC07Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC07Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC07Au, 5u, 3u, cpu.address("abs", 0x0926u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C07A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x926u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C07D;
L_80C07D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC07Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC07Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC07Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C07D ASL
    cpu.aslA();
    goto L_80C07E;
L_80C07E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC07Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC07Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC07Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C07E ASL
    cpu.aslA();
    goto L_80C07F;
L_80C07F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC07Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC07Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC07Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C07F ASL
    cpu.aslA();
    goto L_80C080;
L_80C080:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC080u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC080u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC080u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C080 CLC
    cpu.setFlag('C', false);
    goto L_80C081;
L_80C081:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC081u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC081u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC081u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C081 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16));
    goto L_80C083;
L_80C083:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC083u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC083u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC083u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C083 CLC
    cpu.setFlag('C', false);
    goto L_80C084;
L_80C084:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC084u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC084u,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC084u, 5u, 3u, cpu.address("abs", 0x091Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C084 ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x91Eu), cpu.m8?8:16));
    goto L_80C087;
L_80C087:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC087u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC087u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC087u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C087 TAY
    cpu.transfer("TAY");
    goto L_80C088;
L_80C088:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC088u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC088u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC088u, 5u + 1u, 3u, cpu.address("absy", 0xE84Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C088 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE84Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C08B;
L_80C08B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC08Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC08Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC08Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C08B CLC
    cpu.setFlag('C', false);
    goto L_80C08C;
L_80C08C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC08Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC08Cu,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC08Cu, 5u, 3u, cpu.address("abs", 0x09A4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C08C ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x9A4u), cpu.m8?8:16));
    goto L_80C08F;
L_80C08F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC08Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC08Fu,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC08Fu, 5u, 3u, cpu.address("abs", 0x091Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C08F CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x91Au), cpu.m8?8:16));
    goto L_80C092;
L_80C092:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC092u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC092u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC092u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C092 BEQ -> $80C0A2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C0A2; }
    goto L_80C094;
L_80C094:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC094u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC094u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC094u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C094 BCS -> $80C0A5
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C0A5; }
    goto L_80C096;
L_80C096:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC096u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC096u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC096u, 5u + 1u, 3u, cpu.address("absy", 0xE8CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C096 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xE8CEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C099;
L_80C099:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC099u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC099u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC099u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C099 CLC
    cpu.setFlag('C', false);
    goto L_80C09A;
L_80C09A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC09Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC09Au,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC09Au, 5u, 3u, cpu.address("abs", 0x09A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C09A ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x9A6u), cpu.m8?8:16));
    goto L_80C09D;
L_80C09D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC09Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC09Du,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC09Du, 5u, 3u, cpu.address("abs", 0x091Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C09D CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x91Au), cpu.m8?8:16));
    goto L_80C0A0;
L_80C0A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0A0u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0A0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C0A0 BCC -> $80C0A5
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C0A5; }
    goto L_80C0A2;
L_80C0A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0A2u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0A2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C0A2 CLC
    cpu.setFlag('C', false);
    goto L_80C0A3;
L_80C0A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0A3u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0A3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C0A3 BRA -> $80C0A6
    goto L_80C0A6;
L_80C0A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0A5u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0A5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C0A5 SEC
    cpu.setFlag('C', true);
    goto L_80C0A6;
L_80C0A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0A6u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0A6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0A6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C0A6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80C0A6u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80C0A6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0A6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0A6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C0A6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80C0A6u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80C0A6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC0A6u,0x80C0A6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80D642_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80D642u: goto L_80D642;
    case 0x80D644u: goto L_80D644;
    case 0x80D647u: goto L_80D647;
    case 0x80D64Au: goto L_80D64A;
    case 0x80D64Bu: goto L_80D64B;
    case 0x80D64Eu: goto L_80D64E;
    case 0x80D650u: goto L_80D650;
    case 0x80D654u: goto L_80D654;
    case 0x80D657u: goto L_80D657;
    case 0x80D659u: goto L_80D659;
    case 0x80D65Cu: goto L_80D65C;
    case 0x80D65Du: goto L_80D65D;
    case 0x80D65Eu: goto L_80D65E;
    case 0x80D660u: goto L_80D660;
    case 0x80D662u: goto L_80D662;
    case 0x80D665u: goto L_80D665;
    case 0x80D669u: goto L_80D669;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80D642:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD642u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD642u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD642u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D642 STZ
    hw.write(cpu.address("dp", 0x63u), 0, cpu.m8?8:16);
    goto L_80D644;
L_80D644:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD644u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD644u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD644u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D644 LDY
    cpu.setY(0x4u, 16);
    goto L_80D647;
L_80D647:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD647u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD647u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD647u, 5u + 1u, 3u, cpu.address("absy", 0x03AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D647 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x3AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D64A;
L_80D64A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD64Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD64Au,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD64Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D64A TAX
    cpu.transfer("TAX");
    goto L_80D64B;
L_80D64B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD64Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD64Bu,cpu,0xECu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD64Bu, 5u, 3u, cpu.address("abs", 0x096Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D64B CPX
    cpu.compareX(hw.readW(cpu.address("abs", 0x96Eu), cpu.x8?8:16));
    goto L_80D64E;
L_80D64E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD64Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD64Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD64Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D64E BCC -> $80D65C
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80D65C; }
    goto L_80D650;
L_80D650:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD650u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD650u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD650u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D650 LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D654;
L_80D654:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD654u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD654u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD654u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D654 AND
    cpu.logicAnd(0x2000u);
    goto L_80D657;
L_80D657:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD657u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD657u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD657u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D657 BEQ -> $80D65C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D65C; }
    goto L_80D659;
L_80D659:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD659u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD659u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD659u, 6u, 3u, cpu.address("abs", 0xD66Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D659 JSR -> $80D66A stack real
    { cpu.push16Value(hw,0xD65Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD65Cu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD66Au), 0x80D659u); }
    goto L_80D65C;
L_80D65C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD65Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD65Cu,0x80D65Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD65Cu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD65Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D65C DEY
    cpu.decReg('Y');
    goto L_80D65D;
L_80D65D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD65Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD65Du,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD65Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D65D DEY
    cpu.decReg('Y');
    goto L_80D65E;
L_80D65E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD65Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD65Eu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD65Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D65E BPL -> $80D647
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80D647; }
    goto L_80D660;
L_80D660:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD660u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD660u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD660u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D660 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D662;
L_80D662:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD662u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD662u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD662u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D662 LDA
    cpu.setA(0xFFFFu, 16);
    goto L_80D665;
L_80D665:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD665u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD665u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD665u, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D665 STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D669;
L_80D669:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD669u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD669u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD669u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D669 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80D669u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80D669u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_829280_E0M1X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829280u: goto L_829280;
    case 0x829282u: goto L_829282;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829280:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9280u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9280u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9280u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829280 REP
    cpu.rep(0x20u);
    goto L_829282;
L_829282:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9282u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9282u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9282u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829282 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829282u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829282u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_829280_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829280u: goto L_829280;
    case 0x829282u: goto L_829282;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829280:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9280u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9280u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9280u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829280 REP
    cpu.rep(0x20u);
    goto L_829282;
L_829282:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9282u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9282u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9282u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829282 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829282u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829282u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_829450_E0M1X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829450u: goto L_829450;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829450:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9450u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9450u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9450u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829450 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829450u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829450u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_829450_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829450u: goto L_829450;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829450:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9450u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9450u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9450u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829450 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829450u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829450u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_829E7D_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829E7Du: goto L_829E7D;
    case 0x829E7Eu: goto L_829E7E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829E7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Du,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $829E7D PLB
    cpu.pop("PLB", hw);
    goto L_829E7E;
L_829E7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829E7E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829E7Eu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829E7Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_829E7D_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829E7Du: goto L_829E7D;
    case 0x829E7Eu: goto L_829E7E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829E7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Du,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $829E7D PLB
    cpu.pop("PLB", hw);
    goto L_829E7E;
L_829E7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829E7E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829E7Eu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829E7Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82A0D9_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82A0D9u: goto L_82A0D9;
    case 0x82A0DCu: goto L_82A0DC;
    case 0x82A0DFu: goto L_82A0DF;
    case 0x82A0E2u: goto L_82A0E2;
    case 0x82A0E5u: goto L_82A0E5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82A0D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A0D9 LDA
    cpu.setA(0x0u, 16);
    goto L_82A0DC;
L_82A0DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0DCu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0DCu, 5u, 3u, cpu.address("abs", 0x0143u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A0DC STA
    hw.write(cpu.address("abs", 0x143u), cpu.a, cpu.m8?8:16);
    goto L_82A0DF;
L_82A0DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0DFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0DFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A0DF LDA
    cpu.setA(0x0u, 16);
    goto L_82A0E2;
L_82A0E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E2u, 5u, 3u, cpu.address("abs", 0x0145u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A0E2 STA
    hw.write(cpu.address("abs", 0x145u), cpu.a, cpu.m8?8:16);
    goto L_82A0E5;
L_82A0E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0E5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A0E5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A0E5u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A0E5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82A3FB_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82A3FBu: goto L_82A3FB;
    case 0x82A3FDu: goto L_82A3FD;
    case 0x82A3FFu: goto L_82A3FF;
    case 0x82A402u: goto L_82A402;
    case 0x82A404u: goto L_82A404;
    case 0x82A407u: goto L_82A407;
    case 0x82A409u: goto L_82A409;
    case 0x82A40Cu: goto L_82A40C;
    case 0x82A40Eu: goto L_82A40E;
    case 0x82A411u: goto L_82A411;
    case 0x82A413u: goto L_82A413;
    case 0x82A416u: goto L_82A416;
    case 0x82A418u: goto L_82A418;
    case 0x82A41Bu: goto L_82A41B;
    case 0x82A41Du: goto L_82A41D;
    case 0x82A41Fu: goto L_82A41F;
    case 0x82A422u: goto L_82A422;
    case 0x82A424u: goto L_82A424;
    case 0x82A426u: goto L_82A426;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82A3FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3FBu,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3FBu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82A3FB LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A3FD;
L_82A3FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3FDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3FDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A3FD BNE -> $82A404
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A404; }
    goto L_82A3FF;
L_82A3FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA3FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA3FFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA3FFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A3FF LDA
    cpu.setA(0x8000u, 16);
    goto L_82A402;
L_82A402:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA402u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA402u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA402u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A402 BRA -> $82A41B
    goto L_82A41B;
L_82A404:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA404u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA404u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA404u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A404 BIT
    cpu.bit(0x4000u, true);
    goto L_82A407;
L_82A407:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA407u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA407u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA407u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A407 BEQ -> $82A40E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A40E; }
    goto L_82A409;
L_82A409:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA409u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA409u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA409u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A409 LDA
    cpu.setA(0x4000u, 16);
    goto L_82A40C;
L_82A40C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA40Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA40Cu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA40Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A40C BRA -> $82A41B
    goto L_82A41B;
L_82A40E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA40Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA40Eu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA40Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A40E BIT
    cpu.bit(0x8000u, true);
    goto L_82A411;
L_82A411:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA411u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA411u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA411u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A411 BEQ -> $82A418
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A418; }
    goto L_82A413;
L_82A413:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA413u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA413u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA413u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A413 LDA
    cpu.setA(0x8000u, 16);
    goto L_82A416;
L_82A416:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA416u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA416u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA416u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A416 BRA -> $82A41B
    goto L_82A41B;
L_82A418:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA418u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA418u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA418u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A418 LDA
    cpu.setA(0x0u, 16);
    goto L_82A41B;
L_82A41B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA41Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A41B STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82A41D;
L_82A41D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA41Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Du,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Du, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82A41D LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A41F;
L_82A41F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA41Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA41Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A41F AND
    cpu.logicAnd(0x3FFFu);
    goto L_82A422;
L_82A422:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA422u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA422u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA422u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A422 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_82A424;
L_82A424:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA424u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA424u,cpu,0x91u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA424u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82A424 STA
    hw.write(cpu.addressDpIndirectY(hw, 0x67u), cpu.a, cpu.m8?8:16);
    goto L_82A426;
L_82A426:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA426u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA426u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA426u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A426 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A426u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A426u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B017_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B017u: goto L_82B017;
    case 0x82B019u: goto L_82B019;
    case 0x82B01Bu: goto L_82B01B;
    case 0x82B01Du: goto L_82B01D;
    case 0x82B020u: goto L_82B020;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B017:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB017u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB017u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB017u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B017 SEP
    cpu.sep(0x20u);
    goto L_82B019;
L_82B019:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB019u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB019u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB019u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B019 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_82B01B;
L_82B01B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB01Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B01B REP
    cpu.rep(0x20u);
    goto L_82B01D;
L_82B01D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB01Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Du, 6u, 3u, cpu.address("abs", 0xC631u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B01D JSR -> $82C631 stack real
    { cpu.push16Value(hw,0xB01Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB020u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC631u), 0x82B01Du); }
    goto L_82B020;
L_82B020:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB020u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB020u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB020u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B020 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B020u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B020u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB020u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB020u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B020 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B020u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B020u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB020u,0x82B020u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82B021_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B021u: goto L_82B021;
    case 0x82B024u: goto L_82B024;
    case 0x82B027u: goto L_82B027;
    case 0x82B029u: goto L_82B029;
    case 0x82B02Du: goto L_82B02D;
    case 0x82B030u: goto L_82B030;
    case 0x82B033u: goto L_82B033;
    case 0x82B036u: goto L_82B036;
    case 0x82B038u: goto L_82B038;
    case 0x82B03Bu: goto L_82B03B;
    case 0x82B03Du: goto L_82B03D;
    case 0x82B03Fu: goto L_82B03F;
    case 0x82B041u: goto L_82B041;
    case 0x82B043u: goto L_82B043;
    case 0x82B045u: goto L_82B045;
    case 0x82B048u: goto L_82B048;
    case 0x82B04Au: goto L_82B04A;
    case 0x82B04Du: goto L_82B04D;
    case 0x82B04Fu: goto L_82B04F;
    case 0x82B052u: goto L_82B052;
    case 0x82B055u: goto L_82B055;
    case 0x82B058u: goto L_82B058;
    case 0x82B05Bu: goto L_82B05B;
    case 0x82B05Du: goto L_82B05D;
    case 0x82B060u: goto L_82B060;
    case 0x82B062u: goto L_82B062;
    case 0x82B064u: goto L_82B064;
    case 0x82B066u: goto L_82B066;
    case 0x82B068u: goto L_82B068;
    case 0x82B06Au: goto L_82B06A;
    case 0x82B06Du: goto L_82B06D;
    case 0x82B06Fu: goto L_82B06F;
    case 0x82B072u: goto L_82B072;
    case 0x82B074u: goto L_82B074;
    case 0x82B077u: goto L_82B077;
    case 0x82B07Au: goto L_82B07A;
    case 0x82B07Du: goto L_82B07D;
    case 0x82B07Fu: goto L_82B07F;
    case 0x82B082u: goto L_82B082;
    case 0x82B085u: goto L_82B085;
    case 0x82B088u: goto L_82B088;
    case 0x82B08Bu: goto L_82B08B;
    case 0x82B08Eu: goto L_82B08E;
    case 0x82B091u: goto L_82B091;
    case 0x82B094u: goto L_82B094;
    case 0x82B097u: goto L_82B097;
    case 0x82B099u: goto L_82B099;
    case 0x82B09Cu: goto L_82B09C;
    case 0x82B09Fu: goto L_82B09F;
    case 0x82B0A2u: goto L_82B0A2;
    case 0x82B0A5u: goto L_82B0A5;
    case 0x82B0A8u: goto L_82B0A8;
    case 0x82B0ABu: goto L_82B0AB;
    case 0x82B0ADu: goto L_82B0AD;
    case 0x82B0B0u: goto L_82B0B0;
    case 0x82B0B3u: goto L_82B0B3;
    case 0x82B0B6u: goto L_82B0B6;
    case 0x82B0B9u: goto L_82B0B9;
    case 0x82B0BBu: goto L_82B0BB;
    case 0x82B0BEu: goto L_82B0BE;
    case 0x82B0BFu: goto L_82B0BF;
    case 0x82B0C1u: goto L_82B0C1;
    case 0x82B0C3u: goto L_82B0C3;
    case 0x82B0C5u: goto L_82B0C5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B021:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB021u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB021u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB021u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B021 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B024;
L_82B024:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB024u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB024u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB024u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B024 CMP
    cpu.compareA(0x3u);
    goto L_82B027;
L_82B027:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB027u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB027u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB027u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B027 BCC -> $82B02D
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82B02D; }
    goto L_82B029;
L_82B029:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB029u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB029u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB029u, 8u, 4u, 0x80ACA0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B029 JSL -> $80ACA0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB02Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB02Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80ACA0u, 0x82B029u); }
    goto L_82B02D;
L_82B02D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB02Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB02Du,0x82B02Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB02Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB02Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B02D LDX
    cpu.setX(0x100u, 16);
    goto L_82B030;
L_82B030:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB030u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB030u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB030u, 5u + 1u, 3u, cpu.address("absx", 0x02E8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B030 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2E8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B033;
L_82B033:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB033u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB033u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB033u, 5u + 1u, 3u, cpu.address("absx", 0x02EAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B033 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x2EAu), cpu.m8?8:16));
    goto L_82B036;
L_82B036:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB036u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB036u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB036u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B036 BNE -> $82B052
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B052; }
    goto L_82B038;
L_82B038:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB038u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB038u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB038u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B038 LDX
    cpu.setX(0x0u, 16);
    goto L_82B03B;
L_82B03B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB03Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB03Bu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB03Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B03B STX
    hw.write(cpu.address("dp", 0x5Bu), cpu.x, cpu.x8?8:16);
    goto L_82B03D;
L_82B03D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB03Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB03Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB03Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B03D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B03F;
L_82B03F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB03Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB03Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB03Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xAAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B03F STA
    hw.write(cpu.address("dp", 0xAAu), cpu.a, cpu.m8?8:16);
    goto L_82B041;
L_82B041:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB041u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB041u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB041u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B041 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B043;
L_82B043:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB043u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB043u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB043u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B043 STA
    hw.write(cpu.address("dp", 0xA8u), cpu.a, cpu.m8?8:16);
    goto L_82B045;
L_82B045:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB045u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB045u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB045u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B045 LDA
    cpu.setA(0x2000u, 16);
    goto L_82B048;
L_82B048:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB048u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB048u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB048u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x67u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B048 STA
    hw.write(cpu.address("dp", 0x67u), cpu.a, cpu.m8?8:16);
    goto L_82B04A;
L_82B04A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB04Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB04Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB04Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B04A LDA
    cpu.setA(0x7Eu, 16);
    goto L_82B04D;
L_82B04D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB04Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB04Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB04Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x69u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B04D STA
    hw.write(cpu.address("dp", 0x69u), cpu.a, cpu.m8?8:16);
    goto L_82B04F;
L_82B04F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB04Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB04Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB04Fu, 6u, 3u, cpu.address("abs", 0x9B53u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B04F JSR -> $829B53 stack real
    { cpu.push16Value(hw,0xB051u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB052u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9B53u), 0x82B04Fu); }
    goto L_82B052;
L_82B052:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB052u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB052u,0x82B052u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB052u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB052u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B052 LDX
    cpu.setX(0x0u, 16);
    goto L_82B055;
L_82B055:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB055u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB055u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB055u, 5u + 1u, 3u, cpu.address("absx", 0x02E8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B055 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2E8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B058;
L_82B058:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB058u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB058u,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB058u, 5u + 1u, 3u, cpu.address("absx", 0x02EAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B058 ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x2EAu), cpu.m8?8:16));
    goto L_82B05B;
L_82B05B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB05Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB05Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB05Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B05B BNE -> $82B077
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B077; }
    goto L_82B05D;
L_82B05D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB05Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB05Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB05Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B05D LDX
    cpu.setX(0x100u, 16);
    goto L_82B060;
L_82B060:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB060u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB060u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB060u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B060 STX
    hw.write(cpu.address("dp", 0x5Bu), cpu.x, cpu.x8?8:16);
    goto L_82B062;
L_82B062:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB062u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB062u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB062u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B062 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B064;
L_82B064:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB064u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB064u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB064u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xAAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B064 STA
    hw.write(cpu.address("dp", 0xAAu), cpu.a, cpu.m8?8:16);
    goto L_82B066;
L_82B066:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB066u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB066u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB066u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B066 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B068;
L_82B068:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB068u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB068u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB068u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B068 STA
    hw.write(cpu.address("dp", 0xA8u), cpu.a, cpu.m8?8:16);
    goto L_82B06A;
L_82B06A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB06Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB06Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB06Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B06A LDA
    cpu.setA(0x2220u, 16);
    goto L_82B06D;
L_82B06D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB06Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB06Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB06Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x67u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B06D STA
    hw.write(cpu.address("dp", 0x67u), cpu.a, cpu.m8?8:16);
    goto L_82B06F;
L_82B06F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB06Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB06Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB06Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B06F LDA
    cpu.setA(0x7Eu, 16);
    goto L_82B072;
L_82B072:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB072u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB072u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB072u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x69u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B072 STA
    hw.write(cpu.address("dp", 0x69u), cpu.a, cpu.m8?8:16);
    goto L_82B074;
L_82B074:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB074u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB074u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB074u, 6u, 3u, cpu.address("abs", 0x9B53u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B074 JSR -> $829B53 stack real
    { cpu.push16Value(hw,0xB076u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB077u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9B53u), 0x82B074u); }
    goto L_82B077;
L_82B077:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB077u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB077u,0x82B077u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB077u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB077u, 5u, 3u, cpu.address("abs", 0x013Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B077 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B07A;
L_82B07A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB07Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB07Au,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB07Au, 5u, 3u, cpu.address("abs", 0x0139u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B07A ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x139u), cpu.m8?8:16));
    goto L_82B07D;
L_82B07D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB07Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB07Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB07Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B07D BNE -> $82B085
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B085; }
    goto L_82B07F;
L_82B07F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB07Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB07Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB07Fu, 6u, 3u, cpu.address("abs", 0xC6A1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B07F JSR -> $82C6A1 stack real
    { cpu.push16Value(hw,0xB081u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB082u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC6A1u), 0x82B07Fu); }
    goto L_82B082;
L_82B082:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB082u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB082u,0x82B082u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB082u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB082u, 6u, 3u, cpu.address("abs", 0xC631u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B082 JSR -> $82C631 stack real
    { cpu.push16Value(hw,0xB084u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB085u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC631u), 0x82B082u); }
    goto L_82B085;
L_82B085:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB085u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB085u,0x82B085u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB085u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB085u, 5u, 3u, cpu.address("abs", 0x0420u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B085 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x420u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B088;
L_82B088:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB088u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB088u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB088u, 5u, 3u, cpu.address("abs", 0x02E8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B088 STA
    hw.write(cpu.address("abs", 0x2E8u), cpu.a, cpu.m8?8:16);
    goto L_82B08B;
L_82B08B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB08Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB08Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB08Bu, 5u, 3u, cpu.address("abs", 0x0520u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B08B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x520u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B08E;
L_82B08E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB08Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB08Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB08Eu, 5u, 3u, cpu.address("abs", 0x03E8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B08E STA
    hw.write(cpu.address("abs", 0x3E8u), cpu.a, cpu.m8?8:16);
    goto L_82B091;
L_82B091:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB091u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB091u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB091u, 5u, 3u, cpu.address("abs", 0x02E8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B091 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2E8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B094;
L_82B094:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB094u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB094u,cpu,0x2Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB094u, 5u, 3u, cpu.address("abs", 0x03E8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B094 AND
    cpu.logicAnd(hw.readW(cpu.address("abs", 0x3E8u), cpu.m8?8:16));
    goto L_82B097;
L_82B097:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB097u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB097u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB097u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B097 BNE -> $82B0BF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B0BF; }
    goto L_82B099;
L_82B099:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB099u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB099u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB099u, 5u, 3u, cpu.address("abs", 0x0422u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B099 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x422u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B09C;
L_82B09C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB09Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB09Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB09Cu, 5u, 3u, cpu.address("abs", 0x02EAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B09C STA
    hw.write(cpu.address("abs", 0x2EAu), cpu.a, cpu.m8?8:16);
    goto L_82B09F;
L_82B09F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB09Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB09Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB09Fu, 5u, 3u, cpu.address("abs", 0x0522u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B09F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x522u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B0A2;
L_82B0A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0A2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0A2u, 5u, 3u, cpu.address("abs", 0x03EAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0A2 STA
    hw.write(cpu.address("abs", 0x3EAu), cpu.a, cpu.m8?8:16);
    goto L_82B0A5;
L_82B0A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0A5u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0A5u, 5u, 3u, cpu.address("abs", 0x02EAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0A5 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2EAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B0A8;
L_82B0A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0A8u,cpu,0x2Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0A8u, 5u, 3u, cpu.address("abs", 0x03EAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0A8 AND
    cpu.logicAnd(hw.readW(cpu.address("abs", 0x3EAu), cpu.m8?8:16));
    goto L_82B0AB;
L_82B0AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0ABu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0ABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0AB BNE -> $82B0BF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B0BF; }
    goto L_82B0AD;
L_82B0AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0ADu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0ADu, 5u, 3u, cpu.address("abs", 0x02E8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0AD LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2E8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B0B0;
L_82B0B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B0u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B0u, 5u, 3u, cpu.address("abs", 0x03E8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0B0 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x3E8u), cpu.m8?8:16));
    goto L_82B0B3;
L_82B0B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B3u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B3u, 5u, 3u, cpu.address("abs", 0x02EAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0B3 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x2EAu), cpu.m8?8:16));
    goto L_82B0B6;
L_82B0B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B6u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B6u, 5u, 3u, cpu.address("abs", 0x03EAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0B6 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x3EAu), cpu.m8?8:16));
    goto L_82B0B9;
L_82B0B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0B9 BEQ -> $82B0BE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B0BE; }
    goto L_82B0BB;
L_82B0BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BBu, 6u, 3u, cpu.address("abs", 0xABE3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B0BB JSR -> $82ABE3 stack real
    { cpu.push16Value(hw,0xB0BDu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0BEu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xABE3u), 0x82B0BBu); }
    goto L_82B0BE;
L_82B0BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0BEu))return;
  // 4 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B0BE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B0BEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B0BEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B0BE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B0BEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B0BEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B0BE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B0BEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B0BEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B0BE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B0BEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B0BEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0BEu,0x82B0BEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B0BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BFu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0BF SEP
    cpu.sep(0x20u);
    goto L_82B0C1;
L_82B0C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0C1 LDA
    cpu.setA(0xAu, 8);
    goto L_82B0C3;
L_82B0C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0C3 STA
    hw.write(cpu.address("dp", 0x49u), cpu.a, cpu.m8?8:16);
    goto L_82B0C5;
L_82B0C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B0C5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B0C5u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B0C5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B6E0_E0M1X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B6E0u: goto L_82B6E0;
    case 0x82B6E2u: goto L_82B6E2;
    case 0x82B6E4u: goto L_82B6E4;
    case 0x82B6E6u: goto L_82B6E6;
    case 0x82B6E8u: goto L_82B6E8;
    case 0x82B6EAu: goto L_82B6EA;
    case 0x82B6EBu: goto L_82B6EB;
    case 0x82B6ECu: goto L_82B6EC;
    case 0x82B6EDu: goto L_82B6ED;
    case 0x82B6EFu: goto L_82B6EF;
    case 0x82B6F1u: goto L_82B6F1;
    case 0x82B6F3u: goto L_82B6F3;
    case 0x82B6F4u: goto L_82B6F4;
    case 0x82B6F5u: goto L_82B6F5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B6E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6E0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B6E2;
L_82B6E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E2u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6E2 BMI -> $82B6ED
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82B6ED; }
    goto L_82B6E4;
L_82B6E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6E4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B6E6;
L_82B6E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E6u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6E6 BMI -> $82B6EB
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82B6EB; }
    goto L_82B6E8;
L_82B6E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E8u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6E8 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0xFu), cpu.m8?8:16));
    goto L_82B6EA;
L_82B6EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EAu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B6EA RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B6EAu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B6EAu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82B6EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EBu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6EB CLC
    cpu.setFlag('C', false);
    goto L_82B6EC;
L_82B6EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6ECu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6ECu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B6EC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B6ECu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B6ECu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82B6ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6ED LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B6EF;
L_82B6EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EFu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6EF BPL -> $82B6F4
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82B6F4; }
    goto L_82B6F1;
L_82B6F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F1u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6F1 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0xFu), cpu.m8?8:16));
    goto L_82B6F3;
L_82B6F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B6F3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B6F3u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B6F3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82B6F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F4u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6F4 SEC
    cpu.setFlag('C', true);
    goto L_82B6F5;
L_82B6F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B6F5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B6F5u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B6F5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B6E0_E0M1X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B6E0u: goto L_82B6E0;
    case 0x82B6E2u: goto L_82B6E2;
    case 0x82B6E4u: goto L_82B6E4;
    case 0x82B6E6u: goto L_82B6E6;
    case 0x82B6E8u: goto L_82B6E8;
    case 0x82B6EAu: goto L_82B6EA;
    case 0x82B6EBu: goto L_82B6EB;
    case 0x82B6ECu: goto L_82B6EC;
    case 0x82B6EDu: goto L_82B6ED;
    case 0x82B6EFu: goto L_82B6EF;
    case 0x82B6F1u: goto L_82B6F1;
    case 0x82B6F3u: goto L_82B6F3;
    case 0x82B6F4u: goto L_82B6F4;
    case 0x82B6F5u: goto L_82B6F5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B6E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6E0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B6E2;
L_82B6E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E2u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6E2 BMI -> $82B6ED
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82B6ED; }
    goto L_82B6E4;
L_82B6E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6E4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B6E6;
L_82B6E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E6u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6E6 BMI -> $82B6EB
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82B6EB; }
    goto L_82B6E8;
L_82B6E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E8u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6E8 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0xFu), cpu.m8?8:16));
    goto L_82B6EA;
L_82B6EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EAu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B6EA RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B6EAu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B6EAu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82B6EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EBu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6EB CLC
    cpu.setFlag('C', false);
    goto L_82B6EC;
L_82B6EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6ECu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6ECu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B6EC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B6ECu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B6ECu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82B6ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6ED LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B6EF;
L_82B6EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EFu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6EF BPL -> $82B6F4
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82B6F4; }
    goto L_82B6F1;
L_82B6F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F1u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6F1 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0xFu), cpu.m8?8:16));
    goto L_82B6F3;
L_82B6F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B6F3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B6F3u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B6F3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82B6F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F4u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6F4 SEC
    cpu.setFlag('C', true);
    goto L_82B6F5;
L_82B6F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B6F5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B6F5u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B6F5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B6E0_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B6E0u: goto L_82B6E0;
    case 0x82B6E2u: goto L_82B6E2;
    case 0x82B6E4u: goto L_82B6E4;
    case 0x82B6E6u: goto L_82B6E6;
    case 0x82B6E8u: goto L_82B6E8;
    case 0x82B6EAu: goto L_82B6EA;
    case 0x82B6EBu: goto L_82B6EB;
    case 0x82B6ECu: goto L_82B6EC;
    case 0x82B6EDu: goto L_82B6ED;
    case 0x82B6EFu: goto L_82B6EF;
    case 0x82B6F1u: goto L_82B6F1;
    case 0x82B6F3u: goto L_82B6F3;
    case 0x82B6F4u: goto L_82B6F4;
    case 0x82B6F5u: goto L_82B6F5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B6E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6E0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B6E2;
L_82B6E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E2u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6E2 BMI -> $82B6ED
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82B6ED; }
    goto L_82B6E4;
L_82B6E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6E4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B6E6;
L_82B6E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E6u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6E6 BMI -> $82B6EB
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82B6EB; }
    goto L_82B6E8;
L_82B6E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E8u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6E8 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0xFu), cpu.m8?8:16));
    goto L_82B6EA;
L_82B6EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EAu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B6EA RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B6EAu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B6EAu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82B6EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EBu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6EB CLC
    cpu.setFlag('C', false);
    goto L_82B6EC;
L_82B6EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6ECu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6ECu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B6EC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B6ECu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B6ECu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82B6ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6ED LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B6EF;
L_82B6EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EFu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6EF BPL -> $82B6F4
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82B6F4; }
    goto L_82B6F1;
L_82B6F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F1u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6F1 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0xFu), cpu.m8?8:16));
    goto L_82B6F3;
L_82B6F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B6F3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B6F3u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B6F3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82B6F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F4u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B6F4 SEC
    cpu.setFlag('C', true);
    goto L_82B6F5;
L_82B6F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B6F5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B6F5u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B6F5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B735_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B735u: goto L_82B735;
    case 0x82B737u: goto L_82B737;
    case 0x82B73Au: goto L_82B73A;
    case 0x82B73Cu: goto L_82B73C;
    case 0x82B73Fu: goto L_82B73F;
    case 0x82B742u: goto L_82B742;
    case 0x82B745u: goto L_82B745;
    case 0x82B748u: goto L_82B748;
    case 0x82B74Au: goto L_82B74A;
    case 0x82B74Cu: goto L_82B74C;
    case 0x82B74Eu: goto L_82B74E;
    case 0x82B750u: goto L_82B750;
    case 0x82B753u: goto L_82B753;
    case 0x82B755u: goto L_82B755;
    case 0x82B757u: goto L_82B757;
    case 0x82B75Au: goto L_82B75A;
    case 0x82B75Cu: goto L_82B75C;
    case 0x82B75Fu: goto L_82B75F;
    case 0x82B761u: goto L_82B761;
    case 0x82B764u: goto L_82B764;
    case 0x82B767u: goto L_82B767;
    case 0x82B769u: goto L_82B769;
    case 0x82B76Bu: goto L_82B76B;
    case 0x82B76Du: goto L_82B76D;
    case 0x82B76Eu: goto L_82B76E;
    case 0x82B76Fu: goto L_82B76F;
    case 0x82B771u: goto L_82B771;
    case 0x82B773u: goto L_82B773;
    case 0x82B774u: goto L_82B774;
    case 0x82B775u: goto L_82B775;
    case 0x82B777u: goto L_82B777;
    case 0x82B779u: goto L_82B779;
    case 0x82B77Au: goto L_82B77A;
    case 0x82B77Bu: goto L_82B77B;
    case 0x82B77Cu: goto L_82B77C;
    case 0x82B77Du: goto L_82B77D;
    case 0x82B77Fu: goto L_82B77F;
    case 0x82B782u: goto L_82B782;
    case 0x82B784u: goto L_82B784;
    case 0x82B787u: goto L_82B787;
    case 0x82B789u: goto L_82B789;
    case 0x82B78Bu: goto L_82B78B;
    case 0x82B78Du: goto L_82B78D;
    case 0x82B790u: goto L_82B790;
    case 0x82B793u: goto L_82B793;
    case 0x82B795u: goto L_82B795;
    case 0x82B798u: goto L_82B798;
    case 0x82B79Au: goto L_82B79A;
    case 0x82B79Bu: goto L_82B79B;
    case 0x82B79Cu: goto L_82B79C;
    case 0x82B79Du: goto L_82B79D;
    case 0x82B7A0u: goto L_82B7A0;
    case 0x82B7A3u: goto L_82B7A3;
    case 0x82B7A5u: goto L_82B7A5;
    case 0x82B7A7u: goto L_82B7A7;
    case 0x82B7AAu: goto L_82B7AA;
    case 0x82B7ADu: goto L_82B7AD;
    case 0x82B7B0u: goto L_82B7B0;
    case 0x82B7B3u: goto L_82B7B3;
    case 0x82B7B5u: goto L_82B7B5;
    case 0x82B7B7u: goto L_82B7B7;
    case 0x82B7BAu: goto L_82B7BA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B735:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB735u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB735u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB735u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B735 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B737;
L_82B737:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB737u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB737u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB737u, 5u + 1u, 3u, cpu.address("absx", 0x02FCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B737 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2FCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B73A;
L_82B73A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB73Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB73Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB73Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B73A BNE -> $82B73F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B73F; }
    goto L_82B73C;
L_82B73C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB73Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB73Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB73Cu, 6u, 3u, cpu.address("abs", 0xBB49u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B73C JSR -> $82BB49 stack real
    { cpu.push16Value(hw,0xB73Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB73Fu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBB49u), 0x82B73Cu); }
    goto L_82B73F;
L_82B73F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB73Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB73Fu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB73Fu, 6u, 3u, cpu.address("absx", 0x02FCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B73F STZ
    hw.write(cpu.address("absx", 0x2FCu), 0, cpu.m8?8:16);
    goto L_82B742;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB73Fu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB73Fu, 6u, 3u, cpu.address("absx", 0x02FCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B73F STZ
    hw.write(cpu.address("absx", 0x2FCu), 0, cpu.m8?8:16);
    goto L_82B742;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB73Fu,0x82B73Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B742:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB742u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB742u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB742u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B742 LDY
    cpu.setY(0x0u, 16);
    goto L_82B745;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB742u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB742u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B742 LDY
    cpu.setY(0x0u, 16);
    goto L_82B745;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB742u,0x82B742u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B745:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB745u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB745u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB745u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B745 LDA
    cpu.setA(0x1u, 16);
    goto L_82B748;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB745u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB745u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B745 LDA
    cpu.setA(0x1u, 16);
    goto L_82B748;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB745u,0x82B745u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B748:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB748u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB748u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB748u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B748 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82B74A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB748u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB748u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B748 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82B74A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB748u,0x82B748u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B74A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB74Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB74Au,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB74Au, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82B74A LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B74C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB74Au,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB74Au, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82B74A LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B74C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB74Au,0x82B74Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B74C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB74Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB74Cu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB74Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B74C BMI -> $82B755
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82B755; }
    goto L_82B74E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB74Cu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB74Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B74C BMI -> $82B755
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82B755; }
    goto L_82B74E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB74Cu,0x82B74Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B74E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB74Eu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB74Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB74Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B74E STZ
    hw.write(cpu.address("dp", 0xAu), 0, cpu.m8?8:16);
    goto L_82B750;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB74Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB74Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B74E STZ
    hw.write(cpu.address("dp", 0xAu), 0, cpu.m8?8:16);
    goto L_82B750;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB74Eu,0x82B74Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B750:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB750u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB750u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB750u, 6u, 3u, cpu.address("abs", 0xB7D9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B750 JSR -> $82B7D9 stack real
    { cpu.push16Value(hw,0xB752u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB753u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB7D9u), 0x82B750u); }
    goto L_82B753;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB750u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB750u, 6u, 3u, cpu.address("abs", 0xB7D9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B750 JSR -> $82B7D9 stack real
    { cpu.push16Value(hw,0xB752u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB753u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB7D9u), 0x82B750u); }
    goto L_82B753;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB750u,0x82B750u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B753:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB753u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB753u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB753u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B753 BRA -> $82B74A
    goto L_82B74A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB753u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB753u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B753 BRA -> $82B74A
    goto L_82B74A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB753u,0x82B753u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B755:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB755u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB755u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB755u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B755 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B757;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB755u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB755u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B755 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B757;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB755u,0x82B755u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B757:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB757u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB757u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB757u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B757 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B75A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB757u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB757u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B757 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B75A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB757u,0x82B757u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B75A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB75Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB75Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB75Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B75A BNE -> $82B764
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B764; }
    goto L_82B75C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB75Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB75Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B75A BNE -> $82B764
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B764; }
    goto L_82B75C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB75Au,0x82B75Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B75C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB75Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB75Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB75Cu, 5u, 3u, cpu.address("abs", 0x0193u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B75C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x193u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B75F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB75Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB75Cu, 5u, 3u, cpu.address("abs", 0x0193u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B75C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x193u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B75F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB75Cu,0x82B75Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B75F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB75Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB75Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB75Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B75F BNE -> $82B764
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B764; }
    goto L_82B761;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB75Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB75Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B75F BNE -> $82B764
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B764; }
    goto L_82B761;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB75Fu,0x82B75Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B761:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB761u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB761u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB761u, 6u, 3u, cpu.address("abs", 0xBAF7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B761 JSR -> $82BAF7 stack real
    { cpu.push16Value(hw,0xB763u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB764u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBAF7u), 0x82B761u); }
    goto L_82B764;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB761u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB761u, 6u, 3u, cpu.address("abs", 0xBAF7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B761 JSR -> $82BAF7 stack real
    { cpu.push16Value(hw,0xB763u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB764u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBAF7u), 0x82B761u); }
    goto L_82B764;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB761u,0x82B761u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B764:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB764u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB764u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB764u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B764 LDY
    cpu.setY(0x0u, 16);
    goto L_82B767;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB764u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB764u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B764 LDY
    cpu.setY(0x0u, 16);
    goto L_82B767;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB764u,0x82B764u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B767:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB767u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB767u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB767u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B767 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B769;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB767u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB767u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B767 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B769;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB767u,0x82B767u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B769:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB769u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB769u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB769u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82B769 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B76B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB769u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB769u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82B769 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B76B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB769u,0x82B769u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B76B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB76Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB76Bu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB76Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B76B BMI -> $82B7B5
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82B7B5; }
    goto L_82B76D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB76Bu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB76Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B76B BMI -> $82B7B5
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82B7B5; }
    goto L_82B76D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB76Bu,0x82B76Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B76D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB76Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB76Du,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB76Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B76D INY
    cpu.inc('Y');
    goto L_82B76E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB76Du,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB76Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B76D INY
    cpu.inc('Y');
    goto L_82B76E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB76Du,0x82B76Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B76E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB76Eu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB76Eu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB76Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B76E INY
    cpu.inc('Y');
    goto L_82B76F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB76Eu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB76Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B76E INY
    cpu.inc('Y');
    goto L_82B76F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB76Eu,0x82B76Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B76F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB76Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB76Fu,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB76Fu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82B76F LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B771;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB76Fu,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB76Fu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82B76F LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B771;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB76Fu,0x82B76Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B771:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB771u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB771u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB771u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B771 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_82B773;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB771u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB771u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B771 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_82B773;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB771u,0x82B771u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B773:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB773u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB773u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB773u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B773 INY
    cpu.inc('Y');
    goto L_82B774;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB773u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB773u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B773 INY
    cpu.inc('Y');
    goto L_82B774;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB773u,0x82B773u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B774:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB774u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB774u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB774u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B774 INY
    cpu.inc('Y');
    goto L_82B775;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB774u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB774u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B774 INY
    cpu.inc('Y');
    goto L_82B775;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB774u,0x82B774u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B775:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB775u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB775u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB775u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82B775 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B777;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB775u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB775u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82B775 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B777;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB775u,0x82B775u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B777:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB777u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB777u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB777u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B777 STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_82B779;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB777u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB777u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B777 STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_82B779;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB777u,0x82B777u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B779:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB779u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB779u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB779u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B779 INY
    cpu.inc('Y');
    goto L_82B77A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB779u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB779u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B779 INY
    cpu.inc('Y');
    goto L_82B77A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB779u,0x82B779u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B77A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB77Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB77Au,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB77Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B77A INY
    cpu.inc('Y');
    goto L_82B77B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB77Au,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB77Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B77A INY
    cpu.inc('Y');
    goto L_82B77B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB77Au,0x82B77Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B77B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB77Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB77Bu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB77Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B77B INY
    cpu.inc('Y');
    goto L_82B77C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB77Bu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB77Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B77B INY
    cpu.inc('Y');
    goto L_82B77C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB77Bu,0x82B77Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B77C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB77Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB77Cu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB77Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B77C INY
    cpu.inc('Y');
    goto L_82B77D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB77Cu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB77Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B77C INY
    cpu.inc('Y');
    goto L_82B77D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB77Cu,0x82B77Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B77D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB77Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB77Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB77Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B77D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B77F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB77Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB77Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B77D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B77F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB77Du,0x82B77Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B77F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB77Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB77Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB77Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B77F CMP
    cpu.compareA(0x5u);
    goto L_82B782;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB77Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB77Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B77F CMP
    cpu.compareA(0x5u);
    goto L_82B782;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB77Fu,0x82B77Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B782:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB782u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB782u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB782u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B782 BCC -> $82B769
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82B769; }
    goto L_82B784;
L_82B784:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB784u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB784u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB784u, 5u + 1u, 3u, cpu.address("absx", 0x02DCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B784 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2DCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B787;
L_82B787:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB787u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB787u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB787u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B787 BMI -> $82B7A5
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82B7A5; }
    goto L_82B789;
L_82B789:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB789u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB789u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB789u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B789 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_82B78B;
L_82B78B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB78Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB78Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB78Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B78B BNE -> $82B79A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B79A; }
    goto L_82B78D;
L_82B78D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB78Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB78Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB78Du, 5u + 1u, 3u, cpu.address("absx", 0x02D6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B78D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2D6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B790;
L_82B790:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB790u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB790u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB790u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B790 CMP
    cpu.compareA(0x2u);
    goto L_82B793;
L_82B793:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB793u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB793u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB793u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B793 BNE -> $82B767
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B767; }
    goto L_82B795;
L_82B795:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB795u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB795u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB795u, 6u, 3u, cpu.address("absx", 0x02D6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B795 STZ
    hw.write(cpu.address("absx", 0x2D6u), 0, cpu.m8?8:16);
    goto L_82B798;
L_82B798:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB798u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB798u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB798u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B798 BRA -> $82B767
    goto L_82B767;
L_82B79A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB79Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB79Au,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB79Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B79A INX
    cpu.inc('X');
    goto L_82B79B;
L_82B79B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB79Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB79Bu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB79Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B79B INX
    cpu.inc('X');
    goto L_82B79C;
L_82B79C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB79Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB79Cu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB79Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B79C TXA
    cpu.transfer("TXA");
    goto L_82B79D;
L_82B79D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB79Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB79Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB79Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B79D AND
    cpu.logicAnd(0xFFu);
    goto L_82B7A0;
L_82B7A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7A0u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7A0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7A0 CMP
    cpu.compareA(0x6u);
    goto L_82B7A3;
L_82B7A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7A3u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7A3 BCC -> $82B784
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82B784; }
    goto L_82B7A5;
L_82B7A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7A5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7A5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7A5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B7A7;
L_82B7A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7A7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7A7u, 6u, 3u, cpu.address("abs", 0xBA2Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B7A7 JSR -> $82BA2B stack real
    { cpu.push16Value(hw,0xB7A9u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB7AAu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBA2Bu), 0x82B7A7u); }
    goto L_82B7AA;
L_82B7AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7AAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB7AAu,0x82B7AAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7AAu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7AAu, 6u, 3u, cpu.address("absx", 0x02DCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7AA STA
    hw.write(cpu.address("absx", 0x2DCu), cpu.a, cpu.m8?8:16);
    goto L_82B7AD;
L_82B7AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7ADu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7ADu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7AD LDA
    cpu.setA(0x1u, 16);
    goto L_82B7B0;
L_82B7B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7B0u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7B0u, 6u, 3u, cpu.address("absx", 0x02D6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7B0 STA
    hw.write(cpu.address("absx", 0x2D6u), cpu.a, cpu.m8?8:16);
    goto L_82B7B3;
L_82B7B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7B3u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7B3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7B3 BRA -> $82B767
    goto L_82B767;
L_82B7B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7B5u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7B5u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7B5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7B5 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B7B7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7B5u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7B5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7B5 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B7B7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB7B5u,0x82B7B5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B7B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7B7u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7B7u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7B7u, 9u, 3u, cpu.address("absx", 0x02C8u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7B7 INC
    cpu.incMem(hw, cpu.address("absx", 0x2C8u), cpu.m8?8:16);
    goto L_82B7BA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7B7u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7B7u, 9u, 3u, cpu.address("absx", 0x02C8u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B7B7 INC
    cpu.incMem(hw, cpu.address("absx", 0x2C8u), cpu.m8?8:16);
    goto L_82B7BA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB7B7u,0x82B7B7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B7BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB7BAu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7BAu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7BAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B7BA RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B7BAu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B7BAu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB7BAu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB7BAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B7BA RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B7BAu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B7BAu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB7BAu,0x82B7BAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82B9A2_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B9A2u: goto L_82B9A2;
    case 0x82B9A3u: goto L_82B9A3;
    case 0x82B9A4u: goto L_82B9A4;
    case 0x82B9A7u: goto L_82B9A7;
    case 0x82B9A8u: goto L_82B9A8;
    case 0x82B9AAu: goto L_82B9AA;
    case 0x82B9ADu: goto L_82B9AD;
    case 0x82B9AFu: goto L_82B9AF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B9A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A2u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B9A2 TYA
    cpu.transfer("TYA");
    goto L_82B9A3;
L_82B9A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A3u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B9A3 SEC
    cpu.setFlag('C', true);
    goto L_82B9A4;
L_82B9A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A4u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B9A4 SBC
    cpu.sbc(0x16u);
    goto L_82B9A7;
L_82B9A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A7u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B9A7 TAY
    cpu.transfer("TAY");
    goto L_82B9A8;
L_82B9A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A8u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A8u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82B9A8 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B9AA;
L_82B9AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9AAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9AAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B9AA AND
    cpu.logicAnd(0xFFFBu);
    goto L_82B9AD;
L_82B9AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9ADu,cpu,0x91u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9ADu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82B9AD STA
    hw.write(cpu.addressDpIndirectY(hw, 0x67u), cpu.a, cpu.m8?8:16);
    goto L_82B9AF;
L_82B9AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9AFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9AFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B9AF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B9AFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B9AFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82C17A_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82C17Au: goto L_82C17A;
    case 0x82C17Cu: goto L_82C17C;
    case 0x82C17Eu: goto L_82C17E;
    case 0x82C181u: goto L_82C181;
    case 0x82C183u: goto L_82C183;
    case 0x82C186u: goto L_82C186;
    case 0x82C188u: goto L_82C188;
    case 0x82C18Bu: goto L_82C18B;
    case 0x82C18Du: goto L_82C18D;
    case 0x82C190u: goto L_82C190;
    case 0x82C192u: goto L_82C192;
    case 0x82C195u: goto L_82C195;
    case 0x82C197u: goto L_82C197;
    case 0x82C19Au: goto L_82C19A;
    case 0x82C19Du: goto L_82C19D;
    case 0x82C1A0u: goto L_82C1A0;
    case 0x82C1A3u: goto L_82C1A3;
    case 0x82C1A4u: goto L_82C1A4;
    case 0x82C1A7u: goto L_82C1A7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82C17A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC17Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC17Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC17Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C17A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C17C;
L_82C17C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC17Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC17Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC17Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C17C BNE -> $82C1A7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C1A7; }
    goto L_82C17E;
L_82C17E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC17Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC17Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC17Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C17E LDA
    cpu.setA(0x1u, 16);
    goto L_82C181;
L_82C181:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC181u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC181u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC181u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C181 STA
    hw.write(cpu.address("dp", 0x6Fu), cpu.a, cpu.m8?8:16);
    goto L_82C183;
L_82C183:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC183u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC183u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC183u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C183 LDA
    cpu.setA(0x0u, 16);
    goto L_82C186;
L_82C186:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC186u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC186u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC186u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C186 STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_82C188;
L_82C188:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC188u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC188u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC188u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C188 LDA
    cpu.setA(0xC393u, 16);
    goto L_82C18B;
L_82C18B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC18Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC18Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC18Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C18B STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82C18D;
L_82C18D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC18Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC18Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC18Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C18D LDA
    cpu.setA(0x82u, 16);
    goto L_82C190;
L_82C190:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC190u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC190u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC190u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C190 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82C192;
L_82C192:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC192u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC192u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC192u, 6u, 3u, cpu.address("abs", 0xC2E2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C192 JSR -> $82C2E2 stack real
    { cpu.push16Value(hw,0xC194u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC195u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC2E2u), 0x82C192u); }
    goto L_82C195;
L_82C195:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC195u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC195u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC195u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C195 BCC -> $82C1A4
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82C1A4; }
    goto L_82C197;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC195u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC195u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C195 BCC -> $82C1A4
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82C1A4; }
    goto L_82C197;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC195u,0x82C195u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C197:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC197u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC197u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC197u, 8u, 3u, cpu.address("abs", 0x0176u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C197 INC
    cpu.incMem(hw, cpu.address("abs", 0x176u), cpu.m8?8:16);
    goto L_82C19A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC197u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC197u, 8u, 3u, cpu.address("abs", 0x0176u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C197 INC
    cpu.incMem(hw, cpu.address("abs", 0x176u), cpu.m8?8:16);
    goto L_82C19A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC197u,0x82C197u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C19A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC19Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC19Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC19Au, 5u, 3u, cpu.address("abs", 0x02CCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C19A STZ
    hw.write(cpu.address("abs", 0x2CCu), 0, cpu.m8?8:16);
    goto L_82C19D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC19Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC19Au, 5u, 3u, cpu.address("abs", 0x02CCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C19A STZ
    hw.write(cpu.address("abs", 0x2CCu), 0, cpu.m8?8:16);
    goto L_82C19D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC19Au,0x82C19Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C19D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC19Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC19Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC19Du, 5u, 3u, cpu.address("abs", 0x0177u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C19D STZ
    hw.write(cpu.address("abs", 0x177u), 0, cpu.m8?8:16);
    goto L_82C1A0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC19Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC19Du, 5u, 3u, cpu.address("abs", 0x0177u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C19D STZ
    hw.write(cpu.address("abs", 0x177u), 0, cpu.m8?8:16);
    goto L_82C1A0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC19Du,0x82C19Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C1A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1A0u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A0u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A0u, 8u, 3u, cpu.address("abs", 0x014Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C1A0 INC
    cpu.incMem(hw, cpu.address("abs", 0x14Au), cpu.m8?8:16);
    goto L_82C1A3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A0u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A0u, 8u, 3u, cpu.address("abs", 0x014Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C1A0 INC
    cpu.incMem(hw, cpu.address("abs", 0x14Au), cpu.m8?8:16);
    goto L_82C1A3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC1A0u,0x82C1A0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C1A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1A3u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C1A3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C1A3u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C1A3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C1A3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C1A3u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C1A3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC1A3u,0x82C1A3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C1A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1A4u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A4u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A4u, 8u, 3u, cpu.address("abs", 0x02CCu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C1A4 INC
    cpu.incMem(hw, cpu.address("abs", 0x2CCu), cpu.m8?8:16);
    goto L_82C1A7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A4u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A4u, 8u, 3u, cpu.address("abs", 0x02CCu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C1A4 INC
    cpu.incMem(hw, cpu.address("abs", 0x2CCu), cpu.m8?8:16);
    goto L_82C1A7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC1A4u,0x82C1A4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C1A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC1A7u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C1A7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C1A7u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C1A7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC1A7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C1A7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C1A7u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C1A7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC1A7u,0x82C1A7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82C423_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82C423u: goto L_82C423;
    case 0x82C426u: goto L_82C426;
    case 0x82C428u: goto L_82C428;
    case 0x82C42Au: goto L_82C42A;
    case 0x82C42Du: goto L_82C42D;
    case 0x82C42Fu: goto L_82C42F;
    case 0x82C432u: goto L_82C432;
    case 0x82C434u: goto L_82C434;
    case 0x82C437u: goto L_82C437;
    case 0x82C439u: goto L_82C439;
    case 0x82C43Bu: goto L_82C43B;
    case 0x82C43Eu: goto L_82C43E;
    case 0x82C43Fu: goto L_82C43F;
    case 0x82C441u: goto L_82C441;
    case 0x82C442u: goto L_82C442;
    case 0x82C445u: goto L_82C445;
    case 0x82C447u: goto L_82C447;
    case 0x82C44Bu: goto L_82C44B;
    case 0x82C44Cu: goto L_82C44C;
    case 0x82C44Fu: goto L_82C44F;
    case 0x82C453u: goto L_82C453;
    case 0x82C454u: goto L_82C454;
    case 0x82C456u: goto L_82C456;
    case 0x82C458u: goto L_82C458;
    case 0x82C45Au: goto L_82C45A;
    case 0x82C45Cu: goto L_82C45C;
    case 0x82C45Eu: goto L_82C45E;
    case 0x82C460u: goto L_82C460;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82C423:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC423u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC423u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC423u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C423 LDA
    cpu.setA(0x55Cu, 16);
    goto L_82C426;
L_82C426:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC426u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC426u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC426u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C426 STA
    hw.write(cpu.address("dp", 0x61u), cpu.a, cpu.m8?8:16);
    goto L_82C428;
L_82C428:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC428u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC428u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC428u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C428 STZ
    hw.write(cpu.address("dp", 0x63u), 0, cpu.m8?8:16);
    goto L_82C42A;
L_82C42A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC42Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC42Au,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC42Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C42A LDY
    cpu.setY(0x3u, 16);
    goto L_82C42D;
L_82C42D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC42Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC42Du,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC42Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C42D LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82C42F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC42Du,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC42Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C42D LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82C42F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC42Du,0x82C42Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C42F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC42Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC42Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC42Fu, 5u + 1u, 3u, cpu.address("absx", 0x06C6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C42F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x6C6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C432;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC42Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC42Fu, 5u + 1u, 3u, cpu.address("absx", 0x06C6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C42F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x6C6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C432;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC42Fu,0x82C42Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C432:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC432u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC432u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC432u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C432 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_82C434;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC432u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC432u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C432 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_82C434;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC432u,0x82C432u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C434:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC434u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC434u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC434u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C434 AND
    cpu.logicAnd(0xFu);
    goto L_82C437;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC434u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC434u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C434 AND
    cpu.logicAnd(0xFu);
    goto L_82C437;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC434u,0x82C434u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C437:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC437u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC437u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC437u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C437 STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_82C439;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC437u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC437u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C437 STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_82C439;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC437u,0x82C437u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C439:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC439u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC439u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC439u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C439 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C43B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC439u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC439u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C439 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C43B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC439u,0x82C439u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C43B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC43Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC43Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC43Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C43B AND
    cpu.logicAnd(0xF0u);
    goto L_82C43E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC43Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC43Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C43B AND
    cpu.logicAnd(0xF0u);
    goto L_82C43E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC43Bu,0x82C43Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C43E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC43Eu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC43Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC43Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C43E ASL
    cpu.aslA();
    goto L_82C43F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC43Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC43Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C43E ASL
    cpu.aslA();
    goto L_82C43F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC43Eu,0x82C43Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C43F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC43Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC43Fu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC43Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C43F ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16));
    goto L_82C441;
L_82C441:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC441u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC441u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC441u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C441 CLC
    cpu.setFlag('C', false);
    goto L_82C442;
L_82C442:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC442u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC442u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC442u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C442 ADC
    cpu.adc(0x3530u);
    goto L_82C445;
L_82C445:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC445u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC445u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC445u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C445 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82C447;
L_82C447:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC447u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC447u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC447u, 6u, 4u, ((0x7E2800u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C447 STA
    hw.write(((0x7E2800u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82C44B;
L_82C44B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC44Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC44Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC44Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C44B CLC
    cpu.setFlag('C', false);
    goto L_82C44C;
L_82C44C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC44Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC44Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC44Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C44C ADC
    cpu.adc(0x10u);
    goto L_82C44F;
L_82C44F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC44Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC44Fu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC44Fu, 6u, 4u, ((0x7E2840u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C44F STA
    hw.write(((0x7E2840u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82C453;
L_82C453:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC453u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC453u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC453u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C453 DEY
    cpu.decReg('Y');
    goto L_82C454;
L_82C454:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC454u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC454u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC454u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C454 BEQ -> $82C460
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C460; }
    goto L_82C456;
L_82C456:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC456u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC456u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC456u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C456 INC
    cpu.incMem(hw, cpu.address("dp", 0x61u), cpu.m8?8:16);
    goto L_82C458;
L_82C458:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC458u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC458u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC458u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C458 INC
    cpu.incMem(hw, cpu.address("dp", 0x61u), cpu.m8?8:16);
    goto L_82C45A;
L_82C45A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC45Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC45Au,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC45Au, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C45A INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_82C45C;
L_82C45C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC45Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC45Cu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC45Cu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C45C INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_82C45E;
L_82C45E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC45Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC45Eu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC45Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C45E BRA -> $82C42D
    goto L_82C42D;
L_82C460:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC460u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC460u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC460u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C460 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C460u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C460u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82C423_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82C423u: goto L_82C423;
    case 0x82C426u: goto L_82C426;
    case 0x82C428u: goto L_82C428;
    case 0x82C42Au: goto L_82C42A;
    case 0x82C42Du: goto L_82C42D;
    case 0x82C42Fu: goto L_82C42F;
    case 0x82C432u: goto L_82C432;
    case 0x82C434u: goto L_82C434;
    case 0x82C437u: goto L_82C437;
    case 0x82C439u: goto L_82C439;
    case 0x82C43Bu: goto L_82C43B;
    case 0x82C43Eu: goto L_82C43E;
    case 0x82C43Fu: goto L_82C43F;
    case 0x82C441u: goto L_82C441;
    case 0x82C442u: goto L_82C442;
    case 0x82C445u: goto L_82C445;
    case 0x82C447u: goto L_82C447;
    case 0x82C44Bu: goto L_82C44B;
    case 0x82C44Cu: goto L_82C44C;
    case 0x82C44Fu: goto L_82C44F;
    case 0x82C453u: goto L_82C453;
    case 0x82C454u: goto L_82C454;
    case 0x82C456u: goto L_82C456;
    case 0x82C458u: goto L_82C458;
    case 0x82C45Au: goto L_82C45A;
    case 0x82C45Cu: goto L_82C45C;
    case 0x82C45Eu: goto L_82C45E;
    case 0x82C460u: goto L_82C460;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82C423:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC423u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC423u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC423u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C423 LDA
    cpu.setA(0x55Cu, 16);
    goto L_82C426;
L_82C426:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC426u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC426u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC426u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C426 STA
    hw.write(cpu.address("dp", 0x61u), cpu.a, cpu.m8?8:16);
    goto L_82C428;
L_82C428:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC428u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC428u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC428u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C428 STZ
    hw.write(cpu.address("dp", 0x63u), 0, cpu.m8?8:16);
    goto L_82C42A;
L_82C42A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC42Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC42Au,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC42Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C42A LDY
    cpu.setY(0x3u, 16);
    goto L_82C42D;
L_82C42D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC42Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC42Du,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC42Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C42D LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82C42F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC42Du,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC42Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C42D LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82C42F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC42Du,0x82C42Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C42F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC42Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC42Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC42Fu, 5u + 1u, 3u, cpu.address("absx", 0x06C6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C42F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x6C6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C432;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC42Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC42Fu, 5u + 1u, 3u, cpu.address("absx", 0x06C6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C42F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x6C6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C432;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC42Fu,0x82C42Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C432:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC432u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC432u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC432u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C432 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_82C434;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC432u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC432u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C432 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_82C434;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC432u,0x82C432u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C434:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC434u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC434u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC434u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C434 AND
    cpu.logicAnd(0xFu);
    goto L_82C437;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC434u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC434u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C434 AND
    cpu.logicAnd(0xFu);
    goto L_82C437;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC434u,0x82C434u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C437:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC437u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC437u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC437u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C437 STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_82C439;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC437u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC437u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C437 STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_82C439;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC437u,0x82C437u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C439:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC439u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC439u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC439u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C439 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C43B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC439u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC439u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C439 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C43B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC439u,0x82C439u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C43B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC43Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC43Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC43Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C43B AND
    cpu.logicAnd(0xF0u);
    goto L_82C43E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC43Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC43Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C43B AND
    cpu.logicAnd(0xF0u);
    goto L_82C43E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC43Bu,0x82C43Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C43E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC43Eu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC43Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC43Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C43E ASL
    cpu.aslA();
    goto L_82C43F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC43Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC43Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C43E ASL
    cpu.aslA();
    goto L_82C43F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC43Eu,0x82C43Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82C43F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC43Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC43Fu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC43Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C43F ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16));
    goto L_82C441;
L_82C441:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC441u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC441u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC441u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C441 CLC
    cpu.setFlag('C', false);
    goto L_82C442;
L_82C442:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC442u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC442u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC442u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C442 ADC
    cpu.adc(0x3530u);
    goto L_82C445;
L_82C445:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC445u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC445u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC445u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C445 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82C447;
L_82C447:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC447u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC447u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC447u, 6u, 4u, ((0x7E2800u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C447 STA
    hw.write(((0x7E2800u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82C44B;
L_82C44B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC44Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC44Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC44Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C44B CLC
    cpu.setFlag('C', false);
    goto L_82C44C;
L_82C44C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC44Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC44Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC44Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C44C ADC
    cpu.adc(0x10u);
    goto L_82C44F;
L_82C44F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC44Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC44Fu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC44Fu, 6u, 4u, ((0x7E2840u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C44F STA
    hw.write(((0x7E2840u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82C453;
L_82C453:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC453u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC453u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC453u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C453 DEY
    cpu.decReg('Y');
    goto L_82C454;
L_82C454:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC454u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC454u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC454u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C454 BEQ -> $82C460
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C460; }
    goto L_82C456;
L_82C456:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC456u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC456u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC456u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C456 INC
    cpu.incMem(hw, cpu.address("dp", 0x61u), cpu.m8?8:16);
    goto L_82C458;
L_82C458:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC458u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC458u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC458u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C458 INC
    cpu.incMem(hw, cpu.address("dp", 0x61u), cpu.m8?8:16);
    goto L_82C45A;
L_82C45A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC45Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC45Au,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC45Au, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C45A INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_82C45C;
L_82C45C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC45Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC45Cu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC45Cu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C45C INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_82C45E;
L_82C45E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC45Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC45Eu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC45Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C45E BRA -> $82C42D
    goto L_82C42D;
L_82C460:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC460u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC460u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC460u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C460 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C460u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C460u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82C423_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82C423u: goto L_82C423;
    case 0x82C426u: goto L_82C426;
    case 0x82C428u: goto L_82C428;
    case 0x82C42Au: goto L_82C42A;
    case 0x82C42Du: goto L_82C42D;
    case 0x82C42Fu: goto L_82C42F;
    case 0x82C432u: goto L_82C432;
    case 0x82C434u: goto L_82C434;
    case 0x82C437u: goto L_82C437;
    case 0x82C439u: goto L_82C439;
    case 0x82C43Bu: goto L_82C43B;
    case 0x82C43Eu: goto L_82C43E;
    case 0x82C43Fu: goto L_82C43F;
    case 0x82C441u: goto L_82C441;
    case 0x82C442u: goto L_82C442;
    case 0x82C445u: goto L_82C445;
    case 0x82C447u: goto L_82C447;
    case 0x82C44Bu: goto L_82C44B;
    case 0x82C44Cu: goto L_82C44C;
    case 0x82C44Fu: goto L_82C44F;
    case 0x82C453u: goto L_82C453;
    case 0x82C454u: goto L_82C454;
    case 0x82C456u: goto L_82C456;
    case 0x82C458u: goto L_82C458;
    case 0x82C45Au: goto L_82C45A;
    case 0x82C45Cu: goto L_82C45C;
    case 0x82C45Eu: goto L_82C45E;
    case 0x82C460u: goto L_82C460;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82C423:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC423u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC423u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC423u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C423 LDA
    cpu.setA(0x55Cu, 16);
    goto L_82C426;
L_82C426:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC426u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC426u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC426u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C426 STA
    hw.write(cpu.address("dp", 0x61u), cpu.a, cpu.m8?8:16);
    goto L_82C428;
L_82C428:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC428u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC428u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC428u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C428 STZ
    hw.write(cpu.address("dp", 0x63u), 0, cpu.m8?8:16);
    goto L_82C42A;
L_82C42A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC42Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC42Au,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC42Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C42A LDY
    cpu.setY(0x3u, 16);
    goto L_82C42D;
L_82C42D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC42Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC42Du,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC42Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C42D LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82C42F;
L_82C42F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC42Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC42Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC42Fu, 5u + 1u, 3u, cpu.address("absx", 0x06C6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C42F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x6C6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C432;
L_82C432:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC432u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC432u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC432u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C432 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_82C434;
L_82C434:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC434u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC434u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC434u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C434 AND
    cpu.logicAnd(0xFu);
    goto L_82C437;
L_82C437:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC437u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC437u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC437u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C437 STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_82C439;
L_82C439:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC439u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC439u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC439u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C439 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C43B;
L_82C43B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC43Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC43Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC43Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C43B AND
    cpu.logicAnd(0xF0u);
    goto L_82C43E;
L_82C43E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC43Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC43Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC43Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C43E ASL
    cpu.aslA();
    goto L_82C43F;
L_82C43F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC43Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC43Fu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC43Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C43F ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16));
    goto L_82C441;
L_82C441:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC441u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC441u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC441u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C441 CLC
    cpu.setFlag('C', false);
    goto L_82C442;
L_82C442:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC442u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC442u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC442u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C442 ADC
    cpu.adc(0x3530u);
    goto L_82C445;
L_82C445:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC445u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC445u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC445u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C445 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82C447;
L_82C447:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC447u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC447u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC447u, 6u, 4u, ((0x7E2800u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C447 STA
    hw.write(((0x7E2800u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82C44B;
L_82C44B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC44Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC44Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC44Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C44B CLC
    cpu.setFlag('C', false);
    goto L_82C44C;
L_82C44C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC44Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC44Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC44Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C44C ADC
    cpu.adc(0x10u);
    goto L_82C44F;
L_82C44F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC44Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC44Fu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC44Fu, 6u, 4u, ((0x7E2840u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C44F STA
    hw.write(((0x7E2840u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82C453;
L_82C453:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC453u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC453u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC453u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C453 DEY
    cpu.decReg('Y');
    goto L_82C454;
L_82C454:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC454u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC454u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC454u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C454 BEQ -> $82C460
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C460; }
    goto L_82C456;
L_82C456:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC456u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC456u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC456u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C456 INC
    cpu.incMem(hw, cpu.address("dp", 0x61u), cpu.m8?8:16);
    goto L_82C458;
L_82C458:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC458u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC458u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC458u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C458 INC
    cpu.incMem(hw, cpu.address("dp", 0x61u), cpu.m8?8:16);
    goto L_82C45A;
L_82C45A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC45Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC45Au,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC45Au, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C45A INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_82C45C;
L_82C45C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC45Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC45Cu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC45Cu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C45C INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_82C45E;
L_82C45E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC45Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC45Eu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC45Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C45E BRA -> $82C42D
    goto L_82C42D;
L_82C460:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC460u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC460u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC460u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C460 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C460u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C460u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82C6A1_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82C6A1u: goto L_82C6A1;
    case 0x82C6A4u: goto L_82C6A4;
    case 0x82C6A6u: goto L_82C6A6;
    case 0x82C6A9u: goto L_82C6A9;
    case 0x82C6ABu: goto L_82C6AB;
    case 0x82C6AEu: goto L_82C6AE;
    case 0x82C6B0u: goto L_82C6B0;
    case 0x82C6B2u: goto L_82C6B2;
    case 0x82C6B5u: goto L_82C6B5;
    case 0x82C6B7u: goto L_82C6B7;
    case 0x82C6B9u: goto L_82C6B9;
    case 0x82C6BCu: goto L_82C6BC;
    case 0x82C6BFu: goto L_82C6BF;
    case 0x82C6C1u: goto L_82C6C1;
    case 0x82C6C4u: goto L_82C6C4;
    case 0x82C6C6u: goto L_82C6C6;
    case 0x82C6C9u: goto L_82C6C9;
    case 0x82C6CBu: goto L_82C6CB;
    case 0x82C6CCu: goto L_82C6CC;
    case 0x82C6CDu: goto L_82C6CD;
    case 0x82C6CEu: goto L_82C6CE;
    case 0x82C6D0u: goto L_82C6D0;
    case 0x82C6D2u: goto L_82C6D2;
    case 0x82C6D5u: goto L_82C6D5;
    case 0x82C6D7u: goto L_82C6D7;
    case 0x82C6DAu: goto L_82C6DA;
    case 0x82C6DCu: goto L_82C6DC;
    case 0x82C6DFu: goto L_82C6DF;
    case 0x82C6E1u: goto L_82C6E1;
    case 0x82C6E5u: goto L_82C6E5;
    case 0x82C6E8u: goto L_82C6E8;
    case 0x82C6EAu: goto L_82C6EA;
    case 0x82C6ECu: goto L_82C6EC;
    case 0x82C6EFu: goto L_82C6EF;
    case 0x82C6F2u: goto L_82C6F2;
    case 0x82C6F5u: goto L_82C6F5;
    case 0x82C6F8u: goto L_82C6F8;
    case 0x82C6FBu: goto L_82C6FB;
    case 0x82C6FDu: goto L_82C6FD;
    case 0x82C700u: goto L_82C700;
    case 0x82C702u: goto L_82C702;
    case 0x82C705u: goto L_82C705;
    case 0x82C707u: goto L_82C707;
    case 0x82C709u: goto L_82C709;
    case 0x82C70Cu: goto L_82C70C;
    case 0x82C70Eu: goto L_82C70E;
    case 0x82C710u: goto L_82C710;
    case 0x82C713u: goto L_82C713;
    case 0x82C716u: goto L_82C716;
    case 0x82C718u: goto L_82C718;
    case 0x82C719u: goto L_82C719;
    case 0x82C71Bu: goto L_82C71B;
    case 0x82C71Eu: goto L_82C71E;
    case 0x82C720u: goto L_82C720;
    case 0x82C723u: goto L_82C723;
    case 0x82C725u: goto L_82C725;
    case 0x82C726u: goto L_82C726;
    case 0x82C727u: goto L_82C727;
    case 0x82C728u: goto L_82C728;
    case 0x82C72Au: goto L_82C72A;
    case 0x82C72Cu: goto L_82C72C;
    case 0x82C72Fu: goto L_82C72F;
    case 0x82C731u: goto L_82C731;
    case 0x82C734u: goto L_82C734;
    case 0x82C736u: goto L_82C736;
    case 0x82C739u: goto L_82C739;
    case 0x82C73Bu: goto L_82C73B;
    case 0x82C73Fu: goto L_82C73F;
    case 0x82C742u: goto L_82C742;
    case 0x82C744u: goto L_82C744;
    case 0x82C745u: goto L_82C745;
    case 0x82C747u: goto L_82C747;
    case 0x82C74Au: goto L_82C74A;
    case 0x82C74Du: goto L_82C74D;
    case 0x82C750u: goto L_82C750;
    case 0x82C753u: goto L_82C753;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82C6A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6A1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6A1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C6A1 LDA
    cpu.setA(0x0u, 16);
    goto L_82C6A4;
L_82C6A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6A4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6A4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C6A4 STA
    hw.write(cpu.address("dp", 0x5Bu), cpu.a, cpu.m8?8:16);
    goto L_82C6A6;
L_82C6A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6A6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6A6u, 5u, 3u, cpu.address("abs", 0x0222u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C6A6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x222u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C6A9;
L_82C6A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6A9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6A9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C6A9 BNE -> $82C6B2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C6B2; }
    goto L_82C6AB;
L_82C6AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6ABu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6ABu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C6AB LDA
    cpu.setA(0x208u, 16);
    goto L_82C6AE;
L_82C6AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6AEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6AEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C6AE STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82C6B0;
L_82C6B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6B0u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6B0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C6B0 BRA -> $82C6B7
    goto L_82C6B7;
L_82C6B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6B2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6B2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C6B2 LDA
    cpu.setA(0x224u, 16);
    goto L_82C6B5;
L_82C6B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6B5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6B5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C6B5 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82C6B7;
L_82C6B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6B7u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6B7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C6B7 STZ
    hw.write(cpu.address("dp", 0x2u), 0, cpu.m8?8:16);
    goto L_82C6B9;
L_82C6B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6B9u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6B9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C6B9 LDY
    cpu.setY(0x6u, 16);
    goto L_82C6BC;
L_82C6BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6BCu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6BCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C6BC LDX
    cpu.setX(0x3u, 16);
    goto L_82C6BF;
L_82C6BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6BFu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6BFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C6BF SEP
    cpu.sep(0x20u);
    goto L_82C6C1;
L_82C6C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6C1u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6C1u, 4u + 1u, 3u, cpu.address("absy", 0x0276u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C6C1 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x276u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C6C4;
L_82C6C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6C4u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6C4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C6C4 STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_82C6C6;
L_82C6C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6C6u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6C6u, 4u + 1u, 3u, cpu.address("absy", 0x027Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C6C6 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x27Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C6C9;
L_82C6C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6C9u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6C9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C6C9 STA
    hw.write(cpu.address("dpx", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_82C6CB;
L_82C6CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6CBu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6CBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C6CB DEY
    cpu.decReg('Y');
    goto L_82C6CC;
L_82C6CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6CCu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6CCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C6CC DEY
    cpu.decReg('Y');
    goto L_82C6CD;
L_82C6CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6CDu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6CDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C6CD DEX
    cpu.decReg('X');
    goto L_82C6CE;
L_82C6CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6CEu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6CEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C6CE BPL -> $82C6C1
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82C6C1; }
    goto L_82C6D0;
L_82C6D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6D0u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6D0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C6D0 REP
    cpu.rep(0x20u);
    goto L_82C6D2;
L_82C6D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6D2u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6D2u, 5u, 3u, cpu.address("abs", 0x0410u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C6D2 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x410u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C6D5;
L_82C6D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6D5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6D5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C6D5 BNE -> $82C6DC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C6DC; }
    goto L_82C6D7;
L_82C6D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6D7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6D7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C6D7 LDA
    cpu.setA(0x0u, 16);
    goto L_82C6DA;
L_82C6DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6DAu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6DAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C6DA BRA -> $82C6DF
    goto L_82C6DF;
L_82C6DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6DCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6DCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C6DC LDA
    cpu.setA(0xFFFFu, 16);
    goto L_82C6DF;
L_82C6DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6DFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6DFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C6DF STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_82C6E1;
L_82C6E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6E1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6E1u, 8u, 4u, 0x808915u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82C6E1 JSL -> $808915 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC6E4u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC6E5u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808915u, 0x82C6E1u); }
    goto L_82C6E5;
L_82C6E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6E5u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC6E5u,0x82C6E5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6E5u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6E5u, 5u, 3u, cpu.address("abs", 0x0222u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C6E5 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x222u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C6E8;
L_82C6E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6E8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C6E8 BEQ -> $82C6F8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C6F8; }
    goto L_82C6EA;
L_82C6EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6EAu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6EAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C6EA BMI -> $82C6F5
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82C6F5; }
    goto L_82C6EC;
L_82C6EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6ECu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6ECu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C6EC LDX
    cpu.setX(0x0u, 16);
    goto L_82C6EF;
L_82C6EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6EFu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6EFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C6EF LDY
    cpu.setY(0x0u, 16);
    goto L_82C6F2;
L_82C6F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6F2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6F2u, 6u, 3u, cpu.address("abs", 0xA1CFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C6F2 JSR -> $82A1CF stack real
    { cpu.push16Value(hw,0xC6F4u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC6F5u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA1CFu), 0x82C6F2u); }
    goto L_82C6F5;
L_82C6F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6F5u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC6F5u,0x82C6F5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6F5u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6F5u, 5u, 3u, cpu.address("abs", 0x0222u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C6F5 STZ
    hw.write(cpu.address("abs", 0x222u), 0, cpu.m8?8:16);
    goto L_82C6F8;
L_82C6F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6F8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6F8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C6F8 LDA
    cpu.setA(0x100u, 16);
    goto L_82C6FB;
L_82C6FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6FBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6FBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C6FB STA
    hw.write(cpu.address("dp", 0x5Bu), cpu.a, cpu.m8?8:16);
    goto L_82C6FD;
L_82C6FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6FDu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6FDu, 5u, 3u, cpu.address("abs", 0x0322u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C6FD LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x322u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C700;
L_82C700:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC700u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC700u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC700u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C700 BNE -> $82C709
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C709; }
    goto L_82C702;
L_82C702:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC702u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC702u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC702u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C702 LDA
    cpu.setA(0x308u, 16);
    goto L_82C705;
L_82C705:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC705u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC705u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC705u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C705 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82C707;
L_82C707:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC707u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC707u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC707u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C707 BRA -> $82C70E
    goto L_82C70E;
L_82C709:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC709u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC709u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC709u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C709 LDA
    cpu.setA(0x324u, 16);
    goto L_82C70C;
L_82C70C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC70Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC70Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC70Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C70C STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82C70E;
L_82C70E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC70Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC70Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC70Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C70E STZ
    hw.write(cpu.address("dp", 0x2u), 0, cpu.m8?8:16);
    goto L_82C710;
L_82C710:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC710u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC710u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC710u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C710 LDX
    cpu.setX(0x3u, 16);
    goto L_82C713;
L_82C713:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC713u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC713u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC713u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C713 LDA
    cpu.setA(0x6u, 16);
    goto L_82C716;
L_82C716:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC716u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC716u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC716u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C716 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16));
    goto L_82C718;
L_82C718:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC718u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC718u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC718u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C718 TAY
    cpu.transfer("TAY");
    goto L_82C719;
L_82C719:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC719u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC719u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC719u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C719 SEP
    cpu.sep(0x20u);
    goto L_82C71B;
L_82C71B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC71Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC71Bu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC71Bu, 4u + 1u, 3u, cpu.address("absy", 0x0276u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C71B LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x276u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C71E;
L_82C71E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC71Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC71Eu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC71Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C71E STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_82C720;
L_82C720:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC720u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC720u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC720u, 4u + 1u, 3u, cpu.address("absy", 0x027Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C720 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x27Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C723;
L_82C723:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC723u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC723u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC723u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C723 STA
    hw.write(cpu.address("dpx", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_82C725;
L_82C725:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC725u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC725u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC725u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C725 DEY
    cpu.decReg('Y');
    goto L_82C726;
L_82C726:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC726u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC726u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC726u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C726 DEY
    cpu.decReg('Y');
    goto L_82C727;
L_82C727:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC727u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC727u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC727u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C727 DEX
    cpu.decReg('X');
    goto L_82C728;
L_82C728:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC728u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC728u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC728u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C728 BPL -> $82C71B
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82C71B; }
    goto L_82C72A;
L_82C72A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC72Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC72Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC72Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C72A REP
    cpu.rep(0x20u);
    goto L_82C72C;
L_82C72C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC72Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC72Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC72Cu, 5u, 3u, cpu.address("abs", 0x0510u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C72C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x510u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C72F;
L_82C72F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC72Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC72Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC72Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C72F BNE -> $82C736
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C736; }
    goto L_82C731;
L_82C731:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC731u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC731u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC731u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C731 LDA
    cpu.setA(0x0u, 16);
    goto L_82C734;
L_82C734:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC734u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC734u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC734u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C734 BRA -> $82C739
    goto L_82C739;
L_82C736:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC736u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC736u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC736u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C736 LDA
    cpu.setA(0xFFFFu, 16);
    goto L_82C739;
L_82C739:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC739u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC739u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC739u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C739 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_82C73B;
L_82C73B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC73Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC73Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC73Bu, 8u, 4u, 0x808915u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82C73B JSL -> $808915 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC73Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC73Fu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808915u, 0x82C73Bu); }
    goto L_82C73F;
L_82C73F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC73Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC73Fu,0x82C73Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC73Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC73Fu, 5u, 3u, cpu.address("abs", 0x0322u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C73F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x322u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C742;
L_82C742:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC742u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC742u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC742u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C742 BNE -> $82C745
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C745; }
    goto L_82C744;
L_82C744:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC744u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC744u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC744u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C744 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C744u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C744u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82C745:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC745u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC745u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC745u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C745 BMI -> $82C750
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82C750; }
    goto L_82C747;
L_82C747:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC747u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC747u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC747u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C747 LDX
    cpu.setX(0x100u, 16);
    goto L_82C74A;
L_82C74A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC74Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC74Au,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC74Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C74A LDY
    cpu.setY(0x100u, 16);
    goto L_82C74D;
L_82C74D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC74Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC74Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC74Du, 6u, 3u, cpu.address("abs", 0xA1CFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C74D JSR -> $82A1CF stack real
    { cpu.push16Value(hw,0xC74Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC750u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA1CFu), 0x82C74Du); }
    goto L_82C750;
L_82C750:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC750u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC750u,0x82C750u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC750u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC750u, 5u, 3u, cpu.address("abs", 0x0322u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C750 STZ
    hw.write(cpu.address("abs", 0x322u), 0, cpu.m8?8:16);
    goto L_82C753;
L_82C753:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC753u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC753u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC753u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C753 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C753u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C753u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82D56B_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82D56Bu: goto L_82D56B;
    case 0x82D56Cu: goto L_82D56C;
    case 0x82D56Eu: goto L_82D56E;
    case 0x82D570u: goto L_82D570;
    case 0x82D571u: goto L_82D571;
    case 0x82D573u: goto L_82D573;
    case 0x82D574u: goto L_82D574;
    case 0x82D577u: goto L_82D577;
    case 0x82D57Au: goto L_82D57A;
    case 0x82D57Cu: goto L_82D57C;
    case 0x82D57Fu: goto L_82D57F;
    case 0x82D581u: goto L_82D581;
    case 0x82D583u: goto L_82D583;
    case 0x82D586u: goto L_82D586;
    case 0x82D588u: goto L_82D588;
    case 0x82D58Au: goto L_82D58A;
    case 0x82D58Du: goto L_82D58D;
    case 0x82D58Eu: goto L_82D58E;
    case 0x82D591u: goto L_82D591;
    case 0x82D593u: goto L_82D593;
    case 0x82D596u: goto L_82D596;
    case 0x82D598u: goto L_82D598;
    case 0x82D59Au: goto L_82D59A;
    case 0x82D59Du: goto L_82D59D;
    case 0x82D59Eu: goto L_82D59E;
    case 0x82D59Fu: goto L_82D59F;
    case 0x82D5A1u: goto L_82D5A1;
    case 0x82D5A2u: goto L_82D5A2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82D56B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD56Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD56Bu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD56Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82D56B PHB
    cpu.push("PHB", hw);
    goto L_82D56C;
L_82D56C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD56Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD56Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD56Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D56C SEP
    cpu.sep(0x20u);
    goto L_82D56E;
L_82D56E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD56Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD56Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD56Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D56E LDA
    cpu.setA(0x7Eu, 8);
    goto L_82D570;
L_82D570:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD570u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD570u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD570u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82D570 PHA
    cpu.push("PHA", hw);
    goto L_82D571;
L_82D571:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD571u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD571u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD571u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D571 REP
    cpu.rep(0x20u);
    goto L_82D573;
L_82D573:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD573u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD573u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD573u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82D573 PLB
    cpu.pop("PLB", hw);
    goto L_82D574;
L_82D574:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD574u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD574u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD574u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D574 LDY
    cpu.setY(0x418u, 16);
    goto L_82D577;
L_82D577:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD577u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD577u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD577u, 5u + 1u, 3u, cpu.address("absy", 0x2000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D577 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2000u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D57A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD577u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD577u, 5u + 1u, 3u, cpu.address("absy", 0x2000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D577 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2000u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D57A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD577u,0x82D577u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82D57A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD57Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD57Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD57Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D57A BEQ -> $82D59D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D59D; }
    goto L_82D57C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD57Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD57Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D57A BEQ -> $82D59D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D59D; }
    goto L_82D57C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD57Au,0x82D57Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82D57C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD57Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD57Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD57Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D57C CMP
    cpu.compareA(0xFFFFu);
    goto L_82D57F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD57Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD57Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D57C CMP
    cpu.compareA(0xFFFFu);
    goto L_82D57F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD57Cu,0x82D57Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82D57F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD57Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD57Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD57Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D57F BEQ -> $82D59D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D59D; }
    goto L_82D581;
L_82D581:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD581u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD581u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD581u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D581 STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_82D583;
L_82D583:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD583u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD583u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD583u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D583 AND
    cpu.logicAnd(0xFF8Fu);
    goto L_82D586;
L_82D586:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD586u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD586u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD586u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D586 STA
    hw.write(cpu.address("dp", 0x61u), cpu.a, cpu.m8?8:16);
    goto L_82D588;
L_82D588:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD588u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD588u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD588u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D588 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D58A;
L_82D58A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD58Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD58Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD58Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D58A AND
    cpu.logicAnd(0x70u);
    goto L_82D58D;
L_82D58D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD58Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD58Du,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD58Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D58D SEC
    cpu.setFlag('C', true);
    goto L_82D58E;
L_82D58E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD58Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD58Eu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD58Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D58E SBC
    cpu.sbc(0x10u);
    goto L_82D591;
L_82D591:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD591u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD591u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD591u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D591 BNE -> $82D598
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D598; }
    goto L_82D593;
L_82D593:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD593u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD593u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD593u, 8u, 3u, cpu.address("abs", 0x0141u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D593 INC
    cpu.incMem(hw, cpu.address("abs", 0x141u), cpu.m8?8:16);
    goto L_82D596;
L_82D596:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD596u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD596u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD596u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D596 BRA -> $82D5A1
    goto L_82D5A1;
L_82D598:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD598u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD598u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD598u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D598 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x61u), cpu.m8?8:16));
    goto L_82D59A;
L_82D59A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD59Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD59Au,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD59Au, 6u, 3u, cpu.address("absy", 0x2000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D59A STA
    hw.write(cpu.address("absy", 0x2000u), cpu.a, cpu.m8?8:16);
    goto L_82D59D;
L_82D59D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD59Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD59Du,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD59Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D59D DEY
    cpu.decReg('Y');
    goto L_82D59E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD59Du,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD59Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D59D DEY
    cpu.decReg('Y');
    goto L_82D59E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD59Du,0x82D59Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82D59E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD59Eu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD59Eu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD59Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D59E DEY
    cpu.decReg('Y');
    goto L_82D59F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD59Eu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD59Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D59E DEY
    cpu.decReg('Y');
    goto L_82D59F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD59Eu,0x82D59Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82D59F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD59Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD59Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD59Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D59F BPL -> $82D577
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82D577; }
    goto L_82D5A1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD59Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD59Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D59F BPL -> $82D577
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82D577; }
    goto L_82D5A1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD59Fu,0x82D59Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82D5A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5A1u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5A1u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5A1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82D5A1 PLB
    cpu.pop("PLB", hw);
    goto L_82D5A2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5A1u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5A1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82D5A1 PLB
    cpu.pop("PLB", hw);
    goto L_82D5A2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD5A1u,0x82D5A1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82D5A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5A2u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5A2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5A2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D5A2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D5A2u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D5A2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5A2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5A2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D5A2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D5A2u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D5A2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD5A2u,0x82D5A2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82D5DF_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82D5DFu: goto L_82D5DF;
    case 0x82D5E2u: goto L_82D5E2;
    case 0x82D5E6u: goto L_82D5E6;
    case 0x82D5E8u: goto L_82D5E8;
    case 0x82D5EBu: goto L_82D5EB;
    case 0x82D5EDu: goto L_82D5ED;
    case 0x82D5F0u: goto L_82D5F0;
    case 0x82D5F2u: goto L_82D5F2;
    case 0x82D5F6u: goto L_82D5F6;
    case 0x82D5F9u: goto L_82D5F9;
    case 0x82D5FBu: goto L_82D5FB;
    case 0x82D5FFu: goto L_82D5FF;
    case 0x82D602u: goto L_82D602;
    case 0x82D606u: goto L_82D606;
    case 0x82D608u: goto L_82D608;
    case 0x82D60Bu: goto L_82D60B;
    case 0x82D60Du: goto L_82D60D;
    case 0x82D610u: goto L_82D610;
    case 0x82D612u: goto L_82D612;
    case 0x82D616u: goto L_82D616;
    case 0x82D619u: goto L_82D619;
    case 0x82D61Bu: goto L_82D61B;
    case 0x82D61Fu: goto L_82D61F;
    case 0x82D622u: goto L_82D622;
    case 0x82D624u: goto L_82D624;
    case 0x82D627u: goto L_82D627;
    case 0x82D629u: goto L_82D629;
    case 0x82D62Cu: goto L_82D62C;
    case 0x82D62Du: goto L_82D62D;
    case 0x82D630u: goto L_82D630;
    case 0x82D633u: goto L_82D633;
    case 0x82D635u: goto L_82D635;
    case 0x82D638u: goto L_82D638;
    case 0x82D639u: goto L_82D639;
    case 0x82D63Cu: goto L_82D63C;
    case 0x82D63Fu: goto L_82D63F;
    case 0x82D641u: goto L_82D641;
    case 0x82D644u: goto L_82D644;
    case 0x82D646u: goto L_82D646;
    case 0x82D649u: goto L_82D649;
    case 0x82D64Cu: goto L_82D64C;
    case 0x82D64Fu: goto L_82D64F;
    case 0x82D651u: goto L_82D651;
    case 0x82D654u: goto L_82D654;
    case 0x82D657u: goto L_82D657;
    case 0x82D65Au: goto L_82D65A;
    case 0x82D65Bu: goto L_82D65B;
    case 0x82D65Cu: goto L_82D65C;
    case 0x82D65Fu: goto L_82D65F;
    case 0x82D660u: goto L_82D660;
    case 0x82D664u: goto L_82D664;
    case 0x82D666u: goto L_82D666;
    case 0x82D669u: goto L_82D669;
    case 0x82D66Bu: goto L_82D66B;
    case 0x82D66Eu: goto L_82D66E;
    case 0x82D670u: goto L_82D670;
    case 0x82D674u: goto L_82D674;
    case 0x82D677u: goto L_82D677;
    case 0x82D678u: goto L_82D678;
    case 0x82D679u: goto L_82D679;
    case 0x82D67Cu: goto L_82D67C;
    case 0x82D67Du: goto L_82D67D;
    case 0x82D681u: goto L_82D681;
    case 0x82D683u: goto L_82D683;
    case 0x82D686u: goto L_82D686;
    case 0x82D688u: goto L_82D688;
    case 0x82D68Cu: goto L_82D68C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82D5DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5DFu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5DFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5DF LDX
    cpu.setX(0x0u, 16);
    goto L_82D5E2;
L_82D5E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5E2u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5E2u, 6u, 4u, ((0x9E8232u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5E2 LDA
    cpu.loadA(hw.readW(((0x9E8232u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D5E6;
L_82D5E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5E6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5E6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5E6 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82D5E8;
L_82D5E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5E8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5E8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5E8 LDA
    cpu.setA(0x68u, 16);
    goto L_82D5EB;
L_82D5EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5EBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5EBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5EB STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82D5ED;
L_82D5ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5EDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5EDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5ED LDA
    cpu.setA(0x38u, 16);
    goto L_82D5F0;
L_82D5F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5F0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5F0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5F0 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82D5F2;
L_82D5F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5F2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5F2u, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82D5F2 JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD5F5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD5F6u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x82D5F2u); }
    goto L_82D5F6;
L_82D5F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5F6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD5F6u,0x82D5F6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5F6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5F6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5F6 LDA
    cpu.setA(0xC8u, 16);
    goto L_82D5F9;
L_82D5F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5F9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5F9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5F9 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82D5FB;
L_82D5FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5FBu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5FBu, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82D5FB JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD5FEu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD5FFu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x82D5FBu); }
    goto L_82D5FF;
L_82D5FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5FFu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD5FFu,0x82D5FFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5FFu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5FFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5FF LDX
    cpu.setX(0x2Cu, 16);
    goto L_82D602;
L_82D602:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD602u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD602u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD602u, 6u, 4u, ((0x9E8232u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D602 LDA
    cpu.loadA(hw.readW(((0x9E8232u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D606;
L_82D606:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD606u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD606u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD606u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D606 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82D608;
L_82D608:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD608u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD608u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD608u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D608 LDA
    cpu.setA(0x80u, 16);
    goto L_82D60B;
L_82D60B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD60Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD60Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD60Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D60B STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82D60D;
L_82D60D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD60Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD60Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD60Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D60D LDA
    cpu.setA(0x38u, 16);
    goto L_82D610;
L_82D610:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD610u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD610u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD610u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D610 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82D612;
L_82D612:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD612u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD612u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD612u, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82D612 JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD615u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD616u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x82D612u); }
    goto L_82D616;
L_82D616:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD616u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD616u,0x82D616u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD616u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD616u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D616 LDA
    cpu.setA(0xC8u, 16);
    goto L_82D619;
L_82D619:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD619u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD619u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD619u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D619 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82D61B;
L_82D61B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD61Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD61Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD61Bu, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82D61B JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD61Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD61Fu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x82D61Bu); }
    goto L_82D61F;
L_82D61F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD61Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD61Fu,0x82D61Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD61Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD61Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D61F LDA
    cpu.setA(0x68u, 16);
    goto L_82D622;
L_82D622:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD622u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD622u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD622u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D622 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82D624;
L_82D624:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD624u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD624u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD624u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D624 LDA
    cpu.setA(0x3Cu, 16);
    goto L_82D627;
L_82D627:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD627u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD627u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD627u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D627 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82D629;
L_82D629:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD629u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD629u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD629u, 5u, 3u, cpu.address("abs", 0x02CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D629 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2CEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D62C;
L_82D62C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD62Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD62Cu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD62Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D62C INC
    cpu.inc('A');
    goto L_82D62D;
L_82D62D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD62Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD62Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD62Du, 6u, 3u, cpu.address("abs", 0xCCB0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D62D JSR -> $82CCB0 stack real
    { cpu.push16Value(hw,0xD62Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD630u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCCB0u), 0x82D62Du); }
    goto L_82D630;
L_82D630:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD630u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD630u,0x82D630u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD630u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD630u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D630 LDA
    cpu.setA(0xCCu, 16);
    goto L_82D633;
L_82D633:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD633u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD633u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD633u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D633 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82D635;
L_82D635:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD635u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD635u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD635u, 5u, 3u, cpu.address("abs", 0x03CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D635 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x3CEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D638;
L_82D638:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD638u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD638u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD638u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D638 INC
    cpu.inc('A');
    goto L_82D639;
L_82D639:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD639u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD639u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD639u, 6u, 3u, cpu.address("abs", 0xCCB0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D639 JSR -> $82CCB0 stack real
    { cpu.push16Value(hw,0xD63Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD63Cu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCCB0u), 0x82D639u); }
    goto L_82D63C;
L_82D63C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD63Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD63Cu,0x82D63Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD63Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD63Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D63C LDA
    cpu.setA(0x90u, 16);
    goto L_82D63F;
L_82D63F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD63Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD63Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD63Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D63F STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82D641;
L_82D641:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD641u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD641u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD641u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D641 LDA
    cpu.setA(0x4Cu, 16);
    goto L_82D644;
L_82D644:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD644u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD644u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD644u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D644 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82D646;
L_82D646:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD646u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD646u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD646u, 5u, 3u, cpu.address("abs", 0x02A4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D646 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2A4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D649;
L_82D649:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD649u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD649u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD649u, 6u, 3u, cpu.address("abs", 0xCCB0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D649 JSR -> $82CCB0 stack real
    { cpu.push16Value(hw,0xD64Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD64Cu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCCB0u), 0x82D649u); }
    goto L_82D64C;
L_82D64C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD64Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD64Cu,0x82D64Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD64Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD64Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D64C LDA
    cpu.setA(0xDCu, 16);
    goto L_82D64F;
L_82D64F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD64Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD64Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD64Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D64F STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82D651;
L_82D651:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD651u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD651u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD651u, 5u, 3u, cpu.address("abs", 0x03A4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D651 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x3A4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D654;
L_82D654:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD654u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD654u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD654u, 6u, 3u, cpu.address("abs", 0xCCB0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D654 JSR -> $82CCB0 stack real
    { cpu.push16Value(hw,0xD656u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD657u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCCB0u), 0x82D654u); }
    goto L_82D657;
L_82D657:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD657u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD657u,0x82D657u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD657u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD657u, 5u, 3u, cpu.address("abs", 0x02A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D657 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2A2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D65A;
L_82D65A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD65Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD65Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD65Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D65A ASL
    cpu.aslA();
    goto L_82D65B;
L_82D65B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD65Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD65Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD65Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D65B CLC
    cpu.setFlag('C', false);
    goto L_82D65C;
L_82D65C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD65Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD65Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD65Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D65C ADC
    cpu.adc(0x2Eu);
    goto L_82D65F;
L_82D65F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD65Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD65Fu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD65Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D65F TAX
    cpu.transfer("TAX");
    goto L_82D660;
L_82D660:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD660u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD660u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD660u, 6u, 4u, ((0x9E8232u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D660 LDA
    cpu.loadA(hw.readW(((0x9E8232u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D664;
L_82D664:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD664u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD664u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD664u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D664 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82D666;
L_82D666:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD666u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD666u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD666u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D666 LDA
    cpu.setA(0x90u, 16);
    goto L_82D669;
L_82D669:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD669u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD669u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD669u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D669 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82D66B;
L_82D66B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD66Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD66Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD66Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D66B LDA
    cpu.setA(0x30u, 16);
    goto L_82D66E;
L_82D66E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD66Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD66Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD66Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D66E STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82D670;
L_82D670:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD670u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD670u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD670u, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82D670 JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD673u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD674u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x82D670u); }
    goto L_82D674;
L_82D674:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD674u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD674u,0x82D674u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD674u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD674u, 5u, 3u, cpu.address("abs", 0x03A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D674 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x3A2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D677;
L_82D677:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD677u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD677u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD677u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D677 ASL
    cpu.aslA();
    goto L_82D678;
L_82D678:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD678u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD678u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD678u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D678 CLC
    cpu.setFlag('C', false);
    goto L_82D679;
L_82D679:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD679u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD679u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD679u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D679 ADC
    cpu.adc(0x2Eu);
    goto L_82D67C;
L_82D67C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD67Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD67Cu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD67Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D67C TAX
    cpu.transfer("TAX");
    goto L_82D67D;
L_82D67D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD67Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD67Du,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD67Du, 6u, 4u, ((0x9E8232u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D67D LDA
    cpu.loadA(hw.readW(((0x9E8232u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D681;
L_82D681:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD681u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD681u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD681u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D681 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82D683;
L_82D683:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD683u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD683u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD683u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D683 LDA
    cpu.setA(0xC0u, 16);
    goto L_82D686;
L_82D686:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD686u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD686u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD686u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D686 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82D688;
L_82D688:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD688u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD688u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD688u, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82D688 JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD68Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD68Cu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x82D688u); }
    goto L_82D68C;
L_82D68C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD68Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD68Cu,0x82D68Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD68Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD68Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D68C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D68Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D68Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82D6F5_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82D6F5u: goto L_82D6F5;
    case 0x82D6F8u: goto L_82D6F8;
    case 0x82D6FCu: goto L_82D6FC;
    case 0x82D6FEu: goto L_82D6FE;
    case 0x82D701u: goto L_82D701;
    case 0x82D702u: goto L_82D702;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82D6F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F5u, 6u, 3u, cpu.address("abs", 0xD7C1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D6F5 JSR -> $82D7C1 stack real
    { cpu.push16Value(hw,0xD6F7u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD6F8u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD7C1u), 0x82D6F5u); }
    goto L_82D6F8;
L_82D6F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6F8u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD6F8u,0x82D6F8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6F8u, 8u, 4u, 0x808EE1u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82D6F8 JSL -> $808EE1 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD6FBu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD6FCu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808EE1u, 0x82D6F8u); }
    goto L_82D6FC;
L_82D6FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6FCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD6FCu,0x82D6FCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6FCu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6FCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D6FC LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82D6FE;
L_82D6FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD6FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD6FEu,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD6FEu, 9u, 3u, cpu.address("absx", 0x0404u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D6FE INC
    cpu.incMem(hw, cpu.address("absx", 0x404u), cpu.m8?8:16);
    goto L_82D701;
L_82D701:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD701u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD701u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD701u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D701 SEC
    cpu.setFlag('C', true);
    goto L_82D702;
L_82D702:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD702u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD702u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD702u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D702 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D702u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D702u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82DC0E_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82DC0Eu: goto L_82DC0E;
    case 0x82DC11u: goto L_82DC11;
    case 0x82DC13u: goto L_82DC13;
    case 0x82DC15u: goto L_82DC15;
    case 0x82DC17u: goto L_82DC17;
    case 0x82DC19u: goto L_82DC19;
    case 0x82DC1Au: goto L_82DC1A;
    case 0x82DC1Du: goto L_82DC1D;
    case 0x82DC1Fu: goto L_82DC1F;
    case 0x82DC22u: goto L_82DC22;
    case 0x82DC23u: goto L_82DC23;
    case 0x82DC26u: goto L_82DC26;
    case 0x82DC29u: goto L_82DC29;
    case 0x82DC2Bu: goto L_82DC2B;
    case 0x82DC2Eu: goto L_82DC2E;
    case 0x82DC31u: goto L_82DC31;
    case 0x82DC34u: goto L_82DC34;
    case 0x82DC37u: goto L_82DC37;
    case 0x82DC38u: goto L_82DC38;
    case 0x82DC3Bu: goto L_82DC3B;
    case 0x82DC3Eu: goto L_82DC3E;
    case 0x82DC41u: goto L_82DC41;
    case 0x82DC43u: goto L_82DC43;
    case 0x82DC46u: goto L_82DC46;
    case 0x82DC49u: goto L_82DC49;
    case 0x82DC4Cu: goto L_82DC4C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82DC0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Eu, 5u, 3u, cpu.address("abs", 0x015Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC0E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x15Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DC11;
L_82DC11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC11u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC11u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC11 BNE -> $82DC1A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82DC1A; }
    goto L_82DC13;
L_82DC13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC13u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC13u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC13 SEP
    cpu.sep(0x20u);
    goto L_82DC15;
L_82DC15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC15u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC15u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC15 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_82DC17;
L_82DC17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC17u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC17u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC17 REP
    cpu.rep(0x20u);
    goto L_82DC19;
L_82DC19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC19u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC19u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82DC19 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82DC19u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82DC19u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82DC1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Au, 5u, 3u, cpu.address("abs", 0x013Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC1A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DC1D;
L_82DC1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC1D BEQ -> $82DC23
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82DC23; }
    goto L_82DC1F;
L_82DC1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Fu,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Fu, 8u, 3u, cpu.address("abs", 0x013Du), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC1F DEC
    cpu.decMem(hw, cpu.address("abs", 0x13Du), cpu.m8?8:16);
    goto L_82DC22;
L_82DC22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC22u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC22u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82DC22 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82DC22u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82DC22u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82DC23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC23u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC23u, 5u, 3u, cpu.address("abs", 0x017Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC23 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x17Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DC26;
L_82DC26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC26u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC26u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC26 CMP
    cpu.compareA(0x3u);
    goto L_82DC29;
L_82DC29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC29u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC29u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC29 BCS -> $82DC38
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82DC38; }
    goto L_82DC2B;
L_82DC2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC2B LDA
    cpu.setA(0xAu, 16);
    goto L_82DC2E;
L_82DC2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Eu, 5u, 3u, cpu.address("abs", 0x013Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC2E STA
    hw.write(cpu.address("abs", 0x13Du), cpu.a, cpu.m8?8:16);
    goto L_82DC31;
L_82DC31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC31u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC31u, 8u, 3u, cpu.address("abs", 0x017Fu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC31 INC
    cpu.incMem(hw, cpu.address("abs", 0x17Fu), cpu.m8?8:16);
    goto L_82DC34;
L_82DC34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC34u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC34u, 6u, 3u, cpu.address("abs", 0xDE5Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82DC34 JSR -> $82DE5F stack real
    { cpu.push16Value(hw,0xDC36u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDC37u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xDE5Fu), 0x82DC34u); }
    goto L_82DC37;
L_82DC37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC37u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC37u,0x82DC37u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC37u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC37u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82DC37 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82DC37u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82DC37u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82DC38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC38u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC38u, 5u, 3u, cpu.address("abs", 0x013Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC38 STZ
    hw.write(cpu.address("abs", 0x13Du), 0, cpu.m8?8:16);
    goto L_82DC3B;
L_82DC3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC3Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC3Bu, 5u, 3u, cpu.address("abs", 0x015Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC3B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x15Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DC3E;
L_82DC3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC3Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC3Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC3E CMP
    cpu.compareA(0xBu);
    goto L_82DC41;
L_82DC41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC41u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC41u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC41 BCC -> $82DC49
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82DC49; }
    goto L_82DC43;
L_82DC43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC43u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC43u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC43 LDA
    cpu.setA(0xAu, 16);
    goto L_82DC46;
L_82DC46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC46u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC46u, 5u, 3u, cpu.address("abs", 0x015Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC46 STA
    hw.write(cpu.address("abs", 0x15Au), cpu.a, cpu.m8?8:16);
    goto L_82DC49;
L_82DC49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC49u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC49u, 8u, 3u, cpu.address("abs", 0x013Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC49 INC
    cpu.incMem(hw, cpu.address("abs", 0x13Bu), cpu.m8?8:16);
    goto L_82DC4C;
L_82DC4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC4Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC4Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82DC4C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82DC4Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82DC4Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82DC0E_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82DC0Eu: goto L_82DC0E;
    case 0x82DC11u: goto L_82DC11;
    case 0x82DC13u: goto L_82DC13;
    case 0x82DC15u: goto L_82DC15;
    case 0x82DC17u: goto L_82DC17;
    case 0x82DC19u: goto L_82DC19;
    case 0x82DC1Au: goto L_82DC1A;
    case 0x82DC1Du: goto L_82DC1D;
    case 0x82DC1Fu: goto L_82DC1F;
    case 0x82DC22u: goto L_82DC22;
    case 0x82DC23u: goto L_82DC23;
    case 0x82DC26u: goto L_82DC26;
    case 0x82DC29u: goto L_82DC29;
    case 0x82DC2Bu: goto L_82DC2B;
    case 0x82DC2Eu: goto L_82DC2E;
    case 0x82DC31u: goto L_82DC31;
    case 0x82DC34u: goto L_82DC34;
    case 0x82DC37u: goto L_82DC37;
    case 0x82DC38u: goto L_82DC38;
    case 0x82DC3Bu: goto L_82DC3B;
    case 0x82DC3Eu: goto L_82DC3E;
    case 0x82DC41u: goto L_82DC41;
    case 0x82DC43u: goto L_82DC43;
    case 0x82DC46u: goto L_82DC46;
    case 0x82DC49u: goto L_82DC49;
    case 0x82DC4Cu: goto L_82DC4C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82DC0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC0Eu, 5u, 3u, cpu.address("abs", 0x015Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC0E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x15Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DC11;
L_82DC11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC11u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC11u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC11 BNE -> $82DC1A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82DC1A; }
    goto L_82DC13;
L_82DC13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC13u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC13u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC13 SEP
    cpu.sep(0x20u);
    goto L_82DC15;
L_82DC15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC15u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC15u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC15 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_82DC17;
L_82DC17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC17u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC17u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC17 REP
    cpu.rep(0x20u);
    goto L_82DC19;
L_82DC19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC19u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC19u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82DC19 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82DC19u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82DC19u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82DC1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Au, 5u, 3u, cpu.address("abs", 0x013Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC1A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DC1D;
L_82DC1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC1D BEQ -> $82DC23
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82DC23; }
    goto L_82DC1F;
L_82DC1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Fu,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC1Fu, 8u, 3u, cpu.address("abs", 0x013Du), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC1F DEC
    cpu.decMem(hw, cpu.address("abs", 0x13Du), cpu.m8?8:16);
    goto L_82DC22;
L_82DC22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC22u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC22u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82DC22 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82DC22u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82DC22u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82DC23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC23u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC23u, 5u, 3u, cpu.address("abs", 0x017Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC23 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x17Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DC26;
L_82DC26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC26u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC26u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC26 CMP
    cpu.compareA(0x3u);
    goto L_82DC29;
L_82DC29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC29u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC29u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC29 BCS -> $82DC38
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82DC38; }
    goto L_82DC2B;
L_82DC2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC2B LDA
    cpu.setA(0xAu, 16);
    goto L_82DC2E;
L_82DC2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC2Eu, 5u, 3u, cpu.address("abs", 0x013Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC2E STA
    hw.write(cpu.address("abs", 0x13Du), cpu.a, cpu.m8?8:16);
    goto L_82DC31;
L_82DC31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC31u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC31u, 8u, 3u, cpu.address("abs", 0x017Fu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC31 INC
    cpu.incMem(hw, cpu.address("abs", 0x17Fu), cpu.m8?8:16);
    goto L_82DC34;
L_82DC34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC34u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC34u, 6u, 3u, cpu.address("abs", 0xDE5Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82DC34 JSR -> $82DE5F stack real
    { cpu.push16Value(hw,0xDC36u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDC37u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xDE5Fu), 0x82DC34u); }
    goto L_82DC37;
L_82DC37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC37u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDC37u,0x82DC37u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC37u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC37u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82DC37 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82DC37u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82DC37u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82DC38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC38u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC38u, 5u, 3u, cpu.address("abs", 0x013Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC38 STZ
    hw.write(cpu.address("abs", 0x13Du), 0, cpu.m8?8:16);
    goto L_82DC3B;
L_82DC3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC3Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC3Bu, 5u, 3u, cpu.address("abs", 0x015Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC3B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x15Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DC3E;
L_82DC3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC3Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC3Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC3E CMP
    cpu.compareA(0xBu);
    goto L_82DC41;
L_82DC41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC41u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC41u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC41 BCC -> $82DC49
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82DC49; }
    goto L_82DC43;
L_82DC43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC43u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC43u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC43 LDA
    cpu.setA(0xAu, 16);
    goto L_82DC46;
L_82DC46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC46u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC46u, 5u, 3u, cpu.address("abs", 0x015Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC46 STA
    hw.write(cpu.address("abs", 0x15Au), cpu.a, cpu.m8?8:16);
    goto L_82DC49;
L_82DC49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC49u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC49u, 8u, 3u, cpu.address("abs", 0x013Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DC49 INC
    cpu.incMem(hw, cpu.address("abs", 0x13Bu), cpu.m8?8:16);
    goto L_82DC4C;
L_82DC4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDC4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDC4Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDC4Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82DC4C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82DC4Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82DC4Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84802F_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84802Fu: goto L_84802F;
    case 0x848032u: goto L_848032;
    case 0x848035u: goto L_848035;
    case 0x848039u: goto L_848039;
    case 0x84803Bu: goto L_84803B;
    case 0x84803Eu: goto L_84803E;
    case 0x848041u: goto L_848041;
    case 0x848043u: goto L_848043;
    case 0x848044u: goto L_848044;
    case 0x848045u: goto L_848045;
    case 0x848047u: goto L_848047;
    case 0x848049u: goto L_848049;
    case 0x84804Du: goto L_84804D;
    case 0x84804Fu: goto L_84804F;
    case 0x848050u: goto L_848050;
    case 0x848053u: goto L_848053;
    case 0x848056u: goto L_848056;
    case 0x848059u: goto L_848059;
    case 0x84805Au: goto L_84805A;
    case 0x84805Bu: goto L_84805B;
    case 0x84805Cu: goto L_84805C;
    case 0x84805Fu: goto L_84805F;
    case 0x848060u: goto L_848060;
    case 0x848061u: goto L_848061;
    case 0x848063u: goto L_848063;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84802F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x802Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x802Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x802Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84802F LDX
    cpu.setX(0x4u, 16);
    goto L_848032;
L_848032:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8032u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8032u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8032u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848032 LDY
    cpu.setY(0x0u, 16);
    goto L_848035;
L_848035:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8035u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8035u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8035u, 8u, 4u, 0x8096A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848035 JSL -> $8096A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8038u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8039u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8096A3u, 0x848035u); }
    goto L_848039;
L_848039:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8039u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8039u,0x848039u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8039u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8039u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x51u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848039 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x51u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84803B;
L_84803B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x803Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x803Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x803Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84803B AND
    cpu.logicAnd(0xFu);
    goto L_84803E;
L_84803E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x803Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x803Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x803Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84803E CMP
    cpu.compareA(0xAu);
    goto L_848041;
L_848041:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8041u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8041u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8041u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848041 BCS -> $848035
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_848035; }
    goto L_848043;
L_848043:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8043u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8043u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8043u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848043 ASL
    cpu.aslA();
    goto L_848044;
L_848044:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8044u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8044u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8044u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848044 TAY
    cpu.transfer("TAY");
    goto L_848045;
L_848045:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8045u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8045u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8045u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $848045 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848047;
L_848047:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8047u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8047u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8047u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848047 BNE -> $848035
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848035; }
    goto L_848049;
L_848049:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8049u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8049u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8049u, 6u, 4u, ((0x848064u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848049 LDA
    cpu.loadA(hw.readW(((0x848064u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84804D;
L_84804D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x804Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x804Du,cpu,0x97u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x804Du, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $84804D STA
    hw.write(cpu.addressDpLongY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84804F;
L_84804F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x804Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x804Fu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x804Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84804F TYA
    cpu.transfer("TYA");
    goto L_848050;
L_848050:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8050u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8050u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8050u, 6u, 3u, cpu.address("absx", 0x03AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848050 STA
    hw.write(cpu.address("absx", 0x3AAu), cpu.a, cpu.m8?8:16);
    goto L_848053;
L_848053:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8053u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8053u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8053u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848053 LDA
    cpu.setA(0xCCu, 16);
    goto L_848056;
L_848056:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8056u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8056u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8056u, 6u, 3u, cpu.address("absx", 0x03B6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848056 STA
    hw.write(cpu.address("absx", 0x3B6u), cpu.a, cpu.m8?8:16);
    goto L_848059;
L_848059:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8059u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8059u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8059u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848059 TYA
    cpu.transfer("TYA");
    goto L_84805A;
L_84805A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x805Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x805Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x805Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84805A ASL
    cpu.aslA();
    goto L_84805B;
L_84805B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x805Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x805Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x805Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84805B ASL
    cpu.aslA();
    goto L_84805C;
L_84805C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x805Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x805Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x805Cu, 6u, 3u, cpu.address("absx", 0x03B0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84805C STA
    hw.write(cpu.address("absx", 0x3B0u), cpu.a, cpu.m8?8:16);
    goto L_84805F;
L_84805F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x805Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x805Fu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x805Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84805F DEX
    cpu.decReg('X');
    goto L_848060;
L_848060:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8060u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8060u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8060u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848060 DEX
    cpu.decReg('X');
    goto L_848061;
L_848061:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8061u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8061u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8061u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848061 BPL -> $848035
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_848035; }
    goto L_848063;
L_848063:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8063u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8063u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8063u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848063 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848063u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848063u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_848467_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848467u: goto L_848467;
    case 0x84846Au: goto L_84846A;
    case 0x84846Du: goto L_84846D;
    case 0x848470u: goto L_848470;
    case 0x848473u: goto L_848473;
    case 0x848476u: goto L_848476;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848467:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8467u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8467u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8467u, 6u, 3u, cpu.address("abs", 0xB855u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848467 JSR -> $84B855 stack real
    { cpu.push16Value(hw,0x8469u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x846Au,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB855u), 0x848467u); }
    goto L_84846A;
L_84846A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x846Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x846Au,0x84846Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Au, 5u, 3u, cpu.address("abs", 0x0629u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84846A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84846D;
L_84846D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x846Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Du, 6u, 3u, cpu.address("abs", 0xBCE0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84846D JSR -> $84BCE0 stack real
    { cpu.push16Value(hw,0x846Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8470u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBCE0u), 0x84846Du); }
    goto L_848470;
L_848470:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8470u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8470u,0x848470u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8470u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8470u, 6u, 3u, cpu.address("abs", 0xBC7Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848470 JSR -> $84BC7A stack real
    { cpu.push16Value(hw,0x8472u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8473u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBC7Au), 0x848470u); }
    goto L_848473;
L_848473:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8473u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8473u,0x848473u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8473u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8473u, 6u, 3u, cpu.address("abs", 0xBBF7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848473 JSR -> $84BBF7 stack real
    { cpu.push16Value(hw,0x8475u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8476u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBBF7u), 0x848473u); }
    goto L_848476;
L_848476:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8476u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8476u,0x848476u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8476u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8476u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848476 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x848476u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848476u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_848467_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848467u: goto L_848467;
    case 0x84846Au: goto L_84846A;
    case 0x84846Du: goto L_84846D;
    case 0x848470u: goto L_848470;
    case 0x848473u: goto L_848473;
    case 0x848476u: goto L_848476;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848467:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8467u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8467u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8467u, 6u, 3u, cpu.address("abs", 0xB855u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848467 JSR -> $84B855 stack real
    { cpu.push16Value(hw,0x8469u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x846Au,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB855u), 0x848467u); }
    goto L_84846A;
L_84846A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x846Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x846Au,0x84846Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Au, 5u, 3u, cpu.address("abs", 0x0629u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84846A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84846D;
L_84846D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x846Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Du, 6u, 3u, cpu.address("abs", 0xBCE0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84846D JSR -> $84BCE0 stack real
    { cpu.push16Value(hw,0x846Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8470u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBCE0u), 0x84846Du); }
    goto L_848470;
L_848470:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8470u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8470u,0x848470u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8470u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8470u, 6u, 3u, cpu.address("abs", 0xBC7Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848470 JSR -> $84BC7A stack real
    { cpu.push16Value(hw,0x8472u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8473u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBC7Au), 0x848470u); }
    goto L_848473;
L_848473:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8473u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8473u,0x848473u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8473u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8473u, 6u, 3u, cpu.address("abs", 0xBBF7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848473 JSR -> $84BBF7 stack real
    { cpu.push16Value(hw,0x8475u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8476u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBBF7u), 0x848473u); }
    goto L_848476;
L_848476:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8476u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8476u,0x848476u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8476u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8476u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848476 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x848476u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848476u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_84934B_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84934Bu: goto L_84934B;
    case 0x84934Du: goto L_84934D;
    case 0x849350u: goto L_849350;
    case 0x849353u: goto L_849353;
    case 0x849356u: goto L_849356;
    case 0x849358u: goto L_849358;
    case 0x84935Bu: goto L_84935B;
    case 0x84935Du: goto L_84935D;
    case 0x849360u: goto L_849360;
    case 0x849362u: goto L_849362;
    case 0x849366u: goto L_849366;
    case 0x849369u: goto L_849369;
    case 0x84936Cu: goto L_84936C;
    case 0x84936Fu: goto L_84936F;
    case 0x849371u: goto L_849371;
    case 0x849374u: goto L_849374;
    case 0x849376u: goto L_849376;
    case 0x849379u: goto L_849379;
    case 0x84937Bu: goto L_84937B;
    case 0x84937Fu: goto L_84937F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84934B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x934Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x934Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x934Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84934B REP
    cpu.rep(0x20u);
    goto L_84934D;
L_84934D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x934Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x934Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x934Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84934D LDX
    cpu.setX(0x2u, 16);
    goto L_849350;
L_849350:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9350u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9350u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9350u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849350 LDY
    cpu.setY(0x4u, 16);
    goto L_849353;
L_849353:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9353u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9353u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9353u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849353 LDA
    cpu.setA(0x2A9Cu, 16);
    goto L_849356;
L_849356:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9356u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9356u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9356u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849356 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_849358;
L_849358:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9358u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9358u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9358u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849358 LDA
    cpu.setA(0x7Eu, 16);
    goto L_84935B;
L_84935B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x935Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x935Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x935Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84935B STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_84935D;
L_84935D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x935Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x935Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x935Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84935D LDA
    cpu.setA(0x1000u, 16);
    goto L_849360;
L_849360:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9360u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9360u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9360u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849360 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_849362;
L_849362:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9362u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9362u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9362u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849362 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9365u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9366u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x849362u); }
    goto L_849366;
L_849366:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9366u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9366u,0x849366u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9366u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9366u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849366 LDX
    cpu.setX(0x2u, 16);
    goto L_849369;
L_849369:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9369u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9369u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9369u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849369 LDY
    cpu.setY(0x6u, 16);
    goto L_84936C;
L_84936C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x936Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x936Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x936Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84936C LDA
    cpu.setA(0x2AAAu, 16);
    goto L_84936F;
L_84936F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x936Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x936Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x936Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84936F STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_849371;
L_849371:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9371u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9371u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9371u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849371 LDA
    cpu.setA(0x7Eu, 16);
    goto L_849374;
L_849374:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9374u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9374u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9374u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849374 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_849376;
L_849376:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9376u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9376u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9376u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849376 LDA
    cpu.setA(0x1000u, 16);
    goto L_849379;
L_849379:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9379u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9379u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9379u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849379 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_84937B;
L_84937B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x937Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x937Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x937Bu, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84937B JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x937Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x937Fu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x84937Bu); }
    goto L_84937F;
L_84937F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x937Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x937Fu,0x84937Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x937Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x937Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84937F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84937Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84937Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_849CC8_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849CC8u: goto L_849CC8;
    case 0x849CCAu: goto L_849CCA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849CC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CC8 REP
    cpu.rep(0x20u);
    goto L_849CCA;
L_849CCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCAu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849CCA RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849CCAu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849CCAu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_849CC8_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849CC8u: goto L_849CC8;
    case 0x849CCAu: goto L_849CCA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849CC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CC8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CC8 REP
    cpu.rep(0x20u);
    goto L_849CCA;
L_849CCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCAu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CCAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849CCA RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849CCAu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849CCAu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84B5C1_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84B5C1u: goto L_84B5C1;
    case 0x84B5C3u: goto L_84B5C3;
    case 0x84B5C6u: goto L_84B5C6;
    case 0x84B5C8u: goto L_84B5C8;
    case 0x84B5CBu: goto L_84B5CB;
    case 0x84B5CDu: goto L_84B5CD;
    case 0x84B5CFu: goto L_84B5CF;
    case 0x84B5D2u: goto L_84B5D2;
    case 0x84B5D5u: goto L_84B5D5;
    case 0x84B5D7u: goto L_84B5D7;
    case 0x84B5D9u: goto L_84B5D9;
    case 0x84B5DBu: goto L_84B5DB;
    case 0x84B5DEu: goto L_84B5DE;
    case 0x84B5E0u: goto L_84B5E0;
    case 0x84B5E2u: goto L_84B5E2;
    case 0x84B5E5u: goto L_84B5E5;
    case 0x84B5E7u: goto L_84B5E7;
    case 0x84B5EAu: goto L_84B5EA;
    case 0x84B5ECu: goto L_84B5EC;
    case 0x84B5EEu: goto L_84B5EE;
    case 0x84B5F2u: goto L_84B5F2;
    case 0x84B5F4u: goto L_84B5F4;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84B5C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5C1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B5C3;
L_84B5C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C3u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5C3 BIT
    cpu.bit(0x200u, true);
    goto L_84B5C6;
L_84B5C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5C6 BNE -> $84B5E0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84B5E0; }
    goto L_84B5C8;
L_84B5C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C8u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5C8 BIT
    cpu.bit(0x100u, true);
    goto L_84B5CB;
L_84B5CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5CB BEQ -> $84B5F2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_84B5F2; }
    goto L_84B5CD;
L_84B5CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CDu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5CD SEP
    cpu.sep(0x20u);
    goto L_84B5CF;
L_84B5CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CFu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CFu, 6u, 3u, cpu.address("abs", 0x062Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5CF INC
    cpu.incMem(hw, cpu.address("abs", 0x62Du), cpu.m8?8:16);
    goto L_84B5D2;
L_84B5D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D2u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D2u, 4u, 3u, cpu.address("abs", 0x062Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5D2 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B5D5;
L_84B5D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D5u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5D5 CMP
    cpu.compareA(0x3u);
    goto L_84B5D7;
L_84B5D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D7u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5D7 BCC -> $84B5EC
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_84B5EC; }
    goto L_84B5D9;
L_84B5D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5D9 LDA
    cpu.setA(0x2u, 8);
    goto L_84B5DB;
L_84B5DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DBu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DBu, 4u, 3u, cpu.address("abs", 0x062Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5DB STA
    hw.write(cpu.address("abs", 0x62Du), cpu.a, cpu.m8?8:16);
    goto L_84B5DE;
L_84B5DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5DE BRA -> $84B5F2
    goto L_84B5F2;
L_84B5E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E0u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5E0 SEP
    cpu.sep(0x20u);
    goto L_84B5E2;
L_84B5E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E2u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E2u, 6u, 3u, cpu.address("abs", 0x062Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5E2 DEC
    cpu.decMem(hw, cpu.address("abs", 0x62Du), cpu.m8?8:16);
    goto L_84B5E5;
L_84B5E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E5u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5E5 BPL -> $84B5EC
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_84B5EC; }
    goto L_84B5E7;
L_84B5E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E7u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E7u, 4u, 3u, cpu.address("abs", 0x062Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5E7 STZ
    hw.write(cpu.address("abs", 0x62Du), 0, cpu.m8?8:16);
    goto L_84B5EA;
L_84B5EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EAu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5EA BRA -> $84B5F2
    goto L_84B5F2;
L_84B5EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5ECu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5ECu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5ECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5EC LDA
    cpu.setA(0x6u, 8);
    goto L_84B5EE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5ECu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5ECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5EC LDA
    cpu.setA(0x6u, 8);
    goto L_84B5EE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB5ECu,0x84B5ECu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84B5EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5EEu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EEu, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B5EE JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB5F1u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB5F2u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x84B5EEu); }
    goto L_84B5F2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EEu, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B5EE JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB5F1u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB5F2u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x84B5EEu); }
    goto L_84B5F2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB5EEu,0x84B5EEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84B5F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5F2u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F2u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5F2 REP
    cpu.rep(0x20u);
    goto L_84B5F4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F2u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5F2 REP
    cpu.rep(0x20u);
    goto L_84B5F4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F2u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5F2 REP
    cpu.rep(0x20u);
    goto L_84B5F4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB5F2u,0x84B5F2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84B5F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5F4u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F4u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B5F4 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84B5F4u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84B5F4u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F4u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B5F4 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84B5F4u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84B5F4u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB5F4u,0x84B5F4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_84B5C1_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84B5C1u: goto L_84B5C1;
    case 0x84B5C3u: goto L_84B5C3;
    case 0x84B5C6u: goto L_84B5C6;
    case 0x84B5C8u: goto L_84B5C8;
    case 0x84B5CBu: goto L_84B5CB;
    case 0x84B5CDu: goto L_84B5CD;
    case 0x84B5CFu: goto L_84B5CF;
    case 0x84B5D2u: goto L_84B5D2;
    case 0x84B5D5u: goto L_84B5D5;
    case 0x84B5D7u: goto L_84B5D7;
    case 0x84B5D9u: goto L_84B5D9;
    case 0x84B5DBu: goto L_84B5DB;
    case 0x84B5DEu: goto L_84B5DE;
    case 0x84B5E0u: goto L_84B5E0;
    case 0x84B5E2u: goto L_84B5E2;
    case 0x84B5E5u: goto L_84B5E5;
    case 0x84B5E7u: goto L_84B5E7;
    case 0x84B5EAu: goto L_84B5EA;
    case 0x84B5ECu: goto L_84B5EC;
    case 0x84B5EEu: goto L_84B5EE;
    case 0x84B5F2u: goto L_84B5F2;
    case 0x84B5F4u: goto L_84B5F4;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84B5C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5C1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B5C3;
L_84B5C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C3u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5C3 BIT
    cpu.bit(0x200u, true);
    goto L_84B5C6;
L_84B5C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5C6 BNE -> $84B5E0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84B5E0; }
    goto L_84B5C8;
L_84B5C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C8u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5C8 BIT
    cpu.bit(0x100u, true);
    goto L_84B5CB;
L_84B5CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5CB BEQ -> $84B5F2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_84B5F2; }
    goto L_84B5CD;
L_84B5CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CDu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5CD SEP
    cpu.sep(0x20u);
    goto L_84B5CF;
L_84B5CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CFu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CFu, 6u, 3u, cpu.address("abs", 0x062Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5CF INC
    cpu.incMem(hw, cpu.address("abs", 0x62Du), cpu.m8?8:16);
    goto L_84B5D2;
L_84B5D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D2u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D2u, 4u, 3u, cpu.address("abs", 0x062Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5D2 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B5D5;
L_84B5D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D5u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5D5 CMP
    cpu.compareA(0x3u);
    goto L_84B5D7;
L_84B5D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D7u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5D7 BCC -> $84B5EC
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_84B5EC; }
    goto L_84B5D9;
L_84B5D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5D9 LDA
    cpu.setA(0x2u, 8);
    goto L_84B5DB;
L_84B5DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DBu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DBu, 4u, 3u, cpu.address("abs", 0x062Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5DB STA
    hw.write(cpu.address("abs", 0x62Du), cpu.a, cpu.m8?8:16);
    goto L_84B5DE;
L_84B5DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5DE BRA -> $84B5F2
    goto L_84B5F2;
L_84B5E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E0u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5E0 SEP
    cpu.sep(0x20u);
    goto L_84B5E2;
L_84B5E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E2u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E2u, 6u, 3u, cpu.address("abs", 0x062Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5E2 DEC
    cpu.decMem(hw, cpu.address("abs", 0x62Du), cpu.m8?8:16);
    goto L_84B5E5;
L_84B5E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E5u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5E5 BPL -> $84B5EC
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_84B5EC; }
    goto L_84B5E7;
L_84B5E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E7u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E7u, 4u, 3u, cpu.address("abs", 0x062Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5E7 STZ
    hw.write(cpu.address("abs", 0x62Du), 0, cpu.m8?8:16);
    goto L_84B5EA;
L_84B5EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EAu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5EA BRA -> $84B5F2
    goto L_84B5F2;
L_84B5EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5ECu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5ECu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5ECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5EC LDA
    cpu.setA(0x6u, 8);
    goto L_84B5EE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5ECu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5ECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5EC LDA
    cpu.setA(0x6u, 8);
    goto L_84B5EE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB5ECu,0x84B5ECu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84B5EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5EEu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EEu, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B5EE JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB5F1u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB5F2u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x84B5EEu); }
    goto L_84B5F2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EEu, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B5EE JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB5F1u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB5F2u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x84B5EEu); }
    goto L_84B5F2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB5EEu,0x84B5EEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84B5F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5F2u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F2u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5F2 REP
    cpu.rep(0x20u);
    goto L_84B5F4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F2u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5F2 REP
    cpu.rep(0x20u);
    goto L_84B5F4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F2u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B5F2 REP
    cpu.rep(0x20u);
    goto L_84B5F4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB5F2u,0x84B5F2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84B5F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5F4u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F4u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B5F4 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84B5F4u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84B5F4u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F4u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B5F4 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84B5F4u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84B5F4u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB5F4u,0x84B5F4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_84BFB3_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84BFB3u: goto L_84BFB3;
    case 0x84BFB6u: goto L_84BFB6;
    case 0x84BFB8u: goto L_84BFB8;
    case 0x84BFBAu: goto L_84BFBA;
    case 0x84BFBCu: goto L_84BFBC;
    case 0x84BFC0u: goto L_84BFC0;
    case 0x84BFC3u: goto L_84BFC3;
    case 0x84BFC6u: goto L_84BFC6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84BFB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFB3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFB3u, 5u, 3u, cpu.address("abs", 0x012Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BFB3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x12Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BFB6;
L_84BFB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFB6u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFB6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BFB6 BPL -> $84BFBC
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_84BFBC; }
    goto L_84BFB8;
L_84BFB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFB8u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFB8u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BFB8 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_84BFBA;
L_84BFBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFBAu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFBAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BFBA BRA -> $84BFC0
    goto L_84BFC0;
L_84BFBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFBCu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFBCu, 8u, 4u, 0x80A880u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84BFBC JSL -> $80A880 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBFBFu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBFC0u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A880u, 0x84BFBCu); }
    goto L_84BFC0;
L_84BFC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFC0u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC0u, 6u, 3u, cpu.address("abs", 0xC228u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84BFC0 JSR -> $84C228 stack real
    { cpu.push16Value(hw,0xBFC2u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBFC3u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC228u), 0x84BFC0u); }
    goto L_84BFC3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC0u, 6u, 3u, cpu.address("abs", 0xC228u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84BFC0 JSR -> $84C228 stack real
    { cpu.push16Value(hw,0xBFC2u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBFC3u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC228u), 0x84BFC0u); }
    goto L_84BFC3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBFC0u,0x84BFC0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BFC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFC3u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC3u, 6u, 3u, cpu.address("abs", 0xC25Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84BFC3 JSR -> $84C25B stack real
    { cpu.push16Value(hw,0xBFC5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBFC6u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC25Bu), 0x84BFC3u); }
    goto L_84BFC6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC3u, 6u, 3u, cpu.address("abs", 0xC25Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84BFC3 JSR -> $84C25B stack real
    { cpu.push16Value(hw,0xBFC5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBFC6u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC25Bu), 0x84BFC3u); }
    goto L_84BFC6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBFC3u,0x84BFC3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BFC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBFC6u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84BFC6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84BFC6u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84BFC6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBFC6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84BFC6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84BFC6u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84BFC6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBFC6u,0x84BFC6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_FDFFA1_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xFD000Cu: goto L_FD000C;
    case 0xFDFF91u: goto L_FDFF91;
    case 0xFDFF95u: goto L_FDFF95;
    case 0xFDFF97u: goto L_FDFF97;
    case 0xFDFF9Bu: goto L_FDFF9B;
    case 0xFDFF9Fu: goto L_FDFF9F;
    case 0xFDFFA1u: goto L_FDFFA1;
    case 0xFDFFA3u: goto L_FDFFA3;
    case 0xFDFFA6u: goto L_FDFFA6;
    case 0xFDFFA8u: goto L_FDFFA8;
    case 0xFDFFAAu: goto L_FDFFAA;
    case 0xFDFFAEu: goto L_FDFFAE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_FD000C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x000Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x000Cu,cpu,0x02u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x000Cu, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $FD000C COP
    hw.partial(0xFD000Cu, "COP"); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x000Cu,cpu,0x02u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x000Cu, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $FD000C COP
    hw.partial(0xFD000Cu, "COP"); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x000Cu,0xFD000Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_FDFF91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF91u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF91u,cpu,0x0Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF91u, 6u, 4u, 0x0E741Eu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $FDFF91 ORA
    cpu.logicOr(hw.readW(0xE741Eu, cpu.m8?8:16));
    goto L_FDFF95;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF91u,cpu,0x0Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF91u, 6u, 4u, 0x0E741Eu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $FDFF91 ORA
    cpu.logicOr(hw.readW(0xE741Eu, cpu.m8?8:16));
    goto L_FDFF95;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFF91u,0xFDFF91u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_FDFF95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF95u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF95u,cpu,0xB2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF95u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x60u) & 0xFFFFu), 2u, 0u);
    // $FDFF95 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirect(hw, 0x60u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_FDFF97;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF95u,cpu,0xB2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF95u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x60u) & 0xFFFFu), 2u, 0u);
    // $FDFF95 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirect(hw, 0x60u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_FDFF97;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFF95u,0xFDFF95u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_FDFF97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF97u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF97u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF97u, 6u, 4u, ((0x419240u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $FDFF97 SBC
    cpu.sbc(hw.readW(((0x419240u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_FDFF9B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF97u,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF97u, 6u, 4u, ((0x419240u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $FDFF97 SBC
    cpu.sbc(hw.readW(((0x419240u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_FDFF9B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFF97u,0xFDFF97u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_FDFF9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF9Bu,cpu,0x2Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF9Bu, 6u, 4u, 0x0FDC70u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $FDFF9B AND
    cpu.logicAnd(hw.readW(0xFDC70u, cpu.m8?8:16));
    goto L_FDFF9F;
L_FDFF9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFF9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFF9Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFF9Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $FDFF9F BEQ -> $FDFFAE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_FDFFAE; }
    goto L_FDFFA1;
L_FDFFA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFFA1u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFFA1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFFA1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $FDFFA1 BEQ -> $FDFF91
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_FDFF91; }
    goto L_FDFFA3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFFA1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFFA1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $FDFFA1 BEQ -> $FDFF91
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_FDFF91; }
    goto L_FDFFA3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFFA1u,0xFDFFA1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_FDFFA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFFA3u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFFA3u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFFA3u, 8u, 3u, cpu.address("abs", 0x60F0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $FDFFA3 INC
    cpu.incMem(hw, cpu.address("abs", 0x60F0u), cpu.m8?8:16);
    goto L_FDFFA6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFFA3u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFFA3u, 8u, 3u, cpu.address("abs", 0x60F0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $FDFFA3 INC
    cpu.incMem(hw, cpu.address("abs", 0x60F0u), cpu.m8?8:16);
    goto L_FDFFA6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFFA3u,0xFDFFA3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_FDFFA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFFA6u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFFA6u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFFA6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $FDFFA6 BCS -> $FD000C
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_FD000C; }
    goto L_FDFFA8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFFA6u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFFA6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $FDFFA6 BCS -> $FD000C
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_FD000C; }
    goto L_FDFFA8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFFA6u,0xFDFFA6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_FDFFA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFFA8u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFFA8u,cpu,0xF2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFFA8u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x44u) & 0xFFFFu), 2u, 0u);
    // $FDFFA8 SBC
    cpu.sbc(hw.readW(cpu.addressDpIndirect(hw, 0x44u), cpu.m8?8:16));
    goto L_FDFFAA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFFA8u,cpu,0xF2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFFA8u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x44u) & 0xFFFFu), 2u, 0u);
    // $FDFFA8 SBC
    cpu.sbc(hw.readW(cpu.addressDpIndirect(hw, 0x44u), cpu.m8?8:16));
    goto L_FDFFAA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFFA8u,0xFDFFA8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_FDFFAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFFAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFFAAu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFFAAu, 6u, 4u, ((0xCAE00Cu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $FDFFAA SBC
    cpu.sbc(hw.readW(((0xCAE00Cu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_FDFFAE;
L_FDFFAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFFAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFFAEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFFAEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $FDFFAE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0xFDFFAEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0xFDFFAEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

