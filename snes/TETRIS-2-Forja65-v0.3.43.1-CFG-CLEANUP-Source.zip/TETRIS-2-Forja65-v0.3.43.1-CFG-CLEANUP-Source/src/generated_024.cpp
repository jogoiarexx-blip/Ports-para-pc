#include "generated.hpp"
void sub_80846C_E0M1X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80846Cu: goto L_80846C;
    case 0x80846Du: goto L_80846D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80846C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x846Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Cu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80846C PLP
    cpu.pop("PLP", hw);
    goto L_80846D;
L_80846D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x846Du))return;
  // 4 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80846D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80846Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80846Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80846D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80846Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80846Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80846D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80846Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80846Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80846D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80846Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80846Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x846Du,0x80846Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80846C_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80846Cu: goto L_80846C;
    case 0x80846Du: goto L_80846D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80846C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x846Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Cu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80846C PLP
    cpu.pop("PLP", hw);
    goto L_80846D;
L_80846D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x846Du))return;
  // 4 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80846D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80846Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80846Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80846D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80846Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80846Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80846D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80846Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80846Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80846D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80846Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80846Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x846Du,0x80846Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80864B_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80864Bu: goto L_80864B;
    case 0x80864Cu: goto L_80864C;
    case 0x80864Eu: goto L_80864E;
    case 0x808651u: goto L_808651;
    case 0x808653u: goto L_808653;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80864B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x864Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x864Bu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x864Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80864B PHP
    cpu.push("PHP", hw);
    goto L_80864C;
L_80864C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x864Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x864Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x864Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80864C SEP
    cpu.sep(0x20u);
    goto L_80864E;
L_80864E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x864Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x864Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x864Eu, 4u, 3u, cpu.address("abs", 0x420Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80864E STZ
    hw.write(cpu.address("abs", 0x420Cu), 0, cpu.m8?8:16);
    goto L_808651;
L_808651:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8651u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8651u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8651u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808651 LDX
    cpu.setX(0x0u, 8);
    goto L_808653;
L_808653:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8653u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8653u,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8653u, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $808653 BRK
    hw.partial(0x808653u, "BRK"); return;
}

void sub_808EF0_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808EF0u: goto L_808EF0;
    case 0x808EF1u: goto L_808EF1;
    case 0x808EF3u: goto L_808EF3;
    case 0x808EF5u: goto L_808EF5;
    case 0x808EF6u: goto L_808EF6;
    case 0x808EF7u: goto L_808EF7;
    case 0x808EF8u: goto L_808EF8;
    case 0x808EFAu: goto L_808EFA;
    case 0x808EFCu: goto L_808EFC;
    case 0x808EFDu: goto L_808EFD;
    case 0x808EFEu: goto L_808EFE;
    case 0x808F00u: goto L_808F00;
    case 0x808F02u: goto L_808F02;
    case 0x808F04u: goto L_808F04;
    case 0x808F07u: goto L_808F07;
    case 0x808F09u: goto L_808F09;
    case 0x808F0Cu: goto L_808F0C;
    case 0x808F0Du: goto L_808F0D;
    case 0x808F0Fu: goto L_808F0F;
    case 0x808F12u: goto L_808F12;
    case 0x808F14u: goto L_808F14;
    case 0x808F16u: goto L_808F16;
    case 0x808F18u: goto L_808F18;
    case 0x808F1Bu: goto L_808F1B;
    case 0x808F1Cu: goto L_808F1C;
    case 0x808F1Du: goto L_808F1D;
    case 0x808F1Eu: goto L_808F1E;
    case 0x808F1Fu: goto L_808F1F;
    case 0x808F21u: goto L_808F21;
    case 0x808F23u: goto L_808F23;
    case 0x808F24u: goto L_808F24;
    case 0x808F25u: goto L_808F25;
    case 0x808F28u: goto L_808F28;
    case 0x808F29u: goto L_808F29;
    case 0x808F2Bu: goto L_808F2B;
    case 0x808F2Du: goto L_808F2D;
    case 0x808F2Eu: goto L_808F2E;
    case 0x808F2Fu: goto L_808F2F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808EF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF0u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF0u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808EF0 PHP
    cpu.push("PHP", hw);
    goto L_808EF1;
L_808EF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF1u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808EF1 REP
    cpu.rep(0x20u);
    goto L_808EF3;
L_808EF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF3u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808EF3 STZ
    hw.write(cpu.address("dp", 0xD3u), 0, cpu.m8?8:16);
    goto L_808EF5;
L_808EF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF5u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF5u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808EF5 PLP
    cpu.pop("PLP", hw);
    goto L_808EF6;
L_808EF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EF6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8EF6u,0x808EF6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF6u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF6u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808EF6 PHP
    cpu.push("PHP", hw);
    goto L_808EF7;
L_808EF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF7u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF7u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808EF7 PHB
    cpu.push("PHB", hw);
    goto L_808EF8;
L_808EF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF8u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808EF8 SEP
    cpu.sep(0x20u);
    goto L_808EFA;
L_808EFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EFAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EFAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xCFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808EFA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808EFC;
L_808EFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EFCu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EFCu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808EFC PHA
    cpu.push("PHA", hw);
    goto L_808EFD;
L_808EFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EFDu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EFDu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808EFD PLB
    cpu.pop("PLB", hw);
    goto L_808EFE;
L_808EFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EFEu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EFEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xCDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808EFE LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xCDu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_808F00;
L_808F00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F00u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F00u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F00 REP
    cpu.rep(0x20u);
    goto L_808F02;
L_808F02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F02u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F02u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F02 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xD2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808F04;
L_808F04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F04u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F04u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F04 AND
    cpu.logicAnd(0x3Fu);
    goto L_808F07;
L_808F07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F07u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F07u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F07 STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_808F09;
L_808F09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F09u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F09u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F09 LDY
    cpu.setY(0x0u, 16);
    goto L_808F0C;
L_808F0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Cu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808F0C PHX
    cpu.push("PHX", hw);
    goto L_808F0D;
L_808F0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD1u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F0D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xD1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808F0F;
L_808F0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F0Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F0F AND
    cpu.logicAnd(0x3Fu);
    goto L_808F12;
L_808F12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F12u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F12u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F12 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_808F14;
L_808F14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F14u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F14u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xC9u) & 0xFFFFu), 3u, 0u);
    // $808F14 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0xC9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808F16;
L_808F16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F16u,cpu,0x45u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F16u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F16 EOR
    cpu.logicXor(hw.readW(cpu.address("dp", 0xD3u), cpu.m8?8:16));
    goto L_808F18;
L_808F18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F18u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F18u, 6u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F18 STA
    hw.write(cpu.address("absx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_808F1B;
L_808F1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Bu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F1B INY
    cpu.inc('Y');
    goto L_808F1C;
L_808F1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Cu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F1C INY
    cpu.inc('Y');
    goto L_808F1D;
L_808F1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Du,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F1D INX
    cpu.inc('X');
    goto L_808F1E;
L_808F1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Eu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F1E INX
    cpu.inc('X');
    goto L_808F1F;
L_808F1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Fu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Fu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F1F DEC
    cpu.decMem(hw, cpu.address("dp", 0x10u), cpu.m8?8:16);
    goto L_808F21;
L_808F21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F21u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F21u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F21 BNE -> $808F14
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_808F14; }
    goto L_808F23;
L_808F23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F23u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F23u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808F23 PLA
    cpu.pop("PLA", hw);
    goto L_808F24;
L_808F24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F24u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F24u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F24 CLC
    cpu.setFlag('C', false);
    goto L_808F25;
L_808F25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F25u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F25u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F25 ADC
    cpu.adc(0x40u);
    goto L_808F28;
L_808F28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F28u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F28u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F28 TAX
    cpu.transfer("TAX");
    goto L_808F29;
L_808F29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F29u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F29u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F29 DEC
    cpu.decMem(hw, cpu.address("dp", 0x12u), cpu.m8?8:16);
    goto L_808F2B;
L_808F2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808F2B BNE -> $808F0C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_808F0C; }
    goto L_808F2D;
L_808F2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Du,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808F2D PLB
    cpu.pop("PLB", hw);
    goto L_808F2E;
L_808F2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Eu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808F2E PLP
    cpu.pop("PLP", hw);
    goto L_808F2F;
L_808F2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F2Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F2Fu,0x808F2Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Fu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F2Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808F2F RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808F2Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808F2Fu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80A8CD_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80A8CDu: goto L_80A8CD;
    case 0x80A8CFu: goto L_80A8CF;
    case 0x80A8D1u: goto L_80A8D1;
    case 0x80A8D3u: goto L_80A8D3;
    case 0x80A8D4u: goto L_80A8D4;
    case 0x80A8D6u: goto L_80A8D6;
    case 0x80A8D9u: goto L_80A8D9;
    case 0x80A8DBu: goto L_80A8DB;
    case 0x80A8DEu: goto L_80A8DE;
    case 0x80A8E0u: goto L_80A8E0;
    case 0x80A8E2u: goto L_80A8E2;
    case 0x80A8E5u: goto L_80A8E5;
    case 0x80A8E7u: goto L_80A8E7;
    case 0x80A8E9u: goto L_80A8E9;
    case 0x80A8ECu: goto L_80A8EC;
    case 0x80A8EEu: goto L_80A8EE;
    case 0x80A8F0u: goto L_80A8F0;
    case 0x80A8F1u: goto L_80A8F1;
    case 0x80A8F2u: goto L_80A8F2;
    case 0x80A8F3u: goto L_80A8F3;
    case 0x80A8F4u: goto L_80A8F4;
    case 0x80A8F5u: goto L_80A8F5;
    case 0x80A8F7u: goto L_80A8F7;
    case 0x80A8F9u: goto L_80A8F9;
    case 0x80A8FBu: goto L_80A8FB;
    case 0x80A8FDu: goto L_80A8FD;
    case 0x80A8FFu: goto L_80A8FF;
    case 0x80A901u: goto L_80A901;
    case 0x80A903u: goto L_80A903;
    case 0x80A905u: goto L_80A905;
    case 0x80A907u: goto L_80A907;
    case 0x80A909u: goto L_80A909;
    case 0x80A90Bu: goto L_80A90B;
    case 0x80A90Du: goto L_80A90D;
    case 0x80A90Fu: goto L_80A90F;
    case 0x80A912u: goto L_80A912;
    case 0x80A914u: goto L_80A914;
    case 0x80A916u: goto L_80A916;
    case 0x80A919u: goto L_80A919;
    case 0x80A91Bu: goto L_80A91B;
    case 0x80A91Du: goto L_80A91D;
    case 0x80A91Fu: goto L_80A91F;
    case 0x80A921u: goto L_80A921;
    case 0x80A923u: goto L_80A923;
    case 0x80A925u: goto L_80A925;
    case 0x80A927u: goto L_80A927;
    case 0x80A929u: goto L_80A929;
    case 0x80A92Bu: goto L_80A92B;
    case 0x80A92Du: goto L_80A92D;
    case 0x80A92Fu: goto L_80A92F;
    case 0x80A931u: goto L_80A931;
    case 0x80A933u: goto L_80A933;
    case 0x80A935u: goto L_80A935;
    case 0x80A937u: goto L_80A937;
    case 0x80A93Au: goto L_80A93A;
    case 0x80A93Cu: goto L_80A93C;
    case 0x80A93Eu: goto L_80A93E;
    case 0x80A941u: goto L_80A941;
    case 0x80A943u: goto L_80A943;
    case 0x80A945u: goto L_80A945;
    case 0x80A946u: goto L_80A946;
    case 0x80A947u: goto L_80A947;
    case 0x80A948u: goto L_80A948;
    case 0x80A94Au: goto L_80A94A;
    case 0x80A94Cu: goto L_80A94C;
    case 0x80A94Eu: goto L_80A94E;
    case 0x80A950u: goto L_80A950;
    case 0x80A952u: goto L_80A952;
    case 0x80A954u: goto L_80A954;
    case 0x80A956u: goto L_80A956;
    case 0x80A958u: goto L_80A958;
    case 0x80A95Bu: goto L_80A95B;
    case 0x80A95Du: goto L_80A95D;
    case 0x80A95Fu: goto L_80A95F;
    case 0x80A961u: goto L_80A961;
    case 0x80A964u: goto L_80A964;
    case 0x80A965u: goto L_80A965;
    case 0x80A966u: goto L_80A966;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80A8CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8CDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8CDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A8CD REP
    cpu.rep(0x20u);
    goto L_80A8CF;
L_80A8CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8CFu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8CFu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A8CF DEC
    cpu.decMem(hw, cpu.address("dp", 0x10u), cpu.m8?8:16);
    goto L_80A8D1;
L_80A8D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D1u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A8D1 BPL -> $80A8D4
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80A8D4; }
    goto L_80A8D3;
L_80A8D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A8D3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80A8D3u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80A8D3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80A8D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D4u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A8D4 STZ
    hw.write(cpu.address("dp", 0x5Fu), 0, cpu.m8?8:16);
    goto L_80A8D6;
L_80A8D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D6u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D6u, 5u + 1u, 3u, cpu.address("absy", 0x1900u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A8D6 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1900u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A8D9;
L_80A8D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8D9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A8D9 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_80A8DB;
L_80A8DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DBu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DBu, 5u + 1u, 3u, cpu.address("absy", 0x1B00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A8DB LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1B00u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A8DE;
L_80A8DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8DEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A8DE STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_80A8E0;
L_80A8E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A8E0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A8E2;
L_80A8E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E2u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A8E2 AND
    cpu.logicAnd(0x3E0u);
    goto L_80A8E5;
L_80A8E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A8E5 STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_80A8E7;
L_80A8E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A8E7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A8E9;
L_80A8E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8E9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A8E9 AND
    cpu.logicAnd(0x3E0u);
    goto L_80A8EC;
L_80A8EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8ECu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8ECu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A8EC STA
    hw.write(cpu.address("dp", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_80A8EE;
L_80A8EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8EEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8EEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A8EE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A8F0;
L_80A8F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A8F0 ASL
    cpu.aslA();
    goto L_80A8F1;
L_80A8F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A8F1 ASL
    cpu.aslA();
    goto L_80A8F2;
L_80A8F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A8F2 ASL
    cpu.aslA();
    goto L_80A8F3;
L_80A8F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F3u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A8F3 ASL
    cpu.aslA();
    goto L_80A8F4;
L_80A8F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F4u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A8F4 ASL
    cpu.aslA();
    goto L_80A8F5;
L_80A8F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F5u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A8F5 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16));
    goto L_80A8F7;
L_80A8F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F7u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A8F7 BCC -> $80A909
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80A909; }
    goto L_80A8F9;
L_80A8F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8F9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A8F9 STA
    hw.write(cpu.address("dp", 0x63u), cpu.a, cpu.m8?8:16);
    goto L_80A8FB;
L_80A8FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A8FB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A8FD;
L_80A8FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FDu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A8FD CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x63u), cpu.m8?8:16));
    goto L_80A8FF;
L_80A8FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA8FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FFu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA8FFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A8FF BCC -> $80A909
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80A909; }
    goto L_80A901;
L_80A901:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA901u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA901u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA901u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A901 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A903;
L_80A903:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA903u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA903u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA903u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A903 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x63u), cpu.m8?8:16));
    goto L_80A905;
L_80A905:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA905u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA905u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA905u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A905 STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_80A907;
L_80A907:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA907u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA907u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA907u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A907 BRA -> $80A90D
    goto L_80A90D;
L_80A909:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA909u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA909u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA909u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A909 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A90B;
L_80A90B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA90Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A90B STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_80A90D;
L_80A90D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA90Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A90D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A90F;
L_80A90F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA90Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA90Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A90F AND
    cpu.logicAnd(0x1Fu);
    goto L_80A912;
L_80A912:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA912u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA912u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA912u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A912 STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_80A914;
L_80A914:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA914u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA914u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA914u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A914 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A916;
L_80A916:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA916u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA916u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA916u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A916 AND
    cpu.logicAnd(0x1Fu);
    goto L_80A919;
L_80A919:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA919u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA919u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA919u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A919 STA
    hw.write(cpu.address("dp", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_80A91B;
L_80A91B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA91Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A91B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A91D;
L_80A91D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA91Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Du,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A91D CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16));
    goto L_80A91F;
L_80A91F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA91Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Fu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA91Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A91F BCC -> $80A92F
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80A92F; }
    goto L_80A921;
L_80A921:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA921u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA921u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA921u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A921 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A923;
L_80A923:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA923u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA923u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA923u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A923 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16));
    goto L_80A925;
L_80A925:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA925u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA925u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA925u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A925 BCC -> $80A92F
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80A92F; }
    goto L_80A927;
L_80A927:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA927u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA927u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA927u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A927 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A929;
L_80A929:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA929u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA929u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA929u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A929 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16));
    goto L_80A92B;
L_80A92B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA92Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA92Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA92Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A92B STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_80A92D;
L_80A92D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA92Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA92Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA92Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A92D BRA -> $80A935
    goto L_80A935;
L_80A92F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA92Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA92Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA92Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A92F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A931;
L_80A931:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA931u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA931u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA931u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A931 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16));
    goto L_80A933;
L_80A933:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA933u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA933u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA933u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A933 STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_80A935;
L_80A935:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA935u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA935u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA935u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A935 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A937;
L_80A937:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA937u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA937u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA937u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A937 AND
    cpu.logicAnd(0x7C00u);
    goto L_80A93A;
L_80A93A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA93Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA93Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA93Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A93A STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_80A93C;
L_80A93C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA93Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA93Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA93Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A93C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A93E;
L_80A93E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA93Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA93Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA93Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A93E AND
    cpu.logicAnd(0x7C00u);
    goto L_80A941;
L_80A941:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA941u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA941u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA941u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A941 STA
    hw.write(cpu.address("dp", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_80A943;
L_80A943:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA943u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA943u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA943u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A943 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A945;
L_80A945:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA945u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA945u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA945u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A945 XBA
    cpu.xba();
    goto L_80A946;
L_80A946:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA946u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA946u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA946u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A946 ASL
    cpu.aslA();
    goto L_80A947;
L_80A947:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA947u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA947u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA947u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A947 ASL
    cpu.aslA();
    goto L_80A948;
L_80A948:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA948u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA948u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA948u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A948 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16));
    goto L_80A94A;
L_80A94A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA94Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA94Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA94Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A94A BCC -> $80A95D
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80A95D; }
    goto L_80A94C;
L_80A94C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA94Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA94Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA94Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A94C STA
    hw.write(cpu.address("dp", 0x63u), cpu.a, cpu.m8?8:16);
    goto L_80A94E;
L_80A94E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA94Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA94Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA94Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A94E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A950;
L_80A950:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA950u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA950u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA950u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A950 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x63u), cpu.m8?8:16));
    goto L_80A952;
L_80A952:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA952u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA952u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA952u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A952 BCC -> $80A95D
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80A95D; }
    goto L_80A954;
L_80A954:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA954u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA954u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA954u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A954 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A956;
L_80A956:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA956u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA956u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA956u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A956 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x63u), cpu.m8?8:16));
    goto L_80A958;
L_80A958:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA958u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA958u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA958u, 6u, 3u, cpu.address("absy", 0x1900u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A958 STA
    hw.write(cpu.address("absy", 0x1900u), cpu.a, cpu.m8?8:16);
    goto L_80A95B;
L_80A95B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA95Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A95B BRA -> $80A964
    goto L_80A964;
L_80A95D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA95Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A95D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A95F;
L_80A95F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA95Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Fu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA95Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A95F ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16));
    goto L_80A961;
L_80A961:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA961u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA961u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA961u, 6u, 3u, cpu.address("absy", 0x1900u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A961 STA
    hw.write(cpu.address("absy", 0x1900u), cpu.a, cpu.m8?8:16);
    goto L_80A964;
L_80A964:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA964u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA964u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA964u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A964 INY
    cpu.inc('Y');
    goto L_80A965;
L_80A965:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA965u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA965u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA965u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A965 INY
    cpu.inc('Y');
    goto L_80A966;
L_80A966:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA966u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA966u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA966u, 3u, 3u, cpu.address("abs", 0xA8CFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A966 JMP -> $80A8CF
    goto L_80A8CF;
}

void sub_80AE9E_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AE9Eu: goto L_80AE9E;
    case 0x80AEA1u: goto L_80AEA1;
    case 0x80AEA3u: goto L_80AEA3;
    case 0x80AEA6u: goto L_80AEA6;
    case 0x80AEA9u: goto L_80AEA9;
    case 0x80AEABu: goto L_80AEAB;
    case 0x80AEAEu: goto L_80AEAE;
    case 0x80AEB1u: goto L_80AEB1;
    case 0x80AEB4u: goto L_80AEB4;
    case 0x80AEB7u: goto L_80AEB7;
    case 0x80AEBAu: goto L_80AEBA;
    case 0x80AEBDu: goto L_80AEBD;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AE9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE9Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE9Eu, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE9E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AEA1;
L_80AEA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEA1 BEQ -> $80AEB7
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AEB7; }
    goto L_80AEA3;
L_80AEA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA3u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEA3 LDX
    cpu.setX(0x328u, 16);
    goto L_80AEA6;
L_80AEA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEA6 LDA
    cpu.setA(0x3u, 16);
    goto L_80AEA9;
L_80AEA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEA9 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80AEAB;
L_80AEAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEABu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEABu, 5u, 3u, cpu.address("abs", 0x0914u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEAB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x914u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AEAE;
L_80AEAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEAEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEAEu, 5u, 3u, cpu.address("abs", 0x097Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEAE STA
    hw.write(cpu.address("abs", 0x97Au), cpu.a, cpu.m8?8:16);
    goto L_80AEB1;
L_80AEB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB1u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB1u, 8u, 3u, cpu.address("abs", 0x0986u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEB1 INC
    cpu.incMem(hw, cpu.address("abs", 0x986u), cpu.m8?8:16);
    goto L_80AEB4;
L_80AEB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB4u, 6u, 3u, cpu.address("abs", 0xC85Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AEB4 JSR -> $80C85C stack real
    { cpu.push16Value(hw,0xAEB6u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAEB7u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC85Cu), 0x80AEB4u); }
    goto L_80AEB7;
L_80AEB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEB7u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB7u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB7u, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEB7 STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80AEBA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB7u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB7u, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEB7 STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80AEBA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB7u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB7u, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEB7 STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80AEBA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAEB7u,0x80AEB7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AEBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEBAu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBAu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBAu, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEBA INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AEBD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBAu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBAu, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEBA INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AEBD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBAu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBAu, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEBA INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AEBD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAEBAu,0x80AEBAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AEBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEBDu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBDu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AEBD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AEBDu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AEBDu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBDu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AEBD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AEBDu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AEBDu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBDu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AEBD RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AEBDu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AEBDu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAEBDu,0x80AEBDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80B0B7_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B0B7u: goto L_80B0B7;
    case 0x80B0BAu: goto L_80B0BA;
    case 0x80B0BCu: goto L_80B0BC;
    case 0x80B0BFu: goto L_80B0BF;
    case 0x80B0C2u: goto L_80B0C2;
    case 0x80B0C4u: goto L_80B0C4;
    case 0x80B0C7u: goto L_80B0C7;
    case 0x80B0CAu: goto L_80B0CA;
    case 0x80B0CDu: goto L_80B0CD;
    case 0x80B0D0u: goto L_80B0D0;
    case 0x80B0D3u: goto L_80B0D3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B0B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0B7u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0B7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B0BA;
L_80B0BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0BA BEQ -> $80B0CD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B0CD; }
    goto L_80B0BC;
L_80B0BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BCu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0BC LDX
    cpu.setX(0x3ACu, 16);
    goto L_80B0BF;
L_80B0BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0BFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0BF LDA
    cpu.setA(0x2u, 16);
    goto L_80B0C2;
L_80B0C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0C2 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80B0C4;
L_80B0C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C4u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C4u, 8u, 3u, cpu.address("abs", 0x0986u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0C4 INC
    cpu.incMem(hw, cpu.address("abs", 0x986u), cpu.m8?8:16);
    goto L_80B0C7;
L_80B0C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0C7u, 6u, 3u, cpu.address("abs", 0xC7F6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B0C7 JSR -> $80C7F6 stack real
    { cpu.push16Value(hw,0xB0C9u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0CAu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC7F6u), 0x80B0C7u); }
    goto L_80B0CA;
L_80B0CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0CAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0CAu,0x80B0CAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0CAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0CAu, 6u, 3u, cpu.address("abs", 0xC404u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B0CA JSR -> $80C404 stack real
    { cpu.push16Value(hw,0xB0CCu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0CDu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC404u), 0x80B0CAu); }
    goto L_80B0CD;
L_80B0CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0CDu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0CDu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0CDu, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0CD STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B0D0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0CDu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0CDu, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0CD STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B0D0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0CDu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0CDu, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0CD STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80B0D0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0CDu,0x80B0CDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B0D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0D0u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D0u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D0u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0D0 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B0D3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D0u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D0u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0D0 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B0D3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D0u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D0u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B0D0 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B0D3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0D0u,0x80B0D0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B0D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0D3u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B0D3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B0D3u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B0D3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B0D3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B0D3u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B0D3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B0D3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B0D3u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B0D3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0D3u,0x80B0D3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80B1B7_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B1B7u: goto L_80B1B7;
    case 0x80B1BAu: goto L_80B1BA;
    case 0x80B1BCu: goto L_80B1BC;
    case 0x80B1BFu: goto L_80B1BF;
    case 0x80B1C2u: goto L_80B1C2;
    case 0x80B1C5u: goto L_80B1C5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B1B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1B7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1B7u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B1B7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B1BA;
L_80B1BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1BAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1BAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B1BA BEQ -> $80B1C2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B1C2; }
    goto L_80B1BC;
L_80B1BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1BCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1BCu, 6u, 3u, cpu.address("abs", 0xCAD7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B1BC JSR -> $80CAD7 stack real
    { cpu.push16Value(hw,0xB1BEu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB1BFu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCAD7u), 0x80B1BCu); }
    goto L_80B1BF;
L_80B1BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1BFu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB1BFu,0x80B1BFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1BFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1BFu, 6u, 3u, cpu.address("abs", 0xBBFAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B1BF JSR -> $80BBFA stack real
    { cpu.push16Value(hw,0xB1C1u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB1C2u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBBFAu), 0x80B1BFu); }
    goto L_80B1C2;
L_80B1C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1C2u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C2u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C2u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B1C2 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B1C5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C2u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C2u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B1C2 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B1C5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C2u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C2u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B1C2 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B1C5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB1C2u,0x80B1C2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B1C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB1C5u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B1C5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B1C5u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B1C5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B1C5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B1C5u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B1C5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB1C5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B1C5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B1C5u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B1C5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB1C5u,0x80B1C5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80B2A5_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B2A5u: goto L_80B2A5;
    case 0x80B2A8u: goto L_80B2A8;
    case 0x80B2AAu: goto L_80B2AA;
    case 0x80B2ADu: goto L_80B2AD;
    case 0x80B2AFu: goto L_80B2AF;
    case 0x80B2B2u: goto L_80B2B2;
    case 0x80B2B5u: goto L_80B2B5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B2A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A5u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A5u, 5u, 3u, cpu.address("abs", 0x0137u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2A5 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x137u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B2A8;
L_80B2A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2A8 BEQ -> $80B2B2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B2B2; }
    goto L_80B2AA;
L_80B2AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2AAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2AAu, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2AA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B2AD;
L_80B2AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2ADu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2ADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2AD BEQ -> $80B2B2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B2B2; }
    goto L_80B2AF;
L_80B2AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2AFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2AFu, 6u, 3u, cpu.address("abs", 0xD180u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B2AF JSR -> $80D180 stack real
    { cpu.push16Value(hw,0xB2B1u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB2B2u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD180u), 0x80B2AFu); }
    goto L_80B2B2;
L_80B2B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2B2u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2B2u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2B2u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2B2 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B2B5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2B2u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2B2u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2B2 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80B2B5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2B2u,0x80B2B2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2B5u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2B5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2B5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B2B5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B2B5u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B2B5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2B5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2B5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B2B5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B2B5u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B2B5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2B5u,0x80B2B5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80B64B_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B64Bu: goto L_80B64B;
    case 0x80B64Du: goto L_80B64D;
    case 0x80B64Fu: goto L_80B64F;
    case 0x80B650u: goto L_80B650;
    case 0x80B651u: goto L_80B651;
    case 0x80B654u: goto L_80B654;
    case 0x80B655u: goto L_80B655;
    case 0x80B656u: goto L_80B656;
    case 0x80B65Au: goto L_80B65A;
    case 0x80B65Cu: goto L_80B65C;
    case 0x80B65Fu: goto L_80B65F;
    case 0x80B661u: goto L_80B661;
    case 0x80B664u: goto L_80B664;
    case 0x80B666u: goto L_80B666;
    case 0x80B66Au: goto L_80B66A;
    case 0x80B66Du: goto L_80B66D;
    case 0x80B66Fu: goto L_80B66F;
    case 0x80B672u: goto L_80B672;
    case 0x80B674u: goto L_80B674;
    case 0x80B676u: goto L_80B676;
    case 0x80B679u: goto L_80B679;
    case 0x80B67Au: goto L_80B67A;
    case 0x80B67Du: goto L_80B67D;
    case 0x80B67Eu: goto L_80B67E;
    case 0x80B681u: goto L_80B681;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B64B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB64Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Bu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B64B STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_80B64D;
L_80B64D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB64Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Du,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B64D LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B64F;
L_80B64F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB64Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Fu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B64F TXA
    cpu.transfer("TXA");
    goto L_80B650;
L_80B650:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB650u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB650u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB650u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B650 CLC
    cpu.setFlag('C', false);
    goto L_80B651;
L_80B651:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB651u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB651u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB651u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B651 ADC
    cpu.adc(0x16u);
    goto L_80B654;
L_80B654:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB654u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB654u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB654u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B654 TAX
    cpu.transfer("TAX");
    goto L_80B655;
L_80B655:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB655u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB655u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB655u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B655 INY
    cpu.inc('Y');
    goto L_80B656;
L_80B656:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB656u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB656u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB656u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B656 LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B65A;
L_80B65A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB65Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB65Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB65Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B65A BEQ -> $80B64F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B64F; }
    goto L_80B65C;
L_80B65C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB65Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB65Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB65Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B65C CMP
    cpu.compareA(0xFFFFu);
    goto L_80B65F;
L_80B65F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB65Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB65Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB65Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B65F BEQ -> $80B67E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B67E; }
    goto L_80B661;
L_80B661:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB661u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB661u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB661u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B661 AND
    cpu.logicAnd(0x300u);
    goto L_80B664;
L_80B664:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB664u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB664u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB664u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B664 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80B666;
L_80B666:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB666u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB666u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB666u, 6u, 4u, ((0x7E2016u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B666 LDA
    cpu.loadA(hw.readW(((0x7E2016u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B66A;
L_80B66A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB66Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B66A CMP
    cpu.compareA(0xFFFFu);
    goto L_80B66D;
L_80B66D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB66Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B66D BEQ -> $80B67A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B67A; }
    goto L_80B66F;
L_80B66F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB66Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB66Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B66F AND
    cpu.logicAnd(0x300u);
    goto L_80B672;
L_80B672:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB672u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB672u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB672u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B672 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_80B674;
L_80B674:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB674u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB674u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB674u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B674 BNE -> $80B67A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B67A; }
    goto L_80B676;
L_80B676:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB676u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB676u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB676u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B676 LDA
    cpu.setA(0x2u, 16);
    goto L_80B679;
L_80B679:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB679u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB679u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB679u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B679 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B679u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B679u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80B67A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB67Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB67Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB67Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B67A LDA
    cpu.setA(0x1u, 16);
    goto L_80B67D;
L_80B67D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB67Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB67Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB67Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B67D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B67Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B67Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80B67E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB67Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB67Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB67Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B67E LDA
    cpu.setA(0x0u, 16);
    goto L_80B681;
L_80B681:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB681u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB681u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB681u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B681 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B681u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B681u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80B827_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B827u: goto L_80B827;
    case 0x80B82Au: goto L_80B82A;
    case 0x80B82Cu: goto L_80B82C;
    case 0x80B82Fu: goto L_80B82F;
    case 0x80B830u: goto L_80B830;
    case 0x80B833u: goto L_80B833;
    case 0x80B836u: goto L_80B836;
    case 0x80B838u: goto L_80B838;
    case 0x80B83Bu: goto L_80B83B;
    case 0x80B83Eu: goto L_80B83E;
    case 0x80B840u: goto L_80B840;
    case 0x80B843u: goto L_80B843;
    case 0x80B845u: goto L_80B845;
    case 0x80B848u: goto L_80B848;
    case 0x80B84Bu: goto L_80B84B;
    case 0x80B84Eu: goto L_80B84E;
    case 0x80B851u: goto L_80B851;
    case 0x80B854u: goto L_80B854;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B827:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB827u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB827u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB827u, 5u, 3u, cpu.address("abs", 0x094Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B827 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x94Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B82A;
L_80B82A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB82Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB82Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB82Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B82A BNE -> $80B851
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B851; }
    goto L_80B82C;
L_80B82C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB82Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB82Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB82Cu, 5u, 3u, cpu.address("abs", 0x0926u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B82C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x926u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B82F;
L_80B82F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB82Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB82Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB82Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B82F CLC
    cpu.setFlag('C', false);
    goto L_80B830;
L_80B830:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB830u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB830u,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB830u, 5u, 3u, cpu.address("abs", 0x0928u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B830 ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x928u), cpu.m8?8:16));
    goto L_80B833;
L_80B833:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB833u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB833u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB833u, 5u, 3u, cpu.address("abs", 0x0902u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B833 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x902u), cpu.m8?8:16));
    goto L_80B836;
L_80B836:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB836u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB836u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB836u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B836 BEQ -> $80B851
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B851; }
    goto L_80B838;
L_80B838:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB838u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB838u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB838u, 5u, 3u, cpu.address("abs", 0x0926u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B838 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x926u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B83B;
L_80B83B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB83Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB83Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB83Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B83B CMP
    cpu.compareA(0x3u);
    goto L_80B83E;
L_80B83E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB83Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB83Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB83Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B83E BNE -> $80B845
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B845; }
    goto L_80B840;
L_80B840:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB840u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB840u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB840u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B840 LDA
    cpu.setA(0x8000u, 16);
    goto L_80B843;
L_80B843:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB843u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB843u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB843u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B843 BRA -> $80B848
    goto L_80B848;
L_80B845:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB845u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB845u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB845u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B845 LDA
    cpu.setA(0x80u, 16);
    goto L_80B848;
L_80B848:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB848u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB848u,cpu,0x0Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB848u, 8u, 3u, cpu.address("abs", 0x0924u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B848 TSB
    cpu.tsb(hw, cpu.address("abs", 0x924u), cpu.m8?8:16);
    goto L_80B84B;
L_80B84B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB84Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB84Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB84Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B84B LDA
    cpu.setA(0x4u, 16);
    goto L_80B84E;
L_80B84E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB84Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB84Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB84Eu, 5u, 3u, cpu.address("abs", 0x094Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B84E STA
    hw.write(cpu.address("abs", 0x94Eu), cpu.a, cpu.m8?8:16);
    goto L_80B851;
L_80B851:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB851u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB851u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB851u, 5u, 3u, cpu.address("abs", 0x0928u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B851 STZ
    hw.write(cpu.address("abs", 0x928u), 0, cpu.m8?8:16);
    goto L_80B854;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB851u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB851u, 5u, 3u, cpu.address("abs", 0x0928u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B851 STZ
    hw.write(cpu.address("abs", 0x928u), 0, cpu.m8?8:16);
    goto L_80B854;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB851u,0x80B851u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B854:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB854u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB854u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB854u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B854 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B854u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B854u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB854u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB854u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B854 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B854u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B854u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB854u,0x80B854u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80B827_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B827u: goto L_80B827;
    case 0x80B82Au: goto L_80B82A;
    case 0x80B82Cu: goto L_80B82C;
    case 0x80B82Fu: goto L_80B82F;
    case 0x80B830u: goto L_80B830;
    case 0x80B833u: goto L_80B833;
    case 0x80B836u: goto L_80B836;
    case 0x80B838u: goto L_80B838;
    case 0x80B83Bu: goto L_80B83B;
    case 0x80B83Eu: goto L_80B83E;
    case 0x80B840u: goto L_80B840;
    case 0x80B843u: goto L_80B843;
    case 0x80B845u: goto L_80B845;
    case 0x80B848u: goto L_80B848;
    case 0x80B84Bu: goto L_80B84B;
    case 0x80B84Eu: goto L_80B84E;
    case 0x80B851u: goto L_80B851;
    case 0x80B854u: goto L_80B854;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B827:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB827u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB827u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB827u, 5u, 3u, cpu.address("abs", 0x094Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B827 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x94Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B82A;
L_80B82A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB82Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB82Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB82Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B82A BNE -> $80B851
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B851; }
    goto L_80B82C;
L_80B82C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB82Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB82Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB82Cu, 5u, 3u, cpu.address("abs", 0x0926u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B82C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x926u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B82F;
L_80B82F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB82Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB82Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB82Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B82F CLC
    cpu.setFlag('C', false);
    goto L_80B830;
L_80B830:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB830u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB830u,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB830u, 5u, 3u, cpu.address("abs", 0x0928u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B830 ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x928u), cpu.m8?8:16));
    goto L_80B833;
L_80B833:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB833u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB833u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB833u, 5u, 3u, cpu.address("abs", 0x0902u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B833 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x902u), cpu.m8?8:16));
    goto L_80B836;
L_80B836:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB836u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB836u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB836u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B836 BEQ -> $80B851
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B851; }
    goto L_80B838;
L_80B838:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB838u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB838u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB838u, 5u, 3u, cpu.address("abs", 0x0926u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B838 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x926u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B83B;
L_80B83B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB83Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB83Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB83Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B83B CMP
    cpu.compareA(0x3u);
    goto L_80B83E;
L_80B83E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB83Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB83Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB83Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B83E BNE -> $80B845
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B845; }
    goto L_80B840;
L_80B840:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB840u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB840u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB840u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B840 LDA
    cpu.setA(0x8000u, 16);
    goto L_80B843;
L_80B843:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB843u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB843u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB843u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B843 BRA -> $80B848
    goto L_80B848;
L_80B845:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB845u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB845u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB845u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B845 LDA
    cpu.setA(0x80u, 16);
    goto L_80B848;
L_80B848:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB848u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB848u,cpu,0x0Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB848u, 8u, 3u, cpu.address("abs", 0x0924u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B848 TSB
    cpu.tsb(hw, cpu.address("abs", 0x924u), cpu.m8?8:16);
    goto L_80B84B;
L_80B84B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB84Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB84Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB84Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B84B LDA
    cpu.setA(0x4u, 16);
    goto L_80B84E;
L_80B84E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB84Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB84Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB84Eu, 5u, 3u, cpu.address("abs", 0x094Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B84E STA
    hw.write(cpu.address("abs", 0x94Eu), cpu.a, cpu.m8?8:16);
    goto L_80B851;
L_80B851:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB851u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB851u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB851u, 5u, 3u, cpu.address("abs", 0x0928u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B851 STZ
    hw.write(cpu.address("abs", 0x928u), 0, cpu.m8?8:16);
    goto L_80B854;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB851u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB851u, 5u, 3u, cpu.address("abs", 0x0928u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B851 STZ
    hw.write(cpu.address("abs", 0x928u), 0, cpu.m8?8:16);
    goto L_80B854;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB851u,0x80B851u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B854:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB854u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB854u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB854u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B854 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B854u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B854u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB854u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB854u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B854 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B854u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B854u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB854u,0x80B854u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80B827_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B827u: goto L_80B827;
    case 0x80B82Au: goto L_80B82A;
    case 0x80B82Cu: goto L_80B82C;
    case 0x80B82Fu: goto L_80B82F;
    case 0x80B830u: goto L_80B830;
    case 0x80B833u: goto L_80B833;
    case 0x80B836u: goto L_80B836;
    case 0x80B838u: goto L_80B838;
    case 0x80B83Bu: goto L_80B83B;
    case 0x80B83Eu: goto L_80B83E;
    case 0x80B840u: goto L_80B840;
    case 0x80B843u: goto L_80B843;
    case 0x80B845u: goto L_80B845;
    case 0x80B848u: goto L_80B848;
    case 0x80B84Bu: goto L_80B84B;
    case 0x80B84Eu: goto L_80B84E;
    case 0x80B851u: goto L_80B851;
    case 0x80B854u: goto L_80B854;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B827:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB827u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB827u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB827u, 5u, 3u, cpu.address("abs", 0x094Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B827 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x94Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B82A;
L_80B82A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB82Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB82Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB82Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B82A BNE -> $80B851
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B851; }
    goto L_80B82C;
L_80B82C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB82Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB82Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB82Cu, 5u, 3u, cpu.address("abs", 0x0926u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B82C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x926u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B82F;
L_80B82F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB82Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB82Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB82Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B82F CLC
    cpu.setFlag('C', false);
    goto L_80B830;
L_80B830:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB830u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB830u,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB830u, 5u, 3u, cpu.address("abs", 0x0928u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B830 ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x928u), cpu.m8?8:16));
    goto L_80B833;
L_80B833:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB833u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB833u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB833u, 5u, 3u, cpu.address("abs", 0x0902u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B833 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x902u), cpu.m8?8:16));
    goto L_80B836;
L_80B836:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB836u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB836u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB836u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B836 BEQ -> $80B851
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B851; }
    goto L_80B838;
L_80B838:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB838u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB838u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB838u, 5u, 3u, cpu.address("abs", 0x0926u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B838 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x926u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B83B;
L_80B83B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB83Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB83Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB83Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B83B CMP
    cpu.compareA(0x3u);
    goto L_80B83E;
L_80B83E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB83Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB83Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB83Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B83E BNE -> $80B845
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B845; }
    goto L_80B840;
L_80B840:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB840u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB840u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB840u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B840 LDA
    cpu.setA(0x8000u, 16);
    goto L_80B843;
L_80B843:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB843u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB843u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB843u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B843 BRA -> $80B848
    goto L_80B848;
L_80B845:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB845u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB845u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB845u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B845 LDA
    cpu.setA(0x80u, 16);
    goto L_80B848;
L_80B848:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB848u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB848u,cpu,0x0Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB848u, 8u, 3u, cpu.address("abs", 0x0924u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B848 TSB
    cpu.tsb(hw, cpu.address("abs", 0x924u), cpu.m8?8:16);
    goto L_80B84B;
L_80B84B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB84Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB84Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB84Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B84B LDA
    cpu.setA(0x4u, 16);
    goto L_80B84E;
L_80B84E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB84Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB84Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB84Eu, 5u, 3u, cpu.address("abs", 0x094Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B84E STA
    hw.write(cpu.address("abs", 0x94Eu), cpu.a, cpu.m8?8:16);
    goto L_80B851;
L_80B851:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB851u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB851u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB851u, 5u, 3u, cpu.address("abs", 0x0928u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B851 STZ
    hw.write(cpu.address("abs", 0x928u), 0, cpu.m8?8:16);
    goto L_80B854;
L_80B854:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB854u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB854u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB854u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B854 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B854u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B854u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80C398_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80C398u: goto L_80C398;
    case 0x80C39Au: goto L_80C39A;
    case 0x80C39Du: goto L_80C39D;
    case 0x80C39Fu: goto L_80C39F;
    case 0x80C3A3u: goto L_80C3A3;
    case 0x80C3A6u: goto L_80C3A6;
    case 0x80C3A8u: goto L_80C3A8;
    case 0x80C3ABu: goto L_80C3AB;
    case 0x80C3ADu: goto L_80C3AD;
    case 0x80C3AFu: goto L_80C3AF;
    case 0x80C3B0u: goto L_80C3B0;
    case 0x80C3B2u: goto L_80C3B2;
    case 0x80C3B6u: goto L_80C3B6;
    case 0x80C3B8u: goto L_80C3B8;
    case 0x80C3BCu: goto L_80C3BC;
    case 0x80C3BFu: goto L_80C3BF;
    case 0x80C3C3u: goto L_80C3C3;
    case 0x80C3C5u: goto L_80C3C5;
    case 0x80C3C7u: goto L_80C3C7;
    case 0x80C3C9u: goto L_80C3C9;
    case 0x80C3CBu: goto L_80C3CB;
    case 0x80C3CDu: goto L_80C3CD;
    case 0x80C3CFu: goto L_80C3CF;
    case 0x80C3D1u: goto L_80C3D1;
    case 0x80C3D5u: goto L_80C3D5;
    case 0x80C3D8u: goto L_80C3D8;
    case 0x80C3DAu: goto L_80C3DA;
    case 0x80C3DDu: goto L_80C3DD;
    case 0x80C3DFu: goto L_80C3DF;
    case 0x80C3E1u: goto L_80C3E1;
    case 0x80C3E2u: goto L_80C3E2;
    case 0x80C3E4u: goto L_80C3E4;
    case 0x80C3E8u: goto L_80C3E8;
    case 0x80C3EAu: goto L_80C3EA;
    case 0x80C3EEu: goto L_80C3EE;
    case 0x80C3F1u: goto L_80C3F1;
    case 0x80C3F5u: goto L_80C3F5;
    case 0x80C3F7u: goto L_80C3F7;
    case 0x80C3F9u: goto L_80C3F9;
    case 0x80C3FBu: goto L_80C3FB;
    case 0x80C3FDu: goto L_80C3FD;
    case 0x80C3FFu: goto L_80C3FF;
    case 0x80C401u: goto L_80C401;
    case 0x80C403u: goto L_80C403;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80C398:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC398u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC398u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC398u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C398 STX
    hw.write(cpu.address("dp", 0x61u), cpu.x, cpu.x8?8:16);
    goto L_80C39A;
L_80C39A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC39Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC39Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC39Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C39A AND
    cpu.logicAnd(0x300u);
    goto L_80C39D;
L_80C39D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC39Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC39Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC39Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C39D STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80C39F;
L_80C39F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC39Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC39Fu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC39Fu, 6u, 4u, ((0x7E2002u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C39F LDA
    cpu.loadA(hw.readW(((0x7E2002u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C3A3;
L_80C3A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3A3u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3A3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3A3 CMP
    cpu.compareA(0xFFFFu);
    goto L_80C3A6;
L_80C3A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3A6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3A6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3A6 BEQ -> $80C3D1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C3D1; }
    goto L_80C3A8;
L_80C3A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3A8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3A8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3A8 AND
    cpu.logicAnd(0x300u);
    goto L_80C3AB;
L_80C3AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3ABu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3ABu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3AB CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_80C3AD;
L_80C3AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3ADu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3ADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3AD BNE -> $80C3D1
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C3D1; }
    goto L_80C3AF;
L_80C3AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3AFu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3AFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3AF TXA
    cpu.transfer("TXA");
    goto L_80C3B0;
L_80C3B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3B0u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3B0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3B0 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C3B2;
L_80C3B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3B2u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3B2u, 6u, 4u, ((0x7E2444u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3B2 STA
    hw.write(((0x7E2444u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80C3B6;
L_80C3B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3B6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3B6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3B6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C3B8;
L_80C3B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3B8u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3B8u, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3B8 STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80C3BC;
L_80C3BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3BCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3BCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3BC LDA
    cpu.setA(0x0u, 16);
    goto L_80C3BF;
L_80C3BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3BFu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3BFu, 6u, 4u, ((0x7E2442u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3BF STA
    hw.write(((0x7E2442u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80C3C3;
L_80C3C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3C3u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3C3u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3C3 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C3C5;
L_80C3C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3C5u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3C5u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3C5 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C3C7;
L_80C3C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3C7u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3C7u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3C7 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C3C9;
L_80C3C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3C9u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3C9u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3C9 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C3CB;
L_80C3CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3CBu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3CBu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3CB INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C3CD;
L_80C3CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3CDu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3CDu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3CD INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C3CF;
L_80C3CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3CFu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3CFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3CF LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C3D1;
L_80C3D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3D1u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3D1u, 6u, 4u, ((0x7E2016u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3D1 LDA
    cpu.loadA(hw.readW(((0x7E2016u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C3D5;
L_80C3D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3D5u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3D5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3D5 CMP
    cpu.compareA(0xFFFFu);
    goto L_80C3D8;
L_80C3D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3D8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3D8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3D8 BEQ -> $80C403
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C403; }
    goto L_80C3DA;
L_80C3DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3DAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3DAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3DA AND
    cpu.logicAnd(0x300u);
    goto L_80C3DD;
L_80C3DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3DDu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3DDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3DD CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_80C3DF;
L_80C3DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3DFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3DFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3DF BNE -> $80C403
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C403; }
    goto L_80C3E1;
L_80C3E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3E1u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3E1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3E1 TXA
    cpu.transfer("TXA");
    goto L_80C3E2;
L_80C3E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3E2u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3E2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3E2 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C3E4;
L_80C3E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3E4u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3E4u, 6u, 4u, ((0x7E2444u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3E4 STA
    hw.write(((0x7E2444u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80C3E8;
L_80C3E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3E8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3E8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3E8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C3EA;
L_80C3EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3EAu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3EAu, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3EA STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80C3EE;
L_80C3EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3EEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3EEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3EE LDA
    cpu.setA(0x4u, 16);
    goto L_80C3F1;
L_80C3F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3F1u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3F1u, 6u, 4u, ((0x7E2442u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3F1 STA
    hw.write(((0x7E2442u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80C3F5;
L_80C3F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3F5u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3F5u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3F5 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C3F7;
L_80C3F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3F7u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3F7u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3F7 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C3F9;
L_80C3F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3F9u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3F9u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3F9 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C3FB;
L_80C3FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3FBu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3FBu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3FB INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C3FD;
L_80C3FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3FDu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3FDu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3FD INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C3FF;
L_80C3FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3FFu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3FFu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3FF INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C401;
L_80C401:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC401u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC401u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC401u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C401 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C403;
L_80C403:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC403u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC403u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC403u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C403 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80C403u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80C403u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80C4C3_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80C4C3u: goto L_80C4C3;
    case 0x80C4C5u: goto L_80C4C5;
    case 0x80C4C8u: goto L_80C4C8;
    case 0x80C4CAu: goto L_80C4CA;
    case 0x80C4CEu: goto L_80C4CE;
    case 0x80C4D0u: goto L_80C4D0;
    case 0x80C4D4u: goto L_80C4D4;
    case 0x80C4D7u: goto L_80C4D7;
    case 0x80C4D9u: goto L_80C4D9;
    case 0x80C4DCu: goto L_80C4DC;
    case 0x80C4DEu: goto L_80C4DE;
    case 0x80C4E0u: goto L_80C4E0;
    case 0x80C4E1u: goto L_80C4E1;
    case 0x80C4E3u: goto L_80C4E3;
    case 0x80C4E7u: goto L_80C4E7;
    case 0x80C4E9u: goto L_80C4E9;
    case 0x80C4EDu: goto L_80C4ED;
    case 0x80C4F0u: goto L_80C4F0;
    case 0x80C4F4u: goto L_80C4F4;
    case 0x80C4F6u: goto L_80C4F6;
    case 0x80C4F8u: goto L_80C4F8;
    case 0x80C4FAu: goto L_80C4FA;
    case 0x80C4FCu: goto L_80C4FC;
    case 0x80C4FEu: goto L_80C4FE;
    case 0x80C500u: goto L_80C500;
    case 0x80C502u: goto L_80C502;
    case 0x80C506u: goto L_80C506;
    case 0x80C508u: goto L_80C508;
    case 0x80C50Cu: goto L_80C50C;
    case 0x80C50Fu: goto L_80C50F;
    case 0x80C511u: goto L_80C511;
    case 0x80C514u: goto L_80C514;
    case 0x80C516u: goto L_80C516;
    case 0x80C518u: goto L_80C518;
    case 0x80C519u: goto L_80C519;
    case 0x80C51Bu: goto L_80C51B;
    case 0x80C51Fu: goto L_80C51F;
    case 0x80C521u: goto L_80C521;
    case 0x80C525u: goto L_80C525;
    case 0x80C528u: goto L_80C528;
    case 0x80C52Cu: goto L_80C52C;
    case 0x80C52Eu: goto L_80C52E;
    case 0x80C530u: goto L_80C530;
    case 0x80C532u: goto L_80C532;
    case 0x80C534u: goto L_80C534;
    case 0x80C536u: goto L_80C536;
    case 0x80C538u: goto L_80C538;
    case 0x80C53Au: goto L_80C53A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80C4C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C3u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4C3 STX
    hw.write(cpu.address("dp", 0x61u), cpu.x, cpu.x8?8:16);
    goto L_80C4C5;
L_80C4C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C5u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4C5 AND
    cpu.logicAnd(0x300u);
    goto L_80C4C8;
L_80C4C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4C8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4C8 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80C4CA;
L_80C4CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4CAu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4CAu, 6u, 4u, ((0x7E2002u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4CA LDA
    cpu.loadA(hw.readW(((0x7E2002u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C4CE;
L_80C4CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4CEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4CEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4CE BNE -> $80C502
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C502; }
    goto L_80C4D0;
L_80C4D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D0u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D0u, 6u, 4u, ((0x7E2004u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4D0 LDA
    cpu.loadA(hw.readW(((0x7E2004u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C4D4;
L_80C4D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D4u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4D4 CMP
    cpu.compareA(0xFFFFu);
    goto L_80C4D7;
L_80C4D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4D7 BEQ -> $80C502
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C502; }
    goto L_80C4D9;
L_80C4D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4D9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4D9 AND
    cpu.logicAnd(0x300u);
    goto L_80C4DC;
L_80C4DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4DCu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4DCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4DC CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_80C4DE;
L_80C4DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4DEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4DEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4DE BNE -> $80C502
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C502; }
    goto L_80C4E0;
L_80C4E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E0u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4E0 TXA
    cpu.transfer("TXA");
    goto L_80C4E1;
L_80C4E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E1u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4E1 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C4E3;
L_80C4E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E3u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E3u, 6u, 4u, ((0x7E2444u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4E3 STA
    hw.write(((0x7E2444u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80C4E7;
L_80C4E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4E7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C4E9;
L_80C4E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E9u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4E9u, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4E9 STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80C4ED;
L_80C4ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4EDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4EDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4ED LDA
    cpu.setA(0x2u, 16);
    goto L_80C4F0;
L_80C4F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F0u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F0u, 6u, 4u, ((0x7E2442u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4F0 STA
    hw.write(((0x7E2442u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80C4F4;
L_80C4F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F4u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F4u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4F4 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C4F6;
L_80C4F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F6u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F6u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4F6 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C4F8;
L_80C4F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F8u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4F8u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4F8 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C4FA;
L_80C4FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4FAu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4FAu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4FA INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C4FC;
L_80C4FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4FCu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4FCu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4FC INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C4FE;
L_80C4FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC4FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC4FEu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC4FEu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C4FE INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C500;
L_80C500:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC500u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC500u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC500u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C500 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C502;
L_80C502:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC502u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC502u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC502u, 6u, 4u, ((0x7E2016u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C502 LDA
    cpu.loadA(hw.readW(((0x7E2016u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C506;
L_80C506:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC506u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC506u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC506u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C506 BNE -> $80C53A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C53A; }
    goto L_80C508;
L_80C508:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC508u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC508u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC508u, 6u, 4u, ((0x7E202Cu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C508 LDA
    cpu.loadA(hw.readW(((0x7E202Cu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C50C;
L_80C50C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC50Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC50Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC50Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C50C CMP
    cpu.compareA(0xFFFFu);
    goto L_80C50F;
L_80C50F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC50Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC50Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC50Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C50F BEQ -> $80C53A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C53A; }
    goto L_80C511;
L_80C511:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC511u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC511u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC511u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C511 AND
    cpu.logicAnd(0x300u);
    goto L_80C514;
L_80C514:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC514u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC514u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC514u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C514 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_80C516;
L_80C516:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC516u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC516u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC516u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C516 BNE -> $80C53A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C53A; }
    goto L_80C518;
L_80C518:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC518u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC518u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC518u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C518 TXA
    cpu.transfer("TXA");
    goto L_80C519;
L_80C519:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC519u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC519u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC519u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C519 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C51B;
L_80C51B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC51Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC51Bu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC51Bu, 6u, 4u, ((0x7E2444u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C51B STA
    hw.write(((0x7E2444u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80C51F;
L_80C51F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC51Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC51Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC51Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C51F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C521;
L_80C521:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC521u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC521u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC521u, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C521 STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80C525;
L_80C525:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC525u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC525u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC525u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C525 LDA
    cpu.setA(0x4u, 16);
    goto L_80C528;
L_80C528:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC528u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC528u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC528u, 6u, 4u, ((0x7E2442u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C528 STA
    hw.write(((0x7E2442u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80C52C;
L_80C52C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC52Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Cu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Cu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C52C INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C52E;
L_80C52E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC52Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Eu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC52Eu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C52E INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C530;
L_80C530:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC530u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC530u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC530u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C530 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C532;
L_80C532:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC532u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC532u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC532u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C532 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C534;
L_80C534:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC534u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC534u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC534u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C534 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C536;
L_80C536:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC536u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC536u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC536u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C536 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C538;
L_80C538:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC538u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC538u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC538u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C538 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C53A;
L_80C53A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC53Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC53Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC53Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C53A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80C53Au);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80C53Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80C95D_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80C95Du: goto L_80C95D;
    case 0x80C95Eu: goto L_80C95E;
    case 0x80C95Fu: goto L_80C95F;
    case 0x80C962u: goto L_80C962;
    case 0x80C963u: goto L_80C963;
    case 0x80C965u: goto L_80C965;
    case 0x80C969u: goto L_80C969;
    case 0x80C96Bu: goto L_80C96B;
    case 0x80C96Eu: goto L_80C96E;
    case 0x80C970u: goto L_80C970;
    case 0x80C973u: goto L_80C973;
    case 0x80C975u: goto L_80C975;
    case 0x80C977u: goto L_80C977;
    case 0x80C979u: goto L_80C979;
    case 0x80C97Du: goto L_80C97D;
    case 0x80C97Fu: goto L_80C97F;
    case 0x80C983u: goto L_80C983;
    case 0x80C986u: goto L_80C986;
    case 0x80C98Au: goto L_80C98A;
    case 0x80C98Cu: goto L_80C98C;
    case 0x80C98Eu: goto L_80C98E;
    case 0x80C990u: goto L_80C990;
    case 0x80C992u: goto L_80C992;
    case 0x80C994u: goto L_80C994;
    case 0x80C996u: goto L_80C996;
    case 0x80C998u: goto L_80C998;
    case 0x80C999u: goto L_80C999;
    case 0x80C99Au: goto L_80C99A;
    case 0x80C99Cu: goto L_80C99C;
    case 0x80C99Eu: goto L_80C99E;
    case 0x80C9A2u: goto L_80C9A2;
    case 0x80C9A4u: goto L_80C9A4;
    case 0x80C9A7u: goto L_80C9A7;
    case 0x80C9A9u: goto L_80C9A9;
    case 0x80C9ACu: goto L_80C9AC;
    case 0x80C9AEu: goto L_80C9AE;
    case 0x80C9B0u: goto L_80C9B0;
    case 0x80C9B2u: goto L_80C9B2;
    case 0x80C9B6u: goto L_80C9B6;
    case 0x80C9B8u: goto L_80C9B8;
    case 0x80C9BCu: goto L_80C9BC;
    case 0x80C9BFu: goto L_80C9BF;
    case 0x80C9C3u: goto L_80C9C3;
    case 0x80C9C5u: goto L_80C9C5;
    case 0x80C9C7u: goto L_80C9C7;
    case 0x80C9C9u: goto L_80C9C9;
    case 0x80C9CBu: goto L_80C9CB;
    case 0x80C9CDu: goto L_80C9CD;
    case 0x80C9CFu: goto L_80C9CF;
    case 0x80C9D1u: goto L_80C9D1;
    case 0x80C9D2u: goto L_80C9D2;
    case 0x80C9D3u: goto L_80C9D3;
    case 0x80C9D5u: goto L_80C9D5;
    case 0x80C9D8u: goto L_80C9D8;
    case 0x80C9DAu: goto L_80C9DA;
    case 0x80C9DCu: goto L_80C9DC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80C95D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC95Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC95Du,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC95Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C95D TXA
    cpu.transfer("TXA");
    goto L_80C95E;
L_80C95E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC95Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC95Eu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC95Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C95E SEC
    cpu.setFlag('C', true);
    goto L_80C95F;
L_80C95F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC95Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC95Fu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC95Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C95F SBC
    cpu.sbc(0x16u);
    goto L_80C962;
L_80C962:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC962u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC962u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC962u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C962 TAX
    cpu.transfer("TAX");
    goto L_80C963;
L_80C963:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC963u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC963u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC963u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C963 STX
    hw.write(cpu.address("dp", 0x5Fu), cpu.x, cpu.x8?8:16);
    goto L_80C965;
L_80C965:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC965u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC965u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC965u, 6u, 4u, ((0x7E1FFEu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C965 LDA
    cpu.loadA(hw.readW(((0x7E1FFEu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C969;
L_80C969:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC969u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC969u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC969u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C969 BEQ -> $80C998
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C998; }
    goto L_80C96B;
L_80C96B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC96Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC96Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC96Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C96B CMP
    cpu.compareA(0xFFFFu);
    goto L_80C96E;
L_80C96E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC96Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC96Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC96Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C96E BEQ -> $80C99C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C99C; }
    goto L_80C970;
L_80C970:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC970u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC970u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC970u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C970 AND
    cpu.logicAnd(0x300u);
    goto L_80C973;
L_80C973:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC973u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC973u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC973u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C973 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80C975;
L_80C975:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC975u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC975u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC975u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C975 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C977;
L_80C977:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC977u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC977u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC977u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C977 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C979;
L_80C979:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC979u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC979u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC979u, 6u, 4u, ((0x7E2444u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C979 STA
    hw.write(((0x7E2444u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80C97D;
L_80C97D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC97Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC97Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC97Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C97D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C97F;
L_80C97F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC97Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC97Fu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC97Fu, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C97F STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80C983;
L_80C983:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC983u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC983u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC983u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C983 LDA
    cpu.setA(0x0u, 16);
    goto L_80C986;
L_80C986:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC986u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC986u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC986u, 6u, 4u, ((0x7E2442u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C986 STA
    hw.write(((0x7E2442u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80C98A;
L_80C98A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC98Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC98Au,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC98Au, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C98A INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C98C;
L_80C98C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC98Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC98Cu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC98Cu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C98C INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C98E;
L_80C98E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC98Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC98Eu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC98Eu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C98E INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C990;
L_80C990:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC990u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC990u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC990u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C990 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C992;
L_80C992:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC992u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC992u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC992u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C992 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C994;
L_80C994:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC994u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC994u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC994u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C994 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C996;
L_80C996:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC996u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC996u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC996u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C996 BRA -> $80C9DC
    goto L_80C9DC;
L_80C998:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC998u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC998u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC998u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C998 DEX
    cpu.decReg('X');
    goto L_80C999;
L_80C999:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC999u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC999u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC999u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C999 DEX
    cpu.decReg('X');
    goto L_80C99A;
L_80C99A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC99Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC99Au,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC99Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C99A BRA -> $80C965
    goto L_80C965;
L_80C99C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC99Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC99Cu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC99Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C99C LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Fu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C99E;
L_80C99E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC99Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC99Eu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC99Eu, 6u, 4u, ((0x7E2002u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C99E LDA
    cpu.loadA(hw.readW(((0x7E2002u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C9A2;
L_80C9A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9A2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9A2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C9A2 BEQ -> $80C9D1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C9D1; }
    goto L_80C9A4;
L_80C9A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9A4u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9A4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C9A4 CMP
    cpu.compareA(0xFFFFu);
    goto L_80C9A7;
L_80C9A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9A7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9A7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C9A7 BEQ -> $80C9D5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C9D5; }
    goto L_80C9A9;
L_80C9A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9A9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9A9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C9A9 AND
    cpu.logicAnd(0x300u);
    goto L_80C9AC;
L_80C9AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9ACu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9ACu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C9AC STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80C9AE;
L_80C9AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9AEu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9AEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C9AE LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C9B0;
L_80C9B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9B0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9B0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C9B0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C9B2;
L_80C9B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9B2u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9B2u, 6u, 4u, ((0x7E2444u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C9B2 STA
    hw.write(((0x7E2444u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80C9B6;
L_80C9B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9B6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9B6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C9B6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C9B8;
L_80C9B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9B8u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9B8u, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C9B8 STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80C9BC;
L_80C9BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9BCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9BCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C9BC LDA
    cpu.setA(0x2u, 16);
    goto L_80C9BF;
L_80C9BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9BFu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9BFu, 6u, 4u, ((0x7E2442u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C9BF STA
    hw.write(((0x7E2442u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80C9C3;
L_80C9C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9C3u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9C3u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C9C3 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C9C5;
L_80C9C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9C5u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9C5u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C9C5 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C9C7;
L_80C9C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9C7u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9C7u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C9C7 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C9C9;
L_80C9C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9C9u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9C9u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C9C9 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C9CB;
L_80C9CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9CBu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9CBu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C9CB INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C9CD;
L_80C9CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9CDu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9CDu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C9CD INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80C9CF;
L_80C9CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9CFu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9CFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C9CF BRA -> $80C9DC
    goto L_80C9DC;
L_80C9D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9D1u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9D1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C9D1 INX
    cpu.inc('X');
    goto L_80C9D2;
L_80C9D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9D2u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C9D2 INX
    cpu.inc('X');
    goto L_80C9D3;
L_80C9D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9D3u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9D3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C9D3 BRA -> $80C99E
    goto L_80C99E;
L_80C9D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9D5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9D5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C9D5 LDA
    cpu.setA(0x1u, 16);
    goto L_80C9D8;
L_80C9D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9D8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9D8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C9D8 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80C9DA;
L_80C9DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9DAu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9DAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C9DA BRA -> $80C9AE
    goto L_80C9AE;
L_80C9DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC9DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC9DCu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC9DCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C9DC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80C9DCu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80C9DCu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80CAD7_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80CAD7u: goto L_80CAD7;
    case 0x80CAD9u: goto L_80CAD9;
    case 0x80CADCu: goto L_80CADC;
    case 0x80CADFu: goto L_80CADF;
    case 0x80CAE0u: goto L_80CAE0;
    case 0x80CAE3u: goto L_80CAE3;
    case 0x80CAE5u: goto L_80CAE5;
    case 0x80CAE9u: goto L_80CAE9;
    case 0x80CAECu: goto L_80CAEC;
    case 0x80CAEEu: goto L_80CAEE;
    case 0x80CAF1u: goto L_80CAF1;
    case 0x80CAF4u: goto L_80CAF4;
    case 0x80CAF5u: goto L_80CAF5;
    case 0x80CAF6u: goto L_80CAF6;
    case 0x80CAF8u: goto L_80CAF8;
    case 0x80CAFAu: goto L_80CAFA;
    case 0x80CAFDu: goto L_80CAFD;
    case 0x80CB01u: goto L_80CB01;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80CAD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD7u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CAD7 STZ
    hw.write(cpu.address("dp", 0x63u), 0, cpu.m8?8:16);
    goto L_80CAD9;
L_80CAD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD9u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CAD9 LDY
    cpu.setY(0x4u, 16);
    goto L_80CADC;
L_80CADC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCADCu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCADCu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCADCu, 5u + 1u, 3u, cpu.address("absy", 0x03AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CADC LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x3AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CADF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCADCu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCADCu, 5u + 1u, 3u, cpu.address("absy", 0x03AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CADC LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x3AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CADF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCADCu,0x80CADCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CADF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCADFu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCADFu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCADFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CADF TAX
    cpu.transfer("TAX");
    goto L_80CAE0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCADFu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCADFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CADF TAX
    cpu.transfer("TAX");
    goto L_80CAE0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCADFu,0x80CADFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CAE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAE0u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE0u,cpu,0xECu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE0u, 5u, 3u, cpu.address("abs", 0x096Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CAE0 CPX
    cpu.compareX(hw.readW(cpu.address("abs", 0x96Eu), cpu.x8?8:16));
    goto L_80CAE3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE0u,cpu,0xECu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE0u, 5u, 3u, cpu.address("abs", 0x096Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CAE0 CPX
    cpu.compareX(hw.readW(cpu.address("abs", 0x96Eu), cpu.x8?8:16));
    goto L_80CAE3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCAE0u,0x80CAE0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CAE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE3u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CAE3 BCC -> $80CAF4
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80CAF4; }
    goto L_80CAE5;
L_80CAE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE5u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE5u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CAE5 LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CAE9;
L_80CAE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CAE9 AND
    cpu.logicAnd(0x2000u);
    goto L_80CAEC;
L_80CAEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAECu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CAEC BNE -> $80CAF1
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80CAF1; }
    goto L_80CAEE;
L_80CAEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAEEu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAEEu, 3u, 3u, cpu.address("abs", 0xCAF4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CAEE JMP -> $80CAF4
    goto L_80CAF4;
L_80CAF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF1u, 6u, 3u, cpu.address("abs", 0xC591u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80CAF1 JSR -> $80C591 stack real
    { cpu.push16Value(hw,0xCAF3u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCAF4u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC591u), 0x80CAF1u); }
    goto L_80CAF4;
L_80CAF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAF4u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCAF4u,0x80CAF4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF4u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CAF4 DEY
    cpu.decReg('Y');
    goto L_80CAF5;
L_80CAF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF5u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CAF5 DEY
    cpu.decReg('Y');
    goto L_80CAF6;
L_80CAF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF6u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CAF6 BPL -> $80CADC
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80CADC; }
    goto L_80CAF8;
L_80CAF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF8u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CAF8 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80CAFA;
L_80CAFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAFAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAFAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CAFA LDA
    cpu.setA(0xFFFFu, 16);
    goto L_80CAFD;
L_80CAFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAFDu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAFDu, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CAFD STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80CB01;
L_80CB01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB01u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB01u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80CB01 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80CB01u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80CB01u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80CB02_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80CB02u: goto L_80CB02;
    case 0x80CB05u: goto L_80CB05;
    case 0x80CB07u: goto L_80CB07;
    case 0x80CB0Au: goto L_80CB0A;
    case 0x80CB0Cu: goto L_80CB0C;
    case 0x80CB0Eu: goto L_80CB0E;
    case 0x80CB11u: goto L_80CB11;
    case 0x80CB13u: goto L_80CB13;
    case 0x80CB16u: goto L_80CB16;
    case 0x80CB18u: goto L_80CB18;
    case 0x80CB1Cu: goto L_80CB1C;
    case 0x80CB1Eu: goto L_80CB1E;
    case 0x80CB1Fu: goto L_80CB1F;
    case 0x80CB20u: goto L_80CB20;
    case 0x80CB23u: goto L_80CB23;
    case 0x80CB25u: goto L_80CB25;
    case 0x80CB27u: goto L_80CB27;
    case 0x80CB2Bu: goto L_80CB2B;
    case 0x80CB2Eu: goto L_80CB2E;
    case 0x80CB30u: goto L_80CB30;
    case 0x80CB32u: goto L_80CB32;
    case 0x80CB33u: goto L_80CB33;
    case 0x80CB36u: goto L_80CB36;
    case 0x80CB3Au: goto L_80CB3A;
    case 0x80CB3Cu: goto L_80CB3C;
    case 0x80CB40u: goto L_80CB40;
    case 0x80CB43u: goto L_80CB43;
    case 0x80CB47u: goto L_80CB47;
    case 0x80CB49u: goto L_80CB49;
    case 0x80CB4Au: goto L_80CB4A;
    case 0x80CB4Du: goto L_80CB4D;
    case 0x80CB4Fu: goto L_80CB4F;
    case 0x80CB50u: goto L_80CB50;
    case 0x80CB53u: goto L_80CB53;
    case 0x80CB55u: goto L_80CB55;
    case 0x80CB59u: goto L_80CB59;
    case 0x80CB5Bu: goto L_80CB5B;
    case 0x80CB5Eu: goto L_80CB5E;
    case 0x80CB60u: goto L_80CB60;
    case 0x80CB64u: goto L_80CB64;
    case 0x80CB66u: goto L_80CB66;
    case 0x80CB6Au: goto L_80CB6A;
    case 0x80CB6Du: goto L_80CB6D;
    case 0x80CB6Fu: goto L_80CB6F;
    case 0x80CB70u: goto L_80CB70;
    case 0x80CB72u: goto L_80CB72;
    case 0x80CB76u: goto L_80CB76;
    case 0x80CB78u: goto L_80CB78;
    case 0x80CB7Cu: goto L_80CB7C;
    case 0x80CB7Fu: goto L_80CB7F;
    case 0x80CB83u: goto L_80CB83;
    case 0x80CB85u: goto L_80CB85;
    case 0x80CB87u: goto L_80CB87;
    case 0x80CB89u: goto L_80CB89;
    case 0x80CB8Bu: goto L_80CB8B;
    case 0x80CB8Du: goto L_80CB8D;
    case 0x80CB8Fu: goto L_80CB8F;
    case 0x80CB91u: goto L_80CB91;
    case 0x80CB94u: goto L_80CB94;
    case 0x80CB96u: goto L_80CB96;
    case 0x80CB99u: goto L_80CB99;
    case 0x80CB9Bu: goto L_80CB9B;
    case 0x80CB9Du: goto L_80CB9D;
    case 0x80CB9Eu: goto L_80CB9E;
    case 0x80CBA1u: goto L_80CBA1;
    case 0x80CBA3u: goto L_80CBA3;
    case 0x80CBA4u: goto L_80CBA4;
    case 0x80CBA5u: goto L_80CBA5;
    case 0x80CBA6u: goto L_80CBA6;
    case 0x80CBAAu: goto L_80CBAA;
    case 0x80CBACu: goto L_80CBAC;
    case 0x80CBAFu: goto L_80CBAF;
    case 0x80CBB1u: goto L_80CBB1;
    case 0x80CBB5u: goto L_80CBB5;
    case 0x80CBB7u: goto L_80CBB7;
    case 0x80CBBAu: goto L_80CBBA;
    case 0x80CBBCu: goto L_80CBBC;
    case 0x80CBBDu: goto L_80CBBD;
    case 0x80CBBEu: goto L_80CBBE;
    case 0x80CBC2u: goto L_80CBC2;
    case 0x80CBC4u: goto L_80CBC4;
    case 0x80CBC7u: goto L_80CBC7;
    case 0x80CBC9u: goto L_80CBC9;
    case 0x80CBCDu: goto L_80CBCD;
    case 0x80CBCFu: goto L_80CBCF;
    case 0x80CBD2u: goto L_80CBD2;
    case 0x80CBD4u: goto L_80CBD4;
    case 0x80CBD6u: goto L_80CBD6;
    case 0x80CBD8u: goto L_80CBD8;
    case 0x80CBDBu: goto L_80CBDB;
    case 0x80CBDFu: goto L_80CBDF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80CB02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB02u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB02u, 5u, 3u, cpu.address("abs", 0x098Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB02 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x98Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80CB05;
L_80CB05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB05u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB05u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB05 STX
    hw.write(cpu.address("dp", 0x61u), cpu.x, cpu.x8?8:16);
    goto L_80CB07;
L_80CB07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB07u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB07u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB07 LDA
    cpu.setA(0x6u, 16);
    goto L_80CB0A;
L_80CB0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB0Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB0Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB0A STA
    hw.write(cpu.address("dp", 0x63u), cpu.a, cpu.m8?8:16);
    goto L_80CB0C;
L_80CB0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB0Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB0Cu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB0Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB0C LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80CB0E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB0Cu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB0Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB0C LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80CB0E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCB0Cu,0x80CB0Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CB0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB0Eu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB0Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB0Eu, 6u, 3u, cpu.address("abs", 0xCBE0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80CB0E JSR -> $80CBE0 stack real
    { cpu.push16Value(hw,0xCB10u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCB11u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCBE0u), 0x80CB0Eu); }
    goto L_80CB11;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB0Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB0Eu, 6u, 3u, cpu.address("abs", 0xCBE0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80CB0E JSR -> $80CBE0 stack real
    { cpu.push16Value(hw,0xCB10u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCB11u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCBE0u), 0x80CB0Eu); }
    goto L_80CB11;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCB0Eu,0x80CB0Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CB11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB11u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB11u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB11u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB11 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80CB13;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB11u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB11u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB11 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80CB13;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCB11u,0x80CB11u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CB13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB13u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB13u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB13u, 6u, 3u, cpu.address("abs", 0xCC38u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80CB13 JSR -> $80CC38 stack real
    { cpu.push16Value(hw,0xCB15u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCB16u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCC38u), 0x80CB13u); }
    goto L_80CB16;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB13u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB13u, 6u, 3u, cpu.address("abs", 0xCC38u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80CB13 JSR -> $80CC38 stack real
    { cpu.push16Value(hw,0xCB15u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCB16u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCC38u), 0x80CB13u); }
    goto L_80CB16;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCB13u,0x80CB13u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CB16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB16u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB16u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB16u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB16 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80CB18;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB16u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB16u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB16 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80CB18;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCB16u,0x80CB16u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CB18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB18u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB18u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB18u, 6u, 4u, ((0x7E1FEAu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB18 LDA
    cpu.loadA(hw.readW(((0x7E1FEAu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CB1C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB18u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB18u, 6u, 4u, ((0x7E1FEAu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB18 LDA
    cpu.loadA(hw.readW(((0x7E1FEAu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CB1C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCB18u,0x80CB18u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CB1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB1Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB1Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB1Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB1C BEQ -> $80CB27
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80CB27; }
    goto L_80CB1E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB1Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB1Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB1C BEQ -> $80CB27
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80CB27; }
    goto L_80CB1E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCB1Cu,0x80CB1Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CB1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB1Eu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB1Eu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB1Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB1E TXA
    cpu.transfer("TXA");
    goto L_80CB1F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB1Eu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB1Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB1E TXA
    cpu.transfer("TXA");
    goto L_80CB1F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCB1Eu,0x80CB1Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CB1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB1Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB1Fu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB1Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB1F SEC
    cpu.setFlag('C', true);
    goto L_80CB20;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB1Fu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB1Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB1F SEC
    cpu.setFlag('C', true);
    goto L_80CB20;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCB1Fu,0x80CB1Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CB20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB20u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB20u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB20 SBC
    cpu.sbc(0x16u);
    goto L_80CB23;
L_80CB23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB23u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB23u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB23 STA
    hw.write(cpu.address("dp", 0x61u), cpu.a, cpu.m8?8:16);
    goto L_80CB25;
L_80CB25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB25u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB25u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB25 BRA -> $80CB0C
    goto L_80CB0C;
L_80CB27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB27u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB27u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB27u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB27 LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CB2B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB27u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB27u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB27 LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CB2B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCB27u,0x80CB27u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CB2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB2Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB2Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB2Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB2B AND
    cpu.logicAnd(0x300u);
    goto L_80CB2E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB2Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB2Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB2B AND
    cpu.logicAnd(0x300u);
    goto L_80CB2E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCB2Bu,0x80CB2Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CB2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB2Eu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB2Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB2Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB2E STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80CB30;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB2Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB2Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB2E STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80CB30;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCB2Eu,0x80CB2Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CB30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB30u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB30u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB30u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB30 STX
    hw.write(cpu.address("dp", 0x61u), cpu.x, cpu.x8?8:16);
    goto L_80CB32;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB30u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB30u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB30 STX
    hw.write(cpu.address("dp", 0x61u), cpu.x, cpu.x8?8:16);
    goto L_80CB32;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCB30u,0x80CB30u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CB32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB32u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB32u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB32u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB32 TXA
    cpu.transfer("TXA");
    goto L_80CB33;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB32u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB32u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB32 TXA
    cpu.transfer("TXA");
    goto L_80CB33;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCB32u,0x80CB32u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CB33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB33u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB33u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB33u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB33 LDX
    cpu.setX(0x0u, 16);
    goto L_80CB36;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB33u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB33u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB33 LDX
    cpu.setX(0x0u, 16);
    goto L_80CB36;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCB33u,0x80CB33u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CB36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB36u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB36u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB36u, 6u, 4u, ((0x7E2444u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB36 STA
    hw.write(((0x7E2444u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80CB3A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB36u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB36u, 6u, 4u, ((0x7E2444u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB36 STA
    hw.write(((0x7E2444u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80CB3A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCB36u,0x80CB36u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CB3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB3Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB3Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB3Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB3A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CB3C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB3Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB3Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB3A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CB3C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCB3Au,0x80CB3Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CB3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB3Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB3Cu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB3Cu, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB3C STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80CB40;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB3Cu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB3Cu, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB3C STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80CB40;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCB3Cu,0x80CB3Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CB40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB40u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB40u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB40u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB40 LDA
    cpu.setA(0x4u, 16);
    goto L_80CB43;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB40u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB40u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB40 LDA
    cpu.setA(0x4u, 16);
    goto L_80CB43;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCB40u,0x80CB40u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CB43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB43u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB43u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB43u, 6u, 4u, ((0x7E2442u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB43 STA
    hw.write(((0x7E2442u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80CB47;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB43u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB43u, 6u, 4u, ((0x7E2442u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB43 STA
    hw.write(((0x7E2442u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80CB47;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCB43u,0x80CB43u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CB47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB47u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB47u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB47u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB47 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x61u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CB49;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB47u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB47u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB47 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x61u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CB49;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCB47u,0x80CB47u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CB49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB49u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB49u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB49u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB49 SEC
    cpu.setFlag('C', true);
    goto L_80CB4A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB49u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB49u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB49 SEC
    cpu.setFlag('C', true);
    goto L_80CB4A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCB49u,0x80CB49u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CB4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB4Au,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB4Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB4A SBC
    cpu.sbc(0x16u);
    goto L_80CB4D;
L_80CB4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB4Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB4Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB4D STA
    hw.write(cpu.address("dp", 0x61u), cpu.a, cpu.m8?8:16);
    goto L_80CB4F;
L_80CB4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB4Fu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB4Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB4F TAX
    cpu.transfer("TAX");
    goto L_80CB50;
L_80CB50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB50u,cpu,0xECu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB50u, 5u, 3u, cpu.address("abs", 0x096Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB50 CPX
    cpu.compareX(hw.readW(cpu.address("abs", 0x96Eu), cpu.x8?8:16));
    goto L_80CB53;
L_80CB53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB53u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB53u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB53 BCC -> $80CB91
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80CB91; }
    goto L_80CB55;
L_80CB55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB55u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB55u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB55 LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CB59;
L_80CB59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB59u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB59u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB59 BEQ -> $80CB47
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80CB47; }
    goto L_80CB5B;
L_80CB5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB5Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB5Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB5B CMP
    cpu.compareA(0xFFFFu);
    goto L_80CB5E;
L_80CB5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB5Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB5Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB5E BEQ -> $80CB91
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80CB91; }
    goto L_80CB60;
L_80CB60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB60u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB60u, 6u, 4u, ((0x7E1FEAu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB60 LDA
    cpu.loadA(hw.readW(((0x7E1FEAu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CB64;
L_80CB64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB64u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB64u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB64 BNE -> $80CB47
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80CB47; }
    goto L_80CB66;
L_80CB66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB66u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB66u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB66 LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CB6A;
L_80CB6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB6Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB6Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB6A AND
    cpu.logicAnd(0x300u);
    goto L_80CB6D;
L_80CB6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB6Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB6Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB6D STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80CB6F;
L_80CB6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB6Fu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB6Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB6F TXA
    cpu.transfer("TXA");
    goto L_80CB70;
L_80CB70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB70u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB70u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB70 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80CB72;
L_80CB72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB72u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB72u, 6u, 4u, ((0x7E2444u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB72 STA
    hw.write(((0x7E2444u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80CB76;
L_80CB76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB76u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB76u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB76 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CB78;
L_80CB78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB78u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB78u, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB78 STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80CB7C;
L_80CB7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB7Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB7Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB7C LDA
    cpu.setA(0x4u, 16);
    goto L_80CB7F;
L_80CB7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB7Fu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB7Fu, 6u, 4u, ((0x7E2442u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB7F STA
    hw.write(((0x7E2442u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80CB83;
L_80CB83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB83u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB83u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB83 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80CB85;
L_80CB85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB85u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB85u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB85 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80CB87;
L_80CB87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB87u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB87u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB87 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80CB89;
L_80CB89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB89u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB89u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB89 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80CB8B;
L_80CB8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB8Bu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB8Bu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB8B INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80CB8D;
L_80CB8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB8Du,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB8Du, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB8D INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80CB8F;
L_80CB8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB8Fu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB8Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB8F BRA -> $80CB47
    goto L_80CB47;
L_80CB91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB91u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB91u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB91 LDA
    cpu.setA(0x8u, 16);
    goto L_80CB94;
L_80CB94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB94u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB94u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB94 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80CB96;
L_80CB96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB96u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB96u, 5u, 3u, cpu.address("abs", 0x098Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB96 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x98Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80CB99;
L_80CB99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB99u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB99u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB99 STX
    hw.write(cpu.address("dp", 0x61u), cpu.x, cpu.x8?8:16);
    goto L_80CB9B;
L_80CB9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB9Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB9Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB9B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x61u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CB9D;
L_80CB9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB9Du,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB9Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB9D SEC
    cpu.setFlag('C', true);
    goto L_80CB9E;
L_80CB9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB9Eu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB9Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CB9E SBC
    cpu.sbc(0x16u);
    goto L_80CBA1;
L_80CBA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBA1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBA1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CBA1 STA
    hw.write(cpu.address("dp", 0x61u), cpu.a, cpu.m8?8:16);
    goto L_80CBA3;
L_80CBA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBA3u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBA3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CBA3 TAX
    cpu.transfer("TAX");
    goto L_80CBA4;
L_80CBA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBA4u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBA4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CBA4 DEX
    cpu.decReg('X');
    goto L_80CBA5;
L_80CBA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBA5u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBA5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CBA5 DEX
    cpu.decReg('X');
    goto L_80CBA6;
L_80CBA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBA6u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBA6u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CBA6 LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CBAA;
L_80CBAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBAAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBAAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CBAA BEQ -> $80CBA4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80CBA4; }
    goto L_80CBAC;
L_80CBAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBACu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBACu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CBAC CMP
    cpu.compareA(0xFFFFu);
    goto L_80CBAF;
L_80CBAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBAFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBAFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CBAF BEQ -> $80CBBA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80CBBA; }
    goto L_80CBB1;
L_80CBB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBB1u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBB1u, 6u, 4u, ((0x7E1FEAu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CBB1 LDA
    cpu.loadA(hw.readW(((0x7E1FEAu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CBB5;
L_80CBB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBB5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBB5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CBB5 BEQ -> $80CBA4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80CBA4; }
    goto L_80CBB7;
L_80CBB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBB7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBB7u, 6u, 3u, cpu.address("abs", 0xCC38u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80CBB7 JSR -> $80CC38 stack real
    { cpu.push16Value(hw,0xCBB9u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCBBAu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCC38u), 0x80CBB7u); }
    goto L_80CBBA;
L_80CBBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBBAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCBBAu,0x80CBBAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBBAu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBBAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CBBA LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80CBBC;
L_80CBBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBBCu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBBCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CBBC INX
    cpu.inc('X');
    goto L_80CBBD;
L_80CBBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBBDu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBBDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CBBD INX
    cpu.inc('X');
    goto L_80CBBE;
L_80CBBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBBEu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBBEu, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CBBE LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CBC2;
L_80CBC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBC2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBC2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CBC2 BEQ -> $80CBBC
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80CBBC; }
    goto L_80CBC4;
L_80CBC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBC4u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBC4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CBC4 CMP
    cpu.compareA(0xFFFFu);
    goto L_80CBC7;
L_80CBC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBC7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBC7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CBC7 BEQ -> $80CBD2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80CBD2; }
    goto L_80CBC9;
L_80CBC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBC9u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBC9u, 6u, 4u, ((0x7E1FEAu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CBC9 LDA
    cpu.loadA(hw.readW(((0x7E1FEAu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CBCD;
L_80CBCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBCDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBCDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CBCD BEQ -> $80CBBC
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80CBBC; }
    goto L_80CBCF;
L_80CBCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBCFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBCFu, 6u, 3u, cpu.address("abs", 0xCBE0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80CBCF JSR -> $80CBE0 stack real
    { cpu.push16Value(hw,0xCBD1u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCBD2u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCBE0u), 0x80CBCFu); }
    goto L_80CBD2;
L_80CBD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBD2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCBD2u,0x80CBD2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBD2u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBD2u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CBD2 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_80CBD4;
L_80CBD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBD4u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBD4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CBD4 BPL -> $80CB9B
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80CB9B; }
    goto L_80CBD6;
L_80CBD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBD6u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBD6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CBD6 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80CBD8;
L_80CBD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBD8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBD8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CBD8 LDA
    cpu.setA(0xFFFFu, 16);
    goto L_80CBDB;
L_80CBDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBDBu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBDBu, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CBDB STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80CBDF;
L_80CBDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCBDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCBDFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCBDFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80CBDF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80CBDFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80CBDFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_829146_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829146u: goto L_829146;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829146:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9146u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9146u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9146u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829146 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829146u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829146u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_829230_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829230u: goto L_829230;
    case 0x829232u: goto L_829232;
    case 0x829234u: goto L_829234;
    case 0x829236u: goto L_829236;
    case 0x829239u: goto L_829239;
    case 0x82923Au: goto L_82923A;
    case 0x82923Bu: goto L_82923B;
    case 0x82923Eu: goto L_82923E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829230:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9230u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9230u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9230u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829230 SEP
    cpu.sep(0x20u);
    goto L_829232;
L_829232:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9232u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9232u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9232u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829232 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x49u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829234;
L_829234:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9234u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9234u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9234u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829234 REP
    cpu.rep(0x20u);
    goto L_829236;
L_829236:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9236u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9236u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9236u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829236 AND
    cpu.logicAnd(0xFFu);
    goto L_829239;
L_829239:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9239u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9239u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9239u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829239 ASL
    cpu.aslA();
    goto L_82923A;
L_82923A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Au,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82923A TAX
    cpu.transfer("TAX");
    goto L_82923B;
L_82923B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Bu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Bu, 5u, 3u, cpu.address("abs", 0x9240u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82923B PEA
    cpu.push16Value(hw, 0x9240u);
    goto L_82923E;
L_82923E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Eu,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Eu, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x9258u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $82923E JMP (9258,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x9258u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x82923Eu); return; }
}

void sub_829230_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829230u: goto L_829230;
    case 0x829232u: goto L_829232;
    case 0x829234u: goto L_829234;
    case 0x829236u: goto L_829236;
    case 0x829239u: goto L_829239;
    case 0x82923Au: goto L_82923A;
    case 0x82923Bu: goto L_82923B;
    case 0x82923Eu: goto L_82923E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829230:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9230u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9230u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9230u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829230 SEP
    cpu.sep(0x20u);
    goto L_829232;
L_829232:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9232u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9232u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9232u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829232 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x49u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829234;
L_829234:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9234u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9234u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9234u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829234 REP
    cpu.rep(0x20u);
    goto L_829236;
L_829236:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9236u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9236u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9236u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829236 AND
    cpu.logicAnd(0xFFu);
    goto L_829239;
L_829239:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9239u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9239u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9239u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829239 ASL
    cpu.aslA();
    goto L_82923A;
L_82923A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Au,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82923A TAX
    cpu.transfer("TAX");
    goto L_82923B;
L_82923B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Bu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Bu, 5u, 3u, cpu.address("abs", 0x9240u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82923B PEA
    cpu.push16Value(hw, 0x9240u);
    goto L_82923E;
L_82923E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Eu,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Eu, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x9258u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $82923E JMP (9258,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x9258u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x82923Eu); return; }
}

void sub_829AAA_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829AAAu: goto L_829AAA;
    case 0x829AACu: goto L_829AAC;
    case 0x829AAEu: goto L_829AAE;
    case 0x829AB0u: goto L_829AB0;
    case 0x829AB3u: goto L_829AB3;
    case 0x829AB5u: goto L_829AB5;
    case 0x829AB7u: goto L_829AB7;
    case 0x829AB9u: goto L_829AB9;
    case 0x829ABBu: goto L_829ABB;
    case 0x829ABCu: goto L_829ABC;
    case 0x829ABEu: goto L_829ABE;
    case 0x829ABFu: goto L_829ABF;
    case 0x829AC2u: goto L_829AC2;
    case 0x829AC3u: goto L_829AC3;
    case 0x829AC5u: goto L_829AC5;
    case 0x829AC7u: goto L_829AC7;
    case 0x829ACAu: goto L_829ACA;
    case 0x829ACDu: goto L_829ACD;
    case 0x829ACFu: goto L_829ACF;
    case 0x829AD2u: goto L_829AD2;
    case 0x829AD3u: goto L_829AD3;
    case 0x829AD4u: goto L_829AD4;
    case 0x829AD5u: goto L_829AD5;
    case 0x829AD6u: goto L_829AD6;
    case 0x829AD7u: goto L_829AD7;
    case 0x829AD8u: goto L_829AD8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829AAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AAAu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AAAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AAA SEP
    cpu.sep(0x20u);
    goto L_829AAC;
L_829AAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AACu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AACu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AAC LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829AAE;
L_829AAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AAEu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AAEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AAE LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829AB0;
L_829AB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AB0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AB0u, 4u + 1u, 3u, cpu.address("absy", 0x0240u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AB0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x240u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829AB3;
L_829AB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AB3u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AB3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AB3 BPL -> $829ABC
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_829ABC; }
    goto L_829AB5;
L_829AB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AB5u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AB5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AB5 CMP
    cpu.compareA(0x80u);
    goto L_829AB7;
L_829AB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AB7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AB7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AB7 BNE -> $829AD2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829AD2; }
    goto L_829AB9;
L_829AB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AB9u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AB9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AB9 REP
    cpu.rep(0x20u);
    goto L_829ABB;
L_829ABB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ABBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ABBu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ABBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829ABB RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829ABBu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829ABBu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_829ABC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ABCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ABCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ABCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829ABC LDA
    cpu.setA(0x0u, 8);
    goto L_829ABE;
L_829ABE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ABEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ABEu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ABEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829ABE SEC
    cpu.setFlag('C', true);
    goto L_829ABF;
L_829ABF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ABFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ABFu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ABFu, 4u + 1u, 3u, cpu.address("absy", 0x0243u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829ABF SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x243u), cpu.m8?8:16));
    goto L_829AC2;
L_829AC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AC2 SEC
    cpu.setFlag('C', true);
    goto L_829AC3;
L_829AC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC3u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AC3 SBC
    cpu.sbc(0x8u);
    goto L_829AC5;
L_829AC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AC5 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_829AC7;
L_829AC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC7u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AC7u, 4u + 1u, 3u, cpu.address("absy", 0x0242u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AC7 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x242u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829ACA;
L_829ACA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ACAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ACAu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ACAu, 5u, 3u, cpu.address("absy", 0x0243u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829ACA STA
    hw.write(cpu.address("absy", 0x243u), cpu.a, cpu.m8?8:16);
    goto L_829ACD;
L_829ACD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ACDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ACDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ACDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829ACD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829ACF;
L_829ACF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ACFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ACFu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ACFu, 5u, 3u, cpu.address("absy", 0x0242u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829ACF STA
    hw.write(cpu.address("absy", 0x242u), cpu.a, cpu.m8?8:16);
    goto L_829AD2;
L_829AD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AD2u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AD2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AD2 INY
    cpu.inc('Y');
    goto L_829AD3;
L_829AD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AD3u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AD3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AD3 INY
    cpu.inc('Y');
    goto L_829AD4;
L_829AD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AD4u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AD4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AD4 INY
    cpu.inc('Y');
    goto L_829AD5;
L_829AD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AD5u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AD5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AD5 INY
    cpu.inc('Y');
    goto L_829AD6;
L_829AD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AD6u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AD6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AD6 INY
    cpu.inc('Y');
    goto L_829AD7;
L_829AD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AD7u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AD7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AD7 INY
    cpu.inc('Y');
    goto L_829AD8;
L_829AD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AD8u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AD8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AD8 BRA -> $829AB0
    goto L_829AB0;
}

void sub_829E4A_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829E4Au: goto L_829E4A;
    case 0x829E4Cu: goto L_829E4C;
    case 0x829E4Eu: goto L_829E4E;
    case 0x829E51u: goto L_829E51;
    case 0x829E53u: goto L_829E53;
    case 0x829E56u: goto L_829E56;
    case 0x829E58u: goto L_829E58;
    case 0x829E5Bu: goto L_829E5B;
    case 0x829E5Du: goto L_829E5D;
    case 0x829E5Fu: goto L_829E5F;
    case 0x829E61u: goto L_829E61;
    case 0x829E64u: goto L_829E64;
    case 0x829E66u: goto L_829E66;
    case 0x829E67u: goto L_829E67;
    case 0x829E69u: goto L_829E69;
    case 0x829E6Bu: goto L_829E6B;
    case 0x829E6Cu: goto L_829E6C;
    case 0x829E6Du: goto L_829E6D;
    case 0x829E6Fu: goto L_829E6F;
    case 0x829E72u: goto L_829E72;
    case 0x829E75u: goto L_829E75;
    case 0x829E76u: goto L_829E76;
    case 0x829E77u: goto L_829E77;
    case 0x829E7Au: goto L_829E7A;
    case 0x829E7Eu: goto L_829E7E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829E4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E4Au,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E4Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E4A LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829E4C;
L_829E4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E4Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E4Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E4C BNE -> $829E53
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829E53; }
    goto L_829E4E;
L_829E4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E4Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E4Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E4E LDA
    cpu.setA(0x7000u, 16);
    goto L_829E51;
L_829E51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E51u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E51u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E51 BRA -> $829E56
    goto L_829E56;
L_829E53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E53u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E53u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E53 LDA
    cpu.setA(0x7200u, 16);
    goto L_829E56;
L_829E56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E56u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E56u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E56 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_829E58;
L_829E58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E58u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E58u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E58 LDA
    cpu.setA(0x7Eu, 16);
    goto L_829E5B;
L_829E5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E5Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E5Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E5B STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_829E5D;
L_829E5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E5Du,cpu,0xA7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E5Du, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $829E5D LDA
    cpu.loadA(hw.readW(cpu.addressDpLong(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829E5F;
L_829E5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E5Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E5Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E5F BPL -> $829E66
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_829E66; }
    goto L_829E61;
L_829E61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E61u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E61u, 9u, 3u, cpu.address("absx", 0x0200u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E61 INC
    cpu.incMem(hw, cpu.address("absx", 0x200u), cpu.m8?8:16);
    goto L_829E64;
L_829E64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E64u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E64u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E64 BRA -> $829E7E
    goto L_829E7E;
L_829E66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E66u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E66u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $829E66 PHB
    cpu.push("PHB", hw);
    goto L_829E67;
L_829E67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E67u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E67u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E67 SEP
    cpu.sep(0x20u);
    goto L_829E69;
L_829E69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E69u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E69u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x69u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E69 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x69u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829E6B;
L_829E6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E6Bu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E6Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $829E6B PHA
    cpu.push("PHA", hw);
    goto L_829E6C;
L_829E6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E6Cu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E6Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $829E6C PLB
    cpu.pop("PLB", hw);
    goto L_829E6D;
L_829E6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E6Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E6Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E6D REP
    cpu.rep(0x20u);
    goto L_829E6F;
L_829E6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E6Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E6Fu, 5u + 1u, 3u, cpu.address("absx", 0x02C8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E6F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2C8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829E72;
L_829E72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E72u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E72u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E72 AND
    cpu.logicAnd(0xFFu);
    goto L_829E75;
L_829E75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E75u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E75u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E75 ASL
    cpu.aslA();
    goto L_829E76;
L_829E76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E76u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E76u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E76 TAX
    cpu.transfer("TAX");
    goto L_829E77;
L_829E77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E77u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E77u, 5u, 3u, cpu.address("abs", 0x9E7Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829E77 PEA
    cpu.push16Value(hw, 0x9E7Cu);
    goto L_829E7A;
L_829E7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Au,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Au, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x9E7Fu + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $829E7A JMP (9E7F,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x9E7Fu+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x829E7Au); return; }
L_829E7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829E7E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829E7Eu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829E7Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_829E93_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829E93u: goto L_829E93;
    case 0x829E95u: goto L_829E95;
    case 0x829E98u: goto L_829E98;
    case 0x829E9Bu: goto L_829E9B;
    case 0x829E9Eu: goto L_829E9E;
    case 0x829EA0u: goto L_829EA0;
    case 0x829EA3u: goto L_829EA3;
    case 0x829EA6u: goto L_829EA6;
    case 0x829EA9u: goto L_829EA9;
    case 0x829EABu: goto L_829EAB;
    case 0x829EAEu: goto L_829EAE;
    case 0x829EB0u: goto L_829EB0;
    case 0x829EB2u: goto L_829EB2;
    case 0x829EB4u: goto L_829EB4;
    case 0x829EB7u: goto L_829EB7;
    case 0x829EB9u: goto L_829EB9;
    case 0x829EBCu: goto L_829EBC;
    case 0x829EBFu: goto L_829EBF;
    case 0x829EC0u: goto L_829EC0;
    case 0x829EC3u: goto L_829EC3;
    case 0x829EC6u: goto L_829EC6;
    case 0x829EC8u: goto L_829EC8;
    case 0x829EC9u: goto L_829EC9;
    case 0x829ECCu: goto L_829ECC;
    case 0x829ECFu: goto L_829ECF;
    case 0x829ED1u: goto L_829ED1;
    case 0x829ED2u: goto L_829ED2;
    case 0x829ED3u: goto L_829ED3;
    case 0x829ED4u: goto L_829ED4;
    case 0x829ED6u: goto L_829ED6;
    case 0x829ED9u: goto L_829ED9;
    case 0x829EDBu: goto L_829EDB;
    case 0x829EDEu: goto L_829EDE;
    case 0x829EE1u: goto L_829EE1;
    case 0x829EE4u: goto L_829EE4;
    case 0x829EE7u: goto L_829EE7;
    case 0x829EE9u: goto L_829EE9;
    case 0x829EECu: goto L_829EEC;
    case 0x829EEDu: goto L_829EED;
    case 0x829EEFu: goto L_829EEF;
    case 0x829EF2u: goto L_829EF2;
    case 0x829EF5u: goto L_829EF5;
    case 0x829EF8u: goto L_829EF8;
    case 0x829EFBu: goto L_829EFB;
    case 0x829EFEu: goto L_829EFE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829E93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E93u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E93u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E93 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829E95;
L_829E95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E95u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E95u, 5u + 1u, 3u, cpu.address("absx", 0x02DCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E95 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2DCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829E98;
L_829E98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E98u,cpu,0x3Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E98u, 5u + 1u, 3u, cpu.address("absx", 0x02DEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E98 AND
    cpu.logicAnd(hw.readW(cpu.address("absx", 0x2DEu), cpu.m8?8:16));
    goto L_829E9B;
L_829E9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E9Bu,cpu,0x3Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E9Bu, 5u + 1u, 3u, cpu.address("absx", 0x02E0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E9B AND
    cpu.logicAnd(hw.readW(cpu.address("absx", 0x2E0u), cpu.m8?8:16));
    goto L_829E9E;
L_829E9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E9Eu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E9Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829E9E BMI -> $829EB4
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_829EB4; }
    goto L_829EA0;
L_829EA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA0u, 6u, 3u, cpu.address("abs", 0xE02Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829EA0 JSR -> $82E02E stack real
    { cpu.push16Value(hw,0x9EA2u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9EA3u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE02Eu), 0x829EA0u); }
    goto L_829EA3;
L_829EA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA3u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA3u, 6u, 3u, cpu.address("abs", 0xE0BFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829EA3 JSR -> $82E0BF stack real
    { cpu.push16Value(hw,0x9EA5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9EA6u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE0BFu), 0x829EA3u); }
    goto L_829EA6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA3u, 6u, 3u, cpu.address("abs", 0xE0BFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829EA3 JSR -> $82E0BF stack real
    { cpu.push16Value(hw,0x9EA5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9EA6u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE0BFu), 0x829EA3u); }
    goto L_829EA6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EA3u,0x829EA3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829EA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EA6u,0x829EA6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA6u, 6u, 3u, cpu.address("abs", 0xE04Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829EA6 JSR -> $82E04E stack real
    { cpu.push16Value(hw,0x9EA8u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9EA9u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE04Eu), 0x829EA6u); }
    goto L_829EA9;
L_829EA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EA9u,0x829EA9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA9u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829EA9 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829EAB;
L_829EAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EABu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EABu, 6u, 3u, cpu.address("absx", 0x02C8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829EAB STZ
    hw.write(cpu.address("absx", 0x2C8u), 0, cpu.m8?8:16);
    goto L_829EAE;
L_829EAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EAEu,cpu,0xA7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EAEu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $829EAE LDA
    cpu.loadA(hw.readW(cpu.addressDpLong(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829EB0;
L_829EB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB0u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829EB0 BMI -> $829EEC
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_829EEC; }
    goto L_829EB2;
L_829EB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB2u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829EB2 BRA -> $829EE9
    goto L_829EE9;
L_829EB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB4u, 5u + 1u, 3u, cpu.address("absx", 0x02E8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829EB4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2E8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829EB7;
L_829EB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829EB7 BEQ -> $829EC0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_829EC0; }
    goto L_829EB9;
L_829EB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829EB9 LDA
    cpu.setA(0xCu, 16);
    goto L_829EBC;
L_829EBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBCu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBCu, 6u, 3u, cpu.address("absx", 0x0200u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829EBC STA
    hw.write(cpu.address("absx", 0x200u), cpu.a, cpu.m8?8:16);
    goto L_829EBF;
L_829EBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829EBF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829EBFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829EBFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_829EC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC0u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829EC0 LDY
    cpu.setY(0x2u, 16);
    goto L_829EC3;
L_829EC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829EC3 LDA
    cpu.setA(0x4u, 16);
    goto L_829EC6;
L_829EC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC6u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829EC6 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16));
    goto L_829EC8;
L_829EC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC8u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829EC8 TAX
    cpu.transfer("TAX");
    goto L_829EC9;
L_829EC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC9u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC9u, 5u + 1u, 3u, cpu.address("absx", 0x02BCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829EC9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2BCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829ECC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC9u, 5u + 1u, 3u, cpu.address("absx", 0x02BCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829EC9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2BCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829ECC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EC9u,0x829EC9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829ECC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ECCu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECCu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829ECC CMP
    cpu.compareA(0x8080u);
    goto L_829ECF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECCu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829ECC CMP
    cpu.compareA(0x8080u);
    goto L_829ECF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9ECCu,0x829ECCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829ECF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ECFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829ECF BNE -> $829EED
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829EED; }
    goto L_829ED1;
L_829ED1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED1u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829ED1 DEX
    cpu.decReg('X');
    goto L_829ED2;
L_829ED2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED2u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829ED2 DEX
    cpu.decReg('X');
    goto L_829ED3;
L_829ED3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED3u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829ED3 DEY
    cpu.decReg('Y');
    goto L_829ED4;
L_829ED4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED4u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829ED4 BPL -> $829EC9
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_829EC9; }
    goto L_829ED6;
L_829ED6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED6u, 6u, 3u, cpu.address("abs", 0xB9BEu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829ED6 JSR -> $82B9BE stack real
    { cpu.push16Value(hw,0x9ED8u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9ED9u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB9BEu), 0x829ED6u); }
    goto L_829ED9;
L_829ED9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9ED9u,0x829ED9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED9u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829ED9 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829EDB;
L_829EDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDBu,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDBu, 9u, 3u, cpu.address("absx", 0x0420u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829EDB INC
    cpu.incMem(hw, cpu.address("absx", 0x420u), cpu.m8?8:16);
    goto L_829EDE;
L_829EDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDEu, 5u + 1u, 3u, cpu.address("absx", 0x02DCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829EDE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2DCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829EE1;
L_829EE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE1u,cpu,0x3Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE1u, 5u + 1u, 3u, cpu.address("absx", 0x02DEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829EE1 AND
    cpu.logicAnd(hw.readW(cpu.address("absx", 0x2DEu), cpu.m8?8:16));
    goto L_829EE4;
L_829EE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE4u,cpu,0x3Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE4u, 5u + 1u, 3u, cpu.address("absx", 0x02E0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829EE4 AND
    cpu.logicAnd(hw.readW(cpu.address("absx", 0x2E0u), cpu.m8?8:16));
    goto L_829EE7;
L_829EE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE7u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829EE7 BMI -> $829EEC
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_829EEC; }
    goto L_829EE9;
L_829EE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE9u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE9u, 9u, 3u, cpu.address("absx", 0x0200u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829EE9 DEC
    cpu.decMem(hw, cpu.address("absx", 0x200u), cpu.m8?8:16);
    goto L_829EEC;
L_829EEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EECu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EECu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829EEC RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829EECu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829EECu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_829EED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EEDu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EEDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829EED LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829EEF;
L_829EEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EEFu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EEFu, 6u, 3u, cpu.address("absx", 0x02ECu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829EEF STZ
    hw.write(cpu.address("absx", 0x2ECu), 0, cpu.m8?8:16);
    goto L_829EF2;
L_829EF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF2u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF2u, 6u, 3u, cpu.address("absx", 0x02EEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829EF2 STZ
    hw.write(cpu.address("absx", 0x2EEu), 0, cpu.m8?8:16);
    goto L_829EF5;
L_829EF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF5u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF5u, 6u, 3u, cpu.address("absx", 0x02F0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829EF5 STZ
    hw.write(cpu.address("absx", 0x2F0u), 0, cpu.m8?8:16);
    goto L_829EF8;
L_829EF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF8u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF8u, 9u, 3u, cpu.address("absx", 0x0200u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829EF8 INC
    cpu.incMem(hw, cpu.address("absx", 0x200u), cpu.m8?8:16);
    goto L_829EFB;
L_829EFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFBu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFBu, 6u, 3u, cpu.address("absx", 0x02CCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829EFB STZ
    hw.write(cpu.address("absx", 0x2CCu), 0, cpu.m8?8:16);
    goto L_829EFE;
L_829EFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829EFE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829EFEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829EFEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B2E4_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B2E4u: goto L_82B2E4;
    case 0x82B2E6u: goto L_82B2E6;
    case 0x82B2E8u: goto L_82B2E8;
    case 0x82B2EAu: goto L_82B2EA;
    case 0x82B2ECu: goto L_82B2EC;
    case 0x82B2EEu: goto L_82B2EE;
    case 0x82B2F1u: goto L_82B2F1;
    case 0x82B2F3u: goto L_82B2F3;
    case 0x82B2F5u: goto L_82B2F5;
    case 0x82B2F8u: goto L_82B2F8;
    case 0x82B2F9u: goto L_82B2F9;
    case 0x82B2FCu: goto L_82B2FC;
    case 0x82B2FDu: goto L_82B2FD;
    case 0x82B2FFu: goto L_82B2FF;
    case 0x82B302u: goto L_82B302;
    case 0x82B305u: goto L_82B305;
    case 0x82B306u: goto L_82B306;
    case 0x82B309u: goto L_82B309;
    case 0x82B30Au: goto L_82B30A;
    case 0x82B30Cu: goto L_82B30C;
    case 0x82B30Fu: goto L_82B30F;
    case 0x82B311u: goto L_82B311;
    case 0x82B314u: goto L_82B314;
    case 0x82B317u: goto L_82B317;
    case 0x82B31Au: goto L_82B31A;
    case 0x82B31Du: goto L_82B31D;
    case 0x82B31Eu: goto L_82B31E;
    case 0x82B31Fu: goto L_82B31F;
    case 0x82B320u: goto L_82B320;
    case 0x82B321u: goto L_82B321;
    case 0x82B322u: goto L_82B322;
    case 0x82B323u: goto L_82B323;
    case 0x82B324u: goto L_82B324;
    case 0x82B325u: goto L_82B325;
    case 0x82B327u: goto L_82B327;
    case 0x82B329u: goto L_82B329;
    case 0x82B32Bu: goto L_82B32B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B2E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E4u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2E4 SEP
    cpu.sep(0x20u);
    goto L_82B2E6;
L_82B2E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E6u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2E6 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B2E8;
L_82B2E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E8u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2E8 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B2EA;
L_82B2EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2EA LDA
    cpu.setA(0x3u, 8);
    goto L_82B2EC;
L_82B2EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2ECu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2ECu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2EC STA
    hw.write(cpu.address("dp", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_82B2EE;
L_82B2EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2EEu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EEu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EEu, 4u + 1u, 3u, cpu.address("absy", 0x0208u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2EE LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x208u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B2F1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EEu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EEu, 4u + 1u, 3u, cpu.address("absy", 0x0208u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2EE LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x208u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B2F1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2EEu,0x82B2EEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B2F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F1u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2F1 CMP
    cpu.compareA(0x1u);
    goto L_82B2F3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2F1 CMP
    cpu.compareA(0x1u);
    goto L_82B2F3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2F1u,0x82B2F1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B2F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2F3 BNE -> $82B31D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B31D; }
    goto L_82B2F5;
L_82B2F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F5u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F5u, 4u + 1u, 3u, cpu.address("absy", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2F5 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x20Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B2F8;
L_82B2F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F8u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2F8 CLC
    cpu.setFlag('C', false);
    goto L_82B2F9;
L_82B2F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F9u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F9u, 4u + 1u, 3u, cpu.address("absx", 0x0276u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2F9 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x276u), cpu.m8?8:16));
    goto L_82B2FC;
L_82B2FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FCu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2FC CLC
    cpu.setFlag('C', false);
    goto L_82B2FD;
L_82B2FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FDu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2FD ADC
    cpu.adc(0x4u);
    goto L_82B2FF;
L_82B2FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FFu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FFu, 5u, 3u, cpu.address("absx", 0x0276u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2FF STA
    hw.write(cpu.address("absx", 0x276u), cpu.a, cpu.m8?8:16);
    goto L_82B302;
L_82B302:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB302u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB302u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB302u, 4u + 1u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B302 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x20Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B305;
L_82B305:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB305u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB305u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB305u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B305 CLC
    cpu.setFlag('C', false);
    goto L_82B306;
L_82B306:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB306u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB306u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB306u, 4u + 1u, 3u, cpu.address("absx", 0x027Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B306 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x27Eu), cpu.m8?8:16));
    goto L_82B309;
L_82B309:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB309u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB309u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB309u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B309 CLC
    cpu.setFlag('C', false);
    goto L_82B30A;
L_82B30A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB30Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Au,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B30A ADC
    cpu.adc(0x4u);
    goto L_82B30C;
L_82B30C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB30Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Cu, 5u, 3u, cpu.address("absx", 0x027Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B30C STA
    hw.write(cpu.address("absx", 0x27Eu), cpu.a, cpu.m8?8:16);
    goto L_82B30F;
L_82B30F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB30Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B30F LDA
    cpu.setA(0xFCu, 8);
    goto L_82B311;
L_82B311:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB311u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB311u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB311u, 5u, 3u, cpu.address("absy", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B311 STA
    hw.write(cpu.address("absy", 0x20Au), cpu.a, cpu.m8?8:16);
    goto L_82B314;
L_82B314:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB314u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB314u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB314u, 5u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B314 STA
    hw.write(cpu.address("absy", 0x20Bu), cpu.a, cpu.m8?8:16);
    goto L_82B317;
L_82B317:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB317u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB317u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB317u, 5u, 3u, cpu.address("absy", 0x0226u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B317 STA
    hw.write(cpu.address("absy", 0x226u), cpu.a, cpu.m8?8:16);
    goto L_82B31A;
L_82B31A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB31Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Au,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Au, 5u, 3u, cpu.address("absy", 0x0227u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B31A STA
    hw.write(cpu.address("absy", 0x227u), cpu.a, cpu.m8?8:16);
    goto L_82B31D;
L_82B31D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB31Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Du,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B31D INY
    cpu.inc('Y');
    goto L_82B31E;
L_82B31E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB31Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Eu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B31E INY
    cpu.inc('Y');
    goto L_82B31F;
L_82B31F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB31Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B31F INY
    cpu.inc('Y');
    goto L_82B320;
L_82B320:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB320u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB320u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB320u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B320 INY
    cpu.inc('Y');
    goto L_82B321;
L_82B321:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB321u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB321u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB321u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B321 INY
    cpu.inc('Y');
    goto L_82B322;
L_82B322:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB322u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB322u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB322u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B322 INY
    cpu.inc('Y');
    goto L_82B323;
L_82B323:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB323u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB323u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB323u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B323 INX
    cpu.inc('X');
    goto L_82B324;
L_82B324:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB324u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB324u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB324u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B324 INX
    cpu.inc('X');
    goto L_82B325;
L_82B325:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB325u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB325u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB325u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B325 DEC
    cpu.decMem(hw, cpu.address("dp", 0x1Au), cpu.m8?8:16);
    goto L_82B327;
L_82B327:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB327u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB327u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB327u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B327 BPL -> $82B2EE
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82B2EE; }
    goto L_82B329;
L_82B329:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB329u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB329u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB329u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B329 REP
    cpu.rep(0x20u);
    goto L_82B32B;
L_82B32B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB32Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB32Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB32Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B32B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B32Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B32Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B2E4_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B2E4u: goto L_82B2E4;
    case 0x82B2E6u: goto L_82B2E6;
    case 0x82B2E8u: goto L_82B2E8;
    case 0x82B2EAu: goto L_82B2EA;
    case 0x82B2ECu: goto L_82B2EC;
    case 0x82B2EEu: goto L_82B2EE;
    case 0x82B2F1u: goto L_82B2F1;
    case 0x82B2F3u: goto L_82B2F3;
    case 0x82B2F5u: goto L_82B2F5;
    case 0x82B2F8u: goto L_82B2F8;
    case 0x82B2F9u: goto L_82B2F9;
    case 0x82B2FCu: goto L_82B2FC;
    case 0x82B2FDu: goto L_82B2FD;
    case 0x82B2FFu: goto L_82B2FF;
    case 0x82B302u: goto L_82B302;
    case 0x82B305u: goto L_82B305;
    case 0x82B306u: goto L_82B306;
    case 0x82B309u: goto L_82B309;
    case 0x82B30Au: goto L_82B30A;
    case 0x82B30Cu: goto L_82B30C;
    case 0x82B30Fu: goto L_82B30F;
    case 0x82B311u: goto L_82B311;
    case 0x82B314u: goto L_82B314;
    case 0x82B317u: goto L_82B317;
    case 0x82B31Au: goto L_82B31A;
    case 0x82B31Du: goto L_82B31D;
    case 0x82B31Eu: goto L_82B31E;
    case 0x82B31Fu: goto L_82B31F;
    case 0x82B320u: goto L_82B320;
    case 0x82B321u: goto L_82B321;
    case 0x82B322u: goto L_82B322;
    case 0x82B323u: goto L_82B323;
    case 0x82B324u: goto L_82B324;
    case 0x82B325u: goto L_82B325;
    case 0x82B327u: goto L_82B327;
    case 0x82B329u: goto L_82B329;
    case 0x82B32Bu: goto L_82B32B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B2E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E4u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2E4 SEP
    cpu.sep(0x20u);
    goto L_82B2E6;
L_82B2E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E6u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2E6 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B2E8;
L_82B2E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E8u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2E8 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B2EA;
L_82B2EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2EA LDA
    cpu.setA(0x3u, 8);
    goto L_82B2EC;
L_82B2EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2ECu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2ECu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2EC STA
    hw.write(cpu.address("dp", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_82B2EE;
L_82B2EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2EEu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EEu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EEu, 4u + 1u, 3u, cpu.address("absy", 0x0208u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2EE LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x208u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B2F1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EEu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EEu, 4u + 1u, 3u, cpu.address("absy", 0x0208u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2EE LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x208u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B2F1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2EEu,0x82B2EEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B2F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F1u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2F1 CMP
    cpu.compareA(0x1u);
    goto L_82B2F3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2F1 CMP
    cpu.compareA(0x1u);
    goto L_82B2F3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2F1u,0x82B2F1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B2F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2F3 BNE -> $82B31D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B31D; }
    goto L_82B2F5;
L_82B2F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F5u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F5u, 4u + 1u, 3u, cpu.address("absy", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2F5 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x20Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B2F8;
L_82B2F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F8u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2F8 CLC
    cpu.setFlag('C', false);
    goto L_82B2F9;
L_82B2F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F9u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F9u, 4u + 1u, 3u, cpu.address("absx", 0x0276u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2F9 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x276u), cpu.m8?8:16));
    goto L_82B2FC;
L_82B2FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FCu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2FC CLC
    cpu.setFlag('C', false);
    goto L_82B2FD;
L_82B2FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FDu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2FD ADC
    cpu.adc(0x4u);
    goto L_82B2FF;
L_82B2FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FFu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FFu, 5u, 3u, cpu.address("absx", 0x0276u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2FF STA
    hw.write(cpu.address("absx", 0x276u), cpu.a, cpu.m8?8:16);
    goto L_82B302;
L_82B302:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB302u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB302u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB302u, 4u + 1u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B302 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x20Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B305;
L_82B305:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB305u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB305u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB305u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B305 CLC
    cpu.setFlag('C', false);
    goto L_82B306;
L_82B306:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB306u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB306u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB306u, 4u + 1u, 3u, cpu.address("absx", 0x027Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B306 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x27Eu), cpu.m8?8:16));
    goto L_82B309;
L_82B309:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB309u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB309u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB309u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B309 CLC
    cpu.setFlag('C', false);
    goto L_82B30A;
L_82B30A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB30Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Au,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B30A ADC
    cpu.adc(0x4u);
    goto L_82B30C;
L_82B30C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB30Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Cu, 5u, 3u, cpu.address("absx", 0x027Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B30C STA
    hw.write(cpu.address("absx", 0x27Eu), cpu.a, cpu.m8?8:16);
    goto L_82B30F;
L_82B30F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB30Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B30F LDA
    cpu.setA(0xFCu, 8);
    goto L_82B311;
L_82B311:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB311u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB311u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB311u, 5u, 3u, cpu.address("absy", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B311 STA
    hw.write(cpu.address("absy", 0x20Au), cpu.a, cpu.m8?8:16);
    goto L_82B314;
L_82B314:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB314u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB314u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB314u, 5u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B314 STA
    hw.write(cpu.address("absy", 0x20Bu), cpu.a, cpu.m8?8:16);
    goto L_82B317;
L_82B317:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB317u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB317u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB317u, 5u, 3u, cpu.address("absy", 0x0226u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B317 STA
    hw.write(cpu.address("absy", 0x226u), cpu.a, cpu.m8?8:16);
    goto L_82B31A;
L_82B31A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB31Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Au,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Au, 5u, 3u, cpu.address("absy", 0x0227u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B31A STA
    hw.write(cpu.address("absy", 0x227u), cpu.a, cpu.m8?8:16);
    goto L_82B31D;
L_82B31D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB31Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Du,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B31D INY
    cpu.inc('Y');
    goto L_82B31E;
L_82B31E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB31Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Eu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B31E INY
    cpu.inc('Y');
    goto L_82B31F;
L_82B31F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB31Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B31F INY
    cpu.inc('Y');
    goto L_82B320;
L_82B320:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB320u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB320u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB320u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B320 INY
    cpu.inc('Y');
    goto L_82B321;
L_82B321:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB321u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB321u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB321u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B321 INY
    cpu.inc('Y');
    goto L_82B322;
L_82B322:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB322u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB322u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB322u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B322 INY
    cpu.inc('Y');
    goto L_82B323;
L_82B323:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB323u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB323u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB323u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B323 INX
    cpu.inc('X');
    goto L_82B324;
L_82B324:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB324u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB324u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB324u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B324 INX
    cpu.inc('X');
    goto L_82B325;
L_82B325:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB325u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB325u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB325u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B325 DEC
    cpu.decMem(hw, cpu.address("dp", 0x1Au), cpu.m8?8:16);
    goto L_82B327;
L_82B327:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB327u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB327u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB327u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B327 BPL -> $82B2EE
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82B2EE; }
    goto L_82B329;
L_82B329:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB329u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB329u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB329u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B329 REP
    cpu.rep(0x20u);
    goto L_82B32B;
L_82B32B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB32Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB32Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB32Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B32B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B32Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B32Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B2E4_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B2E4u: goto L_82B2E4;
    case 0x82B2E6u: goto L_82B2E6;
    case 0x82B2E8u: goto L_82B2E8;
    case 0x82B2EAu: goto L_82B2EA;
    case 0x82B2ECu: goto L_82B2EC;
    case 0x82B2EEu: goto L_82B2EE;
    case 0x82B2F1u: goto L_82B2F1;
    case 0x82B2F3u: goto L_82B2F3;
    case 0x82B2F5u: goto L_82B2F5;
    case 0x82B2F8u: goto L_82B2F8;
    case 0x82B2F9u: goto L_82B2F9;
    case 0x82B2FCu: goto L_82B2FC;
    case 0x82B2FDu: goto L_82B2FD;
    case 0x82B2FFu: goto L_82B2FF;
    case 0x82B302u: goto L_82B302;
    case 0x82B305u: goto L_82B305;
    case 0x82B306u: goto L_82B306;
    case 0x82B309u: goto L_82B309;
    case 0x82B30Au: goto L_82B30A;
    case 0x82B30Cu: goto L_82B30C;
    case 0x82B30Fu: goto L_82B30F;
    case 0x82B311u: goto L_82B311;
    case 0x82B314u: goto L_82B314;
    case 0x82B317u: goto L_82B317;
    case 0x82B31Au: goto L_82B31A;
    case 0x82B31Du: goto L_82B31D;
    case 0x82B31Eu: goto L_82B31E;
    case 0x82B31Fu: goto L_82B31F;
    case 0x82B320u: goto L_82B320;
    case 0x82B321u: goto L_82B321;
    case 0x82B322u: goto L_82B322;
    case 0x82B323u: goto L_82B323;
    case 0x82B324u: goto L_82B324;
    case 0x82B325u: goto L_82B325;
    case 0x82B327u: goto L_82B327;
    case 0x82B329u: goto L_82B329;
    case 0x82B32Bu: goto L_82B32B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B2E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E4u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2E4 SEP
    cpu.sep(0x20u);
    goto L_82B2E6;
L_82B2E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E6u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2E6 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B2E8;
L_82B2E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E8u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2E8 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B2EA;
L_82B2EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2EA LDA
    cpu.setA(0x3u, 8);
    goto L_82B2EC;
L_82B2EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2ECu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2ECu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2EC STA
    hw.write(cpu.address("dp", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_82B2EE;
L_82B2EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EEu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2EEu, 4u + 1u, 3u, cpu.address("absy", 0x0208u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2EE LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x208u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B2F1;
L_82B2F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2F1 CMP
    cpu.compareA(0x1u);
    goto L_82B2F3;
L_82B2F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2F3 BNE -> $82B31D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B31D; }
    goto L_82B2F5;
L_82B2F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F5u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F5u, 4u + 1u, 3u, cpu.address("absy", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2F5 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x20Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B2F8;
L_82B2F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F8u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2F8 CLC
    cpu.setFlag('C', false);
    goto L_82B2F9;
L_82B2F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F9u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2F9u, 4u + 1u, 3u, cpu.address("absx", 0x0276u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2F9 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x276u), cpu.m8?8:16));
    goto L_82B2FC;
L_82B2FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FCu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2FC CLC
    cpu.setFlag('C', false);
    goto L_82B2FD;
L_82B2FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FDu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2FD ADC
    cpu.adc(0x4u);
    goto L_82B2FF;
L_82B2FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FFu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2FFu, 5u, 3u, cpu.address("absx", 0x0276u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B2FF STA
    hw.write(cpu.address("absx", 0x276u), cpu.a, cpu.m8?8:16);
    goto L_82B302;
L_82B302:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB302u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB302u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB302u, 4u + 1u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B302 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x20Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B305;
L_82B305:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB305u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB305u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB305u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B305 CLC
    cpu.setFlag('C', false);
    goto L_82B306;
L_82B306:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB306u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB306u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB306u, 4u + 1u, 3u, cpu.address("absx", 0x027Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B306 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x27Eu), cpu.m8?8:16));
    goto L_82B309;
L_82B309:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB309u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB309u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB309u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B309 CLC
    cpu.setFlag('C', false);
    goto L_82B30A;
L_82B30A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB30Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Au,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B30A ADC
    cpu.adc(0x4u);
    goto L_82B30C;
L_82B30C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB30Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Cu, 5u, 3u, cpu.address("absx", 0x027Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B30C STA
    hw.write(cpu.address("absx", 0x27Eu), cpu.a, cpu.m8?8:16);
    goto L_82B30F;
L_82B30F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB30Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB30Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B30F LDA
    cpu.setA(0xFCu, 8);
    goto L_82B311;
L_82B311:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB311u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB311u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB311u, 5u, 3u, cpu.address("absy", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B311 STA
    hw.write(cpu.address("absy", 0x20Au), cpu.a, cpu.m8?8:16);
    goto L_82B314;
L_82B314:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB314u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB314u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB314u, 5u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B314 STA
    hw.write(cpu.address("absy", 0x20Bu), cpu.a, cpu.m8?8:16);
    goto L_82B317;
L_82B317:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB317u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB317u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB317u, 5u, 3u, cpu.address("absy", 0x0226u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B317 STA
    hw.write(cpu.address("absy", 0x226u), cpu.a, cpu.m8?8:16);
    goto L_82B31A;
L_82B31A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB31Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Au,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Au, 5u, 3u, cpu.address("absy", 0x0227u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B31A STA
    hw.write(cpu.address("absy", 0x227u), cpu.a, cpu.m8?8:16);
    goto L_82B31D;
L_82B31D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB31Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Du,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B31D INY
    cpu.inc('Y');
    goto L_82B31E;
L_82B31E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB31Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Eu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B31E INY
    cpu.inc('Y');
    goto L_82B31F;
L_82B31F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB31Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB31Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B31F INY
    cpu.inc('Y');
    goto L_82B320;
L_82B320:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB320u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB320u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB320u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B320 INY
    cpu.inc('Y');
    goto L_82B321;
L_82B321:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB321u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB321u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB321u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B321 INY
    cpu.inc('Y');
    goto L_82B322;
L_82B322:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB322u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB322u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB322u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B322 INY
    cpu.inc('Y');
    goto L_82B323;
L_82B323:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB323u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB323u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB323u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B323 INX
    cpu.inc('X');
    goto L_82B324;
L_82B324:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB324u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB324u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB324u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B324 INX
    cpu.inc('X');
    goto L_82B325;
L_82B325:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB325u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB325u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB325u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B325 DEC
    cpu.decMem(hw, cpu.address("dp", 0x1Au), cpu.m8?8:16);
    goto L_82B327;
L_82B327:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB327u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB327u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB327u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B327 BPL -> $82B2EE
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82B2EE; }
    goto L_82B329;
L_82B329:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB329u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB329u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB329u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B329 REP
    cpu.rep(0x20u);
    goto L_82B32B;
L_82B32B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB32Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB32Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB32Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B32B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B32Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B32Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82C0A5_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82C0A5u: goto L_82C0A5;
    case 0x82C0A8u: goto L_82C0A8;
    case 0x82C0ABu: goto L_82C0AB;
    case 0x82C0AEu: goto L_82C0AE;
    case 0x82C0B1u: goto L_82C0B1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82C0A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0A5u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0A5u, 5u, 3u, cpu.address("abs", 0x013Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C0A5 STZ
    hw.write(cpu.address("abs", 0x13Fu), 0, cpu.m8?8:16);
    goto L_82C0A8;
L_82C0A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0A8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0A8u, 6u, 3u, cpu.address("abs", 0xD1D7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C0A8 JSR -> $82D1D7 stack real
    { cpu.push16Value(hw,0xC0AAu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC0ABu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD1D7u), 0x82C0A8u); }
    goto L_82C0AB;
L_82C0AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0ABu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC0ABu,0x82C0ABu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0ABu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0ABu, 6u, 3u, cpu.address("abs", 0xAA07u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C0AB JSR -> $82AA07 stack real
    { cpu.push16Value(hw,0xC0ADu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC0AEu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAA07u), 0x82C0ABu); }
    goto L_82C0AE;
L_82C0AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0AEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC0AEu,0x82C0AEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0AEu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0AEu, 5u, 3u, cpu.address("abs", 0x013Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C0AE STZ
    hw.write(cpu.address("abs", 0x13Bu), 0, cpu.m8?8:16);
    goto L_82C0B1;
L_82C0B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC0B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC0B1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC0B1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C0B1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C0B1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C0B1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82D4AF_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82D4AFu: goto L_82D4AF;
    case 0x82D4B2u: goto L_82D4B2;
    case 0x82D4B5u: goto L_82D4B5;
    case 0x82D4B7u: goto L_82D4B7;
    case 0x82D4BAu: goto L_82D4BA;
    case 0x82D4BDu: goto L_82D4BD;
    case 0x82D4C0u: goto L_82D4C0;
    case 0x82D4C3u: goto L_82D4C3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82D4AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4AFu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4AFu, 8u, 3u, cpu.address("abs", 0x014Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4AF INC
    cpu.incMem(hw, cpu.address("abs", 0x14Au), cpu.m8?8:16);
    goto L_82D4B2;
L_82D4B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4B2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4B2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4B2 LDA
    cpu.setA(0x470u, 16);
    goto L_82D4B5;
L_82D4B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4B5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4B5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4B5 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82D4B7;
L_82D4B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4B7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4B7u, 6u, 3u, cpu.address("abs", 0xD528u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D4B7 JSR -> $82D528 stack real
    { cpu.push16Value(hw,0xD4B9u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD4BAu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD528u), 0x82D4B7u); }
    goto L_82D4BA;
L_82D4BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4BAu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4BAu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4BAu, 8u, 3u, cpu.address("abs", 0x0141u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4BA INC
    cpu.incMem(hw, cpu.address("abs", 0x141u), cpu.m8?8:16);
    goto L_82D4BD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4BAu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4BAu, 8u, 3u, cpu.address("abs", 0x0141u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4BA INC
    cpu.incMem(hw, cpu.address("abs", 0x141u), cpu.m8?8:16);
    goto L_82D4BD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD4BAu,0x82D4BAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82D4BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4BDu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4BDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4BDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4BD LDA
    cpu.setA(0x18u, 16);
    goto L_82D4C0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4BDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4BDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4BD LDA
    cpu.setA(0x18u, 16);
    goto L_82D4C0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD4BDu,0x82D4BDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82D4C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4C0u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4C0u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4C0u, 5u, 3u, cpu.address("abs", 0x018Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4C0 STA
    hw.write(cpu.address("abs", 0x18Bu), cpu.a, cpu.m8?8:16);
    goto L_82D4C3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4C0u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4C0u, 5u, 3u, cpu.address("abs", 0x018Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4C0 STA
    hw.write(cpu.address("abs", 0x18Bu), cpu.a, cpu.m8?8:16);
    goto L_82D4C3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD4C0u,0x82D4C0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82D4C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4C3u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4C3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4C3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D4C3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D4C3u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D4C3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4C3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4C3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D4C3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D4C3u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D4C3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD4C3u,0x82D4C3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82D4AF_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82D4AFu: goto L_82D4AF;
    case 0x82D4B2u: goto L_82D4B2;
    case 0x82D4B5u: goto L_82D4B5;
    case 0x82D4B7u: goto L_82D4B7;
    case 0x82D4BAu: goto L_82D4BA;
    case 0x82D4BDu: goto L_82D4BD;
    case 0x82D4C0u: goto L_82D4C0;
    case 0x82D4C3u: goto L_82D4C3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82D4AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4AFu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4AFu, 8u, 3u, cpu.address("abs", 0x014Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4AF INC
    cpu.incMem(hw, cpu.address("abs", 0x14Au), cpu.m8?8:16);
    goto L_82D4B2;
L_82D4B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4B2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4B2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4B2 LDA
    cpu.setA(0x470u, 16);
    goto L_82D4B5;
L_82D4B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4B5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4B5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4B5 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82D4B7;
L_82D4B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4B7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4B7u, 6u, 3u, cpu.address("abs", 0xD528u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D4B7 JSR -> $82D528 stack real
    { cpu.push16Value(hw,0xD4B9u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD4BAu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD528u), 0x82D4B7u); }
    goto L_82D4BA;
L_82D4BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4BAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD4BAu,0x82D4BAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4BAu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4BAu, 8u, 3u, cpu.address("abs", 0x0141u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4BA INC
    cpu.incMem(hw, cpu.address("abs", 0x141u), cpu.m8?8:16);
    goto L_82D4BD;
L_82D4BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4BDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4BDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4BD LDA
    cpu.setA(0x18u, 16);
    goto L_82D4C0;
L_82D4C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4C0u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4C0u, 5u, 3u, cpu.address("abs", 0x018Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4C0 STA
    hw.write(cpu.address("abs", 0x18Bu), cpu.a, cpu.m8?8:16);
    goto L_82D4C3;
L_82D4C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4C3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4C3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D4C3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D4C3u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D4C3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82D5A3_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82D5A3u: goto L_82D5A3;
    case 0x82D5A6u: goto L_82D5A6;
    case 0x82D5AAu: goto L_82D5AA;
    case 0x82D5ACu: goto L_82D5AC;
    case 0x82D5AFu: goto L_82D5AF;
    case 0x82D5B1u: goto L_82D5B1;
    case 0x82D5B4u: goto L_82D5B4;
    case 0x82D5B6u: goto L_82D5B6;
    case 0x82D5B9u: goto L_82D5B9;
    case 0x82D5BBu: goto L_82D5BB;
    case 0x82D5BFu: goto L_82D5BF;
    case 0x82D5C2u: goto L_82D5C2;
    case 0x82D5C5u: goto L_82D5C5;
    case 0x82D5C7u: goto L_82D5C7;
    case 0x82D5CAu: goto L_82D5CA;
    case 0x82D5CCu: goto L_82D5CC;
    case 0x82D5CFu: goto L_82D5CF;
    case 0x82D5D3u: goto L_82D5D3;
    case 0x82D5D5u: goto L_82D5D5;
    case 0x82D5D8u: goto L_82D5D8;
    case 0x82D5DAu: goto L_82D5DA;
    case 0x82D5DEu: goto L_82D5DE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82D5A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5A3u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5A3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5A3 LDX
    cpu.setX(0x26u, 16);
    goto L_82D5A6;
L_82D5A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5A6u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5A6u, 6u, 4u, ((0x9E8232u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5A6 LDA
    cpu.loadA(hw.readW(((0x9E8232u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D5AA;
L_82D5AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5AAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5AAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5AA STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82D5AC;
L_82D5AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5ACu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5ACu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5AC LDA
    cpu.setA(0x9Eu, 16);
    goto L_82D5AF;
L_82D5AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5AFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5AFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5AF STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82D5B1;
L_82D5B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5B1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5B1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5B1 LDA
    cpu.setA(0x40u, 16);
    goto L_82D5B4;
L_82D5B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5B4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5B4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5B4 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82D5B6;
L_82D5B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5B6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5B6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5B6 LDA
    cpu.setA(0x38u, 16);
    goto L_82D5B9;
L_82D5B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5B9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5B9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5B9 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82D5BB;
L_82D5BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5BBu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5BBu, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82D5BB JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD5BEu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD5BFu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x82D5BBu); }
    goto L_82D5BF;
L_82D5BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5BFu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD5BFu,0x82D5BFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5BFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5BFu, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5BF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D5C2;
L_82D5C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5C2u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5C2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5C2 CMP
    cpu.compareA(0x2u);
    goto L_82D5C5;
L_82D5C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5C5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5C5 BNE -> $82D5CC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D5CC; }
    goto L_82D5C7;
L_82D5C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5C7u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5C7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5C7 LDX
    cpu.setX(0x28u, 16);
    goto L_82D5CA;
L_82D5CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5CAu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5CAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5CA BRA -> $82D5CF
    goto L_82D5CF;
L_82D5CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5CCu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5CCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5CC LDX
    cpu.setX(0x2Au, 16);
    goto L_82D5CF;
L_82D5CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5CFu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5CFu, 6u, 4u, ((0x9E8232u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5CF LDA
    cpu.loadA(hw.readW(((0x9E8232u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D5D3;
L_82D5D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5D3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5D3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5D3 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82D5D5;
L_82D5D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5D5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5D5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5D5 LDA
    cpu.setA(0xC8u, 16);
    goto L_82D5D8;
L_82D5D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5D8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5D8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5D8 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82D5DA;
L_82D5DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5DAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5DAu, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82D5DA JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD5DDu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD5DEu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x82D5DAu); }
    goto L_82D5DE;
L_82D5DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5DEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD5DEu,0x82D5DEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5DEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5DEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D5DE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D5DEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D5DEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82D5A3_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82D5A3u: goto L_82D5A3;
    case 0x82D5A6u: goto L_82D5A6;
    case 0x82D5AAu: goto L_82D5AA;
    case 0x82D5ACu: goto L_82D5AC;
    case 0x82D5AFu: goto L_82D5AF;
    case 0x82D5B1u: goto L_82D5B1;
    case 0x82D5B4u: goto L_82D5B4;
    case 0x82D5B6u: goto L_82D5B6;
    case 0x82D5B9u: goto L_82D5B9;
    case 0x82D5BBu: goto L_82D5BB;
    case 0x82D5BFu: goto L_82D5BF;
    case 0x82D5C2u: goto L_82D5C2;
    case 0x82D5C5u: goto L_82D5C5;
    case 0x82D5C7u: goto L_82D5C7;
    case 0x82D5CAu: goto L_82D5CA;
    case 0x82D5CCu: goto L_82D5CC;
    case 0x82D5CFu: goto L_82D5CF;
    case 0x82D5D3u: goto L_82D5D3;
    case 0x82D5D5u: goto L_82D5D5;
    case 0x82D5D8u: goto L_82D5D8;
    case 0x82D5DAu: goto L_82D5DA;
    case 0x82D5DEu: goto L_82D5DE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82D5A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5A3u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5A3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5A3 LDX
    cpu.setX(0x26u, 16);
    goto L_82D5A6;
L_82D5A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5A6u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5A6u, 6u, 4u, ((0x9E8232u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5A6 LDA
    cpu.loadA(hw.readW(((0x9E8232u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D5AA;
L_82D5AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5AAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5AAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5AA STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82D5AC;
L_82D5AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5ACu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5ACu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5AC LDA
    cpu.setA(0x9Eu, 16);
    goto L_82D5AF;
L_82D5AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5AFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5AFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5AF STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82D5B1;
L_82D5B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5B1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5B1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5B1 LDA
    cpu.setA(0x40u, 16);
    goto L_82D5B4;
L_82D5B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5B4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5B4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5B4 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82D5B6;
L_82D5B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5B6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5B6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5B6 LDA
    cpu.setA(0x38u, 16);
    goto L_82D5B9;
L_82D5B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5B9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5B9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5B9 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82D5BB;
L_82D5BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5BBu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5BBu, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82D5BB JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD5BEu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD5BFu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x82D5BBu); }
    goto L_82D5BF;
L_82D5BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5BFu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD5BFu,0x82D5BFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5BFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5BFu, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5BF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D5C2;
L_82D5C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5C2u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5C2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5C2 CMP
    cpu.compareA(0x2u);
    goto L_82D5C5;
L_82D5C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5C5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5C5 BNE -> $82D5CC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D5CC; }
    goto L_82D5C7;
L_82D5C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5C7u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5C7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5C7 LDX
    cpu.setX(0x28u, 16);
    goto L_82D5CA;
L_82D5CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5CAu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5CAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5CA BRA -> $82D5CF
    goto L_82D5CF;
L_82D5CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5CCu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5CCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5CC LDX
    cpu.setX(0x2Au, 16);
    goto L_82D5CF;
L_82D5CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5CFu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5CFu, 6u, 4u, ((0x9E8232u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5CF LDA
    cpu.loadA(hw.readW(((0x9E8232u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D5D3;
L_82D5D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5D3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5D3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5D3 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82D5D5;
L_82D5D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5D5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5D5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5D5 LDA
    cpu.setA(0xC8u, 16);
    goto L_82D5D8;
L_82D5D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5D8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5D8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D5D8 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82D5DA;
L_82D5DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5DAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5DAu, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82D5DA JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD5DDu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD5DEu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x82D5DAu); }
    goto L_82D5DE;
L_82D5DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD5DEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD5DEu,0x82D5DEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD5DEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD5DEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D5DE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D5DEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D5DEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82D68D_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82D68Du: goto L_82D68D;
    case 0x82D690u: goto L_82D690;
    case 0x82D691u: goto L_82D691;
    case 0x82D692u: goto L_82D692;
    case 0x82D695u: goto L_82D695;
    case 0x82D698u: goto L_82D698;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82D68D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD68Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD68Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD68Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D68D AND
    cpu.logicAnd(0xFFu);
    goto L_82D690;
L_82D690:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD690u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD690u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD690u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D690 ASL
    cpu.aslA();
    goto L_82D691;
L_82D691:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD691u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD691u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD691u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D691 TAX
    cpu.transfer("TAX");
    goto L_82D692;
L_82D692:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD692u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD692u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD692u, 5u, 3u, cpu.address("abs", 0xD697u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D692 PEA
    cpu.push16Value(hw, 0xD697u);
    goto L_82D695;
L_82D695:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD695u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD695u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD695u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xD699u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $82D695 JMP (D699,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xD699u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x82D695u); return; }
L_82D698:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD698u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD698u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD698u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D698 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D698u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D698u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD698u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD698u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D698 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D698u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D698u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD698u,0x82D698u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82D68D_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82D68Du: goto L_82D68D;
    case 0x82D690u: goto L_82D690;
    case 0x82D691u: goto L_82D691;
    case 0x82D692u: goto L_82D692;
    case 0x82D695u: goto L_82D695;
    case 0x82D698u: goto L_82D698;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82D68D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD68Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD68Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD68Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D68D AND
    cpu.logicAnd(0xFFu);
    goto L_82D690;
L_82D690:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD690u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD690u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD690u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D690 ASL
    cpu.aslA();
    goto L_82D691;
L_82D691:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD691u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD691u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD691u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D691 TAX
    cpu.transfer("TAX");
    goto L_82D692;
L_82D692:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD692u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD692u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD692u, 5u, 3u, cpu.address("abs", 0xD697u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D692 PEA
    cpu.push16Value(hw, 0xD697u);
    goto L_82D695;
L_82D695:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD695u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD695u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD695u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xD699u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $82D695 JMP (D699,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xD699u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x82D695u); return; }
L_82D698:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD698u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD698u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD698u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D698 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D698u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D698u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD698u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD698u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D698 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D698u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D698u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD698u,0x82D698u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82DF65_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82DF65u: goto L_82DF65;
    case 0x82DF67u: goto L_82DF67;
    case 0x82DF68u: goto L_82DF68;
    case 0x82DF6Au: goto L_82DF6A;
    case 0x82DF6Bu: goto L_82DF6B;
    case 0x82DF6Cu: goto L_82DF6C;
    case 0x82DF6Eu: goto L_82DF6E;
    case 0x82DF70u: goto L_82DF70;
    case 0x82DF72u: goto L_82DF72;
    case 0x82DF75u: goto L_82DF75;
    case 0x82DF77u: goto L_82DF77;
    case 0x82DF7Au: goto L_82DF7A;
    case 0x82DF7Cu: goto L_82DF7C;
    case 0x82DF7Fu: goto L_82DF7F;
    case 0x82DF82u: goto L_82DF82;
    case 0x82DF84u: goto L_82DF84;
    case 0x82DF86u: goto L_82DF86;
    case 0x82DF88u: goto L_82DF88;
    case 0x82DF8Au: goto L_82DF8A;
    case 0x82DF8Du: goto L_82DF8D;
    case 0x82DF8Fu: goto L_82DF8F;
    case 0x82DF91u: goto L_82DF91;
    case 0x82DF93u: goto L_82DF93;
    case 0x82DF96u: goto L_82DF96;
    case 0x82DF97u: goto L_82DF97;
    case 0x82DF98u: goto L_82DF98;
    case 0x82DF9Au: goto L_82DF9A;
    case 0x82DF9Du: goto L_82DF9D;
    case 0x82DFA0u: goto L_82DFA0;
    case 0x82DFA2u: goto L_82DFA2;
    case 0x82DFA3u: goto L_82DFA3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82DF65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF65u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF65u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF65 SEP
    cpu.sep(0x20u);
    goto L_82DF67;
L_82DF67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF67u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF67u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82DF67 PHB
    cpu.push("PHB", hw);
    goto L_82DF68;
L_82DF68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF68u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF68u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x69u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF68 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x69u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DF6A;
L_82DF6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF6Au,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF6Au, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82DF6A PHA
    cpu.push("PHA", hw);
    goto L_82DF6B;
L_82DF6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF6Bu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF6Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82DF6B PLB
    cpu.pop("PLB", hw);
    goto L_82DF6C;
L_82DF6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF6Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF6Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF6C REP
    cpu.rep(0x20u);
    goto L_82DF6E;
L_82DF6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF6Eu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF6Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF6E LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82DF70;
L_82DF70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF70u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF70u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF70 BNE -> $82DF77
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82DF77; }
    goto L_82DF72;
L_82DF72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF72u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF72u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF72 LDA
    cpu.setA(0x7000u, 16);
    goto L_82DF75;
L_82DF75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF75u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF75u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF75 BRA -> $82DF7A
    goto L_82DF7A;
L_82DF77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF77u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF77u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF77 LDA
    cpu.setA(0x7200u, 16);
    goto L_82DF7A;
L_82DF7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF7Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF7Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF7A STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82DF7C;
L_82DF7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF7Cu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF7Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF7C LDY
    cpu.setY(0x1F8u, 16);
    goto L_82DF7F;
L_82DF7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF7Fu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF7Fu, 6u, 3u, cpu.address("absx", 0x02FEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF7F STZ
    hw.write(cpu.address("absx", 0x2FEu), 0, cpu.m8?8:16);
    goto L_82DF82;
L_82DF82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF82u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF82u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF82u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF82 STZ
    hw.write(cpu.address("dp", 0x14u), 0, cpu.m8?8:16);
    goto L_82DF84;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF82u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF82u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF82 STZ
    hw.write(cpu.address("dp", 0x14u), 0, cpu.m8?8:16);
    goto L_82DF84;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDF82u,0x82DF82u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82DF84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF84u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF84u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF84u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF84 STZ
    hw.write(cpu.address("dp", 0x16u), 0, cpu.m8?8:16);
    goto L_82DF86;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF84u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF84u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF84 STZ
    hw.write(cpu.address("dp", 0x16u), 0, cpu.m8?8:16);
    goto L_82DF86;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDF84u,0x82DF84u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82DF86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF86u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF86u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF86u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82DF86 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DF88;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF86u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF86u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82DF86 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DF88;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDF86u,0x82DF86u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82DF88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF88u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF88u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF88u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF88 BMI -> $82DF96
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82DF96; }
    goto L_82DF8A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF88u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF88u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF88 BMI -> $82DF96
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82DF96; }
    goto L_82DF8A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDF88u,0x82DF88u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82DF8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF8Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF8Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF8Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF8A AND
    cpu.logicAnd(0x300u);
    goto L_82DF8D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF8Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF8Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF8A AND
    cpu.logicAnd(0x300u);
    goto L_82DF8D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDF8Au,0x82DF8Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82DF8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF8Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF8Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF8Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF8D BEQ -> $82DF96
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82DF96; }
    goto L_82DF8F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF8Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF8Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF8D BEQ -> $82DF96
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82DF96; }
    goto L_82DF8F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDF8Du,0x82DF8Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82DF8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF8Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF8Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF8Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF8F STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82DF91;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF8Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF8Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF8F STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82DF91;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDF8Fu,0x82DF8Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82DF91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF91u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF91u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF91u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF91 STY
    hw.write(cpu.address("dp", 0x63u), cpu.y, cpu.x8?8:16);
    goto L_82DF93;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF91u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF91u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF91 STY
    hw.write(cpu.address("dp", 0x63u), cpu.y, cpu.x8?8:16);
    goto L_82DF93;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDF91u,0x82DF91u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82DF93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF93u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF93u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF93u, 6u, 3u, cpu.address("abs", 0xDFA4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82DF93 JSR -> $82DFA4 stack real
    { cpu.push16Value(hw,0xDF95u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDF96u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xDFA4u), 0x82DF93u); }
    goto L_82DF96;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF93u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF93u, 6u, 3u, cpu.address("abs", 0xDFA4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82DF93 JSR -> $82DFA4 stack real
    { cpu.push16Value(hw,0xDF95u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDF96u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xDFA4u), 0x82DF93u); }
    goto L_82DF96;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDF93u,0x82DF93u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82DF96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF96u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF96u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF96u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF96 DEY
    cpu.decReg('Y');
    goto L_82DF97;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF96u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF96u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF96 DEY
    cpu.decReg('Y');
    goto L_82DF97;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDF96u,0x82DF96u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82DF97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF97u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF97u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF97u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF97 DEY
    cpu.decReg('Y');
    goto L_82DF98;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF97u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF97u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF97 DEY
    cpu.decReg('Y');
    goto L_82DF98;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDF97u,0x82DF97u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82DF98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF98u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF98u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF98u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF98 BPL -> $82DF82
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82DF82; }
    goto L_82DF9A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF98u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF98u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF98 BPL -> $82DF82
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82DF82; }
    goto L_82DF9A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDF98u,0x82DF98u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82DF9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF9Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF9Au,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF9Au, 5u + 1u, 3u, cpu.address("absx", 0x02FEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF9A LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x2FEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82DF9D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF9Au,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF9Au, 5u + 1u, 3u, cpu.address("absx", 0x02FEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF9A LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x2FEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82DF9D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDF9Au,0x82DF9Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82DF9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF9Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF9Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF9Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF9D LDA
    cpu.setA(0xFFFFu, 16);
    goto L_82DFA0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF9Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF9Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF9D LDA
    cpu.setA(0xFFFFu, 16);
    goto L_82DFA0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDF9Du,0x82DF9Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82DFA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDFA0u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDFA0u,cpu,0x91u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDFA0u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82DFA0 STA
    hw.write(cpu.addressDpIndirectY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82DFA2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDFA0u,cpu,0x91u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDFA0u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82DFA0 STA
    hw.write(cpu.addressDpIndirectY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82DFA2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDFA0u,0x82DFA0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82DFA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDFA2u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDFA2u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDFA2u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82DFA2 PLB
    cpu.pop("PLB", hw);
    goto L_82DFA3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDFA2u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDFA2u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82DFA2 PLB
    cpu.pop("PLB", hw);
    goto L_82DFA3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDFA2u,0x82DFA2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82DFA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDFA3u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDFA3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDFA3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82DFA3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82DFA3u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82DFA3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDFA3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDFA3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82DFA3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82DFA3u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82DFA3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDFA3u,0x82DFA3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82DFEF_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82DFEFu: goto L_82DFEF;
    case 0x82DFF2u: goto L_82DFF2;
    case 0x82DFF4u: goto L_82DFF4;
    case 0x82DFF6u: goto L_82DFF6;
    case 0x82DFF9u: goto L_82DFF9;
    case 0x82DFFBu: goto L_82DFFB;
    case 0x82DFFEu: goto L_82DFFE;
    case 0x82E001u: goto L_82E001;
    case 0x82E004u: goto L_82E004;
    case 0x82E006u: goto L_82E006;
    case 0x82E009u: goto L_82E009;
    case 0x82E00Bu: goto L_82E00B;
    case 0x82E00Eu: goto L_82E00E;
    case 0x82E00Fu: goto L_82E00F;
    case 0x82E011u: goto L_82E011;
    case 0x82E013u: goto L_82E013;
    case 0x82E014u: goto L_82E014;
    case 0x82E015u: goto L_82E015;
    case 0x82E017u: goto L_82E017;
    case 0x82E019u: goto L_82E019;
    case 0x82E01Au: goto L_82E01A;
    case 0x82E01Bu: goto L_82E01B;
    case 0x82E01Du: goto L_82E01D;
    case 0x82E01Fu: goto L_82E01F;
    case 0x82E020u: goto L_82E020;
    case 0x82E021u: goto L_82E021;
    case 0x82E023u: goto L_82E023;
    case 0x82E025u: goto L_82E025;
    case 0x82E026u: goto L_82E026;
    case 0x82E027u: goto L_82E027;
    case 0x82E028u: goto L_82E028;
    case 0x82E02Bu: goto L_82E02B;
    case 0x82E02Du: goto L_82E02D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82DFEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDFEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDFEFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDFEFu, 5u + 1u, 3u, cpu.address("absx", 0x02FCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DFEF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2FCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DFF2;
L_82DFF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDFF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDFF2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDFF2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DFF2 BNE -> $82E009
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E009; }
    goto L_82DFF4;
L_82DFF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDFF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDFF4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDFF4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DFF4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82DFF6;
L_82DFF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDFF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDFF6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDFF6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DFF6 CMP
    cpu.compareA(0x2u);
    goto L_82DFF9;
L_82DFF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDFF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDFF9u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDFF9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DFF9 BCC -> $82E02D
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82E02D; }
    goto L_82DFFB;
L_82DFFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDFFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDFFBu,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDFFBu, 9u, 3u, cpu.address("absx", 0x02A0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DFFB INC
    cpu.incMem(hw, cpu.address("absx", 0x2A0u), cpu.m8?8:16);
    goto L_82DFFE;
L_82DFFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDFFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDFFEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDFFEu, 5u + 1u, 3u, cpu.address("absx", 0x02F6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DFFE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2F6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E001;
L_82E001:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE001u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE001u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE001u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E001 CMP
    cpu.compareA(0x4u);
    goto L_82E004;
L_82E004:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE004u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE004u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE004u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E004 BCS -> $82E009
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82E009; }
    goto L_82E006;
L_82E006:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE006u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE006u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE006u, 9u, 3u, cpu.address("absx", 0x02F6u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E006 INC
    cpu.incMem(hw, cpu.address("absx", 0x2F6u), cpu.m8?8:16);
    goto L_82E009;
L_82E009:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE009u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE009u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE009u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E009 STY
    hw.write(cpu.address("dp", 0x63u), cpu.y, cpu.x8?8:16);
    goto L_82E00B;
L_82E00B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE00Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE00Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE00Bu, 5u + 1u, 3u, cpu.address("absx", 0x02FEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E00B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2FEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E00E;
L_82E00E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE00Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE00Eu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE00Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E00E TAY
    cpu.transfer("TAY");
    goto L_82E00F;
L_82E00F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE00Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE00Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE00Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E00F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x63u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E011;
L_82E011:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE011u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE011u,cpu,0x91u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE011u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82E011 STA
    hw.write(cpu.addressDpIndirectY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82E013;
L_82E013:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE013u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE013u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE013u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E013 INY
    cpu.inc('Y');
    goto L_82E014;
L_82E014:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE014u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE014u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE014u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E014 INY
    cpu.inc('Y');
    goto L_82E015;
L_82E015:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE015u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE015u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE015u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E015 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E017;
L_82E017:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE017u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE017u,cpu,0x91u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE017u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82E017 STA
    hw.write(cpu.addressDpIndirectY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82E019;
L_82E019:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE019u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE019u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE019u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E019 INY
    cpu.inc('Y');
    goto L_82E01A;
L_82E01A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE01Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE01Au,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE01Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E01A INY
    cpu.inc('Y');
    goto L_82E01B;
L_82E01B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE01Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE01Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE01Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E01B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E01D;
L_82E01D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE01Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE01Du,cpu,0x91u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE01Du, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82E01D STA
    hw.write(cpu.addressDpIndirectY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82E01F;
L_82E01F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE01Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE01Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE01Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E01F INY
    cpu.inc('Y');
    goto L_82E020;
L_82E020:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE020u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE020u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE020u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E020 INY
    cpu.inc('Y');
    goto L_82E021;
L_82E021:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE021u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE021u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE021u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E021 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E023;
L_82E023:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE023u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE023u,cpu,0x91u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE023u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82E023 STA
    hw.write(cpu.addressDpIndirectY(hw, 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82E025;
L_82E025:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE025u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE025u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE025u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E025 INY
    cpu.inc('Y');
    goto L_82E026;
L_82E026:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE026u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE026u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE026u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E026 INY
    cpu.inc('Y');
    goto L_82E027;
L_82E027:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE027u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE027u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE027u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E027 TYA
    cpu.transfer("TYA");
    goto L_82E028;
L_82E028:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE028u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE028u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE028u, 6u, 3u, cpu.address("absx", 0x02FEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E028 STA
    hw.write(cpu.address("absx", 0x2FEu), cpu.a, cpu.m8?8:16);
    goto L_82E02B;
L_82E02B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE02Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE02Bu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE02Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E02B LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82E02D;
L_82E02D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE02Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE02Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE02Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E02D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82E02Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82E02Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82E260_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82E23Bu: goto L_82E23B;
    case 0x82E23Du: goto L_82E23D;
    case 0x82E23Fu: goto L_82E23F;
    case 0x82E241u: goto L_82E241;
    case 0x82E244u: goto L_82E244;
    case 0x82E246u: goto L_82E246;
    case 0x82E249u: goto L_82E249;
    case 0x82E24Bu: goto L_82E24B;
    case 0x82E24Du: goto L_82E24D;
    case 0x82E24Eu: goto L_82E24E;
    case 0x82E251u: goto L_82E251;
    case 0x82E253u: goto L_82E253;
    case 0x82E255u: goto L_82E255;
    case 0x82E258u: goto L_82E258;
    case 0x82E25Au: goto L_82E25A;
    case 0x82E25Du: goto L_82E25D;
    case 0x82E25Fu: goto L_82E25F;
    case 0x82E260u: goto L_82E260;
    case 0x82E261u: goto L_82E261;
    case 0x82E262u: goto L_82E262;
    case 0x82E263u: goto L_82E263;
    case 0x82E266u: goto L_82E266;
    case 0x82E268u: goto L_82E268;
    case 0x82E26Au: goto L_82E26A;
    case 0x82E26Du: goto L_82E26D;
    case 0x82E26Fu: goto L_82E26F;
    case 0x82E271u: goto L_82E271;
    case 0x82E273u: goto L_82E273;
    case 0x82E276u: goto L_82E276;
    case 0x82E278u: goto L_82E278;
    case 0x82E279u: goto L_82E279;
    case 0x82E27Au: goto L_82E27A;
    case 0x82E27Cu: goto L_82E27C;
    case 0x82E27Du: goto L_82E27D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82E23B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE23Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE23Bu,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE23Bu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82E23B LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E23D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE23Bu,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE23Bu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82E23B LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E23D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE23Bu,0x82E23Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E23D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE23Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE23Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE23Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E23D STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_82E23F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE23Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE23Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E23D STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_82E23F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE23Du,0x82E23Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E23F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE23Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE23Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE23Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E23F BEQ -> $82E278
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E278; }
    goto L_82E241;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE23Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE23Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E23F BEQ -> $82E278
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E278; }
    goto L_82E241;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE23Fu,0x82E23Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E241:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE241u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE241u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE241u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E241 CMP
    cpu.compareA(0xFFFFu);
    goto L_82E244;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE241u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE241u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E241 CMP
    cpu.compareA(0xFFFFu);
    goto L_82E244;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE241u,0x82E241u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E244:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE244u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE244u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE244u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E244 BEQ -> $82E278
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E278; }
    goto L_82E246;
L_82E246:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE246u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE246u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE246u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E246 BIT
    cpu.bit(0x4000u, true);
    goto L_82E249;
L_82E249:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE249u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE249u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE249u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E249 BNE -> $82E278
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E278; }
    goto L_82E24B;
L_82E24B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE24Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE24Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE24Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x67u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E24B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E24D;
L_82E24D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE24Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE24Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE24Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E24D CLC
    cpu.setFlag('C', false);
    goto L_82E24E;
L_82E24E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE24Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE24Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE24Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E24E ADC
    cpu.adc(0x16u);
    goto L_82E251;
L_82E251:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE251u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE251u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE251u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E251 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82E253;
L_82E253:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE253u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE253u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE253u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 2u, 0u);
    // $82E253 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E255;
L_82E255:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE255u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE255u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE255u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E255 BIT
    cpu.bit(0x4000u, true);
    goto L_82E258;
L_82E258:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE258u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE258u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE258u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E258 BNE -> $82E261
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E261; }
    goto L_82E25A;
L_82E25A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE25Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE25Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE25Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E25A CMP
    cpu.compareA(0xFFFFu);
    goto L_82E25D;
L_82E25D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE25Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE25Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE25Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E25D BEQ -> $82E261
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E261; }
    goto L_82E25F;
L_82E25F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE25Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE25Fu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE25Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E25F BRA -> $82E278
    goto L_82E278;
L_82E260:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE260u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE260u,cpu,0x17u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE260u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0xA5u) & 0xFFFFu), 3u, 0u);
    // $82E260 ORA
    cpu.logicOr(hw.readW(cpu.addressDpLongY(hw, 0xA5u), cpu.m8?8:16));
    goto L_82E262;
L_82E261:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE261u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE261u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE261u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E261 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E263;
L_82E262:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE262u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE262u,cpu,0x5Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE262u, 6u, 4u, ((0x000F89u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E262 EOR
    cpu.logicXor(hw.readW(((0xF89u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_82E266;
L_82E263:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE263u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE263u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE263u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E263 BIT
    cpu.bit(0xFu, true);
    goto L_82E266;
L_82E266:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE266u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE266u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE266u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E266 BEQ -> $82E271
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E271; }
    goto L_82E268;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE266u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE266u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E266 BEQ -> $82E271
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E271; }
    goto L_82E268;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE266u,0x82E266u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E268:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE268u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE268u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE268u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E268 STY
    hw.write(cpu.address("dp", 0x63u), cpu.y, cpu.x8?8:16);
    goto L_82E26A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE268u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE268u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E268 STY
    hw.write(cpu.address("dp", 0x63u), cpu.y, cpu.x8?8:16);
    goto L_82E26A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE268u,0x82E268u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E26A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE26Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE26Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE26Au, 6u, 3u, cpu.address("abs", 0xE2ADu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E26A JSR -> $82E2AD stack real
    { cpu.push16Value(hw,0xE26Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE26Du,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE2ADu), 0x82E26Au); }
    goto L_82E26D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE26Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE26Au, 6u, 3u, cpu.address("abs", 0xE2ADu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E26A JSR -> $82E2AD stack real
    { cpu.push16Value(hw,0xE26Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE26Du,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE2ADu), 0x82E26Au); }
    goto L_82E26D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE26Au,0x82E26Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E26D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE26Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE26Du,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE26Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E26D LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82E26F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE26Du,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE26Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E26D LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82E26F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE26Du,0x82E26Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E26F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE26Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE26Fu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE26Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E26F BRA -> $82E278
    goto L_82E278;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE26Fu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE26Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E26F BRA -> $82E278
    goto L_82E278;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE26Fu,0x82E26Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E271:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE271u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE271u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE271u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82E271 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E273;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE271u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE271u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82E271 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E273;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE271u,0x82E271u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E273:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE273u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE273u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE273u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E273 ORA
    cpu.logicOr(0x4000u);
    goto L_82E276;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE273u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE273u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E273 ORA
    cpu.logicOr(0x4000u);
    goto L_82E276;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE273u,0x82E273u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E276:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE276u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE276u,cpu,0x91u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE276u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82E276 STA
    hw.write(cpu.addressDpIndirectY(hw, 0x67u), cpu.a, cpu.m8?8:16);
    goto L_82E278;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE276u,cpu,0x91u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE276u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82E276 STA
    hw.write(cpu.addressDpIndirectY(hw, 0x67u), cpu.a, cpu.m8?8:16);
    goto L_82E278;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE276u,0x82E276u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E278:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE278u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE278u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE278u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E278 DEY
    cpu.decReg('Y');
    goto L_82E279;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE278u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE278u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E278 DEY
    cpu.decReg('Y');
    goto L_82E279;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE278u,0x82E278u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E279:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE279u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE279u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE279u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E279 DEY
    cpu.decReg('Y');
    goto L_82E27A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE279u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE279u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E279 DEY
    cpu.decReg('Y');
    goto L_82E27A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE279u,0x82E279u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E27A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE27Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E27A BNE -> $82E23B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E23B; }
    goto L_82E27C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E27A BNE -> $82E23B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E23B; }
    goto L_82E27C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE27Au,0x82E27Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E27C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE27Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Cu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82E27C PLB
    cpu.pop("PLB", hw);
    goto L_82E27D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Cu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82E27C PLB
    cpu.pop("PLB", hw);
    goto L_82E27D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE27Cu,0x82E27Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E27D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE27Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E27D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82E27Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82E27Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE27Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E27D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82E27Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82E27Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE27Du,0x82E27Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_848221_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848221u: goto L_848221;
    case 0x848224u: goto L_848224;
    case 0x848225u: goto L_848225;
    case 0x848226u: goto L_848226;
    case 0x848229u: goto L_848229;
    case 0x84822Au: goto L_84822A;
    case 0x84822Eu: goto L_84822E;
    case 0x848231u: goto L_848231;
    case 0x848234u: goto L_848234;
    case 0x848238u: goto L_848238;
    case 0x84823Bu: goto L_84823B;
    case 0x84823Eu: goto L_84823E;
    case 0x848242u: goto L_848242;
    case 0x848245u: goto L_848245;
    case 0x848248u: goto L_848248;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848221:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8221u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8221u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8221u, 5u + 1u, 3u, cpu.address("absy", 0x02CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848221 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2CEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848224;
L_848224:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8224u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8224u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8224u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848224 ASL
    cpu.aslA();
    goto L_848225;
L_848225:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8225u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8225u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8225u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848225 CLC
    cpu.setFlag('C', false);
    goto L_848226;
L_848226:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8226u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8226u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8226u, 5u + 1u, 3u, cpu.address("absy", 0x02CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848226 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x2CEu), cpu.m8?8:16));
    goto L_848229;
L_848229:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8229u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8229u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8229u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848229 TAX
    cpu.transfer("TAX");
    goto L_84822A;
L_84822A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x822Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x822Au,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x822Au, 6u, 4u, ((0x9E93D5u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84822A LDA
    cpu.loadA(hw.readW(((0x9E93D5u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84822E;
L_84822E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x822Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x822Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x822Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84822E AND
    cpu.logicAnd(0xFFu);
    goto L_848231;
L_848231:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8231u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8231u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8231u, 6u, 3u, cpu.address("absy", 0x02D0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848231 STA
    hw.write(cpu.address("absy", 0x2D0u), cpu.a, cpu.m8?8:16);
    goto L_848234;
L_848234:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8234u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8234u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8234u, 6u, 4u, ((0x9E93D6u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848234 LDA
    cpu.loadA(hw.readW(((0x9E93D6u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848238;
L_848238:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8238u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8238u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8238u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848238 AND
    cpu.logicAnd(0xFFu);
    goto L_84823B;
L_84823B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x823Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x823Bu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x823Bu, 6u, 3u, cpu.address("absy", 0x02D2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84823B STA
    hw.write(cpu.address("absy", 0x2D2u), cpu.a, cpu.m8?8:16);
    goto L_84823E;
L_84823E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x823Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x823Eu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x823Eu, 6u, 4u, ((0x9E93D7u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84823E LDA
    cpu.loadA(hw.readW(((0x9E93D7u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848242;
L_848242:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8242u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8242u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8242u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848242 AND
    cpu.logicAnd(0xFFu);
    goto L_848245;
L_848245:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8245u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8245u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8245u, 6u, 3u, cpu.address("absy", 0x02D4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848245 STA
    hw.write(cpu.address("absy", 0x2D4u), cpu.a, cpu.m8?8:16);
    goto L_848248;
L_848248:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8248u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8248u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8248u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848248 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x848248u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848248u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_848221_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848221u: goto L_848221;
    case 0x848224u: goto L_848224;
    case 0x848225u: goto L_848225;
    case 0x848226u: goto L_848226;
    case 0x848229u: goto L_848229;
    case 0x84822Au: goto L_84822A;
    case 0x84822Eu: goto L_84822E;
    case 0x848231u: goto L_848231;
    case 0x848234u: goto L_848234;
    case 0x848238u: goto L_848238;
    case 0x84823Bu: goto L_84823B;
    case 0x84823Eu: goto L_84823E;
    case 0x848242u: goto L_848242;
    case 0x848245u: goto L_848245;
    case 0x848248u: goto L_848248;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848221:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8221u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8221u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8221u, 5u + 1u, 3u, cpu.address("absy", 0x02CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848221 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2CEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848224;
L_848224:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8224u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8224u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8224u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848224 ASL
    cpu.aslA();
    goto L_848225;
L_848225:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8225u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8225u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8225u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848225 CLC
    cpu.setFlag('C', false);
    goto L_848226;
L_848226:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8226u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8226u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8226u, 5u + 1u, 3u, cpu.address("absy", 0x02CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848226 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x2CEu), cpu.m8?8:16));
    goto L_848229;
L_848229:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8229u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8229u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8229u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848229 TAX
    cpu.transfer("TAX");
    goto L_84822A;
L_84822A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x822Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x822Au,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x822Au, 6u, 4u, ((0x9E93D5u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84822A LDA
    cpu.loadA(hw.readW(((0x9E93D5u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84822E;
L_84822E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x822Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x822Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x822Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84822E AND
    cpu.logicAnd(0xFFu);
    goto L_848231;
L_848231:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8231u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8231u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8231u, 6u, 3u, cpu.address("absy", 0x02D0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848231 STA
    hw.write(cpu.address("absy", 0x2D0u), cpu.a, cpu.m8?8:16);
    goto L_848234;
L_848234:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8234u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8234u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8234u, 6u, 4u, ((0x9E93D6u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848234 LDA
    cpu.loadA(hw.readW(((0x9E93D6u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848238;
L_848238:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8238u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8238u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8238u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848238 AND
    cpu.logicAnd(0xFFu);
    goto L_84823B;
L_84823B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x823Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x823Bu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x823Bu, 6u, 3u, cpu.address("absy", 0x02D2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84823B STA
    hw.write(cpu.address("absy", 0x2D2u), cpu.a, cpu.m8?8:16);
    goto L_84823E;
L_84823E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x823Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x823Eu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x823Eu, 6u, 4u, ((0x9E93D7u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84823E LDA
    cpu.loadA(hw.readW(((0x9E93D7u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848242;
L_848242:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8242u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8242u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8242u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848242 AND
    cpu.logicAnd(0xFFu);
    goto L_848245;
L_848245:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8245u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8245u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8245u, 6u, 3u, cpu.address("absy", 0x02D4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848245 STA
    hw.write(cpu.address("absy", 0x2D4u), cpu.a, cpu.m8?8:16);
    goto L_848248;
L_848248:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8248u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8248u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8248u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848248 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x848248u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848248u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_848497_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848497u: goto L_848497;
    case 0x848499u: goto L_848499;
    case 0x84849Cu: goto L_84849C;
    case 0x84849Eu: goto L_84849E;
    case 0x8484A0u: goto L_8484A0;
    case 0x8484A2u: goto L_8484A2;
    case 0x8484A4u: goto L_8484A4;
    case 0x8484A6u: goto L_8484A6;
    case 0x8484A8u: goto L_8484A8;
    case 0x8484ABu: goto L_8484AB;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848497:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8497u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8497u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8497u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848497 SEP
    cpu.sep(0x20u);
    goto L_848499;
L_848499:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8499u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8499u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8499u, 4u, 3u, cpu.address("abs", 0x062Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848499 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84849C;
L_84849C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x849Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x849Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x849Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84849C BNE -> $8484A6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8484A6; }
    goto L_84849E;
L_84849E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x849Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x849Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x849Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84849E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8484A0;
L_8484A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484A0 BNE -> $8484AB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8484AB; }
    goto L_8484A2;
L_8484A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A2u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484A2 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_8484A4;
L_8484A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A4u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484A4 BRA -> $8484AB
    goto L_8484AB;
L_8484A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A6u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A6u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484A6 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_8484A8;
L_8484A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A8u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A8u, 4u, 3u, cpu.address("abs", 0x0657u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484A8 STZ
    hw.write(cpu.address("abs", 0x657u), 0, cpu.m8?8:16);
    goto L_8484AB;
L_8484AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84ABu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84ABu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8484AB RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8484ABu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8484ABu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_848497_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848497u: goto L_848497;
    case 0x848499u: goto L_848499;
    case 0x84849Cu: goto L_84849C;
    case 0x84849Eu: goto L_84849E;
    case 0x8484A0u: goto L_8484A0;
    case 0x8484A2u: goto L_8484A2;
    case 0x8484A4u: goto L_8484A4;
    case 0x8484A6u: goto L_8484A6;
    case 0x8484A8u: goto L_8484A8;
    case 0x8484ABu: goto L_8484AB;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848497:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8497u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8497u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8497u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848497 SEP
    cpu.sep(0x20u);
    goto L_848499;
L_848499:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8499u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8499u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8499u, 4u, 3u, cpu.address("abs", 0x062Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848499 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84849C;
L_84849C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x849Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x849Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x849Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84849C BNE -> $8484A6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8484A6; }
    goto L_84849E;
L_84849E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x849Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x849Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x849Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84849E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8484A0;
L_8484A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484A0 BNE -> $8484AB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8484AB; }
    goto L_8484A2;
L_8484A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A2u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484A2 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_8484A4;
L_8484A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A4u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484A4 BRA -> $8484AB
    goto L_8484AB;
L_8484A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A6u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A6u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484A6 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_8484A8;
L_8484A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84A8u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84A8u, 4u, 3u, cpu.address("abs", 0x0657u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8484A8 STZ
    hw.write(cpu.address("abs", 0x657u), 0, cpu.m8?8:16);
    goto L_8484AB;
L_8484AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84ABu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84ABu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8484AB RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8484ABu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8484ABu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_848585_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848585u: goto L_848585;
    case 0x848587u: goto L_848587;
    case 0x848589u: goto L_848589;
    case 0x84858Bu: goto L_84858B;
    case 0x84858Eu: goto L_84858E;
    case 0x84858Fu: goto L_84858F;
    case 0x848590u: goto L_848590;
    case 0x848593u: goto L_848593;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848585:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8585u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8585u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8585u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848585 SEP
    cpu.sep(0x20u);
    goto L_848587;
L_848587:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8587u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8587u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8587u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848587 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x49u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848589;
L_848589:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8589u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8589u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8589u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848589 REP
    cpu.rep(0x20u);
    goto L_84858B;
L_84858B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x858Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x858Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x858Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84858B AND
    cpu.logicAnd(0xFFu);
    goto L_84858E;
L_84858E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x858Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x858Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x858Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84858E ASL
    cpu.aslA();
    goto L_84858F;
L_84858F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x858Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x858Fu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x858Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84858F TAX
    cpu.transfer("TAX");
    goto L_848590;
L_848590:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8590u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8590u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8590u, 5u, 3u, cpu.address("abs", 0x8595u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848590 PEA
    cpu.push16Value(hw, 0x8595u);
    goto L_848593;
L_848593:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8593u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8593u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8593u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x8597u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $848593 JMP (8597,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x8597u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x848593u); return; }
}

void sub_848F7C_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848F7Cu: goto L_848F7C;
    case 0x848F80u: goto L_848F80;
    case 0x848F82u: goto L_848F82;
    case 0x848F85u: goto L_848F85;
    case 0x848F87u: goto L_848F87;
    case 0x848F8Au: goto L_848F8A;
    case 0x848F8Cu: goto L_848F8C;
    case 0x848F8Eu: goto L_848F8E;
    case 0x848F90u: goto L_848F90;
    case 0x848F92u: goto L_848F92;
    case 0x848F94u: goto L_848F94;
    case 0x848F96u: goto L_848F96;
    case 0x848F99u: goto L_848F99;
    case 0x848F9Bu: goto L_848F9B;
    case 0x848F9Du: goto L_848F9D;
    case 0x848F9Fu: goto L_848F9F;
    case 0x848FA1u: goto L_848FA1;
    case 0x848FA3u: goto L_848FA3;
    case 0x848FA5u: goto L_848FA5;
    case 0x848FA7u: goto L_848FA7;
    case 0x848FAAu: goto L_848FAA;
    case 0x848FACu: goto L_848FAC;
    case 0x848FAFu: goto L_848FAF;
    case 0x848FB2u: goto L_848FB2;
    case 0x848FB5u: goto L_848FB5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848F7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F7Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F7Cu, 8u, 4u, 0x82BC35u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848F7C JSL -> $82BC35 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8F7Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8F80u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82BC35u, 0x848F7Cu); }
    goto L_848F80;
L_848F80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F80u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8F80u,0x848F80u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F80u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F80u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F80 SEP
    cpu.sep(0x20u);
    goto L_848F82;
L_848F82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F82u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F82u, 4u, 3u, cpu.address("abs", 0x0657u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F82 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x657u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848F85;
L_848F85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F85u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F85u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F85 BEQ -> $848FAC
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848FAC; }
    goto L_848F87;
L_848F87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F87u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F87u, 4u, 3u, cpu.address("abs", 0x0135u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F87 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848F8A;
L_848F8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F8A CMP
    cpu.compareA(0x1u);
    goto L_848F8C;
L_848F8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F8C BEQ -> $848F96
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848F96; }
    goto L_848F8E;
L_848F8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F8Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F8E CMP
    cpu.compareA(0x3u);
    goto L_848F90;
L_848F90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F90u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F90u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F90 BNE -> $848FA1
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_848FA1; }
    goto L_848F92;
L_848F92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F92u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F92u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F92 LDA
    cpu.setA(0x95u, 8);
    goto L_848F94;
L_848F94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F94u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F94u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F94 BRA -> $848FA3
    goto L_848FA3;
L_848F96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F96u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F96u, 4u, 3u, cpu.address("abs", 0x06FDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F96 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6FDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848F99;
L_848F99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F99u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F99u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F99 BIT
    cpu.bit(0x1u, true);
    goto L_848F9B;
L_848F9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F9B BEQ -> $848FA1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848FA1; }
    goto L_848F9D;
L_848F9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F9D LDA
    cpu.setA(0x96u, 8);
    goto L_848F9F;
L_848F9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Fu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F9Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848F9F BRA -> $848FA3
    goto L_848FA3;
L_848FA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848FA1 LDA
    cpu.setA(0x8Au, 8);
    goto L_848FA3;
L_848FA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA3u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848FA3 STA
    hw.write(cpu.address("dp", 0x46u), cpu.a, cpu.m8?8:16);
    goto L_848FA5;
L_848FA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848FA5 LDA
    cpu.setA(0x83u, 8);
    goto L_848FA7;
L_848FA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FA7u, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848FA7 STA
    hw.write(cpu.address("abs", 0x2140u), cpu.a, cpu.m8?8:16);
    goto L_848FAA;
L_848FAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FAAu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FAAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848FAA BRA -> $848FB5
    goto L_848FB5;
L_848FAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FACu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FACu, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848FAC LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848FAF;
L_848FAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FAFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FAFu, 6u, 3u, cpu.address("abs", 0x8FF8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848FAF JSR -> $848FF8 stack real
    { cpu.push16Value(hw,0x8FB1u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8FB2u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8FF8u), 0x848FAFu); }
    goto L_848FB2;
L_848FB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FB2u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8FB2u,0x848FB2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB2u, 6u, 3u, cpu.address("abs", 0x904Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848FB2 JSR -> $84904F stack real
    { cpu.push16Value(hw,0x8FB4u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8FB5u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x904Fu), 0x848FB2u); }
    goto L_848FB5;
L_848FB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FB5u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848FB5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848FB5u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848FB5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FB5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848FB5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848FB5u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848FB5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8FB5u,0x848FB5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_848FDA_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848FDAu: goto L_848FDA;
    case 0x848FDCu: goto L_848FDC;
    case 0x848FDEu: goto L_848FDE;
    case 0x848FE0u: goto L_848FE0;
    case 0x848FE3u: goto L_848FE3;
    case 0x848FE4u: goto L_848FE4;
    case 0x848FE5u: goto L_848FE5;
    case 0x848FE8u: goto L_848FE8;
    case 0x848FEBu: goto L_848FEB;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848FDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDAu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848FDA SEP
    cpu.sep(0x20u);
    goto L_848FDC;
L_848FDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDCu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848FDC AND
    cpu.logicAnd(0x1u);
    goto L_848FDE;
L_848FDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDEu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FDEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848FDE REP
    cpu.rep(0x20u);
    goto L_848FE0;
L_848FE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE0u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848FE0 AND
    cpu.logicAnd(0xFFu);
    goto L_848FE3;
L_848FE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE3u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848FE3 ASL
    cpu.aslA();
    goto L_848FE4;
L_848FE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE4u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848FE4 TAX
    cpu.transfer("TAX");
    goto L_848FE5;
L_848FE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE5u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE5u, 5u, 3u, cpu.address("abs", 0x8FEAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848FE5 PEA
    cpu.push16Value(hw, 0x8FEAu);
    goto L_848FE8;
L_848FE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE8u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FE8u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x8FECu + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $848FE8 JMP (8FEC,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x8FECu+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x848FE8u); return; }
L_848FEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8FEBu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEBu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848FEB RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848FEBu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848FEBu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEBu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8FEBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848FEB RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848FEBu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848FEBu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8FEBu,0x848FEBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_84904D_E0M1X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84904Du: goto L_84904D;
    case 0x84904Eu: goto L_84904E;
    case 0x84904Fu: goto L_84904F;
    case 0x849051u: goto L_849051;
    case 0x849054u: goto L_849054;
    case 0x849056u: goto L_849056;
    case 0x849058u: goto L_849058;
    case 0x84905Au: goto L_84905A;
    case 0x84905Du: goto L_84905D;
    case 0x84905Fu: goto L_84905F;
    case 0x849061u: goto L_849061;
    case 0x849063u: goto L_849063;
    case 0x849066u: goto L_849066;
    case 0x849069u: goto L_849069;
    case 0x84906Cu: goto L_84906C;
    case 0x84906Fu: goto L_84906F;
    case 0x849072u: goto L_849072;
    case 0x849075u: goto L_849075;
    case 0x849078u: goto L_849078;
    case 0x84907Bu: goto L_84907B;
    case 0x84907Eu: goto L_84907E;
    case 0x849081u: goto L_849081;
    case 0x849083u: goto L_849083;
    case 0x849085u: goto L_849085;
    case 0x849088u: goto L_849088;
    case 0x84908Bu: goto L_84908B;
    case 0x84908Eu: goto L_84908E;
    case 0x849091u: goto L_849091;
    case 0x849094u: goto L_849094;
    case 0x849097u: goto L_849097;
    case 0x84909Au: goto L_84909A;
    case 0x84909Du: goto L_84909D;
    case 0x8490A0u: goto L_8490A0;
    case 0x8490A3u: goto L_8490A3;
    case 0x8490A5u: goto L_8490A5;
    case 0x8490A7u: goto L_8490A7;
    case 0x8490AAu: goto L_8490AA;
    case 0x8490ACu: goto L_8490AC;
    case 0x8490AEu: goto L_8490AE;
    case 0x8490B0u: goto L_8490B0;
    case 0x8490B3u: goto L_8490B3;
    case 0x8490B6u: goto L_8490B6;
    case 0x8490B9u: goto L_8490B9;
    case 0x8490BCu: goto L_8490BC;
    case 0x8490BFu: goto L_8490BF;
    case 0x8490C2u: goto L_8490C2;
    case 0x8490C6u: goto L_8490C6;
    case 0x8490C8u: goto L_8490C8;
    case 0x8490CAu: goto L_8490CA;
    case 0x8490CDu: goto L_8490CD;
    case 0x8490D0u: goto L_8490D0;
    case 0x8490D3u: goto L_8490D3;
    case 0x8490D6u: goto L_8490D6;
    case 0x8490D9u: goto L_8490D9;
    case 0x8490DCu: goto L_8490DC;
    case 0x8490DEu: goto L_8490DE;
    case 0x8490E0u: goto L_8490E0;
    case 0x8490E3u: goto L_8490E3;
    case 0x8490E6u: goto L_8490E6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84904D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x904Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x904Du,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x904Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84904D DEY
    cpu.decReg('Y');
    goto L_84904E;
L_84904E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x904Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x904Eu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x904Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84904E DEY
    cpu.decReg('Y');
    goto L_84904F;
L_84904F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x904Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x904Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x904Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84904F SEP
    cpu.sep(0x20u);
    goto L_849051;
L_849051:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9051u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9051u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9051u, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849051 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849054;
L_849054:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9054u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9054u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9054u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849054 BIT
    cpu.bit(0x1u, true);
    goto L_849056;
L_849056:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9056u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9056u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9056u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849056 BEQ -> $8490A5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8490A5; }
    goto L_849058;
L_849058:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9058u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9058u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9058u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849058 SEP
    cpu.sep(0x20u);
    goto L_84905A;
L_84905A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x905Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x905Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x905Au, 4u, 3u, cpu.address("abs", 0x062Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84905A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84905D;
L_84905D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x905Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x905Du,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x905Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84905D BIT
    cpu.bit(0x1u, true);
    goto L_84905F;
L_84905F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x905Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x905Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x905Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84905F BNE -> $849083
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_849083; }
    goto L_849061;
L_849061:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9061u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9061u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9061u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849061 REP
    cpu.rep(0x20u);
    goto L_849063;
L_849063:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9063u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9063u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9063u, 5u, 3u, cpu.address("abs", 0x0637u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849063 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x637u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849066;
L_849066:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9066u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9066u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9066u, 5u, 3u, cpu.address("abs", 0x03A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849066 STA
    hw.write(cpu.address("abs", 0x3A2u), cpu.a, cpu.m8?8:16);
    goto L_849069;
L_849069:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9069u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9069u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9069u, 5u, 3u, cpu.address("abs", 0x0643u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849069 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x643u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84906C;
L_84906C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x906Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Cu, 5u, 3u, cpu.address("abs", 0x03CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84906C STA
    hw.write(cpu.address("abs", 0x3CEu), cpu.a, cpu.m8?8:16);
    goto L_84906F;
L_84906F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x906Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Fu, 5u, 3u, cpu.address("abs", 0x063Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84906F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x63Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849072;
L_849072:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9072u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9072u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9072u, 5u, 3u, cpu.address("abs", 0x02A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849072 STA
    hw.write(cpu.address("abs", 0x2A2u), cpu.a, cpu.m8?8:16);
    goto L_849075;
L_849075:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9075u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9075u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9075u, 5u, 3u, cpu.address("abs", 0x0647u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849075 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x647u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849078;
L_849078:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9078u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9078u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9078u, 5u, 3u, cpu.address("abs", 0x02CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849078 STA
    hw.write(cpu.address("abs", 0x2CEu), cpu.a, cpu.m8?8:16);
    goto L_84907B;
L_84907B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x907Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Bu, 5u, 3u, cpu.address("abs", 0x064Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84907B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x64Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84907E;
L_84907E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x907Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Eu, 5u, 3u, cpu.address("abs", 0x014Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84907E STA
    hw.write(cpu.address("abs", 0x14Cu), cpu.a, cpu.m8?8:16);
    goto L_849081;
L_849081:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9081u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9081u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9081u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849081 BRA -> $8490E6
    goto L_8490E6;
L_849083:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9083u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9083u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9083u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849083 REP
    cpu.rep(0x20u);
    goto L_849085;
L_849085:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9085u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9085u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9085u, 5u, 3u, cpu.address("abs", 0x0639u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849085 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x639u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849088;
L_849088:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9088u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9088u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9088u, 5u, 3u, cpu.address("abs", 0x03A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849088 STA
    hw.write(cpu.address("abs", 0x3A2u), cpu.a, cpu.m8?8:16);
    goto L_84908B;
L_84908B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x908Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x908Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x908Bu, 5u, 3u, cpu.address("abs", 0x0645u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84908B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x645u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84908E;
L_84908E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x908Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x908Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x908Eu, 5u, 3u, cpu.address("abs", 0x03CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84908E STA
    hw.write(cpu.address("abs", 0x3CEu), cpu.a, cpu.m8?8:16);
    goto L_849091;
L_849091:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9091u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9091u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9091u, 5u, 3u, cpu.address("abs", 0x063Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849091 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x63Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849094;
L_849094:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9094u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9094u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9094u, 5u, 3u, cpu.address("abs", 0x02A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849094 STA
    hw.write(cpu.address("abs", 0x2A2u), cpu.a, cpu.m8?8:16);
    goto L_849097;
L_849097:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9097u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9097u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9097u, 5u, 3u, cpu.address("abs", 0x0649u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849097 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x649u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84909A;
L_84909A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x909Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x909Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x909Au, 5u, 3u, cpu.address("abs", 0x02CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84909A STA
    hw.write(cpu.address("abs", 0x2CEu), cpu.a, cpu.m8?8:16);
    goto L_84909D;
L_84909D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x909Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x909Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x909Du, 5u, 3u, cpu.address("abs", 0x0651u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84909D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x651u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8490A0;
L_8490A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A0u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A0u, 5u, 3u, cpu.address("abs", 0x014Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490A0 STA
    hw.write(cpu.address("abs", 0x14Cu), cpu.a, cpu.m8?8:16);
    goto L_8490A3;
L_8490A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A3u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490A3 BRA -> $8490E6
    goto L_8490E6;
L_8490A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A5u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490A5 SEP
    cpu.sep(0x20u);
    goto L_8490A7;
L_8490A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A7u, 4u, 3u, cpu.address("abs", 0x062Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490A7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8490AA;
L_8490AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90AAu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90AAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490AA BIT
    cpu.bit(0x1u, true);
    goto L_8490AC;
L_8490AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90ACu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90ACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490AC BNE -> $8490C8
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8490C8; }
    goto L_8490AE;
L_8490AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90AEu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90AEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490AE REP
    cpu.rep(0x20u);
    goto L_8490B0;
L_8490B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B0u, 5u, 3u, cpu.address("abs", 0x0633u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490B0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x633u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8490B3;
L_8490B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B3u, 5u, 3u, cpu.address("abs", 0x02A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490B3 STA
    hw.write(cpu.address("abs", 0x2A2u), cpu.a, cpu.m8?8:16);
    goto L_8490B6;
L_8490B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B6u, 5u, 3u, cpu.address("abs", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490B6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x63Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8490B9;
L_8490B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B9u, 5u, 3u, cpu.address("abs", 0x02CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490B9 STA
    hw.write(cpu.address("abs", 0x2CEu), cpu.a, cpu.m8?8:16);
    goto L_8490BC;
L_8490BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90BCu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90BCu, 5u, 3u, cpu.address("abs", 0x064Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490BC LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x64Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8490BF;
L_8490BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90BFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90BFu, 5u, 3u, cpu.address("abs", 0x014Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490BF STA
    hw.write(cpu.address("abs", 0x14Cu), cpu.a, cpu.m8?8:16);
    goto L_8490C2;
L_8490C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90C2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90C2u, 8u, 4u, 0x84B80Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8490C2 JSL -> $84B80F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x90C5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x90C6u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84B80Fu, 0x8490C2u); }
    goto L_8490C6;
L_8490C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90C6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x90C6u,0x8490C6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90C6u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90C6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490C6 BRA -> $8490E6
    goto L_8490E6;
L_8490C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90C8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90C8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490C8 REP
    cpu.rep(0x20u);
    goto L_8490CA;
L_8490CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90CAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90CAu, 5u, 3u, cpu.address("abs", 0x0635u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490CA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x635u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8490CD;
L_8490CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90CDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90CDu, 5u, 3u, cpu.address("abs", 0x02A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490CD STA
    hw.write(cpu.address("abs", 0x2A2u), cpu.a, cpu.m8?8:16);
    goto L_8490D0;
L_8490D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90D0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90D0u, 5u, 3u, cpu.address("abs", 0x064Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490D0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x64Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8490D3;
L_8490D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90D3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90D3u, 5u, 3u, cpu.address("abs", 0x014Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490D3 STA
    hw.write(cpu.address("abs", 0x14Cu), cpu.a, cpu.m8?8:16);
    goto L_8490D6;
L_8490D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90D6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90D6u, 5u, 3u, cpu.address("abs", 0x06FDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490D6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6FDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8490D9;
L_8490D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90D9u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90D9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490D9 BIT
    cpu.bit(0x1u, true);
    goto L_8490DC;
L_8490DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90DCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90DCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490DC BNE -> $8490E6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8490E6; }
    goto L_8490DE;
L_8490DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90DEu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90DEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490DE REP
    cpu.rep(0x20u);
    goto L_8490E0;
L_8490E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90E0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90E0u, 5u, 3u, cpu.address("abs", 0x0641u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490E0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x641u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8490E3;
L_8490E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90E3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90E3u, 5u, 3u, cpu.address("abs", 0x02CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490E3 STA
    hw.write(cpu.address("abs", 0x2CEu), cpu.a, cpu.m8?8:16);
    goto L_8490E6;
L_8490E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90E6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90E6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8490E6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8490E6u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8490E6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84904D_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84904Du: goto L_84904D;
    case 0x84904Eu: goto L_84904E;
    case 0x84904Fu: goto L_84904F;
    case 0x849051u: goto L_849051;
    case 0x849054u: goto L_849054;
    case 0x849056u: goto L_849056;
    case 0x849058u: goto L_849058;
    case 0x84905Au: goto L_84905A;
    case 0x84905Du: goto L_84905D;
    case 0x84905Fu: goto L_84905F;
    case 0x849061u: goto L_849061;
    case 0x849063u: goto L_849063;
    case 0x849066u: goto L_849066;
    case 0x849069u: goto L_849069;
    case 0x84906Cu: goto L_84906C;
    case 0x84906Fu: goto L_84906F;
    case 0x849072u: goto L_849072;
    case 0x849075u: goto L_849075;
    case 0x849078u: goto L_849078;
    case 0x84907Bu: goto L_84907B;
    case 0x84907Eu: goto L_84907E;
    case 0x849081u: goto L_849081;
    case 0x849083u: goto L_849083;
    case 0x849085u: goto L_849085;
    case 0x849088u: goto L_849088;
    case 0x84908Bu: goto L_84908B;
    case 0x84908Eu: goto L_84908E;
    case 0x849091u: goto L_849091;
    case 0x849094u: goto L_849094;
    case 0x849097u: goto L_849097;
    case 0x84909Au: goto L_84909A;
    case 0x84909Du: goto L_84909D;
    case 0x8490A0u: goto L_8490A0;
    case 0x8490A3u: goto L_8490A3;
    case 0x8490A5u: goto L_8490A5;
    case 0x8490A7u: goto L_8490A7;
    case 0x8490AAu: goto L_8490AA;
    case 0x8490ACu: goto L_8490AC;
    case 0x8490AEu: goto L_8490AE;
    case 0x8490B0u: goto L_8490B0;
    case 0x8490B3u: goto L_8490B3;
    case 0x8490B6u: goto L_8490B6;
    case 0x8490B9u: goto L_8490B9;
    case 0x8490BCu: goto L_8490BC;
    case 0x8490BFu: goto L_8490BF;
    case 0x8490C2u: goto L_8490C2;
    case 0x8490C6u: goto L_8490C6;
    case 0x8490C8u: goto L_8490C8;
    case 0x8490CAu: goto L_8490CA;
    case 0x8490CDu: goto L_8490CD;
    case 0x8490D0u: goto L_8490D0;
    case 0x8490D3u: goto L_8490D3;
    case 0x8490D6u: goto L_8490D6;
    case 0x8490D9u: goto L_8490D9;
    case 0x8490DCu: goto L_8490DC;
    case 0x8490DEu: goto L_8490DE;
    case 0x8490E0u: goto L_8490E0;
    case 0x8490E3u: goto L_8490E3;
    case 0x8490E6u: goto L_8490E6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84904D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x904Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x904Du,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x904Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84904D DEY
    cpu.decReg('Y');
    goto L_84904E;
L_84904E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x904Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x904Eu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x904Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84904E DEY
    cpu.decReg('Y');
    goto L_84904F;
L_84904F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x904Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x904Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x904Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84904F SEP
    cpu.sep(0x20u);
    goto L_849051;
L_849051:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9051u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9051u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9051u, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849051 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x629u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849054;
L_849054:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9054u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9054u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9054u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849054 BIT
    cpu.bit(0x1u, true);
    goto L_849056;
L_849056:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9056u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9056u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9056u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849056 BEQ -> $8490A5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8490A5; }
    goto L_849058;
L_849058:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9058u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9058u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9058u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849058 SEP
    cpu.sep(0x20u);
    goto L_84905A;
L_84905A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x905Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x905Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x905Au, 4u, 3u, cpu.address("abs", 0x062Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84905A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84905D;
L_84905D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x905Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x905Du,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x905Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84905D BIT
    cpu.bit(0x1u, true);
    goto L_84905F;
L_84905F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x905Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x905Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x905Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84905F BNE -> $849083
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_849083; }
    goto L_849061;
L_849061:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9061u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9061u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9061u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849061 REP
    cpu.rep(0x20u);
    goto L_849063;
L_849063:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9063u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9063u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9063u, 5u, 3u, cpu.address("abs", 0x0637u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849063 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x637u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849066;
L_849066:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9066u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9066u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9066u, 5u, 3u, cpu.address("abs", 0x03A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849066 STA
    hw.write(cpu.address("abs", 0x3A2u), cpu.a, cpu.m8?8:16);
    goto L_849069;
L_849069:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9069u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9069u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9069u, 5u, 3u, cpu.address("abs", 0x0643u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849069 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x643u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84906C;
L_84906C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x906Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Cu, 5u, 3u, cpu.address("abs", 0x03CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84906C STA
    hw.write(cpu.address("abs", 0x3CEu), cpu.a, cpu.m8?8:16);
    goto L_84906F;
L_84906F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x906Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Fu, 5u, 3u, cpu.address("abs", 0x063Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84906F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x63Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849072;
L_849072:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9072u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9072u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9072u, 5u, 3u, cpu.address("abs", 0x02A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849072 STA
    hw.write(cpu.address("abs", 0x2A2u), cpu.a, cpu.m8?8:16);
    goto L_849075;
L_849075:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9075u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9075u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9075u, 5u, 3u, cpu.address("abs", 0x0647u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849075 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x647u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849078;
L_849078:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9078u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9078u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9078u, 5u, 3u, cpu.address("abs", 0x02CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849078 STA
    hw.write(cpu.address("abs", 0x2CEu), cpu.a, cpu.m8?8:16);
    goto L_84907B;
L_84907B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x907Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Bu, 5u, 3u, cpu.address("abs", 0x064Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84907B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x64Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84907E;
L_84907E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x907Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Eu, 5u, 3u, cpu.address("abs", 0x014Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84907E STA
    hw.write(cpu.address("abs", 0x14Cu), cpu.a, cpu.m8?8:16);
    goto L_849081;
L_849081:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9081u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9081u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9081u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849081 BRA -> $8490E6
    goto L_8490E6;
L_849083:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9083u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9083u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9083u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849083 REP
    cpu.rep(0x20u);
    goto L_849085;
L_849085:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9085u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9085u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9085u, 5u, 3u, cpu.address("abs", 0x0639u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849085 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x639u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849088;
L_849088:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9088u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9088u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9088u, 5u, 3u, cpu.address("abs", 0x03A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849088 STA
    hw.write(cpu.address("abs", 0x3A2u), cpu.a, cpu.m8?8:16);
    goto L_84908B;
L_84908B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x908Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x908Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x908Bu, 5u, 3u, cpu.address("abs", 0x0645u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84908B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x645u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84908E;
L_84908E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x908Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x908Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x908Eu, 5u, 3u, cpu.address("abs", 0x03CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84908E STA
    hw.write(cpu.address("abs", 0x3CEu), cpu.a, cpu.m8?8:16);
    goto L_849091;
L_849091:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9091u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9091u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9091u, 5u, 3u, cpu.address("abs", 0x063Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849091 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x63Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849094;
L_849094:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9094u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9094u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9094u, 5u, 3u, cpu.address("abs", 0x02A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849094 STA
    hw.write(cpu.address("abs", 0x2A2u), cpu.a, cpu.m8?8:16);
    goto L_849097;
L_849097:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9097u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9097u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9097u, 5u, 3u, cpu.address("abs", 0x0649u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849097 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x649u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84909A;
L_84909A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x909Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x909Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x909Au, 5u, 3u, cpu.address("abs", 0x02CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84909A STA
    hw.write(cpu.address("abs", 0x2CEu), cpu.a, cpu.m8?8:16);
    goto L_84909D;
L_84909D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x909Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x909Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x909Du, 5u, 3u, cpu.address("abs", 0x0651u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84909D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x651u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8490A0;
L_8490A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A0u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A0u, 5u, 3u, cpu.address("abs", 0x014Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490A0 STA
    hw.write(cpu.address("abs", 0x14Cu), cpu.a, cpu.m8?8:16);
    goto L_8490A3;
L_8490A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A3u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490A3 BRA -> $8490E6
    goto L_8490E6;
L_8490A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A5u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490A5 SEP
    cpu.sep(0x20u);
    goto L_8490A7;
L_8490A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A7u, 4u, 3u, cpu.address("abs", 0x062Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490A7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8490AA;
L_8490AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90AAu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90AAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490AA BIT
    cpu.bit(0x1u, true);
    goto L_8490AC;
L_8490AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90ACu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90ACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490AC BNE -> $8490C8
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8490C8; }
    goto L_8490AE;
L_8490AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90AEu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90AEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490AE REP
    cpu.rep(0x20u);
    goto L_8490B0;
L_8490B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B0u, 5u, 3u, cpu.address("abs", 0x0633u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490B0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x633u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8490B3;
L_8490B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B3u, 5u, 3u, cpu.address("abs", 0x02A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490B3 STA
    hw.write(cpu.address("abs", 0x2A2u), cpu.a, cpu.m8?8:16);
    goto L_8490B6;
L_8490B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B6u, 5u, 3u, cpu.address("abs", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490B6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x63Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8490B9;
L_8490B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B9u, 5u, 3u, cpu.address("abs", 0x02CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490B9 STA
    hw.write(cpu.address("abs", 0x2CEu), cpu.a, cpu.m8?8:16);
    goto L_8490BC;
L_8490BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90BCu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90BCu, 5u, 3u, cpu.address("abs", 0x064Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490BC LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x64Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8490BF;
L_8490BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90BFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90BFu, 5u, 3u, cpu.address("abs", 0x014Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490BF STA
    hw.write(cpu.address("abs", 0x14Cu), cpu.a, cpu.m8?8:16);
    goto L_8490C2;
L_8490C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90C2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90C2u, 8u, 4u, 0x84B80Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8490C2 JSL -> $84B80F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x90C5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x90C6u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84B80Fu, 0x8490C2u); }
    goto L_8490C6;
L_8490C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90C6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x90C6u,0x8490C6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90C6u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90C6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490C6 BRA -> $8490E6
    goto L_8490E6;
L_8490C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90C8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90C8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490C8 REP
    cpu.rep(0x20u);
    goto L_8490CA;
L_8490CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90CAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90CAu, 5u, 3u, cpu.address("abs", 0x0635u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490CA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x635u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8490CD;
L_8490CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90CDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90CDu, 5u, 3u, cpu.address("abs", 0x02A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490CD STA
    hw.write(cpu.address("abs", 0x2A2u), cpu.a, cpu.m8?8:16);
    goto L_8490D0;
L_8490D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90D0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90D0u, 5u, 3u, cpu.address("abs", 0x064Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490D0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x64Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8490D3;
L_8490D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90D3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90D3u, 5u, 3u, cpu.address("abs", 0x014Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490D3 STA
    hw.write(cpu.address("abs", 0x14Cu), cpu.a, cpu.m8?8:16);
    goto L_8490D6;
L_8490D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90D6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90D6u, 5u, 3u, cpu.address("abs", 0x06FDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490D6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6FDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8490D9;
L_8490D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90D9u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90D9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490D9 BIT
    cpu.bit(0x1u, true);
    goto L_8490DC;
L_8490DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90DCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90DCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490DC BNE -> $8490E6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8490E6; }
    goto L_8490DE;
L_8490DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90DEu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90DEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490DE REP
    cpu.rep(0x20u);
    goto L_8490E0;
L_8490E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90E0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90E0u, 5u, 3u, cpu.address("abs", 0x0641u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490E0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x641u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8490E3;
L_8490E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90E3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90E3u, 5u, 3u, cpu.address("abs", 0x02CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490E3 STA
    hw.write(cpu.address("abs", 0x2CEu), cpu.a, cpu.m8?8:16);
    goto L_8490E6;
L_8490E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90E6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90E6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8490E6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8490E6u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8490E6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_849C6F_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849C6Fu: goto L_849C6F;
    case 0x849C71u: goto L_849C71;
    case 0x849C74u: goto L_849C74;
    case 0x849C76u: goto L_849C76;
    case 0x849C78u: goto L_849C78;
    case 0x849C7Bu: goto L_849C7B;
    case 0x849C7Cu: goto L_849C7C;
    case 0x849C7Du: goto L_849C7D;
    case 0x849C80u: goto L_849C80;
    case 0x849C83u: goto L_849C83;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849C6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C6Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C6Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C6F SEP
    cpu.sep(0x20u);
    goto L_849C71;
L_849C71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C71u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C71u, 4u, 3u, cpu.address("abs", 0x06FDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C71 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6FDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849C74;
L_849C74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C74u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C74u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C74 AND
    cpu.logicAnd(0x1u);
    goto L_849C76;
L_849C76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C76u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C76u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C76 REP
    cpu.rep(0x20u);
    goto L_849C78;
L_849C78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C78u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C78u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C78 AND
    cpu.logicAnd(0xFFu);
    goto L_849C7B;
L_849C7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C7Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C7Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C7B ASL
    cpu.aslA();
    goto L_849C7C;
L_849C7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C7Cu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C7Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849C7C TAX
    cpu.transfer("TAX");
    goto L_849C7D;
L_849C7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C7Du,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C7Du, 5u, 3u, cpu.address("abs", 0x9C82u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849C7D PEA
    cpu.push16Value(hw, 0x9C82u);
    goto L_849C80;
L_849C80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C80u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C80u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x9C84u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $849C80 JMP (9C84,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x9C84u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x849C80u); return; }
L_849C83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C83u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C83u,0x849C83u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C83u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C83u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849C83 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849C83u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849C83u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_849F1F_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849F1Fu: goto L_849F1F;
    case 0x849F21u: goto L_849F21;
    case 0x849F24u: goto L_849F24;
    case 0x849F26u: goto L_849F26;
    case 0x849F29u: goto L_849F29;
    case 0x849F2Bu: goto L_849F2B;
    case 0x849F2Fu: goto L_849F2F;
    case 0x849F32u: goto L_849F32;
    case 0x849F34u: goto L_849F34;
    case 0x849F37u: goto L_849F37;
    case 0x849F39u: goto L_849F39;
    case 0x849F3Du: goto L_849F3D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849F1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849F1F REP
    cpu.rep(0x20u);
    goto L_849F21;
L_849F21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F21u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F21u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849F21 LDA
    cpu.setA(0x9F3Eu, 16);
    goto L_849F24;
L_849F24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F24u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F24u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849F24 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_849F26;
L_849F26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F26u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F26u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849F26 LDA
    cpu.setA(0x84u, 16);
    goto L_849F29;
L_849F29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F29u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F29u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849F29 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_849F2B;
L_849F2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Bu, 8u, 4u, 0x808B4Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849F2B JSL -> $808B4C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9F2Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9F2Fu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808B4Cu, 0x849F2Bu); }
    goto L_849F2F;
L_849F2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F2Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F2Fu,0x849F2Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849F2F LDA
    cpu.setA(0x9F46u, 16);
    goto L_849F32;
L_849F32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F32u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F32u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849F32 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_849F34;
L_849F34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F34u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F34u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849F34 LDA
    cpu.setA(0x84u, 16);
    goto L_849F37;
L_849F37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F37u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F37u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849F37 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_849F39;
L_849F39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F39u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F39u, 8u, 4u, 0x808B4Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849F39 JSL -> $808B4C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9F3Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9F3Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808B4Cu, 0x849F39u); }
    goto L_849F3D;
L_849F3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F3Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F3Du,0x849F3Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849F3D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849F3Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849F3Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84C5D5_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84C5D5u: goto L_84C5D5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84C5D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5D5u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5D5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84C5D5 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x84C5D5u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84C5D5u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_84C5D5_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84C5D5u: goto L_84C5D5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84C5D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5D5u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5D5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84C5D5 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x84C5D5u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84C5D5u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

