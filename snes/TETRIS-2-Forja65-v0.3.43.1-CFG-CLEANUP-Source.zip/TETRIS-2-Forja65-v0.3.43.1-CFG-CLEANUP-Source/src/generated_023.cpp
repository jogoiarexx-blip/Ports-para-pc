#include "generated.hpp"
void sub_388F1B_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x388F1Bu: goto L_388F1B;
    case 0x388F1Du: goto L_388F1D;
    case 0x388F1Fu: goto L_388F1F;
    case 0x388F20u: goto L_388F20;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_388F1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Bu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Bu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $388F1B ROL
    cpu.rolMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_388F1D;
L_388F1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Du,cpu,0xA1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Du, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x56u + cpu.x) & 0xFFFFu), 2u, 0u);
    // $388F1D LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectX(hw, 0x56u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_388F1F;
L_388F1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F1Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $388F1F CLC
    cpu.setFlag('C', false);
    goto L_388F20;
L_388F20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8F20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8F20u,cpu,0x40u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8F20u, 7u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $388F20 RTI stack real
    {auto dst=cpu.returnInterrupt(hw);hw.requestDispatch(dst,0x388F20u);return;}
}

void sub_808065_E0M1X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808065u: goto L_808065;
    case 0x808069u: goto L_808069;
    case 0x80806Bu: goto L_80806B;
    case 0x80806Fu: goto L_80806F;
    case 0x808073u: goto L_808073;
    case 0x808076u: goto L_808076;
    case 0x808078u: goto L_808078;
    case 0x80807Bu: goto L_80807B;
    case 0x80807Cu: goto L_80807C;
    case 0x80807Eu: goto L_80807E;
    case 0x808080u: goto L_808080;
    case 0x808083u: goto L_808083;
    case 0x808085u: goto L_808085;
    case 0x808089u: goto L_808089;
    case 0x80808Du: goto L_80808D;
    case 0x808090u: goto L_808090;
    case 0x808093u: goto L_808093;
    case 0x808095u: goto L_808095;
    case 0x808099u: goto L_808099;
    case 0x80809Du: goto L_80809D;
    case 0x8080A1u: goto L_8080A1;
    case 0x8080A3u: goto L_8080A3;
    case 0x8080A6u: goto L_8080A6;
    case 0x8080A8u: goto L_8080A8;
    case 0x8080AAu: goto L_8080AA;
    case 0x8080AEu: goto L_8080AE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808065:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8065u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8065u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8065u, 8u, 4u, 0x82BB9Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808065 JSL -> $82BB9A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8068u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8069u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82BB9Au, 0x808065u); }
    goto L_808069;
L_808069:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8069u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8069u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8069u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808069 SEP
    cpu.sep(0x24u);
    goto L_80806B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8069u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8069u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808069 SEP
    cpu.sep(0x24u);
    goto L_80806B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8069u,0x808069u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80806B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x806Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x806Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x806Bu, 8u, 4u, 0x808556u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80806B JSL -> $808556 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x806Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x806Fu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808556u, 0x80806Bu); }
    goto L_80806F;
L_80806F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x806Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x806Fu,0x80806Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x806Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x806Fu, 8u, 4u, 0x808572u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80806F JSL -> $808572 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8072u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8073u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808572u, 0x80806Fu); }
    goto L_808073;
L_808073:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8073u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8073u,0x808073u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8073u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8073u, 4u, 3u, cpu.address("abs", 0x420Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808073 STZ
    hw.write(cpu.address("abs", 0x420Cu), 0, cpu.m8?8:16);
    goto L_808076;
L_808076:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8076u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8076u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8076u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xB4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808076 STZ
    hw.write(cpu.address("dp", 0xB4u), 0, cpu.m8?8:16);
    goto L_808078;
L_808078:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8078u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8078u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8078u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808078 LDX
    cpu.setX(0x1FF0u, 16);
    goto L_80807B;
L_80807B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x807Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x807Bu,cpu,0x9Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x807Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80807B TXS
    cpu.transfer("TXS");
    goto L_80807C;
L_80807C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x807Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x807Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x807Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80807C STZ
    hw.write(cpu.address("dp", 0x96u), 0, cpu.m8?8:16);
    goto L_80807E;
L_80807E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x807Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x807Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x807Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80807E STZ
    hw.write(cpu.address("dp", 0x97u), 0, cpu.m8?8:16);
    goto L_808080;
L_808080:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8080u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8080u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8080u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808080 LDX
    cpu.setX(0x200u, 16);
    goto L_808083;
L_808083:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8083u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8083u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8083u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808083 STX
    hw.write(cpu.address("dp", 0x98u), cpu.x, cpu.x8?8:16);
    goto L_808085;
L_808085:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8085u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8085u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8085u, 8u, 4u, 0x808ADEu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808085 JSL -> $808ADE stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8088u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8089u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808ADEu, 0x808085u); }
    goto L_808089;
L_808089:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8089u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8089u,0x808089u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8089u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8089u, 8u, 4u, 0x808B92u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808089 JSL -> $808B92 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x808Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x808Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808B92u, 0x808089u); }
    goto L_80808D;
L_80808D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x808Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x808Du,0x80808Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x808Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x808Du, 6u, 3u, cpu.address("abs", 0x82A7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80808D JSR -> $8082A7 stack real
    { cpu.push16Value(hw,0x808Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8090u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x82A7u), 0x80808Du); }
    goto L_808090;
L_808090:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8090u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8090u,0x808090u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8090u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8090u, 6u, 3u, cpu.address("abs", 0x85ADu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808090 JSR -> $8085AD stack real
    { cpu.push16Value(hw,0x8092u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8093u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x85ADu), 0x808090u); }
    goto L_808093;
L_808093:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8093u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8093u,0x808093u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8093u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8093u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808093 STZ
    hw.write(cpu.address("dp", 0x4Bu), 0, cpu.m8?8:16);
    goto L_808095;
L_808095:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8095u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8095u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8095u, 8u, 4u, 0x808547u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808095 JSL -> $808547 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8098u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8099u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808547u, 0x808095u); }
    goto L_808099;
L_808099:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8099u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8099u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8099u, 8u, 4u, 0x808D03u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808099 JSL -> $808D03 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x809Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x809Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D03u, 0x808099u); }
    goto L_80809D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8099u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8099u, 8u, 4u, 0x808D03u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808099 JSL -> $808D03 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x809Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x809Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D03u, 0x808099u); }
    goto L_80809D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8099u,0x808099u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80809D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x809Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x809Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x809Du, 8u, 4u, 0x8096A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80809D JSL -> $8096A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80A0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80A1u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8096A3u, 0x80809Du); }
    goto L_8080A1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x809Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x809Du, 8u, 4u, 0x8096A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80809D JSL -> $8096A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80A0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80A1u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8096A3u, 0x80809Du); }
    goto L_8080A1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x809Du,0x80809Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8080A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80A1u,0x8080A1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A1u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A1 SEP
    cpu.sep(0x20u);
    goto L_8080A3;
L_8080A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A3u, 6u, 3u, cpu.address("abs", 0x83A4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8080A3 JSR -> $8083A4 stack real
    { cpu.push16Value(hw,0x80A5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80A6u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x83A4u), 0x8080A3u); }
    goto L_8080A6;
L_8080A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A6u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x46u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8080A8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x46u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8080A8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80A6u,0x8080A6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8080A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A8u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A8u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A8 BPL -> $808099
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808099; }
    goto L_8080AA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A8u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A8 BPL -> $808099
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808099; }
    goto L_8080AA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80A8u,0x8080A8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8080AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80AAu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu, 8u, 4u, 0x808556u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080AA JSL -> $808556 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80ADu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80AEu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808556u, 0x8080AAu); }
    goto L_8080AE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu, 8u, 4u, 0x808556u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080AA JSL -> $808556 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80ADu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80AEu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808556u, 0x8080AAu); }
    goto L_8080AE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80AAu,0x8080AAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8080AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80AEu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080AE BRA -> $808069
    goto L_808069;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080AE BRA -> $808069
    goto L_808069;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80AEu,0x8080AEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_808065_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808065u: goto L_808065;
    case 0x808069u: goto L_808069;
    case 0x80806Bu: goto L_80806B;
    case 0x80806Fu: goto L_80806F;
    case 0x808073u: goto L_808073;
    case 0x808076u: goto L_808076;
    case 0x808078u: goto L_808078;
    case 0x80807Bu: goto L_80807B;
    case 0x80807Cu: goto L_80807C;
    case 0x80807Eu: goto L_80807E;
    case 0x808080u: goto L_808080;
    case 0x808083u: goto L_808083;
    case 0x808085u: goto L_808085;
    case 0x808089u: goto L_808089;
    case 0x80808Du: goto L_80808D;
    case 0x808090u: goto L_808090;
    case 0x808093u: goto L_808093;
    case 0x808095u: goto L_808095;
    case 0x808099u: goto L_808099;
    case 0x80809Du: goto L_80809D;
    case 0x8080A1u: goto L_8080A1;
    case 0x8080A3u: goto L_8080A3;
    case 0x8080A6u: goto L_8080A6;
    case 0x8080A8u: goto L_8080A8;
    case 0x8080AAu: goto L_8080AA;
    case 0x8080AEu: goto L_8080AE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808065:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8065u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8065u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8065u, 8u, 4u, 0x82BB9Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808065 JSL -> $82BB9A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8068u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8069u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82BB9Au, 0x808065u); }
    goto L_808069;
L_808069:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8069u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8069u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8069u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808069 SEP
    cpu.sep(0x24u);
    goto L_80806B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8069u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8069u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808069 SEP
    cpu.sep(0x24u);
    goto L_80806B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8069u,0x808069u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80806B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x806Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x806Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x806Bu, 8u, 4u, 0x808556u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80806B JSL -> $808556 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x806Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x806Fu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808556u, 0x80806Bu); }
    goto L_80806F;
L_80806F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x806Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x806Fu,0x80806Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x806Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x806Fu, 8u, 4u, 0x808572u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80806F JSL -> $808572 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8072u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8073u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808572u, 0x80806Fu); }
    goto L_808073;
L_808073:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8073u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8073u,0x808073u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8073u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8073u, 4u, 3u, cpu.address("abs", 0x420Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808073 STZ
    hw.write(cpu.address("abs", 0x420Cu), 0, cpu.m8?8:16);
    goto L_808076;
L_808076:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8076u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8076u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8076u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xB4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808076 STZ
    hw.write(cpu.address("dp", 0xB4u), 0, cpu.m8?8:16);
    goto L_808078;
L_808078:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8078u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8078u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8078u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808078 LDX
    cpu.setX(0x1FF0u, 16);
    goto L_80807B;
L_80807B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x807Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x807Bu,cpu,0x9Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x807Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80807B TXS
    cpu.transfer("TXS");
    goto L_80807C;
L_80807C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x807Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x807Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x807Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80807C STZ
    hw.write(cpu.address("dp", 0x96u), 0, cpu.m8?8:16);
    goto L_80807E;
L_80807E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x807Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x807Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x807Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80807E STZ
    hw.write(cpu.address("dp", 0x97u), 0, cpu.m8?8:16);
    goto L_808080;
L_808080:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8080u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8080u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8080u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808080 LDX
    cpu.setX(0x200u, 16);
    goto L_808083;
L_808083:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8083u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8083u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8083u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808083 STX
    hw.write(cpu.address("dp", 0x98u), cpu.x, cpu.x8?8:16);
    goto L_808085;
L_808085:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8085u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8085u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8085u, 8u, 4u, 0x808ADEu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808085 JSL -> $808ADE stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8088u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8089u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808ADEu, 0x808085u); }
    goto L_808089;
L_808089:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8089u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8089u,0x808089u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8089u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8089u, 8u, 4u, 0x808B92u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808089 JSL -> $808B92 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x808Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x808Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808B92u, 0x808089u); }
    goto L_80808D;
L_80808D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x808Du))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x808Du,0x80808Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x808Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x808Du, 6u, 3u, cpu.address("abs", 0x82A7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80808D JSR -> $8082A7 stack real
    { cpu.push16Value(hw,0x808Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8090u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x82A7u), 0x80808Du); }
    goto L_808090;
L_808090:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8090u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8090u,0x808090u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8090u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8090u, 6u, 3u, cpu.address("abs", 0x85ADu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808090 JSR -> $8085AD stack real
    { cpu.push16Value(hw,0x8092u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8093u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x85ADu), 0x808090u); }
    goto L_808093;
L_808093:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8093u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8093u,0x808093u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8093u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8093u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808093 STZ
    hw.write(cpu.address("dp", 0x4Bu), 0, cpu.m8?8:16);
    goto L_808095;
L_808095:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8095u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8095u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8095u, 8u, 4u, 0x808547u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808095 JSL -> $808547 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8098u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8099u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808547u, 0x808095u); }
    goto L_808099;
L_808099:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8099u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8099u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8099u, 8u, 4u, 0x808D03u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808099 JSL -> $808D03 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x809Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x809Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D03u, 0x808099u); }
    goto L_80809D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8099u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8099u, 8u, 4u, 0x808D03u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808099 JSL -> $808D03 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x809Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x809Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D03u, 0x808099u); }
    goto L_80809D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8099u,0x808099u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80809D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x809Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x809Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x809Du, 8u, 4u, 0x8096A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80809D JSL -> $8096A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80A0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80A1u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8096A3u, 0x80809Du); }
    goto L_8080A1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x809Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x809Du, 8u, 4u, 0x8096A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80809D JSL -> $8096A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80A0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80A1u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8096A3u, 0x80809Du); }
    goto L_8080A1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x809Du,0x80809Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8080A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80A1u,0x8080A1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A1u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A1 SEP
    cpu.sep(0x20u);
    goto L_8080A3;
L_8080A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A3u, 6u, 3u, cpu.address("abs", 0x83A4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8080A3 JSR -> $8083A4 stack real
    { cpu.push16Value(hw,0x80A5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80A6u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x83A4u), 0x8080A3u); }
    goto L_8080A6;
L_8080A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A6u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x46u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8080A8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x46u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8080A8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80A6u,0x8080A6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8080A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A8u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A8u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A8 BPL -> $808099
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808099; }
    goto L_8080AA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A8u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A8 BPL -> $808099
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808099; }
    goto L_8080AA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80A8u,0x8080A8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8080AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80AAu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu, 8u, 4u, 0x808556u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080AA JSL -> $808556 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80ADu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80AEu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808556u, 0x8080AAu); }
    goto L_8080AE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu, 8u, 4u, 0x808556u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080AA JSL -> $808556 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80ADu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80AEu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808556u, 0x8080AAu); }
    goto L_8080AE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80AAu,0x8080AAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8080AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80AEu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080AE BRA -> $808069
    goto L_808069;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080AE BRA -> $808069
    goto L_808069;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80AEu,0x8080AEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_808084_E0M0X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808069u: goto L_808069;
    case 0x80806Bu: goto L_80806B;
    case 0x80806Fu: goto L_80806F;
    case 0x808073u: goto L_808073;
    case 0x808076u: goto L_808076;
    case 0x808078u: goto L_808078;
    case 0x80807Au: goto L_80807A;
    case 0x80807Eu: goto L_80807E;
    case 0x808080u: goto L_808080;
    case 0x808082u: goto L_808082;
    case 0x808084u: goto L_808084;
    case 0x808085u: goto L_808085;
    case 0x808089u: goto L_808089;
    case 0x80808Du: goto L_80808D;
    case 0x808090u: goto L_808090;
    case 0x808093u: goto L_808093;
    case 0x808095u: goto L_808095;
    case 0x808099u: goto L_808099;
    case 0x80809Du: goto L_80809D;
    case 0x8080A1u: goto L_8080A1;
    case 0x8080A3u: goto L_8080A3;
    case 0x8080A6u: goto L_8080A6;
    case 0x8080A8u: goto L_8080A8;
    case 0x8080AAu: goto L_8080AA;
    case 0x8080AEu: goto L_8080AE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808069:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8069u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8069u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8069u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808069 SEP
    cpu.sep(0x24u);
    goto L_80806B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8069u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8069u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808069 SEP
    cpu.sep(0x24u);
    goto L_80806B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8069u,0x808069u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80806B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x806Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x806Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x806Bu, 8u, 4u, 0x808556u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80806B JSL -> $808556 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x806Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x806Fu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808556u, 0x80806Bu); }
    goto L_80806F;
L_80806F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x806Fu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x806Fu,0x80806Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x806Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x806Fu, 8u, 4u, 0x808572u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80806F JSL -> $808572 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8072u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8073u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808572u, 0x80806Fu); }
    goto L_808073;
L_808073:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8073u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8073u,0x808073u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8073u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8073u, 4u, 3u, cpu.address("abs", 0x420Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808073 STZ
    hw.write(cpu.address("abs", 0x420Cu), 0, cpu.m8?8:16);
    goto L_808076;
L_808076:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8076u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8076u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8076u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xB4u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808076 STZ
    hw.write(cpu.address("dp", 0xB4u), 0, cpu.m8?8:16);
    goto L_808078;
L_808078:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8078u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8078u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8078u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808078 LDX
    cpu.setX(0xF0u, 8);
    goto L_80807A;
L_80807A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x807Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x807Au,cpu,0x1Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x807Au, 5u, 4u, ((0x96649Au + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80807A ORA
    cpu.logicOr(hw.readW(((0x96649Au + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_80807E;
L_80807E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x807Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x807Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x807Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80807E STZ
    hw.write(cpu.address("dp", 0x97u), 0, cpu.m8?8:16);
    goto L_808080;
L_808080:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8080u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8080u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8080u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808080 LDX
    cpu.setX(0x0u, 8);
    goto L_808082;
L_808082:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8082u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8082u,cpu,0x02u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8082u, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $808082 COP
    hw.partial(0x808082u, "COP"); return;
L_808084:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8084u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8084u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8084u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808084 TYA
    cpu.transfer("TYA");
    goto L_808085;
L_808085:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8085u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8085u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8085u, 8u, 4u, 0x808ADEu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808085 JSL -> $808ADE stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8088u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8089u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808ADEu, 0x808085u); }
    goto L_808089;
L_808089:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8089u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8089u,0x808089u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8089u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8089u, 8u, 4u, 0x808B92u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808089 JSL -> $808B92 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x808Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x808Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808B92u, 0x808089u); }
    goto L_80808D;
L_80808D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x808Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x808Du,0x80808Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x808Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x808Du, 6u, 3u, cpu.address("abs", 0x82A7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80808D JSR -> $8082A7 stack real
    { cpu.push16Value(hw,0x808Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8090u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x82A7u), 0x80808Du); }
    goto L_808090;
L_808090:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8090u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8090u,0x808090u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8090u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8090u, 6u, 3u, cpu.address("abs", 0x85ADu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808090 JSR -> $8085AD stack real
    { cpu.push16Value(hw,0x8092u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8093u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x85ADu), 0x808090u); }
    goto L_808093;
L_808093:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8093u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8093u,0x808093u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8093u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8093u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808093 STZ
    hw.write(cpu.address("dp", 0x4Bu), 0, cpu.m8?8:16);
    goto L_808095;
L_808095:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8095u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8095u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8095u, 8u, 4u, 0x808547u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808095 JSL -> $808547 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8098u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8099u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808547u, 0x808095u); }
    goto L_808099;
L_808099:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8099u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8099u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8099u, 8u, 4u, 0x808D03u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808099 JSL -> $808D03 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x809Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x809Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D03u, 0x808099u); }
    goto L_80809D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8099u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8099u, 8u, 4u, 0x808D03u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808099 JSL -> $808D03 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x809Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x809Du,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D03u, 0x808099u); }
    goto L_80809D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8099u,0x808099u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80809D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x809Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x809Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x809Du, 8u, 4u, 0x8096A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80809D JSL -> $8096A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80A0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80A1u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8096A3u, 0x80809Du); }
    goto L_8080A1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x809Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x809Du, 8u, 4u, 0x8096A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80809D JSL -> $8096A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80A0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80A1u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8096A3u, 0x80809Du); }
    goto L_8080A1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x809Du,0x80809Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8080A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80A1u,0x8080A1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A1u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A1 SEP
    cpu.sep(0x20u);
    goto L_8080A3;
L_8080A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A3u, 6u, 3u, cpu.address("abs", 0x83A4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8080A3 JSR -> $8083A4 stack real
    { cpu.push16Value(hw,0x80A5u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80A6u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x83A4u), 0x8080A3u); }
    goto L_8080A6;
L_8080A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A6u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x46u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8080A8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x46u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8080A8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80A6u,0x8080A6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8080A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A8u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A8u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A8 BPL -> $808099
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808099; }
    goto L_8080AA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A8u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A8 BPL -> $808099
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808099; }
    goto L_8080AA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80A8u,0x8080A8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8080AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80AAu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu, 8u, 4u, 0x808556u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080AA JSL -> $808556 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80ADu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80AEu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808556u, 0x8080AAu); }
    goto L_8080AE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu, 8u, 4u, 0x808556u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080AA JSL -> $808556 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80ADu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80AEu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808556u, 0x8080AAu); }
    goto L_8080AE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80AAu,0x8080AAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8080AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80AEu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080AE BRA -> $808069
    goto L_808069;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080AE BRA -> $808069
    goto L_808069;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80AEu,0x8080AEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_8083C8_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8083C8u: goto L_8083C8;
    case 0x8083C9u: goto L_8083C9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8083C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C8u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C8u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8083C8 PLP
    cpu.pop("PLP", hw);
    goto L_8083C9;
L_8083C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C9u))return;
  // 4 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8083C9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8083C9u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8083C9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8083C9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8083C9u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8083C9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8083C9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8083C9u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8083C9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8083C9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8083C9u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8083C9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83C9u,0x8083C9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_8083C8_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8083C8u: goto L_8083C8;
    case 0x8083C9u: goto L_8083C9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8083C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C8u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C8u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8083C8 PLP
    cpu.pop("PLP", hw);
    goto L_8083C9;
L_8083C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C9u))return;
  // 4 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8083C9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8083C9u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8083C9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8083C9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8083C9u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8083C9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8083C9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8083C9u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8083C9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C9u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8083C9 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8083C9u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8083C9u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83C9u,0x8083C9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80843D_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80843Du: goto L_80843D;
    case 0x808440u: goto L_808440;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80843D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x843Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x843Du,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x843Du, 6u, 3u, cpu.address("absx", 0x9F82u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80843D STZ
    hw.write(cpu.address("absx", 0x9F82u), 0, cpu.m8?8:16);
    goto L_808440;
L_808440:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8440u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8440u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8440u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808440 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808440u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808440u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808759_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808759u: goto L_808759;
    case 0x80875Au: goto L_80875A;
    case 0x80875Cu: goto L_80875C;
    case 0x80875Eu: goto L_80875E;
    case 0x808760u: goto L_808760;
    case 0x808761u: goto L_808761;
    case 0x808762u: goto L_808762;
    case 0x808764u: goto L_808764;
    case 0x808766u: goto L_808766;
    case 0x808767u: goto L_808767;
    case 0x808769u: goto L_808769;
    case 0x80876Bu: goto L_80876B;
    case 0x80876Du: goto L_80876D;
    case 0x80876Eu: goto L_80876E;
    case 0x808770u: goto L_808770;
    case 0x808772u: goto L_808772;
    case 0x808773u: goto L_808773;
    case 0x808774u: goto L_808774;
    case 0x808776u: goto L_808776;
    case 0x808777u: goto L_808777;
    case 0x808779u: goto L_808779;
    case 0x80877Au: goto L_80877A;
    case 0x80877Bu: goto L_80877B;
    case 0x80877Cu: goto L_80877C;
    case 0x80877Eu: goto L_80877E;
    case 0x808780u: goto L_808780;
    case 0x808783u: goto L_808783;
    case 0x808785u: goto L_808785;
    case 0x808786u: goto L_808786;
    case 0x808788u: goto L_808788;
    case 0x80878Au: goto L_80878A;
    case 0x80878Cu: goto L_80878C;
    case 0x80878Eu: goto L_80878E;
    case 0x808790u: goto L_808790;
    case 0x808793u: goto L_808793;
    case 0x808795u: goto L_808795;
    case 0x808797u: goto L_808797;
    case 0x80879Au: goto L_80879A;
    case 0x80879Cu: goto L_80879C;
    case 0x80879Eu: goto L_80879E;
    case 0x80879Fu: goto L_80879F;
    case 0x8087A2u: goto L_8087A2;
    case 0x8087A4u: goto L_8087A4;
    case 0x8087A5u: goto L_8087A5;
    case 0x8087A7u: goto L_8087A7;
    case 0x8087A9u: goto L_8087A9;
    case 0x8087ABu: goto L_8087AB;
    case 0x8087ADu: goto L_8087AD;
    case 0x8087AFu: goto L_8087AF;
    case 0x8087B1u: goto L_8087B1;
    case 0x8087B2u: goto L_8087B2;
    case 0x8087B3u: goto L_8087B3;
    case 0x8087B4u: goto L_8087B4;
    case 0x8087B5u: goto L_8087B5;
    case 0x8087B7u: goto L_8087B7;
    case 0x8087B8u: goto L_8087B8;
    case 0x8087BAu: goto L_8087BA;
    case 0x8087BCu: goto L_8087BC;
    case 0x8087BDu: goto L_8087BD;
    case 0x8087BFu: goto L_8087BF;
    case 0x8087C1u: goto L_8087C1;
    case 0x8087C3u: goto L_8087C3;
    case 0x8087C5u: goto L_8087C5;
    case 0x8087C7u: goto L_8087C7;
    case 0x8087C9u: goto L_8087C9;
    case 0x8087CBu: goto L_8087CB;
    case 0x8087CDu: goto L_8087CD;
    case 0x8087CFu: goto L_8087CF;
    case 0x8087D2u: goto L_8087D2;
    case 0x8087D3u: goto L_8087D3;
    case 0x8087D4u: goto L_8087D4;
    case 0x8087D6u: goto L_8087D6;
    case 0x8087D7u: goto L_8087D7;
    case 0x8087D8u: goto L_8087D8;
    case 0x8087D9u: goto L_8087D9;
    case 0x8087DAu: goto L_8087DA;
    case 0x8087DBu: goto L_8087DB;
    case 0x8087DCu: goto L_8087DC;
    case 0x8087DDu: goto L_8087DD;
    case 0x8087DFu: goto L_8087DF;
    case 0x8087E2u: goto L_8087E2;
    case 0x8087E3u: goto L_8087E3;
    case 0x8087E5u: goto L_8087E5;
    case 0x8087E8u: goto L_8087E8;
    case 0x8087ECu: goto L_8087EC;
    case 0x8087F0u: goto L_8087F0;
    case 0x8087F3u: goto L_8087F3;
    case 0x8087F4u: goto L_8087F4;
    case 0x8087F5u: goto L_8087F5;
    case 0x8087F8u: goto L_8087F8;
    case 0x8087FAu: goto L_8087FA;
    case 0x8087FCu: goto L_8087FC;
    case 0x8087FEu: goto L_8087FE;
    case 0x8087FFu: goto L_8087FF;
    case 0x808802u: goto L_808802;
    case 0x808804u: goto L_808804;
    case 0x808806u: goto L_808806;
    case 0x808808u: goto L_808808;
    case 0x80880Au: goto L_80880A;
    case 0x80880Cu: goto L_80880C;
    case 0x80880Eu: goto L_80880E;
    case 0x808810u: goto L_808810;
    case 0x808812u: goto L_808812;
    case 0x808813u: goto L_808813;
    case 0x808815u: goto L_808815;
    case 0x808817u: goto L_808817;
    case 0x808818u: goto L_808818;
    case 0x80881Au: goto L_80881A;
    case 0x80881Cu: goto L_80881C;
    case 0x80881Eu: goto L_80881E;
    case 0x808820u: goto L_808820;
    case 0x808822u: goto L_808822;
    case 0x808824u: goto L_808824;
    case 0x808826u: goto L_808826;
    case 0x808828u: goto L_808828;
    case 0x80882Au: goto L_80882A;
    case 0x80882Cu: goto L_80882C;
    case 0x80882Du: goto L_80882D;
    case 0x80882Eu: goto L_80882E;
    case 0x80882Fu: goto L_80882F;
    case 0x808830u: goto L_808830;
    case 0x808831u: goto L_808831;
    case 0x808834u: goto L_808834;
    case 0x808836u: goto L_808836;
    case 0x808838u: goto L_808838;
    case 0x80883Au: goto L_80883A;
    case 0x80883Du: goto L_80883D;
    case 0x808840u: goto L_808840;
    case 0x808841u: goto L_808841;
    case 0x808843u: goto L_808843;
    case 0x808846u: goto L_808846;
    case 0x808848u: goto L_808848;
    case 0x80884Au: goto L_80884A;
    case 0x80884Cu: goto L_80884C;
    case 0x80884Eu: goto L_80884E;
    case 0x808851u: goto L_808851;
    case 0x808853u: goto L_808853;
    case 0x808855u: goto L_808855;
    case 0x808858u: goto L_808858;
    case 0x808859u: goto L_808859;
    case 0x80885Au: goto L_80885A;
    case 0x80885Bu: goto L_80885B;
    case 0x80885Cu: goto L_80885C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808759:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8759u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8759u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8759u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808759 PHP
    cpu.push("PHP", hw);
    goto L_80875A;
L_80875A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x875Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x875Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x875Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80875A REP
    cpu.rep(0x20u);
    goto L_80875C;
L_80875C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x875Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x875Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x875Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80875C STZ
    hw.write(cpu.address("dp", 0x3u), 0, cpu.m8?8:16);
    goto L_80875E;
L_80875E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x875Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x875Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x875Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80875E STZ
    hw.write(cpu.address("dp", 0x4u), 0, cpu.m8?8:16);
    goto L_808760;
L_808760:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8760u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8760u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8760u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808760 PLP
    cpu.pop("PLP", hw);
    goto L_808761;
L_808761:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8761u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8761u,0x808761u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8761u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8761u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808761 PHP
    cpu.push("PHP", hw);
    goto L_808762;
L_808762:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8762u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8762u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8762u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808762 REP
    cpu.rep(0x20u);
    goto L_808764;
L_808764:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8764u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8764u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8764u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808764 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808766;
L_808766:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8766u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8766u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8766u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808766 CLC
    cpu.setFlag('C', false);
    goto L_808767;
L_808767:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8767u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8767u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8767u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808767 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16));
    goto L_808769;
L_808769:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8769u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8769u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8769u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808769 STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_80876B;
L_80876B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x876Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x876Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x876Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80876B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80876D;
L_80876D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x876Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x876Du,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x876Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80876D SEC
    cpu.setFlag('C', true);
    goto L_80876E;
L_80876E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x876Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x876Eu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x876Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x92u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80876E SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x92u), cpu.m8?8:16));
    goto L_808770;
L_808770:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8770u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8770u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8770u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808770 STA
    hw.write(cpu.address("dp", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_808772;
L_808772:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8772u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8772u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8772u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808772 PLP
    cpu.pop("PLP", hw);
    goto L_808773;
L_808773:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8773u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8773u,0x808773u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8773u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8773u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808773 PHP
    cpu.push("PHP", hw);
    goto L_808774;
L_808774:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8774u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8774u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8774u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808774 SEP
    cpu.sep(0x20u);
    goto L_808776;
L_808776:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8776u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8776u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8776u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808776 PHB
    cpu.push("PHB", hw);
    goto L_808777;
L_808777:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8777u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8777u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8777u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808777 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808779;
L_808779:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8779u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8779u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8779u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808779 PHA
    cpu.push("PHA", hw);
    goto L_80877A;
L_80877A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x877Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x877Au,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x877Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80877A PLB
    cpu.pop("PLB", hw);
    goto L_80877B;
L_80877B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x877Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x877Bu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x877Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80877B PHX
    cpu.push("PHX", hw);
    goto L_80877C;
L_80877C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x877Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x877Cu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x877Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80877C LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80877E;
L_80877E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x877Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x877Eu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x877Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80877E LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x96u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_808780;
L_808780:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8780u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8780u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8780u, 4u + 1u, 3u, cpu.address("absy", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808780 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808783;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8780u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8780u, 4u + 1u, 3u, cpu.address("absy", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808780 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808783;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8780u,0x808780u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_808783:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8783u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8783u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8783u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808783 BMI -> $8087AF
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_8087AF; }
    goto L_808785;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8783u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8783u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808783 BMI -> $8087AF
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_8087AF; }
    goto L_808785;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8783u,0x808783u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_808785:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8785u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8785u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8785u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808785 ASL
    cpu.aslA();
    goto L_808786;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8785u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8785u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808785 ASL
    cpu.aslA();
    goto L_808786;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8785u,0x808785u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_808786:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8786u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8786u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8786u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808786 STA
    hw.write(cpu.address("dp", 0x16u), cpu.a, cpu.m8?8:16);
    goto L_808788;
L_808788:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8788u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8788u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8788u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808788 BEQ -> $80878C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80878C; }
    goto L_80878A;
L_80878A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x878Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x878Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x878Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80878A LDA
    cpu.setA(0x8u, 8);
    goto L_80878C;
L_80878C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x878Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x878Cu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x878Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80878C EOR
    cpu.logicXor(0xF8u);
    goto L_80878E;
L_80878E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x878Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x878Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x878Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x17u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80878E STA
    hw.write(cpu.address("dp", 0x17u), cpu.a, cpu.m8?8:16);
    goto L_808790;
L_808790:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8790u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8790u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8790u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808790 CPX
    cpu.compareX(0x200u);
    goto L_808793;
L_808793:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8793u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8793u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8793u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808793 BCS -> $8087AF
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_8087AF; }
    goto L_808795;
L_808795:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8795u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8795u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8795u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808795 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16), false);
    goto L_808797;
L_808797:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8797u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8797u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8797u, 4u + 1u, 3u, cpu.address("absy", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808797 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80879A;
L_80879A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x879Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x879Au,cpu,0x50u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x879Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80879A BVC -> $8087A2
    if (!cpu.v) { hw.addCpuInternalCycles(1u); goto L_8087A2; }
    goto L_80879C;
L_80879C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x879Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x879Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x879Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x17u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80879C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x17u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80879E;
L_80879E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x879Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x879Eu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x879Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80879E SEC
    cpu.setFlag('C', true);
    goto L_80879F;
L_80879F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x879Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x879Fu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x879Fu, 4u + 1u, 3u, cpu.address("absy", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80879F SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x1u), cpu.m8?8:16));
    goto L_8087A2;
L_8087A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A2u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087A2 BMI -> $8087B5
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_8087B5; }
    goto L_8087A4;
L_8087A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A4u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087A4 CLC
    cpu.setFlag('C', false);
    goto L_8087A5;
L_8087A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A5u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087A5 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16));
    goto L_8087A7;
L_8087A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087A7 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_8087A9;
L_8087A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087A9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8087AB;
L_8087AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87ABu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87ABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087AB ADC
    cpu.adc(0x0u);
    goto L_8087AD;
L_8087AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87ADu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87ADu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087AD BRA -> $8087C5
    goto L_8087C5;
L_8087AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87AFu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87AFu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87AFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087AF STX
    hw.write(cpu.address("dp", 0x96u), cpu.x, cpu.x8?8:16);
    goto L_8087B1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87AFu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87AFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087AF STX
    hw.write(cpu.address("dp", 0x96u), cpu.x, cpu.x8?8:16);
    goto L_8087B1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x87AFu,0x8087AFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8087B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B1u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B1u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B1u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8087B1 PLX
    cpu.pop("PLX", hw);
    goto L_8087B2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B1u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B1u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8087B1 PLX
    cpu.pop("PLX", hw);
    goto L_8087B2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x87B1u,0x8087B1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8087B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B2u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B2u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B2u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8087B2 PLB
    cpu.pop("PLB", hw);
    goto L_8087B3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B2u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B2u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8087B2 PLB
    cpu.pop("PLB", hw);
    goto L_8087B3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x87B2u,0x8087B2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8087B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B3u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B3u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B3u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8087B3 PLP
    cpu.pop("PLP", hw);
    goto L_8087B4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B3u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B3u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8087B3 PLP
    cpu.pop("PLP", hw);
    goto L_8087B4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x87B3u,0x8087B3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8087B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B4u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x87B4u,0x8087B4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B4u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8087B4 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8087B4u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8087B4u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_8087B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B5u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087B5 EOR
    cpu.logicXor(0xFFu);
    goto L_8087B7;
L_8087B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B7u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087B7 INC
    cpu.inc('A');
    goto L_8087B8;
L_8087B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087B8 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_8087BA;
L_8087BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87BAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87BAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087BA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8087BC;
L_8087BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87BCu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87BCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087BC SEC
    cpu.setFlag('C', true);
    goto L_8087BD;
L_8087BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87BDu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87BDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087BD SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_8087BF;
L_8087BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87BFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87BFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087BF STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_8087C1;
L_8087C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087C1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8087C3;
L_8087C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C3u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087C3 SBC
    cpu.sbc(0x0u);
    goto L_8087C5;
L_8087C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087C5 BEQ -> $8087CD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8087CD; }
    goto L_8087C7;
L_8087C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C7u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087C7 CMP
    cpu.compareA(0xFFu);
    goto L_8087C9;
L_8087C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087C9 BNE -> $80882C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80882C; }
    goto L_8087CB;
L_8087CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87CBu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87CBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087CB INC
    cpu.incMem(hw, cpu.address("dp", 0x16u), cpu.m8?8:16);
    goto L_8087CD;
L_8087CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87CDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87CDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087CD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8087CF;
L_8087CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87CFu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87CFu, 5u, 3u, cpu.address("absx", 0x1400u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087CF STA
    hw.write(cpu.address("absx", 0x1400u), cpu.a, cpu.m8?8:16);
    goto L_8087D2;
L_8087D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D2u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D2u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8087D2 PHX
    cpu.push("PHX", hw);
    goto L_8087D3;
L_8087D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D3u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D3u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8087D3 PHY
    cpu.push("PHY", hw);
    goto L_8087D4;
L_8087D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D4u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087D4 REP
    cpu.rep(0x20u);
    goto L_8087D6;
L_8087D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D6u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087D6 TXA
    cpu.transfer("TXA");
    goto L_8087D7;
L_8087D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D7u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087D7 LSR
    cpu.lsrA();
    goto L_8087D8;
L_8087D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D8u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087D8 LSR
    cpu.lsrA();
    goto L_8087D9;
L_8087D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D9u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087D9 LSR
    cpu.lsrA();
    goto L_8087DA;
L_8087DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DAu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087DA LSR
    cpu.lsrA();
    goto L_8087DB;
L_8087DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DBu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087DB TAY
    cpu.transfer("TAY");
    goto L_8087DC;
L_8087DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DCu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087DC TXA
    cpu.transfer("TXA");
    goto L_8087DD;
L_8087DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DDu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087DD ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16));
    goto L_8087DF;
L_8087DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DFu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087DF AND
    cpu.logicAnd(0xFu);
    goto L_8087E2;
L_8087E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E2u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087E2 TAX
    cpu.transfer("TAX");
    goto L_8087E3;
L_8087E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E3u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087E3 SEP
    cpu.sep(0x20u);
    goto L_8087E5;
L_8087E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E5u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E5u, 4u + 1u, 3u, cpu.address("absy", 0x1600u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087E5 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1600u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8087E8;
L_8087E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E8u,cpu,0x3Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E8u, 5u, 4u, ((0x80886Eu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087E8 AND
    cpu.logicAnd(hw.readW(((0x80886Eu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_8087EC;
L_8087EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87ECu,cpu,0x1Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87ECu, 5u, 4u, ((0x80885Eu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087EC ORA
    cpu.logicOr(hw.readW(((0x80885Eu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_8087F0;
L_8087F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87F0u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87F0u, 5u, 3u, cpu.address("absy", 0x1600u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087F0 STA
    hw.write(cpu.address("absy", 0x1600u), cpu.a, cpu.m8?8:16);
    goto L_8087F3;
L_8087F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87F3u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87F3u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8087F3 PLY
    cpu.pop("PLY", hw);
    goto L_8087F4;
L_8087F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87F4u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87F4u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8087F4 PLX
    cpu.pop("PLX", hw);
    goto L_8087F5;
L_8087F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87F5u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87F5u, 4u + 1u, 3u, cpu.address("absy", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087F5 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8087F8;
L_8087F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87F8u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87F8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087F8 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16), false);
    goto L_8087FA;
L_8087FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87FAu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87FAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087FA BPL -> $808802
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808802; }
    goto L_8087FC;
L_8087FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87FCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87FCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x17u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087FC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x17u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8087FE;
L_8087FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87FEu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87FEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087FE SEC
    cpu.setFlag('C', true);
    goto L_8087FF;
L_8087FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87FFu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87FFu, 4u + 1u, 3u, cpu.address("absy", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087FF SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16));
    goto L_808802;
L_808802:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8802u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8802u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8802u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808802 CMP
    cpu.compareA(0x80u);
    goto L_808804;
L_808804:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8804u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8804u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8804u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808804 BCS -> $808810
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_808810; }
    goto L_808806;
L_808806:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8806u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8806u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8806u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808806 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16));
    goto L_808808;
L_808808:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8808u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8808u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8808u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808808 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80880A;
L_80880A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x880Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x880Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x880Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80880A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80880C;
L_80880C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x880Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x880Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x880Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80880C ADC
    cpu.adc(0x0u);
    goto L_80880E;
L_80880E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x880Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x880Eu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x880Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80880E BRA -> $808820
    goto L_808820;
L_808810:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8810u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8810u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8810u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808810 EOR
    cpu.logicXor(0xFFu);
    goto L_808812;
L_808812:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8812u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8812u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8812u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808812 INC
    cpu.inc('A');
    goto L_808813;
L_808813:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8813u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8813u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8813u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808813 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_808815;
L_808815:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8815u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8815u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8815u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808815 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808817;
L_808817:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8817u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8817u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8817u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808817 SEC
    cpu.setFlag('C', true);
    goto L_808818;
L_808818:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8818u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8818u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8818u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808818 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_80881A;
L_80881A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x881Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x881Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x881Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80881A STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80881C;
L_80881C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x881Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x881Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x881Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80881C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80881E;
L_80881E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x881Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x881Eu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x881Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80881E SBC
    cpu.sbc(0x0u);
    goto L_808820;
L_808820:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8820u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8820u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8820u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808820 BEQ -> $808834
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_808834; }
    goto L_808822;
L_808822:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8822u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8822u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8822u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808822 CMP
    cpu.compareA(0xFFu);
    goto L_808824;
L_808824:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8824u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8824u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8824u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808824 BNE -> $80882C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80882C; }
    goto L_808826;
L_808826:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8826u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8826u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8826u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808826 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808828;
L_808828:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8828u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8828u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8828u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808828 CMP
    cpu.compareA(0xE0u);
    goto L_80882A;
L_80882A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x882Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x882Au,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x882Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80882A BCS -> $80883A
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80883A; }
    goto L_80882C;
L_80882C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x882Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x882Cu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x882Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80882C INY
    cpu.inc('Y');
    goto L_80882D;
L_80882D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x882Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x882Du,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x882Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80882D INY
    cpu.inc('Y');
    goto L_80882E;
L_80882E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x882Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x882Eu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x882Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80882E INY
    cpu.inc('Y');
    goto L_80882F;
L_80882F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x882Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x882Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x882Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80882F INY
    cpu.inc('Y');
    goto L_808830;
L_808830:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8830u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8830u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8830u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808830 INY
    cpu.inc('Y');
    goto L_808831;
L_808831:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8831u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8831u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8831u, 3u, 3u, cpu.address("abs", 0x8780u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808831 JMP -> $808780
    goto L_808780;
L_808834:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8834u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8834u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8834u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808834 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808836;
L_808836:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8836u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8836u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8836u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808836 CMP
    cpu.compareA(0xE0u);
    goto L_808838;
L_808838:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8838u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8838u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8838u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808838 BCS -> $80882C
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80882C; }
    goto L_80883A;
L_80883A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x883Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x883Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x883Au, 5u, 3u, cpu.address("absx", 0x1401u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80883A STA
    hw.write(cpu.address("absx", 0x1401u), cpu.a, cpu.m8?8:16);
    goto L_80883D;
L_80883D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x883Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x883Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x883Du, 4u + 1u, 3u, cpu.address("absy", 0x0003u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80883D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808840;
L_808840:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8840u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8840u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8840u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808840 CLC
    cpu.setFlag('C', false);
    goto L_808841;
L_808841:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8841u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8841u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8841u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808841 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_808843;
L_808843:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8843u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8843u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8843u, 5u, 3u, cpu.address("absx", 0x1402u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808843 STA
    hw.write(cpu.address("absx", 0x1402u), cpu.a, cpu.m8?8:16);
    goto L_808846;
L_808846:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8846u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8846u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8846u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808846 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808848;
L_808848:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8848u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8848u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8848u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808848 BCC -> $80884C
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80884C; }
    goto L_80884A;
L_80884A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x884Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x884Au,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x884Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80884A ORA
    cpu.logicOr(0x1u);
    goto L_80884C;
L_80884C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x884Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x884Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x884Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80884C STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_80884E;
L_80884E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x884Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x884Eu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x884Eu, 4u + 1u, 3u, cpu.address("absy", 0x0004u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80884E LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808851;
L_808851:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8851u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8851u,cpu,0x45u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8851u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808851 EOR
    cpu.logicXor(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16));
    goto L_808853;
L_808853:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8853u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8853u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8853u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808853 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x6u), cpu.m8?8:16));
    goto L_808855;
L_808855:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8855u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8855u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8855u, 5u, 3u, cpu.address("absx", 0x1403u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808855 STA
    hw.write(cpu.address("absx", 0x1403u), cpu.a, cpu.m8?8:16);
    goto L_808858;
L_808858:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8858u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8858u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8858u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808858 INX
    cpu.inc('X');
    goto L_808859;
L_808859:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8859u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8859u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8859u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808859 INX
    cpu.inc('X');
    goto L_80885A;
L_80885A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x885Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Au,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80885A INX
    cpu.inc('X');
    goto L_80885B;
L_80885B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x885Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Bu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80885B INX
    cpu.inc('X');
    goto L_80885C;
L_80885C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x885Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Cu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80885C BRA -> $80882C
    goto L_80882C;
}

void sub_808759_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808759u: goto L_808759;
    case 0x80875Au: goto L_80875A;
    case 0x80875Cu: goto L_80875C;
    case 0x80875Eu: goto L_80875E;
    case 0x808760u: goto L_808760;
    case 0x808761u: goto L_808761;
    case 0x808762u: goto L_808762;
    case 0x808764u: goto L_808764;
    case 0x808766u: goto L_808766;
    case 0x808767u: goto L_808767;
    case 0x808769u: goto L_808769;
    case 0x80876Bu: goto L_80876B;
    case 0x80876Du: goto L_80876D;
    case 0x80876Eu: goto L_80876E;
    case 0x808770u: goto L_808770;
    case 0x808772u: goto L_808772;
    case 0x808773u: goto L_808773;
    case 0x808774u: goto L_808774;
    case 0x808776u: goto L_808776;
    case 0x808777u: goto L_808777;
    case 0x808779u: goto L_808779;
    case 0x80877Au: goto L_80877A;
    case 0x80877Bu: goto L_80877B;
    case 0x80877Cu: goto L_80877C;
    case 0x80877Eu: goto L_80877E;
    case 0x808780u: goto L_808780;
    case 0x808783u: goto L_808783;
    case 0x808785u: goto L_808785;
    case 0x808786u: goto L_808786;
    case 0x808788u: goto L_808788;
    case 0x80878Au: goto L_80878A;
    case 0x80878Cu: goto L_80878C;
    case 0x80878Eu: goto L_80878E;
    case 0x808790u: goto L_808790;
    case 0x808793u: goto L_808793;
    case 0x808795u: goto L_808795;
    case 0x808797u: goto L_808797;
    case 0x80879Au: goto L_80879A;
    case 0x80879Cu: goto L_80879C;
    case 0x80879Eu: goto L_80879E;
    case 0x80879Fu: goto L_80879F;
    case 0x8087A2u: goto L_8087A2;
    case 0x8087A4u: goto L_8087A4;
    case 0x8087A5u: goto L_8087A5;
    case 0x8087A7u: goto L_8087A7;
    case 0x8087A9u: goto L_8087A9;
    case 0x8087ABu: goto L_8087AB;
    case 0x8087ADu: goto L_8087AD;
    case 0x8087AFu: goto L_8087AF;
    case 0x8087B1u: goto L_8087B1;
    case 0x8087B2u: goto L_8087B2;
    case 0x8087B3u: goto L_8087B3;
    case 0x8087B4u: goto L_8087B4;
    case 0x8087B5u: goto L_8087B5;
    case 0x8087B7u: goto L_8087B7;
    case 0x8087B8u: goto L_8087B8;
    case 0x8087BAu: goto L_8087BA;
    case 0x8087BCu: goto L_8087BC;
    case 0x8087BDu: goto L_8087BD;
    case 0x8087BFu: goto L_8087BF;
    case 0x8087C1u: goto L_8087C1;
    case 0x8087C3u: goto L_8087C3;
    case 0x8087C5u: goto L_8087C5;
    case 0x8087C7u: goto L_8087C7;
    case 0x8087C9u: goto L_8087C9;
    case 0x8087CBu: goto L_8087CB;
    case 0x8087CDu: goto L_8087CD;
    case 0x8087CFu: goto L_8087CF;
    case 0x8087D2u: goto L_8087D2;
    case 0x8087D3u: goto L_8087D3;
    case 0x8087D4u: goto L_8087D4;
    case 0x8087D6u: goto L_8087D6;
    case 0x8087D7u: goto L_8087D7;
    case 0x8087D8u: goto L_8087D8;
    case 0x8087D9u: goto L_8087D9;
    case 0x8087DAu: goto L_8087DA;
    case 0x8087DBu: goto L_8087DB;
    case 0x8087DCu: goto L_8087DC;
    case 0x8087DDu: goto L_8087DD;
    case 0x8087DFu: goto L_8087DF;
    case 0x8087E2u: goto L_8087E2;
    case 0x8087E3u: goto L_8087E3;
    case 0x8087E5u: goto L_8087E5;
    case 0x8087E8u: goto L_8087E8;
    case 0x8087ECu: goto L_8087EC;
    case 0x8087F0u: goto L_8087F0;
    case 0x8087F3u: goto L_8087F3;
    case 0x8087F4u: goto L_8087F4;
    case 0x8087F5u: goto L_8087F5;
    case 0x8087F8u: goto L_8087F8;
    case 0x8087FAu: goto L_8087FA;
    case 0x8087FCu: goto L_8087FC;
    case 0x8087FEu: goto L_8087FE;
    case 0x8087FFu: goto L_8087FF;
    case 0x808802u: goto L_808802;
    case 0x808804u: goto L_808804;
    case 0x808806u: goto L_808806;
    case 0x808808u: goto L_808808;
    case 0x80880Au: goto L_80880A;
    case 0x80880Cu: goto L_80880C;
    case 0x80880Eu: goto L_80880E;
    case 0x808810u: goto L_808810;
    case 0x808812u: goto L_808812;
    case 0x808813u: goto L_808813;
    case 0x808815u: goto L_808815;
    case 0x808817u: goto L_808817;
    case 0x808818u: goto L_808818;
    case 0x80881Au: goto L_80881A;
    case 0x80881Cu: goto L_80881C;
    case 0x80881Eu: goto L_80881E;
    case 0x808820u: goto L_808820;
    case 0x808822u: goto L_808822;
    case 0x808824u: goto L_808824;
    case 0x808826u: goto L_808826;
    case 0x808828u: goto L_808828;
    case 0x80882Au: goto L_80882A;
    case 0x80882Cu: goto L_80882C;
    case 0x80882Du: goto L_80882D;
    case 0x80882Eu: goto L_80882E;
    case 0x80882Fu: goto L_80882F;
    case 0x808830u: goto L_808830;
    case 0x808831u: goto L_808831;
    case 0x808834u: goto L_808834;
    case 0x808836u: goto L_808836;
    case 0x808838u: goto L_808838;
    case 0x80883Au: goto L_80883A;
    case 0x80883Du: goto L_80883D;
    case 0x808840u: goto L_808840;
    case 0x808841u: goto L_808841;
    case 0x808843u: goto L_808843;
    case 0x808846u: goto L_808846;
    case 0x808848u: goto L_808848;
    case 0x80884Au: goto L_80884A;
    case 0x80884Cu: goto L_80884C;
    case 0x80884Eu: goto L_80884E;
    case 0x808851u: goto L_808851;
    case 0x808853u: goto L_808853;
    case 0x808855u: goto L_808855;
    case 0x808858u: goto L_808858;
    case 0x808859u: goto L_808859;
    case 0x80885Au: goto L_80885A;
    case 0x80885Bu: goto L_80885B;
    case 0x80885Cu: goto L_80885C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808759:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8759u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8759u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8759u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808759 PHP
    cpu.push("PHP", hw);
    goto L_80875A;
L_80875A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x875Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x875Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x875Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80875A REP
    cpu.rep(0x20u);
    goto L_80875C;
L_80875C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x875Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x875Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x875Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80875C STZ
    hw.write(cpu.address("dp", 0x3u), 0, cpu.m8?8:16);
    goto L_80875E;
L_80875E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x875Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x875Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x875Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80875E STZ
    hw.write(cpu.address("dp", 0x4u), 0, cpu.m8?8:16);
    goto L_808760;
L_808760:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8760u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8760u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8760u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808760 PLP
    cpu.pop("PLP", hw);
    goto L_808761;
L_808761:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8761u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8761u,0x808761u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8761u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8761u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808761 PHP
    cpu.push("PHP", hw);
    goto L_808762;
L_808762:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8762u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8762u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8762u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808762 REP
    cpu.rep(0x20u);
    goto L_808764;
L_808764:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8764u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8764u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8764u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808764 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808766;
L_808766:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8766u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8766u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8766u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808766 CLC
    cpu.setFlag('C', false);
    goto L_808767;
L_808767:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8767u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8767u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8767u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808767 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16));
    goto L_808769;
L_808769:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8769u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8769u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8769u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808769 STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_80876B;
L_80876B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x876Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x876Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x876Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80876B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80876D;
L_80876D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x876Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x876Du,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x876Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80876D SEC
    cpu.setFlag('C', true);
    goto L_80876E;
L_80876E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x876Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x876Eu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x876Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x92u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80876E SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x92u), cpu.m8?8:16));
    goto L_808770;
L_808770:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8770u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8770u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8770u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808770 STA
    hw.write(cpu.address("dp", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_808772;
L_808772:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8772u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8772u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8772u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808772 PLP
    cpu.pop("PLP", hw);
    goto L_808773;
L_808773:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8773u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8773u,0x808773u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8773u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8773u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808773 PHP
    cpu.push("PHP", hw);
    goto L_808774;
L_808774:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8774u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8774u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8774u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808774 SEP
    cpu.sep(0x20u);
    goto L_808776;
L_808776:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8776u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8776u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8776u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808776 PHB
    cpu.push("PHB", hw);
    goto L_808777;
L_808777:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8777u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8777u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8777u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808777 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808779;
L_808779:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8779u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8779u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8779u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808779 PHA
    cpu.push("PHA", hw);
    goto L_80877A;
L_80877A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x877Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x877Au,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x877Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80877A PLB
    cpu.pop("PLB", hw);
    goto L_80877B;
L_80877B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x877Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x877Bu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x877Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80877B PHX
    cpu.push("PHX", hw);
    goto L_80877C;
L_80877C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x877Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x877Cu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x877Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80877C LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80877E;
L_80877E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x877Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x877Eu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x877Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80877E LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x96u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_808780;
L_808780:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8780u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8780u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8780u, 4u + 1u, 3u, cpu.address("absy", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808780 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808783;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8780u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8780u, 4u + 1u, 3u, cpu.address("absy", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808780 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808783;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8780u,0x808780u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_808783:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8783u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8783u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8783u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808783 BMI -> $8087AF
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_8087AF; }
    goto L_808785;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8783u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8783u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808783 BMI -> $8087AF
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_8087AF; }
    goto L_808785;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8783u,0x808783u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_808785:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8785u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8785u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8785u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808785 ASL
    cpu.aslA();
    goto L_808786;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8785u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8785u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808785 ASL
    cpu.aslA();
    goto L_808786;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8785u,0x808785u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_808786:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8786u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8786u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8786u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808786 STA
    hw.write(cpu.address("dp", 0x16u), cpu.a, cpu.m8?8:16);
    goto L_808788;
L_808788:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8788u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8788u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8788u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808788 BEQ -> $80878C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80878C; }
    goto L_80878A;
L_80878A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x878Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x878Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x878Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80878A LDA
    cpu.setA(0x8u, 8);
    goto L_80878C;
L_80878C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x878Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x878Cu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x878Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80878C EOR
    cpu.logicXor(0xF8u);
    goto L_80878E;
L_80878E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x878Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x878Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x878Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x17u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80878E STA
    hw.write(cpu.address("dp", 0x17u), cpu.a, cpu.m8?8:16);
    goto L_808790;
L_808790:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8790u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8790u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8790u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808790 CPX
    cpu.compareX(0x200u);
    goto L_808793;
L_808793:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8793u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8793u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8793u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808793 BCS -> $8087AF
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_8087AF; }
    goto L_808795;
L_808795:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8795u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8795u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8795u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808795 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16), false);
    goto L_808797;
L_808797:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8797u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8797u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8797u, 4u + 1u, 3u, cpu.address("absy", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808797 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80879A;
L_80879A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x879Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x879Au,cpu,0x50u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x879Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80879A BVC -> $8087A2
    if (!cpu.v) { hw.addCpuInternalCycles(1u); goto L_8087A2; }
    goto L_80879C;
L_80879C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x879Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x879Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x879Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x17u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80879C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x17u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80879E;
L_80879E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x879Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x879Eu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x879Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80879E SEC
    cpu.setFlag('C', true);
    goto L_80879F;
L_80879F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x879Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x879Fu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x879Fu, 4u + 1u, 3u, cpu.address("absy", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80879F SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x1u), cpu.m8?8:16));
    goto L_8087A2;
L_8087A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A2u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087A2 BMI -> $8087B5
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_8087B5; }
    goto L_8087A4;
L_8087A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A4u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087A4 CLC
    cpu.setFlag('C', false);
    goto L_8087A5;
L_8087A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A5u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087A5 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16));
    goto L_8087A7;
L_8087A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087A7 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_8087A9;
L_8087A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087A9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8087AB;
L_8087AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87ABu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87ABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087AB ADC
    cpu.adc(0x0u);
    goto L_8087AD;
L_8087AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87ADu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87ADu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087AD BRA -> $8087C5
    goto L_8087C5;
L_8087AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87AFu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87AFu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87AFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087AF STX
    hw.write(cpu.address("dp", 0x96u), cpu.x, cpu.x8?8:16);
    goto L_8087B1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87AFu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87AFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087AF STX
    hw.write(cpu.address("dp", 0x96u), cpu.x, cpu.x8?8:16);
    goto L_8087B1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x87AFu,0x8087AFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8087B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B1u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B1u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B1u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8087B1 PLX
    cpu.pop("PLX", hw);
    goto L_8087B2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B1u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B1u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8087B1 PLX
    cpu.pop("PLX", hw);
    goto L_8087B2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x87B1u,0x8087B1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8087B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B2u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B2u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B2u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8087B2 PLB
    cpu.pop("PLB", hw);
    goto L_8087B3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B2u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B2u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8087B2 PLB
    cpu.pop("PLB", hw);
    goto L_8087B3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x87B2u,0x8087B2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8087B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B3u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B3u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B3u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8087B3 PLP
    cpu.pop("PLP", hw);
    goto L_8087B4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B3u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B3u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8087B3 PLP
    cpu.pop("PLP", hw);
    goto L_8087B4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x87B3u,0x8087B3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8087B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B4u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x87B4u,0x8087B4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B4u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8087B4 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8087B4u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8087B4u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_8087B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B5u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087B5 EOR
    cpu.logicXor(0xFFu);
    goto L_8087B7;
L_8087B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B7u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087B7 INC
    cpu.inc('A');
    goto L_8087B8;
L_8087B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087B8 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_8087BA;
L_8087BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87BAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87BAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087BA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8087BC;
L_8087BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87BCu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87BCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087BC SEC
    cpu.setFlag('C', true);
    goto L_8087BD;
L_8087BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87BDu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87BDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087BD SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_8087BF;
L_8087BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87BFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87BFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087BF STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_8087C1;
L_8087C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087C1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8087C3;
L_8087C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C3u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087C3 SBC
    cpu.sbc(0x0u);
    goto L_8087C5;
L_8087C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087C5 BEQ -> $8087CD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8087CD; }
    goto L_8087C7;
L_8087C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C7u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087C7 CMP
    cpu.compareA(0xFFu);
    goto L_8087C9;
L_8087C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087C9 BNE -> $80882C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80882C; }
    goto L_8087CB;
L_8087CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87CBu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87CBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087CB INC
    cpu.incMem(hw, cpu.address("dp", 0x16u), cpu.m8?8:16);
    goto L_8087CD;
L_8087CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87CDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87CDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087CD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8087CF;
L_8087CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87CFu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87CFu, 5u, 3u, cpu.address("absx", 0x1400u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087CF STA
    hw.write(cpu.address("absx", 0x1400u), cpu.a, cpu.m8?8:16);
    goto L_8087D2;
L_8087D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D2u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D2u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8087D2 PHX
    cpu.push("PHX", hw);
    goto L_8087D3;
L_8087D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D3u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D3u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8087D3 PHY
    cpu.push("PHY", hw);
    goto L_8087D4;
L_8087D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D4u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087D4 REP
    cpu.rep(0x20u);
    goto L_8087D6;
L_8087D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D6u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087D6 TXA
    cpu.transfer("TXA");
    goto L_8087D7;
L_8087D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D7u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087D7 LSR
    cpu.lsrA();
    goto L_8087D8;
L_8087D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D8u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087D8 LSR
    cpu.lsrA();
    goto L_8087D9;
L_8087D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D9u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087D9 LSR
    cpu.lsrA();
    goto L_8087DA;
L_8087DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DAu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087DA LSR
    cpu.lsrA();
    goto L_8087DB;
L_8087DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DBu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087DB TAY
    cpu.transfer("TAY");
    goto L_8087DC;
L_8087DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DCu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087DC TXA
    cpu.transfer("TXA");
    goto L_8087DD;
L_8087DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DDu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087DD ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16));
    goto L_8087DF;
L_8087DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DFu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087DF AND
    cpu.logicAnd(0xFu);
    goto L_8087E2;
L_8087E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E2u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087E2 TAX
    cpu.transfer("TAX");
    goto L_8087E3;
L_8087E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E3u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087E3 SEP
    cpu.sep(0x20u);
    goto L_8087E5;
L_8087E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E5u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E5u, 4u + 1u, 3u, cpu.address("absy", 0x1600u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087E5 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1600u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8087E8;
L_8087E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E8u,cpu,0x3Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E8u, 5u, 4u, ((0x80886Eu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087E8 AND
    cpu.logicAnd(hw.readW(((0x80886Eu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_8087EC;
L_8087EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87ECu,cpu,0x1Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87ECu, 5u, 4u, ((0x80885Eu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087EC ORA
    cpu.logicOr(hw.readW(((0x80885Eu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_8087F0;
L_8087F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87F0u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87F0u, 5u, 3u, cpu.address("absy", 0x1600u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087F0 STA
    hw.write(cpu.address("absy", 0x1600u), cpu.a, cpu.m8?8:16);
    goto L_8087F3;
L_8087F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87F3u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87F3u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8087F3 PLY
    cpu.pop("PLY", hw);
    goto L_8087F4;
L_8087F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87F4u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87F4u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8087F4 PLX
    cpu.pop("PLX", hw);
    goto L_8087F5;
L_8087F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87F5u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87F5u, 4u + 1u, 3u, cpu.address("absy", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087F5 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8087F8;
L_8087F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87F8u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87F8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087F8 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16), false);
    goto L_8087FA;
L_8087FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87FAu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87FAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087FA BPL -> $808802
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808802; }
    goto L_8087FC;
L_8087FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87FCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87FCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x17u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087FC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x17u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8087FE;
L_8087FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87FEu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87FEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087FE SEC
    cpu.setFlag('C', true);
    goto L_8087FF;
L_8087FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87FFu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87FFu, 4u + 1u, 3u, cpu.address("absy", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087FF SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16));
    goto L_808802;
L_808802:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8802u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8802u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8802u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808802 CMP
    cpu.compareA(0x80u);
    goto L_808804;
L_808804:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8804u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8804u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8804u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808804 BCS -> $808810
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_808810; }
    goto L_808806;
L_808806:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8806u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8806u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8806u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808806 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16));
    goto L_808808;
L_808808:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8808u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8808u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8808u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808808 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80880A;
L_80880A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x880Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x880Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x880Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80880A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80880C;
L_80880C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x880Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x880Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x880Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80880C ADC
    cpu.adc(0x0u);
    goto L_80880E;
L_80880E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x880Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x880Eu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x880Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80880E BRA -> $808820
    goto L_808820;
L_808810:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8810u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8810u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8810u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808810 EOR
    cpu.logicXor(0xFFu);
    goto L_808812;
L_808812:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8812u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8812u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8812u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808812 INC
    cpu.inc('A');
    goto L_808813;
L_808813:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8813u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8813u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8813u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808813 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_808815;
L_808815:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8815u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8815u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8815u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808815 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808817;
L_808817:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8817u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8817u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8817u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808817 SEC
    cpu.setFlag('C', true);
    goto L_808818;
L_808818:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8818u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8818u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8818u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808818 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_80881A;
L_80881A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x881Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x881Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x881Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80881A STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80881C;
L_80881C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x881Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x881Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x881Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80881C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80881E;
L_80881E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x881Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x881Eu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x881Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80881E SBC
    cpu.sbc(0x0u);
    goto L_808820;
L_808820:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8820u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8820u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8820u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808820 BEQ -> $808834
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_808834; }
    goto L_808822;
L_808822:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8822u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8822u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8822u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808822 CMP
    cpu.compareA(0xFFu);
    goto L_808824;
L_808824:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8824u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8824u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8824u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808824 BNE -> $80882C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80882C; }
    goto L_808826;
L_808826:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8826u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8826u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8826u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808826 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808828;
L_808828:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8828u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8828u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8828u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808828 CMP
    cpu.compareA(0xE0u);
    goto L_80882A;
L_80882A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x882Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x882Au,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x882Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80882A BCS -> $80883A
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80883A; }
    goto L_80882C;
L_80882C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x882Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x882Cu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x882Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80882C INY
    cpu.inc('Y');
    goto L_80882D;
L_80882D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x882Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x882Du,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x882Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80882D INY
    cpu.inc('Y');
    goto L_80882E;
L_80882E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x882Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x882Eu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x882Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80882E INY
    cpu.inc('Y');
    goto L_80882F;
L_80882F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x882Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x882Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x882Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80882F INY
    cpu.inc('Y');
    goto L_808830;
L_808830:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8830u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8830u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8830u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808830 INY
    cpu.inc('Y');
    goto L_808831;
L_808831:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8831u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8831u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8831u, 3u, 3u, cpu.address("abs", 0x8780u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808831 JMP -> $808780
    goto L_808780;
L_808834:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8834u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8834u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8834u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808834 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808836;
L_808836:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8836u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8836u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8836u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808836 CMP
    cpu.compareA(0xE0u);
    goto L_808838;
L_808838:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8838u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8838u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8838u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808838 BCS -> $80882C
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80882C; }
    goto L_80883A;
L_80883A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x883Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x883Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x883Au, 5u, 3u, cpu.address("absx", 0x1401u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80883A STA
    hw.write(cpu.address("absx", 0x1401u), cpu.a, cpu.m8?8:16);
    goto L_80883D;
L_80883D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x883Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x883Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x883Du, 4u + 1u, 3u, cpu.address("absy", 0x0003u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80883D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808840;
L_808840:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8840u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8840u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8840u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808840 CLC
    cpu.setFlag('C', false);
    goto L_808841;
L_808841:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8841u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8841u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8841u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808841 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_808843;
L_808843:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8843u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8843u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8843u, 5u, 3u, cpu.address("absx", 0x1402u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808843 STA
    hw.write(cpu.address("absx", 0x1402u), cpu.a, cpu.m8?8:16);
    goto L_808846;
L_808846:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8846u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8846u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8846u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808846 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808848;
L_808848:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8848u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8848u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8848u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808848 BCC -> $80884C
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80884C; }
    goto L_80884A;
L_80884A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x884Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x884Au,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x884Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80884A ORA
    cpu.logicOr(0x1u);
    goto L_80884C;
L_80884C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x884Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x884Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x884Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80884C STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_80884E;
L_80884E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x884Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x884Eu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x884Eu, 4u + 1u, 3u, cpu.address("absy", 0x0004u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80884E LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808851;
L_808851:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8851u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8851u,cpu,0x45u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8851u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808851 EOR
    cpu.logicXor(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16));
    goto L_808853;
L_808853:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8853u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8853u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8853u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808853 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x6u), cpu.m8?8:16));
    goto L_808855;
L_808855:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8855u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8855u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8855u, 5u, 3u, cpu.address("absx", 0x1403u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808855 STA
    hw.write(cpu.address("absx", 0x1403u), cpu.a, cpu.m8?8:16);
    goto L_808858;
L_808858:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8858u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8858u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8858u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808858 INX
    cpu.inc('X');
    goto L_808859;
L_808859:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8859u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8859u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8859u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808859 INX
    cpu.inc('X');
    goto L_80885A;
L_80885A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x885Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Au,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80885A INX
    cpu.inc('X');
    goto L_80885B;
L_80885B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x885Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Bu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80885B INX
    cpu.inc('X');
    goto L_80885C;
L_80885C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x885Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Cu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80885C BRA -> $80882C
    goto L_80882C;
}

void sub_808759_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808759u: goto L_808759;
    case 0x80875Au: goto L_80875A;
    case 0x80875Cu: goto L_80875C;
    case 0x80875Eu: goto L_80875E;
    case 0x808760u: goto L_808760;
    case 0x808761u: goto L_808761;
    case 0x808762u: goto L_808762;
    case 0x808764u: goto L_808764;
    case 0x808766u: goto L_808766;
    case 0x808767u: goto L_808767;
    case 0x808769u: goto L_808769;
    case 0x80876Bu: goto L_80876B;
    case 0x80876Du: goto L_80876D;
    case 0x80876Eu: goto L_80876E;
    case 0x808770u: goto L_808770;
    case 0x808772u: goto L_808772;
    case 0x808773u: goto L_808773;
    case 0x808774u: goto L_808774;
    case 0x808776u: goto L_808776;
    case 0x808777u: goto L_808777;
    case 0x808779u: goto L_808779;
    case 0x80877Au: goto L_80877A;
    case 0x80877Bu: goto L_80877B;
    case 0x80877Cu: goto L_80877C;
    case 0x80877Eu: goto L_80877E;
    case 0x808780u: goto L_808780;
    case 0x808783u: goto L_808783;
    case 0x808785u: goto L_808785;
    case 0x808786u: goto L_808786;
    case 0x808788u: goto L_808788;
    case 0x80878Au: goto L_80878A;
    case 0x80878Cu: goto L_80878C;
    case 0x80878Eu: goto L_80878E;
    case 0x808790u: goto L_808790;
    case 0x808793u: goto L_808793;
    case 0x808795u: goto L_808795;
    case 0x808797u: goto L_808797;
    case 0x80879Au: goto L_80879A;
    case 0x80879Cu: goto L_80879C;
    case 0x80879Eu: goto L_80879E;
    case 0x80879Fu: goto L_80879F;
    case 0x8087A2u: goto L_8087A2;
    case 0x8087A4u: goto L_8087A4;
    case 0x8087A5u: goto L_8087A5;
    case 0x8087A7u: goto L_8087A7;
    case 0x8087A9u: goto L_8087A9;
    case 0x8087ABu: goto L_8087AB;
    case 0x8087ADu: goto L_8087AD;
    case 0x8087AFu: goto L_8087AF;
    case 0x8087B1u: goto L_8087B1;
    case 0x8087B2u: goto L_8087B2;
    case 0x8087B3u: goto L_8087B3;
    case 0x8087B4u: goto L_8087B4;
    case 0x8087B5u: goto L_8087B5;
    case 0x8087B7u: goto L_8087B7;
    case 0x8087B8u: goto L_8087B8;
    case 0x8087BAu: goto L_8087BA;
    case 0x8087BCu: goto L_8087BC;
    case 0x8087BDu: goto L_8087BD;
    case 0x8087BFu: goto L_8087BF;
    case 0x8087C1u: goto L_8087C1;
    case 0x8087C3u: goto L_8087C3;
    case 0x8087C5u: goto L_8087C5;
    case 0x8087C7u: goto L_8087C7;
    case 0x8087C9u: goto L_8087C9;
    case 0x8087CBu: goto L_8087CB;
    case 0x8087CDu: goto L_8087CD;
    case 0x8087CFu: goto L_8087CF;
    case 0x8087D2u: goto L_8087D2;
    case 0x8087D3u: goto L_8087D3;
    case 0x8087D4u: goto L_8087D4;
    case 0x8087D6u: goto L_8087D6;
    case 0x8087D7u: goto L_8087D7;
    case 0x8087D8u: goto L_8087D8;
    case 0x8087D9u: goto L_8087D9;
    case 0x8087DAu: goto L_8087DA;
    case 0x8087DBu: goto L_8087DB;
    case 0x8087DCu: goto L_8087DC;
    case 0x8087DDu: goto L_8087DD;
    case 0x8087DFu: goto L_8087DF;
    case 0x8087E2u: goto L_8087E2;
    case 0x8087E3u: goto L_8087E3;
    case 0x8087E5u: goto L_8087E5;
    case 0x8087E8u: goto L_8087E8;
    case 0x8087ECu: goto L_8087EC;
    case 0x8087F0u: goto L_8087F0;
    case 0x8087F3u: goto L_8087F3;
    case 0x8087F4u: goto L_8087F4;
    case 0x8087F5u: goto L_8087F5;
    case 0x8087F8u: goto L_8087F8;
    case 0x8087FAu: goto L_8087FA;
    case 0x8087FCu: goto L_8087FC;
    case 0x8087FEu: goto L_8087FE;
    case 0x8087FFu: goto L_8087FF;
    case 0x808802u: goto L_808802;
    case 0x808804u: goto L_808804;
    case 0x808806u: goto L_808806;
    case 0x808808u: goto L_808808;
    case 0x80880Au: goto L_80880A;
    case 0x80880Cu: goto L_80880C;
    case 0x80880Eu: goto L_80880E;
    case 0x808810u: goto L_808810;
    case 0x808812u: goto L_808812;
    case 0x808813u: goto L_808813;
    case 0x808815u: goto L_808815;
    case 0x808817u: goto L_808817;
    case 0x808818u: goto L_808818;
    case 0x80881Au: goto L_80881A;
    case 0x80881Cu: goto L_80881C;
    case 0x80881Eu: goto L_80881E;
    case 0x808820u: goto L_808820;
    case 0x808822u: goto L_808822;
    case 0x808824u: goto L_808824;
    case 0x808826u: goto L_808826;
    case 0x808828u: goto L_808828;
    case 0x80882Au: goto L_80882A;
    case 0x80882Cu: goto L_80882C;
    case 0x80882Du: goto L_80882D;
    case 0x80882Eu: goto L_80882E;
    case 0x80882Fu: goto L_80882F;
    case 0x808830u: goto L_808830;
    case 0x808831u: goto L_808831;
    case 0x808834u: goto L_808834;
    case 0x808836u: goto L_808836;
    case 0x808838u: goto L_808838;
    case 0x80883Au: goto L_80883A;
    case 0x80883Du: goto L_80883D;
    case 0x808840u: goto L_808840;
    case 0x808841u: goto L_808841;
    case 0x808843u: goto L_808843;
    case 0x808846u: goto L_808846;
    case 0x808848u: goto L_808848;
    case 0x80884Au: goto L_80884A;
    case 0x80884Cu: goto L_80884C;
    case 0x80884Eu: goto L_80884E;
    case 0x808851u: goto L_808851;
    case 0x808853u: goto L_808853;
    case 0x808855u: goto L_808855;
    case 0x808858u: goto L_808858;
    case 0x808859u: goto L_808859;
    case 0x80885Au: goto L_80885A;
    case 0x80885Bu: goto L_80885B;
    case 0x80885Cu: goto L_80885C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808759:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8759u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8759u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8759u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808759 PHP
    cpu.push("PHP", hw);
    goto L_80875A;
L_80875A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x875Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x875Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x875Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80875A REP
    cpu.rep(0x20u);
    goto L_80875C;
L_80875C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x875Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x875Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x875Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80875C STZ
    hw.write(cpu.address("dp", 0x3u), 0, cpu.m8?8:16);
    goto L_80875E;
L_80875E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x875Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x875Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x875Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80875E STZ
    hw.write(cpu.address("dp", 0x4u), 0, cpu.m8?8:16);
    goto L_808760;
L_808760:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8760u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8760u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8760u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808760 PLP
    cpu.pop("PLP", hw);
    goto L_808761;
L_808761:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8761u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8761u,0x808761u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8761u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8761u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808761 PHP
    cpu.push("PHP", hw);
    goto L_808762;
L_808762:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8762u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8762u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8762u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808762 REP
    cpu.rep(0x20u);
    goto L_808764;
L_808764:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8764u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8764u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8764u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808764 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808766;
L_808766:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8766u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8766u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8766u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808766 CLC
    cpu.setFlag('C', false);
    goto L_808767;
L_808767:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8767u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8767u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8767u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808767 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x94u), cpu.m8?8:16));
    goto L_808769;
L_808769:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8769u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8769u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8769u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808769 STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_80876B;
L_80876B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x876Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x876Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x876Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80876B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80876D;
L_80876D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x876Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x876Du,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x876Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80876D SEC
    cpu.setFlag('C', true);
    goto L_80876E;
L_80876E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x876Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x876Eu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x876Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x92u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80876E SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x92u), cpu.m8?8:16));
    goto L_808770;
L_808770:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8770u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8770u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8770u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808770 STA
    hw.write(cpu.address("dp", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_808772;
L_808772:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8772u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8772u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8772u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808772 PLP
    cpu.pop("PLP", hw);
    goto L_808773;
L_808773:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8773u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8773u,0x808773u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8773u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8773u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808773 PHP
    cpu.push("PHP", hw);
    goto L_808774;
L_808774:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8774u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8774u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8774u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808774 SEP
    cpu.sep(0x20u);
    goto L_808776;
L_808776:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8776u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8776u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8776u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808776 PHB
    cpu.push("PHB", hw);
    goto L_808777;
L_808777:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8777u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8777u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8777u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808777 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808779;
L_808779:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8779u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8779u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8779u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808779 PHA
    cpu.push("PHA", hw);
    goto L_80877A;
L_80877A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x877Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x877Au,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x877Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80877A PLB
    cpu.pop("PLB", hw);
    goto L_80877B;
L_80877B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x877Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x877Bu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x877Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80877B PHX
    cpu.push("PHX", hw);
    goto L_80877C;
L_80877C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x877Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x877Cu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x877Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80877C LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80877E;
L_80877E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x877Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x877Eu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x877Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80877E LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x96u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_808780;
L_808780:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8780u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8780u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8780u, 4u + 1u, 3u, cpu.address("absy", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808780 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808783;
L_808783:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8783u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8783u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8783u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808783 BMI -> $8087AF
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_8087AF; }
    goto L_808785;
L_808785:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8785u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8785u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8785u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808785 ASL
    cpu.aslA();
    goto L_808786;
L_808786:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8786u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8786u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8786u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808786 STA
    hw.write(cpu.address("dp", 0x16u), cpu.a, cpu.m8?8:16);
    goto L_808788;
L_808788:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8788u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8788u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8788u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808788 BEQ -> $80878C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80878C; }
    goto L_80878A;
L_80878A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x878Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x878Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x878Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80878A LDA
    cpu.setA(0x8u, 8);
    goto L_80878C;
L_80878C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x878Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x878Cu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x878Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80878C EOR
    cpu.logicXor(0xF8u);
    goto L_80878E;
L_80878E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x878Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x878Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x878Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x17u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80878E STA
    hw.write(cpu.address("dp", 0x17u), cpu.a, cpu.m8?8:16);
    goto L_808790;
L_808790:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8790u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8790u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8790u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808790 CPX
    cpu.compareX(0x200u);
    goto L_808793;
L_808793:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8793u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8793u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8793u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808793 BCS -> $8087AF
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_8087AF; }
    goto L_808795;
L_808795:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8795u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8795u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8795u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808795 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16), false);
    goto L_808797;
L_808797:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8797u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8797u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8797u, 4u + 1u, 3u, cpu.address("absy", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808797 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80879A;
L_80879A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x879Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x879Au,cpu,0x50u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x879Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80879A BVC -> $8087A2
    if (!cpu.v) { hw.addCpuInternalCycles(1u); goto L_8087A2; }
    goto L_80879C;
L_80879C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x879Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x879Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x879Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x17u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80879C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x17u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80879E;
L_80879E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x879Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x879Eu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x879Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80879E SEC
    cpu.setFlag('C', true);
    goto L_80879F;
L_80879F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x879Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x879Fu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x879Fu, 4u + 1u, 3u, cpu.address("absy", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80879F SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x1u), cpu.m8?8:16));
    goto L_8087A2;
L_8087A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A2u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087A2 BMI -> $8087B5
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_8087B5; }
    goto L_8087A4;
L_8087A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A4u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087A4 CLC
    cpu.setFlag('C', false);
    goto L_8087A5;
L_8087A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A5u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087A5 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16));
    goto L_8087A7;
L_8087A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087A7 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_8087A9;
L_8087A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87A9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87A9u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087A9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8087AB;
L_8087AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87ABu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87ABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087AB ADC
    cpu.adc(0x0u);
    goto L_8087AD;
L_8087AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87ADu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87ADu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087AD BRA -> $8087C5
    goto L_8087C5;
L_8087AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87AFu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87AFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087AF STX
    hw.write(cpu.address("dp", 0x96u), cpu.x, cpu.x8?8:16);
    goto L_8087B1;
L_8087B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B1u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B1u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8087B1 PLX
    cpu.pop("PLX", hw);
    goto L_8087B2;
L_8087B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B2u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B2u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8087B2 PLB
    cpu.pop("PLB", hw);
    goto L_8087B3;
L_8087B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B3u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B3u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8087B3 PLP
    cpu.pop("PLP", hw);
    goto L_8087B4;
L_8087B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B4u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x87B4u,0x8087B4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B4u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8087B4 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8087B4u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8087B4u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_8087B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B5u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087B5 EOR
    cpu.logicXor(0xFFu);
    goto L_8087B7;
L_8087B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B7u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087B7 INC
    cpu.inc('A');
    goto L_8087B8;
L_8087B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87B8u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87B8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087B8 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_8087BA;
L_8087BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87BAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87BAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087BA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8087BC;
L_8087BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87BCu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87BCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087BC SEC
    cpu.setFlag('C', true);
    goto L_8087BD;
L_8087BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87BDu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87BDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087BD SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_8087BF;
L_8087BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87BFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87BFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087BF STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_8087C1;
L_8087C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087C1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8087C3;
L_8087C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C3u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087C3 SBC
    cpu.sbc(0x0u);
    goto L_8087C5;
L_8087C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087C5 BEQ -> $8087CD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8087CD; }
    goto L_8087C7;
L_8087C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C7u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087C7 CMP
    cpu.compareA(0xFFu);
    goto L_8087C9;
L_8087C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87C9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87C9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087C9 BNE -> $80882C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80882C; }
    goto L_8087CB;
L_8087CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87CBu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87CBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087CB INC
    cpu.incMem(hw, cpu.address("dp", 0x16u), cpu.m8?8:16);
    goto L_8087CD;
L_8087CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87CDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87CDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087CD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8087CF;
L_8087CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87CFu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87CFu, 5u, 3u, cpu.address("absx", 0x1400u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087CF STA
    hw.write(cpu.address("absx", 0x1400u), cpu.a, cpu.m8?8:16);
    goto L_8087D2;
L_8087D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D2u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D2u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8087D2 PHX
    cpu.push("PHX", hw);
    goto L_8087D3;
L_8087D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D3u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D3u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8087D3 PHY
    cpu.push("PHY", hw);
    goto L_8087D4;
L_8087D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D4u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087D4 REP
    cpu.rep(0x20u);
    goto L_8087D6;
L_8087D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D6u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087D6 TXA
    cpu.transfer("TXA");
    goto L_8087D7;
L_8087D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D7u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087D7 LSR
    cpu.lsrA();
    goto L_8087D8;
L_8087D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D8u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087D8 LSR
    cpu.lsrA();
    goto L_8087D9;
L_8087D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87D9u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87D9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087D9 LSR
    cpu.lsrA();
    goto L_8087DA;
L_8087DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DAu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087DA LSR
    cpu.lsrA();
    goto L_8087DB;
L_8087DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DBu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087DB TAY
    cpu.transfer("TAY");
    goto L_8087DC;
L_8087DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DCu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087DC TXA
    cpu.transfer("TXA");
    goto L_8087DD;
L_8087DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DDu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087DD ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16));
    goto L_8087DF;
L_8087DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87DFu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87DFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087DF AND
    cpu.logicAnd(0xFu);
    goto L_8087E2;
L_8087E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E2u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087E2 TAX
    cpu.transfer("TAX");
    goto L_8087E3;
L_8087E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E3u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087E3 SEP
    cpu.sep(0x20u);
    goto L_8087E5;
L_8087E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E5u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E5u, 4u + 1u, 3u, cpu.address("absy", 0x1600u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087E5 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1600u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8087E8;
L_8087E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87E8u,cpu,0x3Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87E8u, 5u, 4u, ((0x80886Eu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087E8 AND
    cpu.logicAnd(hw.readW(((0x80886Eu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_8087EC;
L_8087EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87ECu,cpu,0x1Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87ECu, 5u, 4u, ((0x80885Eu + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087EC ORA
    cpu.logicOr(hw.readW(((0x80885Eu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_8087F0;
L_8087F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87F0u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87F0u, 5u, 3u, cpu.address("absy", 0x1600u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087F0 STA
    hw.write(cpu.address("absy", 0x1600u), cpu.a, cpu.m8?8:16);
    goto L_8087F3;
L_8087F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87F3u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87F3u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8087F3 PLY
    cpu.pop("PLY", hw);
    goto L_8087F4;
L_8087F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87F4u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87F4u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8087F4 PLX
    cpu.pop("PLX", hw);
    goto L_8087F5;
L_8087F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87F5u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87F5u, 4u + 1u, 3u, cpu.address("absy", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087F5 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8087F8;
L_8087F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87F8u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87F8u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087F8 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16), false);
    goto L_8087FA;
L_8087FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87FAu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87FAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087FA BPL -> $808802
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808802; }
    goto L_8087FC;
L_8087FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87FCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87FCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x17u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087FC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x17u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8087FE;
L_8087FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87FEu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87FEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087FE SEC
    cpu.setFlag('C', true);
    goto L_8087FF;
L_8087FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x87FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x87FFu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x87FFu, 4u + 1u, 3u, cpu.address("absy", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8087FF SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16));
    goto L_808802;
L_808802:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8802u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8802u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8802u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808802 CMP
    cpu.compareA(0x80u);
    goto L_808804;
L_808804:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8804u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8804u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8804u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808804 BCS -> $808810
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_808810; }
    goto L_808806;
L_808806:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8806u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8806u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8806u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808806 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16));
    goto L_808808;
L_808808:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8808u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8808u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8808u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808808 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80880A;
L_80880A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x880Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x880Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x880Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80880A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80880C;
L_80880C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x880Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x880Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x880Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80880C ADC
    cpu.adc(0x0u);
    goto L_80880E;
L_80880E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x880Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x880Eu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x880Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80880E BRA -> $808820
    goto L_808820;
L_808810:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8810u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8810u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8810u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808810 EOR
    cpu.logicXor(0xFFu);
    goto L_808812;
L_808812:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8812u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8812u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8812u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808812 INC
    cpu.inc('A');
    goto L_808813;
L_808813:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8813u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8813u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8813u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808813 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_808815;
L_808815:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8815u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8815u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8815u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808815 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808817;
L_808817:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8817u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8817u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8817u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808817 SEC
    cpu.setFlag('C', true);
    goto L_808818;
L_808818:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8818u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8818u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8818u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808818 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_80881A;
L_80881A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x881Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x881Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x881Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80881A STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80881C;
L_80881C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x881Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x881Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x881Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80881C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80881E;
L_80881E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x881Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x881Eu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x881Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80881E SBC
    cpu.sbc(0x0u);
    goto L_808820;
L_808820:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8820u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8820u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8820u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808820 BEQ -> $808834
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_808834; }
    goto L_808822;
L_808822:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8822u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8822u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8822u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808822 CMP
    cpu.compareA(0xFFu);
    goto L_808824;
L_808824:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8824u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8824u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8824u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808824 BNE -> $80882C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80882C; }
    goto L_808826;
L_808826:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8826u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8826u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8826u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808826 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808828;
L_808828:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8828u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8828u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8828u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808828 CMP
    cpu.compareA(0xE0u);
    goto L_80882A;
L_80882A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x882Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x882Au,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x882Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80882A BCS -> $80883A
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80883A; }
    goto L_80882C;
L_80882C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x882Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x882Cu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x882Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80882C INY
    cpu.inc('Y');
    goto L_80882D;
L_80882D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x882Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x882Du,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x882Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80882D INY
    cpu.inc('Y');
    goto L_80882E;
L_80882E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x882Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x882Eu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x882Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80882E INY
    cpu.inc('Y');
    goto L_80882F;
L_80882F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x882Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x882Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x882Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80882F INY
    cpu.inc('Y');
    goto L_808830;
L_808830:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8830u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8830u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8830u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808830 INY
    cpu.inc('Y');
    goto L_808831;
L_808831:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8831u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8831u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8831u, 3u, 3u, cpu.address("abs", 0x8780u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808831 JMP -> $808780
    goto L_808780;
L_808834:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8834u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8834u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8834u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808834 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808836;
L_808836:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8836u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8836u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8836u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808836 CMP
    cpu.compareA(0xE0u);
    goto L_808838;
L_808838:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8838u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8838u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8838u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808838 BCS -> $80882C
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80882C; }
    goto L_80883A;
L_80883A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x883Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x883Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x883Au, 5u, 3u, cpu.address("absx", 0x1401u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80883A STA
    hw.write(cpu.address("absx", 0x1401u), cpu.a, cpu.m8?8:16);
    goto L_80883D;
L_80883D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x883Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x883Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x883Du, 4u + 1u, 3u, cpu.address("absy", 0x0003u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80883D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808840;
L_808840:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8840u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8840u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8840u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808840 CLC
    cpu.setFlag('C', false);
    goto L_808841;
L_808841:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8841u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8841u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8841u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808841 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16));
    goto L_808843;
L_808843:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8843u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8843u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8843u, 5u, 3u, cpu.address("absx", 0x1402u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808843 STA
    hw.write(cpu.address("absx", 0x1402u), cpu.a, cpu.m8?8:16);
    goto L_808846;
L_808846:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8846u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8846u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8846u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808846 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808848;
L_808848:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8848u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8848u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8848u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808848 BCC -> $80884C
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80884C; }
    goto L_80884A;
L_80884A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x884Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x884Au,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x884Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80884A ORA
    cpu.logicOr(0x1u);
    goto L_80884C;
L_80884C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x884Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x884Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x884Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80884C STA
    hw.write(cpu.address("dp", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_80884E;
L_80884E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x884Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x884Eu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x884Eu, 4u + 1u, 3u, cpu.address("absy", 0x0004u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80884E LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808851;
L_808851:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8851u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8851u,cpu,0x45u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8851u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808851 EOR
    cpu.logicXor(hw.readW(cpu.address("dp", 0x3u), cpu.m8?8:16));
    goto L_808853;
L_808853:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8853u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8853u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8853u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808853 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x6u), cpu.m8?8:16));
    goto L_808855;
L_808855:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8855u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8855u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8855u, 5u, 3u, cpu.address("absx", 0x1403u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808855 STA
    hw.write(cpu.address("absx", 0x1403u), cpu.a, cpu.m8?8:16);
    goto L_808858;
L_808858:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8858u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8858u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8858u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808858 INX
    cpu.inc('X');
    goto L_808859;
L_808859:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8859u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8859u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8859u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808859 INX
    cpu.inc('X');
    goto L_80885A;
L_80885A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x885Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Au,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80885A INX
    cpu.inc('X');
    goto L_80885B;
L_80885B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x885Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Bu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80885B INX
    cpu.inc('X');
    goto L_80885C;
L_80885C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x885Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x885Cu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x885Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80885C BRA -> $80882C
    goto L_80882C;
}

void sub_808ADE_E0M0X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808ADEu: goto L_808ADE;
    case 0x808AE0u: goto L_808AE0;
    case 0x808AE2u: goto L_808AE2;
    case 0x808AE5u: goto L_808AE5;
    case 0x808AE7u: goto L_808AE7;
    case 0x808AE8u: goto L_808AE8;
    case 0x808AE9u: goto L_808AE9;
    case 0x808AEAu: goto L_808AEA;
    case 0x808AEBu: goto L_808AEB;
    case 0x808AEDu: goto L_808AED;
    case 0x808AEFu: goto L_808AEF;
    case 0x808AF1u: goto L_808AF1;
    case 0x808AF3u: goto L_808AF3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808ADE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ADEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ADEu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ADEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808ADE LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x96u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_808AE0;
L_808AE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE0u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AE0 BRA -> $808AEB
    goto L_808AEB;
L_808AE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AE2 LDA
    cpu.setA(0x9DE0u, 16);
    goto L_808AE5;
L_808AE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE5u,cpu,0x01u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE5u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x14u + cpu.x) & 0xFFFFu), 2u, 0u);
    // $808AE5 ORA
    cpu.logicOr(hw.readW(cpu.addressDpIndirectX(hw, 0x14u), cpu.m8?8:16));
    goto L_808AE7;
L_808AE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE7u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AE7 INX
    cpu.inc('X');
    goto L_808AE8;
L_808AE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE8u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AE8 INX
    cpu.inc('X');
    goto L_808AE9;
L_808AE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE9u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AE9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AE9 INX
    cpu.inc('X');
    goto L_808AEA;
L_808AEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AEAu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AEAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AEA INX
    cpu.inc('X');
    goto L_808AEB;
L_808AEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AEBu,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AEBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AEB CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0x98u), cpu.x8?8:16));
    goto L_808AED;
L_808AED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AEDu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AEDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AED BCC -> $808AE2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_808AE2; }
    goto L_808AEF;
L_808AEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AEFu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AEFu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AEF LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x96u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_808AF1;
L_808AF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF1u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AF1 STX
    hw.write(cpu.address("dp", 0x98u), cpu.x, cpu.x8?8:16);
    goto L_808AF3;
L_808AF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF3u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AF3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808AF3 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808AF3u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808AF3u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808B92_E0M0X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808B92u: goto L_808B92;
    case 0x808B94u: goto L_808B94;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808B92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B92u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B92u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808B92 LDX
    cpu.setX(0x0u, 8);
    goto L_808B94;
L_808B94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B94u,cpu,0x00u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B94u, 8u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $808B94 BRK
    hw.partial(0x808B94u, "BRK"); return;
}

void sub_808EE1_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808ECAu: goto L_808ECA;
    case 0x808ECDu: goto L_808ECD;
    case 0x808ED0u: goto L_808ED0;
    case 0x808ED3u: goto L_808ED3;
    case 0x808ED4u: goto L_808ED4;
    case 0x808ED7u: goto L_808ED7;
    case 0x808ED8u: goto L_808ED8;
    case 0x808EDBu: goto L_808EDB;
    case 0x808EDCu: goto L_808EDC;
    case 0x808EDFu: goto L_808EDF;
    case 0x808EE0u: goto L_808EE0;
    case 0x808EE1u: goto L_808EE1;
    case 0x808EE2u: goto L_808EE2;
    case 0x808EE4u: goto L_808EE4;
    case 0x808EE5u: goto L_808EE5;
    case 0x808EE6u: goto L_808EE6;
    case 0x808EE7u: goto L_808EE7;
    case 0x808EEBu: goto L_808EEB;
    case 0x808EEEu: goto L_808EEE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808ECA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ECAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECAu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECAu, 6u, 3u, cpu.address("absx", 0x1805u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808ECA STA
    hw.write(cpu.address("absx", 0x1805u), cpu.a, cpu.m8?8:16);
    goto L_808ECD;
L_808ECD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ECDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ECDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808ECD LDA
    cpu.setA(0x80u, 16);
    goto L_808ED0;
L_808ED0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED0u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED0u, 6u, 3u, cpu.address("absx", 0x1800u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808ED0 STA
    hw.write(cpu.address("absx", 0x1800u), cpu.a, cpu.m8?8:16);
    goto L_808ED3;
L_808ED3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED3u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED3u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808ED3 PLA
    cpu.pop("PLA", hw);
    goto L_808ED4;
L_808ED4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED4u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED4u, 6u, 3u, cpu.address("absx", 0x1801u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808ED4 STA
    hw.write(cpu.address("absx", 0x1801u), cpu.a, cpu.m8?8:16);
    goto L_808ED7;
L_808ED7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED7u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED7u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808ED7 PLA
    cpu.pop("PLA", hw);
    goto L_808ED8;
L_808ED8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED8u, 6u, 3u, cpu.address("absx", 0x1803u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808ED8 STA
    hw.write(cpu.address("absx", 0x1803u), cpu.a, cpu.m8?8:16);
    goto L_808EDB;
L_808EDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDBu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDBu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808EDB PLA
    cpu.pop("PLA", hw);
    goto L_808EDC;
L_808EDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDCu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDCu, 6u, 3u, cpu.address("absx", 0x1806u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808EDC STA
    hw.write(cpu.address("absx", 0x1806u), cpu.a, cpu.m8?8:16);
    goto L_808EDF;
L_808EDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDFu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDFu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808EDF PLP
    cpu.pop("PLP", hw);
    goto L_808EE0;
L_808EE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8EE0u,0x808EE0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE0u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808EE0 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808EE0u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808EE0u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_808EE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE1u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE1u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808EE1 PHP
    cpu.push("PHP", hw);
    goto L_808EE2;
L_808EE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE2u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808EE2 REP
    cpu.rep(0x20u);
    goto L_808EE4;
L_808EE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE4u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE4u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808EE4 PHA
    cpu.push("PHA", hw);
    goto L_808EE5;
L_808EE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE5u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE5u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808EE5 PHX
    cpu.push("PHX", hw);
    goto L_808EE6;
L_808EE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE6u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE6u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $808EE6 PHY
    cpu.push("PHY", hw);
    goto L_808EE7;
L_808EE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE7u, 8u, 4u, 0x808B7Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808EE7 JSL -> $808B7C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8EEAu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8EEBu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808B7Cu, 0x808EE7u); }
    goto L_808EEB;
L_808EEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EEBu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8EEBu,0x808EEBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808EEB LDA
    cpu.setA(0x7Fu, 16);
    goto L_808EEE;
L_808EEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEEu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808EEE BRA -> $808ECA
    goto L_808ECA;
}

void sub_80AE64_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AE64u: goto L_80AE64;
    case 0x80AE67u: goto L_80AE67;
    case 0x80AE69u: goto L_80AE69;
    case 0x80AE6Cu: goto L_80AE6C;
    case 0x80AE6Fu: goto L_80AE6F;
    case 0x80AE71u: goto L_80AE71;
    case 0x80AE74u: goto L_80AE74;
    case 0x80AE77u: goto L_80AE77;
    case 0x80AE7Au: goto L_80AE7A;
    case 0x80AE7Du: goto L_80AE7D;
    case 0x80AE80u: goto L_80AE80;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AE64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE64u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE64u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE64 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AE67;
L_80AE67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE67u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE67u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE67 BEQ -> $80AE7A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AE7A; }
    goto L_80AE69;
L_80AE69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE69u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE69u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE69 LDX
    cpu.setX(0x354u, 16);
    goto L_80AE6C;
L_80AE6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE6C LDA
    cpu.setA(0x2u, 16);
    goto L_80AE6F;
L_80AE6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE6F STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80AE71;
L_80AE71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE71u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE71u, 8u, 3u, cpu.address("abs", 0x0986u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE71 INC
    cpu.incMem(hw, cpu.address("abs", 0x986u), cpu.m8?8:16);
    goto L_80AE74;
L_80AE74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE74u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE74u, 6u, 3u, cpu.address("abs", 0xC829u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AE74 JSR -> $80C829 stack real
    { cpu.push16Value(hw,0xAE76u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE77u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC829u), 0x80AE74u); }
    goto L_80AE77;
L_80AE77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE77u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE77u,0x80AE77u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE77u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE77u, 6u, 3u, cpu.address("abs", 0xBBFAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AE77 JSR -> $80BBFA stack real
    { cpu.push16Value(hw,0xAE79u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE7Au,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBBFAu), 0x80AE77u); }
    goto L_80AE7A;
L_80AE7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE7Au))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE7Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE7Au, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE7A STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80AE7D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE7Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE7Au, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE7A STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80AE7D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE7Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE7Au, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE7A STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80AE7D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE7Au,0x80AE7Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AE7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE7Du))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE7Du,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE7Du, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE7D INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AE80;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE7Du,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE7Du, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE7D INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AE80;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE7Du,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE7Du, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE7D INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AE80;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE7Du,0x80AE7Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AE80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE80u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE80u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE80u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AE80 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AE80u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AE80u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE80u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE80u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AE80 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AE80u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AE80u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE80u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE80u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AE80 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AE80u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AE80u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE80u,0x80AE80u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80AF64_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AF64u: goto L_80AF64;
    case 0x80AF67u: goto L_80AF67;
    case 0x80AF69u: goto L_80AF69;
    case 0x80AF6Cu: goto L_80AF6C;
    case 0x80AF6Eu: goto L_80AF6E;
    case 0x80AF71u: goto L_80AF71;
    case 0x80AF74u: goto L_80AF74;
    case 0x80AF77u: goto L_80AF77;
    case 0x80AF7Au: goto L_80AF7A;
    case 0x80AF7Du: goto L_80AF7D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AF64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF64u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF64u, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF64 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AF67;
L_80AF67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF67u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF67u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF67 BEQ -> $80AF77
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AF77; }
    goto L_80AF69;
L_80AF69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF69u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF69u, 5u, 3u, cpu.address("abs", 0x098Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF69 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x98Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AF6C;
L_80AF6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF6Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF6Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF6C BEQ -> $80AF77
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AF77; }
    goto L_80AF6E;
L_80AF6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF6Eu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF6Eu, 8u, 3u, cpu.address("abs", 0x0986u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF6E INC
    cpu.incMem(hw, cpu.address("abs", 0x986u), cpu.m8?8:16);
    goto L_80AF71;
L_80AF71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF71u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF71u, 6u, 3u, cpu.address("abs", 0xCB02u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AF71 JSR -> $80CB02 stack real
    { cpu.push16Value(hw,0xAF73u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF74u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCB02u), 0x80AF71u); }
    goto L_80AF74;
L_80AF74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF74u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF74u,0x80AF74u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF74u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF74u, 6u, 3u, cpu.address("abs", 0xBCC2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AF74 JSR -> $80BCC2 stack real
    { cpu.push16Value(hw,0xAF76u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF77u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBCC2u), 0x80AF74u); }
    goto L_80AF77;
L_80AF77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF77u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF77u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF77u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF77 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AF7A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF77u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF77u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF77 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AF7A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF77u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF77u, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF77 INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AF7A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF77u,0x80AF77u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AF7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF7Au))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Au, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF7A STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80AF7D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Au, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF7A STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80AF7D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Au, 5u, 3u, cpu.address("abs", 0x0986u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF7A STZ
    hw.write(cpu.address("abs", 0x986u), 0, cpu.m8?8:16);
    goto L_80AF7D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF7Au,0x80AF7Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AF7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF7Du))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AF7D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AF7Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AF7Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AF7D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AF7Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AF7Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AF7D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AF7Du);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AF7Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF7Du,0x80AF7Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80AF7E_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AF7Eu: goto L_80AF7E;
    case 0x80AF81u: goto L_80AF81;
    case 0x80AF83u: goto L_80AF83;
    case 0x80AF86u: goto L_80AF86;
    case 0x80AF89u: goto L_80AF89;
    case 0x80AF8Cu: goto L_80AF8C;
    case 0x80AF8Fu: goto L_80AF8F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AF7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF7Eu, 5u, 3u, cpu.address("abs", 0x0958u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF7E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x958u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AF81;
L_80AF81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF81u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF81u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF81 BEQ -> $80AF8C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AF8C; }
    goto L_80AF83;
L_80AF83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF83u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF83u, 5u, 3u, cpu.address("abs", 0x0914u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF83 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x914u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AF86;
L_80AF86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF86u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF86u, 5u, 3u, cpu.address("abs", 0x097Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF86 STA
    hw.write(cpu.address("abs", 0x97Au), cpu.a, cpu.m8?8:16);
    goto L_80AF89;
L_80AF89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF89u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF89u, 6u, 3u, cpu.address("abs", 0xBBB7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AF89 JSR -> $80BBB7 stack real
    { cpu.push16Value(hw,0xAF8Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAF8Cu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBBB7u), 0x80AF89u); }
    goto L_80AF8C;
L_80AF8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF8Cu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Cu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Cu, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF8C INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AF8F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Cu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Cu, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF8C INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AF8F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Cu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Cu, 8u, 3u, cpu.address("abs", 0x0900u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AF8C INC
    cpu.incMem(hw, cpu.address("abs", 0x900u), cpu.m8?8:16);
    goto L_80AF8F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF8Cu,0x80AF8Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AF8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAF8Fu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AF8F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AF8Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AF8Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AF8F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AF8Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AF8Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAF8Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AF8F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AF8Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80AF8Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAF8Fu,0x80AF8Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80B343_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B343u: goto L_80B343;
    case 0x80B346u: goto L_80B346;
    case 0x80B348u: goto L_80B348;
    case 0x80B34Bu: goto L_80B34B;
    case 0x80B34Eu: goto L_80B34E;
    case 0x80B350u: goto L_80B350;
    case 0x80B353u: goto L_80B353;
    case 0x80B356u: goto L_80B356;
    case 0x80B359u: goto L_80B359;
    case 0x80B35Cu: goto L_80B35C;
    case 0x80B35Fu: goto L_80B35F;
    case 0x80B362u: goto L_80B362;
    case 0x80B365u: goto L_80B365;
    case 0x80B368u: goto L_80B368;
    case 0x80B36Bu: goto L_80B36B;
    case 0x80B36Eu: goto L_80B36E;
    case 0x80B371u: goto L_80B371;
    case 0x80B374u: goto L_80B374;
    case 0x80B377u: goto L_80B377;
    case 0x80B37Au: goto L_80B37A;
    case 0x80B37Du: goto L_80B37D;
    case 0x80B380u: goto L_80B380;
    case 0x80B383u: goto L_80B383;
    case 0x80B386u: goto L_80B386;
    case 0x80B389u: goto L_80B389;
    case 0x80B38Cu: goto L_80B38C;
    case 0x80B38Eu: goto L_80B38E;
    case 0x80B391u: goto L_80B391;
    case 0x80B393u: goto L_80B393;
    case 0x80B396u: goto L_80B396;
    case 0x80B399u: goto L_80B399;
    case 0x80B39Cu: goto L_80B39C;
    case 0x80B39Eu: goto L_80B39E;
    case 0x80B3A1u: goto L_80B3A1;
    case 0x80B3A3u: goto L_80B3A3;
    case 0x80B3A6u: goto L_80B3A6;
    case 0x80B3A9u: goto L_80B3A9;
    case 0x80B3ABu: goto L_80B3AB;
    case 0x80B3ADu: goto L_80B3AD;
    case 0x80B3B0u: goto L_80B3B0;
    case 0x80B3B3u: goto L_80B3B3;
    case 0x80B3B5u: goto L_80B3B5;
    case 0x80B3B7u: goto L_80B3B7;
    case 0x80B3BAu: goto L_80B3BA;
    case 0x80B3BDu: goto L_80B3BD;
    case 0x80B3BFu: goto L_80B3BF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B343:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB343u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB343u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB343u, 5u, 3u, cpu.address("abs", 0x099Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B343 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x99Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B346;
L_80B346:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB346u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB346u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB346u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B346 BEQ -> $80B34B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B34B; }
    goto L_80B348;
L_80B348:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB348u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB348u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB348u, 3u, 3u, cpu.address("abs", 0xB3BFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B348 JMP -> $80B3BF
    goto L_80B3BF;
L_80B34B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB34Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Bu, 5u, 3u, cpu.address("abs", 0x094Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B34B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x94Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B34E;
L_80B34E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB34Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B34E BEQ -> $80B353
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B353; }
    goto L_80B350;
L_80B350:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB350u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB350u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB350u, 8u, 3u, cpu.address("abs", 0x094Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B350 DEC
    cpu.decMem(hw, cpu.address("abs", 0x94Eu), cpu.m8?8:16);
    goto L_80B353;
L_80B353:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB353u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB353u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB353u, 5u, 3u, cpu.address("abs", 0x039Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B353 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x39Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B356;
L_80B356:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB356u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB356u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB356u, 5u, 3u, cpu.address("abs", 0x0902u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B356 STA
    hw.write(cpu.address("abs", 0x902u), cpu.a, cpu.m8?8:16);
    goto L_80B359;
L_80B359:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB359u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB359u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB359u, 6u, 3u, cpu.address("abs", 0xB417u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B359 JSR -> $80B417 stack real
    { cpu.push16Value(hw,0xB35Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB35Cu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB417u), 0x80B359u); }
    goto L_80B35C;
L_80B35C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB35Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB35Cu,0x80B35Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Cu, 5u, 3u, cpu.address("abs", 0x0308u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B35C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x308u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B35F;
L_80B35F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB35Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B35F AND
    cpu.logicAnd(0xFFu);
    goto L_80B362;
L_80B362:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB362u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB362u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB362u, 5u, 3u, cpu.address("abs", 0x097Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B362 STA
    hw.write(cpu.address("abs", 0x97Eu), cpu.a, cpu.m8?8:16);
    goto L_80B365;
L_80B365:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB365u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB365u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB365u, 5u, 3u, cpu.address("abs", 0x030Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B365 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x30Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B368;
L_80B368:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB368u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB368u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB368u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B368 AND
    cpu.logicAnd(0xFFu);
    goto L_80B36B;
L_80B36B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB36Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB36Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB36Bu, 5u, 3u, cpu.address("abs", 0x0980u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B36B STA
    hw.write(cpu.address("abs", 0x980u), cpu.a, cpu.m8?8:16);
    goto L_80B36E;
L_80B36E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB36Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB36Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB36Eu, 5u, 3u, cpu.address("abs", 0x0314u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B36E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x314u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B371;
L_80B371:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB371u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB371u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB371u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B371 AND
    cpu.logicAnd(0xFFu);
    goto L_80B374;
L_80B374:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB374u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB374u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB374u, 5u, 3u, cpu.address("abs", 0x0982u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B374 STA
    hw.write(cpu.address("abs", 0x982u), cpu.a, cpu.m8?8:16);
    goto L_80B377;
L_80B377:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB377u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB377u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB377u, 5u, 3u, cpu.address("abs", 0x031Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B377 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x31Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B37A;
L_80B37A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB37Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B37A AND
    cpu.logicAnd(0xFFu);
    goto L_80B37D;
L_80B37D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB37Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Du, 5u, 3u, cpu.address("abs", 0x0984u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B37D STA
    hw.write(cpu.address("abs", 0x984u), cpu.a, cpu.m8?8:16);
    goto L_80B380;
L_80B380:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB380u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB380u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB380u, 6u, 3u, cpu.address("abs", 0xB47Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B380 JSR -> $80B47A stack real
    { cpu.push16Value(hw,0xB382u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB383u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB47Au), 0x80B380u); }
    goto L_80B383;
L_80B383:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB383u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB383u,0x80B383u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB383u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB383u, 5u, 3u, cpu.address("abs", 0x091Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B383 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x91Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B386;
L_80B386:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB386u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB386u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB386u, 5u + 1u, 3u, cpu.address("absx", 0x097Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B386 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x97Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B389;
L_80B389:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB389u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB389u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB389u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B389 CMP
    cpu.compareA(0xFFu);
    goto L_80B38C;
L_80B38C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB38Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B38C BNE -> $80B393
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B393; }
    goto L_80B38E;
L_80B38E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB38Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Eu, 6u, 3u, cpu.address("abs", 0xB4DAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B38E JSR -> $80B4DA stack real
    { cpu.push16Value(hw,0xB390u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB391u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB4DAu), 0x80B38Eu); }
    goto L_80B391;
L_80B391:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB391u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB391u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB391u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B391 BRA -> $80B396
    goto L_80B396;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB391u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB391u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B391 BRA -> $80B396
    goto L_80B396;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB391u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB391u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B391 BRA -> $80B396
    goto L_80B396;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB391u,0x80B391u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B393:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB393u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB393u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB393u, 6u, 3u, cpu.address("abs", 0xB7A9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B393 JSR -> $80B7A9 stack real
    { cpu.push16Value(hw,0xB395u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB396u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB7A9u), 0x80B393u); }
    goto L_80B396;
L_80B396:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB396u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB396u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB396u, 6u, 3u, cpu.address("abs", 0xB827u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B396 JSR -> $80B827 stack real
    { cpu.push16Value(hw,0xB398u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB399u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB827u), 0x80B396u); }
    goto L_80B399;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB396u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB396u, 6u, 3u, cpu.address("abs", 0xB827u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B396 JSR -> $80B827 stack real
    { cpu.push16Value(hw,0xB398u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB399u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB827u), 0x80B396u); }
    goto L_80B399;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB396u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB396u, 6u, 3u, cpu.address("abs", 0xB827u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B396 JSR -> $80B827 stack real
    { cpu.push16Value(hw,0xB398u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB399u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB827u), 0x80B396u); }
    goto L_80B399;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB396u,0x80B396u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B399:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB399u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB399u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB399u, 5u, 3u, cpu.address("abs", 0x0922u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B399 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x922u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B39C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB399u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB399u, 5u, 3u, cpu.address("abs", 0x0922u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B399 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x922u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B39C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB399u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB399u, 5u, 3u, cpu.address("abs", 0x0922u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B399 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x922u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B39C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB399u,0x80B399u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B39C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB39Cu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39C STA
    hw.write(cpu.address("dp", 0x9Eu), cpu.a, cpu.m8?8:16);
    goto L_80B39E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39C STA
    hw.write(cpu.address("dp", 0x9Eu), cpu.a, cpu.m8?8:16);
    goto L_80B39E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39C STA
    hw.write(cpu.address("dp", 0x9Eu), cpu.a, cpu.m8?8:16);
    goto L_80B39E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB39Cu,0x80B39Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B39E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB39Eu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Eu, 5u, 3u, cpu.address("abs", 0x0924u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x924u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B3A1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Eu, 5u, 3u, cpu.address("abs", 0x0924u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x924u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B3A1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Eu, 5u, 3u, cpu.address("abs", 0x0924u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x924u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B3A1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB39Eu,0x80B39Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B3A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A1u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B3A1 STA
    hw.write(cpu.address("dp", 0xA2u), cpu.a, cpu.m8?8:16);
    goto L_80B3A3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B3A1 STA
    hw.write(cpu.address("dp", 0xA2u), cpu.a, cpu.m8?8:16);
    goto L_80B3A3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B3A1 STA
    hw.write(cpu.address("dp", 0xA2u), cpu.a, cpu.m8?8:16);
    goto L_80B3A3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3A1u,0x80B3A1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B3A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A3u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A3u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B3A3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B3A6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A3u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B3A3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B3A6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A3u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B3A3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B3A6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3A3u,0x80B3A3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B3A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A6u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B3A6 CMP
    cpu.compareA(0x4u);
    goto L_80B3A9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B3A6 CMP
    cpu.compareA(0x4u);
    goto L_80B3A9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B3A6 CMP
    cpu.compareA(0x4u);
    goto L_80B3A9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3A6u,0x80B3A6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B3A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A9u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B3A9 BCC -> $80B3BF
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B3BF; }
    goto L_80B3AB;
L_80B3AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3ABu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3ABu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B3AB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B3AD;
L_80B3AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3ADu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3ADu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B3AD AND
    cpu.logicAnd(0x2030u);
    goto L_80B3B0;
L_80B3B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B0u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B0u, 5u, 3u, cpu.address("abs", 0x0922u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B3B0 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x922u), cpu.m8?8:16));
    goto L_80B3B3;
L_80B3B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B3B3 STA
    hw.write(cpu.address("dp", 0x9Cu), cpu.a, cpu.m8?8:16);
    goto L_80B3B5;
L_80B3B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B3B5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B3B7;
L_80B3B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B3B7 AND
    cpu.logicAnd(0x2030u);
    goto L_80B3BA;
L_80B3BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BAu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BAu, 5u, 3u, cpu.address("abs", 0x0924u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B3BA ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x924u), cpu.m8?8:16));
    goto L_80B3BD;
L_80B3BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B3BD STA
    hw.write(cpu.address("dp", 0xA0u), cpu.a, cpu.m8?8:16);
    goto L_80B3BF;
L_80B3BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3BFu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B3BF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B3BFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B3BFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B3BF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B3BFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B3BFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3BFu,0x80B3BFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80B343_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B343u: goto L_80B343;
    case 0x80B346u: goto L_80B346;
    case 0x80B348u: goto L_80B348;
    case 0x80B34Bu: goto L_80B34B;
    case 0x80B34Eu: goto L_80B34E;
    case 0x80B350u: goto L_80B350;
    case 0x80B353u: goto L_80B353;
    case 0x80B356u: goto L_80B356;
    case 0x80B359u: goto L_80B359;
    case 0x80B35Cu: goto L_80B35C;
    case 0x80B35Fu: goto L_80B35F;
    case 0x80B362u: goto L_80B362;
    case 0x80B365u: goto L_80B365;
    case 0x80B368u: goto L_80B368;
    case 0x80B36Bu: goto L_80B36B;
    case 0x80B36Eu: goto L_80B36E;
    case 0x80B371u: goto L_80B371;
    case 0x80B374u: goto L_80B374;
    case 0x80B377u: goto L_80B377;
    case 0x80B37Au: goto L_80B37A;
    case 0x80B37Du: goto L_80B37D;
    case 0x80B380u: goto L_80B380;
    case 0x80B383u: goto L_80B383;
    case 0x80B386u: goto L_80B386;
    case 0x80B389u: goto L_80B389;
    case 0x80B38Cu: goto L_80B38C;
    case 0x80B38Eu: goto L_80B38E;
    case 0x80B391u: goto L_80B391;
    case 0x80B393u: goto L_80B393;
    case 0x80B396u: goto L_80B396;
    case 0x80B399u: goto L_80B399;
    case 0x80B39Cu: goto L_80B39C;
    case 0x80B39Eu: goto L_80B39E;
    case 0x80B3A1u: goto L_80B3A1;
    case 0x80B3A3u: goto L_80B3A3;
    case 0x80B3A6u: goto L_80B3A6;
    case 0x80B3A9u: goto L_80B3A9;
    case 0x80B3ABu: goto L_80B3AB;
    case 0x80B3ADu: goto L_80B3AD;
    case 0x80B3B0u: goto L_80B3B0;
    case 0x80B3B3u: goto L_80B3B3;
    case 0x80B3B5u: goto L_80B3B5;
    case 0x80B3B7u: goto L_80B3B7;
    case 0x80B3BAu: goto L_80B3BA;
    case 0x80B3BDu: goto L_80B3BD;
    case 0x80B3BFu: goto L_80B3BF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B343:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB343u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB343u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB343u, 5u, 3u, cpu.address("abs", 0x099Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B343 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x99Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B346;
L_80B346:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB346u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB346u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB346u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B346 BEQ -> $80B34B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B34B; }
    goto L_80B348;
L_80B348:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB348u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB348u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB348u, 3u, 3u, cpu.address("abs", 0xB3BFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B348 JMP -> $80B3BF
    goto L_80B3BF;
L_80B34B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB34Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Bu, 5u, 3u, cpu.address("abs", 0x094Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B34B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x94Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B34E;
L_80B34E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB34Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB34Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B34E BEQ -> $80B353
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B353; }
    goto L_80B350;
L_80B350:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB350u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB350u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB350u, 8u, 3u, cpu.address("abs", 0x094Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B350 DEC
    cpu.decMem(hw, cpu.address("abs", 0x94Eu), cpu.m8?8:16);
    goto L_80B353;
L_80B353:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB353u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB353u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB353u, 5u, 3u, cpu.address("abs", 0x039Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B353 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x39Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B356;
L_80B356:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB356u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB356u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB356u, 5u, 3u, cpu.address("abs", 0x0902u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B356 STA
    hw.write(cpu.address("abs", 0x902u), cpu.a, cpu.m8?8:16);
    goto L_80B359;
L_80B359:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB359u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB359u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB359u, 6u, 3u, cpu.address("abs", 0xB417u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B359 JSR -> $80B417 stack real
    { cpu.push16Value(hw,0xB35Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB35Cu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB417u), 0x80B359u); }
    goto L_80B35C;
L_80B35C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB35Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB35Cu,0x80B35Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Cu, 5u, 3u, cpu.address("abs", 0x0308u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B35C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x308u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B35F;
L_80B35F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB35Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB35Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B35F AND
    cpu.logicAnd(0xFFu);
    goto L_80B362;
L_80B362:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB362u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB362u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB362u, 5u, 3u, cpu.address("abs", 0x097Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B362 STA
    hw.write(cpu.address("abs", 0x97Eu), cpu.a, cpu.m8?8:16);
    goto L_80B365;
L_80B365:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB365u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB365u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB365u, 5u, 3u, cpu.address("abs", 0x030Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B365 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x30Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B368;
L_80B368:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB368u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB368u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB368u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B368 AND
    cpu.logicAnd(0xFFu);
    goto L_80B36B;
L_80B36B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB36Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB36Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB36Bu, 5u, 3u, cpu.address("abs", 0x0980u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B36B STA
    hw.write(cpu.address("abs", 0x980u), cpu.a, cpu.m8?8:16);
    goto L_80B36E;
L_80B36E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB36Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB36Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB36Eu, 5u, 3u, cpu.address("abs", 0x0314u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B36E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x314u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B371;
L_80B371:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB371u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB371u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB371u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B371 AND
    cpu.logicAnd(0xFFu);
    goto L_80B374;
L_80B374:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB374u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB374u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB374u, 5u, 3u, cpu.address("abs", 0x0982u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B374 STA
    hw.write(cpu.address("abs", 0x982u), cpu.a, cpu.m8?8:16);
    goto L_80B377;
L_80B377:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB377u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB377u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB377u, 5u, 3u, cpu.address("abs", 0x031Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B377 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x31Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B37A;
L_80B37A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB37Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B37A AND
    cpu.logicAnd(0xFFu);
    goto L_80B37D;
L_80B37D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB37Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB37Du, 5u, 3u, cpu.address("abs", 0x0984u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B37D STA
    hw.write(cpu.address("abs", 0x984u), cpu.a, cpu.m8?8:16);
    goto L_80B380;
L_80B380:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB380u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB380u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB380u, 6u, 3u, cpu.address("abs", 0xB47Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B380 JSR -> $80B47A stack real
    { cpu.push16Value(hw,0xB382u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB383u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB47Au), 0x80B380u); }
    goto L_80B383;
L_80B383:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB383u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB383u,0x80B383u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB383u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB383u, 5u, 3u, cpu.address("abs", 0x091Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B383 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x91Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B386;
L_80B386:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB386u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB386u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB386u, 5u + 1u, 3u, cpu.address("absx", 0x097Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B386 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x97Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B389;
L_80B389:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB389u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB389u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB389u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B389 CMP
    cpu.compareA(0xFFu);
    goto L_80B38C;
L_80B38C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB38Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B38C BNE -> $80B393
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B393; }
    goto L_80B38E;
L_80B38E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB38Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB38Eu, 6u, 3u, cpu.address("abs", 0xB4DAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B38E JSR -> $80B4DA stack real
    { cpu.push16Value(hw,0xB390u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB391u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB4DAu), 0x80B38Eu); }
    goto L_80B391;
L_80B391:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB391u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB391u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB391u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B391 BRA -> $80B396
    goto L_80B396;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB391u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB391u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B391 BRA -> $80B396
    goto L_80B396;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB391u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB391u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B391 BRA -> $80B396
    goto L_80B396;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB391u,0x80B391u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B393:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB393u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB393u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB393u, 6u, 3u, cpu.address("abs", 0xB7A9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B393 JSR -> $80B7A9 stack real
    { cpu.push16Value(hw,0xB395u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB396u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB7A9u), 0x80B393u); }
    goto L_80B396;
L_80B396:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB396u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB396u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB396u, 6u, 3u, cpu.address("abs", 0xB827u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B396 JSR -> $80B827 stack real
    { cpu.push16Value(hw,0xB398u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB399u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB827u), 0x80B396u); }
    goto L_80B399;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB396u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB396u, 6u, 3u, cpu.address("abs", 0xB827u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B396 JSR -> $80B827 stack real
    { cpu.push16Value(hw,0xB398u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB399u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB827u), 0x80B396u); }
    goto L_80B399;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB396u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB396u, 6u, 3u, cpu.address("abs", 0xB827u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B396 JSR -> $80B827 stack real
    { cpu.push16Value(hw,0xB398u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB399u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB827u), 0x80B396u); }
    goto L_80B399;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB396u,0x80B396u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B399:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB399u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB399u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB399u, 5u, 3u, cpu.address("abs", 0x0922u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B399 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x922u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B39C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB399u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB399u, 5u, 3u, cpu.address("abs", 0x0922u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B399 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x922u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B39C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB399u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB399u, 5u, 3u, cpu.address("abs", 0x0922u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B399 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x922u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B39C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB399u,0x80B399u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B39C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB39Cu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39C STA
    hw.write(cpu.address("dp", 0x9Eu), cpu.a, cpu.m8?8:16);
    goto L_80B39E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39C STA
    hw.write(cpu.address("dp", 0x9Eu), cpu.a, cpu.m8?8:16);
    goto L_80B39E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39C STA
    hw.write(cpu.address("dp", 0x9Eu), cpu.a, cpu.m8?8:16);
    goto L_80B39E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB39Cu,0x80B39Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B39E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB39Eu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Eu, 5u, 3u, cpu.address("abs", 0x0924u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x924u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B3A1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Eu, 5u, 3u, cpu.address("abs", 0x0924u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x924u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B3A1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB39Eu, 5u, 3u, cpu.address("abs", 0x0924u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B39E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x924u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B3A1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB39Eu,0x80B39Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B3A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A1u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B3A1 STA
    hw.write(cpu.address("dp", 0xA2u), cpu.a, cpu.m8?8:16);
    goto L_80B3A3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B3A1 STA
    hw.write(cpu.address("dp", 0xA2u), cpu.a, cpu.m8?8:16);
    goto L_80B3A3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B3A1 STA
    hw.write(cpu.address("dp", 0xA2u), cpu.a, cpu.m8?8:16);
    goto L_80B3A3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3A1u,0x80B3A1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B3A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A3u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A3u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B3A3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B3A6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A3u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B3A3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B3A6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A3u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B3A3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B3A6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3A3u,0x80B3A3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B3A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A6u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B3A6 CMP
    cpu.compareA(0x4u);
    goto L_80B3A9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B3A6 CMP
    cpu.compareA(0x4u);
    goto L_80B3A9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B3A6 CMP
    cpu.compareA(0x4u);
    goto L_80B3A9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB3A6u,0x80B3A6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B3A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A9u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3A9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B3A9 BCC -> $80B3BF
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B3BF; }
    goto L_80B3AB;
L_80B3AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3ABu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3ABu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B3AB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B3AD;
L_80B3AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3ADu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3ADu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B3AD AND
    cpu.logicAnd(0x2030u);
    goto L_80B3B0;
L_80B3B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B0u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B0u, 5u, 3u, cpu.address("abs", 0x0922u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B3B0 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x922u), cpu.m8?8:16));
    goto L_80B3B3;
L_80B3B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B3B3 STA
    hw.write(cpu.address("dp", 0x9Cu), cpu.a, cpu.m8?8:16);
    goto L_80B3B5;
L_80B3B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B3B5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B3B7;
L_80B3B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3B7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B3B7 AND
    cpu.logicAnd(0x2030u);
    goto L_80B3BA;
L_80B3BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BAu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BAu, 5u, 3u, cpu.address("abs", 0x0924u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B3BA ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x924u), cpu.m8?8:16));
    goto L_80B3BD;
L_80B3BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B3BD STA
    hw.write(cpu.address("dp", 0xA0u), cpu.a, cpu.m8?8:16);
    goto L_80B3BF;
L_80B3BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB3BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB3BFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B3BF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B3BFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B3BFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80B8AF_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B8AFu: goto L_80B8AF;
    case 0x80B8B2u: goto L_80B8B2;
    case 0x80B8B5u: goto L_80B8B5;
    case 0x80B8B7u: goto L_80B8B7;
    case 0x80B8BAu: goto L_80B8BA;
    case 0x80B8BCu: goto L_80B8BC;
    case 0x80B8BFu: goto L_80B8BF;
    case 0x80B8C2u: goto L_80B8C2;
    case 0x80B8C4u: goto L_80B8C4;
    case 0x80B8C7u: goto L_80B8C7;
    case 0x80B8CAu: goto L_80B8CA;
    case 0x80B8CCu: goto L_80B8CC;
    case 0x80B8CFu: goto L_80B8CF;
    case 0x80B8D2u: goto L_80B8D2;
    case 0x80B8D5u: goto L_80B8D5;
    case 0x80B8D7u: goto L_80B8D7;
    case 0x80B8DAu: goto L_80B8DA;
    case 0x80B8DEu: goto L_80B8DE;
    case 0x80B8E0u: goto L_80B8E0;
    case 0x80B8E1u: goto L_80B8E1;
    case 0x80B8E2u: goto L_80B8E2;
    case 0x80B8E4u: goto L_80B8E4;
    case 0x80B8E7u: goto L_80B8E7;
    case 0x80B8E9u: goto L_80B8E9;
    case 0x80B8ECu: goto L_80B8EC;
    case 0x80B8EEu: goto L_80B8EE;
    case 0x80B8F1u: goto L_80B8F1;
    case 0x80B8F3u: goto L_80B8F3;
    case 0x80B8F6u: goto L_80B8F6;
    case 0x80B8F9u: goto L_80B8F9;
    case 0x80B8FBu: goto L_80B8FB;
    case 0x80B8FEu: goto L_80B8FE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B8AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8AFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8AFu, 5u, 3u, cpu.address("abs", 0x094Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B8AF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x94Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B8B2;
L_80B8B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8B2u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8B2u, 5u, 3u, cpu.address("abs", 0x091Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B8B2 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x91Cu), cpu.m8?8:16));
    goto L_80B8B5;
L_80B8B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8B5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8B5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B8B5 BEQ -> $80B8FE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B8FE; }
    goto L_80B8B7;
L_80B8B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8B7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8B7u, 5u, 3u, cpu.address("abs", 0x0946u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B8B7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x946u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B8BA;
L_80B8BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8BAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8BAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B8BA BNE -> $80B8FB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B8FB; }
    goto L_80B8BC;
L_80B8BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8BCu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8BCu, 5u, 3u, cpu.address("abs", 0x091Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B8BC LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x91Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B8BF;
L_80B8BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8BFu,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8BFu, 5u, 3u, cpu.address("abs", 0x095Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B8BF CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x95Cu), cpu.m8?8:16));
    goto L_80B8C2;
L_80B8C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8C2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8C2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B8C2 BNE -> $80B8FE
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B8FE; }
    goto L_80B8C4;
L_80B8C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8C4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8C4u, 5u, 3u, cpu.address("abs", 0x0902u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B8C4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x902u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B8C7;
L_80B8C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8C7u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8C7u, 5u, 3u, cpu.address("abs", 0x0926u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B8C7 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x926u), cpu.m8?8:16));
    goto L_80B8CA;
L_80B8CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8CAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8CAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B8CA BNE -> $80B8FE
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B8FE; }
    goto L_80B8CC;
L_80B8CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8CCu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8CCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B8CC LDY
    cpu.setY(0x6u, 16);
    goto L_80B8CF;
L_80B8CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8CFu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8CFu, 5u + 1u, 3u, cpu.address("absy", 0x097Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B8CF LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x97Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B8D2;
L_80B8D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D2u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B8D2 CMP
    cpu.compareA(0xFFu);
    goto L_80B8D5;
L_80B8D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B8D5 BEQ -> $80B8E0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B8E0; }
    goto L_80B8D7;
L_80B8D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D7u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8D7u, 5u + 1u, 3u, cpu.address("absy", 0x093Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B8D7 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0x93Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B8DA;
L_80B8DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DAu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DAu, 6u, 4u, ((0x7E2016u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B8DA LDA
    cpu.loadA(hw.readW(((0x7E2016u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B8DE;
L_80B8DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8DEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B8DE BNE -> $80B8FE
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B8FE; }
    goto L_80B8E0;
L_80B8E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E0u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B8E0 DEY
    cpu.decReg('Y');
    goto L_80B8E1;
L_80B8E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E1u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B8E1 DEY
    cpu.decReg('Y');
    goto L_80B8E2;
L_80B8E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E2u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B8E2 BPL -> $80B8CF
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80B8CF; }
    goto L_80B8E4;
L_80B8E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E4u, 5u, 3u, cpu.address("abs", 0x0137u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B8E4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x137u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B8E7;
L_80B8E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B8E7 BEQ -> $80B8FE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B8FE; }
    goto L_80B8E9;
L_80B8E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8E9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B8E9 CMP
    cpu.compareA(0x2u);
    goto L_80B8EC;
L_80B8EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8ECu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8ECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B8EC BCS -> $80B8F3
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B8F3; }
    goto L_80B8EE;
L_80B8EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8EEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8EEu, 6u, 3u, cpu.address("abs", 0xB8FFu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B8EE JSR -> $80B8FF stack real
    { cpu.push16Value(hw,0xB8F0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB8F1u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB8FFu), 0x80B8EEu); }
    goto L_80B8F1;
L_80B8F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8F1u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F1u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B8F1 BCC -> $80B8FE
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B8FE; }
    goto L_80B8F3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F1u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B8F1 BCC -> $80B8FE
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B8FE; }
    goto L_80B8F3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB8F1u,0x80B8F1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B8F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8F3u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B8F3 LDA
    cpu.setA(0x400u, 16);
    goto L_80B8F6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B8F3 LDA
    cpu.setA(0x400u, 16);
    goto L_80B8F6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B8F3 LDA
    cpu.setA(0x400u, 16);
    goto L_80B8F6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB8F3u,0x80B8F3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B8F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8F6u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F6u,cpu,0x0Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F6u, 8u, 3u, cpu.address("abs", 0x0922u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B8F6 TSB
    cpu.tsb(hw, cpu.address("abs", 0x922u), cpu.m8?8:16);
    goto L_80B8F9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F6u,cpu,0x0Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F6u, 8u, 3u, cpu.address("abs", 0x0922u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B8F6 TSB
    cpu.tsb(hw, cpu.address("abs", 0x922u), cpu.m8?8:16);
    goto L_80B8F9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F6u,cpu,0x0Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F6u, 8u, 3u, cpu.address("abs", 0x0922u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B8F6 TSB
    cpu.tsb(hw, cpu.address("abs", 0x922u), cpu.m8?8:16);
    goto L_80B8F9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB8F6u,0x80B8F6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B8F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8F9u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F9u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B8F9 BRA -> $80B8FE
    goto L_80B8FE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F9u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B8F9 BRA -> $80B8FE
    goto L_80B8FE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F9u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8F9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B8F9 BRA -> $80B8FE
    goto L_80B8FE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB8F9u,0x80B8F9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B8FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FBu, 6u, 3u, cpu.address("abs", 0xB930u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B8FB JSR -> $80B930 stack real
    { cpu.push16Value(hw,0xB8FDu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB8FEu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB930u), 0x80B8FBu); }
    goto L_80B8FE;
L_80B8FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB8FEu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B8FE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B8FEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B8FEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B8FE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B8FEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B8FEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB8FEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B8FE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B8FEu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80B8FEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB8FEu,0x80B8FEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80C248_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80C248u: goto L_80C248;
    case 0x80C24Au: goto L_80C24A;
    case 0x80C24Cu: goto L_80C24C;
    case 0x80C24Fu: goto L_80C24F;
    case 0x80C252u: goto L_80C252;
    case 0x80C254u: goto L_80C254;
    case 0x80C258u: goto L_80C258;
    case 0x80C25Au: goto L_80C25A;
    case 0x80C25Bu: goto L_80C25B;
    case 0x80C25Cu: goto L_80C25C;
    case 0x80C25Eu: goto L_80C25E;
    case 0x80C260u: goto L_80C260;
    case 0x80C262u: goto L_80C262;
    case 0x80C263u: goto L_80C263;
    case 0x80C264u: goto L_80C264;
    case 0x80C268u: goto L_80C268;
    case 0x80C26Au: goto L_80C26A;
    case 0x80C26Du: goto L_80C26D;
    case 0x80C26Fu: goto L_80C26F;
    case 0x80C271u: goto L_80C271;
    case 0x80C273u: goto L_80C273;
    case 0x80C275u: goto L_80C275;
    case 0x80C277u: goto L_80C277;
    case 0x80C279u: goto L_80C279;
    case 0x80C27Bu: goto L_80C27B;
    case 0x80C27Cu: goto L_80C27C;
    case 0x80C27Du: goto L_80C27D;
    case 0x80C281u: goto L_80C281;
    case 0x80C283u: goto L_80C283;
    case 0x80C286u: goto L_80C286;
    case 0x80C288u: goto L_80C288;
    case 0x80C28Au: goto L_80C28A;
    case 0x80C28Cu: goto L_80C28C;
    case 0x80C28Eu: goto L_80C28E;
    case 0x80C290u: goto L_80C290;
    case 0x80C292u: goto L_80C292;
    case 0x80C294u: goto L_80C294;
    case 0x80C296u: goto L_80C296;
    case 0x80C298u: goto L_80C298;
    case 0x80C29Bu: goto L_80C29B;
    case 0x80C29Du: goto L_80C29D;
    case 0x80C2A0u: goto L_80C2A0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80C248:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC248u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC248u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC248u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C248 STZ
    hw.write(cpu.address("dp", 0x1Cu), 0, cpu.m8?8:16);
    goto L_80C24A;
L_80C24A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC24Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC24Au,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC24Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C24A STZ
    hw.write(cpu.address("dp", 0x1Eu), 0, cpu.m8?8:16);
    goto L_80C24C;
L_80C24C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC24Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC24Cu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC24Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C24C LDY
    cpu.setY(0x6u, 16);
    goto L_80C24F;
L_80C24F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC24Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC24Fu,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC24Fu, 5u + 1u, 3u, cpu.address("absy", 0x0960u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C24F LDX
    cpu.setX(hw.readW(cpu.address("absy", 0x960u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C252;
L_80C252:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC252u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC252u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC252u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C252 BMI -> $80C25A
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80C25A; }
    goto L_80C254;
L_80C254:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC254u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC254u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC254u, 6u, 4u, ((0x7E2016u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C254 LDA
    cpu.loadA(hw.readW(((0x7E2016u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C258;
L_80C258:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC258u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC258u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC258u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C258 BNE -> $80C260
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C260; }
    goto L_80C25A;
L_80C25A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC25Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC25Au,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC25Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C25A DEY
    cpu.decReg('Y');
    goto L_80C25B;
L_80C25B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC25Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC25Bu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC25Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C25B DEY
    cpu.decReg('Y');
    goto L_80C25C;
L_80C25C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC25Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC25Cu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC25Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C25C BPL -> $80C24F
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80C24F; }
    goto L_80C25E;
L_80C25E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC25Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC25Eu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC25Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C25E BRA -> $80C2A0
    goto L_80C2A0;
L_80C260:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC260u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC260u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC260u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C260 STX
    hw.write(cpu.address("dp", 0x61u), cpu.x, cpu.x8?8:16);
    goto L_80C262;
L_80C262:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC262u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC262u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC262u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C262 INX
    cpu.inc('X');
    goto L_80C263;
L_80C263:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC263u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC263u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC263u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C263 INX
    cpu.inc('X');
    goto L_80C264;
L_80C264:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC264u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC264u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC264u, 6u, 4u, ((0x7E2016u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C264 LDA
    cpu.loadA(hw.readW(((0x7E2016u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C268;
L_80C268:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC268u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC268u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC268u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C268 BEQ -> $80C275
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C275; }
    goto L_80C26A;
L_80C26A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC26Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC26Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC26Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C26A CMP
    cpu.compareA(0xFFFFu);
    goto L_80C26D;
L_80C26D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC26Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC26Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC26Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C26D BEQ -> $80C279
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C279; }
    goto L_80C26F;
L_80C26F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC26Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC26Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC26Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C26F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C271;
L_80C271:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC271u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC271u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC271u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C271 BNE -> $80C279
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C279; }
    goto L_80C273;
L_80C273:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC273u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC273u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC273u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C273 BRA -> $80C262
    goto L_80C262;
L_80C275:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC275u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC275u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC275u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C275 INC
    cpu.incMem(hw, cpu.address("dp", 0x1Cu), cpu.m8?8:16);
    goto L_80C277;
L_80C277:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC277u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC277u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC277u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C277 BRA -> $80C262
    goto L_80C262;
L_80C279:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC279u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC279u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC279u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C279 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C27B;
L_80C27B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC27Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Bu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C27B DEX
    cpu.decReg('X');
    goto L_80C27C;
L_80C27C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC27Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Cu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C27C DEX
    cpu.decReg('X');
    goto L_80C27D;
L_80C27D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC27Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Du,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Du, 6u, 4u, ((0x7E2016u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C27D LDA
    cpu.loadA(hw.readW(((0x7E2016u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C281;
L_80C281:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC281u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC281u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC281u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C281 BEQ -> $80C28E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C28E; }
    goto L_80C283;
L_80C283:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC283u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC283u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC283u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C283 CMP
    cpu.compareA(0xFFFFu);
    goto L_80C286;
L_80C286:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC286u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC286u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC286u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C286 BEQ -> $80C292
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C292; }
    goto L_80C288;
L_80C288:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC288u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC288u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC288u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C288 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C28A;
L_80C28A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC28Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC28Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC28Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C28A BNE -> $80C292
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C292; }
    goto L_80C28C;
L_80C28C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC28Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC28Cu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC28Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C28C BRA -> $80C27B
    goto L_80C27B;
L_80C28E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC28Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC28Eu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC28Eu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C28E INC
    cpu.incMem(hw, cpu.address("dp", 0x1Eu), cpu.m8?8:16);
    goto L_80C290;
L_80C290:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC290u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC290u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC290u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C290 BRA -> $80C27B
    goto L_80C27B;
L_80C292:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC292u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC292u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC292u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C292 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C294;
L_80C294:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC294u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC294u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC294u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C294 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x1Eu), cpu.m8?8:16));
    goto L_80C296;
L_80C296:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC296u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC296u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC296u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C296 BCS -> $80C29D
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C29D; }
    goto L_80C298;
L_80C298:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC298u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC298u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC298u, 6u, 3u, cpu.address("abs", 0xC2A1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C298 JSR -> $80C2A1 stack real
    { cpu.push16Value(hw,0xC29Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC29Bu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC2A1u), 0x80C298u); }
    goto L_80C29B;
L_80C29B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC29Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC29Bu,0x80C29Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC29Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC29Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C29B BRA -> $80C2A0
    goto L_80C2A0;
L_80C29D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC29Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC29Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC29Du, 6u, 3u, cpu.address("abs", 0xC302u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C29D JSR -> $80C302 stack real
    { cpu.push16Value(hw,0xC29Fu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC2A0u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC302u), 0x80C29Du); }
    goto L_80C2A0;
L_80C2A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2A0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC2A0u,0x80C2A0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2A0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2A0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C2A0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80C2A0u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80C2A0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80CD63_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80CD63u: goto L_80CD63;
    case 0x80CD66u: goto L_80CD66;
    case 0x80CD69u: goto L_80CD69;
    case 0x80CD6Bu: goto L_80CD6B;
    case 0x80CD6Du: goto L_80CD6D;
    case 0x80CD6Eu: goto L_80CD6E;
    case 0x80CD6Fu: goto L_80CD6F;
    case 0x80CD73u: goto L_80CD73;
    case 0x80CD75u: goto L_80CD75;
    case 0x80CD78u: goto L_80CD78;
    case 0x80CD7Au: goto L_80CD7A;
    case 0x80CD7Du: goto L_80CD7D;
    case 0x80CD7Fu: goto L_80CD7F;
    case 0x80CD81u: goto L_80CD81;
    case 0x80CD83u: goto L_80CD83;
    case 0x80CD85u: goto L_80CD85;
    case 0x80CD88u: goto L_80CD88;
    case 0x80CD8Cu: goto L_80CD8C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80CD63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD63u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD63u, 5u, 3u, cpu.address("abs", 0x096Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CD63 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x96Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80CD66;
L_80CD66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD66u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD66u, 5u, 3u, cpu.address("abs", 0x0970u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CD66 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x970u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CD69;
L_80CD69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD69u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD69u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CD69 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80CD6B;
L_80CD6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Bu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CD6B STZ
    hw.write(cpu.address("dp", 0x63u), 0, cpu.m8?8:16);
    goto L_80CD6D;
L_80CD6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD6Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Du,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CD6D INX
    cpu.inc('X');
    goto L_80CD6E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Du,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CD6D INX
    cpu.inc('X');
    goto L_80CD6E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD6Du,0x80CD6Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CD6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD6Eu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Eu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CD6E INX
    cpu.inc('X');
    goto L_80CD6F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Eu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CD6E INX
    cpu.inc('X');
    goto L_80CD6F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD6Eu,0x80CD6Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CD6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD6Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Fu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Fu, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CD6F LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CD73;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Fu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Fu, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CD6F LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CD73;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD6Fu,0x80CD6Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CD73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD73u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD73u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD73u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CD73 BEQ -> $80CD6D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80CD6D; }
    goto L_80CD75;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD73u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD73u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CD73 BEQ -> $80CD6D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80CD6D; }
    goto L_80CD75;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD73u,0x80CD73u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CD75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD75u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD75u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD75u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CD75 CMP
    cpu.compareA(0xFFFFu);
    goto L_80CD78;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD75u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD75u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CD75 CMP
    cpu.compareA(0xFFFFu);
    goto L_80CD78;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD75u,0x80CD75u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CD78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD78u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD78u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CD78 BEQ -> $80CD7F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80CD7F; }
    goto L_80CD7A;
L_80CD7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD7Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD7Au, 6u, 3u, cpu.address("abs", 0xCD8Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80CD7A JSR -> $80CD8D stack real
    { cpu.push16Value(hw,0xCD7Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCD7Du,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCD8Du), 0x80CD7Au); }
    goto L_80CD7D;
L_80CD7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD7Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD7Du,0x80CD7Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD7Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD7Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CD7D BRA -> $80CD6D
    goto L_80CD6D;
L_80CD7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD7Fu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD7Fu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CD7F DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_80CD81;
L_80CD81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD81u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD81u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CD81 BNE -> $80CD6D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80CD6D; }
    goto L_80CD83;
L_80CD83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD83u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD83u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CD83 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80CD85;
L_80CD85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD85u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD85u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CD85 LDA
    cpu.setA(0xFFFFu, 16);
    goto L_80CD88;
L_80CD88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD88u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD88u, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CD88 STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80CD8C;
L_80CD8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD8Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD8Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80CD8C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80CD8Cu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80CD8Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80CF26_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80CF26u: goto L_80CF26;
    case 0x80CF29u: goto L_80CF29;
    case 0x80CF2Bu: goto L_80CF2B;
    case 0x80CF2Eu: goto L_80CF2E;
    case 0x80CF30u: goto L_80CF30;
    case 0x80CF32u: goto L_80CF32;
    case 0x80CF35u: goto L_80CF35;
    case 0x80CF37u: goto L_80CF37;
    case 0x80CF3Au: goto L_80CF3A;
    case 0x80CF3Cu: goto L_80CF3C;
    case 0x80CF40u: goto L_80CF40;
    case 0x80CF42u: goto L_80CF42;
    case 0x80CF43u: goto L_80CF43;
    case 0x80CF44u: goto L_80CF44;
    case 0x80CF47u: goto L_80CF47;
    case 0x80CF49u: goto L_80CF49;
    case 0x80CF4Bu: goto L_80CF4B;
    case 0x80CF4Fu: goto L_80CF4F;
    case 0x80CF52u: goto L_80CF52;
    case 0x80CF54u: goto L_80CF54;
    case 0x80CF56u: goto L_80CF56;
    case 0x80CF57u: goto L_80CF57;
    case 0x80CF59u: goto L_80CF59;
    case 0x80CF5Au: goto L_80CF5A;
    case 0x80CF5Du: goto L_80CF5D;
    case 0x80CF60u: goto L_80CF60;
    case 0x80CF64u: goto L_80CF64;
    case 0x80CF66u: goto L_80CF66;
    case 0x80CF6Au: goto L_80CF6A;
    case 0x80CF6Du: goto L_80CF6D;
    case 0x80CF71u: goto L_80CF71;
    case 0x80CF73u: goto L_80CF73;
    case 0x80CF74u: goto L_80CF74;
    case 0x80CF77u: goto L_80CF77;
    case 0x80CF79u: goto L_80CF79;
    case 0x80CF7Au: goto L_80CF7A;
    case 0x80CF7Du: goto L_80CF7D;
    case 0x80CF7Fu: goto L_80CF7F;
    case 0x80CF83u: goto L_80CF83;
    case 0x80CF85u: goto L_80CF85;
    case 0x80CF88u: goto L_80CF88;
    case 0x80CF8Au: goto L_80CF8A;
    case 0x80CF8Eu: goto L_80CF8E;
    case 0x80CF90u: goto L_80CF90;
    case 0x80CF94u: goto L_80CF94;
    case 0x80CF97u: goto L_80CF97;
    case 0x80CF99u: goto L_80CF99;
    case 0x80CF9Au: goto L_80CF9A;
    case 0x80CF9Bu: goto L_80CF9B;
    case 0x80CF9Eu: goto L_80CF9E;
    case 0x80CFA0u: goto L_80CFA0;
    case 0x80CFA4u: goto L_80CFA4;
    case 0x80CFA6u: goto L_80CFA6;
    case 0x80CFAAu: goto L_80CFAA;
    case 0x80CFADu: goto L_80CFAD;
    case 0x80CFB1u: goto L_80CFB1;
    case 0x80CFB3u: goto L_80CFB3;
    case 0x80CFB5u: goto L_80CFB5;
    case 0x80CFB7u: goto L_80CFB7;
    case 0x80CFB9u: goto L_80CFB9;
    case 0x80CFBBu: goto L_80CFBB;
    case 0x80CFBDu: goto L_80CFBD;
    case 0x80CFBFu: goto L_80CFBF;
    case 0x80CFC2u: goto L_80CFC2;
    case 0x80CFC4u: goto L_80CFC4;
    case 0x80CFC6u: goto L_80CFC6;
    case 0x80CFC8u: goto L_80CFC8;
    case 0x80CFCAu: goto L_80CFCA;
    case 0x80CFCBu: goto L_80CFCB;
    case 0x80CFCEu: goto L_80CFCE;
    case 0x80CFD0u: goto L_80CFD0;
    case 0x80CFD1u: goto L_80CFD1;
    case 0x80CFD4u: goto L_80CFD4;
    case 0x80CFD6u: goto L_80CFD6;
    case 0x80CFD7u: goto L_80CFD7;
    case 0x80CFD8u: goto L_80CFD8;
    case 0x80CFDCu: goto L_80CFDC;
    case 0x80CFDEu: goto L_80CFDE;
    case 0x80CFE1u: goto L_80CFE1;
    case 0x80CFE3u: goto L_80CFE3;
    case 0x80CFE7u: goto L_80CFE7;
    case 0x80CFE9u: goto L_80CFE9;
    case 0x80CFECu: goto L_80CFEC;
    case 0x80CFEEu: goto L_80CFEE;
    case 0x80CFEFu: goto L_80CFEF;
    case 0x80CFF0u: goto L_80CFF0;
    case 0x80CFF4u: goto L_80CFF4;
    case 0x80CFF6u: goto L_80CFF6;
    case 0x80CFF9u: goto L_80CFF9;
    case 0x80CFFBu: goto L_80CFFB;
    case 0x80CFFFu: goto L_80CFFF;
    case 0x80D001u: goto L_80D001;
    case 0x80D004u: goto L_80D004;
    case 0x80D006u: goto L_80D006;
    case 0x80D008u: goto L_80D008;
    case 0x80D00Au: goto L_80D00A;
    case 0x80D00Du: goto L_80D00D;
    case 0x80D011u: goto L_80D011;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80CF26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF26u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF26u, 5u, 3u, cpu.address("abs", 0x098Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF26 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x98Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80CF29;
L_80CF29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF29u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF29u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF29 STX
    hw.write(cpu.address("dp", 0x61u), cpu.x, cpu.x8?8:16);
    goto L_80CF2B;
L_80CF2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF2Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF2Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF2B LDA
    cpu.setA(0x6u, 16);
    goto L_80CF2E;
L_80CF2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF2Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF2Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF2E STA
    hw.write(cpu.address("dp", 0x63u), cpu.a, cpu.m8?8:16);
    goto L_80CF30;
L_80CF30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF30u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF30u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF30u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF30 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80CF32;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF30u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF30u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF30 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80CF32;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCF30u,0x80CF30u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CF32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF32u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF32u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF32u, 6u, 3u, cpu.address("abs", 0xD012u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80CF32 JSR -> $80D012 stack real
    { cpu.push16Value(hw,0xCF34u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCF35u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD012u), 0x80CF32u); }
    goto L_80CF35;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF32u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF32u, 6u, 3u, cpu.address("abs", 0xD012u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80CF32 JSR -> $80D012 stack real
    { cpu.push16Value(hw,0xCF34u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCF35u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD012u), 0x80CF32u); }
    goto L_80CF35;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCF32u,0x80CF32u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CF35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF35u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF35u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF35u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF35 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80CF37;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF35u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF35u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF35 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80CF37;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCF35u,0x80CF35u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CF37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF37u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF37u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF37u, 6u, 3u, cpu.address("abs", 0xD04Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80CF37 JSR -> $80D04D stack real
    { cpu.push16Value(hw,0xCF39u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCF3Au,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD04Du), 0x80CF37u); }
    goto L_80CF3A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF37u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF37u, 6u, 3u, cpu.address("abs", 0xD04Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80CF37 JSR -> $80D04D stack real
    { cpu.push16Value(hw,0xCF39u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCF3Au,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD04Du), 0x80CF37u); }
    goto L_80CF3A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCF37u,0x80CF37u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CF3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF3Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF3Au,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF3Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF3A LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80CF3C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF3Au,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF3Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF3A LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80CF3C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCF3Au,0x80CF3Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CF3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF3Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF3Cu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF3Cu, 6u, 4u, ((0x7E1FEAu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF3C LDA
    cpu.loadA(hw.readW(((0x7E1FEAu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CF40;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF3Cu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF3Cu, 6u, 4u, ((0x7E1FEAu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF3C LDA
    cpu.loadA(hw.readW(((0x7E1FEAu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CF40;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCF3Cu,0x80CF3Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CF40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF40u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF40u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF40u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF40 BEQ -> $80CF4B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80CF4B; }
    goto L_80CF42;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF40u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF40u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF40 BEQ -> $80CF4B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80CF4B; }
    goto L_80CF42;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCF40u,0x80CF40u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CF42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF42u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF42u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF42u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF42 TXA
    cpu.transfer("TXA");
    goto L_80CF43;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF42u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF42u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF42 TXA
    cpu.transfer("TXA");
    goto L_80CF43;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCF42u,0x80CF42u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CF43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF43u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF43u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF43u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF43 SEC
    cpu.setFlag('C', true);
    goto L_80CF44;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF43u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF43u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF43 SEC
    cpu.setFlag('C', true);
    goto L_80CF44;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCF43u,0x80CF43u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CF44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF44u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF44u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF44 SBC
    cpu.sbc(0x16u);
    goto L_80CF47;
L_80CF47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF47u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF47u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF47 STA
    hw.write(cpu.address("dp", 0x61u), cpu.a, cpu.m8?8:16);
    goto L_80CF49;
L_80CF49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF49u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF49u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF49 BRA -> $80CF30
    goto L_80CF30;
L_80CF4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF4Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF4Bu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF4Bu, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF4B LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CF4F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF4Bu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF4Bu, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF4B LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CF4F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCF4Bu,0x80CF4Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CF4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF4Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF4Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF4Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF4F AND
    cpu.logicAnd(0x300u);
    goto L_80CF52;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF4Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF4Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF4F AND
    cpu.logicAnd(0x300u);
    goto L_80CF52;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCF4Fu,0x80CF4Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CF52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF52u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF52u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF52u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF52 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80CF54;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF52u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF52u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF52 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80CF54;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCF52u,0x80CF52u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CF54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF54u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF54u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF54u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF54 STX
    hw.write(cpu.address("dp", 0x61u), cpu.x, cpu.x8?8:16);
    goto L_80CF56;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF54u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF54u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF54 STX
    hw.write(cpu.address("dp", 0x61u), cpu.x, cpu.x8?8:16);
    goto L_80CF56;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCF54u,0x80CF54u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CF56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF56u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF56u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF56u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF56 TXA
    cpu.transfer("TXA");
    goto L_80CF57;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF56u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF56u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF56 TXA
    cpu.transfer("TXA");
    goto L_80CF57;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCF56u,0x80CF56u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CF57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF57u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF57u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF57u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF57 STA
    hw.write(cpu.address("dp", 0x65u), cpu.a, cpu.m8?8:16);
    goto L_80CF59;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF57u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF57u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF57 STA
    hw.write(cpu.address("dp", 0x65u), cpu.a, cpu.m8?8:16);
    goto L_80CF59;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCF57u,0x80CF57u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CF59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF59u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF59u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF59u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF59 SEC
    cpu.setFlag('C', true);
    goto L_80CF5A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF59u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF59u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF59 SEC
    cpu.setFlag('C', true);
    goto L_80CF5A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCF59u,0x80CF59u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80CF5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF5Au,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF5Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF5A SBC
    cpu.sbc(0x16u);
    goto L_80CF5D;
L_80CF5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF5Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF5Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF5D LDX
    cpu.setX(0x0u, 16);
    goto L_80CF60;
L_80CF60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF60u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF60u, 6u, 4u, ((0x7E2444u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF60 STA
    hw.write(((0x7E2444u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80CF64;
L_80CF64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF64u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF64u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF64 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CF66;
L_80CF66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF66u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF66u, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF66 STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80CF6A;
L_80CF6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF6Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF6Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF6A LDA
    cpu.setA(0x4u, 16);
    goto L_80CF6D;
L_80CF6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF6Du,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF6Du, 6u, 4u, ((0x7E2442u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF6D STA
    hw.write(((0x7E2442u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80CF71;
L_80CF71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF71u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF71u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF71 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x61u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CF73;
L_80CF73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF73u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF73u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF73 SEC
    cpu.setFlag('C', true);
    goto L_80CF74;
L_80CF74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF74u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF74u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF74 SBC
    cpu.sbc(0x16u);
    goto L_80CF77;
L_80CF77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF77u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF77u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF77 STA
    hw.write(cpu.address("dp", 0x61u), cpu.a, cpu.m8?8:16);
    goto L_80CF79;
L_80CF79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF79u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF79u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF79 TAX
    cpu.transfer("TAX");
    goto L_80CF7A;
L_80CF7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Au,cpu,0xECu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Au, 5u, 3u, cpu.address("abs", 0x096Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF7A CPX
    cpu.compareX(hw.readW(cpu.address("abs", 0x96Eu), cpu.x8?8:16));
    goto L_80CF7D;
L_80CF7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Du,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF7D BCC -> $80CFBF
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80CFBF; }
    goto L_80CF7F;
L_80CF7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Fu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF7Fu, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF7F LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CF83;
L_80CF83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF83u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF83u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF83 BEQ -> $80CF71
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80CF71; }
    goto L_80CF85;
L_80CF85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF85u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF85u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF85 CMP
    cpu.compareA(0xFFFFu);
    goto L_80CF88;
L_80CF88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF88u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF88u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF88 BEQ -> $80CFBF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80CFBF; }
    goto L_80CF8A;
L_80CF8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF8Au,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF8Au, 6u, 4u, ((0x7E1FEAu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF8A LDA
    cpu.loadA(hw.readW(((0x7E1FEAu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CF8E;
L_80CF8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF8Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF8Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF8E BNE -> $80CF71
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80CF71; }
    goto L_80CF90;
L_80CF90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF90u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF90u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF90 LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CF94;
L_80CF94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF94u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF94u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF94 AND
    cpu.logicAnd(0x300u);
    goto L_80CF97;
L_80CF97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF97u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF97u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF97 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80CF99;
L_80CF99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF99u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF99u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF99 TXA
    cpu.transfer("TXA");
    goto L_80CF9A;
L_80CF9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF9Au,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF9Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF9A SEC
    cpu.setFlag('C', true);
    goto L_80CF9B;
L_80CF9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF9Bu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF9Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF9B SBC
    cpu.sbc(0x16u);
    goto L_80CF9E;
L_80CF9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF9Eu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF9Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CF9E LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80CFA0;
L_80CFA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA0u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA0u, 6u, 4u, ((0x7E2444u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CFA0 STA
    hw.write(((0x7E2444u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80CFA4;
L_80CFA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CFA4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CFA6;
L_80CFA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA6u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA6u, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CFA6 STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80CFAA;
L_80CFAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFAAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFAAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CFAA LDA
    cpu.setA(0x4u, 16);
    goto L_80CFAD;
L_80CFAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFADu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFADu, 6u, 4u, ((0x7E2442u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CFAD STA
    hw.write(((0x7E2442u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80CFB1;
L_80CFB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB1u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB1u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CFB1 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80CFB3;
L_80CFB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB3u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB3u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CFB3 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80CFB5;
L_80CFB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB5u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB5u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CFB5 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80CFB7;
L_80CFB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB7u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB7u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CFB7 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80CFB9;
L_80CFB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB9u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB9u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CFB9 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80CFBB;
L_80CFBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFBBu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFBBu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CFBB INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_80CFBD;
L_80CFBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFBDu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFBDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CFBD BRA -> $80CF71
    goto L_80CF71;
L_80CFBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFBFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFBFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CFBF LDA
    cpu.setA(0x8u, 16);
    goto L_80CFC2;
L_80CFC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CFC2 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80CFC4;
L_80CFC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC4u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CFC4 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x65u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80CFC6;
L_80CFC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC6u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CFC6 STX
    hw.write(cpu.address("dp", 0x61u), cpu.x, cpu.x8?8:16);
    goto L_80CFC8;
L_80CFC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CFC8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x61u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CFCA;
L_80CFCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFCAu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFCAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CFCA SEC
    cpu.setFlag('C', true);
    goto L_80CFCB;
L_80CFCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFCBu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFCBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CFCB SBC
    cpu.sbc(0x16u);
    goto L_80CFCE;
L_80CFCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFCEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFCEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CFCE STA
    hw.write(cpu.address("dp", 0x61u), cpu.a, cpu.m8?8:16);
    goto L_80CFD0;
L_80CFD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD0u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CFD0 TAX
    cpu.transfer("TAX");
    goto L_80CFD1;
L_80CFD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD1u,cpu,0xECu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD1u, 5u, 3u, cpu.address("abs", 0x096Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CFD1 CPX
    cpu.compareX(hw.readW(cpu.address("abs", 0x96Eu), cpu.x8?8:16));
    goto L_80CFD4;
L_80CFD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD4u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CFD4 BCC -> $80D008
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80D008; }
    goto L_80CFD6;
L_80CFD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD6u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CFD6 DEX
    cpu.decReg('X');
    goto L_80CFD7;
L_80CFD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD7u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CFD7 DEX
    cpu.decReg('X');
    goto L_80CFD8;
L_80CFD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD8u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD8u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CFD8 LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CFDC;
L_80CFDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFDCu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFDCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CFDC BEQ -> $80CFD6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80CFD6; }
    goto L_80CFDE;
L_80CFDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFDEu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFDEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CFDE CMP
    cpu.compareA(0xFFFFu);
    goto L_80CFE1;
L_80CFE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFE1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFE1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CFE1 BEQ -> $80CFEC
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80CFEC; }
    goto L_80CFE3;
L_80CFE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFE3u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFE3u, 6u, 4u, ((0x7E1FEAu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CFE3 LDA
    cpu.loadA(hw.readW(((0x7E1FEAu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CFE7;
L_80CFE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFE7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFE7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CFE7 BEQ -> $80CFD6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80CFD6; }
    goto L_80CFE9;
L_80CFE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFE9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFE9u, 6u, 3u, cpu.address("abs", 0xD04Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80CFE9 JSR -> $80D04D stack real
    { cpu.push16Value(hw,0xCFEBu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCFECu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD04Du), 0x80CFE9u); }
    goto L_80CFEC;
L_80CFEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFECu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCFECu,0x80CFECu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFECu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFECu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CFEC LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80CFEE;
L_80CFEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFEEu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFEEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CFEE INX
    cpu.inc('X');
    goto L_80CFEF;
L_80CFEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFEFu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFEFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CFEF INX
    cpu.inc('X');
    goto L_80CFF0;
L_80CFF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF0u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF0u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CFF0 LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CFF4;
L_80CFF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CFF4 BEQ -> $80CFEE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80CFEE; }
    goto L_80CFF6;
L_80CFF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CFF6 CMP
    cpu.compareA(0xFFFFu);
    goto L_80CFF9;
L_80CFF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CFF9 BEQ -> $80D004
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D004; }
    goto L_80CFFB;
L_80CFFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFFBu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFFBu, 6u, 4u, ((0x7E1FEAu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CFFB LDA
    cpu.loadA(hw.readW(((0x7E1FEAu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80CFFF;
L_80CFFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFFFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFFFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80CFFF BEQ -> $80CFEE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80CFEE; }
    goto L_80D001;
L_80D001:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD001u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD001u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD001u, 6u, 3u, cpu.address("abs", 0xD012u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D001 JSR -> $80D012 stack real
    { cpu.push16Value(hw,0xD003u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD004u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD012u), 0x80D001u); }
    goto L_80D004;
L_80D004:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD004u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD004u,0x80D004u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD004u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD004u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D004 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_80D006;
L_80D006:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD006u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD006u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD006u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D006 BPL -> $80CFC8
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80CFC8; }
    goto L_80D008;
L_80D008:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD008u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD008u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD008u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D008 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D00A;
L_80D00A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD00Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD00Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD00Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D00A LDA
    cpu.setA(0xFFFFu, 16);
    goto L_80D00D;
L_80D00D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD00Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD00Du,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD00Du, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D00D STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D011;
L_80D011:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD011u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD011u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD011u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D011 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80D011u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80D011u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82AFB1_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82AFB1u: goto L_82AFB1;
    case 0x82AFB4u: goto L_82AFB4;
    case 0x82AFB7u: goto L_82AFB7;
    case 0x82AFB9u: goto L_82AFB9;
    case 0x82AFBCu: goto L_82AFBC;
    case 0x82AFBFu: goto L_82AFBF;
    case 0x82AFC2u: goto L_82AFC2;
    case 0x82AFC4u: goto L_82AFC4;
    case 0x82AFC7u: goto L_82AFC7;
    case 0x82AFCAu: goto L_82AFCA;
    case 0x82AFCDu: goto L_82AFCD;
    case 0x82AFCFu: goto L_82AFCF;
    case 0x82AFD1u: goto L_82AFD1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82AFB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB1u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB1u, 8u, 3u, cpu.address("abs", 0x014Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFB1 INC
    cpu.incMem(hw, cpu.address("abs", 0x14Au), cpu.m8?8:16);
    goto L_82AFB4;
L_82AFB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB4u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFB4 LDX
    cpu.setX(0x0u, 16);
    goto L_82AFB7;
L_82AFB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB7u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFB7 STX
    hw.write(cpu.address("dp", 0x5Bu), cpu.x, cpu.x8?8:16);
    goto L_82AFB9;
L_82AFB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB9u, 6u, 3u, cpu.address("abs", 0xBD2Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AFB9 JSR -> $82BD2B stack real
    { cpu.push16Value(hw,0xAFBBu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAFBCu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBD2Bu), 0x82AFB9u); }
    goto L_82AFBC;
L_82AFBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFBCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAFBCu,0x82AFBCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFBCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFBCu, 6u, 3u, cpu.address("abs", 0xA84Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AFBC JSR -> $82A84E stack real
    { cpu.push16Value(hw,0xAFBEu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAFBFu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA84Eu), 0x82AFBCu); }
    goto L_82AFBF;
L_82AFBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFBFu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAFBFu,0x82AFBFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFBFu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFBFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFBF LDX
    cpu.setX(0x100u, 16);
    goto L_82AFC2;
L_82AFC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC2u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFC2 STX
    hw.write(cpu.address("dp", 0x5Bu), cpu.x, cpu.x8?8:16);
    goto L_82AFC4;
L_82AFC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC4u, 6u, 3u, cpu.address("abs", 0xBD2Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AFC4 JSR -> $82BD2B stack real
    { cpu.push16Value(hw,0xAFC6u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAFC7u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBD2Bu), 0x82AFC4u); }
    goto L_82AFC7;
L_82AFC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFC7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAFC7u,0x82AFC7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC7u, 6u, 3u, cpu.address("abs", 0xA84Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AFC7 JSR -> $82A84E stack real
    { cpu.push16Value(hw,0xAFC9u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAFCAu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA84Eu), 0x82AFC7u); }
    goto L_82AFCA;
L_82AFCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFCAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAFCAu,0x82AFCAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFCAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFCAu, 6u, 3u, cpu.address("abs", 0xBDADu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AFCA JSR -> $82BDAD stack real
    { cpu.push16Value(hw,0xAFCCu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAFCDu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBDADu), 0x82AFCAu); }
    goto L_82AFCD;
L_82AFCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFCDu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAFCDu,0x82AFCDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFCDu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFCDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFCD SEP
    cpu.sep(0x20u);
    goto L_82AFCF;
L_82AFCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFCFu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFCFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFCF INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_82AFD1;
L_82AFD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AFD1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82AFD1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82AFD1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82AFB1_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82AFB1u: goto L_82AFB1;
    case 0x82AFB4u: goto L_82AFB4;
    case 0x82AFB7u: goto L_82AFB7;
    case 0x82AFB9u: goto L_82AFB9;
    case 0x82AFBCu: goto L_82AFBC;
    case 0x82AFBFu: goto L_82AFBF;
    case 0x82AFC2u: goto L_82AFC2;
    case 0x82AFC4u: goto L_82AFC4;
    case 0x82AFC7u: goto L_82AFC7;
    case 0x82AFCAu: goto L_82AFCA;
    case 0x82AFCDu: goto L_82AFCD;
    case 0x82AFCFu: goto L_82AFCF;
    case 0x82AFD1u: goto L_82AFD1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82AFB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB1u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB1u, 8u, 3u, cpu.address("abs", 0x014Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFB1 INC
    cpu.incMem(hw, cpu.address("abs", 0x14Au), cpu.m8?8:16);
    goto L_82AFB4;
L_82AFB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB4u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFB4 LDX
    cpu.setX(0x0u, 16);
    goto L_82AFB7;
L_82AFB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB7u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFB7 STX
    hw.write(cpu.address("dp", 0x5Bu), cpu.x, cpu.x8?8:16);
    goto L_82AFB9;
L_82AFB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFB9u, 6u, 3u, cpu.address("abs", 0xBD2Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AFB9 JSR -> $82BD2B stack real
    { cpu.push16Value(hw,0xAFBBu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAFBCu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBD2Bu), 0x82AFB9u); }
    goto L_82AFBC;
L_82AFBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFBCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAFBCu,0x82AFBCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFBCu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFBCu, 6u, 3u, cpu.address("abs", 0xA84Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AFBC JSR -> $82A84E stack real
    { cpu.push16Value(hw,0xAFBEu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAFBFu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA84Eu), 0x82AFBCu); }
    goto L_82AFBF;
L_82AFBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFBFu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAFBFu,0x82AFBFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFBFu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFBFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFBF LDX
    cpu.setX(0x100u, 16);
    goto L_82AFC2;
L_82AFC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC2u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFC2 STX
    hw.write(cpu.address("dp", 0x5Bu), cpu.x, cpu.x8?8:16);
    goto L_82AFC4;
L_82AFC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC4u, 6u, 3u, cpu.address("abs", 0xBD2Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AFC4 JSR -> $82BD2B stack real
    { cpu.push16Value(hw,0xAFC6u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAFC7u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBD2Bu), 0x82AFC4u); }
    goto L_82AFC7;
L_82AFC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFC7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAFC7u,0x82AFC7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFC7u, 6u, 3u, cpu.address("abs", 0xA84Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AFC7 JSR -> $82A84E stack real
    { cpu.push16Value(hw,0xAFC9u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAFCAu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA84Eu), 0x82AFC7u); }
    goto L_82AFCA;
L_82AFCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFCAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAFCAu,0x82AFCAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFCAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFCAu, 6u, 3u, cpu.address("abs", 0xBDADu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AFCA JSR -> $82BDAD stack real
    { cpu.push16Value(hw,0xAFCCu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAFCDu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBDADu), 0x82AFCAu); }
    goto L_82AFCD;
L_82AFCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFCDu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAFCDu,0x82AFCDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFCDu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFCDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFCD SEP
    cpu.sep(0x20u);
    goto L_82AFCF;
L_82AFCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFCFu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFCFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AFCF INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_82AFD1;
L_82AFD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAFD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAFD1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82AFD1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82AFD1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82AFD1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B559_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B559u: goto L_82B559;
    case 0x82B55Bu: goto L_82B55B;
    case 0x82B55Du: goto L_82B55D;
    case 0x82B55Fu: goto L_82B55F;
    case 0x82B560u: goto L_82B560;
    case 0x82B562u: goto L_82B562;
    case 0x82B564u: goto L_82B564;
    case 0x82B566u: goto L_82B566;
    case 0x82B568u: goto L_82B568;
    case 0x82B56Au: goto L_82B56A;
    case 0x82B56Bu: goto L_82B56B;
    case 0x82B56Du: goto L_82B56D;
    case 0x82B56Fu: goto L_82B56F;
    case 0x82B571u: goto L_82B571;
    case 0x82B574u: goto L_82B574;
    case 0x82B576u: goto L_82B576;
    case 0x82B579u: goto L_82B579;
    case 0x82B57Cu: goto L_82B57C;
    case 0x82B57Eu: goto L_82B57E;
    case 0x82B580u: goto L_82B580;
    case 0x82B582u: goto L_82B582;
    case 0x82B585u: goto L_82B585;
    case 0x82B588u: goto L_82B588;
    case 0x82B58Au: goto L_82B58A;
    case 0x82B58Cu: goto L_82B58C;
    case 0x82B58Fu: goto L_82B58F;
    case 0x82B592u: goto L_82B592;
    case 0x82B595u: goto L_82B595;
    case 0x82B597u: goto L_82B597;
    case 0x82B599u: goto L_82B599;
    case 0x82B59Cu: goto L_82B59C;
    case 0x82B59Fu: goto L_82B59F;
    case 0x82B5A1u: goto L_82B5A1;
    case 0x82B5A3u: goto L_82B5A3;
    case 0x82B5A6u: goto L_82B5A6;
    case 0x82B5A9u: goto L_82B5A9;
    case 0x82B5ACu: goto L_82B5AC;
    case 0x82B5AEu: goto L_82B5AE;
    case 0x82B5B0u: goto L_82B5B0;
    case 0x82B5B2u: goto L_82B5B2;
    case 0x82B5B5u: goto L_82B5B5;
    case 0x82B5B8u: goto L_82B5B8;
    case 0x82B5BAu: goto L_82B5BA;
    case 0x82B5BCu: goto L_82B5BC;
    case 0x82B5BFu: goto L_82B5BF;
    case 0x82B5C2u: goto L_82B5C2;
    case 0x82B5C3u: goto L_82B5C3;
    case 0x82B5C5u: goto L_82B5C5;
    case 0x82B5C7u: goto L_82B5C7;
    case 0x82B5CAu: goto L_82B5CA;
    case 0x82B5CDu: goto L_82B5CD;
    case 0x82B5CFu: goto L_82B5CF;
    case 0x82B5D1u: goto L_82B5D1;
    case 0x82B5D4u: goto L_82B5D4;
    case 0x82B5D7u: goto L_82B5D7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B559:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB559u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB559u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB559u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B559 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x3u), cpu.m8?8:16);
    goto L_82B55B;
L_82B55B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB55Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB55Bu,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB55Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B55B ROR
    cpu.rorMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_82B55D;
L_82B55D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB55Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB55Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB55Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B55D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B55F;
L_82B55F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB55Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB55Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB55Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B55F CLC
    cpu.setFlag('C', false);
    goto L_82B560;
L_82B560:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB560u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB560u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB560u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B560 ADC
    cpu.adc(0x4u);
    goto L_82B562;
L_82B562:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB562u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB562u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB562u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B562 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82B564;
L_82B564:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB564u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB564u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB564u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x05u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B564 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x5u), cpu.m8?8:16);
    goto L_82B566;
L_82B566:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB566u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB566u,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB566u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B566 ROR
    cpu.rorMem(hw, cpu.address("dp", 0x4u), cpu.m8?8:16);
    goto L_82B568;
L_82B568:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB568u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB568u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB568u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B568 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B56A;
L_82B56A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB56Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB56Au,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB56Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B56A CLC
    cpu.setFlag('C', false);
    goto L_82B56B;
L_82B56B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB56Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB56Bu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB56Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B56B ADC
    cpu.adc(0x4u);
    goto L_82B56D;
L_82B56D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB56Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB56Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB56Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B56D STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_82B56F;
L_82B56F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB56Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB56Fu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB56Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B56F LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x10u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B571;
L_82B571:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB571u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB571u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB571u, 6u, 3u, cpu.address("abs", 0xB6BEu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B571 JSR -> $82B6BE stack real
    { cpu.push16Value(hw,0xB573u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB574u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB6BEu), 0x82B571u); }
    goto L_82B574;
L_82B574:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB574u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB574u,0x82B574u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB574u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB574u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B574 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x14u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B576;
L_82B576:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB576u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB576u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB576u, 6u, 3u, cpu.address("abs", 0xB6BEu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B576 JSR -> $82B6BE stack real
    { cpu.push16Value(hw,0xB578u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB579u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB6BEu), 0x82B576u); }
    goto L_82B579;
L_82B579:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB579u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB579u,0x82B579u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB579u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB579u, 6u, 3u, cpu.address("abs", 0xB6C9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B579 JSR -> $82B6C9 stack real
    { cpu.push16Value(hw,0xB57Bu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB57Cu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB6C9u), 0x82B579u); }
    goto L_82B57C;
L_82B57C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB57Cu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B57C BCS -> $82B595
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82B595; }
    goto L_82B57E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B57C BCS -> $82B595
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82B595; }
    goto L_82B57E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B57C BCS -> $82B595
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82B595; }
    goto L_82B57E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB57Cu,0x82B57Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B57E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB57Eu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Eu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B57E LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x12u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B580;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Eu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B57E LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x12u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B580;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Eu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B57E LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x12u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B580;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB57Eu,0x82B57Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B580:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB580u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB580u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB580u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B580 LDA
    cpu.setA(0xF8u, 8);
    goto L_82B582;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB580u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB580u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B580 LDA
    cpu.setA(0xF8u, 8);
    goto L_82B582;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB580u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB580u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B580 LDA
    cpu.setA(0xF8u, 8);
    goto L_82B582;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB580u,0x82B580u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B582:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB582u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB582u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB582u, 5u, 3u, cpu.address("absy", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B582 STA
    hw.write(cpu.address("absy", 0x20Au), cpu.a, cpu.m8?8:16);
    goto L_82B585;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB582u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB582u, 5u, 3u, cpu.address("absy", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B582 STA
    hw.write(cpu.address("absy", 0x20Au), cpu.a, cpu.m8?8:16);
    goto L_82B585;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB582u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB582u, 5u, 3u, cpu.address("absy", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B582 STA
    hw.write(cpu.address("absy", 0x20Au), cpu.a, cpu.m8?8:16);
    goto L_82B585;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB582u,0x82B582u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B585:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB585u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB585u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB585u, 5u, 3u, cpu.address("absy", 0x0226u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B585 STA
    hw.write(cpu.address("absy", 0x226u), cpu.a, cpu.m8?8:16);
    goto L_82B588;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB585u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB585u, 5u, 3u, cpu.address("absy", 0x0226u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B585 STA
    hw.write(cpu.address("absy", 0x226u), cpu.a, cpu.m8?8:16);
    goto L_82B588;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB585u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB585u, 5u, 3u, cpu.address("absy", 0x0226u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B585 STA
    hw.write(cpu.address("absy", 0x226u), cpu.a, cpu.m8?8:16);
    goto L_82B588;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB585u,0x82B585u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B588:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB588u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB588u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB588u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B588 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x16u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B58A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB588u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB588u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B588 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x16u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B58A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB588u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB588u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B588 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x16u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B58A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB588u,0x82B588u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B58A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB58Au))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B58A LDA
    cpu.setA(0x0u, 8);
    goto L_82B58C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B58A LDA
    cpu.setA(0x0u, 8);
    goto L_82B58C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B58A LDA
    cpu.setA(0x0u, 8);
    goto L_82B58C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB58Au,0x82B58Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B58C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB58Cu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Cu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Cu, 5u, 3u, cpu.address("absy", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B58C STA
    hw.write(cpu.address("absy", 0x20Au), cpu.a, cpu.m8?8:16);
    goto L_82B58F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Cu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Cu, 5u, 3u, cpu.address("absy", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B58C STA
    hw.write(cpu.address("absy", 0x20Au), cpu.a, cpu.m8?8:16);
    goto L_82B58F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Cu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Cu, 5u, 3u, cpu.address("absy", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B58C STA
    hw.write(cpu.address("absy", 0x20Au), cpu.a, cpu.m8?8:16);
    goto L_82B58F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB58Cu,0x82B58Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B58F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB58Fu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Fu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Fu, 5u, 3u, cpu.address("absy", 0x0226u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B58F STA
    hw.write(cpu.address("absy", 0x226u), cpu.a, cpu.m8?8:16);
    goto L_82B592;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Fu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Fu, 5u, 3u, cpu.address("absy", 0x0226u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B58F STA
    hw.write(cpu.address("absy", 0x226u), cpu.a, cpu.m8?8:16);
    goto L_82B592;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Fu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Fu, 5u, 3u, cpu.address("absy", 0x0226u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B58F STA
    hw.write(cpu.address("absy", 0x226u), cpu.a, cpu.m8?8:16);
    goto L_82B592;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB58Fu,0x82B58Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B592:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB592u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB592u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB592u, 3u, 3u, cpu.address("abs", 0xB5A9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B592 JMP -> $82B5A9
    goto L_82B5A9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB592u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB592u, 3u, 3u, cpu.address("abs", 0xB5A9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B592 JMP -> $82B5A9
    goto L_82B5A9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB592u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB592u, 3u, 3u, cpu.address("abs", 0xB5A9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B592 JMP -> $82B5A9
    goto L_82B5A9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB592u,0x82B592u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B595:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB595u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB595u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB595u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B595 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x12u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B597;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB595u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB595u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B595 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x12u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B597;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB595u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB595u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B595 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x12u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B597;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB595u,0x82B595u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B597:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB597u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB597u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB597u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B597 LDA
    cpu.setA(0x0u, 8);
    goto L_82B599;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB597u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB597u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B597 LDA
    cpu.setA(0x0u, 8);
    goto L_82B599;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB597u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB597u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B597 LDA
    cpu.setA(0x0u, 8);
    goto L_82B599;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB597u,0x82B597u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B599:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB599u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB599u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB599u, 5u, 3u, cpu.address("absy", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B599 STA
    hw.write(cpu.address("absy", 0x20Au), cpu.a, cpu.m8?8:16);
    goto L_82B59C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB599u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB599u, 5u, 3u, cpu.address("absy", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B599 STA
    hw.write(cpu.address("absy", 0x20Au), cpu.a, cpu.m8?8:16);
    goto L_82B59C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB599u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB599u, 5u, 3u, cpu.address("absy", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B599 STA
    hw.write(cpu.address("absy", 0x20Au), cpu.a, cpu.m8?8:16);
    goto L_82B59C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB599u,0x82B599u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B59C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB59Cu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB59Cu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB59Cu, 5u, 3u, cpu.address("absy", 0x0226u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B59C STA
    hw.write(cpu.address("absy", 0x226u), cpu.a, cpu.m8?8:16);
    goto L_82B59F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB59Cu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB59Cu, 5u, 3u, cpu.address("absy", 0x0226u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B59C STA
    hw.write(cpu.address("absy", 0x226u), cpu.a, cpu.m8?8:16);
    goto L_82B59F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB59Cu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB59Cu, 5u, 3u, cpu.address("absy", 0x0226u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B59C STA
    hw.write(cpu.address("absy", 0x226u), cpu.a, cpu.m8?8:16);
    goto L_82B59F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB59Cu,0x82B59Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B59F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB59Fu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB59Fu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB59Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B59F LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x16u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B5A1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB59Fu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB59Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B59F LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x16u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B5A1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB59Fu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB59Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B59F LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x16u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B5A1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB59Fu,0x82B59Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B5A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5A1u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5A1 LDA
    cpu.setA(0xF8u, 8);
    goto L_82B5A3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5A1 LDA
    cpu.setA(0xF8u, 8);
    goto L_82B5A3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5A1 LDA
    cpu.setA(0xF8u, 8);
    goto L_82B5A3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB5A1u,0x82B5A1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B5A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5A3u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A3u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A3u, 5u, 3u, cpu.address("absy", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5A3 STA
    hw.write(cpu.address("absy", 0x20Au), cpu.a, cpu.m8?8:16);
    goto L_82B5A6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A3u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A3u, 5u, 3u, cpu.address("absy", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5A3 STA
    hw.write(cpu.address("absy", 0x20Au), cpu.a, cpu.m8?8:16);
    goto L_82B5A6;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A3u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A3u, 5u, 3u, cpu.address("absy", 0x020Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5A3 STA
    hw.write(cpu.address("absy", 0x20Au), cpu.a, cpu.m8?8:16);
    goto L_82B5A6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB5A3u,0x82B5A3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B5A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5A6u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A6u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A6u, 5u, 3u, cpu.address("absy", 0x0226u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5A6 STA
    hw.write(cpu.address("absy", 0x226u), cpu.a, cpu.m8?8:16);
    goto L_82B5A9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A6u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A6u, 5u, 3u, cpu.address("absy", 0x0226u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5A6 STA
    hw.write(cpu.address("absy", 0x226u), cpu.a, cpu.m8?8:16);
    goto L_82B5A9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A6u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A6u, 5u, 3u, cpu.address("absy", 0x0226u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5A6 STA
    hw.write(cpu.address("absy", 0x226u), cpu.a, cpu.m8?8:16);
    goto L_82B5A9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB5A6u,0x82B5A6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B5A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5A9u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A9u, 6u, 3u, cpu.address("abs", 0xB6E0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B5A9 JSR -> $82B6E0 stack real
    { cpu.push16Value(hw,0xB5ABu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB5ACu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB6E0u), 0x82B5A9u); }
    goto L_82B5AC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A9u, 6u, 3u, cpu.address("abs", 0xB6E0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B5A9 JSR -> $82B6E0 stack real
    { cpu.push16Value(hw,0xB5ABu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB5ACu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB6E0u), 0x82B5A9u); }
    goto L_82B5AC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A9u, 6u, 3u, cpu.address("abs", 0xB6E0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B5A9 JSR -> $82B6E0 stack real
    { cpu.push16Value(hw,0xB5ABu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB5ACu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB6E0u), 0x82B5A9u); }
    goto L_82B5AC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB5A9u,0x82B5A9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B5AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5ACu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5ACu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5ACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5AC BCS -> $82B5C3
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82B5C3; }
    goto L_82B5AE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5ACu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5ACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5AC BCS -> $82B5C3
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82B5C3; }
    goto L_82B5AE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5ACu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5ACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5AC BCS -> $82B5C3
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82B5C3; }
    goto L_82B5AE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB5ACu,0x82B5ACu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B5AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5AEu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5AEu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5AEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5AE LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x12u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B5B0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5AEu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5AEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5AE LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x12u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B5B0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5AEu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5AEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5AE LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x12u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B5B0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB5AEu,0x82B5AEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B5B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5B0u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5B0 LDA
    cpu.setA(0xF8u, 8);
    goto L_82B5B2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5B0 LDA
    cpu.setA(0xF8u, 8);
    goto L_82B5B2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5B0 LDA
    cpu.setA(0xF8u, 8);
    goto L_82B5B2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB5B0u,0x82B5B0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B5B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5B2u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B2u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B2u, 5u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5B2 STA
    hw.write(cpu.address("absy", 0x20Bu), cpu.a, cpu.m8?8:16);
    goto L_82B5B5;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B2u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B2u, 5u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5B2 STA
    hw.write(cpu.address("absy", 0x20Bu), cpu.a, cpu.m8?8:16);
    goto L_82B5B5;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B2u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B2u, 5u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5B2 STA
    hw.write(cpu.address("absy", 0x20Bu), cpu.a, cpu.m8?8:16);
    goto L_82B5B5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB5B2u,0x82B5B2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B5B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5B5u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B5u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B5u, 5u, 3u, cpu.address("absy", 0x0227u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5B5 STA
    hw.write(cpu.address("absy", 0x227u), cpu.a, cpu.m8?8:16);
    goto L_82B5B8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B5u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B5u, 5u, 3u, cpu.address("absy", 0x0227u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5B5 STA
    hw.write(cpu.address("absy", 0x227u), cpu.a, cpu.m8?8:16);
    goto L_82B5B8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B5u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B5u, 5u, 3u, cpu.address("absy", 0x0227u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5B5 STA
    hw.write(cpu.address("absy", 0x227u), cpu.a, cpu.m8?8:16);
    goto L_82B5B8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB5B5u,0x82B5B5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B5B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5B8u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B8u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5B8 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x16u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B5BA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B8u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5B8 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x16u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B5BA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B8u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5B8 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x16u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B5BA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB5B8u,0x82B5B8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B5BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5BAu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5BA LDA
    cpu.setA(0x0u, 8);
    goto L_82B5BC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5BA LDA
    cpu.setA(0x0u, 8);
    goto L_82B5BC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5BA LDA
    cpu.setA(0x0u, 8);
    goto L_82B5BC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB5BAu,0x82B5BAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B5BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5BCu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BCu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BCu, 5u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5BC STA
    hw.write(cpu.address("absy", 0x20Bu), cpu.a, cpu.m8?8:16);
    goto L_82B5BF;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BCu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BCu, 5u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5BC STA
    hw.write(cpu.address("absy", 0x20Bu), cpu.a, cpu.m8?8:16);
    goto L_82B5BF;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BCu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BCu, 5u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5BC STA
    hw.write(cpu.address("absy", 0x20Bu), cpu.a, cpu.m8?8:16);
    goto L_82B5BF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB5BCu,0x82B5BCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B5BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5BFu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BFu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BFu, 5u, 3u, cpu.address("absy", 0x0227u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5BF STA
    hw.write(cpu.address("absy", 0x227u), cpu.a, cpu.m8?8:16);
    goto L_82B5C2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BFu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BFu, 5u, 3u, cpu.address("absy", 0x0227u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5BF STA
    hw.write(cpu.address("absy", 0x227u), cpu.a, cpu.m8?8:16);
    goto L_82B5C2;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BFu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BFu, 5u, 3u, cpu.address("absy", 0x0227u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5BF STA
    hw.write(cpu.address("absy", 0x227u), cpu.a, cpu.m8?8:16);
    goto L_82B5C2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB5BFu,0x82B5BFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B5C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C2u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B5C2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B5C2u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B5C2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B5C2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B5C2u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B5C2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B5C2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B5C2u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B5C2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB5C2u,0x82B5C2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B5C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C3u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C3u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5C3 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x12u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B5C5;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C3u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5C3 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x12u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B5C5;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C3u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5C3 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x12u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B5C5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB5C3u,0x82B5C3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B5C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C5u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5C5 LDA
    cpu.setA(0x0u, 8);
    goto L_82B5C7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5C5 LDA
    cpu.setA(0x0u, 8);
    goto L_82B5C7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5C5 LDA
    cpu.setA(0x0u, 8);
    goto L_82B5C7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB5C5u,0x82B5C5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B5C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C7u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C7u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C7u, 5u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5C7 STA
    hw.write(cpu.address("absy", 0x20Bu), cpu.a, cpu.m8?8:16);
    goto L_82B5CA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C7u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C7u, 5u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5C7 STA
    hw.write(cpu.address("absy", 0x20Bu), cpu.a, cpu.m8?8:16);
    goto L_82B5CA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C7u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C7u, 5u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5C7 STA
    hw.write(cpu.address("absy", 0x20Bu), cpu.a, cpu.m8?8:16);
    goto L_82B5CA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB5C7u,0x82B5C7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B5CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5CAu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CAu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CAu, 5u, 3u, cpu.address("absy", 0x0227u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5CA STA
    hw.write(cpu.address("absy", 0x227u), cpu.a, cpu.m8?8:16);
    goto L_82B5CD;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CAu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CAu, 5u, 3u, cpu.address("absy", 0x0227u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5CA STA
    hw.write(cpu.address("absy", 0x227u), cpu.a, cpu.m8?8:16);
    goto L_82B5CD;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CAu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CAu, 5u, 3u, cpu.address("absy", 0x0227u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5CA STA
    hw.write(cpu.address("absy", 0x227u), cpu.a, cpu.m8?8:16);
    goto L_82B5CD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB5CAu,0x82B5CAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B5CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5CDu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CDu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5CD LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x16u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B5CF;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CDu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5CD LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x16u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B5CF;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CDu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5CD LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x16u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B5CF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB5CDu,0x82B5CDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B5CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5CFu))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5CF LDA
    cpu.setA(0xF8u, 8);
    goto L_82B5D1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5CF LDA
    cpu.setA(0xF8u, 8);
    goto L_82B5D1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5CF LDA
    cpu.setA(0xF8u, 8);
    goto L_82B5D1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB5CFu,0x82B5CFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B5D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5D1u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D1u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D1u, 5u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5D1 STA
    hw.write(cpu.address("absy", 0x20Bu), cpu.a, cpu.m8?8:16);
    goto L_82B5D4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D1u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D1u, 5u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5D1 STA
    hw.write(cpu.address("absy", 0x20Bu), cpu.a, cpu.m8?8:16);
    goto L_82B5D4;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D1u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D1u, 5u, 3u, cpu.address("absy", 0x020Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5D1 STA
    hw.write(cpu.address("absy", 0x20Bu), cpu.a, cpu.m8?8:16);
    goto L_82B5D4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB5D1u,0x82B5D1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B5D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5D4u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D4u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D4u, 5u, 3u, cpu.address("absy", 0x0227u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5D4 STA
    hw.write(cpu.address("absy", 0x227u), cpu.a, cpu.m8?8:16);
    goto L_82B5D7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D4u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D4u, 5u, 3u, cpu.address("absy", 0x0227u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5D4 STA
    hw.write(cpu.address("absy", 0x227u), cpu.a, cpu.m8?8:16);
    goto L_82B5D7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D4u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D4u, 5u, 3u, cpu.address("absy", 0x0227u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B5D4 STA
    hw.write(cpu.address("absy", 0x227u), cpu.a, cpu.m8?8:16);
    goto L_82B5D7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB5D4u,0x82B5D4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B5D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5D7u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B5D7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B5D7u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B5D7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B5D7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B5D7u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B5D7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B5D7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B5D7u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B5D7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB5D7u,0x82B5D7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82B998_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B998u: goto L_82B998;
    case 0x82B999u: goto L_82B999;
    case 0x82B99Au: goto L_82B99A;
    case 0x82B99Cu: goto L_82B99C;
    case 0x82B99Fu: goto L_82B99F;
    case 0x82B9A1u: goto L_82B9A1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B998:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB998u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB998u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB998u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B998 DEY
    cpu.decReg('Y');
    goto L_82B999;
L_82B999:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB999u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB999u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB999u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B999 DEY
    cpu.decReg('Y');
    goto L_82B99A;
L_82B99A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB99Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Au,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Au, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82B99A LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B99C;
L_82B99C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB99Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B99C AND
    cpu.logicAnd(0xFFF7u);
    goto L_82B99F;
L_82B99F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB99Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Fu,cpu,0x91u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Fu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82B99F STA
    hw.write(cpu.addressDpIndirectY(hw, 0x67u), cpu.a, cpu.m8?8:16);
    goto L_82B9A1;
L_82B9A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B9A1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B9A1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B9A1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82BB68_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82BB68u: goto L_82BB68;
    case 0x82BB6Au: goto L_82BB6A;
    case 0x82BB6Cu: goto L_82BB6C;
    case 0x82BB6Eu: goto L_82BB6E;
    case 0x82BB70u: goto L_82BB70;
    case 0x82BB73u: goto L_82BB73;
    case 0x82BB76u: goto L_82BB76;
    case 0x82BB78u: goto L_82BB78;
    case 0x82BB7Bu: goto L_82BB7B;
    case 0x82BB7Du: goto L_82BB7D;
    case 0x82BB7Fu: goto L_82BB7F;
    case 0x82BB82u: goto L_82BB82;
    case 0x82BB84u: goto L_82BB84;
    case 0x82BB87u: goto L_82BB87;
    case 0x82BB89u: goto L_82BB89;
    case 0x82BB8Cu: goto L_82BB8C;
    case 0x82BB8Eu: goto L_82BB8E;
    case 0x82BB90u: goto L_82BB90;
    case 0x82BB91u: goto L_82BB91;
    case 0x82BB92u: goto L_82BB92;
    case 0x82BB94u: goto L_82BB94;
    case 0x82BB95u: goto L_82BB95;
    case 0x82BB97u: goto L_82BB97;
    case 0x82BB99u: goto L_82BB99;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82BB68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB68u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB68u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB68 STY
    hw.write(cpu.address("dp", 0x63u), cpu.y, cpu.x8?8:16);
    goto L_82BB6A;
L_82BB6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB6Au,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB6Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB6A LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x10u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82BB6C;
L_82BB6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB6Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB6Cu,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB6Cu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82BB6C LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BB6E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB6Cu,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB6Cu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82BB6C LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BB6E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB6Cu,0x82BB6Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82BB6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB6Eu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB6Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB6Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB6E STA
    hw.write(cpu.address("dp", 0x65u), cpu.a, cpu.m8?8:16);
    goto L_82BB70;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB6Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB6Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB6E STA
    hw.write(cpu.address("dp", 0x65u), cpu.a, cpu.m8?8:16);
    goto L_82BB70;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB6Eu,0x82BB6Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82BB70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB70u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB70u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB70u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB70 AND
    cpu.logicAnd(0xFu);
    goto L_82BB73;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB70u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB70u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB70 AND
    cpu.logicAnd(0xFu);
    goto L_82BB73;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB70u,0x82BB70u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82BB73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB73u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB73u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB73u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB73 CMP
    cpu.compareA(0xFu);
    goto L_82BB76;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB73u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB73u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB73 CMP
    cpu.compareA(0xFu);
    goto L_82BB76;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB73u,0x82BB73u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82BB76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB76u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB76u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB76 BNE -> $82BB7D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82BB7D; }
    goto L_82BB78;
L_82BB78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB78u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB78u, 9u, 3u, cpu.address("absx", 0x02F8u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB78 INC
    cpu.incMem(hw, cpu.address("absx", 0x2F8u), cpu.m8?8:16);
    goto L_82BB7B;
L_82BB7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB7Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB7Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB7B BRA -> $82BB8C
    goto L_82BB8C;
L_82BB7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB7Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB7Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB7D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x65u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BB7F;
L_82BB7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB7Fu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB7Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB7F BIT
    cpu.bit(0x2000u, true);
    goto L_82BB82;
L_82BB82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB82u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB82u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB82 BEQ -> $82BB89
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82BB89; }
    goto L_82BB84;
L_82BB84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB84u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB84u, 9u, 3u, cpu.address("absx", 0x02FAu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB84 INC
    cpu.incMem(hw, cpu.address("absx", 0x2FAu), cpu.m8?8:16);
    goto L_82BB87;
L_82BB87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB87u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB87u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB87 BRA -> $82BB8C
    goto L_82BB8C;
L_82BB89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB89u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB89u, 9u, 3u, cpu.address("absx", 0x02F4u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB89 INC
    cpu.incMem(hw, cpu.address("absx", 0x2F4u), cpu.m8?8:16);
    goto L_82BB8C;
L_82BB8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB8Cu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB8Cu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB8C DEC
    cpu.decMem(hw, cpu.address("dp", 0x12u), cpu.m8?8:16);
    goto L_82BB8E;
L_82BB8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB8Eu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB8Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB8E BMI -> $82BB97
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82BB97; }
    goto L_82BB90;
L_82BB90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB90u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB90u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB90 TYA
    cpu.transfer("TYA");
    goto L_82BB91;
L_82BB91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB91u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB91u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB91 SEC
    cpu.setFlag('C', true);
    goto L_82BB92;
L_82BB92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB92u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB92u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB92 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16));
    goto L_82BB94;
L_82BB94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB94u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB94u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB94 TAY
    cpu.transfer("TAY");
    goto L_82BB95;
L_82BB95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB95u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB95u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB95 BRA -> $82BB6C
    goto L_82BB6C;
L_82BB97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB97u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB97u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB97 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82BB99;
L_82BB99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB99u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB99u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82BB99 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82BB99u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82BB99u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82BB68_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82BB68u: goto L_82BB68;
    case 0x82BB6Au: goto L_82BB6A;
    case 0x82BB6Cu: goto L_82BB6C;
    case 0x82BB6Eu: goto L_82BB6E;
    case 0x82BB70u: goto L_82BB70;
    case 0x82BB73u: goto L_82BB73;
    case 0x82BB76u: goto L_82BB76;
    case 0x82BB78u: goto L_82BB78;
    case 0x82BB7Bu: goto L_82BB7B;
    case 0x82BB7Du: goto L_82BB7D;
    case 0x82BB7Fu: goto L_82BB7F;
    case 0x82BB82u: goto L_82BB82;
    case 0x82BB84u: goto L_82BB84;
    case 0x82BB87u: goto L_82BB87;
    case 0x82BB89u: goto L_82BB89;
    case 0x82BB8Cu: goto L_82BB8C;
    case 0x82BB8Eu: goto L_82BB8E;
    case 0x82BB90u: goto L_82BB90;
    case 0x82BB91u: goto L_82BB91;
    case 0x82BB92u: goto L_82BB92;
    case 0x82BB94u: goto L_82BB94;
    case 0x82BB95u: goto L_82BB95;
    case 0x82BB97u: goto L_82BB97;
    case 0x82BB99u: goto L_82BB99;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82BB68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB68u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB68u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB68 STY
    hw.write(cpu.address("dp", 0x63u), cpu.y, cpu.x8?8:16);
    goto L_82BB6A;
L_82BB6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB6Au,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB6Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB6A LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x10u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82BB6C;
L_82BB6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB6Cu,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB6Cu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82BB6C LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BB6E;
L_82BB6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB6Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB6Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB6E STA
    hw.write(cpu.address("dp", 0x65u), cpu.a, cpu.m8?8:16);
    goto L_82BB70;
L_82BB70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB70u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB70u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB70 AND
    cpu.logicAnd(0xFu);
    goto L_82BB73;
L_82BB73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB73u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB73u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB73 CMP
    cpu.compareA(0xFu);
    goto L_82BB76;
L_82BB76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB76u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB76u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB76 BNE -> $82BB7D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82BB7D; }
    goto L_82BB78;
L_82BB78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB78u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB78u, 9u, 3u, cpu.address("absx", 0x02F8u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB78 INC
    cpu.incMem(hw, cpu.address("absx", 0x2F8u), cpu.m8?8:16);
    goto L_82BB7B;
L_82BB7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB7Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB7Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB7B BRA -> $82BB8C
    goto L_82BB8C;
L_82BB7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB7Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB7Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB7D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x65u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BB7F;
L_82BB7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB7Fu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB7Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB7F BIT
    cpu.bit(0x2000u, true);
    goto L_82BB82;
L_82BB82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB82u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB82u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB82 BEQ -> $82BB89
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82BB89; }
    goto L_82BB84;
L_82BB84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB84u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB84u, 9u, 3u, cpu.address("absx", 0x02FAu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB84 INC
    cpu.incMem(hw, cpu.address("absx", 0x2FAu), cpu.m8?8:16);
    goto L_82BB87;
L_82BB87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB87u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB87u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB87 BRA -> $82BB8C
    goto L_82BB8C;
L_82BB89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB89u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB89u, 9u, 3u, cpu.address("absx", 0x02F4u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB89 INC
    cpu.incMem(hw, cpu.address("absx", 0x2F4u), cpu.m8?8:16);
    goto L_82BB8C;
L_82BB8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB8Cu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB8Cu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB8C DEC
    cpu.decMem(hw, cpu.address("dp", 0x12u), cpu.m8?8:16);
    goto L_82BB8E;
L_82BB8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB8Eu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB8Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB8E BMI -> $82BB97
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82BB97; }
    goto L_82BB90;
L_82BB90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB90u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB90u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB90 TYA
    cpu.transfer("TYA");
    goto L_82BB91;
L_82BB91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB91u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB91u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB91 SEC
    cpu.setFlag('C', true);
    goto L_82BB92;
L_82BB92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB92u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB92u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB92 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16));
    goto L_82BB94;
L_82BB94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB94u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB94u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB94 TAY
    cpu.transfer("TAY");
    goto L_82BB95;
L_82BB95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB95u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB95u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB95 BRA -> $82BB6C
    goto L_82BB6C;
L_82BB97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB97u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB97u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BB97 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82BB99;
L_82BB99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB99u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB99u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82BB99 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82BB99u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82BB99u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82D4F9_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82D4F9u: goto L_82D4F9;
    case 0x82D4FBu: goto L_82D4FB;
    case 0x82D4FDu: goto L_82D4FD;
    case 0x82D4FFu: goto L_82D4FF;
    case 0x82D501u: goto L_82D501;
    case 0x82D504u: goto L_82D504;
    case 0x82D506u: goto L_82D506;
    case 0x82D509u: goto L_82D509;
    case 0x82D50Bu: goto L_82D50B;
    case 0x82D50Eu: goto L_82D50E;
    case 0x82D512u: goto L_82D512;
    case 0x82D514u: goto L_82D514;
    case 0x82D517u: goto L_82D517;
    case 0x82D519u: goto L_82D519;
    case 0x82D51Cu: goto L_82D51C;
    case 0x82D51Eu: goto L_82D51E;
    case 0x82D521u: goto L_82D521;
    case 0x82D523u: goto L_82D523;
    case 0x82D527u: goto L_82D527;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82D4F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4F9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4F9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4F9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D4FB;
L_82D4FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4FBu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4FBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4FB BNE -> $82D527
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D527; }
    goto L_82D4FD;
L_82D4FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4FDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4FDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x71u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4FD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x71u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D4FF;
L_82D4FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD4FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD4FFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD4FFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D4FF BNE -> $82D50B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D50B; }
    goto L_82D501;
L_82D501:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD501u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD501u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD501u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D501 LDA
    cpu.setA(0x10u, 16);
    goto L_82D504;
L_82D504:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD504u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD504u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD504u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D504 STA
    hw.write(cpu.address("dp", 0x6Fu), cpu.a, cpu.m8?8:16);
    goto L_82D506;
L_82D506:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD506u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD506u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD506u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D506 LDA
    cpu.setA(0x20u, 16);
    goto L_82D509;
L_82D509:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD509u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD509u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD509u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x71u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D509 STA
    hw.write(cpu.address("dp", 0x71u), cpu.a, cpu.m8?8:16);
    goto L_82D50B;
L_82D50B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD50Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD50Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD50Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D50B LDX
    cpu.setX(0x2u, 16);
    goto L_82D50E;
L_82D50E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD50Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD50Eu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD50Eu, 6u, 4u, ((0x9E8232u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D50E LDA
    cpu.loadA(hw.readW(((0x9E8232u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D512;
L_82D512:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD512u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD512u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD512u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D512 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82D514;
L_82D514:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD514u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD514u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD514u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D514 LDA
    cpu.setA(0x9Eu, 16);
    goto L_82D517;
L_82D517:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD517u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD517u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD517u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D517 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82D519;
L_82D519:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD519u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD519u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD519u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D519 LDA
    cpu.setA(0x40u, 16);
    goto L_82D51C;
L_82D51C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD51Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD51Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD51Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D51C STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82D51E;
L_82D51E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD51Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD51Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD51Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D51E LDA
    cpu.setA(0x80u, 16);
    goto L_82D521;
L_82D521:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD521u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD521u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD521u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D521 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82D523;
L_82D523:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD523u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD523u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD523u, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82D523 JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD526u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD527u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x82D523u); }
    goto L_82D527;
L_82D527:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD527u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD527u,0x82D527u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD527u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD527u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D527 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D527u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D527u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82E0BF_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82E0BFu: goto L_82E0BF;
    case 0x82E0C1u: goto L_82E0C1;
    case 0x82E0C2u: goto L_82E0C2;
    case 0x82E0C4u: goto L_82E0C4;
    case 0x82E0C5u: goto L_82E0C5;
    case 0x82E0C6u: goto L_82E0C6;
    case 0x82E0C8u: goto L_82E0C8;
    case 0x82E0CAu: goto L_82E0CA;
    case 0x82E0CDu: goto L_82E0CD;
    case 0x82E0CFu: goto L_82E0CF;
    case 0x82E0D2u: goto L_82E0D2;
    case 0x82E0D5u: goto L_82E0D5;
    case 0x82E0D7u: goto L_82E0D7;
    case 0x82E0D8u: goto L_82E0D8;
    case 0x82E0D9u: goto L_82E0D9;
    case 0x82E0DAu: goto L_82E0DA;
    case 0x82E0DDu: goto L_82E0DD;
    case 0x82E0E0u: goto L_82E0E0;
    case 0x82E0E2u: goto L_82E0E2;
    case 0x82E0E4u: goto L_82E0E4;
    case 0x82E0E6u: goto L_82E0E6;
    case 0x82E0E9u: goto L_82E0E9;
    case 0x82E0EBu: goto L_82E0EB;
    case 0x82E0EEu: goto L_82E0EE;
    case 0x82E0F1u: goto L_82E0F1;
    case 0x82E0F2u: goto L_82E0F2;
    case 0x82E0F3u: goto L_82E0F3;
    case 0x82E0F6u: goto L_82E0F6;
    case 0x82E0F9u: goto L_82E0F9;
    case 0x82E0FBu: goto L_82E0FB;
    case 0x82E0FEu: goto L_82E0FE;
    case 0x82E101u: goto L_82E101;
    case 0x82E102u: goto L_82E102;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82E0BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0BFu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0BFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0BF SEP
    cpu.sep(0x20u);
    goto L_82E0C1;
L_82E0C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0C1u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0C1u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82E0C1 PHB
    cpu.push("PHB", hw);
    goto L_82E0C2;
L_82E0C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0C2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0C2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x69u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0C2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x69u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E0C4;
L_82E0C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0C4u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0C4u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82E0C4 PHA
    cpu.push("PHA", hw);
    goto L_82E0C5;
L_82E0C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0C5u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0C5u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82E0C5 PLB
    cpu.pop("PLB", hw);
    goto L_82E0C6;
L_82E0C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0C6u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0C6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0C6 REP
    cpu.rep(0x20u);
    goto L_82E0C8;
L_82E0C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0C8u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0C8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0C8 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82E0CA;
L_82E0CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0CAu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0CAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0CA LDY
    cpu.setY(0x1F8u, 16);
    goto L_82E0CD;
L_82E0CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0CDu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0CDu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0CDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0CD STX
    hw.write(cpu.address("dp", 0x61u), cpu.x, cpu.x8?8:16);
    goto L_82E0CF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0CDu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0CDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0CD STX
    hw.write(cpu.address("dp", 0x61u), cpu.x, cpu.x8?8:16);
    goto L_82E0CF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE0CDu,0x82E0CDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E0CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0CFu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0CFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0CFu, 5u + 1u, 3u, cpu.address("absx", 0x02DCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0CF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2DCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E0D2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0CFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0CFu, 5u + 1u, 3u, cpu.address("absx", 0x02DCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0CF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2DCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E0D2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE0CFu,0x82E0CFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E0D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0D2u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0D2u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0D2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0D2 CMP
    cpu.compareA(0xFFFFu);
    goto L_82E0D5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0D2u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0D2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0D2 CMP
    cpu.compareA(0xFFFFu);
    goto L_82E0D5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE0D2u,0x82E0D2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E0D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0D5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0D5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0D5 BNE -> $82E0E4
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E0E4; }
    goto L_82E0D7;
L_82E0D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0D7u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0D7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0D7 INX
    cpu.inc('X');
    goto L_82E0D8;
L_82E0D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0D8u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0D8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0D8 INX
    cpu.inc('X');
    goto L_82E0D9;
L_82E0D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0D9u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0D9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0D9 TXA
    cpu.transfer("TXA");
    goto L_82E0DA;
L_82E0DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0DAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0DAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0DA AND
    cpu.logicAnd(0xFFu);
    goto L_82E0DD;
L_82E0DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0DDu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0DDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0DD CMP
    cpu.compareA(0x6u);
    goto L_82E0E0;
L_82E0E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E0u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0E0 BCC -> $82E0CD
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82E0CD; }
    goto L_82E0E2;
L_82E0E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E2u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0E2 BRA -> $82E101
    goto L_82E101;
L_82E0E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0E4 STA
    hw.write(cpu.address("dp", 0x18u), cpu.a, cpu.m8?8:16);
    goto L_82E0E6;
L_82E0E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E6u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0E6 AND
    cpu.logicAnd(0xFCFFu);
    goto L_82E0E9;
L_82E0E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0E9 BNE -> $82E0F9
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E0F9; }
    goto L_82E0EB;
L_82E0EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0EBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0EBu, 5u + 1u, 3u, cpu.address("absx", 0x02D6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0EB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2D6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E0EE;
L_82E0EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0EEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0EEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0EE AND
    cpu.logicAnd(0xFFu);
    goto L_82E0F1;
L_82E0F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0F1 ASL
    cpu.aslA();
    goto L_82E0F2;
L_82E0F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F2u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0F2 TAX
    cpu.transfer("TAX");
    goto L_82E0F3;
L_82E0F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F3u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F3u, 5u, 3u, cpu.address("abs", 0xE0F8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E0F3 PEA
    cpu.push16Value(hw, 0xE0F8u);
    goto L_82E0F6;
L_82E0F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F6u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F6u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xE103u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $82E0F6 JMP (E103,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xE103u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x82E0F6u); return; }
L_82E0F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0F9u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F9u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0F9 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82E0FB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F9u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0F9 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82E0FB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE0F9u,0x82E0F9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E0FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0FBu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0FB LDA
    cpu.setA(0xFFFFu, 16);
    goto L_82E0FE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0FB LDA
    cpu.setA(0xFFFFu, 16);
    goto L_82E0FE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE0FBu,0x82E0FBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E0FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0FEu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FEu, 6u, 3u, cpu.address("absx", 0x02DCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0FE STA
    hw.write(cpu.address("absx", 0x2DCu), cpu.a, cpu.m8?8:16);
    goto L_82E101;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FEu, 6u, 3u, cpu.address("absx", 0x02DCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0FE STA
    hw.write(cpu.address("absx", 0x2DCu), cpu.a, cpu.m8?8:16);
    goto L_82E101;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE0FEu,0x82E0FEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E101:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE101u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE101u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE101u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82E101 PLB
    cpu.pop("PLB", hw);
    goto L_82E102;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE101u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE101u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82E101 PLB
    cpu.pop("PLB", hw);
    goto L_82E102;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE101u,0x82E101u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E102:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE102u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE102u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE102u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E102 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82E102u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82E102u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE102u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE102u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E102 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82E102u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82E102u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE102u,0x82E102u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82E0BF_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82E0BFu: goto L_82E0BF;
    case 0x82E0C1u: goto L_82E0C1;
    case 0x82E0C2u: goto L_82E0C2;
    case 0x82E0C4u: goto L_82E0C4;
    case 0x82E0C5u: goto L_82E0C5;
    case 0x82E0C6u: goto L_82E0C6;
    case 0x82E0C8u: goto L_82E0C8;
    case 0x82E0CAu: goto L_82E0CA;
    case 0x82E0CDu: goto L_82E0CD;
    case 0x82E0CFu: goto L_82E0CF;
    case 0x82E0D2u: goto L_82E0D2;
    case 0x82E0D5u: goto L_82E0D5;
    case 0x82E0D7u: goto L_82E0D7;
    case 0x82E0D8u: goto L_82E0D8;
    case 0x82E0D9u: goto L_82E0D9;
    case 0x82E0DAu: goto L_82E0DA;
    case 0x82E0DDu: goto L_82E0DD;
    case 0x82E0E0u: goto L_82E0E0;
    case 0x82E0E2u: goto L_82E0E2;
    case 0x82E0E4u: goto L_82E0E4;
    case 0x82E0E6u: goto L_82E0E6;
    case 0x82E0E9u: goto L_82E0E9;
    case 0x82E0EBu: goto L_82E0EB;
    case 0x82E0EEu: goto L_82E0EE;
    case 0x82E0F1u: goto L_82E0F1;
    case 0x82E0F2u: goto L_82E0F2;
    case 0x82E0F3u: goto L_82E0F3;
    case 0x82E0F6u: goto L_82E0F6;
    case 0x82E0F9u: goto L_82E0F9;
    case 0x82E0FBu: goto L_82E0FB;
    case 0x82E0FEu: goto L_82E0FE;
    case 0x82E101u: goto L_82E101;
    case 0x82E102u: goto L_82E102;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82E0BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0BFu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0BFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0BF SEP
    cpu.sep(0x20u);
    goto L_82E0C1;
L_82E0C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0C1u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0C1u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82E0C1 PHB
    cpu.push("PHB", hw);
    goto L_82E0C2;
L_82E0C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0C2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0C2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x69u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0C2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x69u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E0C4;
L_82E0C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0C4u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0C4u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82E0C4 PHA
    cpu.push("PHA", hw);
    goto L_82E0C5;
L_82E0C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0C5u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0C5u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82E0C5 PLB
    cpu.pop("PLB", hw);
    goto L_82E0C6;
L_82E0C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0C6u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0C6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0C6 REP
    cpu.rep(0x20u);
    goto L_82E0C8;
L_82E0C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0C8u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0C8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0C8 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82E0CA;
L_82E0CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0CAu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0CAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0CA LDY
    cpu.setY(0x1F8u, 16);
    goto L_82E0CD;
L_82E0CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0CDu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0CDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0CD STX
    hw.write(cpu.address("dp", 0x61u), cpu.x, cpu.x8?8:16);
    goto L_82E0CF;
L_82E0CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0CFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0CFu, 5u + 1u, 3u, cpu.address("absx", 0x02DCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0CF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2DCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E0D2;
L_82E0D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0D2u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0D2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0D2 CMP
    cpu.compareA(0xFFFFu);
    goto L_82E0D5;
L_82E0D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0D5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0D5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0D5 BNE -> $82E0E4
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E0E4; }
    goto L_82E0D7;
L_82E0D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0D7u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0D7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0D7 INX
    cpu.inc('X');
    goto L_82E0D8;
L_82E0D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0D8u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0D8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0D8 INX
    cpu.inc('X');
    goto L_82E0D9;
L_82E0D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0D9u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0D9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0D9 TXA
    cpu.transfer("TXA");
    goto L_82E0DA;
L_82E0DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0DAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0DAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0DA AND
    cpu.logicAnd(0xFFu);
    goto L_82E0DD;
L_82E0DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0DDu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0DDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0DD CMP
    cpu.compareA(0x6u);
    goto L_82E0E0;
L_82E0E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E0u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0E0 BCC -> $82E0CD
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82E0CD; }
    goto L_82E0E2;
L_82E0E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E2u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0E2 BRA -> $82E101
    goto L_82E101;
L_82E0E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0E4 STA
    hw.write(cpu.address("dp", 0x18u), cpu.a, cpu.m8?8:16);
    goto L_82E0E6;
L_82E0E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E6u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0E6 AND
    cpu.logicAnd(0xFCFFu);
    goto L_82E0E9;
L_82E0E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0E9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0E9 BNE -> $82E0F9
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E0F9; }
    goto L_82E0EB;
L_82E0EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0EBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0EBu, 5u + 1u, 3u, cpu.address("absx", 0x02D6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0EB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2D6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E0EE;
L_82E0EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0EEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0EEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0EE AND
    cpu.logicAnd(0xFFu);
    goto L_82E0F1;
L_82E0F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0F1 ASL
    cpu.aslA();
    goto L_82E0F2;
L_82E0F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F2u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0F2 TAX
    cpu.transfer("TAX");
    goto L_82E0F3;
L_82E0F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F3u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F3u, 5u, 3u, cpu.address("abs", 0xE0F8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E0F3 PEA
    cpu.push16Value(hw, 0xE0F8u);
    goto L_82E0F6;
L_82E0F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F6u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F6u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xE103u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $82E0F6 JMP (E103,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xE103u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x82E0F6u); return; }
L_82E0F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0F9u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F9u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0F9 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82E0FB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F9u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0F9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x61u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0F9 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x61u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82E0FB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE0F9u,0x82E0F9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E0FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0FBu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0FB LDA
    cpu.setA(0xFFFFu, 16);
    goto L_82E0FE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0FB LDA
    cpu.setA(0xFFFFu, 16);
    goto L_82E0FE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE0FBu,0x82E0FBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E0FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE0FEu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FEu, 6u, 3u, cpu.address("absx", 0x02DCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0FE STA
    hw.write(cpu.address("absx", 0x2DCu), cpu.a, cpu.m8?8:16);
    goto L_82E101;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE0FEu, 6u, 3u, cpu.address("absx", 0x02DCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E0FE STA
    hw.write(cpu.address("absx", 0x2DCu), cpu.a, cpu.m8?8:16);
    goto L_82E101;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE0FEu,0x82E0FEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E101:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE101u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE101u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE101u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82E101 PLB
    cpu.pop("PLB", hw);
    goto L_82E102;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE101u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE101u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82E101 PLB
    cpu.pop("PLB", hw);
    goto L_82E102;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE101u,0x82E101u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82E102:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE102u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE102u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE102u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E102 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82E102u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82E102u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE102u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE102u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E102 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82E102u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82E102u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE102u,0x82E102u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82E109_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82E109u: goto L_82E109;
    case 0x82E10Bu: goto L_82E10B;
    case 0x82E10Du: goto L_82E10D;
    case 0x82E10Fu: goto L_82E10F;
    case 0x82E111u: goto L_82E111;
    case 0x82E114u: goto L_82E114;
    case 0x82E116u: goto L_82E116;
    case 0x82E118u: goto L_82E118;
    case 0x82E11Au: goto L_82E11A;
    case 0x82E11Du: goto L_82E11D;
    case 0x82E11Fu: goto L_82E11F;
    case 0x82E122u: goto L_82E122;
    case 0x82E125u: goto L_82E125;
    case 0x82E127u: goto L_82E127;
    case 0x82E129u: goto L_82E129;
    case 0x82E12Cu: goto L_82E12C;
    case 0x82E12Du: goto L_82E12D;
    case 0x82E12Eu: goto L_82E12E;
    case 0x82E130u: goto L_82E130;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82E109:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE109u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE109u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE109u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82E109 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x67u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E10B;
L_82E10B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE10Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE10Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE10Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E10B BEQ -> $82E12C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E12C; }
    goto L_82E10D;
L_82E10D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE10Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE10Du,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE10Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E10D BMI -> $82E12C
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82E12C; }
    goto L_82E10F;
L_82E10F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE10Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE10Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE10Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E10F STA
    hw.write(cpu.address("dp", 0x16u), cpu.a, cpu.m8?8:16);
    goto L_82E111;
L_82E111:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE111u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE111u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE111u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E111 AND
    cpu.logicAnd(0x300u);
    goto L_82E114;
L_82E114:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE114u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE114u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE114u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E114 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x18u), cpu.m8?8:16));
    goto L_82E116;
L_82E116:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE116u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE116u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE116u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E116 BNE -> $82E12C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E12C; }
    goto L_82E118;
L_82E118:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE118u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE118u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE118u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E118 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82E11A;
L_82E11A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE11Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE11Au,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE11Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E11A ORA
    cpu.logicOr(0x8000u);
    goto L_82E11D;
L_82E11D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE11Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE11Du,cpu,0x91u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE11Du, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x67u) & 0xFFFFu), 2u, 0u);
    // $82E11D STA
    hw.write(cpu.addressDpIndirectY(hw, 0x67u), cpu.a, cpu.m8?8:16);
    goto L_82E11F;
L_82E11F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE11Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE11Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE11Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E11F AND
    cpu.logicAnd(0xFu);
    goto L_82E122;
L_82E122:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE122u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE122u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE122u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E122 CMP
    cpu.compareA(0xFu);
    goto L_82E125;
L_82E125:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE125u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE125u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE125u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E125 BNE -> $82E12C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82E12C; }
    goto L_82E127;
L_82E127:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE127u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE127u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE127u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E127 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82E129;
L_82E129:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE129u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE129u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE129u, 9u, 3u, cpu.address("absx", 0x02FAu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E129 INC
    cpu.incMem(hw, cpu.address("absx", 0x2FAu), cpu.m8?8:16);
    goto L_82E12C;
L_82E12C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE12Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE12Cu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE12Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E12C DEY
    cpu.decReg('Y');
    goto L_82E12D;
L_82E12D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE12Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE12Du,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE12Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E12D DEY
    cpu.decReg('Y');
    goto L_82E12E;
L_82E12E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE12Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE12Eu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE12Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E12E BPL -> $82E109
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82E109; }
    goto L_82E130;
L_82E130:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE130u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE130u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE130u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E130 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82E130u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82E130u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84810F_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84810Fu: goto L_84810F;
    case 0x848112u: goto L_848112;
    case 0x848114u: goto L_848114;
    case 0x848116u: goto L_848116;
    case 0x848117u: goto L_848117;
    case 0x848118u: goto L_848118;
    case 0x848119u: goto L_848119;
    case 0x84811Au: goto L_84811A;
    case 0x84811Cu: goto L_84811C;
    case 0x84811Du: goto L_84811D;
    case 0x84811Eu: goto L_84811E;
    case 0x848120u: goto L_848120;
    case 0x848123u: goto L_848123;
    case 0x848125u: goto L_848125;
    case 0x848127u: goto L_848127;
    case 0x848129u: goto L_848129;
    case 0x84812Au: goto L_84812A;
    case 0x84812Cu: goto L_84812C;
    case 0x84812Fu: goto L_84812F;
    case 0x848132u: goto L_848132;
    case 0x848134u: goto L_848134;
    case 0x848137u: goto L_848137;
    case 0x848139u: goto L_848139;
    case 0x84813Bu: goto L_84813B;
    case 0x84813Du: goto L_84813D;
    case 0x84813Fu: goto L_84813F;
    case 0x848142u: goto L_848142;
    case 0x848145u: goto L_848145;
    case 0x848148u: goto L_848148;
    case 0x84814Au: goto L_84814A;
    case 0x84814Du: goto L_84814D;
    case 0x84814Fu: goto L_84814F;
    case 0x848151u: goto L_848151;
    case 0x848153u: goto L_848153;
    case 0x848156u: goto L_848156;
    case 0x848159u: goto L_848159;
    case 0x84815Bu: goto L_84815B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84810F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x810Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x810Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x810Fu, 5u, 3u, cpu.address("abs", 0x0606u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84810F STZ
    hw.write(cpu.address("abs", 0x606u), 0, cpu.m8?8:16);
    goto L_848112;
L_848112:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8112u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8112u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8112u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x00u) & 0xFFFFu), 3u, 0u);
    // $848112 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848114;
L_848114:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8114u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8114u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8114u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848114 BEQ -> $848129
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848129; }
    goto L_848116;
L_848116:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8116u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8116u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8116u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848116 INY
    cpu.inc('Y');
    goto L_848117;
L_848117:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8117u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8117u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8117u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848117 INY
    cpu.inc('Y');
    goto L_848118;
L_848118:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8118u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8118u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8118u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848118 INY
    cpu.inc('Y');
    goto L_848119;
L_848119:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8119u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8119u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8119u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848119 INY
    cpu.inc('Y');
    goto L_84811A;
L_84811A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Au,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84811A STY
    hw.write(cpu.address("dp", 0x63u), cpu.y, cpu.x8?8:16);
    goto L_84811C;
L_84811C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Cu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84811C TYA
    cpu.transfer("TYA");
    goto L_84811D;
L_84811D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Du,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84811D SEC
    cpu.setFlag('C', true);
    goto L_84811E;
L_84811E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Eu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84811E SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_848120;
L_848120:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8120u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8120u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8120u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848120 CMP
    cpu.compareA(0x14u);
    goto L_848123;
L_848123:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8123u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8123u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8123u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848123 BCS -> $84815B
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_84815B; }
    goto L_848125;
L_848125:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8125u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8125u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8125u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848125 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_848127;
L_848127:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8127u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8127u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8127u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848127 BRA -> $848112
    goto L_848112;
L_848129:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8129u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8129u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8129u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848129 TYA
    cpu.transfer("TYA");
    goto L_84812A;
L_84812A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x812Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x812Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x812Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84812A STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_84812C;
L_84812C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x812Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x812Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x812Cu, 6u, 3u, cpu.address("abs", 0x815Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84812C JSR -> $84815C stack real
    { cpu.push16Value(hw,0x812Eu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x812Fu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x815Cu), 0x84812Cu); }
    goto L_84812F;
L_84812F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x812Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x812Fu,0x84812Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x812Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x812Fu, 5u, 3u, cpu.address("abs", 0x0606u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84812F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x606u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848132;
L_848132:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8132u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8132u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8132u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848132 BNE -> $84813F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84813F; }
    goto L_848134;
L_848134:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8134u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8134u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8134u, 6u, 3u, cpu.address("abs", 0x81E2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848134 JSR -> $8481E2 stack real
    { cpu.push16Value(hw,0x8136u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8137u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x81E2u), 0x848134u); }
    goto L_848137;
L_848137:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8137u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8137u,0x848137u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8137u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8137u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848137 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_848139;
L_848139:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8139u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8139u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8139u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848139 BEQ -> $84815B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_84815B; }
    goto L_84813B;
L_84813B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x813Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x813Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x813Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84813B STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_84813D;
L_84813D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x813Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x813Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x813Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84813D BRA -> $84812C
    goto L_84812C;
L_84813F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x813Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x813Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x813Fu, 5u, 3u, cpu.address("abs", 0x0606u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84813F STZ
    hw.write(cpu.address("abs", 0x606u), 0, cpu.m8?8:16);
    goto L_848142;
L_848142:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8142u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8142u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8142u, 6u, 3u, cpu.address("abs", 0x81B0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848142 JSR -> $8481B0 stack real
    { cpu.push16Value(hw,0x8144u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8145u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x81B0u), 0x848142u); }
    goto L_848145;
L_848145:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8145u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8145u,0x848145u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8145u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8145u, 5u, 3u, cpu.address("abs", 0x0606u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848145 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x606u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848148;
L_848148:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8148u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8148u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8148u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848148 BNE -> $84815B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84815B; }
    goto L_84814A;
L_84814A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x814Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x814Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x814Au, 6u, 3u, cpu.address("abs", 0x81E2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84814A JSR -> $8481E2 stack real
    { cpu.push16Value(hw,0x814Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x814Du,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x81E2u), 0x84814Au); }
    goto L_84814D;
L_84814D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x814Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x814Du,0x84814Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x814Du,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x814Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84814D CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_84814F;
L_84814F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x814Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x814Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x814Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84814F BEQ -> $84815B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_84815B; }
    goto L_848151;
L_848151:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8151u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8151u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8151u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848151 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_848153;
L_848153:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8153u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8153u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8153u, 6u, 3u, cpu.address("abs", 0x815Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848153 JSR -> $84815C stack real
    { cpu.push16Value(hw,0x8155u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8156u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x815Cu), 0x848153u); }
    goto L_848156;
L_848156:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8156u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8156u,0x848156u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8156u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8156u, 5u, 3u, cpu.address("abs", 0x0606u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848156 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x606u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848159;
L_848159:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8159u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8159u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8159u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848159 BNE -> $84813F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84813F; }
    goto L_84815B;
L_84815B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x815Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x815Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x815Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84815B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84815Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84815Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_848695_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848695u: goto L_848695;
    case 0x848697u: goto L_848697;
    case 0x84869Au: goto L_84869A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848695:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8695u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8695u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8695u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848695 SEP
    cpu.sep(0x20u);
    goto L_848697;
L_848697:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8697u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8697u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8697u, 6u, 3u, cpu.address("abs", 0x8BF8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848697 JSR -> $848BF8 stack real
    { cpu.push16Value(hw,0x8699u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x869Au,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8BF8u), 0x848697u); }
    goto L_84869A;
L_84869A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x869Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x869Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x869Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84869A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84869Au);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84869Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x869Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x869Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84869A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84869Au);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84869Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x869Au,0x84869Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_848695_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848695u: goto L_848695;
    case 0x848697u: goto L_848697;
    case 0x84869Au: goto L_84869A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848695:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8695u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8695u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8695u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848695 SEP
    cpu.sep(0x20u);
    goto L_848697;
L_848697:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8697u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8697u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8697u, 6u, 3u, cpu.address("abs", 0x8BF8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848697 JSR -> $848BF8 stack real
    { cpu.push16Value(hw,0x8699u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x869Au,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8BF8u), 0x848697u); }
    goto L_84869A;
L_84869A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x869Au))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x869Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x869Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84869A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84869Au);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84869Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x869Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x869Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84869A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84869Au);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84869Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x869Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x869Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84869A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84869Au);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84869Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x869Au,0x84869Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_848ED8_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848ED8u: goto L_848ED8;
    case 0x848EDBu: goto L_848EDB;
    case 0x848EDEu: goto L_848EDE;
    case 0x848EE1u: goto L_848EE1;
    case 0x848EE4u: goto L_848EE4;
    case 0x848EE7u: goto L_848EE7;
    case 0x848EE9u: goto L_848EE9;
    case 0x848EECu: goto L_848EEC;
    case 0x848EEFu: goto L_848EEF;
    case 0x848EF1u: goto L_848EF1;
    case 0x848EF4u: goto L_848EF4;
    case 0x848EF6u: goto L_848EF6;
    case 0x848EF9u: goto L_848EF9;
    case 0x848EFCu: goto L_848EFC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848ED8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED8u, 6u, 3u, cpu.address("abs", 0xB8CAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848ED8 JSR -> $84B8CA stack real
    { cpu.push16Value(hw,0x8EDAu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8EDBu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB8CAu), 0x848ED8u); }
    goto L_848EDB;
L_848EDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EDBu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8EDBu,0x848EDBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDBu, 6u, 3u, cpu.address("abs", 0x9145u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848EDB JSR -> $849145 stack real
    { cpu.push16Value(hw,0x8EDDu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8EDEu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9145u), 0x848EDBu); }
    goto L_848EDE;
L_848EDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EDEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8EDEu,0x848EDEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDEu, 6u, 3u, cpu.address("abs", 0xBBF7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848EDE JSR -> $84BBF7 stack real
    { cpu.push16Value(hw,0x8EE0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8EE1u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBBF7u), 0x848EDEu); }
    goto L_848EE1;
L_848EE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8EE1u,0x848EE1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE1u, 5u, 3u, cpu.address("abs", 0x062Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848EE1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848EE4;
L_848EE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE4u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848EE4 BIT
    cpu.bit(0x1u, true);
    goto L_848EE7;
L_848EE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848EE7 BEQ -> $848EF6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848EF6; }
    goto L_848EE9;
L_848EE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE9u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE9u, 5u, 3u, cpu.address("abs", 0x06FDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848EE9 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6FDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848EEC;
L_848EEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EECu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EECu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848EEC BIT
    cpu.bit(0x1u, true);
    goto L_848EEF;
L_848EEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848EEF BEQ -> $848EF6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848EF6; }
    goto L_848EF1;
L_848EF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF1u, 5u, 3u, cpu.address("abs", 0x06FEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848EF1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6FEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848EF4;
L_848EF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF4u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848EF4 BRA -> $848EF9
    goto L_848EF9;
L_848EF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF6u, 5u, 3u, cpu.address("abs", 0x062Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848EF6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848EF9;
L_848EF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF9u, 6u, 3u, cpu.address("abs", 0x90E7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848EF9 JSR -> $8490E7 stack real
    { cpu.push16Value(hw,0x8EFBu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8EFCu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x90E7u), 0x848EF9u); }
    goto L_848EFC;
L_848EFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EFCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8EFCu,0x848EFCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EFCu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EFCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848EFC RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x848EFCu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848EFCu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_848ED8_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848ED8u: goto L_848ED8;
    case 0x848EDBu: goto L_848EDB;
    case 0x848EDEu: goto L_848EDE;
    case 0x848EE1u: goto L_848EE1;
    case 0x848EE4u: goto L_848EE4;
    case 0x848EE7u: goto L_848EE7;
    case 0x848EE9u: goto L_848EE9;
    case 0x848EECu: goto L_848EEC;
    case 0x848EEFu: goto L_848EEF;
    case 0x848EF1u: goto L_848EF1;
    case 0x848EF4u: goto L_848EF4;
    case 0x848EF6u: goto L_848EF6;
    case 0x848EF9u: goto L_848EF9;
    case 0x848EFCu: goto L_848EFC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848ED8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ED8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ED8u, 6u, 3u, cpu.address("abs", 0xB8CAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848ED8 JSR -> $84B8CA stack real
    { cpu.push16Value(hw,0x8EDAu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8EDBu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB8CAu), 0x848ED8u); }
    goto L_848EDB;
L_848EDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EDBu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8EDBu,0x848EDBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDBu, 6u, 3u, cpu.address("abs", 0x9145u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848EDB JSR -> $849145 stack real
    { cpu.push16Value(hw,0x8EDDu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8EDEu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9145u), 0x848EDBu); }
    goto L_848EDE;
L_848EDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EDEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8EDEu,0x848EDEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EDEu, 6u, 3u, cpu.address("abs", 0xBBF7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848EDE JSR -> $84BBF7 stack real
    { cpu.push16Value(hw,0x8EE0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8EE1u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBBF7u), 0x848EDEu); }
    goto L_848EE1;
L_848EE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8EE1u,0x848EE1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE1u, 5u, 3u, cpu.address("abs", 0x062Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848EE1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848EE4;
L_848EE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE4u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848EE4 BIT
    cpu.bit(0x1u, true);
    goto L_848EE7;
L_848EE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848EE7 BEQ -> $848EF6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848EF6; }
    goto L_848EE9;
L_848EE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE9u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EE9u, 5u, 3u, cpu.address("abs", 0x06FDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848EE9 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6FDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848EEC;
L_848EEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EECu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EECu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848EEC BIT
    cpu.bit(0x1u, true);
    goto L_848EEF;
L_848EEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EEFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848EEF BEQ -> $848EF6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_848EF6; }
    goto L_848EF1;
L_848EF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF1u, 5u, 3u, cpu.address("abs", 0x06FEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848EF1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6FEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848EF4;
L_848EF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF4u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848EF4 BRA -> $848EF9
    goto L_848EF9;
L_848EF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF6u, 5u, 3u, cpu.address("abs", 0x062Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848EF6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x62Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848EF9;
L_848EF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EF9u, 6u, 3u, cpu.address("abs", 0x90E7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848EF9 JSR -> $8490E7 stack real
    { cpu.push16Value(hw,0x8EFBu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8EFCu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x90E7u), 0x848EF9u); }
    goto L_848EFC;
L_848EFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8EFCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8EFCu,0x848EFCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8EFCu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8EFCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848EFC RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x848EFCu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848EFCu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8494B4_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8494B4u: goto L_8494B4;
    case 0x8494B6u: goto L_8494B6;
    case 0x8494B7u: goto L_8494B7;
    case 0x8494BAu: goto L_8494BA;
    case 0x8494BDu: goto L_8494BD;
    case 0x8494C0u: goto L_8494C0;
    case 0x8494C3u: goto L_8494C3;
    case 0x8494C6u: goto L_8494C6;
    case 0x8494C9u: goto L_8494C9;
    case 0x8494CCu: goto L_8494CC;
    case 0x8494CFu: goto L_8494CF;
    case 0x8494D0u: goto L_8494D0;
    case 0x8494D3u: goto L_8494D3;
    case 0x8494D6u: goto L_8494D6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8494B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94B4u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94B4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494B4 REP
    cpu.rep(0x20u);
    goto L_8494B6;
L_8494B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94B6u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94B6u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8494B6 PHB
    cpu.push("PHB", hw);
    goto L_8494B7;
L_8494B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94B7u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94B7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494B7 LDX
    cpu.setX(0x996Cu, 16);
    goto L_8494BA;
L_8494BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94BAu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94BAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494BA LDY
    cpu.setY(0x1900u, 16);
    goto L_8494BD;
L_8494BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94BDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94BDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494BD LDA
    cpu.setA(0xFFu, 16);
    goto L_8494C0;
L_8494C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94C0u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0x94C0u, (std::uint32_t(cpu.a)+1u), 0x8Au, 0x84u);
    // $8494C0 MVN
    cpu.blockMove(hw, 0x84u, 0x8Au, false);
    goto L_8494C3;
L_8494C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94C3u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94C3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494C3 LDX
    cpu.setX(0xAA2Cu, 16);
    goto L_8494C6;
L_8494C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94C6u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94C6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494C6 LDY
    cpu.setY(0x1A00u, 16);
    goto L_8494C9;
L_8494C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94C9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94C9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494C9 LDA
    cpu.setA(0x1Fu, 16);
    goto L_8494CC;
L_8494CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94CCu,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0x94CCu, (std::uint32_t(cpu.a)+1u), 0x8Au, 0x84u);
    // $8494CC MVN
    cpu.blockMove(hw, 0x84u, 0x8Au, false);
    goto L_8494CF;
L_8494CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94CFu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94CFu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8494CF PLB
    cpu.pop("PLB", hw);
    goto L_8494D0;
L_8494D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94D0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94D0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494D0 LDA
    cpu.setA(0x42Fu, 16);
    goto L_8494D3;
L_8494D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94D3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94D3u, 5u, 3u, cpu.address("abs", 0x1A64u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8494D3 STA
    hw.write(cpu.address("abs", 0x1A64u), cpu.a, cpu.m8?8:16);
    goto L_8494D6;
L_8494D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x94D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x94D6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x94D6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8494D6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8494D6u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8494D6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_849A15_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849A15u: goto L_849A15;
    case 0x849A17u: goto L_849A17;
    case 0x849A19u: goto L_849A19;
    case 0x849A1Cu: goto L_849A1C;
    case 0x849A1Eu: goto L_849A1E;
    case 0x849A21u: goto L_849A21;
    case 0x849A23u: goto L_849A23;
    case 0x849A25u: goto L_849A25;
    case 0x849A28u: goto L_849A28;
    case 0x849A2Au: goto L_849A2A;
    case 0x849A2Du: goto L_849A2D;
    case 0x849A2Fu: goto L_849A2F;
    case 0x849A32u: goto L_849A32;
    case 0x849A35u: goto L_849A35;
    case 0x849A38u: goto L_849A38;
    case 0x849A3Au: goto L_849A3A;
    case 0x849A3Du: goto L_849A3D;
    case 0x849A40u: goto L_849A40;
    case 0x849A42u: goto L_849A42;
    case 0x849A44u: goto L_849A44;
    case 0x849A47u: goto L_849A47;
    case 0x849A4Bu: goto L_849A4B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849A15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A15u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A15u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A15 REP
    cpu.rep(0x20u);
    goto L_849A17;
L_849A17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A17u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A17u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A17 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849A19;
L_849A19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A19u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A19u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A19 BIT
    cpu.bit(0x200u, true);
    goto L_849A1C;
L_849A1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A1Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A1Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A1C BNE -> $849A25
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_849A25; }
    goto L_849A1E;
L_849A1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A1Eu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A1Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A1E BIT
    cpu.bit(0x100u, true);
    goto L_849A21;
L_849A21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A21u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A21u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A21 BNE -> $849A2F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_849A2F; }
    goto L_849A23;
L_849A23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A23u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A23u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A23 BRA -> $849A4B
    goto L_849A4B;
L_849A25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A25u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A25u, 9u, 3u, cpu.address("absx", 0x0633u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A25 DEC
    cpu.decMem(hw, cpu.address("absx", 0x633u), cpu.m8?8:16);
    goto L_849A28;
L_849A28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A28u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A28u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A28 BPL -> $849A42
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_849A42; }
    goto L_849A2A;
L_849A2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A2Au,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A2Au, 6u, 3u, cpu.address("absx", 0x0633u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A2A STZ
    hw.write(cpu.address("absx", 0x633u), 0, cpu.m8?8:16);
    goto L_849A2D;
L_849A2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A2Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A2Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A2D BRA -> $849A4B
    goto L_849A4B;
L_849A2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A2Fu,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A2Fu, 9u, 3u, cpu.address("absx", 0x0633u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A2F INC
    cpu.incMem(hw, cpu.address("absx", 0x633u), cpu.m8?8:16);
    goto L_849A32;
L_849A32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A32u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A32u, 5u + 1u, 3u, cpu.address("absx", 0x0633u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A32 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x633u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849A35;
L_849A35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A35u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A35u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A35 CMP
    cpu.compareA(0x3u);
    goto L_849A38;
L_849A38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A38u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A38u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A38 BCC -> $849A42
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_849A42; }
    goto L_849A3A;
L_849A3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A3Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A3Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A3A LDA
    cpu.setA(0x2u, 16);
    goto L_849A3D;
L_849A3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A3Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A3Du, 6u, 3u, cpu.address("absx", 0x0633u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A3D STA
    hw.write(cpu.address("absx", 0x633u), cpu.a, cpu.m8?8:16);
    goto L_849A40;
L_849A40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A40u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A40u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A40 BRA -> $849A4B
    goto L_849A4B;
L_849A42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A42u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A42u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A42u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A42 REP
    cpu.rep(0x20u);
    goto L_849A44;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A42u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A42u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A42 REP
    cpu.rep(0x20u);
    goto L_849A44;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9A42u,0x849A42u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849A44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A44u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A44u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A44u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A44 LDA
    cpu.setA(0x7u, 16);
    goto L_849A47;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A44u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A44u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A44 LDA
    cpu.setA(0x7u, 16);
    goto L_849A47;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9A44u,0x849A44u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849A47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A47u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A47u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A47u, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849A47 JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9A4Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9A4Bu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x849A47u); }
    goto L_849A4B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A47u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A47u, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849A47 JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9A4Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9A4Bu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x849A47u); }
    goto L_849A4B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9A47u,0x849A47u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849A4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A4Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A4Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A4Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849A4B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849A4Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849A4Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A4Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A4Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849A4B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849A4Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849A4Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9A4Bu,0x849A4Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_849A15_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849A15u: goto L_849A15;
    case 0x849A17u: goto L_849A17;
    case 0x849A19u: goto L_849A19;
    case 0x849A1Cu: goto L_849A1C;
    case 0x849A1Eu: goto L_849A1E;
    case 0x849A21u: goto L_849A21;
    case 0x849A23u: goto L_849A23;
    case 0x849A25u: goto L_849A25;
    case 0x849A28u: goto L_849A28;
    case 0x849A2Au: goto L_849A2A;
    case 0x849A2Du: goto L_849A2D;
    case 0x849A2Fu: goto L_849A2F;
    case 0x849A32u: goto L_849A32;
    case 0x849A35u: goto L_849A35;
    case 0x849A38u: goto L_849A38;
    case 0x849A3Au: goto L_849A3A;
    case 0x849A3Du: goto L_849A3D;
    case 0x849A40u: goto L_849A40;
    case 0x849A42u: goto L_849A42;
    case 0x849A44u: goto L_849A44;
    case 0x849A47u: goto L_849A47;
    case 0x849A4Bu: goto L_849A4B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849A15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A15u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A15u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A15 REP
    cpu.rep(0x20u);
    goto L_849A17;
L_849A17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A17u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A17u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A17 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849A19;
L_849A19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A19u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A19u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A19 BIT
    cpu.bit(0x200u, true);
    goto L_849A1C;
L_849A1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A1Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A1Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A1C BNE -> $849A25
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_849A25; }
    goto L_849A1E;
L_849A1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A1Eu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A1Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A1E BIT
    cpu.bit(0x100u, true);
    goto L_849A21;
L_849A21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A21u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A21u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A21 BNE -> $849A2F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_849A2F; }
    goto L_849A23;
L_849A23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A23u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A23u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A23 BRA -> $849A4B
    goto L_849A4B;
L_849A25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A25u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A25u, 9u, 3u, cpu.address("absx", 0x0633u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A25 DEC
    cpu.decMem(hw, cpu.address("absx", 0x633u), cpu.m8?8:16);
    goto L_849A28;
L_849A28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A28u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A28u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A28 BPL -> $849A42
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_849A42; }
    goto L_849A2A;
L_849A2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A2Au,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A2Au, 6u, 3u, cpu.address("absx", 0x0633u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A2A STZ
    hw.write(cpu.address("absx", 0x633u), 0, cpu.m8?8:16);
    goto L_849A2D;
L_849A2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A2Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A2Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A2D BRA -> $849A4B
    goto L_849A4B;
L_849A2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A2Fu,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A2Fu, 9u, 3u, cpu.address("absx", 0x0633u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A2F INC
    cpu.incMem(hw, cpu.address("absx", 0x633u), cpu.m8?8:16);
    goto L_849A32;
L_849A32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A32u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A32u, 5u + 1u, 3u, cpu.address("absx", 0x0633u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A32 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x633u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849A35;
L_849A35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A35u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A35u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A35 CMP
    cpu.compareA(0x3u);
    goto L_849A38;
L_849A38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A38u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A38u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A38 BCC -> $849A42
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_849A42; }
    goto L_849A3A;
L_849A3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A3Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A3Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A3A LDA
    cpu.setA(0x2u, 16);
    goto L_849A3D;
L_849A3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A3Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A3Du, 6u, 3u, cpu.address("absx", 0x0633u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A3D STA
    hw.write(cpu.address("absx", 0x633u), cpu.a, cpu.m8?8:16);
    goto L_849A40;
L_849A40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A40u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A40u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A40 BRA -> $849A4B
    goto L_849A4B;
L_849A42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A42u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A42u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A42 REP
    cpu.rep(0x20u);
    goto L_849A44;
L_849A44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A44u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A44u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849A44 LDA
    cpu.setA(0x7u, 16);
    goto L_849A47;
L_849A47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A47u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A47u, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849A47 JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9A4Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9A4Bu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x849A47u); }
    goto L_849A4B;
L_849A4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9A4Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9A4Bu,0x849A4Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9A4Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9A4Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849A4B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849A4Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849A4Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_849BC1_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849BC1u: goto L_849BC1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849BC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BC1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BC1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849BC1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849BC1u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849BC1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_849CE8_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849CE8u: goto L_849CE8;
    case 0x849CEAu: goto L_849CEA;
    case 0x849CEDu: goto L_849CED;
    case 0x849CF0u: goto L_849CF0;
    case 0x849CF3u: goto L_849CF3;
    case 0x849CF5u: goto L_849CF5;
    case 0x849CF8u: goto L_849CF8;
    case 0x849CFBu: goto L_849CFB;
    case 0x849CFEu: goto L_849CFE;
    case 0x849D01u: goto L_849D01;
    case 0x849D04u: goto L_849D04;
    case 0x849D05u: goto L_849D05;
    case 0x849D06u: goto L_849D06;
    case 0x849D0Au: goto L_849D0A;
    case 0x849D0Bu: goto L_849D0B;
    case 0x849D0Eu: goto L_849D0E;
    case 0x849D11u: goto L_849D11;
    case 0x849D14u: goto L_849D14;
    case 0x849D17u: goto L_849D17;
    case 0x849D18u: goto L_849D18;
    case 0x849D19u: goto L_849D19;
    case 0x849D1Cu: goto L_849D1C;
    case 0x849D1Du: goto L_849D1D;
    case 0x849D20u: goto L_849D20;
    case 0x849D23u: goto L_849D23;
    case 0x849D25u: goto L_849D25;
    case 0x849D28u: goto L_849D28;
    case 0x849D2Bu: goto L_849D2B;
    case 0x849D2Cu: goto L_849D2C;
    case 0x849D2Du: goto L_849D2D;
    case 0x849D31u: goto L_849D31;
    case 0x849D32u: goto L_849D32;
    case 0x849D35u: goto L_849D35;
    case 0x849D38u: goto L_849D38;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849CE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CE8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CE8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CE8 REP
    cpu.rep(0x20u);
    goto L_849CEA;
L_849CEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CEAu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CEAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CEA LDY
    cpu.setY(0x0u, 16);
    goto L_849CED;
L_849CED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CEDu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CEDu, 5u + 1u, 3u, cpu.address("absy", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CED LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x63Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849CF0;
L_849CF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CF0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CF0u, 6u, 3u, cpu.address("abs", 0x9F4Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849CF0 JSR -> $849F4E stack real
    { cpu.push16Value(hw,0x9CF2u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9CF3u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F4Eu), 0x849CF0u); }
    goto L_849CF3;
L_849CF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CF3u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CF3u,0x849CF3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CF3u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CF3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CF3 REP
    cpu.rep(0x20u);
    goto L_849CF5;
L_849CF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CF5u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CF5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CF5 LDX
    cpu.setX(0x0u, 16);
    goto L_849CF8;
L_849CF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CF8u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CF8u, 5u + 1u, 3u, cpu.address("absy", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CF8 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x63Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849CFB;
L_849CFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CFBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CFBu, 6u, 3u, cpu.address("abs", 0x9F86u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849CFB JSR -> $849F86 stack real
    { cpu.push16Value(hw,0x9CFDu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9CFEu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F86u), 0x849CFBu); }
    goto L_849CFE;
L_849CFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CFEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CFEu,0x849CFEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CFEu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CFEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CFE LDY
    cpu.setY(0x0u, 16);
    goto L_849D01;
L_849D01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D01u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D01u, 5u + 1u, 3u, cpu.address("absy", 0x0633u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849D01 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x633u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849D04;
L_849D04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D04u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D04u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849D04 ASL
    cpu.aslA();
    goto L_849D05;
L_849D05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D05u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D05u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849D05 TAX
    cpu.transfer("TAX");
    goto L_849D06;
L_849D06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D06u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D06u, 6u, 4u, ((0x849FBEu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849D06 LDA
    cpu.loadA(hw.readW(((0x849FBEu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849D0A;
L_849D0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D0Au,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D0Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849D0A TAY
    cpu.transfer("TAY");
    goto L_849D0B;
L_849D0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D0Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D0Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849D0B LDA
    cpu.setA(0x0u, 16);
    goto L_849D0E;
L_849D0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D0Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D0Eu, 6u, 3u, cpu.address("abs", 0x9EF1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849D0E JSR -> $849EF1 stack real
    { cpu.push16Value(hw,0x9D10u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9D11u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9EF1u), 0x849D0Eu); }
    goto L_849D11;
L_849D11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D11u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D11u,0x849D11u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D11u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D11u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849D11 LDY
    cpu.setY(0x0u, 16);
    goto L_849D14;
L_849D14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D14u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D14u, 5u + 1u, 3u, cpu.address("absy", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849D14 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x63Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849D17;
L_849D17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D17u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D17u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849D17 ASL
    cpu.aslA();
    goto L_849D18;
L_849D18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D18u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D18u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849D18 ASL
    cpu.aslA();
    goto L_849D19;
L_849D19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D19u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D19u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849D19 ADC
    cpu.adc(0x68u);
    goto L_849D1C;
L_849D1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Cu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849D1C TAY
    cpu.transfer("TAY");
    goto L_849D1D;
L_849D1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849D1D LDA
    cpu.setA(0x3u, 16);
    goto L_849D20;
L_849D20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D20u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D20u, 6u, 3u, cpu.address("abs", 0x9EF1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849D20 JSR -> $849EF1 stack real
    { cpu.push16Value(hw,0x9D22u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9D23u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9EF1u), 0x849D20u); }
    goto L_849D23;
L_849D23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D23u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D23u,0x849D23u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D23u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D23u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849D23 REP
    cpu.rep(0x20u);
    goto L_849D25;
L_849D25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D25u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D25u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849D25 LDY
    cpu.setY(0x0u, 16);
    goto L_849D28;
L_849D28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D28u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D28u, 5u + 1u, 3u, cpu.address("absy", 0x064Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849D28 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x64Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849D2B;
L_849D2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849D2B ASL
    cpu.aslA();
    goto L_849D2C;
L_849D2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Cu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849D2C TAX
    cpu.transfer("TAX");
    goto L_849D2D;
L_849D2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Du,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Du, 6u, 4u, ((0x849FC8u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849D2D LDA
    cpu.loadA(hw.readW(((0x849FC8u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849D31;
L_849D31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D31u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D31u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849D31 TAY
    cpu.transfer("TAY");
    goto L_849D32;
L_849D32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D32u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D32u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849D32 LDA
    cpu.setA(0x6u, 16);
    goto L_849D35;
L_849D35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D35u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D35u, 6u, 3u, cpu.address("abs", 0x9EF1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849D35 JSR -> $849EF1 stack real
    { cpu.push16Value(hw,0x9D37u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9D38u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9EF1u), 0x849D35u); }
    goto L_849D38;
L_849D38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D38u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D38u,0x849D38u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D38u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D38u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849D38 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849D38u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849D38u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_849CE8_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849CE8u: goto L_849CE8;
    case 0x849CEAu: goto L_849CEA;
    case 0x849CEDu: goto L_849CED;
    case 0x849CF0u: goto L_849CF0;
    case 0x849CF3u: goto L_849CF3;
    case 0x849CF5u: goto L_849CF5;
    case 0x849CF8u: goto L_849CF8;
    case 0x849CFBu: goto L_849CFB;
    case 0x849CFEu: goto L_849CFE;
    case 0x849D01u: goto L_849D01;
    case 0x849D04u: goto L_849D04;
    case 0x849D05u: goto L_849D05;
    case 0x849D06u: goto L_849D06;
    case 0x849D0Au: goto L_849D0A;
    case 0x849D0Bu: goto L_849D0B;
    case 0x849D0Eu: goto L_849D0E;
    case 0x849D11u: goto L_849D11;
    case 0x849D14u: goto L_849D14;
    case 0x849D17u: goto L_849D17;
    case 0x849D18u: goto L_849D18;
    case 0x849D19u: goto L_849D19;
    case 0x849D1Cu: goto L_849D1C;
    case 0x849D1Du: goto L_849D1D;
    case 0x849D20u: goto L_849D20;
    case 0x849D23u: goto L_849D23;
    case 0x849D25u: goto L_849D25;
    case 0x849D28u: goto L_849D28;
    case 0x849D2Bu: goto L_849D2B;
    case 0x849D2Cu: goto L_849D2C;
    case 0x849D2Du: goto L_849D2D;
    case 0x849D31u: goto L_849D31;
    case 0x849D32u: goto L_849D32;
    case 0x849D35u: goto L_849D35;
    case 0x849D38u: goto L_849D38;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849CE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CE8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CE8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CE8 REP
    cpu.rep(0x20u);
    goto L_849CEA;
L_849CEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CEAu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CEAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CEA LDY
    cpu.setY(0x0u, 16);
    goto L_849CED;
L_849CED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CEDu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CEDu, 5u + 1u, 3u, cpu.address("absy", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CED LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x63Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849CF0;
L_849CF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CF0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CF0u, 6u, 3u, cpu.address("abs", 0x9F4Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849CF0 JSR -> $849F4E stack real
    { cpu.push16Value(hw,0x9CF2u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9CF3u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F4Eu), 0x849CF0u); }
    goto L_849CF3;
L_849CF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CF3u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CF3u,0x849CF3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CF3u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CF3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CF3 REP
    cpu.rep(0x20u);
    goto L_849CF5;
L_849CF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CF5u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CF5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CF5 LDX
    cpu.setX(0x0u, 16);
    goto L_849CF8;
L_849CF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CF8u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CF8u, 5u + 1u, 3u, cpu.address("absy", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CF8 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x63Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849CFB;
L_849CFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CFBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CFBu, 6u, 3u, cpu.address("abs", 0x9F86u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849CFB JSR -> $849F86 stack real
    { cpu.push16Value(hw,0x9CFDu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9CFEu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9F86u), 0x849CFBu); }
    goto L_849CFE;
L_849CFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CFEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9CFEu,0x849CFEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CFEu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CFEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849CFE LDY
    cpu.setY(0x0u, 16);
    goto L_849D01;
L_849D01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D01u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D01u, 5u + 1u, 3u, cpu.address("absy", 0x0633u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849D01 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x633u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849D04;
L_849D04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D04u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D04u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849D04 ASL
    cpu.aslA();
    goto L_849D05;
L_849D05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D05u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D05u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849D05 TAX
    cpu.transfer("TAX");
    goto L_849D06;
L_849D06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D06u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D06u, 6u, 4u, ((0x849FBEu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849D06 LDA
    cpu.loadA(hw.readW(((0x849FBEu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849D0A;
L_849D0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D0Au,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D0Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849D0A TAY
    cpu.transfer("TAY");
    goto L_849D0B;
L_849D0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D0Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D0Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849D0B LDA
    cpu.setA(0x0u, 16);
    goto L_849D0E;
L_849D0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D0Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D0Eu, 6u, 3u, cpu.address("abs", 0x9EF1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849D0E JSR -> $849EF1 stack real
    { cpu.push16Value(hw,0x9D10u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9D11u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9EF1u), 0x849D0Eu); }
    goto L_849D11;
L_849D11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D11u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D11u,0x849D11u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D11u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D11u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849D11 LDY
    cpu.setY(0x0u, 16);
    goto L_849D14;
L_849D14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D14u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D14u, 5u + 1u, 3u, cpu.address("absy", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849D14 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x63Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849D17;
L_849D17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D17u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D17u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849D17 ASL
    cpu.aslA();
    goto L_849D18;
L_849D18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D18u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D18u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849D18 ASL
    cpu.aslA();
    goto L_849D19;
L_849D19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D19u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D19u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849D19 ADC
    cpu.adc(0x68u);
    goto L_849D1C;
L_849D1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Cu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849D1C TAY
    cpu.transfer("TAY");
    goto L_849D1D;
L_849D1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D1Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849D1D LDA
    cpu.setA(0x3u, 16);
    goto L_849D20;
L_849D20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D20u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D20u, 6u, 3u, cpu.address("abs", 0x9EF1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849D20 JSR -> $849EF1 stack real
    { cpu.push16Value(hw,0x9D22u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9D23u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9EF1u), 0x849D20u); }
    goto L_849D23;
L_849D23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D23u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D23u,0x849D23u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D23u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D23u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849D23 REP
    cpu.rep(0x20u);
    goto L_849D25;
L_849D25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D25u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D25u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849D25 LDY
    cpu.setY(0x0u, 16);
    goto L_849D28;
L_849D28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D28u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D28u, 5u + 1u, 3u, cpu.address("absy", 0x064Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849D28 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x64Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849D2B;
L_849D2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849D2B ASL
    cpu.aslA();
    goto L_849D2C;
L_849D2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Cu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849D2C TAX
    cpu.transfer("TAX");
    goto L_849D2D;
L_849D2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Du,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D2Du, 6u, 4u, ((0x849FC8u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849D2D LDA
    cpu.loadA(hw.readW(((0x849FC8u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849D31;
L_849D31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D31u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D31u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849D31 TAY
    cpu.transfer("TAY");
    goto L_849D32;
L_849D32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D32u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D32u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849D32 LDA
    cpu.setA(0x6u, 16);
    goto L_849D35;
L_849D35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D35u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D35u, 6u, 3u, cpu.address("abs", 0x9EF1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849D35 JSR -> $849EF1 stack real
    { cpu.push16Value(hw,0x9D37u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9D38u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9EF1u), 0x849D35u); }
    goto L_849D38;
L_849D38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D38u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D38u,0x849D38u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D38u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D38u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849D38 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x849D38u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x849D38u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84B51D_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84B51Du: goto L_84B51D;
    case 0x84B51Fu: goto L_84B51F;
    case 0x84B521u: goto L_84B521;
    case 0x84B523u: goto L_84B523;
    case 0x84B525u: goto L_84B525;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84B51D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB51Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB51Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB51Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B51D SEP
    cpu.sep(0x20u);
    goto L_84B51F;
L_84B51F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB51Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB51Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB51Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B51F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B521;
L_84B521:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB521u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB521u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB521u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B521 BNE -> $84B525
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84B525; }
    goto L_84B523;
L_84B523:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB523u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB523u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB523u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B523 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_84B525;
L_84B525:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB525u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB525u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB525u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B525 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84B525u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84B525u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84B51D_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84B51Du: goto L_84B51D;
    case 0x84B51Fu: goto L_84B51F;
    case 0x84B521u: goto L_84B521;
    case 0x84B523u: goto L_84B523;
    case 0x84B525u: goto L_84B525;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84B51D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB51Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB51Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB51Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B51D SEP
    cpu.sep(0x20u);
    goto L_84B51F;
L_84B51F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB51Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB51Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB51Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x75u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B51F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B521;
L_84B521:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB521u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB521u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB521u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B521 BNE -> $84B525
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84B525; }
    goto L_84B523;
L_84B523:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB523u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB523u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB523u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B523 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_84B525;
L_84B525:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB525u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB525u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB525u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B525 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84B525u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84B525u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84C5D6_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84C5D6u: goto L_84C5D6;
    case 0x84C5D9u: goto L_84C5D9;
    case 0x84C5DAu: goto L_84C5DA;
    case 0x84C5DDu: goto L_84C5DD;
    case 0x84C5E0u: goto L_84C5E0;
    case 0x84C5E1u: goto L_84C5E1;
    case 0x84C5E2u: goto L_84C5E2;
    case 0x84C5E4u: goto L_84C5E4;
    case 0x84C5E5u: goto L_84C5E5;
    case 0x84C5E6u: goto L_84C5E6;
    case 0x84C5E8u: goto L_84C5E8;
    case 0x84C5ECu: goto L_84C5EC;
    case 0x84C5EDu: goto L_84C5ED;
    case 0x84C5EFu: goto L_84C5EF;
    case 0x84C5F3u: goto L_84C5F3;
    case 0x84C5F4u: goto L_84C5F4;
    case 0x84C5F5u: goto L_84C5F5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84C5D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5D6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5D6u, 5u, 3u, cpu.address("abs", 0x0665u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C5D6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x665u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84C5D9;
L_84C5D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5D9u,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5D9u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $84C5D9 PHK
    cpu.push("PHK", hw);
    goto L_84C5DA;
L_84C5DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5DAu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5DAu, 5u, 3u, cpu.address("abs", 0xC5F5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84C5DA PEA
    cpu.push16Value(hw, 0xC5F5u);
    goto L_84C5DD;
L_84C5DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5DDu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5DDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C5DD AND
    cpu.logicAnd(0xFFu);
    goto L_84C5E0;
L_84C5E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E0u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E0u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84C5E0 PHA
    cpu.push("PHA", hw);
    goto L_84C5E1;
L_84C5E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C5E1 ASL
    cpu.aslA();
    goto L_84C5E2;
L_84C5E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E2u,cpu,0x63u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E2u, 5u, 2u, cpu.addressStack(0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C5E2 ADC
    cpu.adc(hw.readW(cpu.addressStack(0x1u), cpu.m8?8:16));
    goto L_84C5E4;
L_84C5E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E4u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C5E4 TAX
    cpu.transfer("TAX");
    goto L_84C5E5;
L_84C5E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E5u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E5u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84C5E5 PLA
    cpu.pop("PLA", hw);
    goto L_84C5E6;
L_84C5E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E6u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C5E6 SEP
    cpu.sep(0x20u);
    goto L_84C5E8;
L_84C5E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E8u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5E8u, 5u, 4u, ((0x84C647u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C5E8 LDA
    cpu.loadA(hw.readW(((0x84C647u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84C5EC;
L_84C5EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5ECu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5ECu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $84C5EC PHA
    cpu.push("PHA", hw);
    goto L_84C5ED;
L_84C5ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5EDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5EDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C5ED REP
    cpu.rep(0x20u);
    goto L_84C5EF;
L_84C5EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5EFu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5EFu, 6u, 4u, ((0x84C645u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C5EF LDA
    cpu.loadA(hw.readW(((0x84C645u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84C5F3;
L_84C5F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5F3u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5F3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84C5F3 DEC
    cpu.decReg('A');
    goto L_84C5F4;
L_84C5F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5F4u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5F4u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84C5F4 PHA
    cpu.push("PHA", hw);
    goto L_84C5F5;
L_84C5F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC5F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC5F5u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC5F5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84C5F5 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x84C5F5u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84C5F5u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

