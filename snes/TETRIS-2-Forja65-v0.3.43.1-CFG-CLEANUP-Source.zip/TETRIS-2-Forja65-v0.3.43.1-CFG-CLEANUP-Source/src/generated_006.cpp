#include "generated.hpp"
void sub_0080B0_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0080B0u: goto L_0080B0;
    case 0x8080B4u: goto L_8080B4;
    case 0x8080B6u: goto L_8080B6;
    case 0x8080B7u: goto L_8080B7;
    case 0x8080B8u: goto L_8080B8;
    case 0x8080B9u: goto L_8080B9;
    case 0x8080BAu: goto L_8080BA;
    case 0x8080BBu: goto L_8080BB;
    case 0x8080BEu: goto L_8080BE;
    case 0x8080BFu: goto L_8080BF;
    case 0x8080C1u: goto L_8080C1;
    case 0x8080C2u: goto L_8080C2;
    case 0x8080C3u: goto L_8080C3;
    case 0x8080C6u: goto L_8080C6;
    case 0x8080C8u: goto L_8080C8;
    case 0x8080CAu: goto L_8080CA;
    case 0x8080CCu: goto L_8080CC;
    case 0x8080D0u: goto L_8080D0;
    case 0x8080D4u: goto L_8080D4;
    case 0x8080D7u: goto L_8080D7;
    case 0x8080DAu: goto L_8080DA;
    case 0x8080DCu: goto L_8080DC;
    case 0x8080DEu: goto L_8080DE;
    case 0x8080E1u: goto L_8080E1;
    case 0x8080E5u: goto L_8080E5;
    case 0x8080E9u: goto L_8080E9;
    case 0x8080EDu: goto L_8080ED;
    case 0x8080EFu: goto L_8080EF;
    case 0x8080F1u: goto L_8080F1;
    case 0x8080F2u: goto L_8080F2;
    case 0x8080F3u: goto L_8080F3;
    case 0x8080F4u: goto L_8080F4;
    case 0x8080F5u: goto L_8080F5;
    case 0x8080F6u: goto L_8080F6;
    case 0x808105u: goto L_808105;
    case 0x808109u: goto L_808109;
    case 0x80810Bu: goto L_80810B;
    case 0x80810Cu: goto L_80810C;
    case 0x80810Du: goto L_80810D;
    case 0x80810Eu: goto L_80810E;
    case 0x80810Fu: goto L_80810F;
    case 0x808110u: goto L_808110;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0080B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B0u,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B0u, 4u, 4u, 0x8080B4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080B0 JML -> $8080B4
    cpu.pb=0x80u; // JML troca o Program Bank mesmo em goto local recompilado
    goto L_8080B4;
L_8080B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B4u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080B4 REP
    cpu.rep(0x20u);
    goto L_8080B6;
L_8080B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B6u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B6u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8080B6 PHA
    cpu.push("PHA", hw);
    goto L_8080B7;
L_8080B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B7u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B7u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8080B7 PHX
    cpu.push("PHX", hw);
    goto L_8080B8;
L_8080B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B8u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B8u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8080B8 PHY
    cpu.push("PHY", hw);
    goto L_8080B9;
L_8080B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B9u,cpu,0x0Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B9u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8080B9 PHD
    cpu.push("PHD", hw);
    goto L_8080BA;
L_8080BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BAu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BAu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8080BA PHB
    cpu.push("PHB", hw);
    goto L_8080BB;
L_8080BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080BB LDA
    cpu.setA(0x0u, 16);
    goto L_8080BE;
L_8080BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BEu,cpu,0x5Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080BE TCD
    cpu.tcd();
    goto L_8080BF;
L_8080BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BFu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080BF SEP
    cpu.sep(0x20u);
    goto L_8080C1;
L_8080C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C1u,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C1u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8080C1 PHK
    cpu.push("PHK", hw);
    goto L_8080C2;
L_8080C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C2u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C2u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8080C2 PLB
    cpu.pop("PLB", hw);
    goto L_8080C3;
L_8080C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C3u,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C3u, 4u, 3u, cpu.address("abs", 0x4210u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080C3 BIT
    cpu.bit(hw.readW(cpu.address("abs", 0x4210u), cpu.m8?8:16), false);
    goto L_8080C6;
L_8080C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080C6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8080C8;
L_8080C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080C8 BNE -> $808105
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_808105; }
    goto L_8080CA;
L_8080CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CAu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080CA INC
    cpu.incMem(hw, cpu.address("dp", 0x4Au), cpu.m8?8:16);
    goto L_8080CC;
L_8080CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CCu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CCu, 8u, 4u, 0x80864Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080CC JSL -> $80864B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80CFu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80D0u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80864Bu, 0x8080CCu); }
    goto L_8080D0;
L_8080D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D0u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80D0u,0x8080D0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D0u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D0u, 8u, 4u, 0x808564u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080D0 JSL -> $808564 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80D3u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80D4u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808564u, 0x8080D0u); }
    goto L_8080D4;
L_8080D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D4u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80D4u,0x8080D4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D4u, 6u, 3u, cpu.address("abs", 0x85ADu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8080D4 JSR -> $8085AD stack real
    { cpu.push16Value(hw,0x80D6u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80D7u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x85ADu), 0x8080D4u); }
    goto L_8080D7;
L_8080D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D7u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80D7u,0x8080D7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D7u, 6u, 3u, cpu.address("abs", 0x858Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8080D7 JSR -> $80858D stack real
    { cpu.push16Value(hw,0x80D9u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80DAu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x858Du), 0x8080D7u); }
    goto L_8080DA;
L_8080DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80DAu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80DAu,0x8080DAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80DAu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80DAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080DA STZ
    hw.write(cpu.address("dp", 0x96u), 0, cpu.m8?8:16);
    goto L_8080DC;
L_8080DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80DCu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80DCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x97u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080DC STZ
    hw.write(cpu.address("dp", 0x97u), 0, cpu.m8?8:16);
    goto L_8080DE;
L_8080DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80DEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80DEu, 6u, 3u, cpu.address("abs", 0x8444u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8080DE JSR -> $808444 stack real
    { cpu.push16Value(hw,0x80E0u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80E1u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8444u), 0x8080DEu); }
    goto L_8080E1;
L_8080E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80E1u,0x8080E1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E1u, 8u, 4u, 0x808ADEu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080E1 JSL -> $808ADE stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80E4u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80E5u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808ADEu, 0x8080E1u); }
    goto L_8080E5;
L_8080E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E5u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80E5u,0x8080E5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E5u, 8u, 4u, 0x80A724u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080E5 JSL -> $80A724 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80E8u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80E9u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A724u, 0x8080E5u); }
    goto L_8080E9;
L_8080E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80E9u,0x8080E9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E9u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E9u, 8u, 4u, 0x808BEAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080E9 JSL -> $808BEA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80ECu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80EDu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808BEAu, 0x8080E9u); }
    goto L_8080ED;
L_8080ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80EDu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80EDu,0x8080EDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80EDu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80EDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080ED STZ
    hw.write(cpu.address("dp", 0x4Au), 0, cpu.m8?8:16);
    goto L_8080EF;
L_8080EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80EFu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80EFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080EF REP
    cpu.rep(0x20u);
    goto L_8080F1;
L_8080F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F1u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8080F1 PLB
    cpu.pop("PLB", hw);
    goto L_8080F2;
L_8080F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F2u,cpu,0x2Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F2u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8080F2 PLD
    cpu.pop("PLD", hw);
    goto L_8080F3;
L_8080F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F3u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F3u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8080F3 PLY
    cpu.pop("PLY", hw);
    goto L_8080F4;
L_8080F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F4u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F4u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8080F4 PLX
    cpu.pop("PLX", hw);
    goto L_8080F5;
L_8080F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F5u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F5u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8080F5 PLA
    cpu.pop("PLA", hw);
    goto L_8080F6;
L_8080F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F6u,cpu,0x40u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F6u, 7u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $8080F6 RTI stack real
    {auto dst=cpu.returnInterrupt(hw);hw.requestDispatch(dst,0x8080F6u);return;}
L_808105:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8105u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8105u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8105u, 8u, 4u, 0x808564u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808105 JSL -> $808564 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8108u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8109u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808564u, 0x808105u); }
    goto L_808109;
L_808109:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8109u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8109u,0x808109u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8109u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8109u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808109 REP
    cpu.rep(0x20u);
    goto L_80810B;
L_80810B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x810Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x810Bu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x810Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80810B PLB
    cpu.pop("PLB", hw);
    goto L_80810C;
L_80810C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x810Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x810Cu,cpu,0x2Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x810Cu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80810C PLD
    cpu.pop("PLD", hw);
    goto L_80810D;
L_80810D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x810Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x810Du,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x810Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80810D PLY
    cpu.pop("PLY", hw);
    goto L_80810E;
L_80810E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x810Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x810Eu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x810Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80810E PLX
    cpu.pop("PLX", hw);
    goto L_80810F;
L_80810F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x810Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x810Fu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x810Fu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80810F PLA
    cpu.pop("PLA", hw);
    goto L_808110;
L_808110:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8110u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8110u,cpu,0x40u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8110u, 7u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 4u);
    // $808110 RTI stack real
    {auto dst=cpu.returnInterrupt(hw);hw.requestDispatch(dst,0x808110u);return;}
}

void sub_808414_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808414u: goto L_808414;
    case 0x808418u: goto L_808418;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808414:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8414u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8414u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8414u, 8u, 4u, 0x84BEA2u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808414 JSL -> $84BEA2 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8417u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8418u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84BEA2u, 0x808414u); }
    goto L_808418;
L_808418:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8418u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8418u,0x808418u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8418u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8418u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808418 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808418u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808418u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808414_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808414u: goto L_808414;
    case 0x808418u: goto L_808418;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808414:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8414u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8414u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8414u, 8u, 4u, 0x84BEA2u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808414 JSL -> $84BEA2 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8417u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8418u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84BEA2u, 0x808414u); }
    goto L_808418;
L_808418:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8418u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8418u,0x808418u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8418u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8418u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808418 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808418u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808418u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8084B7_E0M1X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8084B7u: goto L_8084B7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8084B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B7u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8084B7 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8084B7u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8084B7u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8084B7_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8084B7u: goto L_8084B7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8084B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x84B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x84B7u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x84B7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8084B7 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8084B7u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8084B7u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808D03_E0M1X1CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808D03u: goto L_808D03;
    case 0x808D04u: goto L_808D04;
    case 0x808D06u: goto L_808D06;
    case 0x808D09u: goto L_808D09;
    case 0x808D0Au: goto L_808D0A;
    case 0x808D0Bu: goto L_808D0B;
    case 0x808D0Cu: goto L_808D0C;
    case 0x808D0Fu: goto L_808D0F;
    case 0x808D10u: goto L_808D10;
    case 0x808D13u: goto L_808D13;
    case 0x808D16u: goto L_808D16;
    case 0x808D17u: goto L_808D17;
    case 0x808D18u: goto L_808D18;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808D03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D03u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D03u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808D03 PHP
    cpu.push("PHP", hw);
    goto L_808D04;
L_808D04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D04u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D04u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D04 REP
    cpu.rep(0x20u);
    goto L_808D06;
L_808D06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D06u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D06u, 5u, 3u, cpu.address("abs", 0x0120u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D06 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x120u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808D09;
L_808D09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D09u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D09u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D09 ASL
    cpu.aslA();
    goto L_808D0A;
L_808D0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D0A ASL
    cpu.aslA();
    goto L_808D0B;
L_808D0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D0B CLC
    cpu.setFlag('C', false);
    goto L_808D0C;
L_808D0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Cu,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Cu, 5u, 3u, cpu.address("abs", 0x0120u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D0C ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x120u), cpu.m8?8:16));
    goto L_808D0F;
L_808D0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D0F CLC
    cpu.setFlag('C', false);
    goto L_808D10;
L_808D10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D10u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D10u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D10 ADC
    cpu.adc(0x3711u);
    goto L_808D13;
L_808D13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D13u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D13u, 5u, 3u, cpu.address("abs", 0x0120u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D13 STA
    hw.write(cpu.address("abs", 0x120u), cpu.a, cpu.m8?8:16);
    goto L_808D16;
L_808D16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D16u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D16u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D16 XBA
    cpu.xba();
    goto L_808D17;
L_808D17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D17u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D17u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808D17 PLP
    cpu.pop("PLP", hw);
    goto L_808D18;
L_808D18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D18u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==true)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8D18u,0x808D18u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D18u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D18u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808D18 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808D18u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x808D18u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_809E11_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809E11u: goto L_809E11;
    case 0x809E14u: goto L_809E14;
    case 0x809E17u: goto L_809E17;
    case 0x809E19u: goto L_809E19;
    case 0x809E1Cu: goto L_809E1C;
    case 0x809E1Fu: goto L_809E1F;
    case 0x809E22u: goto L_809E22;
    case 0x809E24u: goto L_809E24;
    case 0x809E27u: goto L_809E27;
    case 0x809E2Au: goto L_809E2A;
    case 0x809E2Du: goto L_809E2D;
    case 0x809E30u: goto L_809E30;
    case 0x809E33u: goto L_809E33;
    case 0x809E36u: goto L_809E36;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809E11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E11u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E11u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E11 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809E14;
L_809E14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E14u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E14u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E14 CMP
    cpu.compareA(0x2u);
    goto L_809E17;
L_809E17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E17u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E17u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E17 BCS -> $809E24
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_809E24; }
    goto L_809E19;
L_809E19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E19u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E19u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E19 LDX
    cpu.setX(0x668u, 16);
    goto L_809E1C;
L_809E1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E1C LDA
    cpu.setA(0x13u, 16);
    goto L_809E1F;
L_809E1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Fu, 6u, 3u, cpu.address("abs", 0x9E37u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809E1F JSR -> $809E37 stack real
    { cpu.push16Value(hw,0x9E21u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9E22u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9E37u), 0x809E1Fu); }
    goto L_809E22;
L_809E22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E22u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E22u,0x809E22u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E22u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E22u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E22 BRA -> $809E36
    goto L_809E36;
L_809E24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E24u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E24u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E24 LDX
    cpu.setX(0x656u, 16);
    goto L_809E27;
L_809E27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E27u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E27u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E27 LDA
    cpu.setA(0x15u, 16);
    goto L_809E2A;
L_809E2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Au, 6u, 3u, cpu.address("abs", 0x9E37u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809E2A JSR -> $809E37 stack real
    { cpu.push16Value(hw,0x9E2Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9E2Du,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9E37u), 0x809E2Au); }
    goto L_809E2D;
L_809E2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E2Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E2Du,0x809E2Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E2D LDX
    cpu.setX(0x67Au, 16);
    goto L_809E30;
L_809E30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E30u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E30u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E30 LDA
    cpu.setA(0x15u, 16);
    goto L_809E33;
L_809E33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E33u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E33u, 6u, 3u, cpu.address("abs", 0x9E37u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809E33 JSR -> $809E37 stack real
    { cpu.push16Value(hw,0x9E35u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9E36u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9E37u), 0x809E33u); }
    goto L_809E36;
L_809E36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E36u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E36u,0x809E36u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E36u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E36u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809E36 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x809E36u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x809E36u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_809E11_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809E11u: goto L_809E11;
    case 0x809E14u: goto L_809E14;
    case 0x809E17u: goto L_809E17;
    case 0x809E19u: goto L_809E19;
    case 0x809E1Cu: goto L_809E1C;
    case 0x809E1Fu: goto L_809E1F;
    case 0x809E22u: goto L_809E22;
    case 0x809E24u: goto L_809E24;
    case 0x809E27u: goto L_809E27;
    case 0x809E2Au: goto L_809E2A;
    case 0x809E2Du: goto L_809E2D;
    case 0x809E30u: goto L_809E30;
    case 0x809E33u: goto L_809E33;
    case 0x809E36u: goto L_809E36;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809E11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E11u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E11u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E11 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809E14;
L_809E14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E14u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E14u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E14 CMP
    cpu.compareA(0x2u);
    goto L_809E17;
L_809E17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E17u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E17u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E17 BCS -> $809E24
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_809E24; }
    goto L_809E19;
L_809E19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E19u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E19u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E19 LDX
    cpu.setX(0x668u, 16);
    goto L_809E1C;
L_809E1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E1C LDA
    cpu.setA(0x13u, 16);
    goto L_809E1F;
L_809E1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Fu, 6u, 3u, cpu.address("abs", 0x9E37u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809E1F JSR -> $809E37 stack real
    { cpu.push16Value(hw,0x9E21u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9E22u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9E37u), 0x809E1Fu); }
    goto L_809E22;
L_809E22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E22u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E22u,0x809E22u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E22u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E22u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E22 BRA -> $809E36
    goto L_809E36;
L_809E24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E24u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E24u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E24 LDX
    cpu.setX(0x656u, 16);
    goto L_809E27;
L_809E27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E27u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E27u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E27 LDA
    cpu.setA(0x15u, 16);
    goto L_809E2A;
L_809E2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Au, 6u, 3u, cpu.address("abs", 0x9E37u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809E2A JSR -> $809E37 stack real
    { cpu.push16Value(hw,0x9E2Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9E2Du,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9E37u), 0x809E2Au); }
    goto L_809E2D;
L_809E2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E2Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E2Du,0x809E2Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E2D LDX
    cpu.setX(0x67Au, 16);
    goto L_809E30;
L_809E30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E30u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E30u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E30 LDA
    cpu.setA(0x15u, 16);
    goto L_809E33;
L_809E33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E33u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E33u, 6u, 3u, cpu.address("abs", 0x9E37u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809E33 JSR -> $809E37 stack real
    { cpu.push16Value(hw,0x9E35u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9E36u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9E37u), 0x809E33u); }
    goto L_809E36;
L_809E36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E36u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E36u,0x809E36u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E36u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E36u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809E36 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x809E36u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x809E36u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_809E11_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809E11u: goto L_809E11;
    case 0x809E14u: goto L_809E14;
    case 0x809E17u: goto L_809E17;
    case 0x809E19u: goto L_809E19;
    case 0x809E1Cu: goto L_809E1C;
    case 0x809E1Fu: goto L_809E1F;
    case 0x809E22u: goto L_809E22;
    case 0x809E24u: goto L_809E24;
    case 0x809E27u: goto L_809E27;
    case 0x809E2Au: goto L_809E2A;
    case 0x809E2Du: goto L_809E2D;
    case 0x809E30u: goto L_809E30;
    case 0x809E33u: goto L_809E33;
    case 0x809E36u: goto L_809E36;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809E11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E11u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E11u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E11 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809E14;
L_809E14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E14u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E14u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E14 CMP
    cpu.compareA(0x2u);
    goto L_809E17;
L_809E17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E17u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E17u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E17 BCS -> $809E24
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_809E24; }
    goto L_809E19;
L_809E19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E19u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E19u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E19 LDX
    cpu.setX(0x668u, 16);
    goto L_809E1C;
L_809E1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E1C LDA
    cpu.setA(0x13u, 16);
    goto L_809E1F;
L_809E1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E1Fu, 6u, 3u, cpu.address("abs", 0x9E37u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809E1F JSR -> $809E37 stack real
    { cpu.push16Value(hw,0x9E21u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9E22u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9E37u), 0x809E1Fu); }
    goto L_809E22;
L_809E22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E22u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E22u,0x809E22u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E22u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E22u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E22 BRA -> $809E36
    goto L_809E36;
L_809E24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E24u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E24u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E24 LDX
    cpu.setX(0x656u, 16);
    goto L_809E27;
L_809E27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E27u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E27u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E27 LDA
    cpu.setA(0x15u, 16);
    goto L_809E2A;
L_809E2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Au, 6u, 3u, cpu.address("abs", 0x9E37u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809E2A JSR -> $809E37 stack real
    { cpu.push16Value(hw,0x9E2Cu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9E2Du,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9E37u), 0x809E2Au); }
    goto L_809E2D;
L_809E2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E2Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E2Du,0x809E2Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E2Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E2D LDX
    cpu.setX(0x67Au, 16);
    goto L_809E30;
L_809E30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E30u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E30u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E30 LDA
    cpu.setA(0x15u, 16);
    goto L_809E33;
L_809E33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E33u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E33u, 6u, 3u, cpu.address("abs", 0x9E37u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809E33 JSR -> $809E37 stack real
    { cpu.push16Value(hw,0x9E35u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9E36u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9E37u), 0x809E33u); }
    goto L_809E36;
L_809E36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E36u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E36u,0x809E36u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E36u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E36u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809E36 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x809E36u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x809E36u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_809F36_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809F36u: goto L_809F36;
    case 0x809F39u: goto L_809F39;
    case 0x809F3Cu: goto L_809F3C;
    case 0x809F3Fu: goto L_809F3F;
    case 0x809F42u: goto L_809F42;
    case 0x809F46u: goto L_809F46;
    case 0x809F48u: goto L_809F48;
    case 0x809F4Au: goto L_809F4A;
    case 0x809F4Bu: goto L_809F4B;
    case 0x809F4Eu: goto L_809F4E;
    case 0x809F51u: goto L_809F51;
    case 0x809F54u: goto L_809F54;
    case 0x809F58u: goto L_809F58;
    case 0x809F5Bu: goto L_809F5B;
    case 0x809F5Eu: goto L_809F5E;
    case 0x809F61u: goto L_809F61;
    case 0x809F64u: goto L_809F64;
    case 0x809F68u: goto L_809F68;
    case 0x809F6Au: goto L_809F6A;
    case 0x809F6Cu: goto L_809F6C;
    case 0x809F6Du: goto L_809F6D;
    case 0x809F70u: goto L_809F70;
    case 0x809F73u: goto L_809F73;
    case 0x809F76u: goto L_809F76;
    case 0x809F7Au: goto L_809F7A;
    case 0x809F7Du: goto L_809F7D;
    case 0x809F7Fu: goto L_809F7F;
    case 0x809F82u: goto L_809F82;
    case 0x809F84u: goto L_809F84;
    case 0x809F87u: goto L_809F87;
    case 0x809F8Au: goto L_809F8A;
    case 0x809F8Eu: goto L_809F8E;
    case 0x809F91u: goto L_809F91;
    case 0x809F94u: goto L_809F94;
    case 0x809F97u: goto L_809F97;
    case 0x809F9Au: goto L_809F9A;
    case 0x809F9Eu: goto L_809F9E;
    case 0x809F9Fu: goto L_809F9F;
    case 0x809FA2u: goto L_809FA2;
    case 0x809FA5u: goto L_809FA5;
    case 0x809FA7u: goto L_809FA7;
    case 0x809FA8u: goto L_809FA8;
    case 0x809FABu: goto L_809FAB;
    case 0x809FACu: goto L_809FAC;
    case 0x809FAFu: goto L_809FAF;
    case 0x809FB2u: goto L_809FB2;
    case 0x809FB5u: goto L_809FB5;
    case 0x809FB8u: goto L_809FB8;
    case 0x809FBCu: goto L_809FBC;
    case 0x809FBDu: goto L_809FBD;
    case 0x809FC0u: goto L_809FC0;
    case 0x809FC3u: goto L_809FC3;
    case 0x809FC5u: goto L_809FC5;
    case 0x809FC6u: goto L_809FC6;
    case 0x809FC9u: goto L_809FC9;
    case 0x809FCAu: goto L_809FCA;
    case 0x809FCDu: goto L_809FCD;
    case 0x809FD0u: goto L_809FD0;
    case 0x809FD3u: goto L_809FD3;
    case 0x809FD6u: goto L_809FD6;
    case 0x809FDAu: goto L_809FDA;
    case 0x809FDBu: goto L_809FDB;
    case 0x809FDEu: goto L_809FDE;
    case 0x809FE1u: goto L_809FE1;
    case 0x809FE3u: goto L_809FE3;
    case 0x809FE4u: goto L_809FE4;
    case 0x809FE7u: goto L_809FE7;
    case 0x809FE8u: goto L_809FE8;
    case 0x809FEBu: goto L_809FEB;
    case 0x809FEFu: goto L_809FEF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809F36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F36u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F36u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F36 LDA
    cpu.setA(0x8000u, 16);
    goto L_809F39;
L_809F39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F39u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F39u, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F39 STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_809F3C;
L_809F3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F3C LDA
    cpu.setA(0x8Du, 16);
    goto L_809F3F;
L_809F3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Fu, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F3F STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_809F42;
L_809F42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F42u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F42u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809F42 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9F45u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9F46u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x809F42u); }
    goto L_809F46;
L_809F46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F46u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F46u,0x809F46u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F46u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F46u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F46 SEP
    cpu.sep(0x20u);
    goto L_809F48;
L_809F48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F48u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F48u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F48 LDA
    cpu.setA(0x7Eu, 8);
    goto L_809F4A;
L_809F4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Au,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Au, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809F4A PHA
    cpu.push("PHA", hw);
    goto L_809F4B;
L_809F4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Bu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Bu, 5u, 3u, cpu.address("abs", 0x8000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809F4B PEA
    cpu.push16Value(hw, 0x8000u);
    goto L_809F4E;
L_809F4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Eu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Eu, 5u, 3u, cpu.address("abs", 0x6000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809F4E PEA
    cpu.push16Value(hw, 0x6000u);
    goto L_809F51;
L_809F51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F51u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F51u, 5u, 3u, cpu.address("abs", 0x2000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809F51 PEA
    cpu.push16Value(hw, 0x2000u);
    goto L_809F54;
L_809F54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F54u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F54u, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809F54 JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9F57u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9F58u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x809F54u); }
    goto L_809F58;
L_809F58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F58u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F58u,0x809F58u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F58u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F58u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F58 LDA
    cpu.setA(0x8000u, 16);
    goto L_809F5B;
L_809F5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F5Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F5Bu, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F5B STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_809F5E;
L_809F5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F5Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F5Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F5E LDA
    cpu.setA(0x9Bu, 16);
    goto L_809F61;
L_809F61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F61u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F61u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F61 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_809F64;
L_809F64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F64u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F64u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809F64 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9F67u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9F68u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x809F64u); }
    goto L_809F68;
L_809F68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F68u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F68u,0x809F68u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F68u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F68u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F68 SEP
    cpu.sep(0x20u);
    goto L_809F6A;
L_809F6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F6Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F6Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F6A LDA
    cpu.setA(0x7Eu, 8);
    goto L_809F6C;
L_809F6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F6Cu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F6Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809F6C PHA
    cpu.push("PHA", hw);
    goto L_809F6D;
L_809F6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F6Du,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F6Du, 5u, 3u, cpu.address("abs", 0x8000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809F6D PEA
    cpu.push16Value(hw, 0x8000u);
    goto L_809F70;
L_809F70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F70u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F70u, 5u, 3u, cpu.address("abs", 0x2000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809F70 PEA
    cpu.push16Value(hw, 0x2000u);
    goto L_809F73;
L_809F73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F73u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F73u, 5u, 3u, cpu.address("abs", 0x6000u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809F73 PEA
    cpu.push16Value(hw, 0x6000u);
    goto L_809F76;
L_809F76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F76u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F76u, 8u, 4u, 0x809B54u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809F76 JSL -> $809B54 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9F79u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9F7Au,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809B54u, 0x809F76u); }
    goto L_809F7A;
L_809F7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F7Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F7Au,0x809F7Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F7Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F7Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F7A LDA
    cpu.setA(0x826Cu, 16);
    goto L_809F7D;
L_809F7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F7Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F7Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F7D STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_809F7F;
L_809F7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F7Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F7Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F7F LDA
    cpu.setA(0x8Au, 16);
    goto L_809F82;
L_809F82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F82u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F82u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F82 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_809F84;
L_809F84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F84u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F84u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F84 LDX
    cpu.setX(0x0u, 16);
    goto L_809F87;
L_809F87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F87u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F87u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F87 LDY
    cpu.setY(0x200u, 16);
    goto L_809F8A;
L_809F8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F8Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F8Au, 8u, 4u, 0x808BB9u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809F8A JSL -> $808BB9 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9F8Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9F8Eu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808BB9u, 0x809F8Au); }
    goto L_809F8E;
L_809F8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F8Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F8Eu,0x809F8Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F8Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F8Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F8E LDA
    cpu.setA(0xB46Cu, 16);
    goto L_809F91;
L_809F91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F91u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F91u, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F91 STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_809F94;
L_809F94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F94u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F94u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F94 LDA
    cpu.setA(0x8Au, 16);
    goto L_809F97;
L_809F97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F97u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F97u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F97 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_809F9A;
L_809F9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F9Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F9Au, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809F9A JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9F9Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9F9Eu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x809F9Au); }
    goto L_809F9E;
L_809F9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F9Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F9Eu,0x809F9Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F9Eu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F9Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809F9E PHB
    cpu.push("PHB", hw);
    goto L_809F9F;
L_809F9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F9Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F9Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809F9F LDX
    cpu.setX(0x8000u, 16);
    goto L_809FA2;
L_809FA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FA2u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FA2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809FA2 LDY
    cpu.setY(0x2800u, 16);
    goto L_809FA5;
L_809FA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FA5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FA5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809FA5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809FA7;
L_809FA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FA7u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FA7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809FA7 DEC
    cpu.decReg('A');
    goto L_809FA8;
L_809FA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FA8u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0x9FA8u, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $809FA8 MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_809FAB;
L_809FAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FABu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FABu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809FAB PLB
    cpu.pop("PLB", hw);
    goto L_809FAC;
L_809FAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FACu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FACu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809FAC LDA
    cpu.setA(0xFA86u, 16);
    goto L_809FAF;
L_809FAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FAFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FAFu, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809FAF STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_809FB2;
L_809FB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FB2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FB2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809FB2 LDA
    cpu.setA(0x90u, 16);
    goto L_809FB5;
L_809FB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FB5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FB5u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809FB5 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_809FB8;
L_809FB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FB8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FB8u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809FB8 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9FBBu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9FBCu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x809FB8u); }
    goto L_809FBC;
L_809FBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FBCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9FBCu,0x809FBCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FBCu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FBCu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809FBC PHB
    cpu.push("PHB", hw);
    goto L_809FBD;
L_809FBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FBDu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FBDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809FBD LDX
    cpu.setX(0x8000u, 16);
    goto L_809FC0;
L_809FC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FC0u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FC0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809FC0 LDY
    cpu.setY(0x4000u, 16);
    goto L_809FC3;
L_809FC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FC3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FC3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809FC3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809FC5;
L_809FC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FC5u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FC5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809FC5 DEC
    cpu.decReg('A');
    goto L_809FC6;
L_809FC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FC6u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0x9FC6u, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $809FC6 MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_809FC9;
L_809FC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FC9u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FC9u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809FC9 PLB
    cpu.pop("PLB", hw);
    goto L_809FCA;
L_809FCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FCAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FCAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809FCA LDA
    cpu.setA(0x8300u, 16);
    goto L_809FCD;
L_809FCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FCDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FCDu, 5u, 3u, cpu.address("abs", 0x00B5u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809FCD STA
    hw.write(cpu.address("abs", 0xB5u), cpu.a, cpu.m8?8:16);
    goto L_809FD0;
L_809FD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FD0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FD0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809FD0 LDA
    cpu.setA(0x89u, 16);
    goto L_809FD3;
L_809FD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FD3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FD3u, 5u, 3u, cpu.address("abs", 0x00B7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809FD3 STA
    hw.write(cpu.address("abs", 0xB7u), cpu.a, cpu.m8?8:16);
    goto L_809FD6;
L_809FD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FD6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FD6u, 8u, 4u, 0x809022u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809FD6 JSL -> $809022 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9FD9u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9FDAu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809022u, 0x809FD6u); }
    goto L_809FDA;
L_809FDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FDAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9FDAu,0x809FDAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FDAu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FDAu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809FDA PHB
    cpu.push("PHB", hw);
    goto L_809FDB;
L_809FDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FDBu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FDBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809FDB LDX
    cpu.setX(0x8000u, 16);
    goto L_809FDE;
L_809FDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FDEu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FDEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809FDE LDY
    cpu.setY(0x6000u, 16);
    goto L_809FE1;
L_809FE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FE1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FE1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xBDu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809FE1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xBDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809FE3;
L_809FE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FE3u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FE3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809FE3 DEC
    cpu.decReg('A');
    goto L_809FE4;
L_809FE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FE4u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0x9FE4u, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $809FE4 MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_809FE7;
L_809FE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FE7u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FE7u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809FE7 PLB
    cpu.pop("PLB", hw);
    goto L_809FE8;
L_809FE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FE8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FE8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809FE8 LDA
    cpu.setA(0xFFFFu, 16);
    goto L_809FEB;
L_809FEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FEBu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FEBu, 8u, 4u, 0x80A460u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809FEB JSL -> $80A460 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9FEEu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9FEFu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A460u, 0x809FEBu); }
    goto L_809FEF;
L_809FEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FEFu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9FEFu,0x809FEFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FEFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FEFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809FEF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x809FEFu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x809FEFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80BAE7_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80BAE7u: goto L_80BAE7;
    case 0x80BAEAu: goto L_80BAEA;
    case 0x80BAEDu: goto L_80BAED;
    case 0x80BAEFu: goto L_80BAEF;
    case 0x80BAF2u: goto L_80BAF2;
    case 0x80BAF5u: goto L_80BAF5;
    case 0x80BAF7u: goto L_80BAF7;
    case 0x80BAFAu: goto L_80BAFA;
    case 0x80BAFCu: goto L_80BAFC;
    case 0x80BAFDu: goto L_80BAFD;
    case 0x80BAFEu: goto L_80BAFE;
    case 0x80BB00u: goto L_80BB00;
    case 0x80BB02u: goto L_80BB02;
    case 0x80BB06u: goto L_80BB06;
    case 0x80BB09u: goto L_80BB09;
    case 0x80BB0Bu: goto L_80BB0B;
    case 0x80BB0Du: goto L_80BB0D;
    case 0x80BB0Fu: goto L_80BB0F;
    case 0x80BB12u: goto L_80BB12;
    case 0x80BB14u: goto L_80BB14;
    case 0x80BB16u: goto L_80BB16;
    case 0x80BB18u: goto L_80BB18;
    case 0x80BB1Bu: goto L_80BB1B;
    case 0x80BB1Du: goto L_80BB1D;
    case 0x80BB20u: goto L_80BB20;
    case 0x80BB23u: goto L_80BB23;
    case 0x80BB25u: goto L_80BB25;
    case 0x80BB28u: goto L_80BB28;
    case 0x80BB2Bu: goto L_80BB2B;
    case 0x80BB2Cu: goto L_80BB2C;
    case 0x80BB2Fu: goto L_80BB2F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80BAE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAE7u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAE7u, 5u, 3u, cpu.address("abs", 0x096Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAE7 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x96Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80BAEA;
L_80BAEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAEAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAEAu, 5u, 3u, cpu.address("abs", 0x0970u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAEA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x970u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BAED;
L_80BAED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAEDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAEDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAED STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80BAEF;
L_80BAEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAEFu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAEFu, 5u, 3u, cpu.address("abs", 0x097Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAEF STZ
    hw.write(cpu.address("abs", 0x97Cu), 0, cpu.m8?8:16);
    goto L_80BAF2;
L_80BAF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAF2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAF2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAF2 LDA
    cpu.setA(0x3u, 16);
    goto L_80BAF5;
L_80BAF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAF5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAF5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAF5 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_80BAF7;
L_80BAF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAF7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAF7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAF7 LDA
    cpu.setA(0x3u, 16);
    goto L_80BAFA;
L_80BAFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAFAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAFAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAFA STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_80BAFC;
L_80BAFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAFCu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAFCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAFC INX
    cpu.inc('X');
    goto L_80BAFD;
L_80BAFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAFDu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAFDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAFD INX
    cpu.inc('X');
    goto L_80BAFE;
L_80BAFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAFEu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAFEu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BAFE DEC
    cpu.decMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_80BB00;
L_80BB00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB00u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB00u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB00 BPL -> $80BAFC
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BAFC; }
    goto L_80BB02;
L_80BB02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB02u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB02u, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB02 LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BB06;
L_80BB06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB06u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB06u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB06 CMP
    cpu.compareA(0xFFFFu);
    goto L_80BB09;
L_80BB09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB09u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB09u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB09 BEQ -> $80BB16
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BB16; }
    goto L_80BB0B;
L_80BB0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB0Bu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB0Bu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB0B DEC
    cpu.decMem(hw, cpu.address("dp", 0x4u), cpu.m8?8:16);
    goto L_80BB0D;
L_80BB0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB0Du,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB0D BMI -> $80BAFC
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BAFC; }
    goto L_80BB0F;
L_80BB0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB0Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB0Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB0F AND
    cpu.logicAnd(0xFFFFu);
    goto L_80BB12;
L_80BB12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB12u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB12u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB12 BNE -> $80BB1D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BB1D; }
    goto L_80BB14;
L_80BB14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB14u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB14u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB14 BRA -> $80BAFC
    goto L_80BAFC;
L_80BB16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB16u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB16u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB16 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_80BB18;
L_80BB18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB18u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB18u, 8u, 3u, cpu.address("abs", 0x097Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB18 INC
    cpu.incMem(hw, cpu.address("abs", 0x97Cu), cpu.m8?8:16);
    goto L_80BB1B;
L_80BB1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB1Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB1Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB1B BNE -> $80BAF2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BAF2; }
    goto L_80BB1D;
L_80BB1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB1Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB1Du, 5u, 3u, cpu.address("abs", 0x097Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB1D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x97Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BB20;
L_80BB20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB20u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB20u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB20 CMP
    cpu.compareA(0x4u);
    goto L_80BB23;
L_80BB23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB23u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB23u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB23 BCS -> $80BB2C
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80BB2C; }
    goto L_80BB25;
L_80BB25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB25u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB25u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB25 LDA
    cpu.setA(0xFFFFu, 16);
    goto L_80BB28;
L_80BB28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB28u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB28u, 5u, 3u, cpu.address("abs", 0x095Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB28 STA
    hw.write(cpu.address("abs", 0x95Au), cpu.a, cpu.m8?8:16);
    goto L_80BB2B;
L_80BB2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB2Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB2Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BB2B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80BB2Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80BB2Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80BB2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB2Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB2Cu, 5u, 3u, cpu.address("abs", 0x095Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB2C STZ
    hw.write(cpu.address("abs", 0x95Au), 0, cpu.m8?8:16);
    goto L_80BB2F;
L_80BB2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB2Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB2Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BB2F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80BB2Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80BB2Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80D45E_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80D45Eu: goto L_80D45E;
    case 0x80D460u: goto L_80D460;
    case 0x80D463u: goto L_80D463;
    case 0x80D466u: goto L_80D466;
    case 0x80D467u: goto L_80D467;
    case 0x80D46Au: goto L_80D46A;
    case 0x80D46Cu: goto L_80D46C;
    case 0x80D470u: goto L_80D470;
    case 0x80D473u: goto L_80D473;
    case 0x80D475u: goto L_80D475;
    case 0x80D478u: goto L_80D478;
    case 0x80D479u: goto L_80D479;
    case 0x80D47Au: goto L_80D47A;
    case 0x80D47Cu: goto L_80D47C;
    case 0x80D47Eu: goto L_80D47E;
    case 0x80D481u: goto L_80D481;
    case 0x80D485u: goto L_80D485;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80D45E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD45Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD45Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD45Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D45E STZ
    hw.write(cpu.address("dp", 0x63u), 0, cpu.m8?8:16);
    goto L_80D460;
L_80D460:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD460u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD460u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD460u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D460 LDY
    cpu.setY(0x4u, 16);
    goto L_80D463;
L_80D463:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD463u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD463u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD463u, 5u + 1u, 3u, cpu.address("absy", 0x03AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D463 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x3AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D466;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD463u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD463u, 5u + 1u, 3u, cpu.address("absy", 0x03AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D463 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x3AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D466;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD463u,0x80D463u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D466:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD466u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD466u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD466u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D466 TAX
    cpu.transfer("TAX");
    goto L_80D467;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD466u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD466u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D466 TAX
    cpu.transfer("TAX");
    goto L_80D467;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD466u,0x80D466u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D467:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD467u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD467u,cpu,0xECu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD467u, 5u, 3u, cpu.address("abs", 0x096Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D467 CPX
    cpu.compareX(hw.readW(cpu.address("abs", 0x96Eu), cpu.x8?8:16));
    goto L_80D46A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD467u,cpu,0xECu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD467u, 5u, 3u, cpu.address("abs", 0x096Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D467 CPX
    cpu.compareX(hw.readW(cpu.address("abs", 0x96Eu), cpu.x8?8:16));
    goto L_80D46A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD467u,0x80D467u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D46A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD46Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD46Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD46Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D46A BCC -> $80D478
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80D478; }
    goto L_80D46C;
L_80D46C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD46Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD46Cu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD46Cu, 6u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D46C LDA
    cpu.loadA(hw.readW(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D470;
L_80D470:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD470u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD470u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD470u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D470 AND
    cpu.logicAnd(0x2000u);
    goto L_80D473;
L_80D473:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD473u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD473u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD473u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D473 BEQ -> $80D478
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D478; }
    goto L_80D475;
L_80D475:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD475u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD475u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD475u, 6u, 3u, cpu.address("abs", 0xD486u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D475 JSR -> $80D486 stack real
    { cpu.push16Value(hw,0xD477u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD478u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD486u), 0x80D475u); }
    goto L_80D478;
L_80D478:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD478u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD478u,0x80D478u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD478u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD478u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D478 DEY
    cpu.decReg('Y');
    goto L_80D479;
L_80D479:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD479u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD479u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD479u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D479 DEY
    cpu.decReg('Y');
    goto L_80D47A;
L_80D47A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD47Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD47Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD47Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D47A BPL -> $80D463
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80D463; }
    goto L_80D47C;
L_80D47C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD47Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD47Cu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD47Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D47C LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D47E;
L_80D47E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD47Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD47Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD47Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D47E LDA
    cpu.setA(0xFFFFu, 16);
    goto L_80D481;
L_80D481:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD481u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD481u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD481u, 6u, 4u, ((0x7E2440u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D481 STA
    hw.write(((0x7E2440u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D485;
L_80D485:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD485u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD485u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD485u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D485 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x80D485u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x80D485u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82989B_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82989Bu: goto L_82989B;
    case 0x82989Du: goto L_82989D;
    case 0x8298A0u: goto L_8298A0;
    case 0x8298A3u: goto L_8298A3;
    case 0x8298A5u: goto L_8298A5;
    case 0x8298A8u: goto L_8298A8;
    case 0x8298AAu: goto L_8298AA;
    case 0x8298ACu: goto L_8298AC;
    case 0x8298AFu: goto L_8298AF;
    case 0x8298B2u: goto L_8298B2;
    case 0x8298B4u: goto L_8298B4;
    case 0x8298B7u: goto L_8298B7;
    case 0x8298BAu: goto L_8298BA;
    case 0x8298BBu: goto L_8298BB;
    case 0x8298BEu: goto L_8298BE;
    case 0x8298C1u: goto L_8298C1;
    case 0x8298C4u: goto L_8298C4;
    case 0x8298C6u: goto L_8298C6;
    case 0x8298C9u: goto L_8298C9;
    case 0x8298CBu: goto L_8298CB;
    case 0x8298CEu: goto L_8298CE;
    case 0x8298D1u: goto L_8298D1;
    case 0x8298D3u: goto L_8298D3;
    case 0x8298D6u: goto L_8298D6;
    case 0x8298D8u: goto L_8298D8;
    case 0x8298DBu: goto L_8298DB;
    case 0x8298DCu: goto L_8298DC;
    case 0x8298DFu: goto L_8298DF;
    case 0x8298E2u: goto L_8298E2;
    case 0x8298E5u: goto L_8298E5;
    case 0x8298E6u: goto L_8298E6;
    case 0x8298E9u: goto L_8298E9;
    case 0x8298EBu: goto L_8298EB;
    case 0x8298EEu: goto L_8298EE;
    case 0x8298F1u: goto L_8298F1;
    case 0x8298F3u: goto L_8298F3;
    case 0x8298F6u: goto L_8298F6;
    case 0x8298F8u: goto L_8298F8;
    case 0x8298FBu: goto L_8298FB;
    case 0x8298FEu: goto L_8298FE;
    case 0x829901u: goto L_829901;
    case 0x829903u: goto L_829903;
    case 0x829906u: goto L_829906;
    case 0x829908u: goto L_829908;
    case 0x82990Bu: goto L_82990B;
    case 0x82990Cu: goto L_82990C;
    case 0x82990Fu: goto L_82990F;
    case 0x829911u: goto L_829911;
    case 0x829914u: goto L_829914;
    case 0x829915u: goto L_829915;
    case 0x829918u: goto L_829918;
    case 0x82991Bu: goto L_82991B;
    case 0x82991Eu: goto L_82991E;
    case 0x829921u: goto L_829921;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82989B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x989Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x989Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x989Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82989B STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_82989D;
L_82989D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x989Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x989Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x989Du, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82989D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8298A0;
L_8298A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98A0u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98A0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298A0 CMP
    cpu.compareA(0x1u);
    goto L_8298A3;
L_8298A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98A3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298A3 BNE -> $8298A8
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8298A8; }
    goto L_8298A5;
L_8298A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98A5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98A5u, 6u, 3u, cpu.address("abs", 0xD3F0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8298A5 JSR -> $82D3F0 stack real
    { cpu.push16Value(hw,0x98A7u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x98A8u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD3F0u), 0x8298A5u); }
    goto L_8298A8;
L_8298A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98A8u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x98A8u,0x8298A8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98A8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98A8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298A8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8298AA;
L_8298AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98AAu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98AAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298AA LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8298AC;
L_8298AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98ACu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98ACu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298AC AND
    cpu.logicAnd(0xF000u);
    goto L_8298AF;
L_8298AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98AFu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98AFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298AF CMP
    cpu.compareA(0xF000u);
    goto L_8298B2;
L_8298B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298B2 BEQ -> $8298BB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8298BB; }
    goto L_8298B4;
L_8298B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B4u, 6u, 3u, cpu.address("abs", 0x99B9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8298B4 JSR -> $8299B9 stack real
    { cpu.push16Value(hw,0x98B6u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x98B7u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x99B9u), 0x8298B4u); }
    goto L_8298B7;
L_8298B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x98B7u,0x8298B7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B7u, 6u, 3u, cpu.address("abs", 0x9922u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8298B7 JSR -> $829922 stack real
    { cpu.push16Value(hw,0x98B9u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x98BAu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9922u), 0x8298B7u); }
    goto L_8298BA;
L_8298BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98BAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x98BAu,0x8298BAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98BAu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98BAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8298BA RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8298BAu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8298BAu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_8298BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98BBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98BBu, 5u + 1u, 3u, cpu.address("absx", 0x02F2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298BB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2F2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8298BE;
L_8298BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98BEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98BEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298BE AND
    cpu.logicAnd(0xFF00u);
    goto L_8298C1;
L_8298C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298C1 CMP
    cpu.compareA(0xFF00u);
    goto L_8298C4;
L_8298C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298C4 BEQ -> $8298E6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8298E6; }
    goto L_8298C6;
L_8298C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C6u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C6u, 6u, 3u, cpu.address("abs", 0x99B9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8298C6 JSR -> $8299B9 stack real
    { cpu.push16Value(hw,0x98C8u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x98C9u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x99B9u), 0x8298C6u); }
    goto L_8298C9;
L_8298C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x98C9u,0x8298C9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C9u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298C9 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8298CB;
L_8298CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98CBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98CBu, 5u + 1u, 3u, cpu.address("absx", 0x02F2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298CB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2F2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8298CE;
L_8298CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98CEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98CEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298CE AND
    cpu.logicAnd(0xFFu);
    goto L_8298D1;
L_8298D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98D1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98D1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298D1 BEQ -> $8298DC
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8298DC; }
    goto L_8298D3;
L_8298D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98D3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98D3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298D3 LDA
    cpu.setA(0x2u, 16);
    goto L_8298D6;
L_8298D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98D6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98D6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298D6 STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_8298D8;
L_8298D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98D8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98D8u, 6u, 3u, cpu.address("abs", 0x99A6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8298D8 JSR -> $8299A6 stack real
    { cpu.push16Value(hw,0x98DAu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x98DBu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x99A6u), 0x8298D8u); }
    goto L_8298DB;
L_8298DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98DBu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x98DBu,0x8298DBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98DBu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98DBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8298DB RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8298DBu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8298DBu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_8298DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98DCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98DCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298DC LDA
    cpu.setA(0xFF08u, 16);
    goto L_8298DF;
L_8298DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98DFu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98DFu, 6u, 3u, cpu.address("absx", 0x02F2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298DF STA
    hw.write(cpu.address("absx", 0x2F2u), cpu.a, cpu.m8?8:16);
    goto L_8298E2;
L_8298E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98E2u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98E2u, 6u, 3u, cpu.address("absx", 0x0406u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298E2 STZ
    hw.write(cpu.address("absx", 0x406u), 0, cpu.m8?8:16);
    goto L_8298E5;
L_8298E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98E5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98E5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8298E5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8298E5u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8298E5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_8298E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98E6u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98E6u, 5u + 1u, 3u, cpu.address("absx", 0x029Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298E6 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x29Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8298E9;
L_8298E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98E9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98E9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298E9 BEQ -> $8298EE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8298EE; }
    goto L_8298EB;
L_8298EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98EBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98EBu, 6u, 3u, cpu.address("abs", 0x99B9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8298EB JSR -> $8299B9 stack real
    { cpu.push16Value(hw,0x98EDu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x98EEu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x99B9u), 0x8298EBu); }
    goto L_8298EE;
L_8298EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98EEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x98EEu,0x8298EEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98EEu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98EEu, 9u, 3u, cpu.address("absx", 0x0406u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298EE DEC
    cpu.decMem(hw, cpu.address("absx", 0x406u), cpu.m8?8:16);
    goto L_8298F1;
L_8298F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F1u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298F1 BPL -> $82990B
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82990B; }
    goto L_8298F3;
L_8298F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F3u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F3u, 5u + 1u, 3u, cpu.address("absx", 0x0414u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298F3 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x414u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8298F6;
L_8298F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298F6 BNE -> $8298FB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8298FB; }
    goto L_8298F8;
L_8298F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F8u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F8u, 9u, 3u, cpu.address("absx", 0x0414u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298F8 INC
    cpu.incMem(hw, cpu.address("absx", 0x414u), cpu.m8?8:16);
    goto L_8298FB;
L_8298FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98FBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98FBu, 5u + 1u, 3u, cpu.address("absx", 0x02F2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298FB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2F2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8298FE;
L_8298FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98FEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98FEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8298FE AND
    cpu.logicAnd(0xFFu);
    goto L_829901;
L_829901:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9901u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9901u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9901u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829901 BEQ -> $82990C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82990C; }
    goto L_829903;
L_829903:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9903u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9903u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9903u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829903 LDA
    cpu.setA(0x1u, 16);
    goto L_829906;
L_829906:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9906u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9906u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9906u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829906 STA
    hw.write(cpu.address("dp", 0x5Fu), cpu.a, cpu.m8?8:16);
    goto L_829908;
L_829908:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9908u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9908u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9908u, 6u, 3u, cpu.address("abs", 0x99A6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829908 JSR -> $8299A6 stack real
    { cpu.push16Value(hw,0x990Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x990Bu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x99A6u), 0x829908u); }
    goto L_82990B;
L_82990B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x990Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x990Bu,0x82990Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x990Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x990Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82990B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82990Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82990Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82990C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x990Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x990Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x990Cu, 5u + 1u, 3u, cpu.address("absx", 0x029Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82990C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x29Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82990F;
L_82990F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x990Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x990Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x990Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82990F BEQ -> $829915
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_829915; }
    goto L_829911;
L_829911:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9911u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9911u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9911u, 6u, 3u, cpu.address("abs", 0x99B9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829911 JSR -> $8299B9 stack real
    { cpu.push16Value(hw,0x9913u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9914u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x99B9u), 0x829911u); }
    goto L_829914;
L_829914:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9914u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9914u,0x829914u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9914u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9914u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829914 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829914u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829914u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_829915:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9915u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9915u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9915u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829915 LDA
    cpu.setA(0xFFFFu, 16);
    goto L_829918;
L_829918:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9918u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9918u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9918u, 6u, 3u, cpu.address("absx", 0x02F2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829918 STA
    hw.write(cpu.address("absx", 0x2F2u), cpu.a, cpu.m8?8:16);
    goto L_82991B;
L_82991B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x991Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x991Bu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x991Bu, 6u, 3u, cpu.address("absx", 0x0406u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82991B STZ
    hw.write(cpu.address("absx", 0x406u), 0, cpu.m8?8:16);
    goto L_82991E;
L_82991E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x991Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x991Eu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x991Eu, 6u, 3u, cpu.address("absx", 0x0408u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82991E STZ
    hw.write(cpu.address("absx", 0x408u), 0, cpu.m8?8:16);
    goto L_829921;
L_829921:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9921u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9921u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9921u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829921 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829921u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829921u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8299A6_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8299A6u: goto L_8299A6;
    case 0x8299A9u: goto L_8299A9;
    case 0x8299AAu: goto L_8299AA;
    case 0x8299ACu: goto L_8299AC;
    case 0x8299AFu: goto L_8299AF;
    case 0x8299B2u: goto L_8299B2;
    case 0x8299B3u: goto L_8299B3;
    case 0x8299B5u: goto L_8299B5;
    case 0x8299B8u: goto L_8299B8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8299A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99A6u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99A6u, 5u + 1u, 3u, cpu.address("absx", 0x028Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8299A6 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x28Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8299A9;
L_8299A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99A9u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99A9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8299A9 CLC
    cpu.setFlag('C', false);
    goto L_8299AA;
L_8299AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99AAu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99AAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8299AA ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16));
    goto L_8299AC;
L_8299AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99ACu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99ACu, 6u, 3u, cpu.address("absx", 0x028Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8299AC STA
    hw.write(cpu.address("absx", 0x28Eu), cpu.a, cpu.m8?8:16);
    goto L_8299AF;
L_8299AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99AFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99AFu, 5u + 1u, 3u, cpu.address("absx", 0x02F2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8299AF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2F2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8299B2;
L_8299B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99B2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99B2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8299B2 SEC
    cpu.setFlag('C', true);
    goto L_8299B3;
L_8299B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99B3u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99B3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8299B3 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16));
    goto L_8299B5;
L_8299B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99B5u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99B5u, 6u, 3u, cpu.address("absx", 0x02F2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8299B5 STA
    hw.write(cpu.address("absx", 0x2F2u), cpu.a, cpu.m8?8:16);
    goto L_8299B8;
L_8299B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x99B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x99B8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x99B8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8299B8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x8299B8u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x8299B8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_829ADA_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829ADAu: goto L_829ADA;
    case 0x829ADCu: goto L_829ADC;
    case 0x829ADEu: goto L_829ADE;
    case 0x829AE0u: goto L_829AE0;
    case 0x829AE3u: goto L_829AE3;
    case 0x829AE5u: goto L_829AE5;
    case 0x829AE7u: goto L_829AE7;
    case 0x829AE9u: goto L_829AE9;
    case 0x829AEBu: goto L_829AEB;
    case 0x829AECu: goto L_829AEC;
    case 0x829AEEu: goto L_829AEE;
    case 0x829AEFu: goto L_829AEF;
    case 0x829AF2u: goto L_829AF2;
    case 0x829AF3u: goto L_829AF3;
    case 0x829AF5u: goto L_829AF5;
    case 0x829AF7u: goto L_829AF7;
    case 0x829AFAu: goto L_829AFA;
    case 0x829AFDu: goto L_829AFD;
    case 0x829AFFu: goto L_829AFF;
    case 0x829B02u: goto L_829B02;
    case 0x829B03u: goto L_829B03;
    case 0x829B04u: goto L_829B04;
    case 0x829B05u: goto L_829B05;
    case 0x829B06u: goto L_829B06;
    case 0x829B07u: goto L_829B07;
    case 0x829B08u: goto L_829B08;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829ADA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ADAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ADAu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ADAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829ADA SEP
    cpu.sep(0x20u);
    goto L_829ADC;
L_829ADC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ADCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ADCu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ADCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829ADC LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829ADE;
L_829ADE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ADEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ADEu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ADEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829ADE LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829AE0;
L_829AE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AE0u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE0u, 4u + 1u, 3u, cpu.address("absy", 0x025Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AE0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x25Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829AE3;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE0u, 4u + 1u, 3u, cpu.address("absy", 0x025Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AE0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x25Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829AE3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9AE0u,0x829AE0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829AE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AE3u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE3u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AE3 BPL -> $829AEC
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_829AEC; }
    goto L_829AE5;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE3u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AE3 BPL -> $829AEC
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_829AEC; }
    goto L_829AE5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9AE3u,0x829AE3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829AE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AE5u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE5u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AE5 CMP
    cpu.compareA(0x80u);
    goto L_829AE7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE5u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AE5 CMP
    cpu.compareA(0x80u);
    goto L_829AE7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9AE5u,0x829AE5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829AE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AE7 BNE -> $829B02
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829B02; }
    goto L_829AE9;
L_829AE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE9u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AE9 REP
    cpu.rep(0x20u);
    goto L_829AEB;
L_829AEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AEBu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AEBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829AEB RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829AEBu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829AEBu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_829AEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AECu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AECu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AEC LDA
    cpu.setA(0x0u, 8);
    goto L_829AEE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AECu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AEC LDA
    cpu.setA(0x0u, 8);
    goto L_829AEE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9AECu,0x829AECu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829AEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AEEu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AEEu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AEEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AEE SEC
    cpu.setFlag('C', true);
    goto L_829AEF;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AEEu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AEEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AEE SEC
    cpu.setFlag('C', true);
    goto L_829AEF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9AEEu,0x829AEEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829AEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AEFu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AEFu, 4u + 1u, 3u, cpu.address("absy", 0x025Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AEF SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x25Fu), cpu.m8?8:16));
    goto L_829AF2;
L_829AF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AF2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AF2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AF2 SEC
    cpu.setFlag('C', true);
    goto L_829AF3;
L_829AF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AF3u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AF3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AF3 SBC
    cpu.sbc(0x8u);
    goto L_829AF5;
L_829AF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AF5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AF5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AF5 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_829AF7;
L_829AF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AF7u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AF7u, 4u + 1u, 3u, cpu.address("absy", 0x025Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AF7 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x25Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829AFA;
L_829AFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AFAu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AFAu, 5u, 3u, cpu.address("absy", 0x025Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AFA STA
    hw.write(cpu.address("absy", 0x25Fu), cpu.a, cpu.m8?8:16);
    goto L_829AFD;
L_829AFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AFDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AFDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AFD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829AFF;
L_829AFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AFFu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AFFu, 5u, 3u, cpu.address("absy", 0x025Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AFF STA
    hw.write(cpu.address("absy", 0x25Eu), cpu.a, cpu.m8?8:16);
    goto L_829B02;
L_829B02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B02u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B02u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B02 INY
    cpu.inc('Y');
    goto L_829B03;
L_829B03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B03u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B03u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B03 INY
    cpu.inc('Y');
    goto L_829B04;
L_829B04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B04u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B04u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B04 INY
    cpu.inc('Y');
    goto L_829B05;
L_829B05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B05u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B05u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B05 INY
    cpu.inc('Y');
    goto L_829B06;
L_829B06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B06u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B06u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B06 INY
    cpu.inc('Y');
    goto L_829B07;
L_829B07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B07u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B07u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B07 INY
    cpu.inc('Y');
    goto L_829B08;
L_829B08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B08u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B08u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B08 BRA -> $829AE0
    goto L_829AE0;
}

void sub_829ADA_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829ADAu: goto L_829ADA;
    case 0x829ADCu: goto L_829ADC;
    case 0x829ADEu: goto L_829ADE;
    case 0x829AE0u: goto L_829AE0;
    case 0x829AE3u: goto L_829AE3;
    case 0x829AE5u: goto L_829AE5;
    case 0x829AE7u: goto L_829AE7;
    case 0x829AE9u: goto L_829AE9;
    case 0x829AEBu: goto L_829AEB;
    case 0x829AECu: goto L_829AEC;
    case 0x829AEEu: goto L_829AEE;
    case 0x829AEFu: goto L_829AEF;
    case 0x829AF2u: goto L_829AF2;
    case 0x829AF3u: goto L_829AF3;
    case 0x829AF5u: goto L_829AF5;
    case 0x829AF7u: goto L_829AF7;
    case 0x829AFAu: goto L_829AFA;
    case 0x829AFDu: goto L_829AFD;
    case 0x829AFFu: goto L_829AFF;
    case 0x829B02u: goto L_829B02;
    case 0x829B03u: goto L_829B03;
    case 0x829B04u: goto L_829B04;
    case 0x829B05u: goto L_829B05;
    case 0x829B06u: goto L_829B06;
    case 0x829B07u: goto L_829B07;
    case 0x829B08u: goto L_829B08;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829ADA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ADAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ADAu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ADAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829ADA SEP
    cpu.sep(0x20u);
    goto L_829ADC;
L_829ADC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ADCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ADCu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ADCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829ADC LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829ADE;
L_829ADE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ADEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ADEu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ADEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829ADE LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829AE0;
L_829AE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE0u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE0u, 4u + 1u, 3u, cpu.address("absy", 0x025Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AE0 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x25Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829AE3;
L_829AE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE3u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AE3 BPL -> $829AEC
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_829AEC; }
    goto L_829AE5;
L_829AE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE5u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AE5 CMP
    cpu.compareA(0x80u);
    goto L_829AE7;
L_829AE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE7u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AE7 BNE -> $829B02
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829B02; }
    goto L_829AE9;
L_829AE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE9u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AE9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AE9 REP
    cpu.rep(0x20u);
    goto L_829AEB;
L_829AEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AEBu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AEBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829AEB RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829AEBu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829AEBu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_829AEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AECu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AEC LDA
    cpu.setA(0x0u, 8);
    goto L_829AEE;
L_829AEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AEEu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AEEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AEE SEC
    cpu.setFlag('C', true);
    goto L_829AEF;
L_829AEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AEFu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AEFu, 4u + 1u, 3u, cpu.address("absy", 0x025Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AEF SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x25Fu), cpu.m8?8:16));
    goto L_829AF2;
L_829AF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AF2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AF2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AF2 SEC
    cpu.setFlag('C', true);
    goto L_829AF3;
L_829AF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AF3u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AF3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AF3 SBC
    cpu.sbc(0x8u);
    goto L_829AF5;
L_829AF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AF5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AF5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AF5 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_829AF7;
L_829AF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AF7u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AF7u, 4u + 1u, 3u, cpu.address("absy", 0x025Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AF7 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x25Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829AFA;
L_829AFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AFAu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AFAu, 5u, 3u, cpu.address("absy", 0x025Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AFA STA
    hw.write(cpu.address("absy", 0x25Fu), cpu.a, cpu.m8?8:16);
    goto L_829AFD;
L_829AFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AFDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AFDu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AFD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829AFF;
L_829AFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AFFu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AFFu, 5u, 3u, cpu.address("absy", 0x025Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AFF STA
    hw.write(cpu.address("absy", 0x25Eu), cpu.a, cpu.m8?8:16);
    goto L_829B02;
L_829B02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B02u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B02u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B02 INY
    cpu.inc('Y');
    goto L_829B03;
L_829B03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B03u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B03u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B03 INY
    cpu.inc('Y');
    goto L_829B04;
L_829B04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B04u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B04u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B04 INY
    cpu.inc('Y');
    goto L_829B05;
L_829B05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B05u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B05u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B05 INY
    cpu.inc('Y');
    goto L_829B06;
L_829B06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B06u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B06u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B06 INY
    cpu.inc('Y');
    goto L_829B07;
L_829B07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B07u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B07u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B07 INY
    cpu.inc('Y');
    goto L_829B08;
L_829B08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B08u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B08u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B08 BRA -> $829AE0
    goto L_829AE0;
}

void sub_829B53_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829B53u: goto L_829B53;
    case 0x829B56u: goto L_829B56;
    case 0x829B58u: goto L_829B58;
    case 0x829B5Bu: goto L_829B5B;
    case 0x829B5Eu: goto L_829B5E;
    case 0x829B61u: goto L_829B61;
    case 0x829B63u: goto L_829B63;
    case 0x829B66u: goto L_829B66;
    case 0x829B68u: goto L_829B68;
    case 0x829B6Bu: goto L_829B6B;
    case 0x829B6Eu: goto L_829B6E;
    case 0x829B6Fu: goto L_829B6F;
    case 0x829B70u: goto L_829B70;
    case 0x829B73u: goto L_829B73;
    case 0x829B83u: goto L_829B83;
    case 0x829B86u: goto L_829B86;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829B53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B53u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B53u, 6u, 3u, cpu.address("abs", 0xC01Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829B53 JSR -> $82C01D stack real
    { cpu.push16Value(hw,0x9B55u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9B56u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC01Du), 0x829B53u); }
    goto L_829B56;
L_829B56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B56u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9B56u,0x829B56u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B56u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B56u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B56 BNE -> $829B83
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829B83; }
    goto L_829B58;
L_829B58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B58u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B58u, 6u, 3u, cpu.address("abs", 0xBF6Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829B58 JSR -> $82BF6E stack real
    { cpu.push16Value(hw,0x9B5Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9B5Bu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBF6Eu), 0x829B58u); }
    goto L_829B5B;
L_829B5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B5Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Bu, 5u, 3u, cpu.address("abs", 0x013Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B5B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829B5E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Bu, 5u, 3u, cpu.address("abs", 0x013Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B5B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829B5E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9B5Bu,0x829B5Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829B5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B5Eu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Eu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Eu, 5u, 3u, cpu.address("abs", 0x0139u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B5E ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x139u), cpu.m8?8:16));
    goto L_829B61;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Eu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Eu, 5u, 3u, cpu.address("abs", 0x0139u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B5E ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x139u), cpu.m8?8:16));
    goto L_829B61;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9B5Eu,0x829B5Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829B61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B61u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B61u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B61u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B61 BNE -> $829B83
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829B83; }
    goto L_829B63;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B61u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B61u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B61 BNE -> $829B83
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829B83; }
    goto L_829B63;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9B61u,0x829B61u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829B63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B63u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B63u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B63u, 6u, 3u, cpu.address("abs", 0xA8DAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829B63 JSR -> $82A8DA stack real
    { cpu.push16Value(hw,0x9B65u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9B66u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA8DAu), 0x829B63u); }
    goto L_829B66;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B63u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B63u, 6u, 3u, cpu.address("abs", 0xA8DAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829B63 JSR -> $82A8DA stack real
    { cpu.push16Value(hw,0x9B65u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9B66u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA8DAu), 0x829B63u); }
    goto L_829B66;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9B63u,0x829B63u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829B66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B66u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9B66u,0x829B66u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B66u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B66u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B66 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829B68;
L_829B68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B68u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B68u, 5u + 1u, 3u, cpu.address("absy", 0x0200u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B68 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x200u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829B6B;
L_829B6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B6Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B6Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B6B AND
    cpu.logicAnd(0xFFu);
    goto L_829B6E;
L_829B6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B6Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B6Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B6E ASL
    cpu.aslA();
    goto L_829B6F;
L_829B6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B6Fu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B6Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B6F TAX
    cpu.transfer("TAX");
    goto L_829B70;
L_829B70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B70u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B70u, 5u, 3u, cpu.address("abs", 0x9B75u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829B70 PEA
    cpu.push16Value(hw, 0x9B75u);
    goto L_829B73;
L_829B73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B73u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B73u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x9B87u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $829B73 JMP (9B87,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x9B87u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x829B73u); return; }
L_829B83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B83u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B83u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B83u, 6u, 3u, cpu.address("abs", 0xBFDEu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829B83 JSR -> $82BFDE stack real
    { cpu.push16Value(hw,0x9B85u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9B86u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBFDEu), 0x829B83u); }
    goto L_829B86;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B83u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B83u, 6u, 3u, cpu.address("abs", 0xBFDEu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829B83 JSR -> $82BFDE stack real
    { cpu.push16Value(hw,0x9B85u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9B86u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBFDEu), 0x829B83u); }
    goto L_829B86;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9B83u,0x829B83u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_829B86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B86u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B86u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B86u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829B86 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829B86u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829B86u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B86u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B86u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829B86 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829B86u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829B86u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9B86u,0x829B86u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_829B53_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829B53u: goto L_829B53;
    case 0x829B56u: goto L_829B56;
    case 0x829B58u: goto L_829B58;
    case 0x829B5Bu: goto L_829B5B;
    case 0x829B5Eu: goto L_829B5E;
    case 0x829B61u: goto L_829B61;
    case 0x829B63u: goto L_829B63;
    case 0x829B66u: goto L_829B66;
    case 0x829B68u: goto L_829B68;
    case 0x829B6Bu: goto L_829B6B;
    case 0x829B6Eu: goto L_829B6E;
    case 0x829B6Fu: goto L_829B6F;
    case 0x829B70u: goto L_829B70;
    case 0x829B73u: goto L_829B73;
    case 0x829B83u: goto L_829B83;
    case 0x829B86u: goto L_829B86;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829B53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B53u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B53u, 6u, 3u, cpu.address("abs", 0xC01Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829B53 JSR -> $82C01D stack real
    { cpu.push16Value(hw,0x9B55u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9B56u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC01Du), 0x829B53u); }
    goto L_829B56;
L_829B56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B56u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9B56u,0x829B56u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B56u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B56u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B56 BNE -> $829B83
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829B83; }
    goto L_829B58;
L_829B58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B58u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B58u, 6u, 3u, cpu.address("abs", 0xBF6Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829B58 JSR -> $82BF6E stack real
    { cpu.push16Value(hw,0x9B5Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9B5Bu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBF6Eu), 0x829B58u); }
    goto L_829B5B;
L_829B5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B5Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9B5Bu,0x829B5Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Bu, 5u, 3u, cpu.address("abs", 0x013Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B5B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829B5E;
L_829B5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Eu,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B5Eu, 5u, 3u, cpu.address("abs", 0x0139u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B5E ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x139u), cpu.m8?8:16));
    goto L_829B61;
L_829B61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B61u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B61u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B61 BNE -> $829B83
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_829B83; }
    goto L_829B63;
L_829B63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B63u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B63u, 6u, 3u, cpu.address("abs", 0xA8DAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829B63 JSR -> $82A8DA stack real
    { cpu.push16Value(hw,0x9B65u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9B66u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA8DAu), 0x829B63u); }
    goto L_829B66;
L_829B66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B66u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9B66u,0x829B66u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B66u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B66u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B66 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_829B68;
L_829B68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B68u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B68u, 5u + 1u, 3u, cpu.address("absy", 0x0200u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B68 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x200u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829B6B;
L_829B6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B6Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B6Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B6B AND
    cpu.logicAnd(0xFFu);
    goto L_829B6E;
L_829B6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B6Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B6Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B6E ASL
    cpu.aslA();
    goto L_829B6F;
L_829B6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B6Fu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B6Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B6F TAX
    cpu.transfer("TAX");
    goto L_829B70;
L_829B70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B70u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B70u, 5u, 3u, cpu.address("abs", 0x9B75u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829B70 PEA
    cpu.push16Value(hw, 0x9B75u);
    goto L_829B73;
L_829B73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B73u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B73u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x9B87u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $829B73 JMP (9B87,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x9B87u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x829B73u); return; }
L_829B83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B83u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B83u, 6u, 3u, cpu.address("abs", 0xBFDEu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829B83 JSR -> $82BFDE stack real
    { cpu.push16Value(hw,0x9B85u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9B86u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBFDEu), 0x829B83u); }
    goto L_829B86;
L_829B86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B86u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9B86u,0x829B86u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B86u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B86u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829B86 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829B86u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829B86u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_829B76_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829B76u: goto L_829B76;
    case 0x829B78u: goto L_829B78;
    case 0x829B7Bu: goto L_829B7B;
    case 0x829B7Eu: goto L_829B7E;
    case 0x829B81u: goto L_829B81;
    case 0x829B86u: goto L_829B86;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829B76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B76u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B76u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B76 REP
    cpu.rep(0x20u);
    goto L_829B78;
L_829B78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B78u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B78u, 6u, 3u, cpu.address("abs", 0xCE15u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829B78 JSR -> $82CE15 stack real
    { cpu.push16Value(hw,0x9B7Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9B7Bu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCE15u), 0x829B78u); }
    goto L_829B7B;
L_829B7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B7Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9B7Bu,0x829B7Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B7Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B7Bu, 6u, 3u, cpu.address("abs", 0xA2A0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829B7B JSR -> $82A2A0 stack real
    { cpu.push16Value(hw,0x9B7Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9B7Eu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA2A0u), 0x829B7Bu); }
    goto L_829B7E;
L_829B7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B7Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9B7Eu,0x829B7Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B7Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B7Eu, 6u, 3u, cpu.address("abs", 0x9860u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829B7E JSR -> $829860 stack real
    { cpu.push16Value(hw,0x9B80u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9B81u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9860u), 0x829B7Eu); }
    goto L_829B81;
L_829B81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B81u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9B81u,0x829B81u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B81u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B81u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B81 BRA -> $829B86
    goto L_829B86;
L_829B86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B86u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B86u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829B86 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829B86u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829B86u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_829B76_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829B76u: goto L_829B76;
    case 0x829B78u: goto L_829B78;
    case 0x829B7Bu: goto L_829B7B;
    case 0x829B7Eu: goto L_829B7E;
    case 0x829B81u: goto L_829B81;
    case 0x829B86u: goto L_829B86;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829B76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B76u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B76u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B76 REP
    cpu.rep(0x20u);
    goto L_829B78;
L_829B78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B78u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B78u, 6u, 3u, cpu.address("abs", 0xCE15u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829B78 JSR -> $82CE15 stack real
    { cpu.push16Value(hw,0x9B7Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9B7Bu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCE15u), 0x829B78u); }
    goto L_829B7B;
L_829B7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B7Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9B7Bu,0x829B7Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B7Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B7Bu, 6u, 3u, cpu.address("abs", 0xA2A0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829B7B JSR -> $82A2A0 stack real
    { cpu.push16Value(hw,0x9B7Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9B7Eu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA2A0u), 0x829B7Bu); }
    goto L_829B7E;
L_829B7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B7Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9B7Eu,0x829B7Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B7Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B7Eu, 6u, 3u, cpu.address("abs", 0x9860u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829B7E JSR -> $829860 stack real
    { cpu.push16Value(hw,0x9B80u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9B81u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9860u), 0x829B7Eu); }
    goto L_829B81;
L_829B81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B81u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9B81u,0x829B81u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B81u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B81u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829B81 BRA -> $829B86
    goto L_829B86;
L_829B86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9B86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9B86u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9B86u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829B86 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x829B86u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x829B86u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82A0BF_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82A0BFu: goto L_82A0BF;
    case 0x82A0C2u: goto L_82A0C2;
    case 0x82A0C5u: goto L_82A0C5;
    case 0x82A0C8u: goto L_82A0C8;
    case 0x82A0CBu: goto L_82A0CB;
    case 0x82A0CDu: goto L_82A0CD;
    case 0x82A0D0u: goto L_82A0D0;
    case 0x82A0D2u: goto L_82A0D2;
    case 0x82A0D5u: goto L_82A0D5;
    case 0x82A0D8u: goto L_82A0D8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82A0BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0BFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0BFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A0BF LDA
    cpu.setA(0xFFF8u, 16);
    goto L_82A0C2;
L_82A0C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0C2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0C2u, 5u, 3u, cpu.address("abs", 0x0143u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A0C2 STA
    hw.write(cpu.address("abs", 0x143u), cpu.a, cpu.m8?8:16);
    goto L_82A0C5;
L_82A0C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0C5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0C5u, 5u + 1u, 3u, cpu.address("absx", 0x0200u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A0C5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x200u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A0C8;
L_82A0C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0C8u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0C8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A0C8 CMP
    cpu.compareA(0x1u);
    goto L_82A0CB;
L_82A0CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0CBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0CBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A0CB BEQ -> $82A0D2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A0D2; }
    goto L_82A0CD;
L_82A0CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0CDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0CDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A0CD LDA
    cpu.setA(0x0u, 16);
    goto L_82A0D0;
L_82A0D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D0u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A0D0 BRA -> $82A0D5
    goto L_82A0D5;
L_82A0D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A0D2 LDA
    cpu.setA(0x8u, 16);
    goto L_82A0D5;
L_82A0D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D5u, 5u, 3u, cpu.address("abs", 0x0145u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A0D5 STA
    hw.write(cpu.address("abs", 0x145u), cpu.a, cpu.m8?8:16);
    goto L_82A0D8;
L_82A0D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A0D8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A0D8u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A0D8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82A0BF_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82A0BFu: goto L_82A0BF;
    case 0x82A0C2u: goto L_82A0C2;
    case 0x82A0C5u: goto L_82A0C5;
    case 0x82A0C8u: goto L_82A0C8;
    case 0x82A0CBu: goto L_82A0CB;
    case 0x82A0CDu: goto L_82A0CD;
    case 0x82A0D0u: goto L_82A0D0;
    case 0x82A0D2u: goto L_82A0D2;
    case 0x82A0D5u: goto L_82A0D5;
    case 0x82A0D8u: goto L_82A0D8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82A0BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0BFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0BFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A0BF LDA
    cpu.setA(0xFFF8u, 16);
    goto L_82A0C2;
L_82A0C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0C2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0C2u, 5u, 3u, cpu.address("abs", 0x0143u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A0C2 STA
    hw.write(cpu.address("abs", 0x143u), cpu.a, cpu.m8?8:16);
    goto L_82A0C5;
L_82A0C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0C5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0C5u, 5u + 1u, 3u, cpu.address("absx", 0x0200u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A0C5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x200u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A0C8;
L_82A0C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0C8u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0C8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A0C8 CMP
    cpu.compareA(0x1u);
    goto L_82A0CB;
L_82A0CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0CBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0CBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A0CB BEQ -> $82A0D2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A0D2; }
    goto L_82A0CD;
L_82A0CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0CDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0CDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A0CD LDA
    cpu.setA(0x0u, 16);
    goto L_82A0D0;
L_82A0D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D0u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A0D0 BRA -> $82A0D5
    goto L_82A0D5;
L_82A0D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A0D2 LDA
    cpu.setA(0x8u, 16);
    goto L_82A0D5;
L_82A0D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D5u, 5u, 3u, cpu.address("abs", 0x0145u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A0D5 STA
    hw.write(cpu.address("abs", 0x145u), cpu.a, cpu.m8?8:16);
    goto L_82A0D8;
L_82A0D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0D8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82A0D8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82A0D8u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82A0D8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82AC8A_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82AC8Au: goto L_82AC8A;
    case 0x82AC8Du: goto L_82AC8D;
    case 0x82AC8Fu: goto L_82AC8F;
    case 0x82AC91u: goto L_82AC91;
    case 0x82AC92u: goto L_82AC92;
    case 0x82AC94u: goto L_82AC94;
    case 0x82AC95u: goto L_82AC95;
    case 0x82AC97u: goto L_82AC97;
    case 0x82AC98u: goto L_82AC98;
    case 0x82AC9Bu: goto L_82AC9B;
    case 0x82AC9Du: goto L_82AC9D;
    case 0x82ACA0u: goto L_82ACA0;
    case 0x82ACA2u: goto L_82ACA2;
    case 0x82ACA4u: goto L_82ACA4;
    case 0x82ACA6u: goto L_82ACA6;
    case 0x82ACA9u: goto L_82ACA9;
    case 0x82ACABu: goto L_82ACAB;
    case 0x82ACADu: goto L_82ACAD;
    case 0x82ACAFu: goto L_82ACAF;
    case 0x82ACB0u: goto L_82ACB0;
    case 0x82ACB1u: goto L_82ACB1;
    case 0x82ACB3u: goto L_82ACB3;
    case 0x82ACB4u: goto L_82ACB4;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82AC8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC8Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC8Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC8A LDA
    cpu.setA(0x16u, 16);
    goto L_82AC8D;
L_82AC8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC8Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC8Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC8D STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82AC8F;
L_82AC8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC8Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC8Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC8F SEP
    cpu.sep(0x20u);
    goto L_82AC91;
L_82AC91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC91u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC91u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82AC91 PHB
    cpu.push("PHB", hw);
    goto L_82AC92;
L_82AC92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC92u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC92u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC92 LDA
    cpu.setA(0x7Eu, 8);
    goto L_82AC94;
L_82AC94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC94u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC94u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82AC94 PHA
    cpu.push("PHA", hw);
    goto L_82AC95;
L_82AC95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC95u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC95u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC95 REP
    cpu.rep(0x20u);
    goto L_82AC97;
L_82AC97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC97u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC97u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82AC97 PLB
    cpu.pop("PLB", hw);
    goto L_82AC98;
L_82AC98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC98u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC98u, 5u + 1u, 3u, cpu.address("absx", 0x2000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC98 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x2000u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82AC9B;
L_82AC9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC9Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC9Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC9B BEQ -> $82ACAF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82ACAF; }
    goto L_82AC9D;
L_82AC9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC9Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC9Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82AC9D CMP
    cpu.compareA(0xFFFFu);
    goto L_82ACA0;
L_82ACA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACA0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACA0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ACA0 BEQ -> $82ACAB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82ACAB; }
    goto L_82ACA2;
L_82ACA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACA2u,cpu,0x25u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACA2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ACA2 AND
    cpu.logicAnd(hw.readW(cpu.address("dp", 0x5Fu), cpu.m8?8:16));
    goto L_82ACA4;
L_82ACA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACA4u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACA4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x65u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ACA4 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x65u), cpu.m8?8:16));
    goto L_82ACA6;
L_82ACA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACA6u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACA6u, 6u, 3u, cpu.address("absx", 0x2000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ACA6 STA
    hw.write(cpu.address("absx", 0x2000u), cpu.a, cpu.m8?8:16);
    goto L_82ACA9;
L_82ACA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACA9u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACA9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ACA9 BRA -> $82ACAF
    goto L_82ACAF;
L_82ACAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACABu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACABu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ACAB DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_82ACAD;
L_82ACAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACADu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ACAD BMI -> $82ACB3
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82ACB3; }
    goto L_82ACAF;
L_82ACAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACAFu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACAFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ACAF DEX
    cpu.decReg('X');
    goto L_82ACB0;
L_82ACB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACB0u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACB0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ACB0 DEX
    cpu.decReg('X');
    goto L_82ACB1;
L_82ACB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACB1u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACB1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ACB1 BRA -> $82AC98
    goto L_82AC98;
L_82ACB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACB3u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACB3u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82ACB3 PLB
    cpu.pop("PLB", hw);
    goto L_82ACB4;
L_82ACB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xACB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xACB4u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xACB4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82ACB4 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82ACB4u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82ACB4u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B10C_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B10Cu: goto L_82B10C;
    case 0x82B10Fu: goto L_82B10F;
    case 0x82B112u: goto L_82B112;
    case 0x82B114u: goto L_82B114;
    case 0x82B117u: goto L_82B117;
    case 0x82B118u: goto L_82B118;
    case 0x82B11Bu: goto L_82B11B;
    case 0x82B11Cu: goto L_82B11C;
    case 0x82B11Fu: goto L_82B11F;
    case 0x82B122u: goto L_82B122;
    case 0x82B125u: goto L_82B125;
    case 0x82B128u: goto L_82B128;
    case 0x82B12Bu: goto L_82B12B;
    case 0x82B12Eu: goto L_82B12E;
    case 0x82B131u: goto L_82B131;
    case 0x82B134u: goto L_82B134;
    case 0x82B136u: goto L_82B136;
    case 0x82B139u: goto L_82B139;
    case 0x82B13Cu: goto L_82B13C;
    case 0x82B13Eu: goto L_82B13E;
    case 0x82B141u: goto L_82B141;
    case 0x82B142u: goto L_82B142;
    case 0x82B145u: goto L_82B145;
    case 0x82B146u: goto L_82B146;
    case 0x82B149u: goto L_82B149;
    case 0x82B14Cu: goto L_82B14C;
    case 0x82B14Fu: goto L_82B14F;
    case 0x82B152u: goto L_82B152;
    case 0x82B155u: goto L_82B155;
    case 0x82B158u: goto L_82B158;
    case 0x82B15Bu: goto L_82B15B;
    case 0x82B15Eu: goto L_82B15E;
    case 0x82B161u: goto L_82B161;
    case 0x82B163u: goto L_82B163;
    case 0x82B165u: goto L_82B165;
    case 0x82B167u: goto L_82B167;
    case 0x82B16Au: goto L_82B16A;
    case 0x82B16Eu: goto L_82B16E;
    case 0x82B170u: goto L_82B170;
    case 0x82B172u: goto L_82B172;
    case 0x82B174u: goto L_82B174;
    case 0x82B176u: goto L_82B176;
    case 0x82B178u: goto L_82B178;
    case 0x82B17Bu: goto L_82B17B;
    case 0x82B17Du: goto L_82B17D;
    case 0x82B17Fu: goto L_82B17F;
    case 0x82B182u: goto L_82B182;
    case 0x82B185u: goto L_82B185;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B10C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB10Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Cu, 5u, 3u, cpu.address("abs", 0x041Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B10C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x41Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B10F;
L_82B10F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB10Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB10Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B10F CMP
    cpu.compareA(0x3u);
    goto L_82B112;
L_82B112:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB112u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB112u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB112u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B112 BNE -> $82B136
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B136; }
    goto L_82B114;
L_82B114:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB114u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB114u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB114u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B114 LDA
    cpu.setA(0x14u, 16);
    goto L_82B117;
L_82B117:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB117u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB117u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB117u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B117 SEC
    cpu.setFlag('C', true);
    goto L_82B118;
L_82B118:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB118u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB118u,cpu,0xEDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB118u, 5u, 3u, cpu.address("abs", 0x0500u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B118 SBC
    cpu.sbc(hw.readW(cpu.address("abs", 0x500u), cpu.m8?8:16));
    goto L_82B11B;
L_82B11B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB11Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB11Bu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB11Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B11B INC
    cpu.inc('A');
    goto L_82B11C;
L_82B11C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB11Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB11Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB11Cu, 5u, 3u, cpu.address("abs", 0x0502u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B11C STA
    hw.write(cpu.address("abs", 0x502u), cpu.a, cpu.m8?8:16);
    goto L_82B11F;
L_82B11F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB11Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB11Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB11Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B11F LDA
    cpu.setA(0xFFFFu, 16);
    goto L_82B122;
L_82B122:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB122u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB122u,cpu,0x4Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB122u, 5u, 3u, cpu.address("abs", 0x0400u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B122 EOR
    cpu.logicXor(hw.readW(cpu.address("abs", 0x400u), cpu.m8?8:16));
    goto L_82B125;
L_82B125:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB125u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB125u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB125u, 5u, 3u, cpu.address("abs", 0x0402u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B125 STA
    hw.write(cpu.address("abs", 0x402u), cpu.a, cpu.m8?8:16);
    goto L_82B128;
L_82B128:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB128u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB128u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB128u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B128 LDA
    cpu.setA(0x8000u, 16);
    goto L_82B12B;
L_82B12B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB12Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB12Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB12Bu, 5u, 3u, cpu.address("abs", 0x0524u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B12B STA
    hw.write(cpu.address("abs", 0x524u), cpu.a, cpu.m8?8:16);
    goto L_82B12E;
L_82B12E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB12Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB12Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB12Eu, 5u, 3u, cpu.address("abs", 0x052Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B12E STA
    hw.write(cpu.address("abs", 0x52Cu), cpu.a, cpu.m8?8:16);
    goto L_82B131;
L_82B131:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB131u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB131u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB131u, 5u, 3u, cpu.address("abs", 0x0534u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B131 STA
    hw.write(cpu.address("abs", 0x534u), cpu.a, cpu.m8?8:16);
    goto L_82B134;
L_82B134:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB134u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB134u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB134u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B134 BRA -> $82B15E
    goto L_82B15E;
L_82B136:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB136u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB136u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB136u, 5u, 3u, cpu.address("abs", 0x051Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B136 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x51Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B139;
L_82B139:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB139u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB139u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB139u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B139 CMP
    cpu.compareA(0x3u);
    goto L_82B13C;
L_82B13C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB13Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB13Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB13Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B13C BNE -> $82B170
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B170; }
    goto L_82B13E;
L_82B13E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB13Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB13Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB13Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B13E LDA
    cpu.setA(0x14u, 16);
    goto L_82B141;
L_82B141:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB141u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB141u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB141u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B141 SEC
    cpu.setFlag('C', true);
    goto L_82B142;
L_82B142:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB142u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB142u,cpu,0xEDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB142u, 5u, 3u, cpu.address("abs", 0x0400u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B142 SBC
    cpu.sbc(hw.readW(cpu.address("abs", 0x400u), cpu.m8?8:16));
    goto L_82B145;
L_82B145:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB145u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB145u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB145u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B145 INC
    cpu.inc('A');
    goto L_82B146;
L_82B146:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB146u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB146u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB146u, 5u, 3u, cpu.address("abs", 0x0402u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B146 STA
    hw.write(cpu.address("abs", 0x402u), cpu.a, cpu.m8?8:16);
    goto L_82B149;
L_82B149:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB149u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB149u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB149u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B149 LDA
    cpu.setA(0xFFFFu, 16);
    goto L_82B14C;
L_82B14C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB14Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB14Cu,cpu,0x4Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB14Cu, 5u, 3u, cpu.address("abs", 0x0500u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B14C EOR
    cpu.logicXor(hw.readW(cpu.address("abs", 0x500u), cpu.m8?8:16));
    goto L_82B14F;
L_82B14F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB14Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB14Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB14Fu, 5u, 3u, cpu.address("abs", 0x0502u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B14F STA
    hw.write(cpu.address("abs", 0x502u), cpu.a, cpu.m8?8:16);
    goto L_82B152;
L_82B152:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB152u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB152u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB152u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B152 LDA
    cpu.setA(0x8000u, 16);
    goto L_82B155;
L_82B155:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB155u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB155u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB155u, 5u, 3u, cpu.address("abs", 0x0424u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B155 STA
    hw.write(cpu.address("abs", 0x424u), cpu.a, cpu.m8?8:16);
    goto L_82B158;
L_82B158:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB158u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB158u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB158u, 5u, 3u, cpu.address("abs", 0x042Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B158 STA
    hw.write(cpu.address("abs", 0x42Cu), cpu.a, cpu.m8?8:16);
    goto L_82B15B;
L_82B15B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB15Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB15Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB15Bu, 5u, 3u, cpu.address("abs", 0x0434u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B15B STA
    hw.write(cpu.address("abs", 0x434u), cpu.a, cpu.m8?8:16);
    goto L_82B15E;
L_82B15E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB15Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB15Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB15Eu, 5u, 3u, cpu.address("abs", 0x0141u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B15E STZ
    hw.write(cpu.address("abs", 0x141u), 0, cpu.m8?8:16);
    goto L_82B161;
L_82B161:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB161u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB161u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB161u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B161 SEP
    cpu.sep(0x20u);
    goto L_82B163;
L_82B163:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB163u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB163u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB163u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B163 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_82B165;
L_82B165:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB165u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB165u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB165u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B165 REP
    cpu.rep(0x20u);
    goto L_82B167;
L_82B167:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB167u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB167u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB167u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B167 LDA
    cpu.setA(0x2Bu, 16);
    goto L_82B16A;
L_82B16A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB16Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB16Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB16Au, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B16A JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB16Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB16Eu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x82B16Au); }
    goto L_82B16E;
L_82B16E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB16Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB16Eu,0x82B16Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB16Eu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB16Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B16E BRA -> $82B17D
    goto L_82B17D;
L_82B170:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB170u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB170u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB170u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B170 SEP
    cpu.sep(0x20u);
    goto L_82B172;
L_82B172:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB172u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB172u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB172u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B172 LDA
    cpu.setA(0xDu, 8);
    goto L_82B174;
L_82B174:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB174u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB174u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB174u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B174 STA
    hw.write(cpu.address("dp", 0x49u), cpu.a, cpu.m8?8:16);
    goto L_82B176;
L_82B176:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB176u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB176u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB176u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B176 REP
    cpu.rep(0x20u);
    goto L_82B178;
L_82B178:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB178u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB178u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB178u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B178 LDA
    cpu.setA(0x18u, 16);
    goto L_82B17B;
L_82B17B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB17Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB17Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB17Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B17B STA
    hw.write(cpu.address("dp", 0x6Fu), cpu.a, cpu.m8?8:16);
    goto L_82B17D;
L_82B17D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB17Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB17Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB17Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B17D REP
    cpu.rep(0x20u);
    goto L_82B17F;
L_82B17F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB17Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB17Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB17Fu, 6u, 3u, cpu.address("abs", 0xD5A3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B17F JSR -> $82D5A3 stack real
    { cpu.push16Value(hw,0xB181u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB182u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD5A3u), 0x82B17Fu); }
    goto L_82B182;
L_82B182:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB182u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB182u,0x82B182u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB182u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB182u, 6u, 3u, cpu.address("abs", 0xCAA5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B182 JSR -> $82CAA5 stack real
    { cpu.push16Value(hw,0xB184u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB185u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCAA5u), 0x82B182u); }
    goto L_82B185;
L_82B185:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB185u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB185u,0x82B185u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB185u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB185u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B185 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B185u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82B185u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82BA82_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82BA82u: goto L_82BA82;
    case 0x82BA83u: goto L_82BA83;
    case 0x82BA85u: goto L_82BA85;
    case 0x82BA87u: goto L_82BA87;
    case 0x82BA88u: goto L_82BA88;
    case 0x82BA8Au: goto L_82BA8A;
    case 0x82BA8Bu: goto L_82BA8B;
    case 0x82BA8Du: goto L_82BA8D;
    case 0x82BA8Fu: goto L_82BA8F;
    case 0x82BA92u: goto L_82BA92;
    case 0x82BA94u: goto L_82BA94;
    case 0x82BA97u: goto L_82BA97;
    case 0x82BA98u: goto L_82BA98;
    case 0x82BA9Bu: goto L_82BA9B;
    case 0x82BA9Cu: goto L_82BA9C;
    case 0x82BA9Fu: goto L_82BA9F;
    case 0x82BAA1u: goto L_82BAA1;
    case 0x82BAA3u: goto L_82BAA3;
    case 0x82BAA6u: goto L_82BAA6;
    case 0x82BAA8u: goto L_82BAA8;
    case 0x82BAABu: goto L_82BAAB;
    case 0x82BAADu: goto L_82BAAD;
    case 0x82BAB0u: goto L_82BAB0;
    case 0x82BAB2u: goto L_82BAB2;
    case 0x82BAB4u: goto L_82BAB4;
    case 0x82BAB6u: goto L_82BAB6;
    case 0x82BAB9u: goto L_82BAB9;
    case 0x82BABCu: goto L_82BABC;
    case 0x82BABEu: goto L_82BABE;
    case 0x82BAC0u: goto L_82BAC0;
    case 0x82BAC2u: goto L_82BAC2;
    case 0x82BAC4u: goto L_82BAC4;
    case 0x82BAC6u: goto L_82BAC6;
    case 0x82BAC7u: goto L_82BAC7;
    case 0x82BAC8u: goto L_82BAC8;
    case 0x82BACAu: goto L_82BACA;
    case 0x82BACBu: goto L_82BACB;
    case 0x82BACDu: goto L_82BACD;
    case 0x82BAD0u: goto L_82BAD0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82BA82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA82u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA82u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82BA82 PHB
    cpu.push("PHB", hw);
    goto L_82BA83;
L_82BA83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA83u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA83u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA83 SEP
    cpu.sep(0x20u);
    goto L_82BA85;
L_82BA85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA85u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA85u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA85 LDA
    cpu.setA(0x7Eu, 8);
    goto L_82BA87;
L_82BA87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA87u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA87u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82BA87 PHA
    cpu.push("PHA", hw);
    goto L_82BA88;
L_82BA88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA88u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA88u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA88 REP
    cpu.rep(0x20u);
    goto L_82BA8A;
L_82BA8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA8Au,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA8Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82BA8A PLB
    cpu.pop("PLB", hw);
    goto L_82BA8B;
L_82BA8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA8Bu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA8Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA8B LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82BA8D;
L_82BA8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA8Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA8Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA8D BNE -> $82BA94
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82BA94; }
    goto L_82BA8F;
L_82BA8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA8Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA8Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA8F LDA
    cpu.setA(0x0u, 16);
    goto L_82BA92;
L_82BA92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA92u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA92u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA92 BRA -> $82BA97
    goto L_82BA97;
L_82BA94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA94u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA94u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA94 LDA
    cpu.setA(0x220u, 16);
    goto L_82BA97;
L_82BA97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA97u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA97u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA97 CLC
    cpu.setFlag('C', false);
    goto L_82BA98;
L_82BA98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA98u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA98u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA98 ADC
    cpu.adc(0x1F8u);
    goto L_82BA9B;
L_82BA9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Bu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA9B TAY
    cpu.transfer("TAY");
    goto L_82BA9C;
L_82BA9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA9C LDA
    cpu.setA(0x10u, 16);
    goto L_82BA9F;
L_82BA9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BA9F STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82BAA1;
L_82BAA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAA1u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAA1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BAA1 STZ
    hw.write(cpu.address("dp", 0x2u), 0, cpu.m8?8:16);
    goto L_82BAA3;
L_82BAA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAA3u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAA3u, 5u + 1u, 3u, cpu.address("absy", 0x2000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BAA3 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2000u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BAA6;
L_82BAA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAA6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAA6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BAA6 BEQ -> $82BAC6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82BAC6; }
    goto L_82BAA8;
L_82BAA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAA8u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAA8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BAA8 CMP
    cpu.compareA(0xFFFFu);
    goto L_82BAAB;
L_82BAAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAABu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BAAB BEQ -> $82BAC2
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82BAC2; }
    goto L_82BAAD;
L_82BAAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAADu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAADu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BAAD BIT
    cpu.bit(0x2000u, true);
    goto L_82BAB0;
L_82BAB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAB0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAB0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BAB0 BEQ -> $82BAB6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82BAB6; }
    goto L_82BAB2;
L_82BAB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAB2u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAB2u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BAB2 INC
    cpu.incMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_82BAB4;
L_82BAB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAB4u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAB4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BAB4 BRA -> $82BAC6
    goto L_82BAC6;
L_82BAB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAB6u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAB6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BAB6 AND
    cpu.logicAnd(0xFu);
    goto L_82BAB9;
L_82BAB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAB9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAB9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BAB9 CMP
    cpu.compareA(0xFu);
    goto L_82BABC;
L_82BABC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBABCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBABCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBABCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BABC BNE -> $82BAC6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82BAC6; }
    goto L_82BABE;
L_82BABE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBABEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBABEu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBABEu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BABE INC
    cpu.incMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_82BAC0;
L_82BAC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC0u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BAC0 BRA -> $82BAC6
    goto L_82BAC6;
L_82BAC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC2u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC2u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BAC2 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_82BAC4;
L_82BAC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC4u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BAC4 BMI -> $82BACA
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82BACA; }
    goto L_82BAC6;
L_82BAC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC6u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BAC6 DEY
    cpu.decReg('Y');
    goto L_82BAC7;
L_82BAC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC7u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BAC7 DEY
    cpu.decReg('Y');
    goto L_82BAC8;
L_82BAC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC8u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAC8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BAC8 BPL -> $82BAA3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82BAA3; }
    goto L_82BACA;
L_82BACA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBACAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBACAu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBACAu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82BACA PLB
    cpu.pop("PLB", hw);
    goto L_82BACB;
L_82BACB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBACBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBACBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBACBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BACB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82BACD;
L_82BACD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBACDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBACDu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBACDu, 6u, 3u, cpu.address("absx", 0x044Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82BACD STA
    hw.write(cpu.address("absx", 0x44Au), cpu.a, cpu.m8?8:16);
    goto L_82BAD0;
L_82BAD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBAD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBAD0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBAD0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82BAD0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82BAD0u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82BAD0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82C910_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82C910u: goto L_82C910;
    case 0x82C912u: goto L_82C912;
    case 0x82C915u: goto L_82C915;
    case 0x82C916u: goto L_82C916;
    case 0x82C917u: goto L_82C917;
    case 0x82C919u: goto L_82C919;
    case 0x82C91Bu: goto L_82C91B;
    case 0x82C91Eu: goto L_82C91E;
    case 0x82C920u: goto L_82C920;
    case 0x82C924u: goto L_82C924;
    case 0x82C926u: goto L_82C926;
    case 0x82C929u: goto L_82C929;
    case 0x82C92Bu: goto L_82C92B;
    case 0x82C92Fu: goto L_82C92F;
    case 0x82C931u: goto L_82C931;
    case 0x82C933u: goto L_82C933;
    case 0x82C936u: goto L_82C936;
    case 0x82C938u: goto L_82C938;
    case 0x82C93Au: goto L_82C93A;
    case 0x82C93Cu: goto L_82C93C;
    case 0x82C93Eu: goto L_82C93E;
    case 0x82C941u: goto L_82C941;
    case 0x82C944u: goto L_82C944;
    case 0x82C948u: goto L_82C948;
    case 0x82C949u: goto L_82C949;
    case 0x82C94Au: goto L_82C94A;
    case 0x82C94Cu: goto L_82C94C;
    case 0x82C94Du: goto L_82C94D;
    case 0x82C94Eu: goto L_82C94E;
    case 0x82C950u: goto L_82C950;
    case 0x82C952u: goto L_82C952;
    case 0x82C954u: goto L_82C954;
    case 0x82C956u: goto L_82C956;
    case 0x82C957u: goto L_82C957;
    case 0x82C95Au: goto L_82C95A;
    case 0x82C95Cu: goto L_82C95C;
    case 0x82C95Eu: goto L_82C95E;
    case 0x82C960u: goto L_82C960;
    case 0x82C963u: goto L_82C963;
    case 0x82C966u: goto L_82C966;
    case 0x82C96Au: goto L_82C96A;
    case 0x82C96Bu: goto L_82C96B;
    case 0x82C96Cu: goto L_82C96C;
    case 0x82C96Eu: goto L_82C96E;
    case 0x82C96Fu: goto L_82C96F;
    case 0x82C970u: goto L_82C970;
    case 0x82C972u: goto L_82C972;
    case 0x82C974u: goto L_82C974;
    case 0x82C976u: goto L_82C976;
    case 0x82C978u: goto L_82C978;
    case 0x82C979u: goto L_82C979;
    case 0x82C97Cu: goto L_82C97C;
    case 0x82C97Eu: goto L_82C97E;
    case 0x82C980u: goto L_82C980;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82C910:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC910u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC910u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC910u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C910 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82C912;
L_82C912:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC912u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC912u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC912u, 5u + 1u, 3u, cpu.address("absx", 0x0400u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C912 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x400u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C915;
L_82C915:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC915u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC915u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC915u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C915 ASL
    cpu.aslA();
    goto L_82C916;
L_82C916:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC916u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC916u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC916u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C916 TAX
    cpu.transfer("TAX");
    goto L_82C917;
L_82C917:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC917u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC917u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC917u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C917 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Bu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C919;
L_82C919:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC919u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC919u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC919u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C919 BNE -> $82C926
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C926; }
    goto L_82C91B;
L_82C91B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC91Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC91Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC91Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C91B LDA
    cpu.setA(0x2u, 16);
    goto L_82C91E;
L_82C91E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC91Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC91Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC91Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C91E STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82C920;
L_82C920:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC920u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC920u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC920u, 6u, 4u, ((0x9E956Eu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C920 LDA
    cpu.loadA(hw.readW(((0x9E956Eu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C924;
L_82C924:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC924u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC924u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC924u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C924 BRA -> $82C92F
    goto L_82C92F;
L_82C926:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC926u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC926u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC926u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C926 LDA
    cpu.setA(0xFFFEu, 16);
    goto L_82C929;
L_82C929:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC929u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC929u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC929u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C929 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82C92B;
L_82C92B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC92Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC92Bu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC92Bu, 6u, 4u, ((0x9E9598u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C92B LDA
    cpu.loadA(hw.readW(((0x9E9598u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C92F;
L_82C92F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC92Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC92Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC92Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C92F STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82C931;
L_82C931:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC931u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC931u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC931u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C931 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82C933;
L_82C933:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC933u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC933u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC933u, 5u + 1u, 3u, cpu.address("absx", 0x0402u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C933 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x402u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C936;
L_82C936:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC936u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC936u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC936u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C936 STA
    hw.write(cpu.address("dp", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_82C938;
L_82C938:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC938u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC938u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC938u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C938 BEQ -> $82C980
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C980; }
    goto L_82C93A;
L_82C93A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC93Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC93Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC93Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C93A BPL -> $82C95E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82C95E; }
    goto L_82C93C;
L_82C93C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC93Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC93Cu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC93Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C93C LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82C93E;
L_82C93E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC93Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC93Eu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC93Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C93E LDY
    cpu.setY(0x9u, 16);
    goto L_82C941;
L_82C941:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC941u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC941u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC941u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C941 LDA
    cpu.setA(0x0u, 16);
    goto L_82C944;
L_82C944:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC944u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC944u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC944u, 6u, 4u, ((0x7E6040u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C944 STA
    hw.write(((0x7E6040u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82C948;
L_82C948:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC948u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC948u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC948u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C948 TXA
    cpu.transfer("TXA");
    goto L_82C949;
L_82C949:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC949u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC949u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC949u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C949 CLC
    cpu.setFlag('C', false);
    goto L_82C94A;
L_82C94A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC94Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC94Au,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC94Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C94A ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16));
    goto L_82C94C;
L_82C94C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC94Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC94Cu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC94Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C94C TAX
    cpu.transfer("TAX");
    goto L_82C94D;
L_82C94D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC94Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC94Du,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC94Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C94D DEY
    cpu.decReg('Y');
    goto L_82C94E;
L_82C94E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC94Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC94Eu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC94Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C94E BPL -> $82C941
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82C941; }
    goto L_82C950;
L_82C950:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC950u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC950u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC950u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C950 INC
    cpu.incMem(hw, cpu.address("dp", 0x4u), cpu.m8?8:16);
    goto L_82C952;
L_82C952:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC952u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC952u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC952u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C952 BEQ -> $82C980
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C980; }
    goto L_82C954;
L_82C954:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC954u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC954u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC954u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C954 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C956;
L_82C956:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC956u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC956u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC956u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C956 SEC
    cpu.setFlag('C', true);
    goto L_82C957;
L_82C957:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC957u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC957u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC957u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C957 SBC
    cpu.sbc(0x40u);
    goto L_82C95A;
L_82C95A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC95Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC95Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC95Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C95A STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82C95C;
L_82C95C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC95Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC95Cu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC95Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C95C BRA -> $82C93C
    goto L_82C93C;
L_82C95E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC95Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC95Eu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC95Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C95E LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82C960;
L_82C960:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC960u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC960u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC960u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C960 LDY
    cpu.setY(0x9u, 16);
    goto L_82C963;
L_82C963:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC963u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC963u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC963u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C963 LDA
    cpu.setA(0x3u, 16);
    goto L_82C966;
L_82C966:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC966u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC966u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC966u, 6u, 4u, ((0x7E6000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C966 STA
    hw.write(((0x7E6000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82C96A;
L_82C96A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC96Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC96Au,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC96Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C96A TXA
    cpu.transfer("TXA");
    goto L_82C96B;
L_82C96B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC96Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC96Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC96Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C96B CLC
    cpu.setFlag('C', false);
    goto L_82C96C;
L_82C96C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC96Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC96Cu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC96Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C96C ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16));
    goto L_82C96E;
L_82C96E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC96Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC96Eu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC96Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C96E TAX
    cpu.transfer("TAX");
    goto L_82C96F;
L_82C96F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC96Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC96Fu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC96Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C96F DEY
    cpu.decReg('Y');
    goto L_82C970;
L_82C970:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC970u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC970u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC970u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C970 BPL -> $82C963
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82C963; }
    goto L_82C972;
L_82C972:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC972u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC972u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC972u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C972 DEC
    cpu.decMem(hw, cpu.address("dp", 0x4u), cpu.m8?8:16);
    goto L_82C974;
L_82C974:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC974u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC974u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC974u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C974 BEQ -> $82C980
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82C980; }
    goto L_82C976;
L_82C976:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC976u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC976u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC976u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C976 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82C978;
L_82C978:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC978u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC978u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC978u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C978 CLC
    cpu.setFlag('C', false);
    goto L_82C979;
L_82C979:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC979u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC979u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC979u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C979 ADC
    cpu.adc(0x40u);
    goto L_82C97C;
L_82C97C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC97Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC97Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC97Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C97C STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82C97E;
L_82C97E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC97Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC97Eu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC97Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82C97E BRA -> $82C95E
    goto L_82C95E;
L_82C980:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC980u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC980u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC980u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82C980 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82C980u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82C980u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82D549_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82D549u: goto L_82D549;
    case 0x82D54Au: goto L_82D54A;
    case 0x82D54Cu: goto L_82D54C;
    case 0x82D54Eu: goto L_82D54E;
    case 0x82D54Fu: goto L_82D54F;
    case 0x82D551u: goto L_82D551;
    case 0x82D552u: goto L_82D552;
    case 0x82D555u: goto L_82D555;
    case 0x82D558u: goto L_82D558;
    case 0x82D55Au: goto L_82D55A;
    case 0x82D55Du: goto L_82D55D;
    case 0x82D55Fu: goto L_82D55F;
    case 0x82D562u: goto L_82D562;
    case 0x82D565u: goto L_82D565;
    case 0x82D566u: goto L_82D566;
    case 0x82D567u: goto L_82D567;
    case 0x82D569u: goto L_82D569;
    case 0x82D56Au: goto L_82D56A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82D549:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD549u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD549u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD549u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82D549 PHB
    cpu.push("PHB", hw);
    goto L_82D54A;
L_82D54A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD54Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD54Au,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD54Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D54A SEP
    cpu.sep(0x20u);
    goto L_82D54C;
L_82D54C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD54Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD54Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD54Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D54C LDA
    cpu.setA(0x7Eu, 8);
    goto L_82D54E;
L_82D54E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD54Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD54Eu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD54Eu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82D54E PHA
    cpu.push("PHA", hw);
    goto L_82D54F;
L_82D54F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD54Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD54Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD54Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D54F REP
    cpu.rep(0x20u);
    goto L_82D551;
L_82D551:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD551u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD551u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD551u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82D551 PLB
    cpu.pop("PLB", hw);
    goto L_82D552;
L_82D552:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD552u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD552u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD552u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D552 LDY
    cpu.setY(0x418u, 16);
    goto L_82D555;
L_82D555:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD555u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD555u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD555u, 5u + 1u, 3u, cpu.address("absy", 0x2000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D555 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2000u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D558;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD555u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD555u, 5u + 1u, 3u, cpu.address("absy", 0x2000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D555 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2000u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D558;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD555u,0x82D555u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82D558:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD558u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD558u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD558u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D558 BEQ -> $82D565
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D565; }
    goto L_82D55A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD558u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD558u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D558 BEQ -> $82D565
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D565; }
    goto L_82D55A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD558u,0x82D558u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82D55A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD55Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD55Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD55Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D55A CMP
    cpu.compareA(0xFFFFu);
    goto L_82D55D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD55Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD55Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D55A CMP
    cpu.compareA(0xFFFFu);
    goto L_82D55D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD55Au,0x82D55Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82D55D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD55Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD55Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD55Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D55D BEQ -> $82D565
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D565; }
    goto L_82D55F;
L_82D55F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD55Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD55Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD55Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D55F AND
    cpu.logicAnd(0xFB8Fu);
    goto L_82D562;
L_82D562:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD562u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD562u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD562u, 6u, 3u, cpu.address("absy", 0x2000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D562 STA
    hw.write(cpu.address("absy", 0x2000u), cpu.a, cpu.m8?8:16);
    goto L_82D565;
L_82D565:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD565u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD565u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD565u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D565 DEY
    cpu.decReg('Y');
    goto L_82D566;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD565u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD565u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D565 DEY
    cpu.decReg('Y');
    goto L_82D566;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD565u,0x82D565u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82D566:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD566u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD566u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD566u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D566 DEY
    cpu.decReg('Y');
    goto L_82D567;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD566u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD566u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D566 DEY
    cpu.decReg('Y');
    goto L_82D567;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD566u,0x82D566u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82D567:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD567u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD567u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD567u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D567 BPL -> $82D555
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82D555; }
    goto L_82D569;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD567u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD567u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D567 BPL -> $82D555
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_82D555; }
    goto L_82D569;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD567u,0x82D567u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82D569:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD569u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD569u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD569u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82D569 PLB
    cpu.pop("PLB", hw);
    goto L_82D56A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD569u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD569u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $82D569 PLB
    cpu.pop("PLB", hw);
    goto L_82D56A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD569u,0x82D569u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82D56A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD56Au))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD56Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD56Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D56A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D56Au);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D56Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD56Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD56Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D56A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D56Au);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D56Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD56Au,0x82D56Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82D703_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82D703u: goto L_82D703;
    case 0x82D706u: goto L_82D706;
    case 0x82D70Au: goto L_82D70A;
    case 0x82D70Cu: goto L_82D70C;
    case 0x82D70Fu: goto L_82D70F;
    case 0x82D710u: goto L_82D710;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82D703:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD703u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD703u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD703u, 6u, 3u, cpu.address("abs", 0xD7C1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D703 JSR -> $82D7C1 stack real
    { cpu.push16Value(hw,0xD705u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD706u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD7C1u), 0x82D703u); }
    goto L_82D706;
L_82D706:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD706u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD706u,0x82D706u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD706u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD706u, 8u, 4u, 0x808EE1u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82D706 JSL -> $808EE1 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD709u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD70Au,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808EE1u, 0x82D706u); }
    goto L_82D70A;
L_82D70A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD70Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD70Au,0x82D70Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD70Au,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD70Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D70A LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x5Bu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82D70C;
L_82D70C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD70Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD70Cu,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD70Cu, 9u, 3u, cpu.address("absx", 0x0404u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D70C INC
    cpu.incMem(hw, cpu.address("absx", 0x404u), cpu.m8?8:16);
    goto L_82D70F;
L_82D70F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD70Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD70Fu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD70Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D70F SEC
    cpu.setFlag('C', true);
    goto L_82D710;
L_82D710:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD710u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD710u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD710u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D710 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D710u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82D710u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82DEAE_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82DEAEu: goto L_82DEAE;
    case 0x82DEB0u: goto L_82DEB0;
    case 0x82DEB3u: goto L_82DEB3;
    case 0x82DEB6u: goto L_82DEB6;
    case 0x82DEB9u: goto L_82DEB9;
    case 0x82DEBCu: goto L_82DEBC;
    case 0x82DEBFu: goto L_82DEBF;
    case 0x82DEC2u: goto L_82DEC2;
    case 0x82DEC5u: goto L_82DEC5;
    case 0x82DEC7u: goto L_82DEC7;
    case 0x82DECAu: goto L_82DECA;
    case 0x82DECCu: goto L_82DECC;
    case 0x82DECFu: goto L_82DECF;
    case 0x82DED2u: goto L_82DED2;
    case 0x82DED5u: goto L_82DED5;
    case 0x82DED8u: goto L_82DED8;
    case 0x82DEDBu: goto L_82DEDB;
    case 0x82DEDEu: goto L_82DEDE;
    case 0x82DEE1u: goto L_82DEE1;
    case 0x82DEE4u: goto L_82DEE4;
    case 0x82DEE7u: goto L_82DEE7;
    case 0x82DEEAu: goto L_82DEEA;
    case 0x82DEEDu: goto L_82DEED;
    case 0x82DEF0u: goto L_82DEF0;
    case 0x82DEF3u: goto L_82DEF3;
    case 0x82DEF6u: goto L_82DEF6;
    case 0x82DEF9u: goto L_82DEF9;
    case 0x82DEFCu: goto L_82DEFC;
    case 0x82DEFFu: goto L_82DEFF;
    case 0x82DF02u: goto L_82DF02;
    case 0x82DF05u: goto L_82DF05;
    case 0x82DF08u: goto L_82DF08;
    case 0x82DF0Bu: goto L_82DF0B;
    case 0x82DF0Eu: goto L_82DF0E;
    case 0x82DF11u: goto L_82DF11;
    case 0x82DF14u: goto L_82DF14;
    case 0x82DF17u: goto L_82DF17;
    case 0x82DF1Au: goto L_82DF1A;
    case 0x82DF1Du: goto L_82DF1D;
    case 0x82DF20u: goto L_82DF20;
    case 0x82DF23u: goto L_82DF23;
    case 0x82DF26u: goto L_82DF26;
    case 0x82DF29u: goto L_82DF29;
    case 0x82DF2Cu: goto L_82DF2C;
    case 0x82DF2Fu: goto L_82DF2F;
    case 0x82DF32u: goto L_82DF32;
    case 0x82DF35u: goto L_82DF35;
    case 0x82DF38u: goto L_82DF38;
    case 0x82DF3Bu: goto L_82DF3B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82DEAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEAEu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEAEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DEAE SEP
    cpu.sep(0x20u);
    goto L_82DEB0;
L_82DEB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEB0u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEB0u, 4u, 3u, cpu.address("abs", 0x066Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DEB0 STZ
    hw.write(cpu.address("abs", 0x66Fu), 0, cpu.m8?8:16);
    goto L_82DEB3;
L_82DEB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEB3u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEB3u, 4u, 3u, cpu.address("abs", 0x0629u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DEB3 STZ
    hw.write(cpu.address("abs", 0x629u), 0, cpu.m8?8:16);
    goto L_82DEB6;
L_82DEB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEB6u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEB6u, 4u, 3u, cpu.address("abs", 0x062Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DEB6 STZ
    hw.write(cpu.address("abs", 0x62Au), 0, cpu.m8?8:16);
    goto L_82DEB9;
L_82DEB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEB9u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEB9u, 4u, 3u, cpu.address("abs", 0x062Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DEB9 STZ
    hw.write(cpu.address("abs", 0x62Bu), 0, cpu.m8?8:16);
    goto L_82DEBC;
L_82DEBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEBCu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEBCu, 4u, 3u, cpu.address("abs", 0x06FDu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DEBC STZ
    hw.write(cpu.address("abs", 0x6FDu), 0, cpu.m8?8:16);
    goto L_82DEBF;
L_82DEBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEBFu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEBFu, 4u, 3u, cpu.address("abs", 0x062Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DEBF STZ
    hw.write(cpu.address("abs", 0x62Eu), 0, cpu.m8?8:16);
    goto L_82DEC2;
L_82DEC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEC2u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEC2u, 4u, 3u, cpu.address("abs", 0x062Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DEC2 STZ
    hw.write(cpu.address("abs", 0x62Cu), 0, cpu.m8?8:16);
    goto L_82DEC5;
L_82DEC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEC5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEC5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DEC5 LDA
    cpu.setA(0x1u, 8);
    goto L_82DEC7;
L_82DEC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEC7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEC7u, 4u, 3u, cpu.address("abs", 0x062Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DEC7 STA
    hw.write(cpu.address("abs", 0x62Du), cpu.a, cpu.m8?8:16);
    goto L_82DECA;
L_82DECA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDECAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDECAu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDECAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DECA REP
    cpu.rep(0x20u);
    goto L_82DECC;
L_82DECC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDECCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDECCu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDECCu, 5u, 3u, cpu.address("abs", 0x066Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DECC STZ
    hw.write(cpu.address("abs", 0x66Du), 0, cpu.m8?8:16);
    goto L_82DECF;
L_82DECF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDECFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDECFu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDECFu, 5u, 3u, cpu.address("abs", 0x062Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DECF STZ
    hw.write(cpu.address("abs", 0x62Fu), 0, cpu.m8?8:16);
    goto L_82DED2;
L_82DED2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDED2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDED2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDED2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DED2 LDA
    cpu.setA(0x1u, 16);
    goto L_82DED5;
L_82DED5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDED5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDED5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDED5u, 5u, 3u, cpu.address("abs", 0x0633u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DED5 STA
    hw.write(cpu.address("abs", 0x633u), cpu.a, cpu.m8?8:16);
    goto L_82DED8;
L_82DED8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDED8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDED8u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDED8u, 5u, 3u, cpu.address("abs", 0x0635u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DED8 STZ
    hw.write(cpu.address("abs", 0x635u), 0, cpu.m8?8:16);
    goto L_82DEDB;
L_82DEDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEDBu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEDBu, 5u, 3u, cpu.address("abs", 0x0637u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DEDB STA
    hw.write(cpu.address("abs", 0x637u), cpu.a, cpu.m8?8:16);
    goto L_82DEDE;
L_82DEDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEDEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEDEu, 5u, 3u, cpu.address("abs", 0x0639u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DEDE STA
    hw.write(cpu.address("abs", 0x639u), cpu.a, cpu.m8?8:16);
    goto L_82DEE1;
L_82DEE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEE1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEE1u, 5u, 3u, cpu.address("abs", 0x063Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DEE1 STA
    hw.write(cpu.address("abs", 0x63Bu), cpu.a, cpu.m8?8:16);
    goto L_82DEE4;
L_82DEE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEE4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEE4u, 5u, 3u, cpu.address("abs", 0x063Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DEE4 STA
    hw.write(cpu.address("abs", 0x63Du), cpu.a, cpu.m8?8:16);
    goto L_82DEE7;
L_82DEE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEE7u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEE7u, 5u, 3u, cpu.address("abs", 0x063Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DEE7 STZ
    hw.write(cpu.address("abs", 0x63Fu), 0, cpu.m8?8:16);
    goto L_82DEEA;
L_82DEEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEEAu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEEAu, 5u, 3u, cpu.address("abs", 0x0641u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DEEA STZ
    hw.write(cpu.address("abs", 0x641u), 0, cpu.m8?8:16);
    goto L_82DEED;
L_82DEED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEEDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEEDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEEDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DEED LDA
    cpu.setA(0x4u, 16);
    goto L_82DEF0;
L_82DEF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEF0u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEF0u, 5u, 3u, cpu.address("abs", 0x0643u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DEF0 STA
    hw.write(cpu.address("abs", 0x643u), cpu.a, cpu.m8?8:16);
    goto L_82DEF3;
L_82DEF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEF3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEF3u, 5u, 3u, cpu.address("abs", 0x0645u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DEF3 STA
    hw.write(cpu.address("abs", 0x645u), cpu.a, cpu.m8?8:16);
    goto L_82DEF6;
L_82DEF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEF6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEF6u, 5u, 3u, cpu.address("abs", 0x0647u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DEF6 STA
    hw.write(cpu.address("abs", 0x647u), cpu.a, cpu.m8?8:16);
    goto L_82DEF9;
L_82DEF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEF9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEF9u, 5u, 3u, cpu.address("abs", 0x0649u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DEF9 STA
    hw.write(cpu.address("abs", 0x649u), cpu.a, cpu.m8?8:16);
    goto L_82DEFC;
L_82DEFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEFCu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEFCu, 5u, 3u, cpu.address("abs", 0x064Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DEFC STZ
    hw.write(cpu.address("abs", 0x64Bu), 0, cpu.m8?8:16);
    goto L_82DEFF;
L_82DEFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEFFu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEFFu, 5u, 3u, cpu.address("abs", 0x064Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DEFF STZ
    hw.write(cpu.address("abs", 0x64Du), 0, cpu.m8?8:16);
    goto L_82DF02;
L_82DF02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF02u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF02u, 5u, 3u, cpu.address("abs", 0x064Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF02 STZ
    hw.write(cpu.address("abs", 0x64Fu), 0, cpu.m8?8:16);
    goto L_82DF05;
L_82DF05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF05u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF05u, 5u, 3u, cpu.address("abs", 0x0651u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF05 STZ
    hw.write(cpu.address("abs", 0x651u), 0, cpu.m8?8:16);
    goto L_82DF08;
L_82DF08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF08u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF08u, 5u, 3u, cpu.address("abs", 0x0670u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF08 STZ
    hw.write(cpu.address("abs", 0x670u), 0, cpu.m8?8:16);
    goto L_82DF0B;
L_82DF0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF0Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF0Bu, 5u, 3u, cpu.address("abs", 0x0676u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF0B STZ
    hw.write(cpu.address("abs", 0x676u), 0, cpu.m8?8:16);
    goto L_82DF0E;
L_82DF0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF0Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF0Eu, 5u, 3u, cpu.address("abs", 0x067Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF0E STZ
    hw.write(cpu.address("abs", 0x67Cu), 0, cpu.m8?8:16);
    goto L_82DF11;
L_82DF11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF11u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF11u, 5u, 3u, cpu.address("abs", 0x0682u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF11 STZ
    hw.write(cpu.address("abs", 0x682u), 0, cpu.m8?8:16);
    goto L_82DF14;
L_82DF14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF14u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF14u, 5u, 3u, cpu.address("abs", 0x0688u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF14 STZ
    hw.write(cpu.address("abs", 0x688u), 0, cpu.m8?8:16);
    goto L_82DF17;
L_82DF17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF17u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF17u, 5u, 3u, cpu.address("abs", 0x068Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF17 STZ
    hw.write(cpu.address("abs", 0x68Eu), 0, cpu.m8?8:16);
    goto L_82DF1A;
L_82DF1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF1Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF1Au, 5u, 3u, cpu.address("abs", 0x0694u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF1A STZ
    hw.write(cpu.address("abs", 0x694u), 0, cpu.m8?8:16);
    goto L_82DF1D;
L_82DF1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF1Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF1Du, 5u, 3u, cpu.address("abs", 0x069Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF1D STZ
    hw.write(cpu.address("abs", 0x69Au), 0, cpu.m8?8:16);
    goto L_82DF20;
L_82DF20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF20u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF20u, 5u, 3u, cpu.address("abs", 0x06A0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF20 STZ
    hw.write(cpu.address("abs", 0x6A0u), 0, cpu.m8?8:16);
    goto L_82DF23;
L_82DF23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF23u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF23u, 5u, 3u, cpu.address("abs", 0x06A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF23 STZ
    hw.write(cpu.address("abs", 0x6A6u), 0, cpu.m8?8:16);
    goto L_82DF26;
L_82DF26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF26u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF26u, 5u, 3u, cpu.address("abs", 0x06B0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF26 STZ
    hw.write(cpu.address("abs", 0x6B0u), 0, cpu.m8?8:16);
    goto L_82DF29;
L_82DF29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF29u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF29u, 5u, 3u, cpu.address("abs", 0x06B2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF29 STZ
    hw.write(cpu.address("abs", 0x6B2u), 0, cpu.m8?8:16);
    goto L_82DF2C;
L_82DF2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF2Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF2Cu, 5u, 3u, cpu.address("abs", 0x06B4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF2C STZ
    hw.write(cpu.address("abs", 0x6B4u), 0, cpu.m8?8:16);
    goto L_82DF2F;
L_82DF2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF2Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF2Fu, 5u, 3u, cpu.address("abs", 0x06B6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF2F STZ
    hw.write(cpu.address("abs", 0x6B6u), 0, cpu.m8?8:16);
    goto L_82DF32;
L_82DF32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF32u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF32u, 5u, 3u, cpu.address("abs", 0x06B8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF32 STZ
    hw.write(cpu.address("abs", 0x6B8u), 0, cpu.m8?8:16);
    goto L_82DF35;
L_82DF35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF35u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF35u, 5u, 3u, cpu.address("abs", 0x06BAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF35 STZ
    hw.write(cpu.address("abs", 0x6BAu), 0, cpu.m8?8:16);
    goto L_82DF38;
L_82DF38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF38u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF38u, 5u, 3u, cpu.address("abs", 0x06BCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82DF38 STZ
    hw.write(cpu.address("abs", 0x6BCu), 0, cpu.m8?8:16);
    goto L_82DF3B;
L_82DF3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDF3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDF3Bu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDF3Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82DF3B RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82DF3Bu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x82DF3Bu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_848671_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848671u: goto L_848671;
    case 0x848673u: goto L_848673;
    case 0x848675u: goto L_848675;
    case 0x848677u: goto L_848677;
    case 0x84867Au: goto L_84867A;
    case 0x84867Bu: goto L_84867B;
    case 0x84867Cu: goto L_84867C;
    case 0x84867Fu: goto L_84867F;
    case 0x848682u: goto L_848682;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848671:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8671u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8671u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8671u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848671 SEP
    cpu.sep(0x20u);
    goto L_848673;
L_848673:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8673u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8673u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8673u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848673 AND
    cpu.logicAnd(0x3u);
    goto L_848675;
L_848675:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8675u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8675u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8675u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848675 REP
    cpu.rep(0x20u);
    goto L_848677;
L_848677:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8677u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8677u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8677u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848677 AND
    cpu.logicAnd(0xFFu);
    goto L_84867A;
L_84867A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x867Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x867Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x867Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84867A ASL
    cpu.aslA();
    goto L_84867B;
L_84867B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x867Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x867Bu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x867Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84867B TAX
    cpu.transfer("TAX");
    goto L_84867C;
L_84867C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x867Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x867Cu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x867Cu, 5u, 3u, cpu.address("abs", 0x8681u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84867C PEA
    cpu.push16Value(hw, 0x8681u);
    goto L_84867F;
L_84867F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x867Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x867Fu,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x867Fu, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x8683u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $84867F JMP (8683,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x8683u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x84867Fu); return; }
L_848682:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8682u))return;
  // 3 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8682u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8682u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848682 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848682u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848682u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8682u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8682u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848682 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848682u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848682u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8682u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8682u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848682 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x848682u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x848682u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8682u,0x848682u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_8496F7_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8496F7u: goto L_8496F7;
    case 0x8496F9u: goto L_8496F9;
    case 0x8496FCu: goto L_8496FC;
    case 0x8496FFu: goto L_8496FF;
    case 0x849702u: goto L_849702;
    case 0x849704u: goto L_849704;
    case 0x849707u: goto L_849707;
    case 0x849709u: goto L_849709;
    case 0x84970Cu: goto L_84970C;
    case 0x84970Eu: goto L_84970E;
    case 0x849712u: goto L_849712;
    case 0x849715u: goto L_849715;
    case 0x849718u: goto L_849718;
    case 0x84971Bu: goto L_84971B;
    case 0x84971Du: goto L_84971D;
    case 0x849720u: goto L_849720;
    case 0x849722u: goto L_849722;
    case 0x849725u: goto L_849725;
    case 0x849727u: goto L_849727;
    case 0x84972Bu: goto L_84972B;
    case 0x84972Du: goto L_84972D;
    case 0x849730u: goto L_849730;
    case 0x849732u: goto L_849732;
    case 0x849734u: goto L_849734;
    case 0x849737u: goto L_849737;
    case 0x849738u: goto L_849738;
    case 0x849739u: goto L_849739;
    case 0x84973Cu: goto L_84973C;
    case 0x84973Fu: goto L_84973F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8496F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96F7u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96F7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8496F7 REP
    cpu.rep(0x20u);
    goto L_8496F9;
L_8496F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96F9u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96F9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8496F9 LDX
    cpu.setX(0x2u, 16);
    goto L_8496FC;
L_8496FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96FCu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96FCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8496FC LDY
    cpu.setY(0x5u, 16);
    goto L_8496FF;
L_8496FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96FFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96FFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8496FF LDA
    cpu.setA(0x2A88u, 16);
    goto L_849702;
L_849702:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9702u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9702u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9702u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849702 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_849704;
L_849704:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9704u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9704u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9704u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849704 LDA
    cpu.setA(0x7Eu, 16);
    goto L_849707;
L_849707:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9707u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9707u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9707u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849707 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_849709;
L_849709:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9709u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9709u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9709u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849709 LDA
    cpu.setA(0xC00u, 16);
    goto L_84970C;
L_84970C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x970Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x970Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x970Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84970C STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_84970E;
L_84970E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x970Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x970Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x970Eu, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84970E JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9711u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9712u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x84970Eu); }
    goto L_849712;
L_849712:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9712u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9712u,0x849712u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9712u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9712u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849712 LDX
    cpu.setX(0x2u, 16);
    goto L_849715;
L_849715:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9715u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9715u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9715u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849715 LDY
    cpu.setY(0x5u, 16);
    goto L_849718;
L_849718:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9718u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9718u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9718u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849718 LDA
    cpu.setA(0x2C08u, 16);
    goto L_84971B;
L_84971B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x971Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x971Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x971Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84971B STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84971D;
L_84971D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x971Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x971Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x971Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84971D LDA
    cpu.setA(0x7Eu, 16);
    goto L_849720;
L_849720:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9720u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9720u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9720u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849720 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_849722;
L_849722:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9722u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9722u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9722u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849722 LDA
    cpu.setA(0xC00u, 16);
    goto L_849725;
L_849725:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9725u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9725u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9725u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849725 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_849727;
L_849727:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9727u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9727u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9727u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849727 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x972Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x972Bu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x849727u); }
    goto L_84972B;
L_84972B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x972Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x972Bu,0x84972Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x972Bu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x972Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84972B SEP
    cpu.sep(0x20u);
    goto L_84972D;
L_84972D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x972Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x972Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x972Du, 4u, 3u, cpu.address("abs", 0x06FEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84972D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6FEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849730;
L_849730:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9730u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9730u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9730u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849730 AND
    cpu.logicAnd(0x1u);
    goto L_849732;
L_849732:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9732u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9732u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9732u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849732 REP
    cpu.rep(0x20u);
    goto L_849734;
L_849734:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9734u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9734u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9734u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849734 AND
    cpu.logicAnd(0xFFu);
    goto L_849737;
L_849737:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9737u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9737u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9737u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849737 ASL
    cpu.aslA();
    goto L_849738;
L_849738:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9738u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9738u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9738u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849738 TAX
    cpu.transfer("TAX");
    goto L_849739;
L_849739:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9739u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9739u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9739u, 5u, 3u, cpu.address("abs", 0x973Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849739 PEA
    cpu.push16Value(hw, 0x973Eu);
    goto L_84973C;
L_84973C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x973Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x973Cu,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x973Cu, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x9740u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $84973C JMP (9740,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x9740u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x84973Cu); return; }
L_84973F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x973Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x973Fu,0x84973Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x973Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x973Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84973F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84973Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84973Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8496F7_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8496F7u: goto L_8496F7;
    case 0x8496F9u: goto L_8496F9;
    case 0x8496FCu: goto L_8496FC;
    case 0x8496FFu: goto L_8496FF;
    case 0x849702u: goto L_849702;
    case 0x849704u: goto L_849704;
    case 0x849707u: goto L_849707;
    case 0x849709u: goto L_849709;
    case 0x84970Cu: goto L_84970C;
    case 0x84970Eu: goto L_84970E;
    case 0x849712u: goto L_849712;
    case 0x849715u: goto L_849715;
    case 0x849718u: goto L_849718;
    case 0x84971Bu: goto L_84971B;
    case 0x84971Du: goto L_84971D;
    case 0x849720u: goto L_849720;
    case 0x849722u: goto L_849722;
    case 0x849725u: goto L_849725;
    case 0x849727u: goto L_849727;
    case 0x84972Bu: goto L_84972B;
    case 0x84972Du: goto L_84972D;
    case 0x849730u: goto L_849730;
    case 0x849732u: goto L_849732;
    case 0x849734u: goto L_849734;
    case 0x849737u: goto L_849737;
    case 0x849738u: goto L_849738;
    case 0x849739u: goto L_849739;
    case 0x84973Cu: goto L_84973C;
    case 0x84973Fu: goto L_84973F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8496F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96F7u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96F7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8496F7 REP
    cpu.rep(0x20u);
    goto L_8496F9;
L_8496F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96F9u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96F9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8496F9 LDX
    cpu.setX(0x2u, 16);
    goto L_8496FC;
L_8496FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96FCu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96FCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8496FC LDY
    cpu.setY(0x5u, 16);
    goto L_8496FF;
L_8496FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96FFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96FFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8496FF LDA
    cpu.setA(0x2A88u, 16);
    goto L_849702;
L_849702:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9702u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9702u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9702u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849702 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_849704;
L_849704:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9704u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9704u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9704u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849704 LDA
    cpu.setA(0x7Eu, 16);
    goto L_849707;
L_849707:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9707u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9707u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9707u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849707 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_849709;
L_849709:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9709u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9709u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9709u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849709 LDA
    cpu.setA(0xC00u, 16);
    goto L_84970C;
L_84970C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x970Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x970Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x970Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84970C STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_84970E;
L_84970E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x970Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x970Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x970Eu, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84970E JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9711u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9712u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x84970Eu); }
    goto L_849712;
L_849712:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9712u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9712u,0x849712u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9712u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9712u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849712 LDX
    cpu.setX(0x2u, 16);
    goto L_849715;
L_849715:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9715u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9715u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9715u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849715 LDY
    cpu.setY(0x5u, 16);
    goto L_849718;
L_849718:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9718u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9718u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9718u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849718 LDA
    cpu.setA(0x2C08u, 16);
    goto L_84971B;
L_84971B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x971Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x971Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x971Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84971B STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84971D;
L_84971D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x971Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x971Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x971Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84971D LDA
    cpu.setA(0x7Eu, 16);
    goto L_849720;
L_849720:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9720u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9720u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9720u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849720 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_849722;
L_849722:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9722u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9722u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9722u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849722 LDA
    cpu.setA(0xC00u, 16);
    goto L_849725;
L_849725:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9725u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9725u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9725u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849725 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_849727;
L_849727:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9727u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9727u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9727u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849727 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x972Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x972Bu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x849727u); }
    goto L_84972B;
L_84972B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x972Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x972Bu,0x84972Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x972Bu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x972Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84972B SEP
    cpu.sep(0x20u);
    goto L_84972D;
L_84972D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x972Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x972Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x972Du, 4u, 3u, cpu.address("abs", 0x06FEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84972D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6FEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849730;
L_849730:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9730u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9730u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9730u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849730 AND
    cpu.logicAnd(0x1u);
    goto L_849732;
L_849732:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9732u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9732u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9732u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849732 REP
    cpu.rep(0x20u);
    goto L_849734;
L_849734:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9734u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9734u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9734u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849734 AND
    cpu.logicAnd(0xFFu);
    goto L_849737;
L_849737:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9737u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9737u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9737u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849737 ASL
    cpu.aslA();
    goto L_849738;
L_849738:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9738u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9738u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9738u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849738 TAX
    cpu.transfer("TAX");
    goto L_849739;
L_849739:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9739u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9739u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9739u, 5u, 3u, cpu.address("abs", 0x973Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849739 PEA
    cpu.push16Value(hw, 0x973Eu);
    goto L_84973C;
L_84973C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x973Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x973Cu,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x973Cu, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x9740u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $84973C JMP (9740,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x9740u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x84973Cu); return; }
L_84973F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x973Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x973Fu,0x84973Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x973Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x973Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84973F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84973Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84973Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8496F7_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8496F7u: goto L_8496F7;
    case 0x8496F9u: goto L_8496F9;
    case 0x8496FCu: goto L_8496FC;
    case 0x8496FFu: goto L_8496FF;
    case 0x849702u: goto L_849702;
    case 0x849704u: goto L_849704;
    case 0x849707u: goto L_849707;
    case 0x849709u: goto L_849709;
    case 0x84970Cu: goto L_84970C;
    case 0x84970Eu: goto L_84970E;
    case 0x849712u: goto L_849712;
    case 0x849715u: goto L_849715;
    case 0x849718u: goto L_849718;
    case 0x84971Bu: goto L_84971B;
    case 0x84971Du: goto L_84971D;
    case 0x849720u: goto L_849720;
    case 0x849722u: goto L_849722;
    case 0x849725u: goto L_849725;
    case 0x849727u: goto L_849727;
    case 0x84972Bu: goto L_84972B;
    case 0x84972Du: goto L_84972D;
    case 0x849730u: goto L_849730;
    case 0x849732u: goto L_849732;
    case 0x849734u: goto L_849734;
    case 0x849737u: goto L_849737;
    case 0x849738u: goto L_849738;
    case 0x849739u: goto L_849739;
    case 0x84973Cu: goto L_84973C;
    case 0x84973Fu: goto L_84973F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8496F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96F7u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96F7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8496F7 REP
    cpu.rep(0x20u);
    goto L_8496F9;
L_8496F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96F9u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96F9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8496F9 LDX
    cpu.setX(0x2u, 16);
    goto L_8496FC;
L_8496FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96FCu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96FCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8496FC LDY
    cpu.setY(0x5u, 16);
    goto L_8496FF;
L_8496FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96FFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96FFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8496FF LDA
    cpu.setA(0x2A88u, 16);
    goto L_849702;
L_849702:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9702u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9702u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9702u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849702 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_849704;
L_849704:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9704u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9704u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9704u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849704 LDA
    cpu.setA(0x7Eu, 16);
    goto L_849707;
L_849707:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9707u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9707u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9707u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849707 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_849709;
L_849709:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9709u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9709u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9709u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849709 LDA
    cpu.setA(0xC00u, 16);
    goto L_84970C;
L_84970C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x970Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x970Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x970Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84970C STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_84970E;
L_84970E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x970Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x970Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x970Eu, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84970E JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9711u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9712u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x84970Eu); }
    goto L_849712;
L_849712:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9712u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9712u,0x849712u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9712u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9712u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849712 LDX
    cpu.setX(0x2u, 16);
    goto L_849715;
L_849715:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9715u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9715u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9715u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849715 LDY
    cpu.setY(0x5u, 16);
    goto L_849718;
L_849718:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9718u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9718u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9718u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849718 LDA
    cpu.setA(0x2C08u, 16);
    goto L_84971B;
L_84971B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x971Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x971Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x971Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84971B STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_84971D;
L_84971D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x971Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x971Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x971Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84971D LDA
    cpu.setA(0x7Eu, 16);
    goto L_849720;
L_849720:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9720u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9720u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9720u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849720 STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_849722;
L_849722:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9722u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9722u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9722u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849722 LDA
    cpu.setA(0xC00u, 16);
    goto L_849725;
L_849725:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9725u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9725u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9725u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849725 STA
    hw.write(cpu.address("dp", 0x3u), cpu.a, cpu.m8?8:16);
    goto L_849727;
L_849727:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9727u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9727u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9727u, 8u, 4u, 0x80A839u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849727 JSL -> $80A839 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x972Au); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x972Bu,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A839u, 0x849727u); }
    goto L_84972B;
L_84972B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x972Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x972Bu,0x84972Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x972Bu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x972Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84972B SEP
    cpu.sep(0x20u);
    goto L_84972D;
L_84972D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x972Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x972Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x972Du, 4u, 3u, cpu.address("abs", 0x06FEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84972D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6FEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849730;
L_849730:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9730u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9730u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9730u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849730 AND
    cpu.logicAnd(0x1u);
    goto L_849732;
L_849732:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9732u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9732u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9732u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849732 REP
    cpu.rep(0x20u);
    goto L_849734;
L_849734:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9734u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9734u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9734u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849734 AND
    cpu.logicAnd(0xFFu);
    goto L_849737;
L_849737:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9737u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9737u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9737u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849737 ASL
    cpu.aslA();
    goto L_849738;
L_849738:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9738u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9738u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9738u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849738 TAX
    cpu.transfer("TAX");
    goto L_849739;
L_849739:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9739u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9739u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9739u, 5u, 3u, cpu.address("abs", 0x973Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849739 PEA
    cpu.push16Value(hw, 0x973Eu);
    goto L_84973C;
L_84973C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x973Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x973Cu,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x973Cu, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x9740u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $84973C JMP (9740,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x9740u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x84973Cu); return; }
L_84973F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x973Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x973Fu,0x84973Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x973Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x973Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84973F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84973Fu);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84973Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84B855_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84B855u: goto L_84B855;
    case 0x84B857u: goto L_84B857;
    case 0x84B859u: goto L_84B859;
    case 0x84B85Bu: goto L_84B85B;
    case 0x84B85Eu: goto L_84B85E;
    case 0x84B860u: goto L_84B860;
    case 0x84B863u: goto L_84B863;
    case 0x84B866u: goto L_84B866;
    case 0x84B869u: goto L_84B869;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84B855:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB855u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB855u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB855u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B855 REP
    cpu.rep(0x20u);
    goto L_84B857;
L_84B857:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB857u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB857u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB857u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B857 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B859;
L_84B859:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB859u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB859u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB859u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B859 BNE -> $84B866
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84B866; }
    goto L_84B85B;
L_84B85B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB85Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB85Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB85Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B85B LDA
    cpu.setA(0x4u, 16);
    goto L_84B85E;
L_84B85E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB85Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB85Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB85Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B85E STA
    hw.write(cpu.address("dp", 0x6Fu), cpu.a, cpu.m8?8:16);
    goto L_84B860;
L_84B860:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB860u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB860u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB860u, 8u, 3u, cpu.address("abs", 0x0084u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B860 DEC
    cpu.decMem(hw, cpu.address("abs", 0x84u), cpu.m8?8:16);
    goto L_84B863;
L_84B863:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB863u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB863u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB863u, 8u, 3u, cpu.address("abs", 0x0082u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B863 DEC
    cpu.decMem(hw, cpu.address("abs", 0x82u), cpu.m8?8:16);
    goto L_84B866;
L_84B866:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB866u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB866u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB866u, 6u, 3u, cpu.address("abs", 0xB86Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B866 JSR -> $84B86A stack real
    { cpu.push16Value(hw,0xB868u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB869u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB86Au), 0x84B866u); }
    goto L_84B869;
L_84B869:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB869u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB869u,0x84B869u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB869u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB869u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B869 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84B869u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84B869u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84B855_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84B855u: goto L_84B855;
    case 0x84B857u: goto L_84B857;
    case 0x84B859u: goto L_84B859;
    case 0x84B85Bu: goto L_84B85B;
    case 0x84B85Eu: goto L_84B85E;
    case 0x84B860u: goto L_84B860;
    case 0x84B863u: goto L_84B863;
    case 0x84B866u: goto L_84B866;
    case 0x84B869u: goto L_84B869;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84B855:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB855u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB855u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB855u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B855 REP
    cpu.rep(0x20u);
    goto L_84B857;
L_84B857:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB857u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB857u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB857u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B857 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B859;
L_84B859:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB859u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB859u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB859u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B859 BNE -> $84B866
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84B866; }
    goto L_84B85B;
L_84B85B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB85Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB85Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB85Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B85B LDA
    cpu.setA(0x4u, 16);
    goto L_84B85E;
L_84B85E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB85Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB85Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB85Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B85E STA
    hw.write(cpu.address("dp", 0x6Fu), cpu.a, cpu.m8?8:16);
    goto L_84B860;
L_84B860:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB860u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB860u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB860u, 8u, 3u, cpu.address("abs", 0x0084u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B860 DEC
    cpu.decMem(hw, cpu.address("abs", 0x84u), cpu.m8?8:16);
    goto L_84B863;
L_84B863:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB863u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB863u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB863u, 8u, 3u, cpu.address("abs", 0x0082u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B863 DEC
    cpu.decMem(hw, cpu.address("abs", 0x82u), cpu.m8?8:16);
    goto L_84B866;
L_84B866:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB866u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB866u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB866u, 6u, 3u, cpu.address("abs", 0xB86Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B866 JSR -> $84B86A stack real
    { cpu.push16Value(hw,0xB868u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB869u,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB86Au), 0x84B866u); }
    goto L_84B869;
L_84B869:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB869u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB869u,0x84B869u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB869u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB869u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B869 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84B869u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84B869u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_84B93D_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84B93Du: goto L_84B93D;
    case 0x84B93Fu: goto L_84B93F;
    case 0x84B942u: goto L_84B942;
    case 0x84B944u: goto L_84B944;
    case 0x84B947u: goto L_84B947;
    case 0x84B949u: goto L_84B949;
    case 0x84B94Au: goto L_84B94A;
    case 0x84B94Cu: goto L_84B94C;
    case 0x84B94Fu: goto L_84B94F;
    case 0x84B953u: goto L_84B953;
    case 0x84B955u: goto L_84B955;
    case 0x84B958u: goto L_84B958;
    case 0x84B95Au: goto L_84B95A;
    case 0x84B95Du: goto L_84B95D;
    case 0x84B961u: goto L_84B961;
    case 0x84B963u: goto L_84B963;
    case 0x84B965u: goto L_84B965;
    case 0x84B966u: goto L_84B966;
    case 0x84B968u: goto L_84B968;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84B93D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB93Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB93Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB93Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B93D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B93F;
L_84B93F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB93Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB93Fu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB93Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B93F BIT
    cpu.bit(0x1080u, true);
    goto L_84B942;
L_84B942:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB942u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB942u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB942u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B942 BNE -> $84B95A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84B95A; }
    goto L_84B944;
L_84B944:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB944u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB944u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB944u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B944 BIT
    cpu.bit(0xA000u, true);
    goto L_84B947;
L_84B947:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB947u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB947u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB947u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B947 BNE -> $84B94C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84B94C; }
    goto L_84B949;
L_84B949:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB949u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB949u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB949u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B949 CLC
    cpu.setFlag('C', false);
    goto L_84B94A;
L_84B94A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB94Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Au,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B94A BRA -> $84B968
    goto L_84B968;
L_84B94C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB94Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B94C LDA
    cpu.setA(0x5u, 16);
    goto L_84B94F;
L_84B94F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB94Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Fu, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B94F JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB952u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB953u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x84B94Fu); }
    goto L_84B953;
L_84B953:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB953u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB953u,0x84B953u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB953u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB953u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B953 SEP
    cpu.sep(0x20u);
    goto L_84B955;
L_84B955:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB955u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB955u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB955u, 6u, 3u, cpu.address("abs", 0x0657u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B955 INC
    cpu.incMem(hw, cpu.address("abs", 0x657u), cpu.m8?8:16);
    goto L_84B958;
L_84B958:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB958u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB958u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB958u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B958 BRA -> $84B963
    goto L_84B963;
L_84B95A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB95Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B95A LDA
    cpu.setA(0x4u, 16);
    goto L_84B95D;
L_84B95D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB95Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Du, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B95D JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB960u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB961u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x84B95Du); }
    goto L_84B961;
L_84B961:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB961u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB961u,0x84B961u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB961u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB961u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B961 SEP
    cpu.sep(0x20u);
    goto L_84B963;
L_84B963:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB963u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB963u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB963u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B963 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_84B965;
L_84B965:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB965u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB965u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB965u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B965 SEC
    cpu.setFlag('C', true);
    goto L_84B966;
L_84B966:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB966u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB966u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB966u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B966 REP
    cpu.rep(0x20u);
    goto L_84B968;
L_84B968:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB968u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB968u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB968u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B968 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84B968u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84B968u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB968u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB968u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B968 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84B968u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84B968u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB968u,0x84B968u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_84B93D_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84B93Du: goto L_84B93D;
    case 0x84B93Fu: goto L_84B93F;
    case 0x84B942u: goto L_84B942;
    case 0x84B944u: goto L_84B944;
    case 0x84B947u: goto L_84B947;
    case 0x84B949u: goto L_84B949;
    case 0x84B94Au: goto L_84B94A;
    case 0x84B94Cu: goto L_84B94C;
    case 0x84B94Fu: goto L_84B94F;
    case 0x84B953u: goto L_84B953;
    case 0x84B955u: goto L_84B955;
    case 0x84B958u: goto L_84B958;
    case 0x84B95Au: goto L_84B95A;
    case 0x84B95Du: goto L_84B95D;
    case 0x84B961u: goto L_84B961;
    case 0x84B963u: goto L_84B963;
    case 0x84B965u: goto L_84B965;
    case 0x84B966u: goto L_84B966;
    case 0x84B968u: goto L_84B968;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84B93D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB93Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB93Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB93Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B93D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84B93F;
L_84B93F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB93Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB93Fu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB93Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B93F BIT
    cpu.bit(0x1080u, true);
    goto L_84B942;
L_84B942:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB942u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB942u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB942u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B942 BNE -> $84B95A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84B95A; }
    goto L_84B944;
L_84B944:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB944u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB944u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB944u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B944 BIT
    cpu.bit(0xA000u, true);
    goto L_84B947;
L_84B947:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB947u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB947u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB947u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B947 BNE -> $84B94C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84B94C; }
    goto L_84B949;
L_84B949:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB949u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB949u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB949u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B949 CLC
    cpu.setFlag('C', false);
    goto L_84B94A;
L_84B94A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB94Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Au,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B94A BRA -> $84B968
    goto L_84B968;
L_84B94C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB94Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B94C LDA
    cpu.setA(0x5u, 16);
    goto L_84B94F;
L_84B94F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB94Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Fu, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B94F JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB952u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB953u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x84B94Fu); }
    goto L_84B953;
L_84B953:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB953u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB953u,0x84B953u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB953u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB953u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B953 SEP
    cpu.sep(0x20u);
    goto L_84B955;
L_84B955:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB955u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB955u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB955u, 6u, 3u, cpu.address("abs", 0x0657u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B955 INC
    cpu.incMem(hw, cpu.address("abs", 0x657u), cpu.m8?8:16);
    goto L_84B958;
L_84B958:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB958u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB958u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB958u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B958 BRA -> $84B963
    goto L_84B963;
L_84B95A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB95Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B95A LDA
    cpu.setA(0x4u, 16);
    goto L_84B95D;
L_84B95D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB95Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Du, 8u, 4u, 0x80A6FBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84B95D JSL -> $80A6FB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB960u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB961u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6FBu, 0x84B95Du); }
    goto L_84B961;
L_84B961:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB961u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB961u,0x84B961u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB961u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB961u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B961 SEP
    cpu.sep(0x20u);
    goto L_84B963;
L_84B963:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB963u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB963u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB963u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B963 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_84B965;
L_84B965:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB965u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB965u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB965u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B965 SEC
    cpu.setFlag('C', true);
    goto L_84B966;
L_84B966:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB966u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB966u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB966u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84B966 REP
    cpu.rep(0x20u);
    goto L_84B968;
L_84B968:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB968u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB968u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB968u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B968 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84B968u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84B968u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB968u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB968u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84B968 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84B968u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84B968u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB968u,0x84B968u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_84BEF8_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84BEF8u: goto L_84BEF8;
    case 0x84BEFAu: goto L_84BEFA;
    case 0x84BEFDu: goto L_84BEFD;
    case 0x84BEFFu: goto L_84BEFF;
    case 0x84BF01u: goto L_84BF01;
    case 0x84BF04u: goto L_84BF04;
    case 0x84BF06u: goto L_84BF06;
    case 0x84BF09u: goto L_84BF09;
    case 0x84BF0Cu: goto L_84BF0C;
    case 0x84BF0Fu: goto L_84BF0F;
    case 0x84BF11u: goto L_84BF11;
    case 0x84BF14u: goto L_84BF14;
    case 0x84BF16u: goto L_84BF16;
    case 0x84BF18u: goto L_84BF18;
    case 0x84BF1Bu: goto L_84BF1B;
    case 0x84BF1Du: goto L_84BF1D;
    case 0x84BF20u: goto L_84BF20;
    case 0x84BF22u: goto L_84BF22;
    case 0x84BF24u: goto L_84BF24;
    case 0x84BF27u: goto L_84BF27;
    case 0x84BF29u: goto L_84BF29;
    case 0x84BF2Bu: goto L_84BF2B;
    case 0x84BF2Eu: goto L_84BF2E;
    case 0x84BF30u: goto L_84BF30;
    case 0x84BF32u: goto L_84BF32;
    case 0x84BF34u: goto L_84BF34;
    case 0x84BF36u: goto L_84BF36;
    case 0x84BF38u: goto L_84BF38;
    case 0x84BF3Au: goto L_84BF3A;
    case 0x84BF3Cu: goto L_84BF3C;
    case 0x84BF3Du: goto L_84BF3D;
    case 0x84BF3Fu: goto L_84BF3F;
    case 0x84BF43u: goto L_84BF43;
    case 0x84BF45u: goto L_84BF45;
    case 0x84BF49u: goto L_84BF49;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84BEF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEF8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEF8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEF8 REP
    cpu.rep(0x20u);
    goto L_84BEFA;
L_84BEFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEFAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEFAu, 6u, 3u, cpu.address("abs", 0xC197u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84BEFA JSR -> $84C197 stack real
    { cpu.push16Value(hw,0xBEFCu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBEFDu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC197u), 0x84BEFAu); }
    goto L_84BEFD;
L_84BEFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEFDu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEFDu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEFDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEFD BCC -> $84BF2B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_84BF2B; }
    goto L_84BEFF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEFDu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEFDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEFD BCC -> $84BF2B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_84BF2B; }
    goto L_84BEFF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBEFDu,0x84BEFDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BEFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEFFu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEFFu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEFFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEFF REP
    cpu.rep(0x20u);
    goto L_84BF01;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEFFu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEFFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEFF REP
    cpu.rep(0x20u);
    goto L_84BF01;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBEFFu,0x84BEFFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BF01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF01u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF01u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF01u, 5u, 3u, cpu.address("abs", 0x06EFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF01 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6EFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BF04;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF01u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF01u, 5u, 3u, cpu.address("abs", 0x06EFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF01 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6EFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BF04;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF01u,0x84BF01u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BF04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF04u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF04u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF04u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF04 BNE -> $84BF11
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84BF11; }
    goto L_84BF06;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF04u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF04u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF04 BNE -> $84BF11
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84BF11; }
    goto L_84BF06;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF04u,0x84BF04u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BF06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF06u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF06u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF06u, 8u, 3u, cpu.address("abs", 0x06EFu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF06 INC
    cpu.incMem(hw, cpu.address("abs", 0x6EFu), cpu.m8?8:16);
    goto L_84BF09;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF06u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF06u, 8u, 3u, cpu.address("abs", 0x06EFu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF06 INC
    cpu.incMem(hw, cpu.address("abs", 0x6EFu), cpu.m8?8:16);
    goto L_84BF09;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF06u,0x84BF06u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BF09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF09u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF09u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF09u, 5u, 3u, cpu.address("abs", 0x1902u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF09 STZ
    hw.write(cpu.address("abs", 0x1902u), 0, cpu.m8?8:16);
    goto L_84BF0C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF09u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF09u, 5u, 3u, cpu.address("abs", 0x1902u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF09 STZ
    hw.write(cpu.address("abs", 0x1902u), 0, cpu.m8?8:16);
    goto L_84BF0C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF09u,0x84BF09u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BF0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF0Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF0Cu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF0Cu, 8u, 3u, cpu.address("abs", 0x0122u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF0C INC
    cpu.incMem(hw, cpu.address("abs", 0x122u), cpu.m8?8:16);
    goto L_84BF0F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF0Cu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF0Cu, 8u, 3u, cpu.address("abs", 0x0122u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF0C INC
    cpu.incMem(hw, cpu.address("abs", 0x122u), cpu.m8?8:16);
    goto L_84BF0F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF0Cu,0x84BF0Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BF0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF0Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF0Fu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF0Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF0F BRA -> $84BF2B
    goto L_84BF2B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF0Fu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF0Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF0F BRA -> $84BF2B
    goto L_84BF2B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF0Fu,0x84BF0Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BF11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF11u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF11u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF11u, 5u, 3u, cpu.address("abs", 0x06EFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF11 STZ
    hw.write(cpu.address("abs", 0x6EFu), 0, cpu.m8?8:16);
    goto L_84BF14;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF11u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF11u, 5u, 3u, cpu.address("abs", 0x06EFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF11 STZ
    hw.write(cpu.address("abs", 0x6EFu), 0, cpu.m8?8:16);
    goto L_84BF14;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF11u,0x84BF11u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BF14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF14u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF14u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF14u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF14 SEP
    cpu.sep(0x20u);
    goto L_84BF16;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF14u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF14u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF14 SEP
    cpu.sep(0x20u);
    goto L_84BF16;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF14u,0x84BF14u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BF16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF16u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF16u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF16u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF16 LDA
    cpu.setA(0x1u, 8);
    goto L_84BF18;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF16u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF16u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF16 LDA
    cpu.setA(0x1u, 8);
    goto L_84BF18;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF16u,0x84BF16u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BF18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF18u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF18u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF18u, 4u, 3u, cpu.address("abs", 0x2105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF18 STA
    hw.write(cpu.address("abs", 0x2105u), cpu.a, cpu.m8?8:16);
    goto L_84BF1B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF18u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF18u, 4u, 3u, cpu.address("abs", 0x2105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF18 STA
    hw.write(cpu.address("abs", 0x2105u), cpu.a, cpu.m8?8:16);
    goto L_84BF1B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF18u,0x84BF18u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BF1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF1Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF1Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF1Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF1B LDA
    cpu.setA(0x6u, 8);
    goto L_84BF1D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF1Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF1Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF1B LDA
    cpu.setA(0x6u, 8);
    goto L_84BF1D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF1Bu,0x84BF1Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BF1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF1Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF1Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF1Du, 4u, 3u, cpu.address("abs", 0x210Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF1D STA
    hw.write(cpu.address("abs", 0x210Bu), cpu.a, cpu.m8?8:16);
    goto L_84BF20;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF1Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF1Du, 4u, 3u, cpu.address("abs", 0x210Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF1D STA
    hw.write(cpu.address("abs", 0x210Bu), cpu.a, cpu.m8?8:16);
    goto L_84BF20;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF1Du,0x84BF1Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BF20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF20u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF20u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF20u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF20 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_84BF22;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF20u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF20u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF20 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_84BF22;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF20u,0x84BF20u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BF22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF22u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF22u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF22u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF22 REP
    cpu.rep(0x20u);
    goto L_84BF24;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF22u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF22u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF22 REP
    cpu.rep(0x20u);
    goto L_84BF24;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF22u,0x84BF22u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BF24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF24u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF24u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF24u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF24 LDA
    cpu.setA(0x30u, 16);
    goto L_84BF27;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF24u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF24u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF24 LDA
    cpu.setA(0x30u, 16);
    goto L_84BF27;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF24u,0x84BF24u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BF27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF27u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF27u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF27u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF27 STA
    hw.write(cpu.address("dp", 0x6Fu), cpu.a, cpu.m8?8:16);
    goto L_84BF29;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF27u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF27u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF27 STA
    hw.write(cpu.address("dp", 0x6Fu), cpu.a, cpu.m8?8:16);
    goto L_84BF29;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF27u,0x84BF27u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BF29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF29u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF29u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF29u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF29 BRA -> $84BF45
    goto L_84BF45;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF29u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF29u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF29 BRA -> $84BF45
    goto L_84BF45;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF29u,0x84BF29u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BF2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF2Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF2Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF2Bu, 6u, 3u, cpu.address("abs", 0xC1FCu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84BF2B JSR -> $84C1FC stack real
    { cpu.push16Value(hw,0xBF2Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBF2Eu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC1FCu), 0x84BF2Bu); }
    goto L_84BF2E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF2Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF2Bu, 6u, 3u, cpu.address("abs", 0xC1FCu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84BF2B JSR -> $84C1FC stack real
    { cpu.push16Value(hw,0xBF2Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBF2Eu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC1FCu), 0x84BF2Bu); }
    goto L_84BF2E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF2Bu,0x84BF2Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BF2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF2Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF2Eu,0x84BF2Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF2Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF2Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF2E REP
    cpu.rep(0x20u);
    goto L_84BF30;
L_84BF30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF30u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF30u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF30 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BF32;
L_84BF32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF32u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF32u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF32 BEQ -> $84BF45
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_84BF45; }
    goto L_84BF34;
L_84BF34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF34u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF34u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF34 SEP
    cpu.sep(0x20u);
    goto L_84BF36;
L_84BF36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF36u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF36u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF36 LDA
    cpu.setA(0xBu, 8);
    goto L_84BF38;
L_84BF38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF38u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF38u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF38 STA
    hw.write(cpu.address("dp", 0x49u), cpu.a, cpu.m8?8:16);
    goto L_84BF3A;
L_84BF3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF3Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF3Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF3A LDA
    cpu.setA(0x81u, 8);
    goto L_84BF3C;
L_84BF3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF3Cu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF3Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF3C XBA
    cpu.xba();
    goto L_84BF3D;
L_84BF3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF3Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF3Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF3D LDA
    cpu.setA(0xFu, 8);
    goto L_84BF3F;
L_84BF3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF3Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF3Fu, 8u, 4u, 0x8086F4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84BF3F JSL -> $8086F4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBF42u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBF43u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8086F4u, 0x84BF3Fu); }
    goto L_84BF43;
L_84BF43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF43u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF43u,0x84BF43u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF43u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF43u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF43 REP
    cpu.rep(0x20u);
    goto L_84BF45;
L_84BF45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF45u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF45u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF45u, 8u, 4u, 0x8098BBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84BF45 JSL -> $8098BB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBF48u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBF49u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098BBu, 0x84BF45u); }
    goto L_84BF49;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF45u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF45u, 8u, 4u, 0x8098BBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84BF45 JSL -> $8098BB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBF48u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBF49u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098BBu, 0x84BF45u); }
    goto L_84BF49;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF45u,0x84BF45u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BF49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF49u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF49u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF49u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84BF49 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84BF49u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84BF49u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF49u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF49u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84BF49 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84BF49u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84BF49u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF49u,0x84BF49u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_84BEF8_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84BEF8u: goto L_84BEF8;
    case 0x84BEFAu: goto L_84BEFA;
    case 0x84BEFDu: goto L_84BEFD;
    case 0x84BEFFu: goto L_84BEFF;
    case 0x84BF01u: goto L_84BF01;
    case 0x84BF04u: goto L_84BF04;
    case 0x84BF06u: goto L_84BF06;
    case 0x84BF09u: goto L_84BF09;
    case 0x84BF0Cu: goto L_84BF0C;
    case 0x84BF0Fu: goto L_84BF0F;
    case 0x84BF11u: goto L_84BF11;
    case 0x84BF14u: goto L_84BF14;
    case 0x84BF16u: goto L_84BF16;
    case 0x84BF18u: goto L_84BF18;
    case 0x84BF1Bu: goto L_84BF1B;
    case 0x84BF1Du: goto L_84BF1D;
    case 0x84BF20u: goto L_84BF20;
    case 0x84BF22u: goto L_84BF22;
    case 0x84BF24u: goto L_84BF24;
    case 0x84BF27u: goto L_84BF27;
    case 0x84BF29u: goto L_84BF29;
    case 0x84BF2Bu: goto L_84BF2B;
    case 0x84BF2Eu: goto L_84BF2E;
    case 0x84BF30u: goto L_84BF30;
    case 0x84BF32u: goto L_84BF32;
    case 0x84BF34u: goto L_84BF34;
    case 0x84BF36u: goto L_84BF36;
    case 0x84BF38u: goto L_84BF38;
    case 0x84BF3Au: goto L_84BF3A;
    case 0x84BF3Cu: goto L_84BF3C;
    case 0x84BF3Du: goto L_84BF3D;
    case 0x84BF3Fu: goto L_84BF3F;
    case 0x84BF43u: goto L_84BF43;
    case 0x84BF45u: goto L_84BF45;
    case 0x84BF49u: goto L_84BF49;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84BEF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEF8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEF8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEF8 REP
    cpu.rep(0x20u);
    goto L_84BEFA;
L_84BEFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEFAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEFAu, 6u, 3u, cpu.address("abs", 0xC197u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84BEFA JSR -> $84C197 stack real
    { cpu.push16Value(hw,0xBEFCu); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBEFDu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC197u), 0x84BEFAu); }
    goto L_84BEFD;
L_84BEFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEFDu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEFDu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEFDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEFD BCC -> $84BF2B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_84BF2B; }
    goto L_84BEFF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEFDu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEFDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEFD BCC -> $84BF2B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_84BF2B; }
    goto L_84BEFF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBEFDu,0x84BEFDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BEFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEFFu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEFFu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEFFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEFF REP
    cpu.rep(0x20u);
    goto L_84BF01;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEFFu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEFFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BEFF REP
    cpu.rep(0x20u);
    goto L_84BF01;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBEFFu,0x84BEFFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BF01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF01u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF01u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF01u, 5u, 3u, cpu.address("abs", 0x06EFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF01 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6EFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BF04;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF01u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF01u, 5u, 3u, cpu.address("abs", 0x06EFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF01 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x6EFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BF04;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF01u,0x84BF01u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BF04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF04u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF04u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF04u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF04 BNE -> $84BF11
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84BF11; }
    goto L_84BF06;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF04u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF04u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF04 BNE -> $84BF11
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_84BF11; }
    goto L_84BF06;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF04u,0x84BF04u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BF06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF06u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF06u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF06u, 8u, 3u, cpu.address("abs", 0x06EFu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF06 INC
    cpu.incMem(hw, cpu.address("abs", 0x6EFu), cpu.m8?8:16);
    goto L_84BF09;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF06u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF06u, 8u, 3u, cpu.address("abs", 0x06EFu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF06 INC
    cpu.incMem(hw, cpu.address("abs", 0x6EFu), cpu.m8?8:16);
    goto L_84BF09;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF06u,0x84BF06u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BF09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF09u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF09u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF09u, 5u, 3u, cpu.address("abs", 0x1902u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF09 STZ
    hw.write(cpu.address("abs", 0x1902u), 0, cpu.m8?8:16);
    goto L_84BF0C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF09u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF09u, 5u, 3u, cpu.address("abs", 0x1902u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF09 STZ
    hw.write(cpu.address("abs", 0x1902u), 0, cpu.m8?8:16);
    goto L_84BF0C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF09u,0x84BF09u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BF0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF0Cu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF0Cu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF0Cu, 8u, 3u, cpu.address("abs", 0x0122u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF0C INC
    cpu.incMem(hw, cpu.address("abs", 0x122u), cpu.m8?8:16);
    goto L_84BF0F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF0Cu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF0Cu, 8u, 3u, cpu.address("abs", 0x0122u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF0C INC
    cpu.incMem(hw, cpu.address("abs", 0x122u), cpu.m8?8:16);
    goto L_84BF0F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF0Cu,0x84BF0Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BF0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF0Fu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF0Fu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF0Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF0F BRA -> $84BF2B
    goto L_84BF2B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF0Fu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF0Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF0F BRA -> $84BF2B
    goto L_84BF2B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF0Fu,0x84BF0Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BF11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF11u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF11u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF11u, 5u, 3u, cpu.address("abs", 0x06EFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF11 STZ
    hw.write(cpu.address("abs", 0x6EFu), 0, cpu.m8?8:16);
    goto L_84BF14;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF11u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF11u, 5u, 3u, cpu.address("abs", 0x06EFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF11 STZ
    hw.write(cpu.address("abs", 0x6EFu), 0, cpu.m8?8:16);
    goto L_84BF14;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF11u,0x84BF11u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BF14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF14u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF14u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF14u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF14 SEP
    cpu.sep(0x20u);
    goto L_84BF16;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF14u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF14u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF14 SEP
    cpu.sep(0x20u);
    goto L_84BF16;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF14u,0x84BF14u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BF16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF16u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF16u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF16u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF16 LDA
    cpu.setA(0x1u, 8);
    goto L_84BF18;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF16u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF16u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF16 LDA
    cpu.setA(0x1u, 8);
    goto L_84BF18;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF16u,0x84BF16u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BF18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF18u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF18u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF18u, 4u, 3u, cpu.address("abs", 0x2105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF18 STA
    hw.write(cpu.address("abs", 0x2105u), cpu.a, cpu.m8?8:16);
    goto L_84BF1B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF18u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF18u, 4u, 3u, cpu.address("abs", 0x2105u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF18 STA
    hw.write(cpu.address("abs", 0x2105u), cpu.a, cpu.m8?8:16);
    goto L_84BF1B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF18u,0x84BF18u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BF1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF1Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF1Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF1Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF1B LDA
    cpu.setA(0x6u, 8);
    goto L_84BF1D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF1Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF1Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF1B LDA
    cpu.setA(0x6u, 8);
    goto L_84BF1D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF1Bu,0x84BF1Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BF1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF1Du))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF1Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF1Du, 4u, 3u, cpu.address("abs", 0x210Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF1D STA
    hw.write(cpu.address("abs", 0x210Bu), cpu.a, cpu.m8?8:16);
    goto L_84BF20;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF1Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF1Du, 4u, 3u, cpu.address("abs", 0x210Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF1D STA
    hw.write(cpu.address("abs", 0x210Bu), cpu.a, cpu.m8?8:16);
    goto L_84BF20;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF1Du,0x84BF1Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BF20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF20u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF20u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF20u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF20 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_84BF22;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF20u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF20u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF20 INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_84BF22;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF20u,0x84BF20u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BF22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF22u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF22u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF22u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF22 REP
    cpu.rep(0x20u);
    goto L_84BF24;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF22u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF22u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF22 REP
    cpu.rep(0x20u);
    goto L_84BF24;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF22u,0x84BF22u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BF24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF24u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF24u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF24u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF24 LDA
    cpu.setA(0x30u, 16);
    goto L_84BF27;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF24u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF24u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF24 LDA
    cpu.setA(0x30u, 16);
    goto L_84BF27;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF24u,0x84BF24u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BF27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF27u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF27u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF27u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF27 STA
    hw.write(cpu.address("dp", 0x6Fu), cpu.a, cpu.m8?8:16);
    goto L_84BF29;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF27u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF27u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF27 STA
    hw.write(cpu.address("dp", 0x6Fu), cpu.a, cpu.m8?8:16);
    goto L_84BF29;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF27u,0x84BF27u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BF29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF29u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF29u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF29u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF29 BRA -> $84BF45
    goto L_84BF45;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF29u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF29u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF29 BRA -> $84BF45
    goto L_84BF45;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF29u,0x84BF29u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BF2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF2Bu))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF2Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF2Bu, 6u, 3u, cpu.address("abs", 0xC1FCu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84BF2B JSR -> $84C1FC stack real
    { cpu.push16Value(hw,0xBF2Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBF2Eu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC1FCu), 0x84BF2Bu); }
    goto L_84BF2E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF2Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF2Bu, 6u, 3u, cpu.address("abs", 0xC1FCu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84BF2B JSR -> $84C1FC stack real
    { cpu.push16Value(hw,0xBF2Du); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBF2Eu,false); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC1FCu), 0x84BF2Bu); }
    goto L_84BF2E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF2Bu,0x84BF2Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BF2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF2Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF2Eu,0x84BF2Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF2Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF2Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF2E REP
    cpu.rep(0x20u);
    goto L_84BF30;
L_84BF30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF30u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF30u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF30 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84BF32;
L_84BF32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF32u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF32u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF32 BEQ -> $84BF45
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_84BF45; }
    goto L_84BF34;
L_84BF34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF34u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF34u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF34 SEP
    cpu.sep(0x20u);
    goto L_84BF36;
L_84BF36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF36u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF36u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF36 LDA
    cpu.setA(0xBu, 8);
    goto L_84BF38;
L_84BF38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF38u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF38u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF38 STA
    hw.write(cpu.address("dp", 0x49u), cpu.a, cpu.m8?8:16);
    goto L_84BF3A;
L_84BF3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF3Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF3Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF3A LDA
    cpu.setA(0x81u, 8);
    goto L_84BF3C;
L_84BF3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF3Cu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF3Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF3C XBA
    cpu.xba();
    goto L_84BF3D;
L_84BF3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF3Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF3Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF3D LDA
    cpu.setA(0xFu, 8);
    goto L_84BF3F;
L_84BF3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF3Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF3Fu, 8u, 4u, 0x8086F4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84BF3F JSL -> $8086F4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBF42u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBF43u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8086F4u, 0x84BF3Fu); }
    goto L_84BF43;
L_84BF43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF43u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF43u,0x84BF43u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF43u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF43u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84BF43 REP
    cpu.rep(0x20u);
    goto L_84BF45;
L_84BF45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF45u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF45u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF45u, 8u, 4u, 0x8098BBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84BF45 JSL -> $8098BB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBF48u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBF49u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098BBu, 0x84BF45u); }
    goto L_84BF49;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF45u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF45u, 8u, 4u, 0x8098BBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84BF45 JSL -> $8098BB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBF48u); hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBF49u,true); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098BBu, 0x84BF45u); }
    goto L_84BF49;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF45u,0x84BF45u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84BF49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBF49u))return;
  // 2 variantes de decodificacao M/X para este endereco.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF49u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF49u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84BF49 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84BF49u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84BF49u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBF49u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBF49u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84BF49 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false)){ if(forja65_is_stack_return_target(dst,hw)){cpu.pop16Value(hw);hw.requestDispatch(dst,0x84BF49u);return;} if(hw.romOffset(dst)==(std::size_t)-1)return; hw.unresolvedReturn(0x84BF49u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBF49u,0x84BF49u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

