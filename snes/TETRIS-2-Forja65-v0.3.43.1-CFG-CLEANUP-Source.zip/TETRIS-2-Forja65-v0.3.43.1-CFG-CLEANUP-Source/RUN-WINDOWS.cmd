@echo off
setlocal
cd /d "%~dp0"
if exist game.exe goto run
if exist bin\game.exe (cd bin & goto run)
echo Execute BUILD-WINDOWS.cmd primeiro.
pause
exit /b 1
:run
game.exe
set CODE=%ERRORLEVEL%
if not "%CODE%"=="0" (echo. & echo O port encerrou com erro %CODE%. & if exist forja65-last-error.txt type forja65-last-error.txt & echo. & echo Veja tambem forja65-crash-trace.txt e forja65-runtime-hints.txt, se existirem. & pause)
exit /b %CODE%
