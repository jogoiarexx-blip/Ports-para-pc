@echo off
setlocal
cd /d "%~dp0"
set FRAMES=%~1
if "%FRAMES%"=="" set FRAMES=300
set LIMIT=%~2
if "%LIMIT%"=="" set LIMIT=50000000
set FORJA65_HEADLESS=1
set FORJA65_HEADLESS_FRAMES=%FRAMES%
set FORJA65_WATCHDOG_INSTRUCTIONS=%LIMIT%
if exist game.exe goto run
if exist bin\game.exe (cd bin & goto run)
if exist build-win\Release\game.exe (cd build-win\Release & goto run)
echo Execute BUILD-WINDOWS.cmd primeiro.
pause
exit /b 1
:run
echo [Forja65 Oracle] Executando ate descobrir novo fluxo/estado ou completar %FRAMES% frames...
game.exe
set CODE=%ERRORLEVEL%
echo.
if exist forja65-oracle-hints.txt (echo === ORACLE HINTS === & type forja65-oracle-hints.txt & echo. & echo Importe forja65-oracle-hints.txt na Forja65; a analise sera refeita automaticamente.) else (echo Nenhum alvo novo foi descoberto nesta execucao.)
exit /b %CODE%
