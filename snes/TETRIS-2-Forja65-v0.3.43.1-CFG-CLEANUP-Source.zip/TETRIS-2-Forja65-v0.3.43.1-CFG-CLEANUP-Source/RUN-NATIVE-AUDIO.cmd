@echo off
setlocal
cd /d "%~dp0"
set FORJA65_AUDIO_MODE=native
set FORJA65_AUDIO_DUMP=1
set FORJA65_HEADLESS=1
set FORJA65_HEADLESS_FRAMES=%~1
if "%FORJA65_HEADLESS_FRAMES%"=="" set FORJA65_HEADLESS_FRAMES=600
call RUN-WINDOWS.cmd
echo Audio PCM: forja65-native-audio.wav
pause
