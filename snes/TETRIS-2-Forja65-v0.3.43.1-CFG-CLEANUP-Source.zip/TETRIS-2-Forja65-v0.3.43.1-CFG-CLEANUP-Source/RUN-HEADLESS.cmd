@echo off
setlocal
cd /d "%~dp0"
set FORJA65_HEADLESS=1
if "%FORJA65_HEADLESS_FRAMES%"=="" set FORJA65_HEADLESS_FRAMES=2
if "%FORJA65_WATCHDOG_INSTRUCTIONS%"=="" set FORJA65_WATCHDOG_INSTRUCTIONS=50000000
if exist game.exe goto run
if exist build-win\Release\game.exe (cd build-win\Release & goto run)
if exist bin\game.exe (cd bin & goto run)
echo Execute BUILD-WINDOWS.cmd primeiro.
pause
exit /b 1
:run
game.exe
set CODE=%ERRORLEVEL%
if not "%CODE%"=="0" (echo. & echo HEADLESS encerrou com erro %CODE%. & if exist forja65-last-error.txt type forja65-last-error.txt & if exist forja65-crash-trace.txt type forja65-crash-trace.txt & pause)
exit /b %CODE%
