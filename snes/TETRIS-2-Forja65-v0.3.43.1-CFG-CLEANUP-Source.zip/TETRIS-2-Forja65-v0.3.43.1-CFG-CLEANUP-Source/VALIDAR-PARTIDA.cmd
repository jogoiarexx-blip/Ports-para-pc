@echo off
setlocal
cd /d "%~dp0"
node forja-tooling\tools\forja65.js converge "%~dp0." --frames 6200 --rounds 32 --replay "%~dp0validation\input-pause-retry.txt"
set "CODE=%ERRORLEVEL%"
pause
exit /b %CODE%
