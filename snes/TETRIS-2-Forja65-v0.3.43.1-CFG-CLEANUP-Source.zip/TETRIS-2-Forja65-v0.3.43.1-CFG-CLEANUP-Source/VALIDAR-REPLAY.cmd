@echo off
setlocal
cd /d "%~dp0"
node forja-tooling\tools\forja65.js converge "%~dp0." --frames 1200 --rounds 32 --replay "%~dp0validation\input-gameplay.txt"
set "CODE=%ERRORLEVEL%"
pause
exit /b %CODE%
