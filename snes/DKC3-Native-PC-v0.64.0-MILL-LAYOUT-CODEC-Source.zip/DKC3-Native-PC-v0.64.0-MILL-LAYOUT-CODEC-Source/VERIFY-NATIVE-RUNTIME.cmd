@echo off
setlocal
cd /d "%~dp0"
set BAD=0
if not exist DKC3NativePC.exe (echo ERRO: DKC3NativePC.exe nao encontrado.& set BAD=1)
if not exist assets\native\runtime.nassets (echo ERRO: pacote nativo ausente.& set BAD=1)
if exist rom (echo ERRO: ROM nao deve integrar o pacote runtime.& set BAD=1)
for %%D in (input tools src tests docs) do if exist "%%D" (echo ERRO: pasta de desenvolvimento presente no runtime: %%D& set BAD=1)
if "%BAD%"=="1" exit /b 1
echo OK: estrutura runtime nativa, sem ROM. Fidelidade completa ainda nao demonstrada.
exit /b 0
