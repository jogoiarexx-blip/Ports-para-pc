# DKC3 native port maintenance

When translating a ROM behavior, read docs/ROM-PORT-WORKFLOW.md and use
`tools/rom_workbench.py` yourself before changing the C++ routine. The user
is not expected to operate the analysis tool. Use the shipped ROM-bound index
and generate a focused report/packet for the original addresses involved.

The workbench is static reading, not CPU/PPU execution or an automatic porter.
Catalog spans and source mentions are leads, not complete-function or coverage
proof. Resolve RAM/DBR/direct-page dependencies and unknown dispatch/state
contracts explicitly. Do not promote objects to SUPPORTED from indexing alone.

Preserve byte/word wrapping, carry/sign semantics and table pointers. Read
profiles from ROM where practical; avoid duplicating descriptor/table values
in C++. Keep bounded original-routine comparisons separate from game runtime.
Validate affected behavior and the existing input gold routes without modifying
actor positions, velocities, inventory or health inside those routes.

The compressed index contains structural facts only. Do not copy external
assembly source into the project. Regenerate against a reviewed external
checkout when the ROM changes; never bypass a SHA256 mismatch to keep decoding.
