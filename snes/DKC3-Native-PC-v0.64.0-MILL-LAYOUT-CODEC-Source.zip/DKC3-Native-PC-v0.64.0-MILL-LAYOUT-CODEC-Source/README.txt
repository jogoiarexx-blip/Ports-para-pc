DKC3 Native PC v0.64.0 - MILL Layout Codec + Windows UTF-8

IMPLEMENTADO
- Extrator de pacote semantico runtime.nassets; modo native nao abre a ROM.
- Auditor generico de placements continua lendo FE/FF sem exigir renderer/terreno.
- Novo decoder generico de familia de cenario: shared_data FD -> tabela B7:B01B -> config -> header de assets -> streams comprimidos.
- PIER deixou de depender de offsets hardcoded para level map, map32, definicoes de terreno e foreground; usa o mesmo decoder generico.
- MILL $198D/$1998 agora e PARTIAL com layout comprovado: familia 5, config B7:B302, terrain handler B7:CB2B e shape 7 row-major/160 bytes.
- Doorstop/Squeals/Murky compartilham os assets MILL decodificados e os limites de submapa originais; lookup de metatile usa shape/stride da ROM.
- Doorstop continua com 118/118 Sprite IDs resolvidos, 113 PARTIAL e 5 UNKNOWN.
- Ferramentas Python e testes CMake usam UTF-8 explicito; o Native Map preserva o titulo com o caractere -> Unicode sem depender do charmap do Windows.

VALIDACAO
- Build C++20/GCC concluido nesta versao.
- Decoder PIER revalidado pelo teste de runtime apos a generalizacao.
- MILL: level map 0x9740 bytes, map32 0x4400, terrain defs 0x03D4 e foreground 0x7120 decodificados diretamente da ROM.
- Native Map passa inclusive sob locale C/PYTHONIOENCODING=cp1252, cobrindo a falha observada no Windows.
- Lakeside/Tidal permanecem protegidos pela suite existente; esta versao nao declara Doorstop completa.

WINDOWS
BUILD-WINDOWS.cmd requer Visual Studio 2022 C++ e CMake 3.20+.
Agora define PYTHONUTF8=1 e PYTHONIOENCODING=utf-8 antes de configurar/buildar/testar.
Gera DKC3-Native-PC-v0.64.0-MILL-LAYOUT-CODEC-Portable-Windows-x64.zip.
EXE Windows nao foi compilado neste ambiente Linux; a regressao de encoding foi reproduzida com locale restritivo e corrigida por teste.

LIMITES IMPORTANTES
MILL agora tem codec estrutural de layout/assets, mas RomLevelRuntime ainda bloqueia o renderer MILL: shape 7, B7:CB2B, palette/background e colisao precisam ser ligados ao runtime antes de remover a secao host de Doorstop.
Os cinco objetos 0x0144/0x027C continuam UNKNOWN e nao sao o gargalo dominante.
Fisica/controlador, audio original, efeitos especificos e outros objetos permanecem parciais.

DETALHES E COMANDOS
Leia docs/NATIVE-MIGRATION.md, docs/ROM-MILL-LAYOUT-PACKET.md e docs/VALIDACAO-v0.64.0.md.
O ZIP de fontes preserva a ROM fornecida como entrada de desenvolvimento.
O pacote runtime gerado nao inclui essa ROM.
