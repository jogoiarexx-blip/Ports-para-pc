#include "core/LevelSession.h"
#include "core/NativeScene.h"
#include <iostream>
#include <vector>
int main(){
  using namespace dkc3;
  GameSession s;if(!s.init("assets/levels/levels.index","doorstop")){std::cerr<<"session load failed\n";return 2;}
  InputState none{};for(int i=0;i<120;i++)s.step(none,1.0f/60.0f);
  InputState up{};up.up=true;s.step(up,1.0f/60.0f);up.up=false;for(int i=0;i<30;i++)s.step(up,1.0f/60.0f);
  InputState right{};right.right=true;right.run=true;for(int i=0;i<220;i++)s.step(right,1.0f/60.0f);
  InputState door{};door.up=true;s.step(door,1.0f/60.0f);
  if(s.currentLevel()!="tidal-trouble"){std::cerr<<"transition failed\n";return 3;}
  bool enteredWater=false;s.setAutoTransitions(false);std::string exit;
  for(int i=0;i<10000&&!s.takeExitRequest(exit);++i){InputState in{};in.right=true;in.run=true;in.jump=i%100<15;if(s.game().inWater()){in.up=true;in.jump=true;}else in.attack=i%34==0;s.step(in,1.f/60);enteredWater|=s.game().inWater();}
  std::vector<uint32_t> fb(256*224);s.render(fb.data(),256,224);const auto&p=s.game().player();
  std::cout<<"NATIVE_SESSION_OK level="<<s.currentLevel()<<" transitions="<<s.transitions()
           <<" original_id="<<s.game().world().originalLevelId<<" water="<<enteredWater
           <<" pos="<<p.pos.x<<","<<p.pos.y<<" page="<<s.game().activeScenePage()<<"/"<<s.game().scenePageCount()<<" coins="<<s.game().coins()
           <<" framehash="<<std::hex<<hashFrame(fb.data(),fb.size())<<std::dec<<"\n";
  return (s.transitions()!=1||s.game().world().originalLevelId!=0x27||!enteredWater||s.game().scenePageCount()!=1||!s.game().hasRomScene()||exit!="skiddas-row")?4:0;
}
