#include "core/desktop_viewport.h"
// DKC3 Native-PC - launcher Win32 (GDI + XInput). Sem emulacao: so conversa com o runtime nativo.
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <mmsystem.h>
#include <xinput.h>
#include <algorithm>
#include <chrono>
#include <cstdio>
#include <cstdint>
#include <string>
#include <vector>
#include "../core/Audio.h"
#include "../core/Bmp.h"
#include "../core/Frontend.h"
#include "../core/Hud.h"
#include "../core/LevelSession.h"
#include "../core/Version.h"
#include "../core/WorldMap.h"
#pragma comment(lib,"Xinput9_1_0.lib")
#pragma comment(lib,"winmm.lib")
using namespace dkc3;

namespace {
constexpr int FW = 256, FH = 224;

bool running = true;
bool paused = false;
bool fullscreen = false;
bool integerScale = false;
bool smoothScale = false, filterChanged = false;
bool showHelp = false;
bool wantRestart = false, wantShot = false, wantPauseToggle = false;
bool hudOn = true, debugOn = false;
bool hudChanged = false, debugChanged = false;
bool muteToggle = false; int volumeStep = 0;
bool menuStartKey = false, menuCancelKey = false, caveKey = false;
InputState keys{};
bool shiftRun = false;
WINDOWPLACEMENT savedPlacement{ sizeof(WINDOWPLACEMENT) };
DWORD savedStyle = 0;

void toggleFullscreen(HWND hwnd) {
  if (!fullscreen) {
    MONITORINFO mi{ sizeof(mi) };
    if (!GetWindowPlacement(hwnd, &savedPlacement) || !GetMonitorInfoW(MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST), &mi)) return;
    savedStyle = (DWORD)GetWindowLongW(hwnd, GWL_STYLE);
    SetWindowLongW(hwnd, GWL_STYLE, (LONG)(savedStyle & ~WS_OVERLAPPEDWINDOW));
    SetWindowPos(hwnd, HWND_TOP, mi.rcMonitor.left, mi.rcMonitor.top, mi.rcMonitor.right - mi.rcMonitor.left, mi.rcMonitor.bottom - mi.rcMonitor.top, SWP_NOOWNERZORDER | SWP_FRAMECHANGED);
    fullscreen = true;
  } else {
    SetWindowLongW(hwnd, GWL_STYLE, (LONG)savedStyle);
    SetWindowPlacement(hwnd, &savedPlacement);
    SetWindowPos(hwnd, nullptr, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_NOOWNERZORDER | SWP_FRAMECHANGED);
    fullscreen = false;
  }
}

LRESULT CALLBACK WndProc(HWND h, UINT m, WPARAM w, LPARAM l) {
  switch (m) {
    case WM_CLOSE: case WM_DESTROY: running = false; PostQuitMessage(0); return 0;
    case WM_ERASEBKGND: return 1;
    case WM_KILLFOCUS: keys = InputState{}; shiftRun = false; menuStartKey = menuCancelKey = caveKey = false; paused = true; return 0;
    case WM_SYSKEYDOWN:
      if (w == VK_RETURN && (l & (1 << 29))) { toggleFullscreen(h); return 0; }
      break;
    case WM_KEYDOWN: case WM_KEYUP: {
      const bool d = (m == WM_KEYDOWN);
      const bool fresh = d && !(l & (1 << 30));
      switch (w) {
        case VK_LEFT: case 'A': keys.left = d; break;
        case VK_RIGHT: case 'D': keys.right = d; break;
        case VK_UP: case 'W': keys.up = d; break;
        case VK_DOWN: case 'S': keys.down = d; break;
        case VK_SPACE: case 'Z': keys.jump = d; break;
        case 'X': keys.attack = d; break;
        case VK_SHIFT: shiftRun = d; break;
        case 'Q': keys.switchCharacter = d; break;
        case 'C': caveKey = d; break;
        case VK_RETURN: menuStartKey = d; break;
        case VK_BACK: menuCancelKey = d; break;
        case VK_ESCAPE: if (d) running = false; break;
        case 'P': if (fresh) wantPauseToggle = true; break;
        case 'R': case VK_F5: if (fresh) wantRestart = true; break;
        case VK_F1: if (fresh) showHelp = !showHelp; break;
        case VK_F2: if (fresh) wantShot = true; break;
        case VK_F3: if (fresh) { hudOn = !hudOn; hudChanged = true; } break;
        case VK_F4: if (fresh) { debugOn = !debugOn; debugChanged = true; } break;
        case VK_F6: if (fresh) integerScale = !integerScale; break;
        case VK_F7: if (fresh) { smoothScale = !smoothScale; filterChanged = true; } break;
        case VK_F11: if (fresh) toggleFullscreen(h); break;
        case 'M': if (fresh) muteToggle = true; break;
        case VK_OEM_PLUS: case VK_ADD: if (fresh) volumeStep = 1; break;
        case VK_OEM_MINUS: case VK_SUBTRACT: if (fresh) volumeStep = -1; break;
      }
      return 0;
    }
  }
  return DefWindowProcW(h, m, w, l);
}

class AudioOut {
 public:
  bool open() {
    WAVEFORMATEX fmt{}; fmt.wFormatTag = WAVE_FORMAT_PCM; fmt.nChannels = 1; fmt.nSamplesPerSec = SfxMixer::kRate; fmt.wBitsPerSample = 16;
    fmt.nBlockAlign = 2; fmt.nAvgBytesPerSec = fmt.nSamplesPerSec * 2;
    if (waveOutOpen(&dev_, WAVE_MAPPER, &fmt, 0, 0, CALLBACK_NULL) != MMSYSERR_NOERROR) { dev_ = nullptr; return false; }
    for (int i = 0; i < kBufs; ++i) {
      data_[i].assign(kFrames, 0); hdr_[i] = WAVEHDR{}; hdr_[i].lpData = (LPSTR)data_[i].data(); hdr_[i].dwBufferLength = kFrames * 2;
      waveOutPrepareHeader(dev_, &hdr_[i], sizeof(WAVEHDR)); waveOutWrite(dev_, &hdr_[i], sizeof(WAVEHDR));
    }
    return true;
  }
  void pump(SfxMixer& mixer) {
    if (!dev_) return;
    for (int i = 0; i < kBufs; ++i)
      if (hdr_[i].dwFlags & WHDR_DONE) { mixer.mix(data_[i].data(), kFrames); hdr_[i].dwFlags &= ~WHDR_DONE; waveOutWrite(dev_, &hdr_[i], sizeof(WAVEHDR)); }
  }
  void close() {
    if (!dev_) return;
    waveOutReset(dev_);
    for (int i = 0; i < kBufs; ++i) waveOutUnprepareHeader(dev_, &hdr_[i], sizeof(WAVEHDR));
    waveOutClose(dev_); dev_ = nullptr;
  }
 private:
  static constexpr int kBufs = 4, kFrames = SfxMixer::kRate / 50;
  HWAVEOUT dev_ = nullptr; WAVEHDR hdr_[kBufs]{}; std::vector<int16_t> data_[kBufs];
};

std::wstring widen(const std::string& s) { return std::wstring(s.begin(), s.end()); }

struct CommandOptions { bool directLevel=false; bool skipMap=false; std::string level="doorstop"; };
CommandOptions parseCommandLine(const char* cmd) {
  CommandOptions o;const std::string c=cmd?cmd:"";o.skipMap=c.find("--skip-map")!=std::string::npos;
  const std::string flag="--level";auto p=c.find(flag);if(p==std::string::npos)return o;
  std::string v=c.substr(p+flag.size());size_t a=v.find_first_not_of(" \t\"="),b=v.find_last_not_of(" \t\"");
  o.directLevel=true;o.level=a==std::string::npos?"doorstop":v.substr(a,b-a+1);return o;
}

void drawHelp(uint32_t* fb) {
  static const char* lines[] = {
    "SETAS/WASD  MOVER", "Z/ESPACO  PULAR  (SEGURE = MAIS ALTO)", "X ROLAR / PEGAR   SHIFT CORRER", "SEGURE X CARREGAR / SOLTE LANCAR", "BAIXO + X COLOCAR O BARRIL", "W/CIMA  ALAVANCA/PORTA   Q  TROCAR KONG",
    "P  PAUSA   R  REINICIAR FASE", "F2  PRINT   F3  HUD   F4  DEBUG", "F6  ESCALA INTEIRA   F7  FILTRO", "F11 TELA CHEIA   M MUDO   + / - VOLUME", "F1  FECHAR ESTA AJUDA" };
  const int n = (int)(sizeof(lines) / sizeof(lines[0]));
  hudFillRect(fb, FW, FH, 8, 30, FW - 16, n * 12 + 12, 0x000000u, 190);
  for (int i = 0; i < n; ++i) hudDrawText(fb, FW, FH, 14, 36 + i * 12, lines[i], i == n - 1 ? 0xffa0a0a0u : 0xffffffffu);
}

std::string nextShotPath() {
  CreateDirectoryA("screenshots", nullptr);SYSTEMTIME st;GetLocalTime(&st);char buf[128];
  std::snprintf(buf, sizeof buf, "screenshots\\dkc3_%04d%02d%02d_%02d%02d%02d_%03d.bmp", st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond, st.wMilliseconds);
  return buf;
}
}  // namespace

int WINAPI WinMain(HINSTANCE hi, HINSTANCE, LPSTR cmdLine, int) {
  timeBeginPeriod(1);
  const CommandOptions options=parseCommandLine(cmdLine);
  const wchar_t* cls = L"DKC3NativePC";
  WNDCLASSW wc{}; wc.lpfnWndProc = WndProc; wc.hInstance = hi; wc.lpszClassName = cls; wc.hCursor = LoadCursor(nullptr, IDC_ARROW); wc.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
  RegisterClassW(&wc);
  std::wstring title = L"DKC3 Native PC v" + widen(kVersion);
  HWND hwnd = CreateWindowExW(0, cls, title.c_str(), WS_OVERLAPPEDWINDOW | WS_VISIBLE, CW_USEDEFAULT, CW_USEDEFAULT, 1040, 936, nullptr, nullptr, hi, nullptr);

  Frontend frontend;frontend.init("saves");
  WorldMap worldMap;WorldMapState worldState{};GamePersistentState profilePersistent{};std::string saveLevel="lakeside-limbo";
  LevelCatalog mapCatalog;mapCatalog.load("assets/levels/levels.index");unsigned runtimeMapMask=0;
  if(mapCatalog.find("lakeside-limbo"))runtimeMapMask|=WorldMap::stageBit("lakeside-limbo");
  if(mapCatalog.find("doorstop"))runtimeMapMask|=WorldMap::stageBit("doorstop");
  if(mapCatalog.find("tidal-trouble"))runtimeMapMask|=WorldMap::stageBit("tidal-trouble");
  if(mapCatalog.find("skiddas-row"))runtimeMapMask|=WorldMap::stageBit("skiddas-row");
  enum class AppMode{Frontend,WorldMap,Game};AppMode appMode=AppMode::Frontend;
  GameSession session;bool sessionReady=false;
  if(options.directLevel){
    if(!session.init("assets/levels/levels.index",options.level)){
      std::string msg="Nao foi possivel carregar o catalogo/nivel nativo: "+options.level;MessageBoxA(hwnd,msg.c_str(),"DKC3 Native PC",MB_ICONERROR);timeEndPeriod(1);return 2;
    }
    session.setAutoTransitions(true);sessionReady=true;appMode=AppMode::Game;
  }

  SfxMixer mixer; AudioOut audio; audio.open();
  std::vector<uint32_t> fb((size_t)FW * FH),caveFrame(512u*448u);
  BITMAPINFO bi{}; bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER); bi.bmiHeader.biWidth = FW; bi.bmiHeader.biHeight = -FH;
  bi.bmiHeader.biPlanes = 1; bi.bmiHeader.biBitCount = 32; bi.bmiHeader.biCompression = BI_RGB;

  using clock = std::chrono::steady_clock;auto prev = clock::now();double acc = 0, helpTimer = sessionReady?6.0:0.0;const double dt = 1.0 / 60.0;
  std::string lastLevel,lastSavedLevel;bool lastPaused = !paused, prevStart = false, prevBack = false;FrontendScreen lastFrontend=FrontendScreen::SaveSelect;AppMode lastMode=(AppMode)99;
  showHelp = sessionReady;HBRUSH black = (HBRUSH)GetStockObject(BLACK_BRUSH);

  while (running) {
    MSG msg;while (PeekMessageW(&msg, nullptr, 0, 0, PM_REMOVE)) { TranslateMessage(&msg); DispatchMessageW(&msg); }
    auto now = clock::now();double elapsed = std::chrono::duration<double>(now - prev).count();prev = now;if (elapsed > 0.25) elapsed = 0.25;

    InputState in = keys;in.run = shiftRun || keys.attack;
    bool padStart=false,padBack=false,padCancel=false;
    XINPUT_STATE xs{};
    if (XInputGetState(0, &xs) == ERROR_SUCCESS) {
      const auto b = xs.Gamepad.wButtons;
      in.left |= (b & XINPUT_GAMEPAD_DPAD_LEFT) || (xs.Gamepad.sThumbLX < -9000);
      in.right |= (b & XINPUT_GAMEPAD_DPAD_RIGHT) || (xs.Gamepad.sThumbLX > 9000);
      in.up |= (b & XINPUT_GAMEPAD_DPAD_UP) || (xs.Gamepad.sThumbLY > 12000);
      in.down |= (b & XINPUT_GAMEPAD_DPAD_DOWN) || (xs.Gamepad.sThumbLY < -12000);
      in.jump |= (b & XINPUT_GAMEPAD_A) != 0;in.attack |= (b & XINPUT_GAMEPAD_X) != 0;
      in.run |= (b & XINPUT_GAMEPAD_X) || (b & XINPUT_GAMEPAD_RIGHT_SHOULDER);in.switchCharacter |= (b & XINPUT_GAMEPAD_Y) != 0;
      padStart=(b & XINPUT_GAMEPAD_START)!=0;padBack=(b & XINPUT_GAMEPAD_BACK)!=0;padCancel=(b & XINPUT_GAMEPAD_B)!=0;
      if(appMode==AppMode::Game&&sessionReady){if(padStart&&!prevStart)paused=!paused;if(padBack&&!prevBack)wantRestart=true;}
      prevStart=padStart;prevBack=padBack;
    } else { prevStart=false;prevBack=false; }

    if(appMode==AppMode::Game&&sessionReady&&wantPauseToggle){paused=!paused;wantPauseToggle=false;}else if(!sessionReady)wantPauseToggle=false;
    if(appMode==AppMode::Game&&sessionReady&&wantRestart){session.restart();wantRestart=false;paused=false;acc=0;}else if(!sessionReady)wantRestart=false;
    if(appMode==AppMode::Game&&sessionReady&&hudChanged){session.game().setHudEnabled(hudOn);hudChanged=false;}
    if(appMode==AppMode::Game&&sessionReady&&debugChanged){session.game().setDebugOverlay(debugOn);debugChanged=false;}
    if(filterChanged){if(sessionReady)session.game().showToastPublic(smoothScale?"FILTRO SUAVE":"PIXEL NITIDO");filterChanged=false;}
    if(muteToggle){mixer.setMuted(!mixer.muted());muteToggle=false;if(sessionReady)session.game().showToastPublic(mixer.muted()?"MUDO":"SOM LIGADO");}
    if(volumeStep){mixer.setVolume(mixer.volume()+0.1f*volumeStep);volumeStep=0;if(sessionReady)session.game().showToastPublic("VOLUME "+std::to_string((int)(mixer.volume()*100+0.5f))+"%");}

    acc += elapsed;int guard=0;
    if(appMode==AppMode::Frontend){
      FrontendInput fi;fi.up=in.up;fi.down=in.down;fi.confirm=in.jump||menuStartKey||padStart;fi.cancel=in.attack||menuCancelKey||padCancel||padBack;fi.start=menuStartKey||padStart;
      while(acc>=dt&&guard++<8){frontend.step(fi,(float)dt);acc-=dt;}
      if(guard>=8)acc=0;
      FrontendLaunchRequest req;
      if(frontend.takeLaunchRequest(req)){
        profilePersistent=req.persistent;worldState=req.worldMap;saveLevel=req.level;
        if(!options.skipMap){
          worldMap.init(worldState);worldMap.setRuntimeAvailableMask(runtimeMapMask);worldMap.setCurrentLevel(saveLevel);appMode=AppMode::WorldMap;paused=false;showHelp=false;acc=0;frontend.syncActiveSave(saveLevel,profilePersistent,&worldMap.state());
        }else if(session.init("assets/levels/levels.index",saveLevel,&profilePersistent)){
          session.setAutoTransitions(true);sessionReady=true;appMode=AppMode::Game;paused=false;showHelp=true;helpTimer=6.0;acc=0;lastSavedLevel=saveLevel;
          session.game().setHudEnabled(hudOn);session.game().setDebugOverlay(debugOn);frontend.syncActiveSave(saveLevel,profilePersistent,nullptr);
        }else{
          MessageBoxA(hwnd,"Nao foi possivel iniciar o nivel nativo salvo.","DKC3 Native PC ROM-first",MB_ICONERROR);
        }
      }
    }else if(appMode==AppMode::WorldMap){
      WorldMapInput mi;mi.fast=in.run;mi.left=in.left;mi.right=in.right;mi.up=in.up;mi.down=in.down;mi.confirm=in.jump||menuStartKey||padStart;mi.cancel=in.attack||menuCancelKey||padCancel||padBack;mi.cave=caveKey||in.switchCharacter;
      while(acc>=dt&&guard++<8){worldMap.step(mi,(float)dt);acc-=dt;}
      if(guard>=8)acc=0;
      if(worldMap.takeCaveSaveRequest()){
        worldState=worldMap.state();
        worldMap.acknowledgeCaveSave(frontend.activeSlot()>=0 && frontend.syncActiveSave(saveLevel,profilePersistent,&worldState));
      }
      std::string chosen;
      if(worldMap.takeLaunchRequest(chosen)){
        if(session.init("assets/levels/levels.index",chosen,&profilePersistent)){
          session.setAutoTransitions(false);sessionReady=true;appMode=AppMode::Game;paused=false;showHelp=true;helpTimer=6.0;acc=0;saveLevel=chosen;lastSavedLevel=chosen;
          session.game().setHudEnabled(hudOn);session.game().setDebugOverlay(debugOn);frontend.syncActiveSave(saveLevel,profilePersistent,&worldMap.state());
        }else{
          std::string m="A fase ainda nao esta disponivel no runtime: "+chosen;MessageBoxA(hwnd,m.c_str(),"DKC3 Native PC",MB_ICONWARNING);
        }
      }
    }else if(!paused){
      while(acc>=dt&&guard++<8){session.step(in,(float)dt);acc-=dt;}
      if(guard>=8)acc=0;
      if(session.game().lives()<=0){
        frontend.beginGameOver();sessionReady=false;appMode=AppMode::Frontend;
        paused=false;showHelp=false;acc=0;wantRestart=false;wantPauseToggle=false;
      }
      if(helpTimer>0){helpTimer-=elapsed;if(helpTimer<=0&&showHelp)showHelp=false;}
      if(sessionReady&&frontend.activeSlot()>=0&&session.currentLevel()!=lastSavedLevel){profilePersistent=session.game().persistentState();saveLevel=session.currentLevel();frontend.syncActiveSave(saveLevel,profilePersistent,&worldMap.state());lastSavedLevel=session.currentLevel();}
      std::string exitTarget;
      if(sessionReady&&!options.directLevel&&session.takeExitRequest(exitTarget)){
        profilePersistent=session.game().persistentState();const std::string completed=session.currentLevel();worldMap.completeStage(completed,exitTarget);worldState=worldMap.state();
        if(WorldMap::stageBit(exitTarget))saveLevel=exitTarget;else saveLevel=completed;
        frontend.syncActiveSave(saveLevel,profilePersistent,&worldState);sessionReady=false;appMode=AppMode::WorldMap;paused=false;showHelp=false;acc=0;
      }
    }else acc=0;
    if(appMode==AppMode::Game&&sessionReady){for(Sfx e:session.takeSfx())mixer.trigger(e);}audio.pump(mixer);
    if(appMode==AppMode::Game&&sessionReady)session.render(fb.data(),FW,FH);else if(appMode==AppMode::WorldMap)worldMap.render(fb.data(),FW,FH);else frontend.render(fb.data(),FW,FH);
    if(appMode==AppMode::Game&&sessionReady&&showHelp)drawHelp(fb.data());
    if(appMode==AppMode::Game&&sessionReady&&paused){
      hudFillRect(fb.data(),FW,FH,0,0,FW,FH,0x000000u,110);const std::string t="PAUSADO";hudDrawText(fb.data(),FW,FH,(FW-hudTextWidth(t,3))/2,FH/2-12,t,0xffffffffu,3);
      const std::string s="P CONTINUAR   R REINICIAR   F1 AJUDA";hudDrawText(fb.data(),FW,FH,(FW-hudTextWidth(s))/2,FH/2+18,s,0xffd0d0d0u);
    }
    // Keep the HD cave at 512x448 until the final window blit; never shrink
    // it to the 256x224 gameplay framebuffer first.
    const bool caveView=appMode==AppMode::WorldMap && worldMap.caveOpen();
    const int presentW=caveView?512:FW,presentH=caveView?448:FH;
    const uint32_t* presentPixels=fb.data();
    if(caveView){worldMap.render(caveFrame.data(),presentW,presentH);presentPixels=caveFrame.data();}
    bi.bmiHeader.biWidth=presentW;bi.bmiHeader.biHeight=-presentH;
    if(wantShot){wantShot=false;saveBmp32(nextShotPath(),presentPixels,presentW,presentH);}

    if(appMode!=lastMode||(appMode==AppMode::Game&&session.currentLevel()!=lastLevel)||(appMode==AppMode::Game&&paused!=lastPaused)||(appMode==AppMode::Frontend&&frontend.screen()!=lastFrontend)){
      lastMode=appMode;lastPaused=paused;lastFrontend=frontend.screen();std::wstring t=L"DKC3 Native PC v"+widen(kVersion);
      if(appMode==AppMode::Game){lastLevel=session.currentLevel();t+=L" - "+widen(lastLevel)+(paused?L"  [PAUSADO]":L"");}
      else if(appMode==AppMode::WorldMap)t+=L" - WORLD MAP";
      else t+=L" - "+widen(Frontend::screenName(lastFrontend));
      SetWindowTextW(hwnd,t.c_str());
    }

    HDC dc=GetDC(hwnd);RECT rc;GetClientRect(hwnd,&rc);const int cw=rc.right-rc.left,ch=rc.bottom-rc.top;
    if(cw>0&&ch>0){
      Dkc3DesktopViewport view{};Dkc3DesktopComputeViewport(cw,ch,presentW,presentH,&view);
      int dw=view.width,dh=view.height;
      if(integerScale){const int k=std::min(cw/presentW,ch/presentH);if(k>=1){dw=presentW*k;dh=presentH*k;}}
      const int dx=(cw-dw)/2,dy=(ch-dh)/2;RECT bars[4]={{0,0,cw,dy},{0,dy+dh,cw,ch},{0,dy,dx,dy+dh},{dx+dw,dy,cw,dy+dh}};
      for(auto&r:bars)if(r.right>r.left&&r.bottom>r.top)FillRect(dc,&r,black);SetStretchBltMode(dc,smoothScale?HALFTONE:COLORONCOLOR);if(smoothScale)SetBrushOrgEx(dc,0,0,nullptr);
      StretchDIBits(dc,dx,dy,dw,dh,0,0,presentW,presentH,presentPixels,&bi,DIB_RGB_COLORS,SRCCOPY);
    }
    ReleaseDC(hwnd,dc);
    const double frameUsed=std::chrono::duration<double>(clock::now()-now).count(),left=dt-frameUsed;Sleep(left>0.002?(DWORD)((left-0.001)*1000.0):1);
  }

  if(frontend.activeSlot()>=0){
    if(appMode==AppMode::Game&&sessionReady){profilePersistent=session.game().persistentState();saveLevel=session.currentLevel();}
    if(appMode==AppMode::WorldMap)worldState=worldMap.state();
    frontend.syncActiveSave(saveLevel,profilePersistent,appMode==AppMode::Frontend?nullptr:&worldState);
  }
  audio.close();timeEndPeriod(1);return 0;
}
