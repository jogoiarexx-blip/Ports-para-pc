#include "core/RomObjectRuntime.h"
#include <iostream>
#include <string>

namespace {
bool parseLevel(const std::string& value,uint16_t& levelId){
  if(value=="lakeside")levelId=0x25;
  else if(value=="tidal")levelId=0x27;
  else if(value=="doorstop")levelId=0x28;
  else if(value=="lakeside-bonus1")levelId=0x50;
  else if(value=="lakeside-bonus2")levelId=0x51;
  else if(value=="tidal-bonus1")levelId=0x54;
  else if(value=="tidal-bonus2")levelId=0x55;
  else {
    try{
      size_t used=0;const auto parsed=std::stoul(value,&used,0);
      if(used!=value.size()||parsed>=512)return false;
      levelId=static_cast<uint16_t>(parsed);
    }catch(...){return false;}
  }
  return true;
}
}

int main(int argc,char** argv){
  const std::string romPath=argc>1?argv[1]:"rom/dkc3_ptbr.sfc";
  uint16_t levelId=0x25;
  if(argc>2&&!parseLevel(argv[2],levelId)){
    std::cerr<<"Level must be lakeside, tidal, doorstop, lakeside-bonus1/2, tidal-bonus1/2 or a numeric level id 0..511\n";
    return 2;
  }
  dkc3::RomImage rom;
  if(!rom.load(romPath)||!rom.info().valid){std::cerr<<"ROM load failed or image is not a supported DKC3 ROM\n";return 1;}
  std::vector<dkc3::RomLevelPlacement> placements;
  if(!dkc3::decodeRomLevelPlacements(rom,levelId,placements)){
    std::cerr<<"ROM placement stream/spawn decode failed for level 0x"<<std::hex<<levelId<<"\n";
    return 1;
  }
  dkc3::RomSpawnRuntime spawn;spawn.build(placements);
  std::cout<<spawn.report();return 0;
}
