#include "core/Game.h"
#include "core/NativeReplay.h"
#include <fstream>
#include <iostream>
#include <vector>
#include <cmath>
using namespace dkc3;
// Deterministic native route bot. Room-solving macros are recorded inputs;
// transport decisions inspect game state and never modify a player coordinate.
int main(int argc,char** argv){
  if(argc!=3){std::cerr<<"Usage: route_bot lakeside|lakeside-extended|lakeside-koin|lakeside-bird|lakeside-ellie|lakeside-bonus2|tidal output.txt\n";return 2;}
  const std::string mode=argv[1];const bool full=mode=="lakeside-extended";const bool tidal=mode=="tidal",birdRoute=mode=="lakeside-bird",koinRoute=mode=="lakeside-koin"||full,ellieRoute=mode=="lakeside-ellie",both=mode=="lakeside"||birdRoute||ellieRoute||koinRoute;
  if(!tidal&&!both&&mode!="lakeside-bonus2")return 2;
  Game game;const std::string level=tidal?"tidal-trouble":"lakeside-limbo";
  if(!game.init(("assets/levels/"+level+"/"+level+".level").c_str()))return 3;
  std::vector<unsigned> masks;
  auto step=[&](unsigned mask){masks.push_back(mask);game.step(nativeInputFromSnes(mask),1.f/60);};
  auto macro=[&](const char* path){NativeReplay replay;std::string error;if(!replay.load(path,error)){std::cerr<<error<<'\n';return false;}
    for(size_t i=0;i<replay.count();++i)step(replay.frame(i));return true;};
  if(!ellieRoute&&both&&!macro("tests/replays/lakeside-bonus1-v050.txt"))return 4;
  if(koinRoute){
    if(game.koins().empty()||game.barrelRespawners().empty())return 16;
    const float kx=game.koins()[0].feet.x;
    for(int tick=0;tick<900&&!game.carryingBarrel();++tick){
      const auto& p=game.player();const float target=game.barrelRespawners()[0].feet.x-p.width/2;
      unsigned mask=p.pos.x>target-2?64:128;
      if(p.pos.x>target-50&&p.grounded)mask|=2;
      if(p.grounded&&p.pos.x<kx+24&&tick%70<30)mask|=1;
      if(p.nativeRope>=0)mask=tick%8==0?32:33;
      step(mask);
    }
    if(!game.carryingBarrel())return 17;
    const float target=kx+50-game.player().width/2;
    for(int tick=0;tick<300;++tick){const auto& p=game.player();const float predicted=p.pos.x+p.vel.x*.15f;
      unsigned mask=2;if(predicted<target-2)mask|=128;else if(predicted>target+2)mask|=64;step(mask);
      if(std::fabs(game.player().pos.x-target)<4&&std::fabs(game.player().vel.x)<10)break;
    }
    step(66);step(3);step(3);step(1);
    for(int tick=0;tick<240&&!game.koins()[0].defeated;++tick)step(tick<25?65:0);
    if(!game.koins()[0].defeated)return 18;
    for(int tick=0;tick<600&&!game.dkCoins();++tick){const auto& p=game.player();
      const float target=game.koins()[0].coinPos.x-p.width/2,predicted=p.pos.x+p.vel.x*.15f;
      unsigned mask=0;if(predicted<target-2)mask|=128;else if(predicted>target+2)mask|=64;
      if(game.inWater()){mask|=17;if(tick%8==0)mask&=~1u;}step(mask);
    }
    if(game.dkCoins()!=1)return 19;
    if(!full){std::ofstream out(argv[2]);if(!out)return 9;for(auto mask:masks)out<<std::hex<<mask<<'\n';
    std::cout<<"KOIN_INPUT_OK frames="<<masks.size()<<" dk_coins="<<game.dkCoins()<<" bonus_coins="<<game.bonusCoins()<<" lives="<<game.lives()<<" no position injection; route ends at DK Coin\n";return out?0:9;}
  }
  if(!tidal&&!ellieRoute){
    float entryX=0,firstExitX=0;
    for(const auto& barrel:game.barrelCannons()){
      if(barrel.role==BarrelCannonRole::BonusEntry2)entryX=barrel.pos.x+barrel.w*.5f;
      if(barrel.role==BarrelCannonRole::BonusExit1)firstExitX=barrel.pos.x+barrel.w*.5f;
    }
    if(entryX==0)return 5;
    for(int frame=0;frame<7000&&!game.inBonus()&&game.lives()>0;++frame){
      unsigned mask=0x880;if(frame%100<15)mask|=1;
      const auto& player=game.player();
      if(game.inWater()){
        mask|=17;
        // A fresh stroke near the surface requests the existing breach adapter.
        if(player.pos.x>firstExitX-4&&player.pos.y+player.height<player.nativeWaterSurfaceY+20&&player.vel.y<0&&frame%8==0)mask&=~1u;
      }else if(frame%34==0)mask|=2;
      if(full&&!game.partnerAvailable()&&player.pos.x>2950&&player.pos.x<3500){
        const RuntimeTeamBarrel* dk=nullptr;for(const auto& b:game.teamBarrels())if(b.active&&b.rescuesPartner&&b.pos.x>2800)dk=&b;
        if(dk){const float target=dk->pos.x+dk->w/2-player.width/2-(game.inWater()?-140:0),predicted=player.pos.x+player.vel.x*.15f;
          mask=0;if(predicted<target-2)mask|=128;else if(predicted>target+2)mask|=64;
          if(game.inWater())mask|=17;else if(player.grounded||player.vel.y<0)mask|=1;
          if(frame%16==0)mask&=~1u;
        }
      }
      if(player.pos.x>entryX-19){
        mask=16;if(player.pos.x<entryX-9)mask|=128;if(player.pos.x>entryX-1)mask|=64;
        if(game.inWater())mask|=1;
        if(frame%8==0)mask&=~17u;
        // Room macro uses Kiddy; switch is a real recorded input.
        if(game.activeCharacter()!=CharacterId::Kiddy&&game.partnerAvailable()&&frame%8==0)mask|=4;
      }
      step(mask);
    }
    if(!game.inBonus()||game.activeBonus()!=2){std::cerr<<"Bonus 2 entry failed x="<<game.player().pos.x<<" y="<<game.player().pos.y<<" partner="<<game.partnerAvailable()<<" lives="<<game.lives()<<"\n";return 6;}
    if(game.activeCharacter()==CharacterId::Kiddy){if(!macro("tests/replays/lakeside-bonus2-room-v051.txt"))return 4;}
    else return 22;
    if(game.bonusCoins()!=(both?2:1)){std::cerr<<"Bonus objectives failed\n";return 7;}
  }
  if(ellieRoute||full){
    if(game.animalBoxes().empty())return 12;
    const float boxX=game.animalBoxes()[0].feet.x;
    NativeReplay prefix;std::string error;
    if(!prefix.load("tests/replays/lakeside-bird-and-bonuses-v055.txt",error))return 4;
    if(!full)for(size_t i=0;i<prefix.count()&&game.player().pos.x<boxX-12;++i)step(prefix.frame(i));
    float signX=0,signY=0;for(const auto& sign:game.animalSigns())if(sign.animalType==0x234){signX=sign.feet.x;signY=sign.feet.y;}
    if(signX==0)return 15;
    int towerJump=-1;
    for(int frame=0;frame<1600&&!game.animalSignRewards();++frame){
      unsigned mask=0;const auto& p=game.player();
      if(!game.animal().active){
        const float target=boxX-p.width/2,predicted=p.pos.x+p.vel.x*.15f;
        if(predicted<target-2)mask|=128;else if(predicted>target+2)mask|=64;
        mask|=17;if(frame%8==0)mask&=~1u;
      }else if(!game.animal().mounted){
        const auto& animal=game.animal().body;const float target=animal.pos.x+animal.width/2-p.width/2;
        if(p.pos.x<target-2)mask|=128;else if(p.pos.x>target+2)mask|=64;
        mask|=16;if(frame%8==0)mask&=~16u;
      }else{
        mask=0x880;
        if(game.inWater()){mask|=17;if(frame%8==0)mask&=~1u;}
        else if(p.pos.x<boxX+188&&frame%50<30)mask|=1;
        if(p.pos.x>=boxX+320&&p.grounded&&(towerJump<0||(frame-towerJump>45&&std::fabs(p.vel.x)<40)))towerJump=frame;
        if(towerJump>=0&&frame-towerJump<35)mask|=1;
        if(p.pos.x>boxX+556&&!game.inWater()&&frame%50<30)mask|=1;
        if(frame%34==0)mask|=2;
        // Approach the ROM sign at its contact height before crossing it.
        if(p.pos.x>=signX-200&&p.pos.y+p.height>signY+8){
          const float target=signX-100-p.width/2,predicted=p.pos.x+p.vel.x*.15f;
          mask=0;if(predicted<target-2)mask|=128;else if(predicted>target+2)mask|=64;
          if(game.inWater()){mask|=17;if(frame%8==0)mask&=~1u;}
          else if(frame%50<35)mask|=1;
        }
      }
      if(game.animal().mounted&&p.grounded){for(const auto& enemy:game.enemies())if(enemy.active&&enemy.pos.x>p.pos.x&&enemy.pos.x<p.pos.x+p.width+45&&std::fabs(enemy.pos.y-p.pos.y)<50){
        if(frame%3)mask|=2;else mask&=~2u;break;}}
      step(mask);
    }
    if(game.animalSignRewards()!=1||game.animal().mounted)return 13;
  }
  bool birdLaunched=false,birdDone=false;int birdTick=0;
  for(int frame=0;frame<10000&&game.pendingLevel().empty()&&game.lives()>0;++frame){
    unsigned mask=0x880;if(frame%100<(ellieRoute?25:15))mask|=1;
    if(game.inWater())mask|=17;else if(frame%34==0)mask|=2;
    if(birdRoute&&!birdDone&&game.player().pos.x>=4620){
      const RuntimeEnemy* bird=nullptr;for(const auto& e:game.enemies())if(e.spriteId==0x434)bird=&e;
      if(!bird)return 10;
      mask=0x880;
      if(game.inWater()){mask=17;if(birdTick%8==0)mask&=~1u;}
      else if(game.player().pos.x<4800)mask|=1;
      if(!birdLaunched&&game.player().grounded&&game.player().pos.x>bird->pos.x-60){birdLaunched=true;birdTick=-1;}
      if(birdLaunched&&birdTick<25){if(birdTick<0)mask=0;else mask|=3;}
      if(!bird->active){
        birdDone=(game.kongMask()&8u)!=0;
        if(!birdDone){
          const RuntimeKongLetter* reward=nullptr;
          for(const auto& letter:game.kongLetters())if(letter.letter=='G'&&letter.active)reward=&letter;
          if(!reward)return 14;
          const auto& p=game.player();const float target=reward->pos.x+reward->w/2-p.width/2;
          const float predicted=p.pos.x+p.vel.x*.15f;
          mask=0;if(predicted<target-2)mask|=128;else if(predicted>target+2)mask|=64;
          if(game.inWater()){mask|=17;if(birdTick%8==0)mask&=~1u;}
          else if(p.grounded&&p.pos.y>reward->pos.y&&std::fabs(p.pos.x-target)<60)mask|=1;
          else if(p.vel.y<0)mask|=1;
        }
      }
      else if(birdLaunched&&birdTick>=25){birdLaunched=false;birdTick=0;}
      ++birdTick;
    }
    step(mask);
  }
  if(birdRoute&&!(game.kongMask()&8u))return 11;
  if(full&&(game.dkCoins()!=1||game.bonusCoins()!=2||game.animalSignRewards()!=1||game.coins()!=1))return 23;
  if(game.pendingLevel()!=(tidal?"skiddas-row":"doorstop")||game.checkpointActivations()!=1)return 8;
  std::ofstream out(argv[2]);if(!out)return 9;
  for(auto mask:masks)out<<std::hex<<mask<<'\n';if(!out)return 9;
  std::cout<<"ROUTE_BOT_OK level="<<level<<" frames="<<masks.size()<<" coins="<<game.bonusCoins()<<" animal_rewards="<<game.animalSignRewards()<<" dk_coins="<<game.dkCoins()<<" bear_coins="<<game.coins()<<" kong_mask="<<game.kongMask()<<" lives="<<game.lives()<<" exit="<<game.pendingLevel()<<'\n';
}
