#include "RomTerrain.h"
#include "RomData.h"
#include "NativeAssets.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <fstream>
#include <sstream>
#include <set>

namespace dkc3 {
namespace {
RomIoMetrics ioMetrics;
uint32_t crc32(const uint8_t* p,size_t n){
  uint32_t c=0xffffffffu;
  for(size_t i=0;i<n;++i){c^=p[i];for(int b=0;b<8;++b)c=(c>>1)^(0xedb88320u&(~(c&1u)+1u));}
  return c^0xffffffffu;
}
uint32_t bgr555(uint16_t v){
  const uint32_t r=(v&31u)*255u/31u;
  const uint32_t g=((v>>5)&31u)*255u/31u;
  const uint32_t b=((v>>10)&31u)*255u/31u;
  return (r<<16)|(g<<8)|b;
}
size_t hiromToPc(uint32_t snes){
  const uint32_t bank=(snes>>16)&0xffu;
  return (size_t)(bank-0xc0u)*0x10000u+(size_t)(snes&0xffffu);
}
struct NibbleReader{
  const uint8_t* d=nullptr;size_t n=0,pos=0;bool high=true;
  int nib(){if(pos>=n)return -1;int v=high?(d[pos]>>4):(d[pos]&15);if(!high)++pos;high=!high;return v;}
  int byte(){int a=nib(),b=nib();return (a<0||b<0)?-1:((a<<4)|b);}
};

bool loadRom(const std::string& romPath,RomImage& rom){
  if(!romPath.empty())return rom.load(romPath)&&rom.info().valid;
  return rom.loadFirstAvailable({"rom/dkc3_ptbr.sfc","dkc3_ptbr.sfc","input/dkc3_ptbr.sfc","../rom/dkc3_ptbr.sfc"});
}

size_t tilemapEntryIndex(const RomLayer& layer,int tx,int ty){
  if(!layer.snesScreenBlocks)return (size_t)ty*(size_t)layer.widthTiles+(size_t)tx;
  const int screensX=(layer.widthTiles+31)/32;
  const int sx=tx/32,sy=ty/32;
  return (size_t)(sy*screensX+sx)*1024u+(size_t)(ty&31)*32u+(size_t)(tx&31);
}

struct DynamicPoseSpec{uint32_t headerStart=0,gfxStart=0,gfxEnd=0;};
struct DynamicPiece{int x=0,y=0,w=0,h=0;std::vector<uint32_t> pixels;};

std::array<uint32_t,16> loadSpritePalette(const RomImage& rom,uint32_t start,uint32_t end){
  std::array<uint32_t,16> pal{};pal[0]=0;
  const auto& bytes=rom.bytes();const size_t a=hiromToPc(start),b=hiromToPc(end);
  size_t pi=1;
  for(size_t p=a;p+1<b&&p+1<bytes.size()&&pi<pal.size();p+=2,++pi){
    pal[pi]=0xff000000u|bgr555((uint16_t)(bytes[p]|(bytes[p+1]<<8)));
  }
  return pal;
}

bool decodeObjTile(const std::vector<uint8_t>& gfx,size_t off,const std::array<uint32_t,16>& pal,std::vector<uint32_t>& tile){
  if(off+32>gfx.size())return false;
  tile.assign(64,0);
  for(int y=0;y<8;++y){
    const uint8_t p0=gfx[off+y*2],p1=gfx[off+y*2+1],p2=gfx[off+16+y*2],p3=gfx[off+16+y*2+1];
    for(int x=0;x<8;++x){const int bit=7-x;const int ci=((p0>>bit)&1)|(((p1>>bit)&1)<<1)|(((p2>>bit)&1)<<2)|(((p3>>bit)&1)<<3);tile[(size_t)y*8u+(size_t)x]=pal[(size_t)ci];}
  }
  return true;
}

bool decodeDynamicPose(const RomImage& rom,const DynamicPoseSpec& spec,const std::array<uint32_t,16>& pal,std::vector<DynamicPiece>& pieces){
  pieces.clear();std::vector<uint8_t> hdr,gfx;
  if(!rom.range(hiromToPc(spec.headerStart),hiromToPc(spec.gfxStart),hdr)||!rom.range(hiromToPc(spec.gfxStart),hiromToPc(spec.gfxEnd),gfx)||hdr.size()<10)return false;
  std::vector<int> counts;size_t pairBase=0;
  if(hdr[8]<0x10){if(hdr.size()<14)return false;counts={hdr[0],hdr[1],hdr[3],hdr[8],hdr[10],hdr[12]};pairBase=14;}
  else{counts={hdr[0],hdr[1],hdr[3]};pairBase=8;}
  int total=0;for(int c:counts)total+=c;if(pairBase+(size_t)total*2u>hdr.size())return false;
  size_t gfxOff=0;int pieceIndex=0;
  for(size_t group=0;group<counts.size();++group){
    const bool big=(group%3u)==0u;
    for(int n=0;n<counts[group];++n){
      DynamicPiece p;p.x=(int)hdr[pairBase+(size_t)pieceIndex*2u]-0x80;p.y=(int)hdr[pairBase+(size_t)pieceIndex*2u+1u]-0x80;++pieceIndex;
      if(big){
        p.w=p.h=16;p.pixels.assign(256,0);
        for(int ti=0;ti<4;++ti){std::vector<uint32_t> tile;if(!decodeObjTile(gfx,gfxOff+(size_t)ti*32u,pal,tile))return false;const int ox=(ti&1)*8,oy=(ti>>1)*8;for(int y=0;y<8;++y)for(int x=0;x<8;++x)p.pixels[(size_t)(oy+y)*16u+(size_t)(ox+x)]=tile[(size_t)y*8u+(size_t)x];}
        gfxOff+=128;
      }else{
        p.w=p.h=8;if(!decodeObjTile(gfx,gfxOff,pal,p.pixels))return false;gfxOff+=32;
      }
      pieces.push_back(std::move(p));
    }
  }
  return gfxOff<=gfx.size();
}

void blitPieces(const std::vector<DynamicPiece>& pieces,RomSpriteFrame& frame){
  for(const auto& p:pieces)for(int y=0;y<p.h;++y)for(int x=0;x<p.w;++x){
    const uint32_t c=p.pixels[(size_t)y*(size_t)p.w+(size_t)x];if((c>>24)==0)continue;
    const int dx=frame.anchorX+p.x+x,dy=frame.anchorY+p.y+y;if(dx>=0&&dy>=0&&dx<frame.width&&dy<frame.height)frame.pixels[(size_t)dy*(size_t)frame.width+(size_t)dx]=c;
  }
}

bool composeDynamicFrame(const RomImage& rom,const DynamicPoseSpec& spec,const std::array<uint32_t,16>& pal,RomSpriteFrame& frame){
  std::vector<DynamicPiece> pieces;if(!decodeDynamicPose(rom,spec,pal,pieces)||pieces.empty())return false;
  int minX=pieces.front().x,minY=pieces.front().y,maxX=pieces.front().x+pieces.front().w,maxY=pieces.front().y+pieces.front().h;
  for(const auto& p:pieces){minX=std::min(minX,p.x);minY=std::min(minY,p.y);maxX=std::max(maxX,p.x+p.w);maxY=std::max(maxY,p.y+p.h);}
  if(maxX<=minX||maxY<=minY||maxX-minX>128||maxY-minY>128)return false;
  frame={};frame.width=maxX-minX;frame.height=maxY-minY;frame.anchorX=-minX;frame.anchorY=-minY;
  frame.pixels.assign((size_t)frame.width*(size_t)frame.height,0);blitPieces(pieces,frame);return true;
}

bool buildKobbleWalkFrames(const RomImage& rom,std::vector<RomSpriteFrame>& frames){
  static constexpr DynamicPoseSpec pose[8]={
    {0xD92A39,0xD92A61,0xD92D81},{0xD92D81,0xD92DA9,0xD930C9},
    {0xD930C9,0xD930E9,0xD933E9},{0xD933E9,0xD93409,0xD93709},
    {0xD93709,0xD93729,0xD93A29},{0xD93A29,0xD93A49,0xD93D49},
    {0xD93D49,0xD93D6B,0xD9402B},{0xD9402B,0xD9404B,0xD9434B}};
  const auto pal=loadSpritePalette(rom,0xFD3C6D,0xFD3C8B);
  frames.clear();frames.reserve(8);for(const auto& spec:pose){RomSpriteFrame f;if(!composeDynamicFrame(rom,spec,pal,f))return false;frames.push_back(std::move(f));}
  return frames.size()==8u;
}

bool buildBearCoinFrames(const RomImage& rom,std::vector<RomSpriteFrame>& frames){
  static constexpr DynamicPoseSpec pose[8]={
    {0xCC3D33,0xCC3D45,0xCC3EA5},{0xCC3EA5,0xCC3EB7,0xCC4017},
    {0xCC4017,0xCC4029,0xCC4189},{0xCC4189,0xCC419F,0xCC42DF},
    {0xCC42DF,0xCC42EF,0xCC43CF},{0xCC43CF,0xCC43DF,0xCC44BF},
    {0xCC44BF,0xCC44CF,0xCC45AF},{0xCC45AF,0xCC45C5,0xCC4705}};
  const auto pal=loadSpritePalette(rom,0xFD3B9B,0xFD3BB9);
  frames.clear();frames.reserve(8);
  for(const auto& spec:pose){RomSpriteFrame f;if(!composeDynamicFrame(rom,spec,pal,f))return false;frames.push_back(std::move(f));}
  return frames.size()==8u;
}

bool buildRaw2x2Frames(const RomImage& rom,uint32_t gfxStart,uint32_t gfxEnd,
                       uint32_t palStart,uint32_t palEnd,int frameCount,
                       std::vector<RomSpriteFrame>& frames){
  const auto palette=loadSpritePalette(rom,palStart,palEnd);
  std::vector<uint8_t> gfx;
  if(!rom.range(hiromToPc(gfxStart),hiromToPc(gfxEnd),gfx)||
     gfx.size()<(size_t)frameCount*4u*32u)return false;
  frames.clear();frames.reserve((size_t)frameCount);
  for(int fi=0;fi<frameCount;++fi){
    RomSpriteFrame f;f.width=16;f.height=16;f.anchorX=8;f.anchorY=8;f.pixels.assign(256,0);
    for(int ti=0;ti<4;++ti){
      std::vector<uint32_t> tile;
      if(!decodeObjTile(gfx,((size_t)fi*4u+(size_t)ti)*32u,palette,tile))return false;
      const int ox=(ti&1)*8,oy=(ti>>1)*8;
      for(int y=0;y<8;++y)for(int x=0;x<8;++x)
        f.pixels[(size_t)(oy+y)*16u+(size_t)(ox+x)]=tile[(size_t)y*8u+(size_t)x];
    }
    frames.push_back(std::move(f));
  }
  return true;
}

bool buildBananaSpinFrames(const RomImage& rom,std::vector<RomSpriteFrame>& frames){
  // GFX_Sprite_Bananas is eight authored 16x16 rotation poses (4 tiles each).
  // The cartridge uses the same gold subpalette family as the small gold HUD objects.
  return buildRaw2x2Frames(rom,0xFFE600,0xFFEA00,0xFD3B7D,0xFD3B9B,8,frames);
}

bool buildLifeBalloonFrames(const RomImage& rom,std::vector<RomSpriteFrame>& frames){
  // GFX_LifeBallon_Idle1..8 + PAL_Sprite_RedExtraLifeBalloon from the ROM.
  // Each Lakeside SpriteID $029C placement uses parameter 1, i.e. the red +1 life variant.
  static constexpr DynamicPoseSpec pose[8]={
    {0xCDFADE,0xCDFAF8,0xCDFCD8},{0xCDFCD8,0xCDFCF2,0xCDFED2},
    {0xCE3AE5,0xCE3AFF,0xCE3CDF},{0xCE3CDF,0xCE3CF9,0xCE3ED9},
    {0xCE3ED9,0xCE3EF3,0xCE40D3},{0xCE40D3,0xCE40ED,0xCE42CD},
    {0xCE42CD,0xCE42E7,0xCE44C7},{0xCE44C7,0xCE44E1,0xCE46C1}};
  const auto pal=loadSpritePalette(rom,0xFD397F,0xFD399D);
  frames.clear();frames.reserve(8);
  for(const auto& spec:pose){RomSpriteFrame f;if(!composeDynamicFrame(rom,spec,pal,f))return false;frames.push_back(std::move(f));}
  return frames.size()==8u;
}

bool buildBarrelCannonFrames(const RomImage& rom,std::vector<RomSpriteFrame>& frames,bool autoFire){
  // GFX_BarrelCannon_Base1..16 and GFX_BarrelCannon_AutoFire1..16.
  // The sixteen poses are the authored rotation/orientation set used by the
  // enterable barrels.  AutoFire is a separate ROM-authored graphics bank.
  static constexpr DynamicPoseSpec base[16]={
    {0xCC9849,0xCC985D,0xCC9B5D},{0xCC9B5D,0xCC9B79,0xCC9EF9},
    {0xCC9EF9,0xCC9F1F,0xCCA27F},{0xCCA27F,0xCCA29D,0xCCA5DD},
    {0xCCA5DD,0xCCA5F1,0xCCA8F1},{0xCCA8F1,0xCCA911,0xCCAC71},
    {0xCCAC71,0xCCAC8D,0xCCB00D},{0xCCB00D,0xCCB02D,0xCCB38D},
    {0xCCB38D,0xCCB3A1,0xCCB6A1},{0xCCB6A1,0xCCB6BD,0xCCBA3D},
    {0xCCBA3D,0xCCBA63,0xCCBDC3},{0xCCBDC3,0xCCBDE1,0xCCC121},
    {0xCCC121,0xCCC135,0xCCC435},{0xCCC435,0xCCC455,0xCCC7B5},
    {0xCCC7B5,0xCCC7D1,0xCCCB51},{0xCCCB51,0xCCCB71,0xCCCED1}};
  static constexpr DynamicPoseSpec automatic[16]={
    {0xCCCED1,0xCCCEE5,0xCCD1E5},{0xCCD1E5,0xCCD201,0xCCD581},
    {0xCCD581,0xCCD5A7,0xCCD907},{0xCCD907,0xCCD925,0xCCDC65},
    {0xCCDC65,0xCCDC79,0xCCDF79},{0xCCDF79,0xCCDF99,0xCCE2F9},
    {0xCCE2F9,0xCCE315,0xCCE695},{0xCCE695,0xCCE6B5,0xCCEA15},
    {0xCCEA15,0xCCEA29,0xCCED29},{0xCCED29,0xCCED45,0xCCF0C5},
    {0xCCF0C5,0xCCF0EB,0xCCF44B},{0xCCF44B,0xCCF469,0xCCF7A9},
    {0xCCF7A9,0xCCF7BD,0xCCFABD},{0xCCFABD,0xCCFADD,0xCCFE3D},
    // Bank boundary: the pose-15 OAM header resumes at $CD3DD2.
    {0xCD3DD2,0xCD3DEE,0xCD416E},{0xCD416E,0xCD418E,0xCD44EE}};
  const auto pal=loadSpritePalette(rom,0xFD3AAB,0xFD3AC9); // PAL_Sprite_Barrel
  const auto& specs=autoFire?automatic:base;
  frames.clear();frames.reserve(16);
  for(const auto& spec:specs){RomSpriteFrame f;if(!composeDynamicFrame(rom,spec,pal,f))return false;frames.push_back(std::move(f));}
  return frames.size()==16u;
}

bool buildBonusCoinFrames(const RomImage& rom,std::vector<RomSpriteFrame>& frames){
  static constexpr DynamicPoseSpec pose[8]={
    {0xCC5D4B,0xCC5D5B,0xCC5F5B},{0xCC5F5B,0xCC5F6B,0xCC616B},
    {0xCC616B,0xCC617B,0xCC637B},{0xCC637B,0xCC638F,0xCC650F},
    {0xCC650F,0xCC651B,0xCC661B},{0xCC661B,0xCC6629,0xCC66E9},
    {0xCC66E9,0xCC66F7,0xCC6817},{0xCC6817,0xCC682B,0xCC69AB}};
  const auto pal=loadSpritePalette(rom,0xFD3BB9,0xFD3BD7);
  frames.clear();frames.reserve(8);
  for(const auto& spec:pose){RomSpriteFrame f;if(!composeDynamicFrame(rom,spec,pal,f))return false;frames.push_back(std::move(f));}
  return frames.size()==8u;
}

bool buildKongLetterFrames(const RomImage& rom,std::vector<RomSpriteFrame>& frames){
  // GFX_Sprite_CollectedKONGLetters stores K/O/N/G as four 16x16 glyphs.
  return buildRaw2x2Frames(rom,0xFC2D40,0xFC2F40,0xFD3B7D,0xFD3B9B,4,frames);
}

bool buildBoatFrames(const RomImage& rom,std::vector<RomSpriteFrame>& frames){
  static constexpr DynamicPoseSpec boat[9]={
    {0xCA42D9,0xCA42EB,0xCA43EB},{0xCA43EB,0xCA43FD,0xCA44FD},{0xCA44FD,0xCA4509,0xCA4609},
    {0xCA4609,0xCA4617,0xCA4737},{0xCA4737,0xCA4745,0xCA4865},{0xCA4865,0xCA4873,0xCA4993},
    {0xCA4993,0xCA499F,0xCA4A9F},{0xCA4A9F,0xCA4AB1,0xCA4BB1},{0xCA4BB1,0xCA4BC3,0xCA4CC3}};
  static constexpr DynamicPoseSpec kiddyDriver[9]={
    {0xCA08E1,0xCA08EB,0xCA096B},{0xCA096B,0xCA0975,0xCA09F5},{0xCA09F5,0xCA09FF,0xCA0A7F},
    {0xCA0A7F,0xCA0A89,0xCA0B09},{0xCA0B09,0xCA0B17,0xCA0B77},{0xCA0B77,0xCA0B81,0xCA0C01},
    {0xCA0C01,0xCA0C0B,0xCA0C8B},{0xCA0C8B,0xCA0C99,0xCA0CF9},{0xCA0CF9,0xCA0D07,0xCA0D67}};
  static constexpr DynamicPoseSpec dixiePassenger[9]={
    {0xCA185B,0xCA1867,0xCA18A7},{0xCA18A7,0xCA18B3,0xCA18F3},{0xCA18F3,0xCA18FF,0xCA193F},
    {0xCA193F,0xCA194B,0xCA198B},{0xCA198B,0xCA1999,0xCA19F9},{0xCA19F9,0xCA1A05,0xCA1A45},
    {0xCA1A45,0xCA1A51,0xCA1A91},{0xCA1A91,0xCA1A9D,0xCA1ADD},{0xCA1ADD,0xCA1AE9,0xCA1B29}};
  const auto boatPal=loadSpritePalette(rom,0xFD4895,0xFD48B3);const auto kongPal=loadSpritePalette(rom,0xFD4387,0xFD43A5);
  frames.clear();frames.reserve(9);
  for(int i=0;i<9;++i){
    RomSpriteFrame f;f.width=40;f.height=40;f.anchorX=20;f.anchorY=20;f.pixels.assign(1600,0);
    std::vector<DynamicPiece> p;
    if(!decodeDynamicPose(rom,boat[i],boatPal,p))return false;
    blitPieces(p,f);
    if(!decodeDynamicPose(rom,kiddyDriver[i],kongPal,p))return false;
    blitPieces(p,f);
    if(!decodeDynamicPose(rom,dixiePassenger[i],kongPal,p))return false;
    blitPieces(p,f);
    frames.push_back(std::move(f));
  }
  return true;
}


bool parseSpawnScript(const RomImage& rom,uint16_t script,RomSpawnSpec& spec,
                      std::set<uint16_t>& stack,int depth=0){
  // BB:91B4 saves Y, calls the base script, restores Y and continues.
  // A recursion stack (rather than a global visited set) allows repeated base calls.
  if(depth>24 || !stack.insert(script).second)return false;
  struct Pop {std::set<uint16_t>& stack;uint16_t script;~Pop(){stack.erase(script);}} pop{stack,script};
  const auto& bytes=rom.bytes();
  size_t pos=hiromToPc(0xff0000u|script);
  const size_t end=std::min(bytes.size(),hiromToPc(0xff0000u)+0x10000u);
  auto need=[&](size_t n){return pos<=end && n<=end-pos;};
  auto word=[&](){uint16_t v=static_cast<uint16_t>(bytes[pos]|(bytes[pos+1]<<8));pos+=2;return v;};
  auto write=[&](size_t offset,uint16_t value){
    spec.fields[offset]=static_cast<uint8_t>(value);spec.fields[offset+1]=static_cast<uint8_t>(value>>8);
    spec.written[offset]=spec.written[offset+1]=true;
    if(offset==0)spec.spriteId=value;
    if(offset==0x40)spec.animationId=value;
  };
  for(int guard=0;guard<1024;++guard){
    if(!need(1))return false;
    const uint8_t op=bytes[pos++];
    if(op<0xef){if(!need(2))return false;write(op,word());continue;}
    if(op==0xef)return true;
    if(op==0xf0){write(0x0e,spec.word(0x0e)&0xffbf);write(0x1e,(spec.word(0x1e)&0xcfff)|0x2000);return true;}
    // F5 positions a semi-dynamic sprite and resumes parsing (BB:9350).
    if(op==0xf5)continue;
    if(op==0xf1){
      if(!need(3))return false;
      const auto offset=bytes[pos++];const auto value=word();
      if(offset+1u>=spec.fields.size())return false;
      // Original applies the current sprite's facing here; static descriptors
      // retain the unflipped displacement until the native spawner applies it.
      write(offset,value);continue;
    }
    if(op==0xf7){if(!need(5))return false;pos+=5;continue;}
    if(op==0xf4 || op==0xf9){
      if(!need(op==0xf4?11:2))return false;
      if(op==0xf4)for(size_t offset:{0x4cu,0x4au,0x38u,0x6cu,0x5au,0x58u})write(offset,0);
      const uint16_t target=word();
      if(!parseSpawnScript(rom,target,spec,stack,depth+1))return false;
      if(op==0xf4){
        const uint8_t flags=bytes[pos],routine=bytes[pos+1],speed=bytes[pos+2];
        const uint8_t lower=bytes[pos+3],upper=bytes[pos+4],velocity=bytes[pos+5];
        const uint8_t slip=bytes[pos+6],ground=bytes[pos+7],distance=bytes[pos+8];
        const auto signedSpeed=[](uint8_t v){return static_cast<uint16_t>(static_cast<int16_t>(static_cast<int8_t>(v))*16);};
        write(0x06,spec.word(0x06)|flags);
        if(flags&4)write(0x26,0xc000);
        write(0x48,static_cast<uint16_t>((routine&0x0f)<<12));
        const uint16_t address=static_cast<uint16_t>(((routine&0xf0)<<8)|((routine&0x0f)<<4));
        write(0x46,address);write(0x6a,address);
        write(0x44,signedSpeed(speed));
        const size_t axis=(spec.word(0x06)&0x80)?0x16:0x12;
        write(0x5c,static_cast<uint16_t>(spec.word(axis)-lower*8));
        write(0x5e,static_cast<uint16_t>(spec.word(axis)+upper*8));
        write(axis==0x16?0x34:0x30,signedSpeed(velocity));
        write(axis==0x16?0x2e:0x2a,0);
        write(0x36,static_cast<uint16_t>(slip*16));
        write(0x18,ground);write(0x1a,static_cast<uint16_t>(ground+distance));
        pos+=9;
      }
      continue;
    }
    if(op==0xf8){
      if(!need(8))return false;
      word();word();const auto zero=word(),nonzero=word();
      auto a=spec,b=spec;
      if(!parseSpawnScript(rom,zero,a,stack,depth+1)||!parseSpawnScript(rom,nonzero,b,stack,depth+1))return false;
      // Unknown global RAM must not silently choose a branch. Keep only common writes.
      spec.conditional=true;
      spec.spriteId=a.spriteId==b.spriteId?a.spriteId:0xffff;
      spec.animationId=a.animationId==b.animationId?a.animationId:0;
      spec.paletteCommand=a.paletteCommand==b.paletteCommand?a.paletteCommand:0;
      for(size_t i=0;i<spec.fields.size();++i){
        spec.written[i]=a.written[i]&&b.written[i]&&a.fields[i]==b.fields[i];
        spec.fields[i]=spec.written[i]?a.fields[i]:0;
      }
      continue;
    }
    if(!need(2))return false;
    const auto value=word();
    switch(op){
      case 0xff:spec.spriteId=value;write(0,value);break;
      case 0xfa:spec.animationId=value;write(0x40,value);break;
      case 0xfb:case 0xfc:spec.paletteCommand=value;break;
      case 0xfe:case 0xfd:write(0x1e,(spec.word(0x1e)&0x0fff)|(value&0xf000));break;
      case 0xf2:write(0x0e,value);break;
      case 0xf3:case 0xf6:break;
      default:return false;
    }
  }
  return false;
}
}

bool decodeRomSpawnScript(const RomImage& rom,uint16_t descriptor,RomSpawnSpec& result,uint16_t x,uint16_t y){
  RomSpawnSpec decoded;std::set<uint16_t> stack;
  decoded.fields[0x12]=static_cast<uint8_t>(x);decoded.fields[0x13]=static_cast<uint8_t>(x>>8);
  decoded.fields[0x16]=static_cast<uint8_t>(y);decoded.fields[0x17]=static_cast<uint8_t>(y>>8);
  if(!parseSpawnScript(rom,descriptor,decoded,stack)){result={};return false;}
  result=decoded;return true;
}

bool buildDixieMapWalkFrames(const RomImage& rom,std::vector<RomSpriteFrame>& frames){
  static constexpr DynamicPoseSpec dixieSide[8]={
    {0xC9FB57,0xC9FB61,0xC9FBE1},{0xC9FBE1,0xC9FBEB,0xC9FC6B},
    {0xC9FC6B,0xC9FC75,0xC9FCF5},{0xC9FCF5,0xC9FCFF,0xC9FD7F},
    {0xC9FD7F,0xC9FD89,0xC9FE09},{0xC9FE09,0xC9FE13,0xC9FE93},
    {0xC9FE93,0xC9FE9D,0xC9FF1D},{0xC9FF1D,0xC9FF27,0xC9FFA7}};
  const auto pal=loadSpritePalette(rom,0xFD4387,0xFD43A5);
  frames.clear();frames.reserve(8);
  for(const auto& spec:dixieSide){
    RomSpriteFrame f;f.width=40;f.height=40;f.anchorX=20;f.anchorY=20;f.pixels.assign(1600,0);
    std::vector<DynamicPiece> pieces;
    if(!decodeDynamicPose(rom,spec,pal,pieces))return false;
    blitPieces(pieces,f);frames.push_back(std::move(f));
  }
  return true;
}


bool decodeRomObjectFrame(const RomImage& rom,uint32_t address,uint16_t paletteIndex,RomSpriteFrame& frame){
  const auto& b=rom.bytes();
  if(address<0xc00000 || address>0xffffff)return false;
  const size_t start=hiromToPc(address);
  if(start+14>b.size() || b.size()<=0x3b9654)return false;
  const bool extended=b[start+8]<0x10;
  const size_t prefix=extended?14:8;
  const unsigned counts[6]={b[start],b[start+1],b[start+3],extended?b[start+8]:0u,extended?b[start+10]:0u,extended?b[start+12]:0u};
  size_t header=prefix,gfx=0;
  for(unsigned i=0;i<(extended?6u:3u);++i){header+=counts[i]*2u;gfx+=counts[i]*(i%3==0?128u:32u);}
  if(!gfx || start+header+gfx>b.size())return false;
  // BB:9651 reads the original FD palette pointer table. Mirror BB -> FB.
  if(b[0x3b9651]!=0xbf)return false;
  const uint32_t table=b[0x3b9652]|(b[0x3b9653]<<8)|(b[0x3b9654]<<16);
  if(table<0xc00000)return false;
  const size_t entry=hiromToPc(table)+paletteIndex*2u;
  if(entry+2>b.size())return false;
  const uint32_t palette=0xfd0000u|b[entry]|(b[entry+1]<<8);
  if(hiromToPc(palette)+30>b.size())return false;
  RomSpriteFrame decoded;
  if(!composeDynamicFrame(rom,{address,address+(uint32_t)header,address+(uint32_t)(header+gfx)},loadSpritePalette(rom,palette,palette+30),decoded))return false;
  frame=std::move(decoded);return true;
}
bool loadRomBootyBirdFrames(const RomImage& rom,std::vector<RomSpriteFrame>& frames){
  static constexpr uint32_t graphics[]={0xd4c583,0xd4c887,0xd4cb8b,0xd4ce45,0xd4d0e3,0xd4d35f,0xd4d5db,0xd4d8b7};
  std::vector<RomSpriteFrame> decoded;
  for(auto address:graphics){RomSpriteFrame f;if(!decodeRomObjectFrame(rom,address,0x4f,f))return false;decoded.push_back(std::move(f));}
  frames=std::move(decoded);return true;
}
bool readRomObjectReward(const RomImage& rom,uint16_t index,RomObjectReward& reward){
  // DATA_FF257C has 19 six-byte records, selected by B6:B8C5.
  if(index>=19)return false;
  const size_t p=0x3f257c+index*6u;const auto& b=rom.bytes();
  if(p+6>b.size())return false;
  reward={static_cast<uint16_t>(b[p]|(b[p+1]<<8)),static_cast<uint16_t>(b[p+2]|(b[p+3]<<8)),static_cast<uint16_t>(b[p+4]|(b[p+5]<<8))};return true;
}

RomIoMetrics romIoMetrics(){return ioMetrics;}
void resetRomIoMetrics(){ioMetrics={};}
const std::vector<uint8_t>& RomImage::bytes() const{++ioMetrics.byteViewRequests;return data_;}
bool RomImage::load(const std::string& path){
  ++ioMetrics.loadAttempts;
  data_.clear();info_=RomInfo{};
  std::ifstream f(path,std::ios::binary);if(!f)return false;
  f.seekg(0,std::ios::end);const auto len=f.tellg();if(len<=0)return false;f.seekg(0,std::ios::beg);
  data_.resize((size_t)len);f.read((char*)data_.data(),len);ioMetrics.fileBytesRead+=static_cast<uint64_t>(f.gcount());if(!f){data_.clear();return false;}
  ++ioMetrics.successfulLoads;
  info_.path=path;info_.size=data_.size();info_.crc32=crc32(data_.data(),data_.size());
  if(data_.size()>=0xffd5){
    std::string t((const char*)data_.data()+0xffc0,21);while(!t.empty()&&(t.back()==' '||t.back()=='\0'))t.pop_back();info_.title=t;
    const uint8_t map=data_[0xffd5];info_.valid=(data_.size()==4194304u&&t.find("DONKEY KONG COUNTRY 3")!=std::string::npos&&(map==0x31||map==0x30));
  }
  return true;
}
bool RomImage::loadFirstAvailable(const std::vector<std::string>& paths){for(const auto& p:paths)if(load(p)&&info_.valid)return true;return false;}
bool RomImage::range(size_t begin,size_t end,std::vector<uint8_t>& out) const{if(begin>end||end>data_.size())return false;out.assign(data_.begin()+(ptrdiff_t)begin,data_.begin()+(ptrdiff_t)end);ioMetrics.rangeBytesRead+=end-begin;return true;}

bool dkc3BigDataDecompress(const uint8_t* data,size_t size,std::vector<uint8_t>& out,size_t* consumed){
  out.clear();if(!data||size<0x27)return false;NibbleReader r{data,size,0x27,true};
  auto relay=[&](size_t dist)->bool{if(dist==0||dist>out.size())return false;out.push_back(out[out.size()-dist]);return true;};
  for(;;){
    int c=r.nib();if(c<0)return false;
    if(c==0){int k=r.nib();if(k<0)return false;if(k==0)break;while(k--){int v=r.byte();if(v<0)return false;out.push_back((uint8_t)v);}}
    else if(c==1||c==2){int k=(c==1)?1:2;while(k--){int v=r.byte();if(v<0)return false;out.push_back((uint8_t)v);}}
    else if(c==3){int k=r.nib(),v=r.byte();if(k<0||v<0)return false;k+=3;out.insert(out.end(),(size_t)k,(uint8_t)v);}
    else if(c==4||c==5){int k=r.nib();if(k<0)return false;k+=3;out.insert(out.end(),(size_t)k,data[1+(c&1)]);}
    else if(c==6){out.push_back(data[5]);out.push_back(data[6]);}
    else if(c==7||c==8){out.push_back(data[3+((c^1)&1)]);}
    else if(c==9){int d=r.nib();if(d<0)return false;d+=2;if(!relay((size_t)d)||!relay((size_t)d))return false;}
    else if(c==10){int k=r.nib(),d=r.byte();if(k<0||d<0)return false;k+=3;d+=k;while(k--)if(!relay((size_t)d))return false;}
    else if(c==11){int k=r.nib(),a=r.byte(),lo=r.nib();if(k<0||a<0||lo<0)return false;k+=3;size_t d=(size_t)(((a<<4)|lo)+0x103);while(k--)if(!relay(d))return false;}
    else if(c==12){int k=r.nib(),a=r.byte(),lo=r.byte();if(k<0||a<0||lo<0)return false;k+=3;size_t d=(size_t)((a<<8)|lo);while(k--)if(!relay(d))return false;}
    else if(c==13){if(!relay(1))return false;}
    else if(c==14){if(!relay(2)||!relay(2))return false;}
    else if(c==15){int a=r.nib();if(a<0)return false;a=(a<<1)+7;if((size_t)a+1>=size)return false;out.push_back(data[a]);out.push_back(data[a+1]);}
    if(out.size()>65536u)return false;
  }
  if(consumed)*consumed=r.pos+(r.high?0u:1u);
  return true;
}

bool dkc3SmallDataDecompress(const uint8_t* data,size_t size,std::vector<uint8_t>& out,size_t* consumed){
  out.clear();if(!data||size<3)return false;const int flags=data[0]&7;const size_t words=(size_t)data[1]|((size_t)data[2]<<8);if(words>32768u)return false;
  std::vector<uint16_t> w(words,0);size_t bp=3;int bit=0;
  auto bits=[&](int count,int& result)->bool{unsigned v=0;while(count--){if(bp>=size)return false;v=(v<<1)|((data[bp]>>(7-bit))&1u);if(++bit==8){bit=0;++bp;}}result=(int)v;return true;};
  auto sub=[&](int mode)->bool{size_t a=0;int vs=1,cs=6,shift=13+mode;if(mode==3){vs=3;cs=4;shift=10;}for(;;){int loop=0,v=0,k=0;if(!bits(1,loop)||!bits(vs,v))return false;v<<=shift;if(loop){if(!bits(cs,k))return false;}else k=1;if(k==0)break;while(k--){if(a>=w.size())return false;w[a++]|=(uint16_t)v;}}return true;};
  for(int i=0;i<3;++i)if((flags&(1<<i))&&!sub(i))return false;
  if(!sub(3))return false;
  size_t a=0;for(;;){int mode=0,v=0,k=0;if(!bits(2,mode)||!bits(10,v))return false;if(mode==0)k=1;else if(mode==1){if(!bits(6,k))return false;if(k==0)break;}else{if(!bits(4,k)||k==0)return false;}while(k--){if(a>=w.size())return false;w[a++]|=(uint16_t)v;if(mode==2)v=(v+1)&0x3ff;else if(mode==3)v=(v-1)&0x3ff;}}
  out.resize(words*2);for(size_t i=0;i<words;++i){out[i*2]=(uint8_t)w[i];out[i*2+1]=(uint8_t)(w[i]>>8);}if(consumed)*consumed=bp+(bit?1u:0u);return true;
}

bool renderSnesLayer(const RomLayer& layer,std::vector<uint32_t>& out,int outW,int outH,int dstX,int dstY,std::vector<uint8_t>* opaqueMask){
  if(layer.widthTiles<=0||layer.heightTiles<=0||layer.palette.size()<2||outW<=0||outH<=0||(layer.bpp!=2&&layer.bpp!=4))return false;
  const size_t needEntries=(size_t)((layer.widthTiles+31)/32)*(size_t)((layer.heightTiles+31)/32)*1024u;
  if(layer.snesScreenBlocks&&layer.tilemap.size()/2<needEntries)return false;
  if(!layer.snesScreenBlocks&&layer.tilemap.size()/2<(size_t)layer.widthTiles*(size_t)layer.heightTiles)return false;
  if(out.size()!=(size_t)outW*(size_t)outH)out.assign((size_t)outW*(size_t)outH,0);
  if(opaqueMask&&opaqueMask->size()!=out.size())opaqueMask->assign(out.size(),0);
  std::array<uint32_t,128> pal{};const size_t pc=std::min<size_t>(128,layer.palette.size()/2);for(size_t i=0;i<pc;++i)pal[i]=bgr555((uint16_t)(layer.palette[i*2]|(layer.palette[i*2+1]<<8)));
  const size_t tileBytes=layer.bpp==4?32u:16u;
  for(int ty=0;ty<layer.heightTiles;++ty)for(int tx=0;tx<layer.widthTiles;++tx){
    const size_t ei=tilemapEntryIndex(layer,tx,ty);const uint16_t e=(uint16_t)(layer.tilemap[ei*2]|(layer.tilemap[ei*2+1]<<8));const int tile=e&0x3ff;const int p=(e>>10)&7;const bool xf=(e&0x4000)!=0,yf=(e&0x8000)!=0;const size_t off=(size_t)tile*tileBytes;if(off+tileBytes>layer.gfx4bpp.size())continue;
    for(int py=0;py<8;++py){
      const int sy=yf?7-py:py;const uint8_t p0=layer.gfx4bpp[off+sy*2],p1=layer.gfx4bpp[off+sy*2+1];const uint8_t p2=layer.bpp==4?layer.gfx4bpp[off+16+sy*2]:0,p3=layer.bpp==4?layer.gfx4bpp[off+16+sy*2+1]:0;
      for(int px=0;px<8;++px){
        const int sx=xf?7-px:px,bb=7-sx;const int ci=((p0>>bb)&1)|(((p1>>bb)&1)<<1)|(layer.bpp==4?(((p2>>bb)&1)<<2)|(((p3>>bb)&1)<<3):0);if(layer.transparentZero&&ci==0)continue;
        const int dx=dstX+tx*8+px,dy=dstY+ty*8+py;if(dx<0||dy<0||dx>=outW||dy>=outH)continue;const int pi=p*(layer.bpp==4?16:4)+ci;if(pi<(int)pc){const size_t oi=(size_t)dy*(size_t)outW+(size_t)dx;out[oi]=pal[(size_t)pi];if(opaqueMask)(*opaqueMask)[oi]=1;}
      }
    }
  }
  return true;
}

bool renderSnes4bppLayer(const RomLayer& layer,std::vector<uint32_t>& out,int outW,int outH,int dstX,int dstY){RomLayer copy=layer;copy.bpp=4;return renderSnesLayer(copy,out,outW,outH,dstX,dstY,nullptr);}

bool RomFrontendVisuals::load(const std::string& romPath){
  if(romPath.empty()){std::string error;auto a=runtimeNativeAssets(error);if(!a){valid_=false;return false;}*this=a->frontend;return true;}
  valid_=false;title_.clear();fileSelect_.clear();RomImage rom;if(!loadRom(romPath,rom))return false;info_=rom.info();
  auto slice=[&](size_t a,size_t b,std::vector<uint8_t>& v){return rom.range(a,b,v);};
  std::vector<uint8_t> cg1,cg2,ct1,ct2,pal,g1,g2,t1,t2;
  if(!slice(0x0CFE3D,0x0D3DD2,cg1)||!slice(0x29342E,0x2945BC,cg2)||!slice(0x287581,0x2877CC,ct1)||!slice(0x29339E,0x29342E,ct2)||!slice(0x3D7701,0x3D7801,pal))return false;
  if(!dkc3BigDataDecompress(cg1.data(),cg1.size(),g1)||!dkc3BigDataDecompress(cg2.data(),cg2.size(),g2)||!dkc3SmallDataDecompress(ct1.data(),ct1.size(),t1)||!dkc3SmallDataDecompress(ct2.data(),ct2.size(),t2))return false;
  title_.assign(256u*224u,0);RomLayer l1{32,28,std::move(g1),std::move(t1),pal,false,4,false};if(!renderSnesLayer(l1,title_,256,224))return false;
  RomLayer l2{32,12,std::move(g2),std::move(t2),pal,true,4,false};if(!renderSnesLayer(l2,title_,256,224))return false;
  std::vector<uint8_t> fcg,ftm,fg,fp;
  if(!slice(0x13FE2A,0x141E8B,fcg)||!slice(0x2A0488,0x2A0694,ftm)||!slice(0x3D8641,0x3D8741,fp))return false;
  if(!dkc3BigDataDecompress(fcg.data(),fcg.size(),fg)||!dkc3SmallDataDecompress(ftm.data(),ftm.size(),t1))return false;
  fileSelect_.assign(256u*224u,0);if(t1.size()<32u*30u*2u)return false;t1.resize(32u*30u*2u);RomLayer fs{32,30,std::move(fg),std::move(t1),std::move(fp),false,4,false};if(!renderSnesLayer(fs,fileSelect_,256,224))return false;
  valid_=true;return true;
}
std::string RomFrontendVisuals::status() const{std::ostringstream ss;if(!valid_){ss<<"ROM NAO ENCONTRADA/INVALIDA";return ss.str();}ss<<info_.title<<" CRC32="<<std::hex<<info_.crc32;return ss.str();}

bool decodeRomPlacements(const RomImage& rom,const std::vector<uint8_t>& data,std::vector<RomLevelPlacement>& out){
  out.clear();std::vector<RomLevelPlacement> decoded;
  for(size_t off=0;off+1u<data.size();off+=8u){
    const uint16_t parameter=(uint16_t)(data[off]|((uint16_t)data[off+1u]<<8));
    if(parameter==0){out=std::move(decoded);return true;}
    if(off+7u>=data.size())return false;
    RomLevelPlacement p;
    p.parameter=parameter;
    p.x=(uint16_t)(data[off+2u]|((uint16_t)data[off+3u]<<8));
    p.y=(uint16_t)(data[off+4u]|((uint16_t)data[off+5u]<<8));
    p.type=(uint16_t)(data[off+6u]|((uint16_t)data[off+7u]<<8));
    const size_t table=hiromToPc(0xFF0040u)+(size_t)p.type;
    if(table+1u>=rom.bytes().size())return false;
    p.descriptor=(uint16_t)(rom.bytes()[table]|((uint16_t)rom.bytes()[table+1u]<<8));
    if(decodeRomSpawnScript(rom,p.descriptor,p.spawn,p.x,p.y))p.spriteId=p.spawn.spriteId;
    decoded.push_back(p);
  }
  return false; // Missing terminator or truncated stream.
}

namespace {
// PIER uses 16 rows per column. Level headers and placement pointers select
// the submap; the codec does not contain per-level offsets or object counts.
constexpr int pierRows=16;
constexpr unsigned pierSubmaps=7;
bool readLevelPlacementStream(const RomImage& rom,uint16_t levelId,std::vector<uint8_t>& out){
  out.clear();
  // FE:0000 is a 512-entry word table. Each stream ends with a zero word.
  if(levelId>=512)return false;
  const auto& bytes=rom.bytes();
  const size_t bank=hiromToPc(0xFE0000u),end=bank+0x10000u;
  if(end>bytes.size())return false;
  const size_t entry=bank+size_t(levelId)*2u;
  const unsigned offset=bytes[entry]|(unsigned(bytes[entry+1u])<<8);
  if(offset<0x400u)return false; // Never decode the pointer table as objects.
  const size_t begin=bank+offset;
  for(size_t at=begin;at+1u<end;at+=8u){
    if(bytes[at]==0&&bytes[at+1u]==0){return rom.range(begin,at+2u,out);}
    if(at+7u>=end)return false;
  }
  return false;
}
constexpr RomScenarioCodec scenarioCodecs[]={
  {0x19f0,"PIER",RomSupport::Partial},
  {0x198d,"MILL",RomSupport::Partial},
  {0x1998,"MILL variant",RomSupport::Partial},
  {0x19da,"SNOW",RomSupport::Unknown}
};

size_t hiromMirrorToPc(uint32_t snes){
  return (size_t)(((snes>>16)&0x3fu)*0x10000u)+(size_t)(snes&0xffffu);
}
}
bool decodeRomLevelPlacements(const RomImage& rom,uint16_t levelId,std::vector<RomLevelPlacement>& out,std::vector<uint8_t>* rawData){
  std::vector<uint8_t> data;
  if(!readLevelPlacementStream(rom,levelId,data)){out.clear();if(rawData)rawData->clear();return false;}
  std::vector<RomLevelPlacement> decoded;
  if(!decodeRomPlacements(rom,data,decoded)){out.clear();if(rawData)rawData->clear();return false;}
  if(rawData)*rawData=data;
  out=std::move(decoded);
  return true;
}

const char* romSupportName(RomSupport s){
  switch(s){case RomSupport::Supported:return "SUPPORTED";case RomSupport::Partial:return "PARTIAL";default:return "UNKNOWN";}
}
const RomScenarioCodec* findRomScenarioCodec(uint16_t sharedData){
  for(const auto& codec:scenarioCodecs)if(codec.sharedData==sharedData)return &codec;
  return nullptr;
}

bool decodeRomScenarioLayout(const RomImage& rom,uint16_t sharedData,uint8_t submap,RomScenarioLayout& out){
  out={};out.sharedData=sharedData;out.submap=submap;
  const auto& rb=rom.bytes();
  auto valid=[&](uint32_t address,size_t bytes=1u){const size_t p=hiromMirrorToPc(address);return p<=rb.size()&&bytes<=rb.size()-p;};
  auto byte=[&](uint32_t address)->uint8_t{return rb[hiromMirrorToPc(address)];};
  auto word=[&](uint32_t address)->uint16_t{const size_t p=hiromMirrorToPc(address);return (uint16_t)(rb[p]|((uint16_t)rb[p+1u]<<8));};
  auto pointer24=[&](uint32_t address)->uint32_t{const uint16_t lo=word(address);const uint8_t bank=(uint8_t)(byte(address+2u)|0x80u);return ((uint32_t)bank<<16)|lo;};
  const uint32_t sharedAddress=0xFD0000u+(uint32_t)sharedData;
  if(!valid(sharedAddress,9u))return false;
  out.familyIndex=byte(sharedAddress+8u);
  // The table is ROM-authored; validate the entry itself instead of hard-limiting
  // the family id to the subset already seen in our first migrated stages.
  const uint32_t familyEntry=0xB7B01Bu+(uint32_t)out.familyIndex*4u;
  if(!valid(familyEntry,4u))return false;
  out.familyConfigAddress=0xB70000u|word(familyEntry);
  out.terrainQueryHandler=0xB70000u|word(familyEntry+2u);
  if(!valid(out.familyConfigAddress,9u+(size_t)(submap+1u)*10u))return false;
  out.assetHeaderAddress=pointer24(out.familyConfigAddress);
  out.terrainVramBase=word(out.familyConfigAddress+3u);
  const uint32_t record=out.familyConfigAddress+9u+(uint32_t)submap*10u;
  out.xBegin=word(record);out.xEnd=word(record+2u);out.yBegin=word(record+4u);out.yEnd=word(record+6u);
  out.shape=byte(record+8u);out.flags=byte(record+9u);
  if(out.xEnd<=out.xBegin||out.yEnd<=out.yBegin)return false;
  if(!valid(out.assetHeaderAddress,9u))return false;
  out.map32StreamAddress=pointer24(out.assetHeaderAddress);
  out.terrainDefinitionsAddress=pointer24(out.assetHeaderAddress+3u);
  out.foregroundStreamAddress=pointer24(out.assetHeaderAddress+6u);
  out.levelStreamAddress=out.assetHeaderAddress+9u;
  auto orderedPc=[&](uint32_t a,uint32_t b){return hiromMirrorToPc(a)<hiromMirrorToPc(b);};
  if(!orderedPc(out.levelStreamAddress,out.map32StreamAddress)||!orderedPc(out.map32StreamAddress,out.terrainDefinitionsAddress)||!orderedPc(out.terrainDefinitionsAddress,out.foregroundStreamAddress))return false;
  auto decompress=[&](uint32_t start,std::vector<uint8_t>& decoded,size_t& consumed)->bool{
    const size_t p=hiromMirrorToPc(start);if(p>=rb.size())return false;
    return dkc3BigDataDecompress(rb.data()+p,rb.size()-p,decoded,&consumed);
  };
  if(!decompress(out.levelStreamAddress,out.levelMap,out.levelCompressedBytes) ||
     hiromMirrorToPc(out.levelStreamAddress)+out.levelCompressedBytes!=hiromMirrorToPc(out.map32StreamAddress))return false;
  if(!decompress(out.map32StreamAddress,out.map32,out.map32CompressedBytes) ||
     hiromMirrorToPc(out.map32StreamAddress)+out.map32CompressedBytes!=hiromMirrorToPc(out.terrainDefinitionsAddress))return false;
  const size_t defsBegin=hiromMirrorToPc(out.terrainDefinitionsAddress),defsEnd=hiromMirrorToPc(out.foregroundStreamAddress);
  if(defsEnd<=defsBegin||defsEnd>rb.size())return false;
  out.terrainDefinitions.assign(rb.begin()+(ptrdiff_t)defsBegin,rb.begin()+(ptrdiff_t)defsEnd);
  if(!decompress(out.foregroundStreamAddress,out.foregroundGfx,out.foregroundCompressedBytes))return false;
  return !out.levelMap.empty()&&!out.map32.empty()&&!out.terrainDefinitions.empty()&&!out.foregroundGfx.empty();
}

bool romScenarioMapMetatile(const RomScenarioLayout& layout,int localX,int localY,uint16_t& metatile){
  metatile=0;
  if(localX<0||localY<0||layout.levelMap.size()<2u)return false;
  const uint32_t gx=(uint32_t)layout.xBegin+(uint32_t)localX;
  const uint32_t gy=(uint32_t)layout.yBegin+(uint32_t)localY;
  const size_t column=(size_t)(gx/32u),row=(size_t)(gy/32u);
  size_t wordIndex=0;
  switch(layout.shape){
    case 0u:case 8u: wordIndex=column*16u+row;break;
    case 1u: wordIndex=column*32u+row;break;
    case 4u: wordIndex=row*32u+column;break;  // 64-byte rows
    case 5u: wordIndex=row*16u+column;break;  // 32-byte rows
    case 6u:case 9u: wordIndex=row*96u+column;break; // 192-byte rows
    case 7u: wordIndex=row*80u+column;break;  // 160-byte rows (MILL)
    default:return false;
  }
  const size_t offset=wordIndex*2u;
  if(offset+1u>=layout.levelMap.size())return false;
  metatile=(uint16_t)(layout.levelMap[offset]|((uint16_t)layout.levelMap[offset+1u]<<8));
  return true;
}

bool RomLevelRuntime::load(const RomLevelRequest& request,const std::string& romPath){
  if(romPath.empty()){
    // Match the original loader contract: failure invalidates prior level data.
    *this=RomLevelRuntime{};request_=request;width_=height_=waterSurfaceY_=0;
    std::string error;auto a=runtimeNativeAssets(error);
    if(!a){error_=error;return false;}
    auto level=a->levels.find(request.originalLevelId);
    if(level==a->levels.end()||level->second.request().sharedData!=request.sharedData||level->second.request().submap!=request.submap){error_="Native level request is not in package";return false;}
    *this=level->second;return true;
  }
  valid_=false;pixels_.clear();foregroundMask_.clear();placements_.clear();placementData_.clear();kobbleWalkFrames_.clear();bananaSpinFrames_.clear();bearCoinFrames_.clear();lifeBalloonFrames_.clear();barrelCannonFrames_.clear();barrelCannonAutoFrames_.clear();kongLetterFrames_.clear();
  kobbleWalkFrames_.clear();bananaSpinFrames_.clear();bearCoinFrames_.clear();kongLetterFrames_.clear();
  collisionRects_.clear();groundSpans_.clear();waterGaps_.clear();
  request_=request;startPoint_={};checkpointPoint_={};error_.clear();info_={};terrain_=RomPierTerrain{};
  width_=height_=0;waterSurfaceY_=0;
  const auto* codec=findRomScenarioCodec(request.sharedData);
  if(!codec){error_="Unknown shared_data codec";return false;}
  if(codec->sharedData!=0x19f0){error_="Scenario codec is not decoded yet";return false;}
  if(request.originalLevelId>=512 || request.submap>=pierSubmaps){error_="Level/submap outside decoded PIER tables";return false;}
  RomImage rom;if(!loadRom(romPath,rom)){error_="ROM load failed";return false;}info_=rom.info();
  const auto& rb=rom.bytes();
  const size_t ptr=0x3d0000u+static_cast<size_t>(request.originalLevelId)*2u;
  if(ptr+1>=rb.size()){error_="Level pointer outside ROM";return false;}
  const size_t header=0x3d0000u+(rb[ptr]|(rb[ptr+1]<<8));
  if(header+8>=rb.size()){error_="Level header outside ROM";return false;}
  if(rb[header]!=1&&rb[header]!=2){error_="Unsupported level header type";return false;}
  const size_t sharedOffset=rb[header]==2?5u:3u;
  if((rb[header+sharedOffset]|(rb[header+sharedOffset+1]<<8))!=request.sharedData ||
     rb[header+sharedOffset+2]!=request.submap){error_="ROM header does not match level request";return false;}
  const size_t pointOffset=rb[header]==2?18u:16u;
  if(header+pointOffset+3u>=rb.size()){error_="Spawn outside ROM";return false;}
  startPoint_={static_cast<int>(rb[header+pointOffset]|(rb[header+pointOffset+1u]<<8))-256,
               static_cast<int>(rb[header+pointOffset+2u]|(rb[header+pointOffset+3u]<<8))-256};
  if(rb[header]==1){
    if(header+24u>=rb.size()){error_="Checkpoint outside ROM";return false;}
    checkpointPoint_={static_cast<int>(rb[header+21u]|(rb[header+22u]<<8))-256,
                      static_cast<int>(rb[header+23u]|(rb[header+24u]<<8))-256};
  }
  RomScenarioLayout layout;
  if(!decodeRomScenarioLayout(rom,request.sharedData,request.submap,layout)){error_="Scenario family layout decode failed";return false;}
  if(layout.familyIndex!=9u||layout.shape!=0u){error_="PIER renderer received non-PIER map shape";return false;}
  const int mapStart=layout.xBegin,mapEnd=layout.xEnd;
  if((mapStart&31)||(mapEnd&31)||(layout.yBegin&31)||(layout.yEnd&31)){error_="Invalid submap bounds";return false;}
  const int columnStart=mapStart/32,kColumns=(mapEnd-mapStart)/32,kRows=(layout.yEnd-layout.yBegin)/32;
  if(kRows!=pierRows){error_="Unsupported PIER row count";return false;}
  width_=mapEnd-mapStart;height_=layout.yEnd-layout.yBegin;
  std::vector<uint8_t> packedBg,packedBgMap,packedSeaFloor,palette;
  std::vector<uint8_t> level=layout.levelMap,map32=layout.map32,fg=layout.foregroundGfx,bg,bgMap,seaFloorMap;
  // Level map, metatile definitions and foreground GFX now come through the
  // generic B7:B01B scenario-family decoder. PIER-only background/water art
  // remains here until those shared visual tables are decoded generically.
  if(!rom.range(hiromToPc(0xE5968A),hiromToPc(0xE5B2A5),packedBg) ||
     !rom.range(hiromToPc(0xE591C9),hiromToPc(0xE594A2),packedBgMap) ||
     !rom.range(hiromToPc(0xE594A2),hiromToPc(0xE59533),packedSeaFloor) ||
     !rom.range(hiromToPc(0xFD5601),hiromToPc(0xFD5701),palette) ||
     !decodeRomLevelPlacements(rom,request.originalLevelId,placements_,&placementData_))return false;
  if(!dkc3BigDataDecompress(packedBg.data(),packedBg.size(),bg) ||
     !dkc3SmallDataDecompress(packedBgMap.data(),packedBgMap.size(),bgMap) ||
     !dkc3BigDataDecompress(packedSeaFloor.data(),packedSeaFloor.size(),seaFloorMap))return false;

  if(level.size()<(size_t)(columnStart+kColumns)*kRows*2u || map32.size()<32u || fg.size()<32u ||
     bgMap.size()!=32u*32u*2u || seaFloorMap.size()!=32u*6u*2u || palette.size()<256u)return false;

  level=std::vector<uint8_t>(level.begin()+columnStart*kRows*2,
                            level.begin()+(columnStart+kColumns)*kRows*2);

  // Layer 1 usa cor 0 como transparencia no SNES. A v0.29 inicial a tratava
  // como uma cor RGB real (verde), criando faixas artificiais quando a camera
  // descia. Renderizamos uma mascara de opacidade e, apenas nas linhas que o
  // cartucho deixa transparentes, continuamos com linhas de agua authored da
  // propria ROM. Nao inventamos uma cor de preenchimento.
  std::vector<uint32_t> upperBg(256u*256u,0);
  std::vector<uint8_t> upperOpaque(256u*256u,0);
  RomLayer bgLayer{32,32,std::move(bg),std::move(bgMap),palette,true,4,false};
  if(!renderSnesLayer(bgLayer,upperBg,256,256,0,0,&upperOpaque))return false;
  std::vector<uint32_t> seaFloor(256u*48u,0);
  RomLayer seaLayer{32,6,bgLayer.gfx4bpp,std::move(seaFloorMap),palette,false,4,false};
  if(!renderSnesLayer(seaLayer,seaFloor,256,48))return false;

  // As linhas 112..225 sao a faixa de agua opaca do background PIER. A
  // partir de 226 o tilemap passa a cor 0/transparencia; por isso a extensao
  // vertical nunca deve reciclar 226..255 como fazia a versao anterior.
  constexpr int kWaterSourceFirst=112;
  constexpr int kWaterSourceLast=225;
  constexpr int kWaterSourceRows=kWaterSourceLast-kWaterSourceFirst+1;
  auto waterPixel=[&](int y,int x)->uint32_t{
    const int sy=kWaterSourceFirst+(y%kWaterSourceRows);
    return upperBg[(size_t)sy*256u+(size_t)(x&255)];
  };

  pixels_.resize((size_t)width_*(size_t)height_);
  foregroundMask_.assign(pixels_.size(),0);
  for(int y=0;y<height_;++y){
    for(int x=0;x<width_;++x){
      uint32_t c=0xff000000u;
      if(y<256){
        const size_t bi=(size_t)y*256u+(size_t)(x&255);
        c=upperOpaque[bi]?upperBg[bi]:waterPixel(std::max(0,y-226),x);
      }else if(y<464){
        c=waterPixel(y-256,x);
      }else{
        c=seaFloor[(size_t)(y-464)*256u+(size_t)(x&255)];
      }
      pixels_[(size_t)y*(size_t)width_+(size_t)x]=c;
    }
  }

  std::array<uint32_t,128> pal{};
  for(size_t i=0;i<pal.size();++i)pal[i]=bgr555((uint16_t)(palette[i*2]|(palette[i*2+1]<<8)));
  auto drawTile=[&](uint16_t entry,int dx,int dy){
    const int tile=entry&0x03ff;
    const int paletteIndex=(entry>>10)&7;
    const bool xflip=(entry&0x4000)!=0;
    const bool yflip=(entry&0x8000)!=0;
    const size_t tileOff=(size_t)tile*32u;
    if(tileOff+32u>fg.size())return;
    for(int py=0;py<8;++py){
      const int sy=yflip?7-py:py;
      const uint8_t p0=fg[tileOff+(size_t)sy*2u];
      const uint8_t p1=fg[tileOff+(size_t)sy*2u+1u];
      const uint8_t p2=fg[tileOff+16u+(size_t)sy*2u];
      const uint8_t p3=fg[tileOff+16u+(size_t)sy*2u+1u];
      for(int px=0;px<8;++px){
        const int sx=xflip?7-px:px;
        const int bit=7-sx;
        const int ci=((p0>>bit)&1)|(((p1>>bit)&1)<<1)|(((p2>>bit)&1)<<2)|(((p3>>bit)&1)<<3);
        if(ci==0)continue;
        const int outX=dx+px,outY=dy+py;
        if(outX<0||outY<0||outX>=width_||outY>=height_)continue;
        const int pi=paletteIndex*16+ci;
        const size_t oi=(size_t)outY*(size_t)width_+(size_t)outX;
        pixels_[oi]=pal[(size_t)pi];foregroundMask_[oi]=1;
      }
    }
  };

  // shared_data $19F0 usa o primeiro submapa para Lakeside. O primeiro mapa
  // tem exatamente 195 colunas x 16 linhas de metatile = 6240x512 pixels.
  for(int mx=0;mx<kColumns;++mx){
    for(int my=0;my<kRows;++my){
      const size_t mapOff=((size_t)mx*(size_t)kRows+(size_t)my)*2u;
      const uint16_t metatile=(uint16_t)(level[mapOff]|((uint16_t)level[mapOff+1u]<<8));
      const uint16_t flips=(uint16_t)(metatile&0xc000u);
      const uint16_t scaled=(uint16_t)((uint16_t)(metatile<<5)+((metatile&0x0800u)?1u:0u));
      for(int sy=0;sy<4;++sy){
        for(int sx=0;sx<4;++sx){
          const int ssx=(flips&0x4000u)?3-sx:sx;
          const int ssy=(flips&0x8000u)?3-sy:sy;
          const uint16_t defOff=(uint16_t)(scaled+(uint16_t)(ssy*8+ssx*2));
          if((size_t)defOff+1u>=map32.size())continue;
          const uint16_t entry=(uint16_t)((map32[(size_t)defOff]|((uint16_t)map32[(size_t)defOff+1u]<<8))^flips);
          drawTile(entry,mx*32+sx*8,my*32+sy*8);
        }
      }
    }
  }

  const std::vector<uint8_t>& terrainDefinitions=layout.terrainDefinitions;
  std::vector<uint8_t> terrainAttributes;
  if(!rom.range(0x37cfd0,0x37d078,terrainAttributes)||!terrain_.load(level,terrainDefinitions,terrainAttributes,kColumns))return false;
  std::vector<RomTerrainSurface> surfaces;
  if(!buildRomPierSurfaces(level,terrainDefinitions,kColumns,kRows,surfaces))return false;
  for(const auto& surface:surfaces)collisionRects_.push_back({surface.x,surface.y,surface.width,surface.height});
  // BB:A0D1 searches the ROM's level/index/behavior triples at BB:B7BC.
  size_t waterIndex=0;bool waterFound=false;
  for(size_t at=0x3bb7bcu;at+2u<0x3bb831u;at+=3u)if(rb[at]==request.originalLevelId){waterIndex=rb[at+1u];waterFound=true;break;}
  if(!waterFound){error_="Water profile missing from ROM";return false;}
  const size_t waterOffset=0x3bb831u+waterIndex*2u;
  if(waterOffset+1u>=rb.size()){error_="Water profile outside ROM";return false;}
  waterSurfaceY_=static_cast<int>(rom.bytes()[waterOffset]|(rom.bytes()[waterOffset+1u]<<8))-0x100;
  if(waterSurfaceY_<0||waterSurfaceY_>=height_)return false;
  std::vector<uint8_t> aboveWater(static_cast<size_t>(width_),0);
  for(const auto& r:collisionRects_)if(r.y<waterSurfaceY_)for(int x=r.x;x<r.x+r.width;++x)aboveWater[static_cast<size_t>(x)]=1;
  for(int x=0;x<width_;){const int start=x;const bool ground=aboveWater[static_cast<size_t>(x)]!=0;
    while(x<width_&&(aboveWater[static_cast<size_t>(x)]!=0)==ground)++x;
    (ground?groundSpans_:waterGaps_).push_back({start,waterSurfaceY_,x-start,height_-waterSurfaceY_});
  }
  std::sort(collisionRects_.begin(),collisionRects_.end(),[](const auto&a,const auto&b){return a.y<b.y||(a.y==b.y&&a.x<b.x);});

  if(!buildKobbleWalkFrames(rom,kobbleWalkFrames_)||
     !buildBananaSpinFrames(rom,bananaSpinFrames_)||
     !buildBearCoinFrames(rom,bearCoinFrames_)||
     !buildLifeBalloonFrames(rom,lifeBalloonFrames_)||
     !buildBarrelCannonFrames(rom,barrelCannonFrames_,false)||
     !buildBarrelCannonFrames(rom,barrelCannonAutoFrames_,true)||
     !buildKongLetterFrames(rom,kongLetterFrames_))return false;
  valid_=true;return true;
}


std::pair<int,int> RomLakesideBonusVisuals::startPoint() const{
  return startPoint_;
}
std::pair<int,int> RomLakesideBonusVisuals::returnPoint() const{
  return bonusIndex_==1?std::pair<int,int>{0x770,0x78}:std::pair<int,int>{0x1150,0x88};
}

bool RomLakesideBonusVisuals::load(int bonusIndex,const std::string& romPath){
  if(romPath.empty()){std::string error;auto a=runtimeNativeAssets(error);if(!a||bonusIndex<1||bonusIndex>2){valid_=false;return false;}*this=a->bonuses[bonusIndex-1];return true;}
  valid_=false;bonusIndex_=bonusIndex;pixels_.clear();foregroundMask_.clear();collisionRects_.clear();placements_.clear();starFrames_.clear();greenBananaFrames_.clear();bonusCoinFrames_.clear();starPositions_.clear();greenBananaPositions_.clear();
  if(bonusIndex_!=1&&bonusIndex_!=2)return false;
  RomImage rom;if(!loadRom(romPath,rom))return false;
  const auto& rb=rom.bytes();const size_t levelId=bonusIndex_==1?0x50u:0x51u;
  const size_t ptr=0x3d0000u+levelId*2u;
  const size_t header=0x3d0000u+(rb[ptr]|(rb[ptr+1u]<<8));
  if(header+22u>rb.size()||rb[header]!=2u||rb[header+5u]!=0xf0u||rb[header+6u]!=0x19u)return false;
  const unsigned submap=rb[header+7u];
  startPoint_={static_cast<int>(rb[header+18u]|(rb[header+19u]<<8))-256,static_cast<int>(rb[header+20u]|(rb[header+21u]<<8))-256};
  RomLevelRuntime runtime;
  if(!runtime.load(RomLevelRequest{static_cast<uint16_t>(levelId),0x19f0,static_cast<uint8_t>(submap)},romPath))return false;
  terrain_=runtime.terrain();width_=runtime.width();height_=runtime.height();
  pixels_=runtime.pixels();foregroundMask_=runtime.foregroundMask();
  collisionRects_=runtime.collisionRects();placements_=runtime.placements();

  if(!buildRaw2x2Frames(rom,0xFFDF80,0xFFE380,0xFD3B7D,0xFD3B9B,8,starFrames_)||
     !buildRaw2x2Frames(rom,0xFFE600,0xFFEA00,0xFD38E9,0xFD3907,8,greenBananaFrames_)||
     !buildBonusCoinFrames(rom,bonusCoinFrames_))return false;

  if(bonusIndex_==1){
    // ROM banana-placement stream $ECECCA..$ECECFE. Each 4-byte record encodes
    // a base coordinate plus a formation id. Formation payloads are width,
    // height and an LSB-first occupancy bitmap. These four formations resolve
    // to exactly the original 50 collectible stars.
    const std::vector<uint8_t> stream(rom.bytes().begin()+hiromToPc(0xECECCA),rom.bytes().begin()+hiromToPc(0xECECFE));
    const uint16_t basePointer=(uint16_t)(rom.bytes()[hiromToPc(0xECD000)]|((uint16_t)rom.bytes()[hiromToPc(0xECD000)+1]<<8));
    for(size_t o=0;o+3<stream.size();o+=4){const uint8_t a=stream[o],b=stream[o+1],c=stream[o+2],fid=stream[o+3];const uint16_t ab=(uint16_t)(a|((uint16_t)b<<8)),bc=(uint16_t)(b|((uint16_t)c<<8));const int bx=(int)(((ab>>1)&0x3ff8u));const int by=(int)(((bc>>4)&0x03f8u));const uint32_t ptrAddr=0xEC0000u+(uint16_t)(basePointer+(uint16_t)fid*2u);const size_t ptrPc=hiromToPc(ptrAddr);if(ptrPc+1u>=rom.bytes().size())return false;const uint16_t rel=(uint16_t)(rom.bytes()[ptrPc]|((uint16_t)rom.bytes()[ptrPc+1]<<8));const uint32_t formAddr=0xEC0000u+(uint16_t)(basePointer+rel);const size_t fp=hiromToPc(formAddr);if(fp+2u>rom.bytes().size())return false;const int fw=rom.bytes()[fp],fh=rom.bytes()[fp+1];const size_t bits=(size_t)fw*(size_t)fh,bytes=(bits+7u)/8u;if(fp+2u+bytes>rom.bytes().size())return false;for(size_t bit=0;bit<bits;++bit)if(rom.bytes()[fp+2u+bit/8u]&(1u<<(bit&7u)))starPositions_.push_back({bx+(int)(bit%(size_t)fw)*8,by+(int)(bit/(size_t)fw)*8});}
    if(starPositions_.size()!=50u)return false;
  }else{
    // The SpriteID $0154 descriptor ($FF:B5A3) points at this exact 15-entry
    // spawn table. Coordinates are stored with the engine's +$0100 bias.
    const size_t p0=hiromToPc(0xFFB5ADu);if(p0+60u>rom.bytes().size())return false;for(int i=0;i<15;++i){const size_t q=p0+(size_t)i*4u;const int x=(int)(rom.bytes()[q]|((uint16_t)rom.bytes()[q+1]<<8))-0x100;const int y=(int)(rom.bytes()[q+2]|((uint16_t)rom.bytes()[q+3]<<8))-0x100;greenBananaPositions_.push_back({x,y});}
  }
  valid_=true;return true;
}

bool RomLakeOrangatangaVisuals::load(const std::string& romPath){
  if(romPath.empty()){std::string error;auto a=runtimeNativeAssets(error);if(!a){valid_=false;return false;}*this=a->lakeMap;return true;}
  valid_=false;map_.clear();collision_.clear();dixieWalkFrames_.clear();
  RomImage rom;if(!loadRom(romPath,rom))return false;info_=rom.info();
  std::vector<uint8_t> packedGfx,packedMap,gfx,tilemap,palette;
  if(!rom.range(hiromToPc(0xCFFF7E),hiromToPc(0xD04F61),packedGfx))return false;
  if(!rom.range(hiromToPc(0xE86F2B),hiromToPc(0xE871D7),packedMap))return false;
  if(!rom.range(hiromToPc(0xFD7D41),hiromToPc(0xFD7E41),palette))return false;
  if(!rom.range(hiromToPc(0xE926FB),hiromToPc(0xE92796),collision_))return false;
  if(!dkc3BigDataDecompress(packedGfx.data(),packedGfx.size(),gfx))return false;
  if(!dkc3SmallDataDecompress(packedMap.data(),packedMap.size(),tilemap))return false;
  if(tilemap.size()!=32u*28u*2u)return false;
  map_.assign(256u*224u,0);
  RomLayer layer{32,28,std::move(gfx),std::move(tilemap),std::move(palette),false,4,false};
  if(!renderSnesLayer(layer,map_,256,224))return false;
  if(!buildDixieMapWalkFrames(rom,dixieWalkFrames_))return false;
  valid_=true;return true;
}

bool RomWorldMapVisuals::load(const std::string& romPath){
  if(romPath.empty()){std::string error;auto a=runtimeNativeAssets(error);if(!a){valid_=false;return false;}*this=a->worldMap;return true;}
  valid_=false;map_.clear();landMask_.clear();boatFrames_.clear();RomImage rom;if(!loadRom(romPath,rom))return false;info_=rom.info();
  auto dec=[&](size_t a,size_t b,std::vector<uint8_t>& out)->bool{std::vector<uint8_t> in;if(!rom.range(a,b,in))return false;return dkc3BigDataDecompress(in.data(),in.size(),out);};
  std::vector<uint8_t> pal;if(!rom.range(0x3D7421,0x3D7521,pal))return false;
  std::vector<uint8_t> wg,wt,l3g,l3t,l1g,l1t;
  if(!dec(0x2B0B39,0x2B12E2,wg)||!dec(0x2B081C,0x2B0B39,wt)||!dec(0x321DA4,0x32275C,l3g)||!dec(0x3215A9,0x321DA4,l3t)||!dec(0x350000,0x35702E,l1g)||!dec(0x320000,0x3215A9,l1t))return false;
  std::vector<uint32_t> water(256u*256u,0);RomLayer waterLayer{32,32,std::move(wg),std::move(wt),pal,false,4,false};if(!renderSnesLayer(waterLayer,water,256,256))return false;
  map_.assign((size_t)width_*(size_t)height_,0);for(int y=0;y<height_;++y)for(int x=0;x<width_;++x)map_[(size_t)y*(size_t)width_+(size_t)x]=water[(size_t)(y&255)*256u+(size_t)(x&255)];
  RomLayer shore{64,64,std::move(l3g),std::move(l3t),pal,true,2,true};if(!renderSnesLayer(shore,map_,width_,height_))return false;
  RomLayer land{64,64,std::move(l1g),std::move(l1t),pal,true,4,true};landMask_.assign(map_.size(),0);if(!renderSnesLayer(land,map_,width_,height_,0,0,&landMask_))return false;
  if(!buildBoatFrames(rom,boatFrames_))return false;
  valid_=true;return true;
}

bool RomWorldMapVisuals::landAt(int x,int y) const{if(!valid_||x<0||y<0||x>=width_||y>=height_)return true;return landMask_[(size_t)y*(size_t)width_+(size_t)x]!=0;}
bool RomWorldMapVisuals::boatBlocked(float x,float y,int halfW,int halfH) const{
  if(!valid_)return false;
  const int cx=(int)std::lround(x),cy=(int)std::lround(y);
  for(int sy=-halfH;sy<=halfH;sy+=3)for(int sx=-halfW;sx<=halfW;sx+=3)if(landAt(cx+sx,cy+sy))return true;
  return landAt(cx-halfW,cy-halfH)||landAt(cx+halfW,cy-halfH)||landAt(cx-halfW,cy+halfH)||landAt(cx+halfW,cy+halfH);
}

}
