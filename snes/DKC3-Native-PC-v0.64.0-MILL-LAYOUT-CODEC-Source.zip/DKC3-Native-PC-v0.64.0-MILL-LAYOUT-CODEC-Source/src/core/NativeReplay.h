#pragma once
#include "Input.h"
#include "WorldMap.h"
#include "input_playback.h"
#include <string>
namespace dkc3 {
InputState nativeInputFromSnes(uint32_t mask);
WorldMapInput nativeMapInputFromSnes(uint32_t mask);
class NativeReplay {
 public:
  NativeReplay()=default;
  ~NativeReplay(){Dkc3InputPlaybackFree(&playback_);}
  NativeReplay(const NativeReplay&)=delete;
  NativeReplay& operator=(const NativeReplay&)=delete;
  bool load(const std::string& path,std::string& error);
  size_t count()const{return playback_.count;}
  uint32_t frame(size_t at)const{return Dkc3InputPlaybackFrame(&playback_,at);}
 private:Dkc3InputPlayback playback_{};
};
}
