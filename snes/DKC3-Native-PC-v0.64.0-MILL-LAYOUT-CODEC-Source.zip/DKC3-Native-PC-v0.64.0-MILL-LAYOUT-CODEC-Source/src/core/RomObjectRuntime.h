#pragma once
#include "RomData.h"
namespace dkc3 {
enum class RomObjectBehavior { Unknown, LevelTrigger, DespawnControl, KoinController, BarrelRespawner, SteelKeg, AnimalBox, NoAnimalSign, BootyBird, Sneek, Buzz, Kobble, BearCoin, Banana, LifeBalloon,
  KongLetter, Checkpoint, EndFlag, BarrelCannon, TeamBarrel, CarryBarrel, BonusCoin, GreenBananaSpawner, DoorLever, MetalDoor, DoorGear };
struct RomObjectDefinition {
  uint16_t spriteId;
  RomObjectBehavior behavior;
  RomSupport support;
  const char* name;
  const char* limitation;
  uint32_t romHandler=0;
};
const RomObjectDefinition& findRomObject(uint16_t spriteId);
RomObjectBehavior romObjectBehavior(uint16_t spriteId);
struct RomSpawnRecord {
  size_t placementIndex;
  RomLevelPlacement placement;
  RomObjectDefinition definition;
};
class RomSpawnRuntime {
 public:
  void build(const std::vector<RomLevelPlacement>& placements);
  const std::vector<RomSpawnRecord>& records() const { return records_; }
  size_t count(RomSupport support) const;
  std::string report() const;
 private:
  std::vector<RomSpawnRecord> records_;
};
}
