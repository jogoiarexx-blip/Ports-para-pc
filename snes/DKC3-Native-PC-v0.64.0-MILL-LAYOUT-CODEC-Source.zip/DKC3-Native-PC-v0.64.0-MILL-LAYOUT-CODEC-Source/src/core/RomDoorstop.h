#pragma once
#include "RomData.h"
#include <cstdint>

namespace dkc3 {

// Static contracts recovered from Doorstop/Buzz spawn scripts and the original
// B6 handlers. These helpers intentionally stop before collision/actor dispatch;
// they preserve the ROM-authored parameters required by the future MILL runtime.
struct RomBuzzProfile {
  uint16_t animationId=0;
  uint16_t renderFlags=0;
  uint16_t movementFlags=0;
  uint16_t movementWord60=0;
  uint16_t movementWord64=0;
  uint8_t variant=0;
};

struct RomDoorLeverProfile {
  uint16_t animationId=0;
  uint16_t renderFlags=0;
  uint16_t initialState=0;
  uint8_t activationStep=0;
  uint8_t phaseStep=0;
  uint8_t phaseOrigin=0;
};

struct RomMetalDoorProfile {
  uint16_t animationId=0;
  uint16_t renderFlags=0;
  uint8_t travel=0;
  uint8_t closeStep=0;
  uint8_t phaseStep=0;
};

struct RomDoorGearProfile {
  uint16_t animationId=0;
  uint16_t renderFlags=0;
};

bool loadRomBuzzProfile(const RomLevelPlacement& placement,RomBuzzProfile& out);
bool loadRomDoorLeverProfile(const RomLevelPlacement& placement,RomDoorLeverProfile& out);
bool loadRomMetalDoorProfile(const RomLevelPlacement& placement,RomMetalDoorProfile& out);
bool loadRomDoorGearProfile(const RomLevelPlacement& placement,RomDoorGearProfile& out);

// Exact 8-bit multiply/high-byte arithmetic used by the reviewed B6 routines.
uint8_t romDoorScaledOffset(uint8_t distance,uint8_t control);
uint16_t romDoorY(uint16_t baseY,uint8_t travel,uint8_t control);
uint16_t romDoorLeverAxis(uint16_t base,uint8_t phase,uint8_t control);
uint16_t romDoorGearMotion(uint8_t control);

}
