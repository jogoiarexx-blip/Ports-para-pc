#include "CarryBarrel.h"
#include "RomTerrain.h"
#include "RomSteelKeg.h"
#include <algorithm>
#include <cmath>
namespace dkc3 {
Rect carryBarrelSweepBounds(const CarryBarrelBody& b,Vec2 previous){
 const float x=std::min(previous.x,b.pos.x),y=std::min(previous.y,b.pos.y);
 return {x,y,b.w+std::fabs(b.pos.x-previous.x),b.h+std::fabs(b.pos.y-previous.y)};
}
CarryBarrelImpact advanceCarryBarrel(CarryBarrelBody& b,float dt,const std::vector<Rect>& solids,const std::vector<Rect>& platforms,const RomPierTerrain* terrain,int width,int height){
 if(b.state!=CarryBarrelState::Thrown&&b.state!=CarryBarrelState::Dropped)return CarryBarrelImpact::None;
 b.remainder+=std::max(0.f,dt);constexpr double tick=1.0/60.0;
 while(b.remainder+1e-9>=tick){
  b.remainder=std::max(0.0,b.remainder-tick);b.age+=static_cast<float>(tick);
  b.velocity.y=std::min(420.f,b.velocity.y+720.f/60.f);
  const float dx=b.velocity.x/60.f,dy=b.velocity.y/60.f;
  const int steps=std::max(1,static_cast<int>(std::ceil(std::max(std::fabs(dx),std::fabs(dy)))));
  for(int n=0;n<steps;++n){
   const Vec2 old=b.pos;b.pos.x+=dx/steps;b.pos.y+=dy/steps;
   if(b.pos.x<0||b.pos.x+b.w>width||b.pos.y>height+64)return CarryBarrelImpact::Outside;
   bool hit=false;float top=0;
   for(const auto& solid:solids)if(overlaps(b.bounds(),solid)){hit=true;top=solid.y;break;}
   if(!hit&&dy>=0)for(const auto& platform:platforms)
    if(b.pos.x+b.w>platform.x&&b.pos.x<platform.x+platform.w&&old.y+b.h<=platform.y+.01f&&b.pos.y+b.h>=platform.y){hit=true;top=platform.y;break;}
   if(!hit&&terrain){
    const int edge=static_cast<int>(std::floor(b.pos.x+(dx<0?0:b.w-1)));
    for(int y=static_cast<int>(b.pos.y)+1;y<static_cast<int>(b.pos.y+b.h)-1;++y)
     if(terrain->solidBodyPoint(edge,y)&&!terrain->solidBodyPoint(static_cast<int>(old.x+(dx<0?0:b.w-1)),y)){hit=true;break;}
    if(!hit&&dy<0)for(int x=static_cast<int>(b.pos.x)+1;x<static_cast<int>(b.pos.x+b.w)-1;++x)
     if(terrain->solidBodyPoint(x,static_cast<int>(b.pos.y))&&!terrain->solidBodyPoint(x,static_cast<int>(old.y))){hit=true;break;}
   }
   if(hit){
    if(b.state==CarryBarrelState::Dropped&&dy>=0&&old.y+b.h<=top+.01f){b.pos.y=top-b.h;b.velocity={};b.state=CarryBarrelState::Resting;b.remainder=0;return CarryBarrelImpact::None;}
    b.pos=old;return CarryBarrelImpact::Terrain;
   }
  }
 }
 return CarryBarrelImpact::None;
}
SteelKegStep advanceSteelKeg(CarryBarrelBody& b,float dt,const std::vector<Rect>& solids,const std::vector<Rect>& platforms,const RomPierTerrain* terrain,int width,int height,uint16_t waterY){
 SteelKegStep result;
 if(b.state!=CarryBarrelState::Thrown&&b.state!=CarryBarrelState::Dropped)return result;
 b.remainder+=std::max(0.f,dt);constexpr double tick=1./60.;
 while(b.remainder+1e-9>=tick){
  b.remainder=std::max(0.,b.remainder-tick);b.age+=float(tick);
  if(b.steelProfile.valid){
   const auto vy=romSteelGravity(uint16_t(int(std::lround(b.velocity.y*256.f/60.f))),b.steelProfile);
   const auto vx=romSteelInterpolate(uint16_t(int(std::lround(b.velocity.x*256.f/60.f))),b.steelTarget);
   b.velocity={float(int16_t(vx))*60.f/256.f,float(int16_t(vy))*60.f/256.f};
  }else b.velocity.y=std::min(420.f,b.velocity.y+12.f);
  const auto probe=romSteelWaterProbe(b.steelProfile.valid?waterY:0xffff,
   uint16_t(int(std::floor(b.pos.y+b.h))+256),uint16_t(int(std::lround(b.velocity.x*256.f/60.f))),uint16_t(int(std::lround(b.velocity.y*256.f/60.f))));
  const float dx=b.steelProfile.valid?float(int16_t(probe.x))/256.f:b.velocity.x/60.f;
  const float dy=b.steelProfile.valid?float(int16_t(probe.y))/256.f:b.velocity.y/60.f;
  const int steps=std::max(1,int(std::ceil(std::max(std::fabs(dx),std::fabs(dy)))));
  bool bounced=false;
  for(int n=0;n<steps;++n){
   const Vec2 old=b.pos;b.pos.x+=bounced?0:dx/steps;
   if(b.pos.x<0||b.pos.x+b.w>width){result.outside=true;return result;}
   bool wall=false;for(const auto& solid:solids)wall|=overlaps(b.bounds(),solid);
   if(terrain&&!bounced&&dx!=0){const int edge=int(std::floor(b.pos.x+(dx<0?0:b.w-1)));
    for(int y=int(b.pos.y)+2;y<int(b.pos.y+b.h)-2;++y)
     wall|=terrain->solidBodyPoint(edge,y)&&!terrain->solidBodyPoint(int(old.x+(dx<0?0:b.w-1)),y);}
   if(wall){b.pos.x=old.x;RomSteelVelocity native;native.oam=b.steelOam;
    const auto previousX=probe.x;
    romSteelWall(native,b.steelTarget,previousX);b.steelOam=native.oam;b.steelTarget=native.target;
    b.velocity.x=float(int16_t(native.x))*60.f/256.f;result.wall=true;bounced=true;}
   const float oldBottom=b.pos.y+b.h;b.pos.y+=dy/steps;
   if(b.pos.y>height+64){result.outside=true;return result;}
   float floor=1e9;
   auto test=[&](const Rect& s){if(b.pos.x+b.w>s.x&&b.pos.x<s.x+s.w&&oldBottom<=s.y+.01f&&b.pos.y+b.h>=s.y)floor=std::min(floor,s.y);};
   if(dy>=0){for(const auto& s:solids)test(s);for(const auto& s:platforms)test(s);
    if(terrain)for(int x=int(b.pos.x)+2;x<int(b.pos.x+b.w)-2;++x){auto q=terrain->query(uint16_t(x),uint16_t(oldBottom+256));
     const int surface=q.surfaceY();if(q.supported&&surface>=0&&!q.ceiling&&!(q.initialAttributes&0x4000u)&&!(q.attributes&0x1800u))test({float(x),float(surface),1,1});}}
   if(floor<1e8){b.pos.y=floor-b.h;b.velocity.y=0;result.terrain=0x101;
    if(b.state==CarryBarrelState::Dropped){b.velocity={};b.state=CarryBarrelState::Resting;b.remainder=0;return result;}}
   else if(dy<0){bool ceiling=false;for(const auto& s:solids)ceiling|=overlaps(b.bounds(),s);
    if(terrain)for(int x=int(b.pos.x)+2;x<int(b.pos.x+b.w)-2;++x)
     ceiling|=terrain->solidBodyPoint(x,int(b.pos.y))&&!terrain->solidBodyPoint(x,int(old.y));
    if(ceiling){b.pos.y=old.y;b.velocity.y=0;}}
  }
 }
 return result;
}

}
