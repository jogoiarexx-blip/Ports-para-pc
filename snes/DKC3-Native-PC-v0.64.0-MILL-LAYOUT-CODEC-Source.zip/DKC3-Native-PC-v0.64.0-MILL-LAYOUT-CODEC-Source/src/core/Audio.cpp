#include "Audio.h"
#include <algorithm>
#include <cmath>
namespace dkc3 {
namespace {
constexpr float kPi = 3.14159265f;
struct Def { const char* name; float dur; };
const Def kDefs[] = {
  {"jump",0.14f},{"land",0.09f},{"coin",0.20f},{"stomp",0.14f},{"roll",0.22f},{"enemy_hit",0.20f},{"hurt",0.32f},
  {"checkpoint",0.30f},{"lever",0.22f},{"switch",0.12f},{"door",0.24f},{"locked",0.22f},{"splash",0.28f},
};
inline float sq(float ph){return (ph-std::floor(ph))<0.5f?1.0f:-1.0f;}
inline float tri(float ph){float x=ph-std::floor(ph);return 4.0f*std::fabs(x-0.5f)-1.0f;}
inline float saw(float ph){return 2.0f*(ph-std::floor(ph))-1.0f;}
inline float noise(uint32_t& r){r=r*1664525u+1013904223u;return (float)(int32_t)(r>>8)/8388608.0f-1.0f;}
inline float decay(float t,float d,float p=1.0f){float x=1.0f-t/d;return x<=0?0:std::pow(x,p);}
// Gera uma amostra [-1,1] do efeito 'id' no tempo t (s). 'ph' e 'lp' sao estados do voice.
float synth(Sfx id,float t,float& ph,float& lp,uint32_t& rng){
  const float dt=1.0f/SfxMixer::kRate;
  switch(id){
    case Sfx::Jump:{float f=300.0f+320.0f*(t/0.14f);ph+=f*dt;return 0.30f*sq(ph)*decay(t,0.14f,0.8f);}
    case Sfx::Land:{float n=noise(rng);lp+=0.18f*(n-lp);ph+=(95.0f-30.0f*t/0.09f)*dt;return (0.9f*lp*1.6f+0.5f*std::sin(2*kPi*ph))*0.45f*decay(t,0.09f,1.5f);}
    case Sfx::Coin:{float f=t<0.06f?988.0f:1319.0f;ph+=f*dt;return 0.22f*sq(ph)*(t<0.06f?1.0f:decay(t-0.06f,0.14f,1.2f));}
    case Sfx::Stomp:{float f=240.0f-150.0f*(t/0.14f);ph+=f*dt;float n=noise(rng);lp+=0.35f*(n-lp);return (0.55f*tri(ph)+0.35f*lp)*0.7f*decay(t,0.14f,1.1f);}
    case Sfx::Roll:{float n=noise(rng);lp+=(0.12f+0.5f*(t/0.22f))*(n-lp);ph+=(130.0f+90.0f*t/0.22f)*dt;float env=std::sin(kPi*std::min(1.0f,t/0.22f));return (0.8f*lp+0.25f*sq(ph))*0.5f*env;}
    case Sfx::EnemyHit:{float f=520.0f-400.0f*(t/0.20f);ph+=f*dt;float n=noise(rng);float burst=t<0.04f?n*0.5f:0.0f;return (0.30f*saw(ph)+burst)*decay(t,0.20f,1.0f);}
    case Sfx::Hurt:{float f=420.0f-260.0f*(t/0.32f)+18.0f*std::sin(2*kPi*28.0f*t);ph+=f*dt;return 0.38f*std::sin(2*kPi*ph)*decay(t,0.32f,0.9f)+0.12f*tri(ph*2.0f)*decay(t,0.32f,2.0f);}
    case Sfx::Checkpoint:{static const float n[3]={523.25f,659.25f,783.99f};int i=std::min(2,(int)(t/0.10f));float lt=t-i*0.10f;ph+=n[i]*dt;return 0.32f*tri(ph)*(i<2?decay(lt,0.12f,0.6f):decay(lt,0.20f,1.0f));}
    case Sfx::Lever:{float f=t<0.10f?110.0f:220.0f;ph+=f*dt;float lt=t<0.10f?t:t-0.10f;return 0.34f*sq(ph)*decay(lt,t<0.10f?0.10f:0.12f,1.3f);}
    case Sfx::Switch:{float f=t<0.05f?660.0f:880.0f;ph+=f*dt;float lt=t<0.05f?t:t-0.05f;return 0.24f*sq(ph)*decay(lt,t<0.05f?0.05f:0.07f,1.0f);}
    case Sfx::Door:{static const float n[3]={392.0f,330.0f,262.0f};int i=std::min(2,(int)(t/0.08f));float lt=t-i*0.08f;ph+=n[i]*dt;return 0.30f*tri(ph)*decay(lt,i<2?0.09f:0.16f,0.8f);}
    case Sfx::Locked:{float on=(t<0.08f||(t>0.11f&&t<0.19f))?1.0f:0.0f;ph+=130.0f*dt;return 0.30f*sq(ph)*on;}
    case Sfx::Splash:{float n=noise(rng);lp+=(0.45f-0.35f*(t/0.28f))*(n-lp);return 0.9f*lp*std::sin(0.5f*kPi*std::min(1.0f,t/0.05f))*decay(t,0.28f,1.4f);}
    default:return 0;
  }
}
}
const char* sfxName(Sfx s){return (int)s<(int)Sfx::Count?kDefs[(int)s].name:"?";}
float sfxDuration(Sfx s){return (int)s<(int)Sfx::Count?kDefs[(int)s].dur:0.0f;}
void SfxMixer::trigger(Sfx s){
  if((int)s>=(int)Sfx::Count)return;
  // Mesmo efeito repetido no mesmo instante: reinicia a voz em vez de empilhar (evita estouro de volume).
  for(auto&v:voices_)if(v.id==s&&v.n<(int)(0.02f*kRate)){v.n=0;v.phase=v.lp=0;return;}
  if((int)voices_.size()>=kMaxVoices)voices_.erase(voices_.begin());
  Voice v;v.id=s;seed_=seed_*1103515245u+12345u;v.rng=seed_|1u;voices_.push_back(v);
}
void SfxMixer::mix(int16_t* out,int frames){
  if(!out||frames<=0)return;
  for(int i=0;i<frames;++i){
    float acc=0;
    for(auto&v:voices_){const float t=(float)v.n/kRate;if(t<sfxDuration(v.id))acc+=synth(v.id,t,v.phase,v.lp,v.rng);++v.n;}
    acc=muted_?0.0f:acc*volume_;
    // limitador suave: nunca passa de +-1 mesmo com varias vozes
    acc=std::tanh(acc*1.2f)/std::tanh(1.2f);
    out[i]=(int16_t)std::lrint(std::clamp(acc,-1.0f,1.0f)*32000.0f);
  }
  voices_.erase(std::remove_if(voices_.begin(),voices_.end(),[](const Voice&v){return (float)v.n/kRate>=sfxDuration(v.id);}),voices_.end());
}
}
