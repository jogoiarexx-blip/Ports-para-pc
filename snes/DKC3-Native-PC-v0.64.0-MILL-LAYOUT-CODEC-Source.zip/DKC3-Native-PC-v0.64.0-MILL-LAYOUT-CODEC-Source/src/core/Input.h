#pragma once
namespace dkc3 {
struct InputState {
  bool left=false,right=false,up=false,down=false;
  bool jump=false,run=false,attack=false,switchCharacter=false;
};
}
