#include "Game.h"
#include "LevelSession.h"
#include "NativeTrace.h"
namespace dkc3 {
namespace {
void vec(TraceState& s,const std::string& k,Vec2 v){s.set(k+".x",v.x);s.set(k+".y",v.y);}
void rect(TraceState& s,const std::string& k,Rect r){s.set(k+".x",r.x);s.set(k+".y",r.y);s.set(k+".w",r.w);s.set(k+".h",r.h);}
void anim(TraceState& s,const std::string& k,const AnimationPlayer& a){s.set(k+".frame",a.frame);s.set(k+".time",a.time);s.set(k+".finished",a.finished);}
void playerState(TraceState& s,const std::string& k,const Player& p){
 vec(s,k+".position",p.pos);vec(s,k+".velocity",p.vel);
#define P(n) s.set(k+"." #n,p.n)
 P(nativeRemainder);P(ropeRemainder);P(nativeRope);P(nativeWaterSurfaceY);P(ropeRegrabDelay);P(ropeJumpPending);P(nativeRopeGrabs);P(nativeRopeStops);P(nativeJumpPending);P(nativeControlFlags);P(nativeTerrainFlags);P(nativeTerrainAttributes);P(nativeCeilingHits);P(nativeWallHits);P(nativeAirWallHits);P(nativeGroundFollows);P(nativeHorizontalTarget);P(nativeBlockedTarget);P(nativeBlockedVelocity);P(nativeGravity);P(nativeLandingVelocity);P(width);P(height);P(grounded);P(facingRight);P(coyoteTimer);P(jumpBuffer);P(jumpTime);P(jumpWasDown);P(jumping);P(justJumped);
#undef P
 s.set(k+".motion",int(p.motion));s.set(k+".water_state",int(p.nativeWaterState));
}
void collectible(TraceState& s,const std::string& k,const RuntimeCollectible& c){s.set(k+".id",c.id);vec(s,k+".position",c.pos);s.set(k+".active",c.active);s.set(k+".value",c.value);s.set(k+".width",c.w);s.set(k+".height",c.h);anim(s,k+".animation",c.animator);}
std::string at(const std::string& group,size_t i){return "objects."+group+"."+std::to_string(i);}
}
void Game::appendTraceState(TraceState& s)const{
 s.set("state_profile","dkc3.host-observable.v1");s.unavailable("rng.original");
 playerState(s,"player",player_);vec(s,"camera",{camera_.x,camera_.y});s.set("camera.width",camera_.viewportW);s.set("camera.height",camera_.viewportH);
 vec(s,"respawn",respawn_);vec(s,"main_respawn",mainRespawn_);vec(s,"companion.position",companionPos_);vec(s,"water.current",activeWaterCurrent_);
 s.set("player.animation_state",playerAnimState_);s.set("companion.animation_state",companionAnimState_);anim(s,"player.animation",playerAnimator_);anim(s,"companion.animation",companionAnimator_);
 s.set("game.in_bonus",inBonus_);s.set("game.active_character",int(activeCharacter_));s.set("game.pending_level",pendingLevel_);s.set("game.level",world_.id);s.set("game.original_level",world_.originalLevelId);
#define G(n) s.set("game." #n,n##_)
 G(surfaceJumpPending);G(partnerAvailable);G(coins);G(bananas);G(lives);G(damageCount);G(defeatedEnemies);G(characterSwitches);G(leverActivations);G(checkpointActivations);G(lockedDoorAttempts);G(teamBarrelRescues);G(barrelEntries);G(warpShortcuts);G(bonusBarrelAttempts);G(activeBonus);G(bonusCollected);G(bonusGreenIndex);G(bonusCoins);G(lakesideBonusMask);G(bonusTimeRemaining);G(bonusGreenLife);G(kongMask);G(kongLettersCollected);G(attackTimer);G(attackCooldown);G(invulnerableTimer);G(carriedBarrel);G(barrelPickups);G(barrelThrows);G(barrelBreaks);G(barrelEnemyHits);G(barrelReleaseBlocked);G(activeBarrel);G(barrelHoldTimer);G(barrelCooldown);G(activeLever);G(inWater);G(inWaterCurrent);G(prevGrounded);G(prevInWater);G(waterKnown);G(lastAirVy);G(levelTime);G(pageFade);G(activeScenePage);G(fadeFromPage);G(prevUp);G(prevJump);G(prevAttack);G(prevSwitch);G(crouchVisual);G(animalMounts);G(animalSignRewards);G(dkCoins);
#undef G
 for(size_t i=0;i<koinFlags_.size();++i)s.set("save.koin_flags."+std::to_string(i),koinFlags_[i]);
 for(size_t i=0;i<checkpointActive_.size();++i)s.set(at("checkpoints",i)+".active",bool(checkpointActive_[i]));
 for(const auto& [address,v]:romLevelBytes_)s.set("ram."+std::to_string(address),v);
 s.set("objects.enemies.count",enemies_.size());
 for(size_t i=0;i<enemies_.size();++i){const auto& e=enemies_[i];const auto k=at("enemies",i);s.set(k+".id",e.id);s.set(k+".sprite_id",e.spriteId);vec(s,k+".position",e.pos);s.set(k+".speed",e.speed);s.set(k+".active",e.active);s.set(k+".facing_right",e.facingRight);s.set(k+".reward_index",e.rewardIndex);anim(s,k+".animation",e.animator);}
 s.set("objects.collectibles.count",collectibles_.size());for(size_t i=0;i<collectibles_.size();++i)collectible(s,at("collectibles",i),collectibles_[i]);
 s.set("objects.bonus.count",bonusCollectibles_.size());for(size_t i=0;i<bonusCollectibles_.size();++i)collectible(s,at("bonus",i),bonusCollectibles_[i]);collectible(s,"objects.bonus_coin",bonusCoin_);
 for(size_t i=0;i<kongLetters_.size();++i){const auto& c=kongLetters_[i];const auto k=at("letters",i);s.set(k+".letter",int(c.letter));s.set(k+".active",c.active);vec(s,k+".position",c.pos);anim(s,k+".animation",c.animator);}
 s.set("objects.barrels.count",teamBarrels_.size());
 for(size_t i=0;i<teamBarrels_.size();++i){const auto& b=teamBarrels_[i];const auto k=at("barrels",i);s.set(k+".id",b.id);s.set(k+".active",b.active);s.set(k+".state",int(b.state));s.set(k+".steel",b.steel);s.set(k+".rescues_partner",b.rescuesPartner);vec(s,k+".position",b.pos);vec(s,k+".velocity",b.velocity);s.set(k+".remainder",b.remainder);s.set(k+".age",b.age);s.set(k+".terrain_flags",b.terrainFlags);s.set(k+".ricochets",b.ricochets);s.set(k+".steel_oam",b.steelOam);s.set(k+".steel_target",b.steelTarget);}
 for(size_t i=0;i<barrelCannons_.size();++i){const auto& b=barrelCannons_[i];const auto k=at("cannons",i);s.set(k+".type",b.placementType);s.set(k+".role",int(b.role));vec(s,k+".position",b.pos);s.set(k+".hidden",b.hidden);s.set(k+".revealed",b.revealed);anim(s,k+".animation",b.animator);}
 for(size_t i=0;i<barrelRespawners_.size();++i){const auto& b=barrelRespawners_[i];const auto k=at("respawners",i);vec(s,k+".feet",b.feet);s.set(k+".type",b.type);s.set(k+".timer",b.timer);s.set(k+".spacing",b.spacing);s.set(k+".current",b.current);s.set(k+".initialized",b.initialized);s.set(k+".remainder",b.remainder);s.set(k+".spawns",b.spawns);}
 for(size_t i=0;i<romTriggers_.size();++i){const auto& t=romTriggers_[i];const auto k=at("triggers",i);rect(s,k+".bounds",t.bounds);s.set(k+".address",t.address);s.set(k+".command",t.command);s.set(k+".state",t.state);s.set(k+".reward",t.reward);s.set(k+".activated",t.activated);}
 for(size_t i=0;i<romControls_.size();++i){const auto& c=romControls_[i];const auto k=at("controls",i);vec(s,k+".anchor",c.anchor);s.set(k+".timer",c.timer);s.set(k+".active",c.active);s.set(k+".activations",c.activations);s.set(k+".remainder",c.remainder);}
 for(size_t i=0;i<koins_.size();++i){const auto& c=koins_[i];const auto k=at("koins",i);vec(s,k+".feet",c.feet);vec(s,k+".coin_position",c.coinPos);s.set(k+".facing_right",c.facingRight);s.set(k+".graphic",c.graphic);s.set(k+".animation",c.animation);s.set(k+".defeated",c.defeated);s.set(k+".coin_collected",c.coinCollected);s.set(k+".defeat_time",c.defeatTime);s.set(k+".guarded_hits",c.guardedHits);}
 s.set("objects.animal.active",animal_.active);s.set("objects.animal.mounted",animal_.mounted);s.set("objects.animal.type",animal_.type);s.set("objects.animal.walking",animal_.walking);playerState(s,"objects.animal.body",animal_.body);anim(s,"objects.animal.animation",animal_.animator);
 for(size_t i=0;i<animalBoxes_.size();++i){const auto& b=animalBoxes_[i];const auto k=at("animal_boxes",i);s.set(k+".state",int(b.lifecycle.state));s.set(k+".delay",b.lifecycle.delay);s.set(k+".duplicate",b.lifecycle.duplicate);s.set(k+".remainder",b.remainder);s.set(k+".opened_at",b.openedAt);}
 for(size_t i=0;i<animalSigns_.size();++i)s.set(at("animal_signs",i)+".awarded",animalSigns_[i].awarded);
 for(size_t i=0;i<levers_.size();++i){const auto& l=levers_[i];const auto k=at("levers",i);s.set(k+".id",l.id);s.set(k+".progress",l.progress);s.set(k+".activated",l.activated);}
 for(size_t i=0;i<gates_.size();++i)s.set(at("gates",i)+".open",gates_[i].open);
 s.set("world.solids.count",world_.solids.size());for(size_t i=0;i<world_.solids.size();++i)rect(s,"world.solids."+std::to_string(i),world_.solids[i]);
 const auto& placements=romSpawnRuntime_.records();s.set("placements.count",placements.size());
 for(size_t i=0;i<placements.size();++i){const auto& p=placements[i].placement;const auto k="placements."+std::to_string(i);s.set(k+".x",p.x);s.set(k+".y",p.y);s.set(k+".type",p.type);s.set(k+".sprite_id",p.spriteId);s.set(k+".parameter",p.parameter);s.set(k+".support",int(placements[i].definition.support));}
}
void GameSession::appendTraceState(TraceState& state)const{
 game_.appendTraceState(state);state.set("session.level",currentLevel_);state.set("session.transitions",transitions_);state.set("session.exit_pending",exitPending_);state.set("session.auto_transitions",autoTransitions_);
}
}
