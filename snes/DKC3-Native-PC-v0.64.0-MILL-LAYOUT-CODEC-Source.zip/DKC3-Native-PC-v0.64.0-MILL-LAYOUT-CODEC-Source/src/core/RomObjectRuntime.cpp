#include "RomObjectRuntime.h"
#include <sstream>
#include <iomanip>
namespace dkc3 {
namespace {
constexpr RomObjectDefinition definitions[]={
  {0x0160,RomObjectBehavior::LevelTrigger,RomSupport::Partial,"Level byte trigger","ROM clipping and byte operation; carried/thrown contact; original Kong state $4F and RAM consumers pending"},
  {0x0138,RomObjectBehavior::DespawnControl,RomSupport::Partial,"Despawn-only control","ROM timer arithmetic; host camera window and reactivation; original group/placement tables pending"},
  {0x0190,RomObjectBehavior::KoinController,RomSupport::Partial,"Koin and DK Coin controller","ROM steel-hit predicate, aim graphics and two-bit progress; host contact, coin flight and turn timing"},
  {0x0250,RomObjectBehavior::AnimalBox,RomSupport::Partial,"Animal box","Ellie break/delayed spawn/mount; host collision; other animal boxes pending"},
  {0x0258,RomObjectBehavior::NoAnimalSign,RomSupport::Partial,"No animal sign","ROM contact and reward; Ellie removal; Enguarde runtime pending"},
  {0x0434,RomObjectBehavior::BootyBird,RomSupport::Partial,"Booty Bird","ROM graphics and reward selection; host patrol and collision; original death and reward flight pending"},
  {0x02c4,RomObjectBehavior::TeamBarrel,RomSupport::Partial,"Floating DK Barrel","Native carry/throw/break/rescue; floating original states pending"},
  {0x02c0,RomObjectBehavior::CarryBarrel,RomSupport::Partial,"Barrel","Native carry/throw/break; original rolling and bounce states pending"},
  {0x028c,RomObjectBehavior::BonusCoin,RomSupport::Partial,"Bonus coin","Target-gated pickup and one-time reward; original object state machine pending"},
  {0x0154,RomObjectBehavior::GreenBananaSpawner,RomSupport::Partial,"Green banana spawner","Original 15-position ROM table; native lifetime and input-completed bonus"},
  {0x0170,RomObjectBehavior::BarrelRespawner,RomSupport::Partial,"Barrel respawner","ROM child type, spacing and timer; host active window; four-slot pool and original visibility pending"},
  {0x02d4,RomObjectBehavior::SteelKeg,RomSupport::Partial,"Steel keg","ROM graphics, launch, gravity, interpolation, water scaling and ricochet words; host position/collision; riding and full original states pending"},
  {0x02f8,RomObjectBehavior::Sneek,RomSupport::Partial,"Sneek","Host patrol; original AI not complete"},
  {0x02fc,RomObjectBehavior::Buzz,RomSupport::Partial,"Buzz","ROM spawn variants and B6 state dispatch identified; native collision, defeat and movement integration pending",0xB68170u},
  {0x03c8,RomObjectBehavior::Kobble,RomSupport::Partial,"Kobble/Skidda","Pier Kobble only; non-Pier family variant selection pending"},
  {0x0284,RomObjectBehavior::BearCoin,RomSupport::Partial,"Bear coin","Host overlap pickup"},
  {0x0298,RomObjectBehavior::Banana,RomSupport::Partial,"Banana","Host overlap pickup"},
  {0x029c,RomObjectBehavior::LifeBalloon,RomSupport::Partial,"Life balloon","Red variant only; host overlap pickup"},
  {0x0294,RomObjectBehavior::KongLetter,RomSupport::Partial,"KONG letter","Letter selected by original descriptor mask"},
  {0x02bc,RomObjectBehavior::Checkpoint,RomSupport::Partial,"Checkpoint","Host full-height trigger"},
  {0x0124,RomObjectBehavior::EndFlag,RomSupport::Partial,"End flag","Host full-height trigger"},
  {0x02b4,RomObjectBehavior::BarrelCannon,RomSupport::Partial,"Barrel cannon","Lakeside type-specific destinations"},
  {0x038c,RomObjectBehavior::DoorLever,RomSupport::Partial,"Door lever handle","ROM four-state dispatch and authored activation/phase parameters decoded; player interaction/group ownership pending",0xB6923Fu},
  {0x0390,RomObjectBehavior::MetalDoor,RomSupport::Partial,"Lever-controlled metal door","ROM shared-control travel arithmetic decoded; native collision/group lifetime pending",0xB69338u},
  {0x0394,RomObjectBehavior::DoorGear,RomSupport::Partial,"Door gear","ROM two-state dispatch and control-scaled animation word decoded; native rendering/group binding pending",0xB693FFu}
};
}
const RomObjectDefinition& findRomObject(uint16_t spriteId){
  for(const auto& d:definitions)if(d.spriteId==spriteId)return d;
  static constexpr RomObjectDefinition unknown={0xffff,RomObjectBehavior::Unknown,RomSupport::Unknown,"Unimplemented object","Preserved for audit; no gameplay handler",0};
  return unknown;
}
RomObjectBehavior romObjectBehavior(uint16_t spriteId){return findRomObject(spriteId).behavior;}
void RomSpawnRuntime::build(const std::vector<RomLevelPlacement>& placements){
  records_.clear();records_.reserve(placements.size());
  for(size_t i=0;i<placements.size();++i){auto definition=findRomObject(placements[i].spriteId);
    definition.spriteId=placements[i].spriteId;records_.push_back({i,placements[i],definition});}
}
size_t RomSpawnRuntime::count(RomSupport support) const {
  size_t n=0;for(const auto& r:records_)n+=r.definition.support==support;return n;
}
std::string RomSpawnRuntime::report() const {
  std::ostringstream out;
  out<<"placements="<<records_.size()<<" SUPPORTED="<<count(RomSupport::Supported)
     <<" PARTIAL="<<count(RomSupport::Partial)<<" UNKNOWN="<<count(RomSupport::Unknown)<<"\n";
  out<<"index,sprite_id,descriptor,type,parameter,x,y,status,behavior,limitation,rom_handler,animation_id,initial_state,reward,conditional\n";
  for(const auto& r:records_){const auto& p=r.placement;
    out<<std::dec<<r.placementIndex<<",0x"<<std::hex<<p.spriteId<<",0x"<<p.descriptor
       <<",0x"<<p.type<<",0x"<<p.parameter<<std::dec<<","<<p.x<<","<<p.y
       <<","<<romSupportName(r.definition.support)<<","<<r.definition.name<<","<<r.definition.limitation<<",0x"<<std::hex<<r.definition.romHandler<<",0x"<<p.spawn.animationId<<",0x"<<p.spawn.word(0x38)<<",0x"<<p.spawn.word(0x6c)<<std::dec<<","<<p.spawn.conditional<<"\n";}
  return out.str();
}
}
