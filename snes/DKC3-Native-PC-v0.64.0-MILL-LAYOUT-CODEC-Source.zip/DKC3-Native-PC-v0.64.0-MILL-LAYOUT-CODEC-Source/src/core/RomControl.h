#pragma once
#include "RomData.h"
#include "Math.h"
namespace dkc3 {
// BB:DE63 uses M=8: only the addressed byte is written.
uint8_t romTriggerByte(uint8_t previous,uint16_t command);
// BB:AB9A / ABA3: reset high byte from low byte, or subtract $0100.
// true means deletion (borrow), including an offscreen timer of zero.
bool romOffscreenTick(uint16_t& timer,bool onscreen);
bool readRomTriggerBounds(const RomImage&,uint16_t index,Vec2 anchor,Rect& bounds);
bool decodeRomGraphicId(const RomImage&,uint16_t graphic,uint16_t palette,RomSpriteFrame&);
struct RomLevelTrigger { Rect bounds;uint16_t address=0,command=0,state=0,reward=0;bool activated=false; };
struct RomControlObject { Vec2 anchor;uint16_t timer=0;bool active=false;unsigned activations=0;double remainder=0; };
enum class RomKoinHit { Guarded, Defeat, TooHigh };
RomKoinHit romKoinSteelHit(uint16_t kx,uint16_t ky,uint16_t bx,uint16_t by,uint16_t oam,uint16_t terrain,uint16_t animation,uint16_t graphic);
struct RomKoinAimProfile {
  std::array<uint32_t,2> source{};
  std::array<std::array<uint8_t,5>,2> limits{};
  std::array<std::array<uint16_t,5>,2> graphics{};
  bool valid=false;
};
bool loadRomKoinAimProfile(const RomImage&,RomKoinAimProfile&);
uint16_t romKoinAimGraphic(uint16_t dx,uint16_t dy,const RomKoinAimProfile&);

uint8_t romKoinProgress(const std::array<uint8_t,32>&,uint16_t level);
bool setRomKoinProgress(std::array<uint8_t,32>&,uint16_t level,uint8_t state);
bool readRomPlacementType(const RomImage&,uint16_t type,RomSpawnSpec&);
struct RomKoinChildren { RomSpawnSpec koin,coin; };
bool loadRomKoinChildren(const RomImage&,RomKoinChildren&);
}
