#pragma once
#include "NativeSprite.h"
#include <cstddef>
#include <string>
#include <vector>
namespace dkc3 {
struct AnimationFrame {
  NativeSprite sprite;
  float duration = 0.12f;
  int offsetX = 0;
  int offsetY = 0;
};
struct NativeAnimation {
  std::vector<AnimationFrame> frames;
  bool loop = true;
  bool valid() const { return !frames.empty(); }
};
struct AnimationPlayer {
  float time = 0.0f;
  size_t frame = 0;
  bool finished = false;
  void reset(){time=0.0f;frame=0;finished=false;}
  void step(const NativeAnimation& animation,float dt);
  const AnimationFrame* current(const NativeAnimation& animation) const;
};
bool loadNativeAnimation(const std::string& path, NativeAnimation& out);
}
