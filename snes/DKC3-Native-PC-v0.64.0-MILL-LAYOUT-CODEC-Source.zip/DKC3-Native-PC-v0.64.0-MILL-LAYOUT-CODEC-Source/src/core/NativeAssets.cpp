#include "NativeAssets.h"
#include "RomObjectRuntime.h"
#include <bit>
#include <cmath>
#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#endif
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <limits>
#include <type_traits>

namespace dkc3 {
// All scalars use fixed-width little endian encoding, bools use exactly 0/1.
// Container lengths are bounded both by the format cap and remaining payload.
static_assert(sizeof(int)==4,"Native format encodes signed int fields as 32-bit words");
static_assert(sizeof(float)==4&&std::numeric_limits<float>::is_iec559,"Native format requires IEEE 754 binary32");
struct NativeAssetCodec {
  bool reading=false,ok=true;
  size_t cursor=0;
  std::vector<uint8_t> data;
  template<class... T> void fields(T&... v){(value(v),...);}
  template<class T> requires(std::is_integral_v<T> && !std::is_same_v<T,bool>)
  void value(T& v){
    static_assert(sizeof(T)<=8);
    using U=std::make_unsigned_t<T>;
    if(!ok)return;
    if(reading){if(data.size()-cursor<sizeof(T)){ok=false;return;}U u=0;for(size_t i=0;i<sizeof(T);++i)u|=U(data[cursor++])<<(i*8);v=std::bit_cast<T>(u);}
    else {U u=static_cast<U>(v);for(size_t i=0;i<sizeof(T);++i)data.push_back(static_cast<uint8_t>(u>>(i*8)));}
  }
  void value(bool& v){uint8_t x=v?1:0;value(x);if(reading){if(x>1)ok=false;v=x==1;}}
  void value(float& v){auto u=std::bit_cast<uint32_t>(v);value(u);if(reading)v=std::bit_cast<float>(u);}
  void value(std::string& s){uint32_t n=static_cast<uint32_t>(s.size());value(n);if(!ok)return;if(n>4096|| (reading&&n>data.size()-cursor)){ok=false;return;}if(reading)s.resize(n);for(auto& x:s){uint8_t u=static_cast<uint8_t>(x);value(u);if(reading)x=static_cast<char>(u);}}
  template<class T,size_t N> void value(std::array<T,N>& a){for(auto& v:a)value(v);}
  template<class A,class B> void value(std::pair<A,B>& p){fields(p.first,p.second);}
  template<class T> void value(std::vector<T>& a){uint32_t n=static_cast<uint32_t>(a.size());value(n);if(!ok)return;if(n>(std::is_integral_v<T>?16000000u:65536u) || (reading&&n>data.size()-cursor)){ok=false;return;}if(reading)a.resize(n);for(auto& v:a){value(v);if(!ok)return;}}
  template<class T> void value(std::map<uint16_t,T>& m){uint32_t n=static_cast<uint32_t>(m.size());value(n);if(n>512||!ok){ok=false;return;}if(reading){m.clear();for(uint32_t i=0;i<n&&ok;++i){uint16_t k=0;T v{};fields(k,v);if(!m.emplace(k,std::move(v)).second)ok=false;}}else for(auto& [k,v]:m){auto key=k;fields(key,v);}}
  void value(RomInfo& v){uint64_t size=v.size;fields(v.valid,v.path,v.title,v.crc32,size);if(reading)v.size=static_cast<size_t>(size);}
  void value(RomSpriteFrame& v){fields(v.width,v.height,v.anchorX,v.anchorY,v.pixels);if(v.width<0||v.height<0||v.width>1024||v.height>1024||v.pixels.size()!=static_cast<size_t>(v.width)*v.height)ok=false;}
  void value(RomSpawnSpec& v){fields(v.fields,v.written,v.spriteId,v.animationId,v.paletteCommand,v.conditional);}
  void value(RomLevelPlacement& v){fields(v.parameter,v.x,v.y,v.type,v.descriptor,v.spriteId,v.spawn);}
  void value(RomCollisionRect& v){fields(v.x,v.y,v.width,v.height);}
  void value(RomHorizontalRope& v){fields(v.x,v.y,v.width);}
  void value(RomPierTerrain& v){fields(v.level_,v.definitions_,v.attributeTable_,v.columns_);if(reading){RomPierTerrain decoded;if(!decoded.load(v.level_,v.definitions_,v.attributeTable_,v.columns_))ok=false;else v=std::move(decoded);}}
  void value(RomLevelRequest& v){fields(v.originalLevelId,v.sharedData,v.submap);}
  void value(RomFrontendVisuals& v){fields(v.valid_,v.info_,v.title_,v.fileSelect_);if(!v.valid_||v.title_.size()!=256*224||v.fileSelect_.size()!=256*224)ok=false;}
  void value(RomWorldMapVisuals& v){fields(v.valid_,v.info_,v.width_,v.height_,v.map_,v.landMask_,v.boatFrames_);if(!v.valid_||v.width_!=512||v.height_!=512||v.map_.size()!=512*512||v.landMask_.size()!=v.map_.size())ok=false;}
  void value(RomLakeOrangatangaVisuals& v){fields(v.valid_,v.info_,v.map_,v.collision_,v.dixieWalkFrames_);if(!v.valid_||v.map_.size()!=256*224)ok=false;}
  void value(RomLevelRuntime& v){
    fields(v.request_,v.startPoint_,v.checkpointPoint_,v.valid_,v.info_,v.width_,v.height_,v.terrain_,v.waterSurfaceY_,v.collisionRects_,v.groundSpans_,v.waterGaps_,v.pixels_,v.foregroundMask_,v.placements_,v.kobbleWalkFrames_,v.bananaSpinFrames_,v.bearCoinFrames_,v.lifeBalloonFrames_,v.barrelCannonFrames_,v.barrelCannonAutoFrames_,v.kongLetterFrames_);
    if(!v.valid_||v.width_<=0||v.width_>16384||v.height_!=512||v.pixels_.size()!=static_cast<size_t>(v.width_)*v.height_||v.foregroundMask_.size()!=v.pixels_.size()||v.waterSurfaceY_<0||v.waterSurfaceY_>=v.height_)ok=false;
    if(reading){v.placementData_.clear();for(auto& p:v.placements_)for(uint16_t x:{p.parameter,p.x,p.y,p.type}){v.placementData_.push_back(x&255);v.placementData_.push_back(x>>8);}v.placementData_.insert(v.placementData_.end(),{0,0});}
  }
  void value(RomLakesideBonusVisuals& v){fields(v.terrain_,v.startPoint_,v.checkpointPoint_,v.valid_,v.bonusIndex_,v.width_,v.height_,v.pixels_,v.foregroundMask_,v.collisionRects_,v.placements_,v.starFrames_,v.greenBananaFrames_,v.bonusCoinFrames_,v.starPositions_,v.greenBananaPositions_);if(!v.valid_||v.bonusIndex_<1||v.bonusIndex_>2||v.width_<=0||v.width_>16384||v.height_!=512||v.pixels_.size()!=static_cast<size_t>(v.width_)*v.height_||v.foregroundMask_.size()!=v.pixels_.size())ok=false;}
  void value(RomMotionProfile& v){fields(v.valid,v.sourceAddress,v.terrainLandingSpeeds,v.risingGravity,v.fallingGravity,v.terminalSpeed,v.jumpImpulse,v.walkSpeed,v.runSpeed,v.swimGravity,v.swimTerminalSpeed,v.groundInterpolation,v.airInterpolation);if(!v.valid)ok=false;}
  void value(RomEllieVisuals& v){fields(v.idle,v.walk,v.box,v.openBox,v.sign,v.enguardeSign);}
  void value(RomObjectReward& v){fields(v.palette,v.animation,v.placementType);}
  void value(RomKoinChildren& v){fields(v.koin,v.coin);}
  void value(RomKoinAimProfile& v){fields(v.source,v.limits,v.graphics,v.valid);if(!v.valid)ok=false;}
  void value(RomSteelProfile& v){fields(v.valid,v.source,v.gravity,v.terminal,v.interpolation);}
  void value(Rect& v){fields(v.x,v.y,v.w,v.h);}
  void value(NativePlacementAssets& v){fields(v.triggerBounds,v.child,v.steel);}
  void value(NativeRuntimeAssets& v){fields(v.source,v.frontend,v.worldMap,v.lakeMap,v.levels,v.placementStreams,v.bonuses,v.dixie,v.kiddy,v.ellieDixie,v.ellieKiddy,v.ellie,v.bird,v.rewards,v.koinChildren,v.koinAim,v.graphics,v.placementAssets);}
};
namespace {
uint32_t checksum(const std::vector<uint8_t>& data){uint32_t c=0xffffffff;for(auto x:data){c^=x;for(int b=0;b<8;++b)c=(c>>1)^(0xedb88320u&(~(c&1u)+1u));}return c^0xffffffff;}
bool validBundle(const NativeRuntimeAssets& a){
  if(a.bird.size()!=8||a.ellie.idle.size()!=4||a.ellie.walk.size()!=14)return false;
  if(!a.source.valid||a.source.size!=4194304||a.source.crc32!=0x448eec19u||a.levels.size()!=6||a.placementStreams.size()!=7||a.placementAssets.size()!=6||a.graphics.size()!=28)return false;
  for(uint16_t id:{0x25,0x27,0x50,0x51,0x54,0x55}){auto l=a.levels.find(id);auto p=a.placementAssets.find(id);auto s=a.placementStreams.find(id);if(l==a.levels.end()||p==a.placementAssets.end()||s==a.placementStreams.end()||l->second.request().originalLevelId!=id||p->second.size()!=l->second.placements().size()||s->second.size()!=l->second.placements().size())return false;}
  auto doorstop=a.placementStreams.find(0x28);if(doorstop==a.placementStreams.end()||doorstop->second.size()!=118)return false;
  for(const auto& [id,l]:a.levels)if(l.kobbleWalkFrames().size()!=8||l.bananaSpinFrames().size()!=8||l.bearCoinFrames().size()!=8||l.lifeBalloonFrames().size()!=8||l.kongLetterFrames().size()!=4||l.barrelCannonFrames().size()!=16||l.barrelCannonAutoFrames().size()!=16)return false;
  for(uint16_t id:{0x2dfa,0x2e3b,0x2431})if(!a.graphics.count(id))return false;
  for(uint16_t id=0x2dcd;id<=0x2df5;id+=5)for(uint16_t key:{id,uint16_t(id+0x2d),uint16_t(id+0x64)})if(!a.graphics.count(key))return false;
  for(const auto& [id,level]:a.levels){const auto& extras=a.placementAssets.at(id);for(size_t i=0;i<extras.size();++i){const auto kind=romObjectBehavior(level.placements()[i].spriteId);const auto& e=extras[i];
    if((kind==RomObjectBehavior::SteelKeg||kind==RomObjectBehavior::BarrelRespawner)&&(!e.steel.valid||!e.steel.gravity||!e.steel.terminal))return false;
    if(kind==RomObjectBehavior::BarrelRespawner&&e.child.spriteId!=0x2d4)return false;
    if(kind==RomObjectBehavior::LevelTrigger&&(!std::isfinite(e.triggerBounds.x)||!std::isfinite(e.triggerBounds.y)||!std::isfinite(e.triggerBounds.w)||!std::isfinite(e.triggerBounds.h)||!(e.triggerBounds.w>0)||!(e.triggerBounds.h>0)))return false;
  }}
  return a.bonuses[0].bonusIndex()==1&&a.bonuses[1].bonusIndex()==2&&a.bonuses[0].starPositions().size()==50&&a.bonuses[1].greenBananaPositions().size()==15;
}
}

bool extractNativeAssets(const std::string& path,NativeRuntimeAssets& out,std::string& error){
  NativeRuntimeAssets a;RomImage rom;
  if(!rom.load(path)||!rom.info().valid||rom.info().crc32!=0x448eec19u){error="Extraction requires reviewed ROM CRC32 448eec19";return false;}a.source=rom.info();
  if(!a.frontend.load(path)||!a.worldMap.load(path)||!a.lakeMap.load(path)||!a.levels[0x25].load(RomLevelRequest{0x25,0x19f0,0},path)||!a.levels[0x27].load(RomLevelRequest{0x27,0x19f0,2},path)||!a.bonuses[0].load(1,path)||!a.bonuses[1].load(2,path)||!loadRomMotionProfiles(path,a.dixie,a.kiddy)||!loadRomEllieMotion(rom,a.dixie,a.ellieDixie)||!loadRomEllieMotion(rom,a.kiddy,a.ellieKiddy)||!loadRomEllieVisuals(rom,a.ellie)||!loadRomBootyBirdFrames(rom,a.bird)||!loadRomKoinChildren(rom,a.koinChildren)||!loadRomKoinAimProfile(rom,a.koinAim)){error="Existing semantic decoder rejected content";return false;}
  for(const auto request : {RomLevelRequest{0x50,0x19f0,3},RomLevelRequest{0x51,0x19f0,4},RomLevelRequest{0x54,0x19f0,5},RomLevelRequest{0x55,0x19f0,6}})
    if(!a.levels[request.originalLevelId].load(request,path)){error="Existing bonus room decoder rejected content";return false;}
  for(const auto& [id,level]:a.levels)a.placementStreams[id]=level.placements();
  if(!decodeRomLevelPlacements(rom,0x28,a.placementStreams[0x28])||a.placementStreams[0x28].size()!=118){error="Doorstop placement decoder rejected content";return false;}
  for(uint16_t i=0;i<19;++i)if(!readRomObjectReward(rom,i,a.rewards[i])){error="Reward decoder failed";return false;}
  auto graphic=[&](uint16_t id,uint16_t palette){return decodeRomGraphicId(rom,id,palette,a.graphics[id]);};
  if(!graphic(0x2dfa,0x23)||!graphic(0x2e3b,0x23)||!graphic(0x2431,0x1d)){error="Common graphics decoder failed";return false;}
  for(uint16_t id=0x2dcd;id<=0x2df5;id+=5)if(!graphic(id,0x57)||!graphic(id+0x2d,0x23)||!graphic(id+0x64,0x23)){error="Koin pose decoder failed";return false;}
  for(auto& [id,level]:a.levels){auto& extras=a.placementAssets[id];extras.resize(level.placements().size());for(size_t i=0;i<extras.size();++i){auto& p=level.placements()[i];auto& e=extras[i];switch(romObjectBehavior(p.spriteId)){
    case RomObjectBehavior::LevelTrigger:if(!readRomTriggerBounds(rom,p.spawn.word(0x5c),{float(int(p.x)-256),float(int(p.y)-256)},e.triggerBounds)){error="Trigger decoder failed";return false;}break;
    case RomObjectBehavior::SteelKeg:if(!loadRomSteelProfile(rom,p.spawn,e.steel)){error="Steel decoder failed";return false;}break;
    case RomObjectBehavior::BarrelRespawner:if(!readRomPlacementType(rom,p.spawn.word(0x6c),e.child)||e.child.spriteId!=0x2d4||!loadRomSteelProfile(rom,e.child,e.steel)){error="Respawner decoder failed";return false;}break;
    default:break;
  }}}
  if(!validBundle(a)){error="Decoded package invariant failed";return false;}out=std::move(a);error.clear();return true;
}
bool writeNativeAssets(const std::string& path,const NativeRuntimeAssets& assets,std::string& error){
  if(!validBundle(assets)){error="Invalid semantic bundle";return false;}
  NativeAssetCodec payload;auto copy=assets;payload.value(copy);if(!payload.ok){error="Semantic serialization rejected fields";return false;}
  NativeAssetCodec header;std::string magic="DKC3NATIVE";uint32_t version=2;uint64_t length=payload.data.size();uint32_t crc=checksum(payload.data);header.fields(magic,version,length,crc);
  auto temp=path+".tmp";std::error_code ec;auto parent=std::filesystem::path(path).parent_path();if(!parent.empty())std::filesystem::create_directories(parent,ec);if(ec){error=ec.message();return false;}
  std::ofstream f(temp,std::ios::binary|std::ios::trunc);f.write(reinterpret_cast<const char*>(header.data.data()),header.data.size());f.write(reinterpret_cast<const char*>(payload.data.data()),payload.data.size());f.close();if(!f){error="Asset write failed";std::filesystem::remove(temp,ec);return false;}
  #ifdef _WIN32
  if(!MoveFileExA(temp.c_str(),path.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH))ec=std::error_code(GetLastError(),std::system_category());
#else
  std::filesystem::rename(temp,path,ec);
#endif
  if(ec){error="Atomic asset replacement failed: "+ec.message();std::filesystem::remove(temp,ec);return false;}error.clear();return true;
}
bool readNativeAssets(const std::string& path,NativeRuntimeAssets& out,std::string& error){
  std::ifstream f(path,std::ios::binary|std::ios::ate);if(!f){error="Native assets missing: "+path;return false;}auto size=f.tellg();if(size<29||size>128*1024*1024){error="Native asset size outside format limits";return false;}
  NativeAssetCodec file;file.reading=true;file.data.resize(static_cast<size_t>(size));f.seekg(0);f.read(reinterpret_cast<char*>(file.data.data()),size);if(!f){error="Native asset read failed";return false;}
  std::string magic;uint32_t version=0,crc=0;uint64_t length=0;file.fields(magic,version,length,crc);if(!file.ok||magic!="DKC3NATIVE"||version!=2||length!=file.data.size()-file.cursor){error="Native asset header/version/length invalid";return false;}
  NativeAssetCodec payload;payload.reading=true;payload.data.assign(file.data.begin()+file.cursor,file.data.end());if(checksum(payload.data)!=crc){error="Native asset integrity check failed";return false;}
  NativeRuntimeAssets a;payload.value(a);if(!payload.ok||payload.cursor!=payload.data.size()||!validBundle(a)){error="Native semantic fields invalid";return false;}out=std::move(a);error.clear();return true;
}
std::string nativeAssetPath(){const char* p=std::getenv("DKC3_NATIVE_ASSET_DIR");return (std::filesystem::path(p?p:"assets/native")/"runtime.nassets").string();}
std::string nativeAssetMode(){const char* p=std::getenv("DKC3_ASSET_MODE");return p?p:"auto";}
std::shared_ptr<const NativeRuntimeAssets> runtimeNativeAssets(std::string& error){
  const auto mode=nativeAssetMode(),path=nativeAssetPath();if(mode!="auto"&&mode!="native"&&mode!="rom"){error="Unknown DKC3_ASSET_MODE (expected auto, native, rom)";return {};}
  auto a=std::make_shared<NativeRuntimeAssets>();
  if(mode!="rom"){
    if(readNativeAssets(path,*a,error))return a;
    // A present invalid package fails closed, even in auto mode.
    if(mode=="native"||std::filesystem::exists(path))return {};
  }
  const char* romEnv=std::getenv("DKC3_ROM_PATH");const auto romPath=romEnv?romEnv:"rom/dkc3_ptbr.sfc";
  if(!extractNativeAssets(romPath,*a,error))return {};
  return a;
}
}
