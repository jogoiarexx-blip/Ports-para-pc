#include "NativeReplay.h"
namespace dkc3 {
InputState nativeInputFromSnes(uint32_t m){
 InputState in;in.jump=(m&1u)!=0;in.run=(m&(2u|0x800u))!=0;in.attack=(m&2u)!=0;in.switchCharacter=(m&4u)!=0;
 in.up=(m&16u)!=0;in.down=(m&32u)!=0;in.left=(m&64u)!=0;in.right=(m&128u)!=0;return in;
}
WorldMapInput nativeMapInputFromSnes(uint32_t m){
 const auto in=nativeInputFromSnes(m);WorldMapInput map;
 map.left=in.left;map.right=in.right;map.up=in.up;map.down=in.down;
 map.confirm=(m&9u)!=0;map.cancel=(m&0x104u)!=0;map.fast=(m&0x802u)!=0;return map;
}
bool NativeReplay::load(const std::string& path,std::string& error){
 Dkc3InputPlaybackFree(&playback_);char message[256]{};
 const bool ok=Dkc3InputPlaybackLoad(path.c_str(),&playback_,message,sizeof message)!=0;
 error=ok?"":message;return ok;
}
}
