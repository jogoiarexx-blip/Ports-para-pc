#include "WrinklyCave.h"
#include "Hud.h"
#include <algorithm>
#include <cmath>
namespace dkc3 {
bool WrinklyCave::init(const std::string& directory){
  originalReady_=hdReady_=false;useHd_=true;saveResult_=0;
  wrinklyPlayer_.reset();wrinkly_={};
  if(!loadNativeAnimation("assets/sprites/dkc3/anims/wrinkly-idle.nanim",wrinkly_))return false;
  original_={};hd_={};bool originalOk=true,hdOk=true;
  for(size_t i=0;i<4;++i){
    originalOk=loadBmp32(directory+"/original-"+std::to_string(i)+".bmp",original_[i]) && originalOk;
    hdOk=loadBmp32(directory+"/hd-"+std::to_string(i)+".bmp",hd_[i]) && hdOk;
    if(original_[i].w!=256 || original_[i].h!=224)originalOk=false;
    if(hd_[i].w<256 || hd_[i].h<224)hdOk=false;
  }
  originalReady_=originalOk;hdReady_=hdOk;
  return ready();
}
void WrinklyCave::render(uint32_t* dst,int w,int h) const {
  if(!dst || w<=0 || h<=0)return;
  std::fill(dst,dst+static_cast<size_t>(w)*h,0xff000000u);
  if(!ready())return;
  const auto& frame=hd()?hd_[0]:original_[0];
  if(frame.w==w && frame.h==h)std::copy(frame.bgra.begin(),frame.bgra.end(),dst);
  else for(int y=0;y<h;++y)for(int x=0;x<w;++x){
    if(!hd()){
      const int sx=std::min(frame.w-1,x*frame.w/w),sy=std::min(frame.h-1,y*frame.h/h);
      dst[static_cast<size_t>(y)*w+x]=frame.bgra[static_cast<size_t>(sy)*frame.w+sx]|0xff000000u;
    }else{
      const float sx=std::clamp((x+0.5f)*frame.w/w-0.5f,0.f,static_cast<float>(frame.w-1));
      const float sy=std::clamp((y+0.5f)*frame.h/h-0.5f,0.f,static_cast<float>(frame.h-1));
      const int x0=static_cast<int>(sx),y0=static_cast<int>(sy),x1=std::min(x0+1,frame.w-1),y1=std::min(y0+1,frame.h-1);
      const float fx=sx-x0,fy=sy-y0;uint32_t color=0xff000000u;
      for(int shift=0;shift<=16;shift+=8){
        auto channel=[&](int xx,int yy){return static_cast<float>((frame.bgra[static_cast<size_t>(yy)*frame.w+xx]>>shift)&255u);};
        const float top=channel(x0,y0)*(1-fx)+channel(x1,y0)*fx;
        const float bottom=channel(x0,y1)*(1-fx)+channel(x1,y1)*fx;
        color|=static_cast<uint32_t>(std::lround(top*(1-fy)+bottom*fy))<<shift;
      }
      dst[static_cast<size_t>(y)*w+x]=color;
    }
  }
  if(const auto* npc=wrinklyPlayer_.current(wrinkly_)){
    const auto& sprite=npc->sprite;
    const int left=160-sprite.originX,top=190-sprite.originY;
    for(int sy=0;sy<sprite.height;++sy)for(int sx=0;sx<sprite.width;++sx){
      const uint32_t color=sprite.bgra[static_cast<size_t>(sy)*sprite.width+sx];if(!(color>>24))continue;
      const int x0=(left+sx)*w/256,x1=(left+sx+1)*w/256,y0=(top+sy)*h/224,y1=(top+sy+1)*h/224;
      for(int yy=std::max(0,y0);yy<std::min(h,y1);++yy)for(int xx=std::max(0,x0);xx<std::min(w,x1);++xx)dst[static_cast<size_t>(yy)*w+xx]=color;
    }
  }
  const int scale=std::max(1,std::min(w/256,h/224));
  hudFillRect(dst,w,h,0,0,w,18*scale,0x000000u,170);
  hudDrawText(dst,w,h,6*scale,5*scale,hd()?"WRINKLY - HD":"WRINKLY - ORIGINAL",0xfff6e5b8u,scale);
  hudFillRect(dst,w,h,0,h-34*scale,w,34*scale,0x000000u,205);
  const char* status=saveResult_>0?"PROGRESSO SALVO":(saveResult_<0?"NAO FOI POSSIVEL SALVAR":"ENTER/Z/A SALVAR   X/B VOLTAR");
  hudDrawText(dst,w,h,6*scale,h-29*scale,status,saveResult_<0?0xffffaaaau:0xffffffffu,scale);
  hudDrawText(dst,w,h,6*scale,h-16*scale,"C/Y HD/ORIGINAL  RIP A.J. NITRO",0xffd2dcecu,scale);
}
}
