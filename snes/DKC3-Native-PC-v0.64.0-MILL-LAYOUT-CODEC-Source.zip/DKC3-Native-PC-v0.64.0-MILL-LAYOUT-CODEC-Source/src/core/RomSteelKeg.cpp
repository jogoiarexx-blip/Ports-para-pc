#include "RomSteelKeg.h"
#include "RomData.h"
namespace dkc3 {
bool loadRomSteelProfile(const RomImage& rom,const RomSpawnSpec& spec,RomSteelProfile& out){
 out={};if(spec.spriteId!=0x2d4||spec.word(0x5a)!=0x4f)return false;
 const auto pointer=spec.word(0x06);const size_t address=0x3f0000+pointer;
 const auto& b=rom.bytes();if(pointer<0x40)return false;
 if(address+6>b.size())return false;
 auto word=[&](size_t offset){return uint16_t(b[address+offset]|(uint16_t(b[address+offset+1])<<8));};
 RomSteelProfile p;p.source=0xff0000+pointer;p.gravity=word(0);p.terminal=word(2);p.interpolation=word(4);
 // This native path implements mode 8 only. Fail rather than silently substitute.
 p.valid=p.gravity>0&&p.gravity<0x8000&&p.terminal>0&&p.terminal<0x8000&&p.interpolation==8;
 if(!p.valid)return false;out=p;return true;
}
uint16_t romSteelGravity(uint16_t velocity,const RomSteelProfile& p){
 const uint16_t sum=uint16_t(velocity+p.gravity);
 return (sum&0x8000)||sum<p.terminal?sum:p.terminal;
}
uint16_t romSteelInterpolate(uint16_t velocity,uint16_t target){
 // B9:F4B0 -> mode 8 B9:F54F; N of word difference, two logical shifts.
 const uint16_t difference=uint16_t(target-velocity);const bool negative=(difference&0x8000)!=0;
 const uint16_t magnitude=negative?uint16_t(0u-difference):difference;
 const uint16_t delta=(magnitude>>4)+(magnitude>>6);
 if(!delta)return target;
 return uint16_t(velocity+(negative?-int(delta):int(delta)));
}
RomSteelProbeVelocity romSteelWaterProbe(uint16_t waterY,uint16_t feetY,uint16_t x,uint16_t y){
 if((waterY&0x8000)||uint16_t(waterY+0x10)>=feetY)return {x,y,false};
 // A is ASL'd twice while the memory operand is ROR'd twice. The second
 // carry comes from original bit 14, not a repeated arithmetic sign shift.
 auto rotate=[](uint16_t v){return uint16_t((v>>2)|((v&0x8000)>>1)|((v&0x4000)<<1));};
 return {rotate(x),rotate(y),true};
}

}
