#include "RomControl.h"
#include <algorithm>
namespace dkc3 {
uint8_t romTriggerByte(uint8_t old,uint16_t c){
  const auto mode=static_cast<uint8_t>(c),value=static_cast<uint8_t>(c>>8);
  return mode==0?mode:mode==1?static_cast<uint8_t>(old|value):static_cast<uint8_t>(old^value);
}
bool romOffscreenTick(uint16_t& timer,bool onscreen){
  if(onscreen){if(timer)timer=static_cast<uint16_t>((timer&255)*257);return false;}
  if(timer<0x100)return true;
  timer=static_cast<uint16_t>(timer-0x100);return false;
}
bool readRomTriggerBounds(const RomImage& rom,uint16_t index,Vec2 anchor,Rect& out){
  // BCE:519 indexes eight-byte rectangles at BC:E14B.
  const auto& b=rom.bytes();const size_t p=0x3ce14b+size_t(index)*8;
  if(p+8>b.size())return false;
  auto word=[&](size_t o){return static_cast<int16_t>(b[p+o]|(b[p+o+1]<<8));};
  const int w=word(4),h=word(6);if(w<=0||h<=0)return false;
  out={anchor.x+word(0),anchor.y+word(2),float(w),float(h)};return true;
}
bool decodeRomGraphicId(const RomImage& rom,uint16_t id,uint16_t palette,RomSpriteFrame& out){
  // BC:8000 has five-byte graphic/hitbox entries; graphic IDs are byte offsets.
  const auto& b=rom.bytes();const size_t p=0x3c8000+id;
  if(id%5||p+5>b.size())return false;
  return decodeRomObjectFrame(rom,b[p]|(b[p+1]<<8)|(b[p+2]<<16),palette,out);
}
bool loadRomKoinChildren(const RomImage& rom,RomKoinChildren& out){
  RomKoinChildren decoded;
  if(!decodeRomSpawnScript(rom,0x30cd,decoded.koin)||!decodeRomSpawnScript(rom,0x30f2,decoded.coin)||
     decoded.koin.spriteId!=0x3d0||decoded.coin.spriteId!=0x3d4)return false;
  out=decoded;return true;
}
RomKoinHit romKoinSteelHit(uint16_t kx,uint16_t ky,uint16_t bx,uint16_t by,uint16_t oam,uint16_t terrain,uint16_t animation,uint16_t graphic){
  // B6:A512..A546. The collision caller already established a steel-keg hit.
  if((terrain&0x101)!=0x101&&!(static_cast<uint16_t>(ky-by-0x14)&0x8000))return RomKoinHit::TooHigh;
  const uint16_t side=static_cast<uint16_t>(kx-bx)^oam;
  if(!(side&0x4000))return RomKoinHit::Defeat;
  if(animation==0x211||animation==0x215||graphic<0x2de2)return RomKoinHit::Guarded;
  return RomKoinHit::Defeat;
}
bool loadRomKoinAimProfile(const RomImage& rom,RomKoinAimProfile& out){
  out={};RomKoinAimProfile p;const auto& bytes=rom.bytes();
  // The workbench identifies the actual LDY.w pointer operands in both
  // branches of B6:A6C4. Tables are five {threshold byte, graphic word} rows.
  constexpr size_t operands[]={0x36a6db,0x36a6f3};
  for(unsigned axis=0;axis<2;++axis){
    const size_t at=operands[axis];if(at+3>bytes.size()||bytes[at]!=0xa0)return false;
    const uint16_t pointer=bytes[at+1]|(uint16_t(bytes[at+2])<<8);
    const size_t table=0x360000u+pointer;
    if(pointer<0x8000u||table+15u>bytes.size()||pointer>0xfff1u)return false;
    p.source[axis]=0xb60000u+pointer;
    for(unsigned row=0;row<5;++row){
      const size_t pos=table+row*3;
      p.limits[axis][row]=bytes[pos];p.graphics[axis][row]=bytes[pos+1]|(uint16_t(bytes[pos+2])<<8);
      if((row&&p.limits[axis][row]<=p.limits[axis][row-1])||!p.graphics[axis][row]||p.graphics[axis][row]%5u)return false;
    }
    if(p.limits[axis][4]!=0xff)return false;
  }
  p.valid=true;out=p;return true;
}
uint16_t romKoinAimGraphic(uint16_t dx,uint16_t dy,const RomKoinAimProfile& p){
  if(!p.valid)return 0;
  // B6:A6C4..A716: word XBA dividend, byte divisor, word INC then clamp.
  const bool horizontal=dy<dx;const uint16_t small=horizontal?dy:dx,big=horizontal?dx:dy;
  const uint16_t swapped=static_cast<uint16_t>((small<<8)|(small>>8));
  unsigned ratio=(big&255)?swapped/(big&255):0xffff;
  ratio=std::min(255u,(ratio+1)&0xffffu);
  const unsigned axis=horizontal?0:1;
  for(unsigned i=0;i<5;++i)if(ratio<=p.limits[axis][i])return p.graphics[axis][i];
  return 0; // Invalid profile must never silently substitute a native pose.
}
uint8_t romKoinProgress(const std::array<uint8_t,32>& flags,uint16_t level){
  const uint16_t index=static_cast<uint16_t>(level-0x25);if(index>=128)return 0;
  return (flags[index/4]>>((index&3)*2))&3;
}
bool setRomKoinProgress(std::array<uint8_t,32>& flags,uint16_t level,uint8_t state){
  const uint16_t index=static_cast<uint16_t>(level-0x25);if(index>=128||state>2)return false;
  const unsigned shift=(index&3)*2;auto& byte=flags[index/4];byte=(byte&~(3<<shift))|(state<<shift);return true;
}
bool readRomPlacementType(const RomImage& rom,uint16_t type,RomSpawnSpec& out){
  const auto& b=rom.bytes();const size_t offset=0x3f0040+type;
  if((type&1)||offset+2>b.size())return false;
  return decodeRomSpawnScript(rom,b[offset]|(b[offset+1]<<8),out);
}

}
