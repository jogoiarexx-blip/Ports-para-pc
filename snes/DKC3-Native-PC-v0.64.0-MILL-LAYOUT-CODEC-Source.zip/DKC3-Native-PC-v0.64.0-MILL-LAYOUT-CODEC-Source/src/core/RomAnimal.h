#pragma once
#include "RomData.h"
#include "RomMotion.h"
namespace dkc3 {
enum class RomAnimalBoxState { Closed, Opening, Spent };
struct RomAnimalBoxStateMachine {
  RomAnimalBoxState state=RomAnimalBoxState::Closed;
  int16_t delay=0;bool duplicate=false;
  bool hit(bool animalExists);
  bool tick(); // B8:EF1E: signed DEC; spawn once after 4 -> -1.
};
bool romAnimalSignContact(uint16_t signX,uint16_t signY,uint16_t animalX,uint16_t animalFeet);
struct RomAnimalSignOffset { int x=0,y=0; };
RomAnimalSignOffset romAnimalSignOffset(uint16_t packed,bool facingRight);
bool loadRomEllieMotion(const RomImage& rom,const RomMotionProfile& kong,RomMotionProfile& ellie);
struct RomEllieVisuals { std::vector<RomSpriteFrame> idle,walk;RomSpriteFrame box,openBox,sign,enguardeSign; };
bool loadRomEllieVisuals(const RomImage& rom,RomEllieVisuals& visuals);
}
