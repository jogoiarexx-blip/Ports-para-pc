#pragma once
#include "Math.h"
#include "Input.h"
#include "RomMotion.h"
namespace dkc3 {
class RomPierTerrain;
enum class PlayerMotion { Ground, Air, Hang, Swim };
struct Player {
  Vec2 pos{92,132};
  Vec2 vel{};
  RomMotionProfile nativeMotion{};
  double nativeRemainder=0.0,ropeRemainder=0.0;
  int nativeRope=-1;
  int nativeWaterSurfaceY=0x7fff;
  RomWaterState nativeWaterState=RomWaterState::Dry;
  float ropeRegrabDelay=0.0f;
  bool ropeJumpPending=false;
  unsigned nativeRopeGrabs=0,nativeRopeStops=0;
  bool nativeJumpPending=false;
  uint16_t nativeControlFlags=0;
  uint16_t nativeTerrainFlags=0,nativeTerrainAttributes=0;
  unsigned nativeCeilingHits=0,nativeWallHits=0,nativeAirWallHits=0,nativeGroundFollows=0;
  int16_t nativeHorizontalTarget=0,nativeBlockedTarget=0,nativeBlockedVelocity=0;
  int16_t nativeGravity=0,nativeLandingVelocity=0;
  float width=18, height=34;
  bool grounded=false;
  bool facingRight=true;
  PlayerMotion motion=PlayerMotion::Air;
  // Estado de "feel" (v0.8.0): coyote time, buffer de pulo e pulo de altura variavel.
  float coyoteTimer=0.0f, jumpBuffer=0.0f, jumpTime=0.0f;
  bool jumpWasDown=false, jumping=false, justJumped=false;
  Rect bounds() const { return {pos.x,pos.y,width,height}; }
};
void updatePlayer(Player& p, const InputState& in, float dt, const Rect* solids, int solidCount, const Rect* platforms=nullptr, int platformCount=0, const RomPierTerrain* terrain=nullptr);
void updateRomRopePlayer(Player& p,const InputState& in,float dt,const RomPierTerrain& terrain);
void updateSwimPlayer(Player& p, const InputState& in, float dt, const Rect* solids, int solidCount, Vec2 current = {}, const Rect* platforms=nullptr, int platformCount=0);
}
