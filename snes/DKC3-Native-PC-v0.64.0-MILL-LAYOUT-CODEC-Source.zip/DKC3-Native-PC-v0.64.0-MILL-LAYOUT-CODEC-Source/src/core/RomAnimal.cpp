#include "RomAnimal.h"
namespace dkc3 {
bool RomAnimalBoxStateMachine::hit(bool exists){
  if(state!=RomAnimalBoxState::Closed)return false;
  state=RomAnimalBoxState::Opening;delay=4;duplicate=exists;return true;
}
bool RomAnimalBoxStateMachine::tick(){
  if(state!=RomAnimalBoxState::Opening)return false;
  if(--delay>=0)return false;
  state=RomAnimalBoxState::Spent;return !duplicate;
}
bool romAnimalSignContact(uint16_t sx,uint16_t sy,uint16_t ax,uint16_t feet){
  if(static_cast<uint16_t>(sy+8u-feet)&0x8000u)return false;
  return static_cast<uint16_t>(sx-ax+16u)<32u;
}
RomAnimalSignOffset romAnimalSignOffset(uint16_t packed,bool right){
  const int x=static_cast<int8_t>(packed&255),y=static_cast<int8_t>(packed>>8);
  return {right?x:-x,y};
}
bool loadRomEllieMotion(const RomImage& rom,const RomMotionProfile& kong,RomMotionProfile& ellie){
  ellie={};if(!kong.valid||kong.sourceAddress<0xff0000)return false;
  const auto& b=rom.bytes();const size_t base=kong.sourceAddress&0x3fffff;
  if(base+0x2ea>b.size())return false;
  auto word=[&](size_t off){return static_cast<int16_t>(b[base+off]|(b[base+off+1]<<8));};
  ellie=kong;
  // B8:9071, D4DB and D509 index by animal type $0234.
  ellie.jumpImpulse=static_cast<int16_t>(word((0x234-0xe0)*2)+0x100);
  ellie.walkSpeed=word((0x234-0xd0)*2);ellie.runSpeed=word((0x234-0xc0)*2);
  if(ellie.jumpImpulse>=0||ellie.walkSpeed<=0||ellie.runSpeed<ellie.walkSpeed){ellie={};return false;}
  return true;
}
bool loadRomEllieVisuals(const RomImage& rom,RomEllieVisuals& v){
  RomEllieVisuals decoded;
  for(auto a:{0xcecb71,0xcecf13,0xced299,0xced641}){RomSpriteFrame f;if(!decodeRomObjectFrame(rom,a,0x16,f))return false;decoded.idle.push_back(std::move(f));}
  for(auto a:{0xced9c7,0xceddeb,0xcee1d1,0xcee5fb,0xcee9bf,0xceedc7,0xcef1cf,0xcef5b5,0xcef93b,0xcf40f6,0xcf44dc,0xcf487e,0xcf4c64,0xcf5028}){RomSpriteFrame f;if(!decodeRomObjectFrame(rom,a,0x16,f))return false;decoded.walk.push_back(std::move(f));}
  if(!decodeRomObjectFrame(rom,0xd12691,0x1c,decoded.box)||
     !decodeRomObjectFrame(rom,0xd12273,0x1c,decoded.openBox)||
     !decodeRomObjectFrame(rom,0xd1371d,0x10,decoded.sign)||
     !decodeRomObjectFrame(rom,0xd13a3d,0x10,decoded.enguardeSign))return false;
  v=std::move(decoded);return true;
}
}
