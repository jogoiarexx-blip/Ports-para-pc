#include "NativeTrace.h"
#include <bit>
#include <cmath>
#include <iomanip>
#include <sstream>
#include <stdexcept>
namespace dkc3 {
namespace {
thread_local TraceRecorder* current=nullptr;
std::string hex(uint64_t value,int width){std::ostringstream o;o<<std::hex<<std::setfill('0')<<std::setw(width)<<value;return o.str();}
std::string value(const std::optional<std::string>& v){return v?*v:"<unavailable>";}
}
void TraceState::set(const std::string& key,float v){if(!std::isfinite(v))throw std::invalid_argument("nonfinite trace state: "+key);fields[key]="f32:"+hex(std::bit_cast<uint32_t>(v),8);}
void TraceState::set(const std::string& key,double v){if(!std::isfinite(v))throw std::invalid_argument("nonfinite trace state: "+key);fields[key]="f64:"+hex(std::bit_cast<uint64_t>(v),16);}
std::string TraceState::hash()const{
 uint64_t h=14695981039346656037ull;
 auto add=[&](std::string_view s){for(unsigned char c:s){h^=c;h*=1099511628211ull;}h*=1099511628211ull;};
 for(const auto& [key,v]:fields){add(key);add(value(v));}return hex(h,16);
}
std::string traceJsonString(std::string_view s){
 std::string r="\"";for(unsigned char c:s){switch(c){case '"':r+="\\\"";break;case '\\':r+="\\\\";break;case '\n':r+="\\n";break;case '\r':r+="\\r";break;case '\t':r+="\\t";break;default:if(c<32)r+="\\u00"+hex(c,2);else r+=char(c);}}return r+'"';
}
TraceRecorder::~TraceRecorder(){if(current==this)current=nullptr;}
void TraceRecorder::beginFrame(uint64_t frame,uint32_t input){
 if(current||active_)throw std::logic_error("nested trace frame");
 frame_=frame;input_=input;totalCalls_=0;calls_.clear();active_=true;current=this;
}
void TraceRecorder::record(const char* fn,uint32_t pc){
 NativeTraceCall c{fn,pc,totalCalls_++};if(calls_.size()<64)calls_.push_back(std::move(c));else calls_[c.sequence%64]=std::move(c);
}
void recordNativeCall(const char* fn,uint32_t sourcePc){if(current)current->record(fn,sourcePc);}
bool TraceRecorder::endFrame(const TraceState& state,const std::vector<NativeTraceEvent>& events,const TraceMetrics& metrics){
 if(!active_||current!=this)throw std::logic_error("trace frame not active");
 current=nullptr;active_=false;
 out_<<"{\"schema\":\"dkc3.trace.v1\",\"provenance\":\"native-runtime\",\"frame\":"<<frame_<<",\"input\":"<<input_<<",\"state_hash\":"<<traceJsonString(state.hash())<<",\"state\":{";
 bool first=true;for(const auto& [k,v]:state.fields){if(!first)out_<<',';first=false;out_<<traceJsonString(k)<<':'<<(v?traceJsonString(*v):"null");}
 out_<<"},\"calls\":[";
 for(size_t i=0;i<calls_.size();++i){if(i)out_<<',';const auto& c=calls_[(i+(totalCalls_>64?totalCalls_%64:0))%calls_.size()];
  out_<<"{\"function\":"<<traceJsonString(c.function)<<",\"kind\":\"native\",\"pc\":null,\"opcode\":null,\"bank\":null,\"source_pc\":";
  if(c.sourcePc)out_<<c.sourcePc;else out_<<"null";
  out_<<",\"sequence\":"<<c.sequence<<",\"rom_reads\":[]}";
 }
 out_<<"],\"events\":[";first=true;for(const auto& e:events){if(!first)out_<<',';first=false;out_<<"{\"type\":"<<traceJsonString(e.type)<<",\"key\":"<<traceJsonString(e.key)<<",\"before\":"<<traceJsonString(e.before)<<",\"after\":"<<traceJsonString(e.after)<<'}';}
 out_<<"],\"metrics\":{\"native_calls\":"<<totalCalls_<<",\"calls_dropped\":"<<(totalCalls_>64?totalCalls_-64:0);
 for(const auto& [k,v]:metrics){out_<<','<<traceJsonString(k)<<':';if(v)out_<<*v;else out_<<"null";}
 out_<<"}}\n";return bool(out_);
}
std::vector<NativeTraceEvent> traceStateEvents(const TraceState* prev,const TraceState& next){
 std::vector<NativeTraceEvent> events;
 for(const auto& [k,v]:next.fields){auto old=prev?prev->fields.find(k):next.fields.end();bool found=prev&&old!=prev->fields.end();if(found&&old->second==v)continue;
  std::string type;
  if(k=="session.level")type="level_change";
  else if(k=="camera.x"||k=="camera.y")type="camera_change";
  else if(k.ends_with(".active"))type=v&&*v=="1"?"spawn":"despawn";
  else if(k.starts_with("ram."))type="ram_write";
  else if(k=="game.in_bonus")type="bonus_transition";
  if(!type.empty())events.push_back({type,k,found?value(old->second):"<absent>",value(v)});
 }
 if(prev)for(const auto& [k,v]:prev->fields)if(k.ends_with(".active")&&!next.fields.contains(k))events.push_back({"despawn",k,value(v),"<absent>"});
 return events;
}
}
