#include "RomDoorstop.h"

namespace dkc3 {
namespace {
uint8_t low(uint16_t v){return static_cast<uint8_t>(v&0xffu);}
}

bool loadRomBuzzProfile(const RomLevelPlacement& p,RomBuzzProfile& out){
  if(p.spriteId!=0x02fcu || (p.spawn.animationId!=0x0139u&&p.spawn.animationId!=0x013bu))return false;
  RomBuzzProfile v;
  v.animationId=p.spawn.animationId;
  v.renderFlags=p.spawn.word(0x1e);
  v.movementFlags=p.spawn.word(0x06);
  v.movementWord60=p.spawn.word(0x60);
  v.movementWord64=p.spawn.word(0x64);
  v.variant=low(p.spawn.word(0x5a));
  if(v.variant!=5u&&v.variant!=6u)return false;
  out=v;return true;
}

bool loadRomDoorLeverProfile(const RomLevelPlacement& p,RomDoorLeverProfile& out){
  if(p.spriteId!=0x038cu||p.spawn.animationId!=0x019du||p.spawn.word(0x38)!=3u)return false;
  RomDoorLeverProfile v;
  v.animationId=p.spawn.animationId;v.renderFlags=p.spawn.word(0x1e);v.initialState=p.spawn.word(0x38);
  v.activationStep=low(p.spawn.word(0x60));v.phaseStep=low(p.spawn.word(0x66));v.phaseOrigin=low(p.spawn.word(0x68));
  if(v.activationStep!=4u||v.phaseStep==0u)return false;
  out=v;return true;
}

bool loadRomMetalDoorProfile(const RomLevelPlacement& p,RomMetalDoorProfile& out){
  if(p.spriteId!=0x0390u||p.spawn.animationId!=0x019cu)return false;
  RomMetalDoorProfile v;
  v.animationId=p.spawn.animationId;v.renderFlags=p.spawn.word(0x1e);
  v.travel=low(p.spawn.word(0x5e));v.closeStep=low(p.spawn.word(0x62));v.phaseStep=low(p.spawn.word(0x64));
  if(v.travel!=0x40u||v.closeStep!=1u||v.phaseStep==0u)return false;
  out=v;return true;
}

bool loadRomDoorGearProfile(const RomLevelPlacement& p,RomDoorGearProfile& out){
  if(p.spriteId!=0x0394u||p.spawn.animationId!=0x019bu)return false;
  out={p.spawn.animationId,p.spawn.word(0x1e)};return true;
}

uint8_t romDoorScaledOffset(uint8_t distance,uint8_t control){
  return static_cast<uint8_t>((static_cast<uint16_t>(distance)*control)>>8);
}
uint16_t romDoorY(uint16_t baseY,uint8_t travel,uint8_t control){
  return static_cast<uint16_t>(baseY-romDoorScaledOffset(travel,control));
}
uint16_t romDoorLeverAxis(uint16_t base,uint8_t phase,uint8_t control){
  return static_cast<uint16_t>(base+romDoorScaledOffset(phase,control));
}
uint16_t romDoorGearMotion(uint8_t control){return static_cast<uint16_t>(0x40u*control);}

}
