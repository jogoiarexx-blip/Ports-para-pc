#pragma once
#include "NativeSprite.h"
#include <cstdint>
#include <span>
#include <string>
#include <vector>
namespace dkc3 {
struct NativeTileSet { int bpp=0; uint32_t tileCount=0; std::vector<uint8_t> pixels; };
struct NativeTileMap { int width=0,height=0; std::vector<uint16_t> entries; };
// Empty masks allow all pixels; nonempty masks reject zero/outside pixels.
struct NativePixelMask { int width=0,height=0; std::vector<uint8_t> pixels; };
struct NativeScanlineOffset { int x=0,y=0; };
struct NativeLayer {
  std::string name; int bpp=0; int scrollX=0,scrollY=0; bool enabled=false;
  NativeTileSet tiles; NativeTileMap map;
  int parallaxX256=256,parallaxY256=256;
  std::vector<NativeScanlineOffset> scanlineOffsets;
  NativePixelMask mainMask,subMask;
};
struct NativeSceneSprite {
  NativeSprite sprite; int x=0,y=0; uint8_t priority=0;
  bool enabled=true,flipX=false,flipY=false,colorMath=false;
  NativePixelMask mainMask,subMask;
};
struct NativeScene {
  int mode=1; bool bg3Priority=false; uint8_t tm=0,ts=0,cgwsel=0,cgadsub=0;
  uint16_t fixedColor=0; int brightness=15; int viewportW=256,viewportH=224; int backdrop=0;
  std::vector<uint16_t> palette; std::vector<NativeLayer> layers;
  std::vector<NativeSceneSprite> sprites;
  NativePixelMask colorMathMask;
  std::vector<uint16_t> fixedColorRows;
};
bool loadNativeScene(const std::string& path,NativeScene& out);
bool validateNativeScene(const NativeScene& s,std::string* error=nullptr);
bool setPalette(NativeScene& s,size_t first,std::span<const uint16_t> colors);
bool updateTilemap(NativeScene& s,size_t layer,int x,int y,int width,int height,std::span<const uint16_t> entries);
bool updateTiles(NativeScene& s,size_t layer,uint32_t firstTile,std::span<const uint8_t> pixels);
bool setLayerScroll(NativeScene& s,size_t layer,int x,int y);
bool setLayerParallax(NativeScene& s,size_t layer,int x256,int y256);
bool updateScanlineOffsets(NativeScene& s,size_t layer,std::span<const NativeScanlineOffset> rows);
bool updateGradient(NativeScene& s,std::span<const uint16_t> fixedColorRows);
// Rejects unsupported/malformed input without touching dst.
bool renderNativeSceneChecked(const NativeScene& s,uint32_t* dst,int w,int h,int cameraX=0,int cameraY=0,std::string* error=nullptr);
void renderNativeScene(const NativeScene& s,uint32_t* dst,int w,int h,int cameraX=0,int cameraY=0);
uint64_t hashFrame(const uint32_t* pixels,size_t count);
}
