#pragma once
#include "Animation.h"
#include <map>
#include <string>
namespace dkc3 {
class SuppliedSprites {
 public:
  bool load(const std::string& directory="assets/sprites/dkc3");
  const NativeAnimation* animation(const std::string& name) const;
  const std::map<std::string,NativeAnimation>& animations() const { return animations_; }
 private:
  std::map<std::string,NativeAnimation> animations_;
};
}
