#pragma once
namespace dkc3 {
constexpr const char* kVersion = "0.62.0";
constexpr const char* kVersionName = "Generic ROM Placement Audit";
}
