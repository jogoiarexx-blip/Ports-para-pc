#include "NativeSprite.h"
#include <algorithm>
#include <cstring>
#include <fstream>
namespace dkc3 {
#pragma pack(push,1)
struct SpriteHeader{char magic[4];uint16_t version;uint16_t flags;uint16_t width,height;int16_t originX,originY;uint32_t pixelCount;};
#pragma pack(pop)
bool loadNativeSprite(const std::string& path, NativeSprite& out){
  out={};std::ifstream f(path,std::ios::binary);SpriteHeader h{};f.read((char*)&h,sizeof h);
  if(!f||std::memcmp(h.magic,"NSPR",4)||h.version!=1||!h.width||!h.height||h.width>4096||h.height>4096||h.flags!=0||h.pixelCount!=(uint32_t)h.width*h.height)return false;
  out.width=h.width;out.height=h.height;out.originX=h.originX;out.originY=h.originY;out.bgra.resize(h.pixelCount);
  f.read((char*)out.bgra.data(),std::streamsize(out.bgra.size()*sizeof(uint32_t)));if(!f||f.peek()!=std::char_traits<char>::eof()){out={};return false;}return true;
}
uint32_t blendNativeSpritePixel(uint32_t c,uint32_t d){
  uint32_t a=c>>24;if(!a)return d;if(a==255)return c;
  auto ch=[&](int shift){return ((((c>>shift)&255)*a+((d>>shift)&255)*(255-a)+127)/255);};
  return 0xff000000u|(ch(16)<<16)|(ch(8)<<8)|ch(0);
}
void drawNativeSprite(const NativeSprite& s,uint32_t* dst,int w,int h,int x,int y,bool flipX,bool flipY){
  if(!dst||w<=0||h<=0||!s.valid())return;
  int64_t dx0=int64_t(x)-s.originX,dy0=int64_t(y)-s.originY;
  for(int sy=0;sy<s.height;++sy){int64_t dy=dy0+sy;if(dy<0||dy>=h)continue;for(int sx=0;sx<s.width;++sx){int64_t dx=dx0+sx;if(dx<0||dx>=w)continue;int srcx=flipX?s.width-1-sx:sx,srcy=flipY?s.height-1-sy:sy;uint32_t c=s.bgra[size_t(srcy)*s.width+srcx];auto& d=dst[size_t(dy)*w+size_t(dx)];d=blendNativeSpritePixel(c,d);}}
}
uint64_t hashSprite(const NativeSprite&s){uint64_t h=1469598103934665603ull;auto mix=[&](const uint8_t*b,size_t n){for(size_t i=0;i<n;i++){h^=b[i];h*=1099511628211ull;}};mix((const uint8_t*)&s.width,sizeof s.width);mix((const uint8_t*)&s.height,sizeof s.height);mix((const uint8_t*)&s.originX,sizeof s.originX);mix((const uint8_t*)&s.originY,sizeof s.originY);if(!s.bgra.empty())mix((const uint8_t*)s.bgra.data(),s.bgra.size()*4);return h;}
}
