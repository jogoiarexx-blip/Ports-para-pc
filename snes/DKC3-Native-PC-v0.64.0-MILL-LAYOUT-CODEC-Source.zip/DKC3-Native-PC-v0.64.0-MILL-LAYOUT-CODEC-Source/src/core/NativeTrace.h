#pragma once
#include <cstdint>
#include <concepts>
#include <map>
#include <optional>
#include <ostream>
#include <string>
#include <string_view>
#include <vector>
namespace dkc3 {
// Flat named state is deliberately independent of C++ object layout and padding.
struct TraceState {
  std::map<std::string,std::optional<std::string>> fields;
  void set(const std::string& key,std::string_view value){fields[key]=std::string(value);}
  template<std::integral T> void set(const std::string& key,T value){fields[key]=std::to_string(value);}
  void set(const std::string& key,float value);
  void set(const std::string& key,double value);
  void unavailable(const std::string& key){fields[key]=std::nullopt;}
  std::string hash() const;
};
struct NativeTraceCall { std::string function;uint32_t sourcePc=0;uint64_t sequence=0; };
struct NativeTraceEvent { std::string type,key,before,after; };
using TraceMetrics=std::map<std::string,std::optional<uint64_t>>;
class TraceRecorder {
 public:
  explicit TraceRecorder(std::ostream& out):out_(out){}
  ~TraceRecorder();
  TraceRecorder(const TraceRecorder&)=delete;
  TraceRecorder& operator=(const TraceRecorder&)=delete;
  void beginFrame(uint64_t frame,uint32_t input);
  bool endFrame(const TraceState&,const std::vector<NativeTraceEvent>&,const TraceMetrics&);
  void record(const char* function,uint32_t sourcePc);
 private:
  std::ostream& out_;uint64_t frame_=0,totalCalls_=0;uint32_t input_=0;
  std::vector<NativeTraceCall> calls_;bool active_=false;
};
// Cheap when disabled. sourcePc is provenance of translated semantics, NEVER an
// executed CPU program counter or proof of instruction-level execution.
void recordNativeCall(const char* function,uint32_t sourcePc=0);
std::vector<NativeTraceEvent> traceStateEvents(const TraceState* previous,const TraceState& next);
std::string traceJsonString(std::string_view text);
}
