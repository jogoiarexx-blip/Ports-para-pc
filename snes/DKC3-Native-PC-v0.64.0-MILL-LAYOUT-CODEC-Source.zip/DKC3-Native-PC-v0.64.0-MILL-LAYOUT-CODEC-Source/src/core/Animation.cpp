#include "Animation.h"
#include <algorithm>
#include <filesystem>
#include <fstream>
#include <sstream>
namespace dkc3 {
void AnimationPlayer::step(const NativeAnimation& a,float dt){
  if(!a.valid()||finished)return;
  time += std::max(0.0f,dt);
  while(frame<a.frames.size() && time>=std::max(0.001f,a.frames[frame].duration)){
    time -= std::max(0.001f,a.frames[frame].duration);
    ++frame;
    if(frame>=a.frames.size()){
      if(a.loop)frame=0;
      else{frame=a.frames.size()-1;finished=true;time=0;break;}
    }
  }
}
const AnimationFrame* AnimationPlayer::current(const NativeAnimation&a)const{
  if(!a.valid())return nullptr;
  return &a.frames[std::min(frame,a.frames.size()-1)];
}
bool loadNativeAnimation(const std::string& path,NativeAnimation& out){
  out={};std::ifstream f(path);if(!f)return false;std::string line;int version=0;const auto base=std::filesystem::path(path).parent_path();
  while(std::getline(f,line)){
    if(line.empty()||line[0]=='#')continue;
    std::istringstream ss(line);std::string k;ss>>k;
    if(k=="NATIVE_ANIMATION")ss>>version;
    else if(k=="loop"){int v=1;ss>>v;out.loop=v!=0;}
    else if(k=="frame"){
      std::string rel;int ms=120,ox=0,oy=0;ss>>rel>>ms>>ox>>oy;if(rel.empty())return false;
      AnimationFrame fr;fr.duration=std::max(1,ms)/1000.0f;fr.offsetX=ox;fr.offsetY=oy;
      if(!loadNativeSprite((base/rel).lexically_normal().string(),fr.sprite))return false;
      out.frames.push_back(std::move(fr));
    }
  }
  return version==1&&out.valid();
}
}
