#pragma once
#include <algorithm>
namespace dkc3 {
struct Vec2 { float x=0, y=0; };
struct Rect { float x=0,y=0,w=0,h=0; };
inline bool overlaps(const Rect&a,const Rect&b){return a.x < b.x+b.w && a.x+a.w>b.x && a.y<b.y+b.h && a.y+a.h>b.y;}
inline float clampf(float v,float lo,float hi){return std::max(lo,std::min(hi,v));}
}
