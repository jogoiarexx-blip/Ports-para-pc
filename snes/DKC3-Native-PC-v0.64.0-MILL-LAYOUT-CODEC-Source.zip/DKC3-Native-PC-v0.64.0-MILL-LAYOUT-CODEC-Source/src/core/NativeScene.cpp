#include "NativeScene.h"
#include <algorithm>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <limits>
#include <sstream>
namespace dkc3 {
namespace fs=std::filesystem;
namespace {
constexpr int maxDimension=4096,maxMapDimension=1024;
#pragma pack(push,1)
struct TileHeader{char magic[4];uint16_t version,bpp;uint32_t tileCount,tileW,tileH,charBaseWord;};
struct MapHeader{char magic[4];uint16_t version,reserved;uint32_t width,height,mapBaseWord;};
struct PalHeader{char magic[4];uint16_t version,colors;};
#pragma pack(pop)
bool exactRead(std::ifstream& f,void* dst,size_t bytes){f.read(static_cast<char*>(dst),std::streamsize(bytes));return bool(f)&&f.peek()==std::char_traits<char>::eof();}
bool readTiles(const fs::path&p,NativeTileSet&o){std::ifstream f(p,std::ios::binary);TileHeader h{};f.read((char*)&h,sizeof h);if(!f||memcmp(h.magic,"NTIL",4)||h.version!=1||h.tileW!=8||h.tileH!=8||!h.tileCount||h.tileCount>1024||(h.bpp!=2&&h.bpp!=4))return false;o.bpp=h.bpp;o.tileCount=h.tileCount;o.pixels.resize(size_t(h.tileCount)*64);return exactRead(f,o.pixels.data(),o.pixels.size());}
bool readMap(const fs::path&p,NativeTileMap&o){std::ifstream f(p,std::ios::binary);MapHeader h{};f.read((char*)&h,sizeof h);if(!f||memcmp(h.magic,"NMAP",4)||h.version!=1||!h.width||!h.height||h.width>maxMapDimension||h.height>maxMapDimension)return false;o.width=int(h.width);o.height=int(h.height);o.entries.resize(size_t(o.width)*o.height);return exactRead(f,o.entries.data(),o.entries.size()*2);}
bool readPal(const fs::path&p,std::vector<uint16_t>&o){std::ifstream f(p,std::ios::binary);PalHeader h{};f.read((char*)&h,sizeof h);if(!f||memcmp(h.magic,"NPAL",4)||h.version!=1||!h.colors||h.colors>256)return false;o.resize(h.colors);return exactRead(f,o.data(),o.size()*2);}
bool dimensions(int w,int h,int max){return w>0&&h>0&&w<=max&&h<=max;}
bool validMask(const NativePixelMask&m){return m.pixels.empty()||(dimensions(m.width,m.height,maxDimension)&&m.pixels.size()==size_t(m.width)*m.height);}
bool allowed(const NativePixelMask&m,int x,int y){return m.pixels.empty()||(x>=0&&y>=0&&x<m.width&&y<m.height&&m.pixels[size_t(y)*m.width+x]!=0);}
bool validTiles(const NativeTileSet&t){return (t.bpp==2||t.bpp==4)&&t.tileCount>0&&t.tileCount<=1024&&t.pixels.size()==size_t(t.tileCount)*64&&std::all_of(t.pixels.begin(),t.pixels.end(),[&](uint8_t p){return p<(1u<<t.bpp);});}
bool validMap(const NativeTileMap&m){return dimensions(m.width,m.height,maxMapDimension)&&m.entries.size()==size_t(m.width)*m.height;}
bool colors15(std::span<const uint16_t> c){return std::all_of(c.begin(),c.end(),[](uint16_t v){return v<=0x7fff;});}
uint32_t color15(uint16_t c,int brightness=15){auto cv=[&](int v){int q=(v<<3)|(v>>2);return uint8_t((q*brightness+7)/15);};return 0xff000000u|(uint32_t(cv(c&31))<<16)|(uint32_t(cv((c>>5)&31))<<8)|cv((c>>10)&31);}
uint16_t rgb15(uint32_t c){return uint16_t(((c>>19)&31)|(((c>>11)&31)<<5)|(((c>>3)&31)<<10));}
uint32_t brighten(uint32_t c,int b){auto ch=[&](int shift){return (((c>>shift)&255)*unsigned(b)+7)/15;};return 0xff000000u|(ch(16)<<16)|(ch(8)<<8)|ch(0);}
int layerZ(const NativeScene&s,int layer,bool high){if(s.bg3Priority){constexpr int lo[3]={5,4,1},hi[3]={8,7,10};return high?hi[layer]:lo[layer];}constexpr int lo[3]={6,5,1},hi[3]={9,8,3};return high?hi[layer]:lo[layer];}
int spriteZ(const NativeScene&s,uint8_t priority){constexpr int normal[4]={2,4,7,10},bg3[4]={2,3,6,9};return s.bg3Priority?bg3[priority]:normal[priority];}
struct ScreenPixel{uint16_t color=0;uint8_t z=0,layerBit=0x20;uint32_t rgba=0xff000000;};
uint16_t math15(uint16_t a,uint16_t b,bool sub,bool half){auto ch=[&](int shift){int v=sub?int((a>>shift)&31)-int((b>>shift)&31):int((a>>shift)&31)+int((b>>shift)&31);v=std::max(0,v);if(half)v>>=1;return std::min(31,v);};return uint16_t(ch(0)|(ch(5)<<5)|(ch(10)<<10));}
int wrap(int64_t value,int length){int r=int(value%length);return r<0?r+length:r;}
void renderScreen(const NativeScene&s,std::vector<ScreenPixel>&out,int w,int h,int cameraX,int cameraY,uint8_t mask,bool main){uint16_t back=s.palette[size_t(s.backdrop)];out.assign(size_t(w)*h,ScreenPixel{back,0,0x20,color15(back)});
  for(size_t li=0;li<s.layers.size();++li){const auto&l=s.layers[li];if(!l.enabled||!(mask&(1u<<li)))continue;int mapW=l.map.width*8,mapH=l.map.height*8,stride=1<<l.bpp;const auto&win=main?l.mainMask:l.subMask;int64_t cx=int64_t(cameraX)*l.parallaxX256/256,cy=int64_t(cameraY)*l.parallaxY256/256;
    for(int y=0;y<h;y++){NativeScanlineOffset row{};if(size_t(y)<l.scanlineOffsets.size())row=l.scanlineOffsets[size_t(y)];int wy=wrap(int64_t(y)+l.scrollY+1+cy+row.y,mapH),ty=wy>>3,py=wy&7;for(int x=0;x<w;x++){if(!allowed(win,x,y))continue;int wx=wrap(int64_t(x)+l.scrollX+cx+row.x,mapW),tx=wx>>3,px=wx&7;uint16_t e=l.map.entries[size_t(ty)*l.map.width+tx];uint32_t tile=e&0x3ffu;if(tile>=l.tiles.tileCount)continue;int sx=(e&0x4000)?7-px:px,sy=(e&0x8000)?7-py:py;uint8_t pix=l.tiles.pixels[size_t(tile)*64+sy*8+sx];if(!pix)continue;int z=layerZ(s,int(li),(e&0x2000)!=0),ci=((e>>10)&7)*stride+pix;auto& p=out[size_t(y)*w+x];if(z<=p.z||size_t(ci)>=s.palette.size())continue;p={s.palette[size_t(ci)],uint8_t(z),uint8_t(1u<<li),color15(s.palette[size_t(ci)])};}}
  }
  if(!(mask&0x10))return;
  std::vector<size_t> order(s.sprites.size());for(size_t i=0;i<order.size();++i)order[i]=i;std::stable_sort(order.begin(),order.end(),[&](size_t a,size_t b){return s.sprites[a].priority<s.sprites[b].priority;});
  for(size_t si:order){const auto&o=s.sprites[si];if(!o.enabled)continue;const auto&sp=o.sprite;const auto&win=main?o.mainMask:o.subMask;int z=spriteZ(s,o.priority);int64_t dx0=int64_t(o.x)-sp.originX-cameraX,dy0=int64_t(o.y)-sp.originY-cameraY;for(int sy=0;sy<sp.height;++sy){int64_t dy=dy0+sy;if(dy<0||dy>=h)continue;for(int sx=0;sx<sp.width;++sx){int64_t dx=dx0+sx;if(dx<0||dx>=w||!allowed(win,int(dx),int(dy)))continue;uint32_t c=sp.bgra[size_t(o.flipY?sp.height-1-sy:sy)*sp.width+(o.flipX?sp.width-1-sx:sx)];if(!(c>>24))continue;auto&p=out[size_t(dy)*w+size_t(dx)];if(z<p.z)continue;p.rgba=blendNativeSpritePixel(c,p.rgba);p.color=rgb15(p.rgba);p.z=uint8_t(z);p.layerBit=o.colorMath?0x10:0;}}}
}
} // namespace
bool validateNativeScene(const NativeScene&s,std::string*error){auto fail=[&](const char*m){if(error)*error=m;return false;};if(s.mode!=1)return fail("unsupported native scene mode (only mode 1)");if(s.cgwsel&~0x02)return fail("unsupported CGWSEL flags; use semantic masks");if(!dimensions(s.viewportW,s.viewportH,maxDimension)||s.brightness<0||s.brightness>15)return fail("invalid viewport or brightness");if(s.palette.empty()||s.palette.size()>256||!colors15(s.palette)||s.backdrop<0||size_t(s.backdrop)>=s.palette.size()||s.fixedColor>0x7fff)return fail("invalid palette/backdrop/fixed color");if(s.layers.size()>3)return fail("mode 1 supports at most three backgrounds");if(!validMask(s.colorMathMask)||s.fixedColorRows.size()>size_t(maxDimension)||!colors15(s.fixedColorRows))return fail("invalid color math mask/gradient");for(size_t i=0;i<s.layers.size();++i){const auto&l=s.layers[i];if(l.bpp!=(i==2?2:4)||l.tiles.bpp!=l.bpp||!validTiles(l.tiles)||!validMap(l.map)||!validMask(l.mainMask)||!validMask(l.subMask)||l.scanlineOffsets.size()>size_t(maxDimension))return fail("invalid mode 1 layer");}for(const auto&o:s.sprites){if(!o.sprite.valid()||!dimensions(o.sprite.width,o.sprite.height,maxDimension)||o.priority>3||!validMask(o.mainMask)||!validMask(o.subMask))return fail("invalid native sprite");}if(error)error->clear();return true;}
bool loadNativeScene(const std::string&path,NativeScene&out){out={};NativeScene s;std::ifstream f(path);if(!f)return false;fs::path base=fs::path(path).parent_path();std::string line,paletteFile="palette.npal";bool header=false;size_t lineCount=0;
  while(std::getline(f,line)){if(++lineCount>4096||line.size()>4096)return false;std::istringstream ss(line);std::string k;if(!(ss>>k)||k[0]=='#')continue;if(k=="NATIVE_SCENE"){int v=0;if(!(ss>>v)||v!=1||header)return false;header=true;}else if(k=="source_frame"){uint64_t frame=0;ss>>frame;}else if(k=="mode")ss>>s.mode;else if(k=="bg3_priority"){int v=-1;ss>>v;if(v<0||v>1)return false;s.bg3Priority=v!=0;}else if(k=="tm"||k=="ts"||k=="cgwsel"||k=="cgadsub"){int v=-1;ss>>v;if(v<0||v>255)return false;if(k=="tm")s.tm=uint8_t(v);else if(k=="ts")s.ts=uint8_t(v);else if(k=="cgwsel")s.cgwsel=uint8_t(v);else s.cgadsub=uint8_t(v);}else if(k=="fixed_color"){int v=-1;ss>>v;if(v<0||v>0x7fff)return false;s.fixedColor=uint16_t(v);}else if(k=="brightness")ss>>s.brightness;else if(k=="backdrop")ss>>s.backdrop;else if(k=="viewport")ss>>s.viewportW>>s.viewportH;else if(k=="palette")ss>>paletteFile;else if(k=="layer"){NativeLayer l;int mw=0,mh=0,en=-1;std::string tf,mf;if(!(ss>>l.name>>l.bpp>>mw>>mh>>l.scrollX>>l.scrollY>>en>>tf>>mf)||en<0||en>1||s.layers.size()>=3)return false;l.enabled=en!=0;if(!readTiles(base/tf,l.tiles)||!readMap(base/mf,l.map)||l.tiles.bpp!=l.bpp||l.map.width!=mw||l.map.height!=mh)return false;s.layers.push_back(std::move(l));}else return false;if(ss.fail())return false;std::string extra;if(ss>>extra&&extra[0]!='#')return false;
  }
  if(!header||!readPal(base/paletteFile,s.palette))return false;
  // v1 exports record main-screen enable; retain explicitly selected subscreen layers.
  for(size_t i=0;i<s.layers.size();++i)s.layers[i].enabled=s.layers[i].enabled||((s.ts&(1u<<i))!=0);
  if(!validateNativeScene(s))return false;
  out=std::move(s);return true;
}
bool setPalette(NativeScene&s,size_t first,std::span<const uint16_t>colors){if(first>s.palette.size()||colors.size()>s.palette.size()-first||!colors15(colors))return false;std::vector<uint16_t> copy(colors.begin(),colors.end());std::copy(copy.begin(),copy.end(),s.palette.begin()+first);return true;}
bool updateTilemap(NativeScene&s,size_t li,int x,int y,int w,int h,std::span<const uint16_t>entries){if(li>=s.layers.size())return false;auto&m=s.layers[li].map;if(!validMap(m)||x<0||y<0||w<=0||h<=0||x>m.width||y>m.height||w>m.width-x||h>m.height-y||entries.size()!=size_t(w)*h)return false;std::vector<uint16_t> copy(entries.begin(),entries.end());for(int row=0;row<h;++row)std::copy_n(copy.begin()+size_t(row)*w,w,m.entries.begin()+size_t(y+row)*m.width+x);return true;}
bool updateTiles(NativeScene&s,size_t li,uint32_t first,std::span<const uint8_t>pixels){if(li>=s.layers.size())return false;auto&t=s.layers[li].tiles;if(!validTiles(t)||pixels.size()%64||first>t.tileCount||pixels.size()/64>t.tileCount-first||!std::all_of(pixels.begin(),pixels.end(),[&](uint8_t v){return v<(1u<<t.bpp);}))return false;std::vector<uint8_t> copy(pixels.begin(),pixels.end());std::copy(copy.begin(),copy.end(),t.pixels.begin()+size_t(first)*64);return true;}
bool setLayerScroll(NativeScene&s,size_t li,int x,int y){if(li>=s.layers.size())return false;s.layers[li].scrollX=x;s.layers[li].scrollY=y;return true;}
bool setLayerParallax(NativeScene&s,size_t li,int x,int y){if(li>=s.layers.size())return false;s.layers[li].parallaxX256=x;s.layers[li].parallaxY256=y;return true;}
bool updateScanlineOffsets(NativeScene&s,size_t li,std::span<const NativeScanlineOffset>rows){if(li>=s.layers.size()||rows.size()>size_t(maxDimension))return false;std::vector<NativeScanlineOffset> copy(rows.begin(),rows.end());s.layers[li].scanlineOffsets=std::move(copy);return true;}
bool updateGradient(NativeScene&s,std::span<const uint16_t>rows){if(rows.size()>size_t(maxDimension)||!colors15(rows))return false;std::vector<uint16_t> copy(rows.begin(),rows.end());s.fixedColorRows=std::move(copy);return true;}
bool renderNativeSceneChecked(const NativeScene&s,uint32_t*dst,int w,int h,int cameraX,int cameraY,std::string*error){if(!dst||!dimensions(w,h,maxDimension)){if(error)*error="invalid render target";return false;}if(!validateNativeScene(s,error))return false;static thread_local std::vector<ScreenPixel> mainPx,subPx;renderScreen(s,mainPx,w,h,cameraX,cameraY,s.tm,true);renderScreen(s,subPx,w,h,cameraX,cameraY,s.ts,false);bool useSub=(s.cgwsel&2)!=0,subtract=(s.cgadsub&0x80)!=0,half=(s.cgadsub&0x40)!=0;
  for(int y=0;y<h;++y)for(int x=0;x<w;++x){size_t i=size_t(y)*w+x;uint16_t fixed=size_t(y)<s.fixedColorRows.size()?s.fixedColorRows[size_t(y)]:s.fixedColor;const auto&p=mainPx[i];if((s.cgadsub&p.layerBit)&&allowed(s.colorMathMask,x,y)){bool subPresent=subPx[i].z!=0;uint16_t b=useSub&&subPresent?subPx[i].color:fixed;bool doHalf=half&&(!useSub||subPresent);dst[i]=color15(math15(p.color,b,subtract,doHalf),s.brightness);}else dst[i]=brighten(p.rgba,s.brightness);}
  return true;
}
void renderNativeScene(const NativeScene&s,uint32_t*dst,int w,int h,int cameraX,int cameraY){if(!renderNativeSceneChecked(s,dst,w,h,cameraX,cameraY)&&dst&&dimensions(w,h,maxDimension))std::fill_n(dst,size_t(w)*h,0xff000000);}
uint64_t hashFrame(const uint32_t*p,size_t n){uint64_t h=1469598103934665603ull;const uint8_t*b=(const uint8_t*)p;for(size_t i=0;i<n*sizeof(uint32_t);i++){h^=b[i];h*=1099511628211ull;}return h;}
}
