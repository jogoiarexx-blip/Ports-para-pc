#pragma once
#include <cstdint>
namespace dkc3 {
class RomImage;
struct RomSpawnSpec;
struct RomSteelProfile {bool valid=false;uint32_t source=0;uint16_t gravity=0,terminal=0,interpolation=0;};
bool loadRomSteelProfile(const RomImage&,const RomSpawnSpec&,RomSteelProfile&);
uint16_t romSteelGravity(uint16_t velocity,const RomSteelProfile&);
uint16_t romSteelInterpolate(uint16_t velocity,uint16_t target);
struct RomSteelProbeVelocity {uint16_t x=0,y=0;bool slowed=false;};
// B9:EC09..EC3B: temporary velocities for terrain, restored after the query.
RomSteelProbeVelocity romSteelWaterProbe(uint16_t waterY,uint16_t feetY,uint16_t x,uint16_t y);
struct RomSteelVelocity {uint16_t x=0,target=0,y=0,terrain=0,oam=0;};
// BE:D960..D974: signed 8.8 velocities; BIT $58 tests bit 14 (V).
inline RomSteelVelocity romSteelRelease(uint16_t direction,uint16_t oam){
 const uint16_t x=(direction&0x4000)?0xfe00:0x0200;
 return {x,x,0xff00,0,oam};
}
// BE:D781..D798: negate the pre-collision words $AE/$B0, flip OAM bit 14.
inline void romSteelWall(RomSteelVelocity& v,uint16_t previousTarget,uint16_t previousX){
 v.oam^=0x4000;v.target=uint16_t(0u-previousTarget);v.x=uint16_t(0u-previousX);
}
}
