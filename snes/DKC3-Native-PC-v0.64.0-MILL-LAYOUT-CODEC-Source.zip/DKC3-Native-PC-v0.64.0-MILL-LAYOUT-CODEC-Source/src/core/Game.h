#pragma once
#include "RomObjectRuntime.h"
#include "RomAnimal.h"
#include "RomControl.h"
#include "CarryBarrel.h"
#include "SuppliedSprites.h"
#include "Bmp.h"
#include "World.h"
#include "Player.h"
#include "NativeScene.h"
#include "NativeSprite.h"
#include "Animation.h"
#include "Hud.h"
#include "Audio.h"
#include "RomData.h"
#include <map>
#include <string>
#include <vector>
namespace dkc3 {
struct TraceState;
struct Camera { float x=0,y=0; int viewportW=256,viewportH=224; };
struct RuntimeSpriteObject { std::string id; Vec2 pos; bool foreground=false; NativeSprite sprite; };
struct RuntimeEnemy {
  std::string id; Vec2 pos; float speed=0,minX=0,maxX=0,w=24,h=24; bool facingRight=false,active=true;
  uint16_t spriteId=0,rewardIndex=0;
  RomObjectReward reward{},duplicateReward{};
  NativeAnimation animation; AnimationPlayer animator;
  Rect bounds() const{return {pos.x,pos.y,w,h};}
};
struct RuntimeLever { std::string id,gateId; Rect rect; Vec2 anchor; float holdTime=0.45f,progress=0.0f; bool activated=false; };
struct RuntimeGate { std::string id; Rect rect; bool open=false; NativeSprite sprite; };
struct RuntimeScenePage { float startX=0; std::string path; NativeScene scene; bool loaded=false; };
struct RuntimeCollectible {
  std::string id; Vec2 pos; float w=20,h=20; int value=1; bool active=true;
  NativeAnimation animation; AnimationPlayer animator;
  Rect bounds() const{return {pos.x,pos.y,w,h};}
};
struct RuntimeKongLetter {
  char letter='K'; Vec2 pos; float w=16,h=28; bool active=true;
  NativeAnimation animation; AnimationPlayer animator;
  Rect bounds() const{return {pos.x,pos.y,w,h};}
};
struct RuntimeTeamBarrel : CarryBarrelBody {
  std::string id;bool active=true,rescuesPartner=true,steel=false;NativeSprite sprite;uint16_t terrainFlags=0;unsigned ricochets=0;
};
enum class BarrelCannonRole { WarpEntry, WarpExit, BonusEntry1, BonusExit1, BonusEntry2, BonusExit2, Unknown };
struct RuntimeBarrelCannon {
  uint16_t placementType=0; Vec2 pos; float w=40,h=48; BarrelCannonRole role=BarrelCannonRole::Unknown;
  bool hidden=false,revealed=false; NativeAnimation animation; AnimationPlayer animator;
  Rect bounds() const{return {pos.x,pos.y,w,h};}
};
struct RuntimeAnimalBox {
  Vec2 feet;uint16_t animalType=0;RomAnimalBoxStateMachine lifecycle;
  NativeAnimation closed,opened;double remainder=0;float openedAt=-1;
  Rect bounds()const{return {feet.x-18,feet.y-36,36,36};}
};
struct RuntimeAnimalSign {
  Vec2 feet;uint16_t animalType=0,rewardIndex=0,offset=0;bool awarded=false;
  RomObjectReward reward;NativeAnimation animation;
};
struct RuntimeAnimal {
  bool active=false,mounted=false;uint16_t type=0;Player body;
  NativeAnimation idle,walk;AnimationPlayer animator;bool walking=false;
  Rect bounds()const{return body.bounds();}
};
struct RuntimeKoin {
  Vec2 feet;RomKoinChildren children;RomKoinAimProfile aimProfile;bool facingRight=false;
  NativeAnimation body,shield;std::map<uint16_t,NativeAnimation> poses,shields;
  uint16_t graphic=0x2dcd,animation=0x211;bool defeated=false,coinCollected=false;float defeatTime=0;
  NativeAnimation coin;Vec2 coinPos;unsigned guardedHits=0;
  Rect coinBounds()const{return {coinPos.x-14,coinPos.y-14,28,28};}
  Rect bounds()const{return {feet.x-18,feet.y-48,36,48};}
};
struct RuntimeBarrelRespawner {
  RomSteelProfile steelProfile;
  Vec2 feet;uint16_t type=0,timer=0,spacing=0;int current=-1;bool initialized=false;
  RomSpawnSpec child;NativeSprite sprite;double remainder=0;unsigned spawns=0;
};
enum class CharacterId { Dixie, Kiddy };
struct GamePersistentState { CharacterId activeCharacter=CharacterId::Dixie; bool partnerAvailable=true; int coins=0; int bananas=0; int lives=5; int bonusCoins=0; unsigned lakesideBonusMask=0; int dkCoins=0;std::array<uint8_t,32> koinFlags{}; };
class Game {
 public:
  void appendTraceState(TraceState&) const;
  const SuppliedSprites& suppliedSprites() const { return suppliedSprites_; }
  const RomSpawnRuntime& romSpawnRuntime() const { return romSpawnRuntime_; }
  bool init(const char* levelPath,const GamePersistentState* persistent=nullptr);
  void step(const InputState& in,float dt);
  void render(uint32_t* dst,int w,int h) const;
  const World& world()const{return world_;}
  const Player& player()const{return player_;}
  const NativeScene& scene()const{return scenePages_.empty()?scene_:scenePages_[activeScenePage_].scene;}
  bool hasNativeScene()const{return hasScene_||hasRomScene_;}
  bool hasRomScene()const{return hasRomScene_;}
  size_t scenePageCount()const{return hasRomScene_?1u:(scenePages_.empty()?(hasScene_?1u:0u):scenePages_.size());}
  size_t activeScenePage()const{return scenePages_.empty()?0u:activeScenePage_;}
  size_t loadedScenePageCount()const{size_t n=0;for(const auto& p:scenePages_)if(p.loaded)++n;return n;}
  bool scenePageLoaded(size_t index)const{return index<scenePages_.size()&&scenePages_[index].loaded;}
  const Camera& camera()const{return camera_;}
  const NativeSprite& playerSprite()const{return playerSprite_;}
  const NativeSprite& companionSprite()const{return companionSprite_;}
  Vec2 companionPos()const{return companionPos_;}
  const std::vector<RuntimeSpriteObject>& spriteObjects()const{return spriteObjects_;}
  const std::vector<RomLevelTrigger>& romTriggers()const{return romTriggers_;}
  const std::vector<RomControlObject>& romControls()const{return romControls_;}
  const std::vector<RuntimeKoin>& koins()const{return koins_;}
  uint8_t romLevelByte(uint16_t address)const{auto i=romLevelBytes_.find(address);return i==romLevelBytes_.end()?0:i->second;}
  const RuntimeAnimal& animal()const{return animal_;}
  const std::vector<RuntimeAnimalBox>& animalBoxes()const{return animalBoxes_;}
  const std::vector<RuntimeAnimalSign>& animalSigns()const{return animalSigns_;}
  unsigned animalMounts()const{return animalMounts_;}
  unsigned animalSignRewards()const{return animalSignRewards_;}
  const std::vector<RuntimeEnemy>& enemies()const{return enemies_;}
  const std::vector<RuntimeCollectible>& collectibles()const{return collectibles_;}
  const std::vector<RuntimeKongLetter>& kongLetters()const{return kongLetters_;}
  const std::vector<RuntimeTeamBarrel>& teamBarrels()const{return teamBarrels_;}
  const std::vector<RuntimeBarrelCannon>& barrelCannons()const{return barrelCannons_;}
  const std::vector<RuntimeLever>& levers()const{return levers_;}
  const std::vector<RuntimeGate>& gates()const{return gates_;}
  const std::string& pendingLevel()const{return pendingLevel_;}
  Vec2 respawnPoint()const{return respawn_;}
  int coins()const{return coins_;}
  int bananas()const{return bananas_;}
  int lives()const{return lives_;}
  int damageCount()const{return damageCount_;}
  int defeatedEnemies()const{return defeatedEnemies_;}
  std::string playerAnimationState()const{return playerAnimState_;}
  std::string companionAnimationState()const{return companionAnimState_;}
  size_t playerAnimationFrame()const{return playerAnimator_.frame;}
  CharacterId activeCharacter()const{return activeCharacter_;}
  bool partnerAvailable()const{return partnerAvailable_;}
  bool attacking()const{return attackTimer_>0.0f;}
  bool attackActive()const;
  Rect attackBounds()const;
  float invulnerabilityTime()const{return invulnerableTimer_;}
  int characterSwitches()const{return characterSwitches_;}
  int leverActivations()const{return leverActivations_;}
  int checkpointActivations()const{return checkpointActivations_;}
  int lockedDoorAttempts()const{return lockedDoorAttempts_;}
  bool carryingBarrel()const{return carriedBarrel_>=0;}
  int barrelPickups()const{return barrelPickups_;}
  int barrelThrows()const{return barrelThrows_;}
  int barrelBreaks()const{return barrelBreaks_;}
  int barrelEnemyHits()const{return barrelEnemyHits_;}
  int teamBarrelRescues()const{return teamBarrelRescues_;}
  int barrelEntries()const{return barrelEntries_;}
  int warpShortcuts()const{return warpShortcuts_;}
  int bonusBarrelAttempts()const{return bonusBarrelAttempts_;}
  bool inBonus()const{return inBonus_;}
  int activeBonus()const{return activeBonus_;}
  int bonusCollected()const{return bonusCollected_;}
  int bonusTarget()const{return activeBonus_?((activeBonus_==1)?50:15):0;}
  float bonusTimeRemaining()const{return bonusTimeRemaining_;}
  const std::vector<RuntimeBarrelRespawner>& barrelRespawners()const{return barrelRespawners_;}
  int dkCoins()const{return dkCoins_;}
  int bonusCoins()const{return bonusCoins_;}
  unsigned lakesideBonusMask()const{return lakesideBonusMask_;}
  const std::vector<RuntimeCollectible>& bonusCollectibles()const{return bonusCollectibles_;}
  const RuntimeCollectible& bonusCoin()const{return bonusCoin_;}
  bool inBarrel()const{return activeBarrel_>=0;}
  unsigned kongMask()const{return kongMask_;}
  int kongLettersCollected()const{return kongLettersCollected_;}
  bool leverActivated(const std::string& id)const;
  GamePersistentState persistentState()const{return {activeCharacter_,partnerAvailable_,coins_,bananas_,lives_,bonusCoins_,lakesideBonusMask_,dkCoins_,koinFlags_};}
  bool inWater()const{return inWater_;}
  bool inWaterCurrent()const{return inWaterCurrent_;}
  Vec2 activeWaterCurrent()const{return activeWaterCurrent_;}
  // v0.8.0: HUD, overlay de debug e transicao suave entre paginas de cena.
  void setHudEnabled(bool v){hudEnabled_=v;} bool hudEnabled()const{return hudEnabled_;}
  void setDebugOverlay(bool v){debugOverlay_=v;} bool debugOverlay()const{return debugOverlay_;}
  float levelTime()const{return levelTime_;}
  bool pageFading()const{return pageFade_<1.0f;}
  float pageFadeProgress()const{return pageFade_;}
  // v0.9.0: eventos de som emitidos desde a ultima chamada (a plataforma consome e toca).
  std::vector<Sfx> takeSfx(){std::vector<Sfx> o;o.swap(sfx_);return o;}
  void showToastPublic(const std::string& text,float seconds=1.2f){showToast(text,seconds);}
  const std::string& toast()const{return toast_;}
  float toastTime()const{return toastTimer_;}
 private:
  RomMotionProfile dixieMotion_,kiddyMotion_,ellieDixieMotion_,ellieKiddyMotion_;
  RuntimeAnimal animal_;std::vector<RuntimeAnimalBox> animalBoxes_;std::vector<RuntimeAnimalSign> animalSigns_;
  unsigned animalMounts_=0,animalSignRewards_=0;
  std::vector<RomLevelTrigger> romTriggers_;std::vector<RomControlObject> romControls_;std::vector<RuntimeKoin> koins_;
  std::map<uint16_t,uint8_t> romLevelBytes_;
  bool hitRomTriggers(Rect hit);
  void stepRomControls(float dt);
  void stepKoins(Vec2 previous,float dt);
  bool hitKoins(RuntimeTeamBarrel&,Rect hit);
  void stepBarrelRespawners(float dt);
  std::vector<RuntimeBarrelRespawner> barrelRespawners_;int dkCoins_=0;std::array<uint8_t,32> koinFlags_{};
  void emit(Sfx s);
  bool hitAnimalBoxes(Rect hit);
  void stepAnimalObjects(const InputState& in,float dt);
  void mountAnimal();
  void dismountAnimal(bool remove=false);
  void defeatEnemy(RuntimeEnemy& enemy);
  void spriteEffect(const std::string& name,Vec2 pos,bool flip=false);
  void showToast(const std::string& text,float seconds=1.6f){toast_=text;toastTimer_=seconds;}
  void renderScenePage(size_t index,uint32_t* dst,int w,int h)const;
  void renderRomScene(uint32_t* dst,int w,int h)const;
  void drawHud(uint32_t* dst,int w,int h)const;
  void drawDebug(uint32_t* dst,int w,int h)const;
  void updateCamera(float dt);
  bool ensureScenePageLoaded(size_t index);
  bool prefetchSceneWindow(size_t center);
  void trimScenePageCache();
  bool loadAnimationMap(const std::vector<AnimationDef>& defs,std::map<std::string,NativeAnimation>& out);
  std::string desiredPlayerAnimation()const;
  const NativeAnimation* findAnim(const std::map<std::string,NativeAnimation>& set,const std::string& key)const;
  const std::map<std::string,NativeAnimation>& activeAnimations()const;
  const std::map<std::string,NativeAnimation>& inactiveAnimations()const;
  const NativeSprite& activeFallbackSprite()const;
  const NativeSprite& inactiveFallbackSprite()const;
  void setPlayerAnimationState(const std::string& state);
  void switchCharacter(bool manualSwitch);
  void applyCharacterDimensions();
  void applyDamage(float enemyCenterX);
  void activateLever(size_t index);
  void breakTeamBarrel(size_t index,bool rescue=true);
  void dropCarriedBarrel();
  bool handleCarryBarrelInput(const InputState& in,bool attackPressed);
  void stepCarryBarrels(float dt);
  float attackDuration() const;
  float attackReach() const;
  bool enterBonus(int bonusIndex);
  void leaveBonus(bool completed);
  void stepBonus(const InputState& in,float dt);
  void renderBonusScene(uint32_t* dst,int w,int h)const;
  struct SpriteEffect { std::string name;Vec2 pos;AnimationPlayer animator;bool flip=false; };
  SuppliedSprites suppliedSprites_;Bitmap gameOverImage_;std::vector<SpriteEffect> spriteEffects_;bool crouchVisual_=false;
  World world_,mainWorld_; Vec2 mainRespawn_{}; bool surfaceJumpPending_=false; Player player_; NativeScene scene_; bool hasScene_=false,hasRomScene_=false; RomSpawnRuntime romSpawnRuntime_; RomLevelRuntime romLakeside_; RomLakesideBonusVisuals romBonus1_,romBonus2_;
  std::vector<RuntimeScenePage> scenePages_; size_t activeScenePage_=0;
  Camera camera_; Vec2 respawn_{}; NativeSprite playerSprite_,companionSprite_; Vec2 companionPos_{};
  std::vector<RuntimeSpriteObject> spriteObjects_; std::vector<RuntimeEnemy> enemies_; std::vector<RuntimeCollectible> collectibles_;
  std::vector<RuntimeKongLetter> kongLetters_;
  std::vector<RuntimeTeamBarrel> teamBarrels_;
  std::vector<RuntimeBarrelCannon> barrelCannons_;
  std::vector<RuntimeLever> levers_; std::vector<RuntimeGate> gates_; std::vector<bool> checkpointActive_;
  std::map<std::string,NativeAnimation> dixieAnimations_,kiddyAnimations_;
  AnimationPlayer playerAnimator_,companionAnimator_; std::string playerAnimState_="idle",companionAnimState_="idle";
  std::string pendingLevel_; bool prevUp_=false,prevJump_=false,prevAttack_=false,prevSwitch_=false;
  int coins_=0,bananas_=0,lives_=5,damageCount_=0,defeatedEnemies_=0,characterSwitches_=0,leverActivations_=0,checkpointActivations_=0,lockedDoorAttempts_=0,teamBarrelRescues_=0;
  int barrelEntries_=0,warpShortcuts_=0,bonusBarrelAttempts_=0;
  bool inBonus_=false;int activeBonus_=0,bonusCollected_=0,bonusGreenIndex_=0,bonusCoins_=0;unsigned lakesideBonusMask_=0;float bonusTimeRemaining_=0.0f,bonusGreenLife_=0.0f;
  std::vector<RuntimeCollectible> bonusCollectibles_;RuntimeCollectible bonusCoin_;
  unsigned kongMask_=0; int kongLettersCollected_=0;
  CharacterId activeCharacter_=CharacterId::Dixie; bool partnerAvailable_=true;
  float attackTimer_=0.0f,attackCooldown_=0.0f,invulnerableTimer_=0.0f;
  int carriedBarrel_=-1,barrelPickups_=0,barrelThrows_=0,barrelBreaks_=0,barrelEnemyHits_=0;bool barrelReleaseBlocked_=false;
  int activeBarrel_=-1; float barrelHoldTimer_=0.0f,barrelCooldown_=0.0f;
  int activeLever_=-1; bool inWater_=false,inWaterCurrent_=false; Vec2 activeWaterCurrent_{};
  std::vector<Sfx> sfx_; bool prevGrounded_=false,prevInWater_=false,waterKnown_=false; float lastAirVy_=0.0f;
  bool hudEnabled_=true,debugOverlay_=false; float levelTime_=0.0f,toastTimer_=0.0f,pageFade_=1.0f; std::string toast_; size_t fadeFromPage_=0;
};
}
