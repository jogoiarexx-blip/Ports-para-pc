#pragma once
#include <cstdint>
#include <string>
#include <vector>
namespace dkc3 {
struct Bitmap { int w=0,h=0; std::vector<uint32_t> bgra; };
bool loadBmp32(const std::string& path, Bitmap& out);
// v0.8.0: grava um framebuffer BGRA como BMP 32 bpp (screenshots F2 e ferramenta de frames).
bool saveBmp32(const std::string& path, const uint32_t* bgra, int w, int h);
}
