#pragma once
#include "Bmp.h"
#include "Animation.h"
#include <array>
#include <string>
namespace dkc3 {
// Native save-room presentation. Frame sequence is intentionally not guessed.
class WrinklyCave {
 public:
  bool init(const std::string& directory="assets/scenes/wrinkly-cave");
  void step(float dt) { wrinklyPlayer_.step(wrinkly_,dt); }
  bool ready() const { return originalReady_; }
  bool hd() const { return useHd_ && hdReady_; }
  void toggleGraphics() { if(hdReady_)useHd_=!useHd_; }
  void setSaveResult(bool success) { saveResult_=success?1:-1; }
  void resetMessage() { saveResult_=0; }
  void render(uint32_t* dst,int w,int h) const;
 private:
  NativeAnimation wrinkly_;AnimationPlayer wrinklyPlayer_;
  std::array<Bitmap,4> original_,hd_;
  bool originalReady_=false,hdReady_=false,useHd_=true;
  int saveResult_=0;
};
}
