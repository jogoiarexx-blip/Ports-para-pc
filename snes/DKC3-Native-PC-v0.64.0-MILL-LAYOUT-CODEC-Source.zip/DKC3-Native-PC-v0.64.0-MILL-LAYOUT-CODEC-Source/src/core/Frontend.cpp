#include "Frontend.h"
#include "Hud.h"
#include <algorithm>
#include <filesystem>
#include <fstream>
#include <sstream>

namespace dkc3 {
namespace {
void centerText(uint32_t* dst,int w,int h,int y,const std::string& text,uint32_t color,int scale=1){
  hudDrawText(dst,w,h,(w-hudTextWidth(text,scale))/2,y,text,color,scale);
}
}

const char* Frontend::screenName(FrontendScreen s){
  switch(s){
    case FrontendScreen::GameOver:return "GAME-OVER";
    case FrontendScreen::BootPublisher:return "BOOT-PUBLISHER";
    case FrontendScreen::BootStudio:return "BOOT-STUDIO";
    case FrontendScreen::Title:return "TITLE";
    case FrontendScreen::SaveSelect:return "SAVE-SELECT";
  }
  return "?";
}

std::string Frontend::slotPath(int index) const{
  return (std::filesystem::path(saveDirectory_)/("slot"+std::to_string(index+1)+".nsav")).string();
}

bool Frontend::loadSlot(int index){
  if(index<0||index>=3)return false;
  SaveSlotData s;s.slot=index+1;
  std::ifstream f(slotPath(index));
  if(!f){slots_[(size_t)index]=s;return true;}
  std::string line;
  if(!std::getline(f,line)||(line!="DKC3_NATIVE_SAVE_V1"&&line!="DKC3_NATIVE_SAVE_V2"&&line!="DKC3_NATIVE_SAVE_V3"&&line!="DKC3_NATIVE_SAVE_V4"&&line!="DKC3_NATIVE_SAVE_V5"&&line!="DKC3_NATIVE_SAVE_V6"&&line!="DKC3_NATIVE_SAVE_V7"&&line!="DKC3_NATIVE_SAVE_V8")){slots_[(size_t)index]=s;return false;}
  const bool v2=line=="DKC3_NATIVE_SAVE_V2";
  const bool v4plus=line=="DKC3_NATIVE_SAVE_V4"||line=="DKC3_NATIVE_SAVE_V5"||line=="DKC3_NATIVE_SAVE_V6"||line=="DKC3_NATIVE_SAVE_V7"||line=="DKC3_NATIVE_SAVE_V8";
  s.exists=true;
  while(std::getline(f,line)){
    std::istringstream ss(line);std::string key;if(!(ss>>key))continue;
    if(key=="level")ss>>s.currentLevel;
    else if(key=="percent")ss>>s.percent;
    else if(key=="play_seconds")ss>>s.playSeconds;
    else if(key=="character"){
      std::string c;ss>>c;s.persistent.activeCharacter=(c=="kiddy")?CharacterId::Kiddy:CharacterId::Dixie;
    }else if(key=="partner"){
      int v=1;ss>>v;s.persistent.partnerAvailable=v!=0;
    }else if(key=="coins")ss>>s.persistent.coins;
    else if(key=="bananas")ss>>s.persistent.bananas;
    else if(key=="lives")ss>>s.persistent.lives;
    else if(key=="bonus_coins")ss>>s.persistent.bonusCoins;
    else if(key=="dk_coins")ss>>s.persistent.dkCoins;
    else if(key=="koin_flags"){for(auto& byte:s.persistent.koinFlags){unsigned v=0;if(!(ss>>v))break;byte=static_cast<uint8_t>(v&255);}}
    else if(key=="lakeside_bonus_mask")ss>>s.persistent.lakesideBonusMask;
    else if(key=="world_x")ss>>s.worldMap.boatX;
    else if(key=="world_y")ss>>s.worldMap.boatY;
    else if(key=="unlocked")ss>>s.worldMap.unlockedMask;
    else if(key=="completed")ss>>s.worldMap.completedMask;
    else if(key=="map_area")ss>>s.worldMap.area;
    else if(key=="lake_node")ss>>s.worldMap.lakeNode;
  }
  if(s.currentLevel.empty())s.currentLevel="lakeside-limbo";
  if(!v4plus){
    // v0.22-v0.26 used Doorstop as the artificial first stage and a 3-bit mask.
    // Preserve those saves while migrating them onto the real Lake Orangatanga order.
    const unsigned oldUnlocked=s.worldMap.unlockedMask;
    const unsigned oldCompleted=s.worldMap.completedMask;
    unsigned nu=WorldMap::stageBit("lakeside-limbo");
    unsigned nc=WorldMap::stageBit("lakeside-limbo");
    if(oldUnlocked&1u)nu|=WorldMap::stageBit("doorstop");
    if(oldUnlocked&2u)nu|=WorldMap::stageBit("tidal-trouble");
    if(oldUnlocked&4u)nu|=WorldMap::stageBit("skiddas-row");
    if(oldCompleted&1u)nc|=WorldMap::stageBit("doorstop");
    if(oldCompleted&2u)nc|=WorldMap::stageBit("tidal-trouble");
    if(oldCompleted&4u)nc|=WorldMap::stageBit("skiddas-row");
    if(s.currentLevel=="doorstop")nu|=WorldMap::stageBit("doorstop");
    else if(s.currentLevel=="tidal-trouble"){nu|=WorldMap::stageBit("doorstop")|WorldMap::stageBit("tidal-trouble");nc|=WorldMap::stageBit("doorstop");}
    else if(s.currentLevel=="skiddas-row"){nu|=WorldMap::stageBit("doorstop")|WorldMap::stageBit("tidal-trouble")|WorldMap::stageBit("skiddas-row");nc|=WorldMap::stageBit("doorstop")|WorldMap::stageBit("tidal-trouble");}
    s.worldMap.unlockedMask=nu;s.worldMap.completedMask=nc;s.worldMap.area=(int)WorldArea::LakeOrangatanga;
    if(s.currentLevel=="doorstop")s.worldMap.lakeNode=1;else if(s.currentLevel=="tidal-trouble")s.worldMap.lakeNode=2;else if(s.currentLevel=="skiddas-row")s.worldMap.lakeNode=3;else s.worldMap.lakeNode=0;
  }
  if(v2){s.worldMap.boatX*=2.0f;s.worldMap.boatY*=2.0f;}
  s.percent=std::clamp(s.percent,0,103);s.playSeconds=std::max(0,s.playSeconds);s.persistent.coins=std::max(0,s.persistent.coins);s.persistent.bananas=std::max(0,s.persistent.bananas);s.persistent.lives=std::max(0,s.persistent.lives);s.persistent.bonusCoins=std::max(0,s.persistent.bonusCoins);
  slots_[(size_t)index]=s;return true;
}

bool Frontend::writeSlot(int index) const{
  if(index<0||index>=3)return false;
  std::error_code ec;std::filesystem::create_directories(saveDirectory_,ec);
  const auto& s=slots_[(size_t)index];
  std::ofstream f(slotPath(index),std::ios::trunc);if(!f)return false;
  f<<"DKC3_NATIVE_SAVE_V8\n";
  f<<"level "<<(s.currentLevel.empty()?"lakeside-limbo":s.currentLevel)<<"\n";
  f<<"percent "<<std::clamp(s.percent,0,103)<<"\n";
  f<<"play_seconds "<<std::max(0,s.playSeconds)<<"\n";
  f<<"character "<<(s.persistent.activeCharacter==CharacterId::Kiddy?"kiddy":"dixie")<<"\n";
  f<<"partner "<<(s.persistent.partnerAvailable?1:0)<<"\n";
  f<<"coins "<<std::max(0,s.persistent.coins)<<"\n";
  f<<"bananas "<<std::max(0,s.persistent.bananas)<<"\n";
  f<<"lives "<<std::max(0,s.persistent.lives)<<"\n";
  f<<"bonus_coins "<<std::max(0,s.persistent.bonusCoins)<<"\n";
  f<<"dk_coins "<<std::max(0,s.persistent.dkCoins)<<"\n";
  f<<"koin_flags";for(auto byte:s.persistent.koinFlags)f<<" "<<unsigned(byte);f<<"\n";
  f<<"lakeside_bonus_mask "<<s.persistent.lakesideBonusMask<<"\n";
  f<<"world_x "<<s.worldMap.boatX<<"\n";
  f<<"world_y "<<s.worldMap.boatY<<"\n";
  f<<"unlocked "<<s.worldMap.unlockedMask<<"\n";
  f<<"completed "<<s.worldMap.completedMask<<"\n";
  f<<"map_area "<<s.worldMap.area<<"\n";
  f<<"lake_node "<<s.worldMap.lakeNode<<"\n";
  return (bool)f;
}

bool Frontend::init(const std::string& saveDirectory,const std::string& romPath){
  saveDirectory_=saveDirectory.empty()?"saves":saveDirectory;
  romVisuals_.load(romPath);
  loadBmp32("assets/sprites/dkc3/screens/publisher.bmp",publisherSheet_);
  loadBmp32("assets/sprites/dkc3/screens/studio.bmp",studioSheet_);
  loadBmp32("assets/sprites/dkc3/screens/title.bmp",titleSheet_);
  loadBmp32("assets/sprites/dkc3/screens/game-over.bmp",gameOverSheet_);
  for(int i=0;i<3;++i){slots_[(size_t)i]=SaveSlotData{};slots_[(size_t)i].slot=i+1;loadSlot(i);}
  selectedSlot_=0;activeSlot_=-1;launchPending_=false;launch_=FrontendLaunchRequest{};prev_=FrontendInput{};
  screen_=FrontendScreen::BootPublisher;screenTime_=0;titleBlink_=0;return true;
}

void Frontend::enter(FrontendScreen next){screen_=next;screenTime_=0.0f;titleBlink_=0.0f;}

void Frontend::beginGameOver(){
  launchPending_=false;launch_={};enter(FrontendScreen::GameOver);
  // A held Start from gameplay must be released before skipping this screen.
  prev_={false,false,true,false,true};
}

void Frontend::step(const FrontendInput& in,float dt){
  dt=std::clamp(dt,0.0f,0.1f);screenTime_+=dt;titleBlink_+=dt;
  const bool confirm=pressed(in.confirm,prev_.confirm)||pressed(in.start,prev_.start);
  const bool cancel=pressed(in.cancel,prev_.cancel);
  const bool up=pressed(in.up,prev_.up),down=pressed(in.down,prev_.down);
  switch(screen_){
    case FrontendScreen::BootPublisher:
      if(screenTime_>=1.25f||confirm)enter(FrontendScreen::BootStudio);
      break;
    case FrontendScreen::BootStudio:
      if(screenTime_>=1.25f||confirm)enter(FrontendScreen::Title);
      break;
    case FrontendScreen::GameOver:
      if(screenTime_>=4.0f||(screenTime_>=0.5f&&confirm))enter(FrontendScreen::Title);
      break;
    case FrontendScreen::Title:
      if(confirm)enter(FrontendScreen::SaveSelect);
      break;
    case FrontendScreen::SaveSelect:
      if(up)selectedSlot_=(selectedSlot_+2)%3;
      if(down)selectedSlot_=(selectedSlot_+1)%3;
      if(cancel){enter(FrontendScreen::Title);break;}
      if(confirm&&!launchPending_){
        auto& s=slots_[(size_t)selectedSlot_];
        if(!s.exists){s.exists=true;s.currentLevel="lakeside-limbo";s.percent=0;s.playSeconds=0;s.persistent=GamePersistentState{};writeSlot(selectedSlot_);}
        activeSlot_=selectedSlot_;
        launch_.slot=selectedSlot_+1;launch_.level=s.currentLevel.empty()?"lakeside-limbo":s.currentLevel;launch_.persistent=s.persistent;if(launch_.persistent.lives<=0){launch_.persistent.lives=5;launch_.persistent.partnerAvailable=true;}launch_.worldMap=s.worldMap;launchPending_=true;
      }
      break;
  }
  prev_=in;
}

bool Frontend::takeLaunchRequest(FrontendLaunchRequest& out){
  if(!launchPending_)return false;
  out=launch_;
  launchPending_=false;
  return true;
}

bool Frontend::syncActiveSave(const std::string& level,const GamePersistentState& persistent,const WorldMapState* worldMap){
  if(activeSlot_<0||activeSlot_>=3)return false;
  auto& s=slots_[(size_t)activeSlot_];s.exists=true;s.currentLevel=level.empty()?"lakeside-limbo":level;s.persistent=persistent;if(worldMap)s.worldMap=*worldMap;return writeSlot(activeSlot_);
}

void Frontend::render(uint32_t* dst,int w,int h) const{
  if(!dst||w<=0||h<=0)return;
  hudFillRect(dst,w,h,0,0,w,h,0x000000u,255);

  auto drawSheet=[&](const Bitmap& sheet){
    if(sheet.w<=0||sheet.h<=0||sheet.bgra.empty())return false;
    for(int y=0;y<h;++y)for(int x=0;x<w;++x)
      dst[(size_t)y*w+x]=sheet.bgra[(size_t)(y*sheet.h/h)*sheet.w+x*sheet.w/w]|0xff000000u;
    return true;
  };
  auto fade=[&](float opacity){
    const int gain=(int)(std::clamp(opacity,0.0f,1.0f)*256);
    for(size_t i=0;i<(size_t)w*h;++i){const auto c=dst[i];dst[i]=0xff000000u|
      ((((c>>16)&255)*gain>>8)<<16)|((((c>>8)&255)*gain>>8)<<8)|((c&255)*gain>>8);}
  };
  if(screen_==FrontendScreen::GameOver){
    if(!drawSheet(gameOverSheet_))centerText(dst,w,h,h/2,"GAME OVER",0xffffffffu,2);
    fade(screenTime_/0.35f);
    if(screenTime_>=0.5f){hudFillRect(dst,w,h,0,h-20,w,20,0x000000u,160);centerText(dst,w,h,h-14,"START: VOLTAR AO TITULO",0xffffffffu,1);}
    return;
  }

  // Original publisher/studio/title crops supplied by the user; ROM fallback retained.
  if(screen_==FrontendScreen::BootPublisher||screen_==FrontendScreen::BootStudio){
    const auto& sheet=screen_==FrontendScreen::BootPublisher?publisherSheet_:studioSheet_;
    drawSheet(sheet);
    fade(std::min(screenTime_/0.25f,(1.25f-screenTime_)/0.25f));
    return;
  }

  if(screen_==FrontendScreen::Title){
    if(drawSheet(titleSheet_)){fade(screenTime_/0.25f);const bool on=((int)(titleBlink_*2.0f)&1)==0;if(on){hudFillRect(dst,w,h,63,194,130,18,0x000000u,180);centerText(dst,w,h,199,"PRESSIONE START",0xffffffffu,1);}}
    else if(romVisuals_.valid()&&romVisuals_.title().size()==(size_t)w*(size_t)h){
      std::copy(romVisuals_.title().begin(),romVisuals_.title().end(),dst);
      // Only the interaction hint is native overlay; all background/logo pixels come from ROM.
      const bool on=((int)(titleBlink_*2.0f)&1)==0;
      if(on){hudFillRect(dst,w,h,63,194,130,18,0x000000u,180);centerText(dst,w,h,199,"PRESSIONE START",0xffffffffu,1);}
    }else{
      centerText(dst,w,h,90,"ROM ORIGINAL NECESSARIA",0xffffffffu,1);
      centerText(dst,w,h,108,"rom/dkc3_ptbr.sfc",0xffc0c0c0u,1);
    }
    return;
  }

  if(romVisuals_.valid()&&romVisuals_.fileSelect().size()==(size_t)w*(size_t)h)
    std::copy(romVisuals_.fileSelect().begin(),romVisuals_.fileSelect().end(),dst);
  else hudFillRect(dst,w,h,0,0,w,h,0x07131fu,255);

  // Native save values are overlaid on the original ROM file-select background.
  for(int i=0;i<3;++i){
    const int y=33+i*50;const bool sel=i==selectedSlot_;const auto& slot=slots_[(size_t)i];
    if(sel)hudOutlineRect(dst,w,h,8,y,177,42,0xffffe080u);
    hudDrawText(dst,w,h,18,y+5,"ARQUIVO "+std::to_string(i+1),sel?0xffffe080u:0xffffffffu,1);
    if(!slot.exists){
      hudDrawText(dst,w,h,18,y+21,"NOVO JOGO",0xff90e090u,1);
    }else{
      const std::string who=slot.persistent.activeCharacter==CharacterId::Kiddy?"KIDDY":"DIXIE";
      hudDrawText(dst,w,h,18,y+21,who+"  "+std::to_string(std::clamp(slot.percent,0,103))+"%",0xffffffffu,1);
    }
  }
  hudFillRect(dst,w,h,42,203,172,14,0x000000u,180);
  centerText(dst,w,h,207,"ENTER CONFIRMAR   X VOLTAR",0xffffffffu,1);
}

}
