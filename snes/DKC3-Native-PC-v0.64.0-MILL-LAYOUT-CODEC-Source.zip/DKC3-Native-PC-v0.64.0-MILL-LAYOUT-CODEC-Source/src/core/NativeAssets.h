#pragma once
#include "RomData.h"
#include "RomMotion.h"
#include "RomAnimal.h"
#include "RomControl.h"
#include "RomSteelKeg.h"
#include <map>
#include <memory>

namespace dkc3 {
// Values are decoded by the existing ROM readers at build time. No machine
// state, compressed ROM data, or ROM image is carried into this package.
struct NativePlacementAssets {
  Rect triggerBounds{};
  RomSpawnSpec child{};
  RomSteelProfile steel{};
};
struct NativeRuntimeAssets {
  RomInfo source;
  RomFrontendVisuals frontend;
  RomWorldMapVisuals worldMap;
  RomLakeOrangatangaVisuals lakeMap;
  std::map<uint16_t,RomLevelRuntime> levels;
  std::map<uint16_t,std::vector<RomLevelPlacement>> placementStreams;
  std::array<RomLakesideBonusVisuals,2> bonuses;
  RomMotionProfile dixie,kiddy,ellieDixie,ellieKiddy;
  RomEllieVisuals ellie;
  std::vector<RomSpriteFrame> bird;
  std::array<RomObjectReward,19> rewards;
  RomKoinChildren koinChildren;
  RomKoinAimProfile koinAim;
  std::map<uint16_t,RomSpriteFrame> graphics;
  std::map<uint16_t,std::vector<NativePlacementAssets>> placementAssets;
};
bool extractNativeAssets(const std::string& romPath,NativeRuntimeAssets& out,std::string& error);
bool writeNativeAssets(const std::string& path,const NativeRuntimeAssets& assets,std::string& error);
bool readNativeAssets(const std::string& path,NativeRuntimeAssets& out,std::string& error);
// Explicit paths passed to the ROM loaders remain reference/tooling reads.
// Empty paths select DKC3_ASSET_MODE=auto|native|rom (auto is the default).
std::shared_ptr<const NativeRuntimeAssets> runtimeNativeAssets(std::string& error);
std::string nativeAssetPath();
std::string nativeAssetMode();
}
