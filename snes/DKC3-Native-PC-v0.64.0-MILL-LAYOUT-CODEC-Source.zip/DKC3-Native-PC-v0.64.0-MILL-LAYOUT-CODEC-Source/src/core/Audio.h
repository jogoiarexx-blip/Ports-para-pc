#pragma once
#include <cstdint>
#include <vector>
namespace dkc3 {
// v0.9.0: efeitos sonoros 100% sinteticos (sem samples, sem ROM). O Game emite eventos Sfx;
// a plataforma consome e alimenta o SfxMixer, que gera PCM 16-bit mono em 22050 Hz.
enum class Sfx : uint8_t { Jump, Land, Coin, Stomp, Roll, EnemyHit, Hurt, Checkpoint, Lever, Switch, Door, Locked, Splash, Count };
const char* sfxName(Sfx s);
float sfxDuration(Sfx s);  // segundos
class SfxMixer {
 public:
  static constexpr int kRate = 22050;
  static constexpr int kMaxVoices = 12;
  void trigger(Sfx s);
  void mix(int16_t* out, int frames);  // sobrescreve 'out' (silencio quando nao ha vozes)
  void setVolume(float v) { volume_ = v < 0 ? 0 : (v > 1 ? 1 : v); }
  float volume() const { return volume_; }
  void setMuted(bool m) { muted_ = m; }
  bool muted() const { return muted_; }
  int activeVoices() const { return (int)voices_.size(); }
  void clear() { voices_.clear(); }
 private:
  struct Voice { Sfx id; int n = 0; uint32_t rng = 1; float phase = 0, lp = 0; };
  std::vector<Voice> voices_;
  float volume_ = 0.6f; bool muted_ = false; uint32_t seed_ = 12345u;
};
}
