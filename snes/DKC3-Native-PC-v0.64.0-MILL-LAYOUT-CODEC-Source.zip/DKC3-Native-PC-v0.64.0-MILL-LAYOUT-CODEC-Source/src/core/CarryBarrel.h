#pragma once
#include "Math.h"
#include "RomSteelKeg.h"
#include <vector>
#include <cstdint>
namespace dkc3 {
class RomPierTerrain;
enum class CarryBarrelState { Resting, Carried, Thrown, Dropped, Broken };
struct CarryBarrelBody {
 Vec2 pos{},velocity{};float w=30,h=38;CarryBarrelState state=CarryBarrelState::Resting;
 double remainder=0;float age=0;
 uint16_t steelOam=0,steelTarget=0;RomSteelProfile steelProfile;
 Rect bounds()const{return {pos.x,pos.y,w,h};}
};
enum class CarryBarrelImpact { None, Terrain, Outside };
// Host fixed-60Hz integration; wood/DK speeds are tuning. Steel release uses ROM 8.8 words.
CarryBarrelImpact advanceCarryBarrel(CarryBarrelBody& barrel,float dt,const std::vector<Rect>& solids,const std::vector<Rect>& platforms,const RomPierTerrain* terrain,int width,int height);
struct SteelKegStep { bool outside=false,wall=false;uint16_t terrain=0; };
SteelKegStep advanceSteelKeg(CarryBarrelBody&,float dt,const std::vector<Rect>&,const std::vector<Rect>&,const RomPierTerrain*,int width,int height,uint16_t waterY=0xffff);
Rect carryBarrelSweepBounds(const CarryBarrelBody& barrel,Vec2 previous);
}
