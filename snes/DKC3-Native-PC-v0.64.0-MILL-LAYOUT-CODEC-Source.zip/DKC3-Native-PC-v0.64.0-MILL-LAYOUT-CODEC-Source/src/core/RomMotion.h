#pragma once
#include <cstdint>
#include <array>
#include <string>
namespace dkc3 {
struct RomMotionProfile {
  bool valid=false;
  uint32_t sourceAddress=0;
  std::array<int16_t,8> terrainLandingSpeeds{};
  int16_t risingGravity=0, fallingGravity=0, terminalSpeed=0, jumpImpulse=0;
  int16_t walkSpeed=0, runSpeed=0;
  int16_t swimGravity=0,swimTerminalSpeed=0;
  uint16_t groundInterpolation=0, airInterpolation=0;
};
// B8:C73A: original feet coordinate and water word, including CMP sign behavior.
enum class RomWaterState : uint8_t { Dry=0, Surface=1, Underwater=2 };
RomWaterState romWaterState(uint16_t waterY,uint16_t feetY);
bool loadRomMotionProfiles(const std::string& path, RomMotionProfile& dixie, RomMotionProfile& kiddy);
// Native arithmetic translations of B8:A035 and B9:F4B0 (mode 3/7/11).
int16_t romGravityStep(int16_t velocity, int16_t gravity, int16_t limit);
int16_t romInterpolateSpeed(int16_t velocity, int16_t target, uint16_t mode);
// Unladen, unmounted branch of B8:D4C2 followed by direction assignment.
int16_t romHorizontalTarget(const RomMotionProfile& profile, uint16_t controlFlags, bool left, bool right);
}
