#include "core/NativeAssets.h"
#include <iostream>
int main(int argc,char** argv){
  const std::string rom=argc>1?argv[1]:"rom/dkc3_ptbr.sfc";
  const std::string destination=argc>2?argv[2]:"assets/native/runtime.nassets";
  dkc3::NativeRuntimeAssets assets;std::string error;
  if(!dkc3::extractNativeAssets(rom,assets,error)||!dkc3::writeNativeAssets(destination,assets,error)){std::cerr<<error<<'\n';return 1;}
  const auto m=dkc3::romIoMetrics();std::cout<<destination<<": semantic package written; ROM load attempts="<<m.loadAttempts<<", file bytes="<<m.fileBytesRead<<", copied range bytes="<<m.rangeBytesRead<<'\n';
}
