#include "core/NativeReplay.h"
#include "core/LevelSession.h"
#include "core/NativeScene.h"
#include "core/NativeTrace.h"
#include "core/NativeAssets.h"
#include "core/input_recording.h"
#include <fstream>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <memory>
#include <optional>
#include <vector>
namespace {
void usage(){std::cerr<<"Usage: dkc3_native_replay boat|game input.txt trace.csv [level-id] [--trace-jsonl PATH] [--metrics PATH] [--no-render] [--frames N]\n";}
}
int main(int argc,char**argv){using namespace dkc3;
 try {
 if(argc<4){usage();return 2;}
 const std::string mode=argv[1];if(mode!="boat"&&mode!="game"){usage();return 2;}
 std::string levelId="lakeside-limbo",jsonPath,metricsPath;bool render=true;size_t limit=0;bool levelSet=false;
 for(int i=4;i<argc;++i){const std::string arg=argv[i];
  if(arg=="--no-render")render=false;
  else if(arg=="--trace-jsonl"||arg=="--metrics"||arg=="--frames"){
   if(++i>=argc){usage();return 2;}
   if(arg=="--trace-jsonl")jsonPath=argv[i];else if(arg=="--metrics")metricsPath=argv[i];else{std::string n=argv[i];size_t pos=0;if(n.empty()||n[0]=='-')return 2;limit=std::stoull(n,&pos);if(!limit||pos!=n.size())return 2;}
  }else if(!arg.starts_with("--")&&!levelSet){levelId=arg;levelSet=true;}else{usage();return 2;}
 }
 if(mode=="boat"&&!jsonPath.empty()){std::cerr<<"Semantic JSONL capture currently requires game mode\n";return 2;}
 NativeReplay replay;std::string error;if(!replay.load(argv[2],error)){std::cerr<<error<<"\n";return 3;}
 std::ofstream out(argv[3]);if(!out){std::cerr<<"Unable to write trace\n";return 4;}
 std::ofstream json;std::unique_ptr<TraceRecorder> tracer;
 if(!jsonPath.empty()){json.open(jsonPath);if(!json){std::cerr<<"Unable to write JSONL trace\n";return 4;}tracer=std::make_unique<TraceRecorder>(json);}
 resetRomIoMetrics();GameSession session;WorldMap map;
 if(mode=="boat"){if(!map.init({},""))return 5;map.setRuntimeAvailableMask(WorldMap::stageBit("lakeside-limbo"));}
 else if(!session.init("assets/levels/levels.index",levelId))return 5;
 const auto startup=romIoMetrics();
 out<<"frame,mask,mode,x,y,vx,vy,grounded,area,level,framehash,wall,air_wall,ground_follow\n"<<std::setprecision(9);
 Dkc3InputRecorder recorder{};char recordError[256]{};
 const char* recordPath=std::getenv("DKC3_NATIVE_INPUT_REC");
 if(recordPath&&!Dkc3InputRecorderOpen(&recorder,recordPath,recordError,sizeof recordError)){std::cerr<<recordError<<"\n";return 7;}
 std::vector<uint32_t> pixels(256*224);std::optional<TraceState> previous;
 const size_t count=limit?std::min(limit,replay.count()):replay.count();
 for(size_t i=0;i<count;++i){const auto mask=replay.frame(i);const auto before=romIoMetrics();
  if(tracer)tracer->beginFrame(i,mask);
  if(recordPath&&!Dkc3InputRecorderWrite(&recorder,mask,recordError,sizeof recordError)){std::cerr<<recordError<<"\n";Dkc3InputRecorderClose(&recorder,nullptr,0);return 7;}
  float x=0,y=0,vx=0,vy=0;bool ground=false;int area=-1;unsigned wall=0,air=0,follow=0;std::string level;
  if(mode=="boat"){map.step(nativeMapInputFromSnes(mask),1.f/60);if(render)map.render(pixels.data(),256,224);x=map.state().boatX;y=map.state().boatY;area=static_cast<int>(map.area());level=map.currentLevel();}
  else{session.step(nativeInputFromSnes(mask),1.f/60);if(render)session.render(pixels.data(),256,224);const auto&p=session.game().player();x=p.pos.x;y=p.pos.y;vx=p.vel.x;vy=p.vel.y;ground=p.grounded;wall=p.nativeWallHits;air=p.nativeAirWallHits;follow=p.nativeGroundFollows;level=session.currentLevel();}
  const uint64_t frameHash=render?hashFrame(pixels.data(),pixels.size()):0;
  out<<i<<','<<std::hex<<mask<<std::dec<<','<<mode<<','<<x<<','<<y<<','<<vx<<','<<vy<<','<<ground<<','<<area<<','<<level<<','<<std::hex<<frameHash<<std::dec<<','<<wall<<','<<air<<','<<follow<<'\n';
  if(tracer){TraceState state;session.appendTraceState(state);state.set("render.captured",render);if(render)state.set("render.frame_hash",frameHash);
   auto ev=traceStateEvents(previous?&*previous:nullptr,state);const auto io=romIoMetrics();
   TraceMetrics metrics{{"rom_load_attempts",io.loadAttempts-before.loadAttempts},{"rom_file_bytes",io.fileBytesRead-before.fileBytesRead},{"rom_range_bytes",io.rangeBytesRead-before.rangeBytesRead},{"rom_byte_view_requests",io.byteViewRequests-before.byteViewRequests},{"rom_exact_runtime_reads",std::nullopt},{"ppu_fallback_frames",std::nullopt},{"virtual_hardware_calls",std::nullopt},{"host_rendered_frames",render?1u:0u}};
   if(!tracer->endFrame(state,ev,metrics)){std::cerr<<"JSONL write failed\n";Dkc3InputRecorderClose(&recorder,nullptr,0);return 6;}previous=std::move(state);
  }
 }
 if(recordPath&&!Dkc3InputRecorderClose(&recorder,recordError,sizeof recordError)){std::cerr<<recordError<<"\n";return 7;}
 out.flush();if(tracer)json.flush();if(!out||(tracer&&!json)){std::cerr<<"Trace write failed\n";return 6;}
 if(!metricsPath.empty()){const auto total=romIoMetrics();std::ofstream m(metricsPath);if(!m)return 4;
  m<<"{\n  \"schema\":\"dkc3.metrics.v1\",\n  \"frames\":"<<count<<",\n  \"asset_mode\":"<<traceJsonString(std::getenv("DKC3_ASSET_MODE")?std::getenv("DKC3_ASSET_MODE"):"auto")<<",\n  \"startup_rom_load_attempts\":"<<startup.loadAttempts<<",\n  \"startup_rom_file_bytes\":"<<startup.fileBytesRead<<",\n  \"total_rom_load_attempts\":"<<total.loadAttempts<<",\n  \"total_rom_file_bytes\":"<<total.fileBytesRead<<",\n  \"total_rom_range_bytes\":"<<total.rangeBytesRead<<",\n  \"total_rom_byte_view_requests\":"<<total.byteViewRequests<<",\n  \"gameplay_rom_file_bytes\":"<<total.fileBytesRead-startup.fileBytesRead<<",\n  \"host_rendered_frames\":"<<(render?count:0)<<",\n  \"legacy_hardware_present\":false,\n  \"ppu_fallback_frames\":null,\n  \"original_cpu_coverage\":null,\n  \"original_game_equivalence\":null,\n  \"exact_rom_read_instructions\":null\n}\n";
  m.flush();if(!m)return 6;
 }
 std::cout<<"NATIVE_REPLAY_OK mode="<<mode<<" frames="<<count<<"\n";return 0;
 }catch(const std::exception& e){std::cerr<<"Replay failed: "<<e.what()<<"\n";return 2;}
}
