# Port packet: koin

ROM SHA256: `2277a2d8dddb01fe5cb0ae9a0fa225d42b3a11adccaeafa18e3c339b3794a32b`

This is an analysis packet, not generated game code or a complete translation.

# ROM B6A6C4..B6A718

Static reading only; no CPU/PPU execution. Bytes and operands come from the current ROM.

Catalog entry: CODE_B6A651 — entry M/X hint `0,0`; not an exit proof.

```text
B6A6C4  A5 1C       LDA $1C                  CODE_B6A6C4
B6A6C6  C5 1A       CMP $1A                  
B6A6C8  B0 16       BCS $B6A6E0              
B6A6CA  EB          XBA                      
B6A6CB  8D 04 42    STA $4204                
B6A6CE  E2 20       SEP #$20                 
B6A6D0  A5 1A       LDA $1A                  
B6A6D2  8D 06 42    STA $4206                
B6A6D5  C2 20       REP #$20                 
B6A6D7  22 03 80 B5 JSL $B58003              
B6A6DB  A0 18 A7    LDY #$A718               
B6A6DE  80 16       BRA $B6A6F6              
B6A6E0  A5 1A       LDA $1A                  CODE_B6A6E0
B6A6E2  EB          XBA                      
B6A6E3  8D 04 42    STA $4204                
B6A6E6  E2 20       SEP #$20                 
B6A6E8  A5 1C       LDA $1C                  
B6A6EA  8D 06 42    STA $4206                
B6A6ED  C2 20       REP #$20                 
B6A6EF  22 03 80 B5 JSL $B58003              
B6A6F3  A0 27 A7    LDY #$A727               
B6A6F6  AD 14 42    LDA $4214                CODE_B6A6F6
B6A6F9  1A          INC A                    
B6A6FA  C9 00 01    CMP #$0100               
B6A6FD  90 03       BCC $B6A702              
B6A6FF  A9 FF 00    LDA #$00FF               
B6A702  85 20       STA $20                  CODE_B6A702
B6A704  B9 00 00    LDA $0000,Y              CODE_B6A704
B6A707  29 FF 00    AND #$00FF               
B6A70A  C5 20       CMP $20                  
B6A70C  90 05       BCC $B6A713              
B6A70E  B9 01 00    LDA $0001,Y              
B6A711  18          CLC                      
B6A712  60          RTS                      
B6A713  C8          INY                      CODE_B6A713
B6A714  C8          INY                      
B6A715  C8          INY                      
B6A716  80 EC       BRA $B6A704              
```

## References

- BCC from `B6A691` to `B6A6C4`
- BCS at `B6A6C8` to `B6A6E0` CODE_B6A6E0
- JSL at `B6A6D7` to `B58003` stall_cpu_time
- BRA at `B6A6DE` to `B6A6F6` CODE_B6A6F6
- JSL at `B6A6EF` to `B58003` stall_cpu_time
- BCC at `B6A6FD` to `B6A702` CODE_B6A702
- BCC at `B6A70C` to `B6A713` CODE_B6A713
- BRA at `B6A716` to `B6A704` CODE_B6A704

## Native source leads (not coverage proof)

- `src/core/RomControl.cpp:44` — // branches of B6:A6C4. Tables are five {threshold byte, graphic word} rows.
- `src/core/RomControl.cpp:63` — // B6:A6C4..A716: word XBA dividend, byte divisor, word INC then clamp.

## Unknowns and obligations

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B6A6D7 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B6A6EF JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- Short memory operands require DBR/direct-page context; a source name or address mention alone does not establish a physical memory address.
- Preserve word wrap, carry/sign flags and memory offsets; verify the C++ with bounded original-routine oracles and input replays.

# ROM B6A742..B6A78E

Static reading only; no CPU/PPU execution. Bytes and operands come from the current ROM.

Catalog entry: CODE_B6A742 — entry M/X hint `0,0`; not an exit proof.

```text
B6A742  AC F9 04    LDY $04F9                CODE_B6A742
B6A745  22 03 C0 BE JSL $BEC003              
B6A749  90 18       BCC $B6A763              
B6A74B  B4 5C       LDY $5C,X                
B6A74D  A9 02 00    LDA #$0002               
B6A750  99 38 00    STA $0038,Y              
B6A753  A9 02 00    LDA #$0002               
B6A756  20 04 A6    JSR $A604                
B6A759  A9 01 00    LDA #$0001               
B6A75C  22 00 C8 BB JSL $BBC800              
B6A760  DC F5 04    JML [$04F5]              
B6A763  4C E6 85    JMP $85E6                CODE_B6A763
B6A766  20 0A C7    JSR $C70A                CODE_B6A766
B6A769  AC F9 04    LDY $04F9                
B6A76C  22 03 C0 BE JSL $BEC003              
B6A770  90 19       BCC $B6A78B              
B6A772  22 B7 80 B8 JSL $B880B7              
B6A776  90 13       BCC $B6A78B              
B6A778  A9 02 00    LDA #$0002               
B6A77B  20 04 A6    JSR $A604                
B6A77E  A9 01 00    LDA #$0001               
B6A781  22 00 C8 BB JSL $BBC800              
B6A785  20 A3 F1    JSR $F1A3                
B6A788  DC F5 04    JML [$04F5]              
B6A78B  4C E6 85    JMP $85E6                CODE_B6A78B
```

## References

- JSL at `B6A745` to `BEC003` CODE_BEC003
- BCC at `B6A749` to `B6A763` CODE_B6A763
- JSR at `B6A756` to `B6A604` CODE_B6A604
- JSL at `B6A75C` to `BBC800` CODE_BBC800
- JMP at `B6A763` to `B685E6` CODE_B685E6
- JSR at `B6A766` to `B6C70A` CODE_B6C70A
- JSL at `B6A76C` to `BEC003` CODE_BEC003
- BCC at `B6A770` to `B6A78B` CODE_B6A78B
- JSL at `B6A772` to `B880B7` CODE_B880B7
- BCC at `B6A776` to `B6A78B` CODE_B6A78B
- JSR at `B6A77B` to `B6A604` CODE_B6A604
- JSL at `B6A781` to `BBC800` CODE_BBC800
- JSR at `B6A785` to `B6F1A3` CODE_B6F1A3
- JMP at `B6A78B` to `B685E6` CODE_B685E6

## Native source leads (not coverage proof)


## Unknowns and obligations

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B6A745 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B6A756 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B6A75C JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B6A760: indirect control flow; target set requires a reviewed dispatch contract or RAM state.
- B6A766 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B6A76C JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B6A772 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B6A77B JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B6A781 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B6A785 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B6A788: indirect control flow; target set requires a reviewed dispatch contract or RAM state.
- Short memory operands require DBR/direct-page context; a source name or address mention alone does not establish a physical memory address.
- Preserve word wrap, carry/sign flags and memory offsets; verify the C++ with bounded original-routine oracles and input replays.

