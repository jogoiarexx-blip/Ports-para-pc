# Native Migration Implementation Plan

> **For agentic workers:** Use superpowers:executing-plans; independent file domains may use superpowers:dispatching-parallel-agents.

**Goal:** Deliver concrete migration infrastructure and reduced ROM dependency while retaining existing behavior.
**Architecture:** Extend existing loaders, renderer and workbench, with explicit extraction/runtime separation and evidence-bearing traces.
**Tech Stack:** C++20, Python 3 standard library.
**Spec:** ../specs/2026-10-06-native-migration.md

## Global Constraints
Preserve input routes, arithmetic and existing partial statuses. No invented full reference runtime. No embedded ROM replacement. Validate actual evidence; unknown coverage remains unknown.

## Review Focus
- Corrupt/truncated native packages fail without silently switching content.
- Traces must align frames and inputs; reconvergence cannot hide an earlier difference.
- Renderer masks/priority/half math must have pixel-exact expected cases.
- Source/index/ROM hashes must match before reporting verified addresses.
- Missing external reference cannot be represented as an original-game comparison.

## Tasks
- [x] Baseline: compile existing sources with GCC, run all existing C++/Python tests and save input traces.
- [x] Assets: test export/load equivalence; implement semantic package/extractor and runtime preference; verify without ROM, report remaining reads.
- [x] Renderer: write failing pixel tests, implement host operations/windows/sprites/scanlines; verify default rendering and corrected math.
- [x] Analyzer: test ROM-bound graph construction and trace linkage; generate first-level reports reusing workbench.
- [x] Trace: test divergence cases, add frame capture and native call instrumentation; expose JSONL capture in replay and structured comparator report.
- [x] Integration: compile all, run tests and unchanged input routes, compare baseline states, review changes, document exact metrics/limitations and package source.
