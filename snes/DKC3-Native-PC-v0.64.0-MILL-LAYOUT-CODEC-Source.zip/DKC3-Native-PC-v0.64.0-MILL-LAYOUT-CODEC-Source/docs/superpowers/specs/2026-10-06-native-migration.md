# Migração nativa baseada no pacote v0.60.0

O pedido completo está em Texto colado.txt. Objetivo: retirar dependências de ROM/hardware virtual com fidelidade e evidência, preservar traduções existentes, priorizar Lakeside Limbo e Doorstop Dash.

## Evidência da auditoria
O ZIP contém um runtime host C++20, extração ROM no carregamento, cenas NTIL/NMAP/NPAL, entidades parciais, SFX sintéticos e workbench estático. Não contém CPU dispatcher, PPU, DMA/HDMA ou SPC em execução. A referência DKC3Recomp é um executável externo não fornecido. Doorstop já é uma seção com assets próprios e lógica aproximada; não é a fase completa.

## Design desta implementação
1. Reutilizar loaders/decoders existentes para exportar dados semânticos e assets. Carregar pacote validado no runtime; ROM explícita continua disponível nas ferramentas de referência. Nenhum blob de ROM disfarçado de asset. Preservar resultados das extrações byte a byte e valores dos perfis.
2. Ampliar NativeScene com operações host de palette/tilemap/scroll/scanline, sprites com prioridade/flips e máscaras. Testar composição e limites. Não inventar padrões DMA/HDMA específicos sem trace da referência.
3. Reutilizar rom_workbench/index para ROM Trace → Native Map em JSON/Markdown, grafos e categorias com proveniência/nível de evidência. Endereços ambíguos e acesso indireto permanecem desconhecidos. Conectar traces semânticos reais; campos PC/opcode só para eventos de instruções realmente observados.
4. Trace JSONL por frame de inputs, estado de player/câmera/animação/objetos/transições, hash canônico e eventos de rotinas. Detector compara mesma sequência, acusa primeira divergência inclusive re-convergência, truncamento e input incompatível. Não atribuir causa confirmada a suspeitas nem chamar replay nativo de referência SNES.
5. Métricas medidas de arquivos ROM carregados/bytes lidos e acessos observáveis; cobertura original desconhecida é null, PPU fallback não aplicável. Validação baseline/replay e relatório honesto.

## Restrições
Sem regressão das rotas por input; sem teleporte/alteração de física para satisfazer teste. Sem promover objetos a SUPPORTED por indexação. Sem CPU/emulador novo. C++20/Python padrão. Build Windows permanece CMake/MSVC; executável Windows não comprovado neste ambiente Linux.
