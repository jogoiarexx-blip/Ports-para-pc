# Port packet: steel

ROM SHA256: `2277a2d8dddb01fe5cb0ae9a0fa225d42b3a11adccaeafa18e3c339b3794a32b`

This is an analysis packet, not generated game code or a complete translation.

# ROM BED960..BED975

Static reading only; no CPU/PPU execution. Bytes and operands come from the current ROM.

Catalog entry: CODE_BED920 — entry M/X hint `0,0`; not an exit proof.

```text
BED960  A9 00 FF    LDA #$FF00               CODE_BED960
BED963  95 2E       STA $2E,X                
BED965  A9 00 02    LDA #$0200               
BED968  34 58       BIT $58,X                
BED96A  50 04       BVC $BED970              
BED96C  49 FF FF    EOR #$FFFF               
BED96F  1A          INC A                    
BED970  95 2A       STA $2A,X                CODE_BED970
BED972  95 30       STA $30,X                
```

## References

- BNE from `BED94B` to `BED960`
- BVC at `BED96A` to `BED970` CODE_BED970

## Native source leads (not coverage proof)

- `src/core/RomSteelKeg.h:14` — // BE:D960..D974: signed 8.8 velocities; BIT $58 tests bit 14 (V).

## Unknowns and obligations

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- Truncated instruction at BED974
- Short memory operands require DBR/direct-page context; a source name or address mention alone does not establish a physical memory address.
- Preserve word wrap, carry/sign flags and memory offsets; verify the C++ with bounded original-routine oracles and input replays.

# ROM B9EC09..B9EC3C

Static reading only; no CPU/PPU execution. Bytes and operands come from the current ROM.

Catalog entry: CODE_B9EC09 — entry M/X hint `0,0`; not an exit proof.

```text
B9EC09  AD 0F 05    LDA $050F                CODE_B9EC09
B9EC0C  10 05       BPL $B9EC13              
B9EC0E  22 A0 EE B9 JSL $B9EEA0              CODE_B9EC0E
B9EC12  60          RTS                      
B9EC13  A6 70       LDX $70                  CODE_B9EC13
B9EC15  18          CLC                      
B9EC16  69 10 00    ADC #$0010               
B9EC19  D5 16       CMP $16,X                
B9EC1B  B0 F1       BCS $B9EC0E              
B9EC1D  B5 2A       LDA $2A,X                
B9EC1F  48          PHA                      
B9EC20  0A          ASL A                    
B9EC21  76 2A       ROR $2A,X                
B9EC23  0A          ASL A                    
B9EC24  76 2A       ROR $2A,X                
B9EC26  B5 2E       LDA $2E,X                
B9EC28  48          PHA                      
B9EC29  0A          ASL A                    
B9EC2A  76 2E       ROR $2E,X                
B9EC2C  0A          ASL A                    
B9EC2D  76 2E       ROR $2E,X                
B9EC2F  22 A0 EE B9 JSL $B9EEA0              
B9EC33  A6 70       LDX $70                  
B9EC35  68          PLA                      
B9EC36  95 2E       STA $2E,X                
B9EC38  68          PLA                      
B9EC39  95 2A       STA $2A,X                
B9EC3B  60          RTS                      
```

## References

- JSR from `B9EBFE` to `B9EC09`
- JSR from `B9EE27` to `B9EC09`
- JSR from `B9EE34` to `B9EC09`
- BPL at `B9EC0C` to `B9EC13` CODE_B9EC13
- JSL at `B9EC0E` to `B9EEA0` CODE_B9EEA0
- BCS at `B9EC1B` to `B9EC0E` CODE_B9EC0E
- JSL at `B9EC2F` to `B9EEA0` CODE_B9EEA0

## Native source leads (not coverage proof)

- `src/core/RomSteelKeg.h:11` — // B9:EC09..EC3B: temporary velocities for terrain, restored after the query.

## Unknowns and obligations

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B9EC0E JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B9EC2F JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- Short memory operands require DBR/direct-page context; a source name or address mention alone does not establish a physical memory address.
- Preserve word wrap, carry/sign flags and memory offsets; verify the C++ with bounded original-routine oracles and input replays.

# ROM B9F54F..B9F55E

Static reading only; no CPU/PPU execution. Bytes and operands come from the current ROM.

Catalog entry: CODE_B9F54F — entry M/X hint `0,0`; not an exit proof.

```text
B9F54F  4A          LSR A                    CODE_B9F54F
B9F550  4A          LSR A                    
B9F551  4A          LSR A                    
B9F552  4A          LSR A                    
B9F553  85 42       STA $42                  
B9F555  4A          LSR A                    
B9F556  4A          LSR A                    
B9F557  18          CLC                      
B9F558  65 42       ADC $42                  
B9F55A  60          RTS                      
B9F55B  4A          LSR A                    CODE_B9F55B
B9F55C  4A          LSR A                    
B9F55D  4A          LSR A                    
```

## References


## Native source leads (not coverage proof)

- `src/core/RomSteelKeg.cpp:20` — // B9:F4B0 -> mode 8 B9:F54F; N of word difference, two logical shifts.

## Unknowns and obligations

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- Short memory operands require DBR/direct-page context; a source name or address mention alone does not establish a physical memory address.
- Preserve word wrap, carry/sign flags and memory offsets; verify the C++ with bounded original-routine oracles and input replays.

