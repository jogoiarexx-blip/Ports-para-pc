# Sprites fornecidos — v0.48.0

A importação offline converte regiões explícitas das folhas em NSPR/NANIM.
O executável usa esses assets nativos: não lê folhas brutas, não emula a SNES.
`tools/import_supplied_sprites.py DIRETORIO_DAS_FOLHAS` reproduz a conversão;
requer Pillow e NumPy somente na ferramenta de importação, não no jogo.

## Seleção

Dixie: somente y >= 1467, seção rotulada DKC3. Idle/cabelo, idle na corda e
ícones de mapa. Correr, pular, cair, atacar e nadar mantêm os assets anteriores
extraídos da ROM. A seção DKC2 não foi importada. As poses pequenas da Dixie
são ampliadas 1,5x por vizinho mais próximo para alinhar os pés ao modelo.

Kremlings: somente as células do Kobble padrão no topo da folha. Oito quadros
de caminhada e três de derrota. Nenhuma área Unused ou paleta alternativa foi
importada. Os demais inimigos da folha não têm handlers ativos compatíveis e
ficam pendentes; não foram colocados como substitutos de Kobble/Sneek.

Kiddy: idle, correr, salto/queda, rolamento, natação, corda, abaixar e dano.
Poses de montaria/team-up não são usadas como movimentos normais.
Wrinkly: dez poses autorizadas para ordem livre na folha, na caverna existente.
Cadências nativas e poses foram escolhidas para os estados do port; não são
uma tradução integral dos estados ou do tempo das animações SNES.

Itens: banana, banana verde, Bear Coin, balão, estrela, Bonus Coin, KONG e
DK Barrel. Eventos de coleta e derrota geram efeitos temporários com limite
32 e remoção ao terminar. O DK Barrel usa a primeira pose compatível; carregar,
arremessar e quebrar foram adicionados na v0.49 com física nativa parcial. A troca visual mantém os triggers,
posições e caixas de colisão já existentes.

Apresentação: Nintendo, Rare, título e Game Over. Ao zerar vidas, o jogo mostra
a tela original e congela a simulação; R/Select reinicia pelo fluxo existente.
São quadros de apresentação, não uma reprodução animada da introdução SNES.

## Evidência

28 animações, 246 quadros e quatro telas. Manifesto contém fontes, SHA-256,
recortes, dimensões e origens. Fundos magenta/ciano/azul, legendas e grades
não são sprites. Créditos preservados em `assets/sprites/dkc3/CREDITS.txt`.

Capturas: `sprites-lakeside.png`, `sprites-tidal.png`, `sprites-wrinkly.png`.
Contato dos primeiros quadros: `assets/sprites/dkc3/import-preview.png`.
Os testes verificam transparência, âncoras dos pés, ciclos, vínculo de Kobble
/KONG, natação, Game Over/restart e mudança visual da Wrinkly por tempo.
O hash de render Lakeside foi atualizado após conferência visual da captura;
os hashes dos decoders da ROM continuam inalterados.

Na v0.51, 22 executaveis de testes passaram em Linux/GCC C++20 -O2. Os 80.000 casos da rotina de corda também passaram.
Não houve build nem execução do EXE Windows neste ambiente.
Sprites adicionais não concluem os 47 placements, o controlador ou a fase:
Lakeside permanece com 41 PARTIAL, 6 UNKNOWN e zero SUPPORTED.

Na v0.51 o barril comum ganhou oito frames da folha Objects & Effects, usados
pelos tres placements $02C0 de Lakeside. Total: 29 animacoes e 254 frames.
