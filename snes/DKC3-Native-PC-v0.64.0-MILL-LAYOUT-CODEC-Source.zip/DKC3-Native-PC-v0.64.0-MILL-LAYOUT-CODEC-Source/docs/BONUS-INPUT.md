# Bonus por input — estado atual v0.60.0

O Bonus 1 continua usando lakeside-bonus1-v050.txt (1480 frames).
O novo Bonus 2 usa lakeside-bonus2-v051.txt (4289 frames, entrada 2253).
O percurso combinado usa lakeside-both-bonuses-v054.txt (4942 frames).
Todos usam apenas input desde o spawn. O combinado coleta 50 estrelas,
15 bananas e duas moedas, passa no checkpoint e sai com cinco vidas.
Warp ainda falta. Consulte SPAWN-AND-LAKESIDE.md para limitacoes do controlador.

G + ambos bonus: lakeside-bird-and-bonuses-v055.txt, 4897 frames.
Ellie/Bear Coin + ambos bonus: lakeside-ellie-and-bonuses-v055.txt, 4802 frames.
DK Coin + Bonus 1: lakeside-koin-v057.txt, 1903 frames; termina na moeda.

Percurso ampliado: lakeside-extended-v059.txt, 6848 frames. Junta DK Coin,
50 estrelas, 15 bananas, recuperacao real do parceiro, Ellie/Bear Coin,
checkpoint e saida. Nao cobre Warp nem as quatro letras KONG; a rota G
continua separada. Teste repete com DK Coin e Bonus Coins ja coletadas.

Cenarios Tidal $54/5 e $55/6 carregam no runtime generico, inclusive mapas
sem chao. Isso ainda nao torna seus bonus jogaveis/concluiveis por input.
