# Caverna da Wrinkly — conferência e integração

## Conferência

Original: 1047×273, quatro quadros de 256×224. HD enviado: 2048×682,
com margem branca, separadores magenta e a faixa de créditos. Os recortes
exatos, hashes SHA-256 e uma matriz de distância de cores reduzida estão em
assets/scenes/wrinkly-cave/import-manifest.json. Os arquivos PNG de origem
permanecem íntegros. A classificação por cor favorece o mesmo índice 0/1/2/3,
mas isso não identifica a ordem de animação original.

A comparação visual confirma a mesma composição geral: prateleiras, móvel
verde, poltrona, luminária, tapete e barris nas mesmas regiões. Entretanto,
a versão HD altera detalhes: recipientes próximos da poltrona, contornos da
poltrona, desenho do tapete, livros e texturas. Portanto não foi aprovada como
reprodução que preserva exatamente todo o desenho. O original acompanha a
versão HD e pode ser selecionado a qualquer momento.

Os separadores e textos foram excluídos dos assets do cenário. Os quatro
quadros HD foram normalizados para 512×448 a partir dos recortes da imagem
fornecida; esse tamanho é a resolução do framebuffer, não detalhe novo criado.
O original usa nearest-neighbor; o HD usa interpolação ao mudar de tamanho.
Nenhuma arte foi regenerada. Credito do rip: A.J. Nitro.

## Integração

WrinklyCave é uma cena de apresentação nativa C++, vinculada ao WorldMap.
C/Y abre a cena; C/Y novamente alterna os gráficos; Enter/Z/A pede save;
X/Backspace/B fecha. O mapa congela e o estado geográfico é preservado.
A aplicação Windows consome o pedido com Frontend::syncActiveSave e só
mostra sucesso quando a gravação retorna sucesso. O cenário é apresentado
em 512×448 diretamente, antes do redimensionamento final da janela.

Não havia caverna no port anterior. Esta entrega acrescenta acesso por atalho
no mapa, sem inventar coordenadas para uma entrada ROM. O acesso original,
o sequenciamento original do cenário continuam pendentes.
A v0.49.0 adiciona a Wrinkly com dez poses da folha enviada. A folha autoriza
qualquer ordem dessas poses; a cadência nativa de 180ms não reproduz uma
rotina SNES medida. A interação de save mantém o sistema existente.
A folha original declara a ordem dos frames aleatória: por isso o quadro 0
fica estático até existir evidência do sequenciamento real.

## Evidência

- docs/wrinkly-comparacao.png: original versus HD enviado.
- docs/wrinkly-runtime-hd.png: render nativo com controles.
- docs/wrinkly-runtime-saved.png: render nativo após save validado.
- docs/VALIDACAO-v0.49.0.txt: 18 executáveis de teste aprovados.
- tests/wrinkly_tests.cpp: assets, render HD/original, ausência de magenta,
  entrada/saída por input, mapa parado, save por borda de botão e releitura.

Os testes C++ foram executados no Linux/GCC C++20. O código Win32 foi
inspecionado, mas o EXE Windows não foi compilado ou executado neste ambiente.
