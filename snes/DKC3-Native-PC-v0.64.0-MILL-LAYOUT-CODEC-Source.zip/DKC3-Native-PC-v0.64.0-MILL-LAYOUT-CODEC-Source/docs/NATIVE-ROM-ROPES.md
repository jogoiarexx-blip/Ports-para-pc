# Mudancas jogaveis e evidencia

## Salas dos bonus

A selecao antiga somava contagens de colunas incorretas para PierLevels. O
cabecalho de nivel em FD:0000 identifica Bonus 1 ($50) em FD:0ED8, submapa 3,
e Bonus 2 ($51) em FD:0EF1, submapa 4; ambos referenciam shared_data FD:19F0.
A tabela de limites B7:B431 tem cabecalho de 9 bytes e registros de 10 bytes.
O loader agora le o subindice e o spawn do cabecalho do nivel, e os limites
X dos registros diretamente da ROM. Uma coluna corresponde a 32 pixels e
16 metatiles verticais, 32 bytes de mapa por coluna.

| Sala | Limites X no mapa combinado | Colunas | Dimensoes | Corda horizontal local |
|---|---|---|---|---|
| Bonus 1 | $3780..$3900 | 444..455 | 384x512 | x=64..320, y=145 |
| Bonus 2 | $3900..$3A80 | 456..467 | 384x512 | x=32..224, y=273 |

Os trechos anteriores, colunas 771/819 e larguras 48/32 colunas, nao eram
estas salas. As posicoes dos itens mantem os mesmos dados ja decodificados;
a correcao faz o cenario corresponder a essas posicoes. Os pisos usam os
14/3 segmentos de formas de colisao da ROM. A antiga deteccao por opacidade
foi removida. Os spawns locais (16,233) e (40,361) vem do cabecalho original;
removeu-se o deslocamento host de +4 pixels que penetrava a primeira plataforma.

## Controlador nativo

RomPierTerrain constrói segmentos horizontais por pixel a partir da forma
$40: altura 15 e flag $0800 em B7:CF68. Nao procura linhas coloridas na imagem.
A captura exige alcance/contacto com esses segmentos; o retangulo livre
x<340/y=145..360 foi eliminado. A altura fica fixada ao segmento enquanto
pendurado. O corpo nativo usa centro X e offset de mao de 40 pixels em relacao
aos pes; esta e a adaptacao para os probes originais B8:C990 e adjacentes.
O contato durante a descida pode agarrar automaticamente, ou CIMA pode ajudar
quando proximo. Nenhum comando move verticalmente numa corda horizontal.

A velocidade basica horizontal usa alvo +/-$0080 de B8:D55C/D566 e
interpolacao modo $000B (B9:F584, magnitude >> 3). O tick move pelo valor
anterior da velocidade, como B8:A4C9, antes de recalcular. Usa tick de 60Hz;
30/60Hz de chamada produzem o mesmo resultado. Velocidade/fração permanecem
nativas; o runtime nao executa instrucoes da ROM.

A resposta B8:A4A0..A4C8 foi traduzida em C++ para a variante sem deslizamento:
comparacoes unsigned dos limites, escolha da direcao $FFFF/$0001, snap do X,
zero da fracao/alvo/velocidade ao ultrapassar a ponta. Igualdade preserva a
fracao, como no original; admite fracao menor que um pixel na ponta.
Nao se afirma que os probes do corpo, animacoes e todo o despacho dos estados
08/09/0B/0C estejam traduzidos.

B + direcao lateral sai com o impulso +/-$0280 de B8:D82F..D842. B + baixo
larga a corda; a gravidade/queda e a breve protecao de reagarre ainda sao
adaptadores do host. Escalada vertical e cordas com deslizamento nao foram
integradas nesta entrega. As salas atuais usam somente cordas horizontais.

## Percurso verificado

O fixture coloca o personagem no barril de entrada em Lakeside apenas para
iniciar a sala de teste. Apos a transicao, nao reposiciona o personagem:
10 ticks de espera, 20 ticks correndo a direita, 16 ticks com pulo e corrida,
soltura do pulo e descida ate agarrar. Passa com Dixie e Kiddy e coleta itens.
A captura de Dixie apos mais 50 ticks mostra 7 estrelas coletadas e 18.2s
restantes. E um percurso real curto, nao prova conclusao das 50 estrelas.

A sonda test-only executa as instrucoes reais da ROM entre B8:A4A0 e o RTS,
com M/X de 16 bits, ramo sem deslizamento. 80000 casos (bordas, igualdade,
fracao, alvos/velocidades/direcoes e valores unsigned altos) coincidem com C++.
Esta sonda so e compilada no executavel de teste. Os testes anteriores de
objetivo/Bonus Coin/retorno/save continuam usando posicoes injetadas e sao
reportados como fixtures, sem alegar playthrough completo.
