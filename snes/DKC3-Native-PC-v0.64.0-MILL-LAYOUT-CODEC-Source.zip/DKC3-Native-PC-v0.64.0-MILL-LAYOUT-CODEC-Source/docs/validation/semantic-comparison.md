# Trace comparison

Status: **match**.

Validated frames: left 6848, right 6848; aligned 6848. All state fields and inputs compared.

Native-to-native comparison establishes replay repeatability only. Reference provenance labels are supplied by the producer; this tool does not authenticate SNES execution or establish a confirmed cause.
