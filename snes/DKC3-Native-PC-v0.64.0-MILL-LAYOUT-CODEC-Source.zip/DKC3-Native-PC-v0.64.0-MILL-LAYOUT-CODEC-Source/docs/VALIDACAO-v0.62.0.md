# Validação v0.62.0 — 6 de outubro de 2026

## Resultado desta rodada

A v0.62.0 não tenta declarar Doorstop Dash como portada. O objetivo estrutural foi remover a dependência entre **auditoria de placements/objetos** e **codec de cenário/terreno**. A ferramenta agora consegue ler o stream de placements `FE`, executar semanticamente os spawn scripts `FF` já suportados e resolver Sprite IDs de uma fase mesmo quando o renderer/codec visual daquele cenário ainda não existe.

| Verificação | Resultado |
| --- | --- |
| Configuração/build CMake, C++20 | concluído no Linux com CMake 3.31.6 / GCC 14.2.0 |
| CTest final em paralelo | **36/36 passaram**, 0 falhas, 15,46 s |
| Teste isolado das áreas alteradas | `native_rom_data`, `native_spawn_script`, `native_assets`: **3/3 passaram** |
| Testes Python do native map | **11/11 passaram** |
| Doorstop por nome | **118 placements**, 118/118 com Sprite ID, 56 PARTIAL, 62 UNKNOWN |
| Doorstop por ID numérico `0x28` | saída byte a byte idêntica à auditoria por nome |
| Native map | 134 rotinas, 1.706 nós, 2.731 arestas; 2 níveis catalogados |
| Lakeside no native map | 47/47 placements com Sprite ID; 47 PARTIAL |
| Doorstop no native map | 118/118 placements com Sprite ID; 56 PARTIAL, 62 UNKNOWN |

Nenhum objeto UNKNOWN foi promovido artificialmente. A resolução do Sprite ID é evidência de identidade de spawn, não prova de que o comportamento original já esteja implementado.

## Gargalo removido

Até a v0.61.0, `dkc3_native_rom_audit` carregava `RomLevelRuntime`. Isso significava que a ferramenta só conseguia listar os objetos de uma fase depois que o codec completo do cenário daquela família já estivesse implementado. Doorstop usa shared data MILL `$198D`, enquanto o runtime atual decodifica PIER; portanto os **118 placements de Doorstop apareciam sem resolução útil** para orientar a migração.

Na v0.62.0 foi criada a API pública `decodeRomLevelPlacements(...)`. Ela lê o pointer/stream de placements da ROM e reutiliza o decoder de spawn scripts sem exigir `RomLevelRuntime`, terreno, tilemap ou renderer da fase. O auditor C++ passou a trabalhar diretamente sobre `RomImage` e também aceita IDs numéricos de nível.

## Doorstop: prioridade real descoberta

O novo audit produz:

`placements=118 SUPPORTED=0 PARTIAL=56 UNKNOWN=62`

Entre os 62 placements ainda UNKNOWN, quatro famílias concentram **57/62 (91,9%)** das lacunas:

| Sprite ID | Quantidade |
| --- | ---: |
| `0x038C` | 15 |
| `0x02FC` | 14 |
| `0x0390` | 14 |
| `0x0394` | 14 |

Os restantes são `0x0144` (3) e `0x027C` (2). A identidade dessas famílias não foi inventada a partir do desenho host; deve ser confirmada pelo workbench/ROM antes de escrever handlers. O relatório detalhado está em `DOORSTOP-MIGRATION-PRIORITY.md` e a evidência bruta em `DOORSTOP-SPAWN-AUDIT.txt`.

## Regressão preservada

Antes do fechamento desta versão, as rotas de replay já usadas como referência foram novamente comparadas entre a extração direta da ROM e o pacote nativo:

- Lakeside: `lakeside-extended-v059.txt`, **6.848 frames**, CSV ROM × native idêntico.
- Tidal: `tidal-trouble-route-v049.txt`, **6.243 frames**, CSV ROM × native idêntico.
- Em ambos os replays, o modo native permaneceu com **0 tentativas de abrir a ROM**, **0 bytes do arquivo ROM lidos** e o mesmo número de frames renderizados.
- Para Lakeside no modo ROM, a medição de referência continua em 15 tentativas de carga e 62.914.560 bytes de arquivo acumulados no carregamento; isso inclui releituras do arquivo de 4 MiB e não representa conteúdo distinto.

Essas comparações protegem o comportamento já coberto, mas não provam conclusão integral das fases originais.

## Pacote nativo preservado

`assets/native/runtime.nassets` não precisou mudar nesta rodada.

- Tamanho: **48.129.769 bytes**.
- SHA256: `c7db06557f79ab7d73848fb31907ce759c79265f92eded71ec3a92ae590c6c2c`.

A alteração é de ferramenta/arquitetura de migração e não altera o formato do asset pack.

## Limites desta conclusão

- O codec completo do cenário MILL `$198D` ainda não foi implementado.
- Doorstop ainda usa seção host e não equivale à fase original completa.
- Os 62 placements UNKNOWN ainda precisam de handlers/contratos confirmados na ROM.
- `SUPPORTED` continua reservado para comportamentos realmente implementados e validados.
- O executável Windows/MSVC não foi compilado neste ambiente Linux; os testes desta entrega cobrem a base CMake/GCC e as ferramentas/replays disponíveis aqui.

O próximo alvo de maior impacto é investigar e implementar, com evidência da ROM, as famílias `0x038C`, `0x0390`, `0x0394` e `0x02FC`, que representam 91,9% dos placements UNKNOWN atuais de Doorstop; em paralelo, avançar o codec MILL `$198D` para substituir a geometria/arte host pela original.
