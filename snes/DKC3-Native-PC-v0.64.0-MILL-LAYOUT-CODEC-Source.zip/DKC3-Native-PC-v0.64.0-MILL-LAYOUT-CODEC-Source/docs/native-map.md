# ROM Trace → Native Map

ROM SHA256: `2277a2d8dddb01fe5cb0ae9a0fa225d42b3a11adccaeafa18e3c339b3794a32b`

No CPU/PPU execution. Static bounded spans and source mentions are leads, not complete functions or runtime coverage. External DKC3Recomp reference executable is not supplied in this ZIP.

Selected 134 bounded routine spans; 1706 graph nodes and 2731 edges. Original runtime coverage: unknown.
Traversal depth 1; routine limit 256; truncated: False.

## Dependency graph excerpt

The JSON contains the complete selected graph. This excerpt combines control, bank and table dependencies; it does not show an observed call stack.

```mermaid
flowchart TD
  n0["kong_state_handler B89F3A..B89F50"]
  n1["bank:B8"]
  n0 -->|in_bank| n1
  n2["kong_state_table"]
  n0 -->|dispatch_table| n2
  n3["kong_state_00 entry"]
  n2 -->|dispatch_target| n3
  n4["kong_state_01 entry"]
  n2 -->|dispatch_target| n4
  n5["kong_state_02 entry"]
  n2 -->|dispatch_target| n5
  n6["kong_state_00 B8A37E..B8A39C"]
  n3 -->|bounded_span_definition| n6
  n6 -->|in_bank| n1
  n7["kong_state_01 B8A39C..B8A3AE"]
  n4 -->|bounded_span_definition| n7
  n7 -->|in_bank| n1
  n8["kong_state_02 B8A3AE..B8A3C6"]
  n5 -->|bounded_span_definition| n8
  n8 -->|in_bank| n1
```

## Routine spans

| Span | Name | Heuristic category | Destination | Instructions | Native leads |
|---|---|---|---|---:|---:|
| `B89F3A..B89F50` | kong_state_handler | gameplay | native_logic | 12 | 0 |
| `B8C6DE..B8C73A` | CODE_B8C6DE | unknown | unknown | 38 | 0 |
| `B9EEA0..B9F13A` | CODE_B9EEA0 | unknown | unknown | 295 | 5 |
| `B9F060..B9F13A` | CODE_B9F060 | unknown | unknown | 90 | 2 |
| `B28012..B28015` | queue_sound_effect | audio | native_audio | 1 | 0 |
| `B28000..B28009` | upload_spc_engine | audio | native_audio | 3 | 0 |
| `B8A37E..B8A39C` | kong_state_00 | gameplay | native_logic | 10 | 0 |
| `B8A39C..B8A3AE` | kong_state_01 | gameplay | native_logic | 6 | 0 |
| `B8A3AE..B8A3C6` | kong_state_02 | gameplay | native_logic | 8 | 0 |
| `B8A3C6..B8A3F2` | kong_state_03 | gameplay | native_logic | 17 | 0 |
| `B8A43A..B8A44C` | kong_state_05 | gameplay | native_logic | 6 | 0 |
| `B8A44C..B8A44F` | kong_state_06 | gameplay | native_logic | 1 | 0 |
| `B8A44F..B8A452` | kong_state_07 | gameplay | native_logic | 1 | 0 |
| `B8A452..B8A493` | kong_state_08 | gameplay | native_logic | 23 | 0 |
| `B8A53B..B8A57C` | kong_state_09 | gameplay | native_logic | 24 | 0 |
| `B8A57C..B8A591` | kong_state_0A | gameplay | native_logic | 7 | 0 |
| `B8A591..B8A5D2` | kong_state_0B | gameplay | native_logic | 24 | 0 |
| `B8A613..B8A669` | kong_state_0C | gameplay | native_logic | 31 | 0 |
| `B8A669..B8A676` | kong_state_0D | gameplay | native_logic | 4 | 0 |
| `B8A676..B8A68E` | kong_state_0F | gameplay | native_logic | 8 | 0 |
| `B8A68E..B8A6A6` | kong_state_10 | gameplay | native_logic | 9 | 0 |
| `B8A6A6..B8A6BB` | kong_state_11 | gameplay | native_logic | 7 | 0 |
| `B8A6BB..B8A6C7` | kong_state_12 | gameplay | native_logic | 4 | 0 |
| `B8A6C7..B8A6EB` | kong_state_13 | gameplay | native_logic | 13 | 0 |
| `B8A6EB..B8A724` | kong_state_14 | gameplay | native_logic | 22 | 0 |
| `B8A724..B8A72D` | kong_state_15 | gameplay | native_logic | 3 | 0 |
| `B8A72D..B8A763` | kong_state_16 | gameplay | native_logic | 20 | 0 |
| `B8A805..B8A85F` | kong_state_17 | gameplay | native_logic | 33 | 0 |
| `B8A85F..B8A874` | kong_state_18 | gameplay | native_logic | 8 | 0 |
| `B8A874..B8A884` | kong_state_19 | gameplay | native_logic | 4 | 0 |
| `B8A8E0..B8A903` | kong_state_1A | gameplay | native_logic | 13 | 0 |
| `B8A903..B8A955` | kong_state_1B | gameplay | native_logic | 33 | 0 |
| `B8AA07..B8AA2F` | kong_state_1C | gameplay | native_logic | 15 | 0 |
| `B8AA2F..B8AB80` | kong_state_1D | gameplay | native_logic | 125 | 0 |
| `B8A955..B8A9AF` | kong_state_1E | gameplay | native_logic | 36 | 0 |
| `B8AB80..B8AB97` | kong_state_1F | gameplay | native_logic | 9 | 0 |
| `B8AB97..B8ABB3` | kong_state_20 | gameplay | native_logic | 10 | 0 |
| `B8ABB3..B8ABCF` | kong_state_21 | gameplay | native_logic | 9 | 0 |
| `B8ABCF..B8AC29` | kong_state_22 | gameplay | native_logic | 37 | 0 |
| `B8AC29..B8AC3E` | kong_state_23 | gameplay | native_logic | 7 | 0 |
| `B8AC3E..B8AC56` | kong_state_24 | gameplay | native_logic | 8 | 0 |
| `B8AC56..B8AC78` | kong_state_25 | gameplay | native_logic | 12 | 0 |
| `B8AC94..B8ACA9` | kong_state_26 | gameplay | native_logic | 7 | 0 |
| `B8ACA9..B8ACC1` | kong_state_27 | gameplay | native_logic | 8 | 0 |
| `B8ACC1..B8ACD6` | kong_state_28 | gameplay | native_logic | 7 | 0 |
| `B8ACD6..B8ACFA` | kong_state_29 | gameplay | native_logic | 13 | 0 |
| `B8ACFA..B8AD12` | kong_state_2A | gameplay | native_logic | 8 | 0 |
| `B8AD12..B8AD28` | kong_state_2B | gameplay | native_logic | 8 | 0 |
| `B8AD28..B8AD3A` | kong_state_2C | gameplay | native_logic | 6 | 0 |
| `B8AD3A..B8AD5C` | kong_state_2D | gameplay | native_logic | 13 | 0 |
| `B8AE19..B8AE2C` | kong_state_2E | gameplay | native_logic | 6 | 0 |
| `B8AE2C..B8AE4E` | kong_state_2F | gameplay | native_logic | 13 | 0 |
| `B8AE4E..B8AE81` | kong_state_30 | gameplay | native_logic | 19 | 0 |
| `B8AE81..B8AE94` | kong_state_31 | gameplay | native_logic | 6 | 0 |
| `B8AE94..B8AEB5` | kong_state_32 | gameplay | native_logic | 10 | 0 |
| `B8AEB5..B8AEDB` | kong_state_33 | gameplay | native_logic | 13 | 0 |
| `B8AEDB..B8AF11` | kong_state_34 | gameplay | native_logic | 22 | 0 |
| `B8AF11..B8AF27` | kong_state_35 | gameplay | native_logic | 9 | 0 |
| `B8AF27..B8AF3D` | kong_state_36 | gameplay | native_logic | 8 | 0 |
| `B8AF3D..B8AFBF` | kong_state_37 | gameplay | native_logic | 55 | 0 |
| `B8AFBF..B8AFD8` | kong_state_38 | gameplay | native_logic | 8 | 0 |
| `B8AFD8..B8AFEF` | kong_state_39 | gameplay | native_logic | 9 | 0 |
| `B8AFEF..B8B086` | kong_state_3A | gameplay | native_logic | 56 | 0 |
| `B8B0D3..B8B115` | kong_state_3B | gameplay | native_logic | 28 | 0 |
| `B8B115..B8B137` | kong_state_3C | gameplay | native_logic | 8 | 0 |
| `B8B5D5..B8B5F0` | kong_state_3D | gameplay | native_logic | 9 | 0 |
| `B8B5F0..B8B614` | kong_state_3E | gameplay | native_logic | 14 | 0 |
| `B8B614..B8B627` | kong_state_3F | gameplay | native_logic | 6 | 0 |
| `B8B627..B8B62A` | kong_state_40 | gameplay | native_logic | 1 | 0 |
| `B8B62A..B8B630` | kong_state_41 | gameplay | native_logic | 2 | 0 |
| `B8B630..B8B67B` | kong_state_42 | gameplay | native_logic | 25 | 0 |
| `B8B67B..B8B694` | kong_state_43 | gameplay | native_logic | 8 | 0 |
| `B8B694..B8B6AD` | kong_state_44 | gameplay | native_logic | 8 | 0 |
| `B8B6AD..B8B6C0` | kong_state_45 | gameplay | native_logic | 6 | 0 |
| `B8B6C0..B8B6CC` | kong_state_46 | gameplay | native_logic | 4 | 0 |
| `B8B6CC..B8B729` | kong_state_47 | gameplay | native_logic | 31 | 0 |
| `B8B75D..B8B76F` | kong_state_48 | gameplay | native_logic | 6 | 0 |
| `B8B76F..B8B89D` | kong_state_49 | gameplay | native_logic | 107 | 0 |
| `B8B8C0..B8B923` | kong_state_4A | gameplay | native_logic | 36 | 0 |
| `B8B97C..B8B9C6` | kong_state_4B | gameplay | native_logic | 26 | 0 |
| `B8B9C6..B8B9DF` | kong_state_4C | gameplay | native_logic | 8 | 0 |
| `B8BAB2..B8BAB8` | kong_state_4D | gameplay | native_logic | 2 | 0 |
| `B8BAB8..B8BBE4` | kong_state_4E | gameplay | native_logic | 25 | 0 |
| `B8BBE4..B8BD06` | kong_state_4F | gameplay | native_logic | 105 | 0 |
| `B8BD29..B8BDD7` | kong_state_50 | gameplay | native_logic | 66 | 0 |
| `B8BDD7..B8BE76` | kong_state_51 | gameplay | native_logic | 65 | 0 |
| `B8BEAC..B8BEE8` | kong_state_52 | gameplay | native_logic | 22 | 0 |
| `B8BF19..B8BF20` | kong_state_53 | gameplay | native_logic | 2 | 0 |
| `B8BF20..B8BF97` | kong_state_54 | gameplay | native_logic | 19 | 0 |
| `B8BF97..B8BFB4` | kong_state_55 | gameplay | native_logic | 11 | 0 |
| `B8BFB4..B8BFB7` | kong_state_56 | gameplay | native_logic | 1 | 0 |
| `B8BFB7..B8BFD3` | kong_state_58 | gameplay | native_logic | 9 | 0 |
| `B8BFD3..B8BFDA` | kong_state_59 | gameplay | native_logic | 2 | 0 |
| `B8BFDA..B8C037` | kong_state_5A | gameplay | native_logic | 35 | 0 |
| `B8C037..B8C04A` | kong_state_5B | gameplay | native_logic | 7 | 0 |
| `B8C04A..B8C06E` | kong_state_5C | gameplay | native_logic | 13 | 0 |
| `B8C06E..B8C07C` | kong_state_5D | gameplay | native_logic | 5 | 0 |
| `B8C07C..B8C09D` | kong_state_5E | gameplay | native_logic | 11 | 0 |
| `B8C09D..B8C0A4` | kong_state_5F | gameplay | native_logic | 2 | 0 |
| `B8C0A4..B8C0D4` | kong_state_60 | gameplay | native_logic | 19 | 0 |
| `B8C0D4..B8C0E2` | kong_state_61 | gameplay | native_logic | 4 | 0 |
| `B8C181..B8C195` | kong_state_62 | gameplay | native_logic | 4 | 0 |
| `B8C265..B8C28B` | kong_state_63 | gameplay | native_logic | 14 | 0 |
| `B8C28B..B8C328` | kong_state_64 | gameplay | native_logic | 64 | 0 |
| `B8C328..B8C334` | kong_state_65 | gameplay | native_logic | 4 | 0 |
| `B8C334..B8C33A` | kong_state_66 | gameplay | native_logic | 2 | 0 |
| `B8C3FA..B8C40C` | kong_state_67 | gameplay | native_logic | 6 | 0 |
| `B8C40C..B8C421` | kong_state_68 | gameplay | native_logic | 7 | 0 |
| `B8C421..B8C433` | kong_state_69 | gameplay | native_logic | 6 | 0 |
| `B8C433..B8C442` | kong_state_6A | gameplay | native_logic | 5 | 0 |
| `B8C442..B8C451` | kong_state_6B | gameplay | native_logic | 5 | 0 |
| `B8C451..B8C45D` | kong_state_6C | gameplay | native_logic | 4 | 0 |
| `B8C45D..B8C469` | kong_state_6D | gameplay | native_logic | 4 | 0 |
| `B8C469..B8C476` | kong_state_6E | gameplay | native_logic | 4 | 0 |
| `B8C476..B8C483` | kong_state_6F | gameplay | native_logic | 4 | 0 |
| `B8F2BB..B8F2C1` | kong_state_70 | gameplay | native_logic | 2 | 0 |
| `B8F2C1..B8F2CB` | kong_state_71 | gameplay | native_logic | 3 | 0 |
| `B8F2CE..B8F2E2` | kong_state_72 | gameplay | native_logic | 6 | 0 |
| `B8F2E2..B8F2F6` | kong_state_73 | gameplay | native_logic | 6 | 0 |
| `B8F2F6..B8F339` | kong_state_74 | gameplay | native_logic | 23 | 0 |
| `B8F339..B8F348` | kong_state_75 | gameplay | native_logic | 5 | 0 |
| `B8F2CB..B8F2CE` | kong_state_76 | gameplay | native_logic | 1 | 0 |
| `B8F348..B8F35B` | kong_state_77 | gameplay | native_logic | 6 | 0 |
| `B9A015..B9A018` | set_anim_handle_animal_and_kiddy | unknown | unknown | 1 | 0 |
| `B8E587..B8E5B3` | CODE_B8E587 | unknown | unknown | 20 | 0 |
| `B9F1E0..B9F226` | CODE_B9F1E0 | unknown | unknown | 38 | 0 |
| `B9F13A..B9F163` | CODE_B9F13A | unknown | unknown | 19 | 0 |
| `B9F181..B9F1E0` | CODE_B9F181 | unknown | unknown | 50 | 1 |
| `B9F165..B9F169` | CODE_B9F165 | unknown | unknown | 2 | 0 |
| `B9F226..B9F260` | CODE_B9F226 | unknown | unknown | 30 | 0 |
| `B28124..B28207` | ROM_B28124 | unknown | unknown | 109 | 0 |
| `B2802D..B28104` | ROM_B2802D | unknown | unknown | 97 | 0 |
| `B2804B..B28104` | ROM_B2804B | unknown | unknown | 83 | 0 |
| `B28064..B28104` | ROM_B28064 | unknown | unknown | 71 | 0 |

## Lakeside Limbo

Level `25`, header `FD06AF`, shared data `19F0`, submap 0, song `0F`.

Placement stream `FE05B2..FE072C`: 47 records; prior matching audit claims PARTIAL 47, UNKNOWN 0. Indexing adds no SUPPORTED objects.

Native level lead: `assets/levels/lakeside-limbo/lakeside-limbo.level`.

| # | Original address | Type | Descriptor | XY | Audit status | Sprite lead |
|---:|---|---|---|---|---|---|
| 0 | `FE05B2` | `0022` | `FF5AC8` | 1936, 521 | PARTIAL | 0160 |
| 1 | `FE05BA` | `0140` | `FF6755` | 1376, 392 | PARTIAL | 02B4 |
| 2 | `FE05C2` | `00FE` | `FF6457` | 280, 366 | PARTIAL | 029C |
| 3 | `FE05CA` | `00FE` | `FF6457` | 496, 416 | PARTIAL | 029C |
| 4 | `FE05D2` | `00F2` | `FF63D8` | 496, 520 | PARTIAL | 0298 |
| 5 | `FE05DA` | `0376` | `FF78FF` | 848, 585 | PARTIAL | 02F8 |
| 6 | `FE05E2` | `010C` | `FF64C5` | 912, 496 | PARTIAL | 0294 |
| 7 | `FE05EA` | `045C` | `FF7EF7` | 1056, 617 | PARTIAL | 02C0 |
| 8 | `FE05F2` | `0376` | `FF78FF` | 1248, 585 | PARTIAL | 02F8 |
| 9 | `FE05FA` | `0376` | `FF78FF` | 1440, 585 | PARTIAL | 02F8 |
| 10 | `FE0602` | `0376` | `FF78FF` | 1487, 585 | PARTIAL | 02F8 |
| 11 | `FE060A` | `0260` | `FF718A` | 1698, 458 | PARTIAL | 02C4 |
| 12 | `FE0612` | `0148` | `FF67B4` | 1936, 568 | PARTIAL | 02B4 |
| 13 | `FE061A` | `0152` | `FF681A` | 2160, 416 | PARTIAL | 02B4 |
| 14 | `FE0622` | `0580` | `FF8919` | 1952, 521 | PARTIAL | 03C8 |
| 15 | `FE062A` | `05A4` | `FF8A6B` | 2288, 617 | PARTIAL | 0190 |
| 16 | `FE0632` | `010E` | `FF64D5` | 2384, 536 | PARTIAL | 0294 |
| 17 | `FE063A` | `0070` | `FF5DA9` | 2386, 617 | PARTIAL | 0170 |
| 18 | `FE0642` | `0578` | `FF88F1` | 2784, 617 | PARTIAL | 03C8 |
| 19 | `FE064A` | `057A` | `FF88FB` | 2912, 617 | PARTIAL | 03C8 |
| 20 | `FE0652` | `00C8` | `FF624A` | 3096, 456 | PARTIAL | 0284 |
| 21 | `FE065A` | `00FC` | `FF644D` | 3149, 408 | PARTIAL | 029C |
| 22 | `FE0662` | `00C8` | `FF624A` | 3208, 456 | PARTIAL | 0284 |
| 23 | `FE066A` | `0472` | `FF8094` | 3328, 504 | PARTIAL | 02BC |
| 24 | `FE0672` | `00F2` | `FF63D8` | 3328, 504 | PARTIAL | 0298 |
| 25 | `FE067A` | `0376` | `FF78FF` | 3352, 585 | PARTIAL | 02F8 |
| 26 | `FE0682` | `0260` | `FF718A` | 3488, 536 | PARTIAL | 02C4 |
| 27 | `FE068A` | `00F2` | `FF63D8` | 3760, 728 | PARTIAL | 0298 |
| 28 | `FE0692` | `0574` | `FF88DA` | 4108, 617 | PARTIAL | 03C8 |
| 29 | `FE069A` | `0110` | `FF64E5` | 4192, 528 | PARTIAL | 0294 |
| 30 | `FE06A2` | `014A` | `FF67BB` | 4552, 592 | PARTIAL | 02B4 |
| 31 | `FE06AA` | `0104` | `FF646F` | 4672, 608 | PARTIAL | 029C |
| 32 | `FE06B2` | `0154` | `FF6821` | 4688, 432 | PARTIAL | 02B4 |
| 33 | `FE06BA` | `0572` | `FF88D0` | 4712, 521 | PARTIAL | 03C8 |
| 34 | `FE06C2` | `0120` | `FF6586` | 4868, 617 | PARTIAL | 0250 |
| 35 | `FE06CA` | `045C` | `FF7EF7` | 5232, 585 | PARTIAL | 02C0 |
| 36 | `FE06D2` | `06CA` | `FF9598` | 5200, 480 | PARTIAL | 0434 |
| 37 | `FE06DA` | `045C` | `FF7EF7` | 5568, 585 | PARTIAL | 02C0 |
| 38 | `FE06E2` | `0106` | `FF6479` | 5888, 440 | PARTIAL | 029C |
| 39 | `FE06EA` | `0374` | `FF78CF` | 5888, 496 | PARTIAL | 0138 |
| 40 | `FE06F2` | `0580` | `FF8919` | 5936, 617 | PARTIAL | 03C8 |
| 41 | `FE06FA` | `027C` | `FF7298` | 6096, 553 | PARTIAL | 0258 |
| 42 | `FE0702` | `0142` | `FF6782` | 6272, 512 | PARTIAL | 02B4 |
| 43 | `FE070A` | `00C2` | `FF61F6` | 6368, 585 | PARTIAL | 0124 |
| 44 | `FE0712` | `00C8` | `FF624A` | 6448, 440 | PARTIAL | 0284 |
| 45 | `FE071A` | `00F4` | `FF63F4` | 6480, 440 | PARTIAL | 0298 |
| 46 | `FE0722` | `00F4` | `FF63F4` | 6472, 552 | PARTIAL | 0298 |

- Song ID is metadata. Native synthetic audio is not a translated SPC/song engine.
- Original per-level scanline, DMA/HDMA, palette and transition timing require reference observations.
- Descriptors and placements do not prove object handler implementations or complete level behavior.

## Doorstop Dash

Level `28`, header `FD0751`, shared data `198D`, submap 0, song `0E`.

Placement stream `FE0B10..FE0EC2`: 118 records; prior matching audit claims PARTIAL 113, UNKNOWN 5. Indexing adds no SUPPORTED objects.

Native level lead: `assets/levels/doorstop/doorstop.level`.

| # | Original address | Type | Descriptor | XY | Audit status | Sprite lead |
|---:|---|---|---|---|---|---|
| 0 | `FE0B10` | `009C` | `FF6125` | 576, 653 | UNKNOWN | 0144 |
| 1 | `FE0B18` | `009E` | `FF612C` | 1920, 1293 | UNKNOWN | 0144 |
| 2 | `FE0B20` | `00A0` | `FF6133` | 1952, 1933 | UNKNOWN | 0144 |
| 3 | `FE0B28` | `00F2` | `FF63D8` | 464, 2072 | PARTIAL | 0298 |
| 4 | `FE0B30` | `010C` | `FF64C5` | 588, 2112 | PARTIAL | 0294 |
| 5 | `FE0B38` | `04CE` | `FF8340` | 588, 2087 | PARTIAL | 038C |
| 6 | `FE0B40` | `04DC` | `FF842F` | 737, 2191 | PARTIAL | 0390 |
| 7 | `FE0B48` | `04DA` | `FF83C3` | 730, 2089 | PARTIAL | 0394 |
| 8 | `FE0B50` | `0260` | `FF718A` | 848, 2096 | PARTIAL | 02C4 |
| 9 | `FE0B58` | `0376` | `FF78FF` | 933, 2189 | PARTIAL | 02F8 |
| 10 | `FE0B60` | `0376` | `FF78FF` | 1216, 2160 | PARTIAL | 02F8 |
| 11 | `FE0B68` | `0376` | `FF78FF` | 1264, 2157 | PARTIAL | 02F8 |
| 12 | `FE0B70` | `0376` | `FF78FF` | 1312, 2165 | PARTIAL | 02F8 |
| 13 | `FE0B78` | `0376` | `FF78FF` | 1360, 2177 | PARTIAL | 02F8 |
| 14 | `FE0B80` | `04CE` | `FF8340` | 972, 2087 | PARTIAL | 038C |
| 15 | `FE0B88` | `0374` | `FF78CF` | 1196, 2128 | PARTIAL | 0138 |
| 16 | `FE0B90` | `04DE` | `FF8436` | 1505, 2191 | PARTIAL | 0390 |
| 17 | `FE0B98` | `04DA` | `FF83C3` | 1498, 2089 | PARTIAL | 0394 |
| 18 | `FE0BA0` | `00C6` | `FF6234` | 1552, 2060 | PARTIAL | 0284 |
| 19 | `FE0BA8` | `0376` | `FF78FF` | 1936, 2125 | PARTIAL | 02F8 |
| 20 | `FE0BB0` | `0378` | `FF7906` | 1664, 1933 | PARTIAL | 02F8 |
| 21 | `FE0BB8` | `039C` | `FF7A7A` | 1440, 1901 | PARTIAL | 02FC |
| 22 | `FE0BC0` | `039E` | `FF7A84` | 1488, 1869 | PARTIAL | 02FC |
| 23 | `FE0BC8` | `03A0` | `FF7A8E` | 1536, 1837 | PARTIAL | 02FC |
| 24 | `FE0BD0` | `010E` | `FF64D5` | 1952, 1856 | PARTIAL | 0294 |
| 25 | `FE0BD8` | `04CE` | `FF8340` | 1932, 2023 | PARTIAL | 038C |
| 26 | `FE0BE0` | `0374` | `FF78CF` | 2128, 2061 | PARTIAL | 0138 |
| 27 | `FE0BE8` | `04E2` | `FF8444` | 1857, 1933 | PARTIAL | 0390 |
| 28 | `FE0BF0` | `04D8` | `FF83AD` | 1864, 1831 | PARTIAL | 0394 |
| 29 | `FE0BF8` | `0140` | `FF6755` | 2176, 1792 | PARTIAL | 02B4 |
| 30 | `FE0C00` | `00D8` | `FF62FB` | 2176, 2008 | UNKNOWN | 027C |
| 31 | `FE0C08` | `04D2` | `FF8354` | 1644, 1831 | PARTIAL | 038C |
| 32 | `FE0C10` | `0374` | `FF78CF` | 1488, 1933 | PARTIAL | 0138 |
| 33 | `FE0C18` | `04E4` | `FF844B` | 1281, 1933 | PARTIAL | 0390 |
| 34 | `FE0C20` | `04D8` | `FF83AD` | 1288, 1831 | PARTIAL | 0394 |
| 35 | `FE0C28` | `00FC` | `FF644D` | 464, 1784 | PARTIAL | 029C |
| 36 | `FE0C30` | `0148` | `FF67B4` | 368, 1712 | PARTIAL | 02B4 |
| 37 | `FE0C38` | `0152` | `FF681A` | 872, 1832 | PARTIAL | 02B4 |
| 38 | `FE0C40` | `04D2` | `FF8354` | 684, 1767 | PARTIAL | 038C |
| 39 | `FE0C48` | `04E4` | `FF844B` | 513, 1805 | PARTIAL | 0390 |
| 40 | `FE0C50` | `04D8` | `FF83AD` | 520, 1831 | PARTIAL | 0394 |
| 41 | `FE0C58` | `04CE` | `FF8340` | 1164, 1511 | PARTIAL | 038C |
| 42 | `FE0C60` | `0374` | `FF78CF` | 1388, 1504 | PARTIAL | 0138 |
| 43 | `FE0C68` | `0374` | `FF78CF` | 1612, 1504 | PARTIAL | 0138 |
| 44 | `FE0C70` | `04DE` | `FF8436` | 1729, 1614 | PARTIAL | 0390 |
| 45 | `FE0C78` | `04DA` | `FF83C3` | 1722, 1513 | PARTIAL | 0394 |
| 46 | `FE0C80` | `03A0` | `FF7A8E` | 1296, 1501 | PARTIAL | 02FC |
| 47 | `FE0C88` | `039E` | `FF7A84` | 1344, 1533 | PARTIAL | 02FC |
| 48 | `FE0C90` | `039C` | `FF7A7A` | 1392, 1565 | PARTIAL | 02FC |
| 49 | `FE0C98` | `03A2` | `FF7A98` | 1504, 1597 | PARTIAL | 02FC |
| 50 | `FE0CA0` | `03A4` | `FF7AA2` | 1552, 1565 | PARTIAL | 02FC |
| 51 | `FE0CA8` | `03A6` | `FF7AAC` | 1600, 1533 | PARTIAL | 02FC |
| 52 | `FE0CB0` | `0474` | `FF80A7` | 2029, 1508 | PARTIAL | 02BC |
| 53 | `FE0CB8` | `00F2` | `FF63D8` | 2029, 1508 | PARTIAL | 0298 |
| 54 | `FE0CC0` | `0376` | `FF78FF` | 2048, 1613 | PARTIAL | 02F8 |
| 55 | `FE0CC8` | `0260` | `FF718A` | 2083, 1262 | PARTIAL | 02C4 |
| 56 | `FE0CD0` | `00DA` | `FF630B` | 2160, 1328 | UNKNOWN | 027C |
| 57 | `FE0CD8` | `0374` | `FF78CF` | 2160, 1472 | PARTIAL | 0138 |
| 58 | `FE0CE0` | `0378` | `FF7906` | 1872, 1293 | PARTIAL | 02F8 |
| 59 | `FE0CE8` | `04CE` | `FF8340` | 2028, 1511 | PARTIAL | 038C |
| 60 | `FE0CF0` | `0374` | `FF78CF` | 2096, 1328 | PARTIAL | 0138 |
| 61 | `FE0CF8` | `0374` | `FF78CF` | 1920, 1280 | PARTIAL | 0138 |
| 62 | `FE0D00` | `04E6` | `FF8452` | 1825, 1293 | PARTIAL | 0390 |
| 63 | `FE0D08` | `0374` | `FF78CF` | 1728, 1280 | PARTIAL | 0138 |
| 64 | `FE0D10` | `04D8` | `FF83AD` | 1832, 1191 | PARTIAL | 0394 |
| 65 | `FE0D18` | `04D2` | `FF8354` | 1580, 1127 | PARTIAL | 038C |
| 66 | `FE0D20` | `0176` | `FF6902` | 1580, 1256 | PARTIAL | 02B4 |
| 67 | `FE0D28` | `04E4` | `FF844B` | 1409, 1261 | PARTIAL | 0390 |
| 68 | `FE0D30` | `04D8` | `FF83AD` | 1416, 1159 | PARTIAL | 0394 |
| 69 | `FE0D38` | `0374` | `FF78CF` | 1280, 1216 | PARTIAL | 0138 |
| 70 | `FE0D40` | `03D2` | `FF7BA3` | 944, 1072 | PARTIAL | 02FC |
| 71 | `FE0D48` | `0374` | `FF78CF` | 1008, 1152 | PARTIAL | 0138 |
| 72 | `FE0D50` | `00FE` | `FF6457` | 1144, 1216 | PARTIAL | 029C |
| 73 | `FE0D58` | `015A` | `FF6836` | 864, 872 | PARTIAL | 02B4 |
| 74 | `FE0D60` | `03B4` | `FF7AF2` | 1168, 928 | PARTIAL | 02FC |
| 75 | `FE0D68` | `014A` | `FF67BB` | 1424, 872 | PARTIAL | 02B4 |
| 76 | `FE0D70` | `03CE` | `FF7B89` | 400, 736 | PARTIAL | 02FC |
| 77 | `FE0D78` | `00F2` | `FF63D8` | 445, 592 | PARTIAL | 0298 |
| 78 | `FE0D80` | `00C6` | `FF6234` | 704, 837 | PARTIAL | 0284 |
| 79 | `FE0D88` | `0386` | `FF794F` | 736, 929 | PARTIAL | 02F8 |
| 80 | `FE0D90` | `04CE` | `FF8340` | 1164, 871 | PARTIAL | 038C |
| 81 | `FE0D98` | `04DC` | `FF842F` | 1281, 974 | PARTIAL | 0390 |
| 82 | `FE0DA0` | `04DA` | `FF83C3` | 1274, 874 | PARTIAL | 0394 |
| 83 | `FE0DA8` | `04D2` | `FF8354` | 556, 871 | PARTIAL | 038C |
| 84 | `FE0DB0` | `04E0` | `FF843D` | 705, 656 | PARTIAL | 0390 |
| 85 | `FE0DB8` | `04DA` | `FF83C3` | 698, 554 | PARTIAL | 0394 |
| 86 | `FE0DC0` | `0374` | `FF78CF` | 368, 864 | PARTIAL | 0138 |
| 87 | `FE0DC8` | `0374` | `FF78CF` | 464, 592 | PARTIAL | 0138 |
| 88 | `FE0DD0` | `0110` | `FF64E5` | 784, 576 | PARTIAL | 0294 |
| 89 | `FE0DD8` | `0376` | `FF78FF` | 992, 685 | PARTIAL | 02F8 |
| 90 | `FE0DE0` | `04CE` | `FF8340` | 1004, 359 | PARTIAL | 038C |
| 91 | `FE0DE8` | `017A` | `FF6928` | 1008, 480 | PARTIAL | 02B4 |
| 92 | `FE0DF0` | `0178` | `FF6915` | 1008, 616 | PARTIAL | 02B4 |
| 93 | `FE0DF8` | `0374` | `FF78CF` | 960, 512 | PARTIAL | 0138 |
| 94 | `FE0E00` | `04DE` | `FF8436` | 1185, 624 | PARTIAL | 0390 |
| 95 | `FE0E08` | `04DA` | `FF83C3` | 1178, 522 | PARTIAL | 0394 |
| 96 | `FE0E10` | `0374` | `FF78CF` | 1296, 576 | PARTIAL | 0138 |
| 97 | `FE0E18` | `03CA` | `FF7B72` | 1520, 488 | PARTIAL | 02FC |
| 98 | `FE0E20` | `04CE` | `FF8340` | 1388, 551 | PARTIAL | 038C |
| 99 | `FE0E28` | `0374` | `FF78CF` | 1520, 496 | PARTIAL | 0138 |
| 100 | `FE0E30` | `04E0` | `FF843D` | 1729, 400 | PARTIAL | 0390 |
| 101 | `FE0E38` | `04DA` | `FF83C3` | 1722, 299 | PARTIAL | 0394 |
| 102 | `FE0E40` | `0112` | `FF64F5` | 1648, 336 | PARTIAL | 0294 |
| 103 | `FE0E48` | `04D4` | `FF835E` | 1996, 327 | PARTIAL | 038C |
| 104 | `FE0E50` | `04DE` | `FF8436` | 2273, 432 | PARTIAL | 0390 |
| 105 | `FE0E58` | `04DA` | `FF83C3` | 2266, 330 | PARTIAL | 0394 |
| 106 | `FE0E60` | `03BA` | `FF7B19` | 2080, 384 | PARTIAL | 02FC |
| 107 | `FE0E68` | `04D0` | `FF834A` | 2284, 903 | PARTIAL | 038C |
| 108 | `FE0E70` | `019E` | `FF6A6C` | 1968, 1008 | PARTIAL | 02B4 |
| 109 | `FE0E78` | `04D0` | `FF834A` | 1964, 839 | PARTIAL | 038C |
| 110 | `FE0E80` | `0074` | `FF5DDB` | 2176, 1037 | PARTIAL | 0170 |
| 111 | `FE0E88` | `05A4` | `FF8A6B` | 2104, 1037 | PARTIAL | 0190 |
| 112 | `FE0E90` | `04E2` | `FF8444` | 2113, 941 | PARTIAL | 0390 |
| 113 | `FE0E98` | `04D8` | `FF83AD` | 2120, 840 | PARTIAL | 0394 |
| 114 | `FE0EA0` | `0104` | `FF646F` | 2544, 320 | PARTIAL | 029C |
| 115 | `FE0EA8` | `0102` | `FF6468` | 2608, 1696 | PARTIAL | 029C |
| 116 | `FE0EB0` | `0142` | `FF6782` | 2656, 2120 | PARTIAL | 02B4 |
| 117 | `FE0EB8` | `00C2` | `FF61F6` | 2744, 2189 | PARTIAL | 0124 |

- Song ID is metadata. Native synthetic audio is not a translated SPC/song engine.
- Original per-level scanline, DMA/HDMA, palette and transition timing require reference observations.
- Descriptors and placements do not prove object handler implementations or complete level behavior.

## Evidence and unresolved contracts

### B89F3A..B89F50

Classification evidence: name/source token: kong

- `B89F3A` write UNKNOWN `operand 72` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B89F3C` write UNKNOWN `operand 74` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B89F3E` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B89F40` read UNKNOWN `operand 6` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B89F43` write UNKNOWN `operand 6A` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B89F47` read UNKNOWN `operand 38` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B89F4D` pointer UNKNOWN `operand A191` (absix); Indirect control pointer; pointer bank, runtime index/state and target set require review.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B89F46 PLB: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.
- B89F4D: indirect control flow; target set requires a reviewed dispatch contract or RAM state.
- ROM-verified dispatch `B8A191`, stride 4, 120 targets; index bounds and dynamic selection unknown.

### B8C6DE..B8C73A

Classification evidence: No reviewed semantic contract; anonymous addresses do not identify behavior.

- `B8C6E1` read UNKNOWN `operand 6A` (dily); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C6E3` read UNKNOWN `operand 72` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C6E5` write UNKNOWN `operand 8` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8C6EB` read UNKNOWN `operand 6A` (dily); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C6ED` read UNKNOWN `operand 72` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C6EF` write UNKNOWN `operand A` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8C6F3` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C6F5` read UNKNOWN `operand 3A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C6FA` write UNKNOWN `operand 3A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C6FF` write UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C708` read UNKNOWN `operand 72` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C70A` write UNKNOWN `operand 8` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C70C` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C70E` write UNKNOWN `operand 30` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C710` write UNKNOWN `operand 2E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C712` read UNKNOWN `operand 50F` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8C719` read UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C71D` write UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C71F` read UNKNOWN `operand 4AD` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8C729` read UNKNOWN `operand 50F` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8C72C` write UNKNOWN `operand 4A2` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8C732` read UNKNOWN `operand 187D` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8C704 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C735 JSL: M/X not assumed to survive; next variable length needs boundary evidence.

### B9EEA0..B9F13A

Classification evidence: No reviewed semantic contract; anonymous addresses do not identify behavior.

- Source lead `src/core/Player.cpp:150`: // Host crossing guard; full B9:EEA0 response is not translated yet.
- Source lead `src/core/RomMotion.cpp:53`: // Original dry-floor response indexes B9:F126 with attributes & 7.
- Source lead `src/core/RomTerrain.h:46`: // B9:EFB9..EFF0, entered only after rising penetration was established.
- Source lead `src/core/RomTerrain.h:60`: // B9:F060..F083 selection, assuming the caller has a positive floor gap.
- Source lead `src/core/RomTerrain.h:73`: // Dry attach response B9:F027..F044. Caller establishes floor contact,
- `B9EEA1` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EEA5` read UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EEA7` write UNKNOWN `operand 29` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EEAD` write UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EEB1` read UNKNOWN `operand 12` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EEB3` write UNKNOWN `operand 54` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EEB5` read UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EEB7` write UNKNOWN `operand 56` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EEB9` read UNKNOWN `operand 29` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EEC6` write UNKNOWN `operand 8A` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EEC9` read UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EED2` read UNKNOWN `operand A2` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EEE2` write UNKNOWN `operand A4` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EEE7` write UNKNOWN `operand 8A` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EEEA` read UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EEEF` read UNKNOWN `operand A4` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EEF4` read UNKNOWN `operand 56` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EEFD` read UNKNOWN `operand A4` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EEFF` write UNKNOWN `operand 8A` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EF05` read UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EF07` read UNKNOWN `operand AA` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EF0E` read UNKNOWN `operand A2` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EF1B` read UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EF1D` write UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EF21` read UNKNOWN `operand A6` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EF26` read UNKNOWN `operand AC` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EF2A` read UNKNOWN `operand 8A` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EF2C` write UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EF33` read UNKNOWN `operand AA` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EF37` read UNKNOWN `operand A2` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EF3E` read UNKNOWN `operand 2A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EF43` read UNKNOWN `operand A2` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EF4C` read UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EF53` read UNKNOWN `operand 2A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EF58` read UNKNOWN `operand A2` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EF64` read UNKNOWN `operand A2` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EF71` read UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EF73` write UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EF77` read UNKNOWN `operand A0` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EF7C` read UNKNOWN `operand AC` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EF80` read UNKNOWN `operand A2` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EF87` read UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EF8E` read UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EF92` read UNKNOWN `operand 2E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EF97` write UNKNOWN `operand A4` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EFA0` read UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EFA4` read UNKNOWN `operand A2` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EFAB` write UNKNOWN `operand 1A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EFAD` write UNKNOWN `operand 18` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EFB2` read UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EFB4` write UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EFB9` read UNKNOWN `operand A4` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EFBD` write UNKNOWN `operand A6` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EFBF` read UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EFC9` write UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EFCE` read UNKNOWN `operand A4` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EFD2` write UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EFD4` write UNKNOWN `operand 2E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EFD6` write UNKNOWN `operand 34` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EFDB` write UNKNOWN `operand 18` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EFE0` write UNKNOWN `operand 1A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EFE2` read UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EFE7` write UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EFE9` read UNKNOWN `operand A6` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EFEE` write UNKNOWN `operand A0` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EFF6` write UNKNOWN `operand 1A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9EFF8` read UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F002` write UNKNOWN `operand 18` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F007` write UNKNOWN `operand 1A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F013` read UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F019` read UNKNOWN `operand A2` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F020` read UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F022` read UNKNOWN `operand 50F` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B9F027` read UNKNOWN `operand A0` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F02E` read ROM `B9F126` (longx); Base address only; runtime X and word wrapping require review.
- `B9F032` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F034` write UNKNOWN `operand 2E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F036` write UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F038` write UNKNOWN `operand 14` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F03A` write UNKNOWN `operand 18` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F03C` write UNKNOWN `operand 1A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F041` read UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F043` write UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F048` write UNKNOWN `operand 18` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F04D` read UNKNOWN `operand 18` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F056` write UNKNOWN `operand 1A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F060` write UNKNOWN `operand 1A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F062` read UNKNOWN `operand A0` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F069` read UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F070` read UNKNOWN `operand A0` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F07B` read UNKNOWN `operand 1A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F081` write UNKNOWN `operand 1A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F083` read UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F08D` write UNKNOWN `operand 18` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F08F` read UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F09A` write UNKNOWN `operand 2E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F09E` write UNKNOWN `operand 1A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F0A8` write UNKNOWN `operand 18` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F0AD` read UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F0AF` write UNKNOWN `operand 1A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F0B3` read UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F0B8` write UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F0BA` read UNKNOWN `operand A2` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F0C6` read UNKNOWN `operand 29` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F0D0` write UNKNOWN `operand 18` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F0D5` write UNKNOWN `operand 1A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F0D9` read UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F0DB` write UNKNOWN `operand 18` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F0DD` write UNKNOWN `operand 1A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F0E1` read UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F0E6` write UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F0E8` read UNKNOWN `operand 2E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F0EC` write UNKNOWN `operand 14` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F0EE` read UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F0F3` write UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F0F5` write UNKNOWN `operand 18` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F0F7` write UNKNOWN `operand 1A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F0FC` write UNKNOWN `operand 2E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F100` read UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F109` write UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F10E` write UNKNOWN `operand 18` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F113` write UNKNOWN `operand 1A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F115` write UNKNOWN `operand 2E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F117` write UNKNOWN `operand 34` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F119` read UNKNOWN `operand A2` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F11B` read UNKNOWN `operand A0` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F120` read UNKNOWN `operand A0` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F122` write UNKNOWN `operand 1C` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B9EEC0 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B9EEC3 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B9EED9 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B9EEDF JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B9EEE4 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B9EF0B JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B9EF4F JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B9EF61 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B9EF8A JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B9EF99 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B9EFCB JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B9F00C JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B9F0A2 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B9F0A5 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B9F124 PLB: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.
- DATA boundary at B9F126; use table command, not code decoding.

### B9F060..B9F13A

Classification evidence: No reviewed semantic contract; anonymous addresses do not identify behavior.

- Source lead `src/core/RomMotion.cpp:53`: // Original dry-floor response indexes B9:F126 with attributes & 7.
- Source lead `src/core/RomTerrain.h:60`: // B9:F060..F083 selection, assuming the caller has a positive floor gap.
- `B9F060` write UNKNOWN `operand 1A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F062` read UNKNOWN `operand A0` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F069` read UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F070` read UNKNOWN `operand A0` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F07B` read UNKNOWN `operand 1A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F081` write UNKNOWN `operand 1A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F083` read UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F08D` write UNKNOWN `operand 18` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F08F` read UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F09A` write UNKNOWN `operand 2E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F09E` write UNKNOWN `operand 1A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F0A8` write UNKNOWN `operand 18` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F0AD` read UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F0AF` write UNKNOWN `operand 1A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F0B3` read UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F0B8` write UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F0BA` read UNKNOWN `operand A2` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F0C6` read UNKNOWN `operand 29` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F0D0` write UNKNOWN `operand 18` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F0D5` write UNKNOWN `operand 1A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F0D9` read UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F0DB` write UNKNOWN `operand 18` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F0DD` write UNKNOWN `operand 1A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F0E1` read UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F0E6` write UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F0E8` read UNKNOWN `operand 2E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F0EC` write UNKNOWN `operand 14` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F0EE` read UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F0F3` write UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F0F5` write UNKNOWN `operand 18` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F0F7` write UNKNOWN `operand 1A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F0FC` write UNKNOWN `operand 2E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F100` read UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F109` write UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F10E` write UNKNOWN `operand 18` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F113` write UNKNOWN `operand 1A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F115` write UNKNOWN `operand 2E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F117` write UNKNOWN `operand 34` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F119` read UNKNOWN `operand A2` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F11B` read UNKNOWN `operand A0` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F120` read UNKNOWN `operand A0` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F122` write UNKNOWN `operand 1C` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B9F0A2 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B9F0A5 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B9F124 PLB: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.
- DATA boundary at B9F126; use table command, not code decoding.

### B28012..B28015

Classification evidence: name/source token: sound

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.

### B28000..B28009

Classification evidence: name/source token: spc

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.

### B8A37E..B8A39C

Classification evidence: name/source token: kong

- `B8A37E` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A380` read UNKNOWN `operand 4CE` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8A396` read_write UNKNOWN `operand 59B` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8A388 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A38F JSL: M/X not assumed to survive; next variable length needs boundary evidence.

### B8A39C..B8A3AE

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8A39F JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A3A2 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A3A5 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A3A8 JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8A3AE..B8A3C6

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8A3B1 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A3B4 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A3B7 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A3BA JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A3BD JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A3C0 JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8A3C6..B8A3F2

Classification evidence: name/source token: kong

- `B8A3D5` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A3D7` read UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A3DE` read UNKNOWN `operand 1C` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A3E3` read UNKNOWN `operand AC` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A3EA` write UNKNOWN `operand 2E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8A3C9 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A3CC JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A3CF JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A3D2 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A3EC JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8A43A..B8A44C

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8A43D JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A440 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A443 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A446 JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8A44C..B8A44F

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.

### B8A44F..B8A452

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.

### B8A452..B8A493

Classification evidence: name/source token: kong

- `B8A455` read_write UNKNOWN `operand 5AF` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8A461` read UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A477` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A47C` write UNKNOWN `operand 1A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A48B` write UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8A458 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A45E JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A468 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A46B JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A473 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A47E JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A482 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A48D JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8A53B..B8A57C

Classification evidence: name/source token: kong

- `B8A53E` read_write UNKNOWN `operand 5AF` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8A54A` read UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A554` read UNKNOWN `operand 30` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A55F` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A564` write UNKNOWN `operand 1A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A574` write UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8A541 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A547 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A551 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A55B JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A566 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A56A JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A576 JSL: M/X not assumed to survive; next variable length needs boundary evidence.

### B8A57C..B8A591

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8A57F JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A582 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A585 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A588 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A58B JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8A591..B8A5D2

Classification evidence: name/source token: kong

- `B8A594` read_write UNKNOWN `operand 5AF` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8A59A` read_write UNKNOWN `operand 1927` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8A5A6` read UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A5B0` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A5B4` read UNKNOWN `operand 34` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A5BB` write UNKNOWN `operand 1A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A5CA` write UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8A59D JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A5A3 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A5AD JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A5BD JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A5C1 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A5CC JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8A613..B8A669

Classification evidence: name/source token: kong

- `B8A616` read_write UNKNOWN `operand 5AF` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8A622` read UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A629` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A62B` read UNKNOWN `operand 34` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A62F` read UNKNOWN `operand 5C` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A636` write UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A659` write UNKNOWN `operand 2A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A65B` write UNKNOWN `operand 30` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A660` write UNKNOWN `operand 1955` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8A619 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A61F JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A63B JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A63F JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A648 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A64C JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A650 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A656 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A663 JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8A669..B8A676

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8A66C JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A670 JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8A676..B8A68E

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8A679 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A67C JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A67F JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A682 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A685 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A688 JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8A68E..B8A6A6

Classification evidence: name/source token: kong

- `B8A697` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A699` read UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8A691 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A694 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A6A0 JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8A6A6..B8A6BB

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8A6A9 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A6AC JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A6AF JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A6B2 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A6B5 JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8A6BB..B8A6C7

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8A6BE JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A6C1 JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8A6C7..B8A6EB

Classification evidence: name/source token: kong

- `B8A6CD` read UNKNOWN `operand 186B` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8A6D2` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A6D4` read UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8A6CA JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A6DB JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A6DF JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A6E5 JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8A6EB..B8A724

Classification evidence: name/source token: kong

- `B8A6EE` read_write UNKNOWN `operand 1927` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8A6F7` read UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A6FE` read UNKNOWN `operand 4C` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A703` read UNKNOWN `operand 3C` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8A706` write UNKNOWN `operand 3C` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8A70E` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A710` read UNKNOWN `operand DA` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A716` write UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A718` write UNKNOWN `operand 1A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8A6F4 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A70A JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A71A JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A71E JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8A724..B8A72D

Classification evidence: name/source token: kong

- `B8A727` read_write UNKNOWN `operand 5AF` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.

### B8A72D..B8A763

Classification evidence: name/source token: kong

- `B8A730` read_write UNKNOWN `operand 5AF` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8A739` read UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A745` read UNKNOWN `operand 34` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A74C` write UNKNOWN `operand 1A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A75B` write UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8A736 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A740 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A74E JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A752 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A75D JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8A805..B8A85F

Classification evidence: name/source token: kong

- `B8A808` read_write UNKNOWN `operand 5AF` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8A811` read UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A81B` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A81D` read UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A821` read UNKNOWN `operand 34` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A825` read UNKNOWN `operand 5C` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A82C` write UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A84F` write UNKNOWN `operand 2A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A851` write UNKNOWN `operand 30` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A856` write UNKNOWN `operand 1955` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8A80E JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A818 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A831 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A835 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A83E JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A842 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A846 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A84C JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A859 JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8A85F..B8A874

Classification evidence: name/source token: kong

- `B8A865` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A867` read UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8A862 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A86E JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8A874..B8A884

Classification evidence: name/source token: kong

- `B8A874` read UNKNOWN `operand 5C` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8A879` pointer UNKNOWN `operand A87C` (absix); Indirect control pointer; pointer bank, runtime index/state and target set require review.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8A879: indirect control flow; target set requires a reviewed dispatch contract or RAM state.
- DATA boundary at B8A87C; use table command, not code decoding.

### B8A8E0..B8A903

Classification evidence: name/source token: kong

- `B8A8E0` read UNKNOWN `operand 28` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8A8E8` read UNKNOWN `operand 16` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8A8EC` read UNKNOWN `operand 1973` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8A8F4 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A8F7 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A8FD JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8A903..B8A955

Classification evidence: name/source token: kong

- `B8A906` read_write UNKNOWN `operand 1927` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8A90A` read UNKNOWN `operand 5A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A90E` read UNKNOWN `operand 60` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A912` read_write UNKNOWN `operand 60` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A923` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A925` read UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A92F` read_write UNKNOWN `operand 5A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A938` read UNKNOWN `operand 5E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A942` write UNKNOWN `operand 30` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A944` write UNKNOWN `operand 2A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A946` write UNKNOWN `operand 2E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8A914 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A91B JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A920 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A931 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A948 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A94B JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A94E JSL: M/X not assumed to survive; next variable length needs boundary evidence.

### B8AA07..B8AA2F

Classification evidence: name/source token: kong

- `B8AA0A` read_write UNKNOWN `operand 1927` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8AA10` read_write UNKNOWN `operand 5AF` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8AA19` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AA1B` write UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AA20` write UNKNOWN `operand 1A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AA22` write UNKNOWN `operand 36` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AA24` read UNKNOWN `operand 7A` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8AA16 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AA28 JSL: M/X not assumed to survive; next variable length needs boundary evidence.

### B8AA2F..B8AB80

Classification evidence: name/source token: kong

- `B8AA32` read_write UNKNOWN `operand 1927` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8AA35` read UNKNOWN `operand 501` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8AA38` read UNKNOWN `operand 6` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AA3A` write UNKNOWN `operand 6A` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AA3C` read UNKNOWN `operand 72` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AA3E` read UNKNOWN `operand 6` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8AA44` write UNKNOWN `operand 6` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8AA4A` read_write UNKNOWN `operand 474` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8AA4D` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AA52` read_write UNKNOWN `operand 5E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AA56` write UNKNOWN `operand 5E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AA58` write UNKNOWN `operand 64` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AA60` read UNKNOWN `operand 62` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AA6A` write UNKNOWN `operand 533` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8AA6D` read_write UNKNOWN `operand 5C` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AA71` write UNKNOWN `operand 195B` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8AA7F` read UNKNOWN `operand 4F9` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8AA82` write UNKNOWN `operand 3A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AA84` read UNKNOWN `operand 4FD` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8AA87` write UNKNOWN `operand 3A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AA90` read UNKNOWN `operand 7E` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AAA1` read_write UNKNOWN `operand 5C` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AAA5` write UNKNOWN `operand 5C` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AAA7` write UNKNOWN `operand 60` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AAAC` read UNKNOWN `operand 6A` (dily); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AAAE` read UNKNOWN `operand 72` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AAB0` write UNKNOWN `operand 8` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8AAB9` read UNKNOWN `operand 5E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AABD` read UNKNOWN `operand 64` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AACD` read UNKNOWN `operand 30` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AAD4` read UNKNOWN `operand 6A` (dily); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AADE` read UNKNOWN `operand 64` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AAF3` read UNKNOWN `operand 2E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AAFF` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AB01` read UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AB08` write UNKNOWN `operand 4AA` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8AB0B` write UNKNOWN `operand 4AE` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8AB23` read_write UNKNOWN `operand 5C` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AB27` write UNKNOWN `operand 5C` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AB29` write UNKNOWN `operand 60` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AB2B` write UNKNOWN `operand 34` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AB30` read UNKNOWN `operand 6A` (dily); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AB39` read UNKNOWN `operand 5E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AB3D` read UNKNOWN `operand 30` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AB44` read UNKNOWN `operand 6A` (dily); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AB4E` read UNKNOWN `operand 64` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AB60` read UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AB67` read UNKNOWN `operand 5E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8AA5D JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AA74 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AA78 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AA7B JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AA89 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AAB3 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AAD6 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AADA JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AAE5 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AAE9 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AAED JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AAF0 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AAF7 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AAFA JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AB0E JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AB12 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AB19 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AB1C JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AB32 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AB46 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AB4A JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AB55 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AB59 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AB5D JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AB6B JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AB6F JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AB76 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AB79 JSL: M/X not assumed to survive; next variable length needs boundary evidence.

### B8A955..B8A9AF

Classification evidence: name/source token: kong

- `B8A958` read_write UNKNOWN `operand 1927` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8A95C` read UNKNOWN `operand 5A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A960` read UNKNOWN `operand 60` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A964` read_write UNKNOWN `operand 60` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A972` read UNKNOWN `operand 5E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A97C` write UNKNOWN `operand 2A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A97E` write UNKNOWN `operand 30` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A982` read UNKNOWN `operand 1E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A98A` write UNKNOWN `operand 1E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8A98C` read UNKNOWN `operand 4FD` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8A98F` read UNKNOWN `operand 1E` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8A998` write UNKNOWN `operand 1E` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8A9A6` read_write UNKNOWN `operand 5A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8A966 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A96D JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A99B JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A9A0 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8A9A8 JSL: M/X not assumed to survive; next variable length needs boundary evidence.

### B8AB80..B8AB97

Classification evidence: name/source token: kong

- `B8AB80` read UNKNOWN `operand 75C` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8AB89` read_write UNKNOWN `operand 5C` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8AB8D JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AB91 JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8AB97..B8ABB3

Classification evidence: name/source token: kong

- `B8AB9A` read_write UNKNOWN `operand 5AF` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8ABA0` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8ABA2` read_write UNKNOWN `operand 5C` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8ABAD` write UNKNOWN `operand 195B` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8AB9D JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8ABA6 JSL: M/X not assumed to survive; next variable length needs boundary evidence.

### B8ABB3..B8ABCF

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8ABB6 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8ABB9 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8ABBF JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8ABC3 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8ABC6 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8ABC9 JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8ABCF..B8AC29

Classification evidence: name/source token: kong

- `B8ABD2` read_write UNKNOWN `operand 1927` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8ABD5` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8ABD7` read UNKNOWN `operand 4C` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8ABDC` read UNKNOWN `operand 3C` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8ABDF` write UNKNOWN `operand 3C` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8ABE7` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8ABE9` read UNKNOWN `operand 4C` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8ABEB` read UNKNOWN `operand D8` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8ABF1` write UNKNOWN `operand 12` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8ABF3` read UNKNOWN `operand DA` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8ABFA` read UNKNOWN `operand 46` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8ABFD` write UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8ABFF` write UNKNOWN `operand 1A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AC01` read UNKNOWN `operand 1E` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8AC08` write UNKNOWN `operand 30` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AC0A` read UNKNOWN `operand 46` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8AC0F` read UNKNOWN `operand 5AF` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8AC17` read UNKNOWN `operand 4FD` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8AC1D` write UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8ABE3 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AC1F JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AC23 JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8AC29..B8AC3E

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8AC2C JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AC2F JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AC32 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AC35 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AC38 JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8AC3E..B8AC56

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8AC41 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AC44 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AC47 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AC4A JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AC4D JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AC50 JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8AC56..B8AC78

Classification evidence: name/source token: kong

- `B8AC5C` read UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AC66` read UNKNOWN `operand 7C` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8AC59 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AC63 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AC6B JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AC6F JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AC72 JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8AC94..B8ACA9

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8AC97 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AC9A JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AC9D JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8ACA0 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8ACA3 JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8ACA9..B8ACC1

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8ACAC JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8ACAF JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8ACB2 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8ACB5 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8ACB8 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8ACBB JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8ACC1..B8ACD6

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8ACC4 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8ACC7 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8ACCA JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8ACCD JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8ACD0 JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8ACD6..B8ACFA

Classification evidence: name/source token: kong

- `B8ACD6` read UNKNOWN `operand 186B` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8ACDB` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8ACDD` read UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8ACE4 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8ACE8 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8ACEB JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8ACF1 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8ACF4 JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8ACFA..B8AD12

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8ACFD JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AD00 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AD03 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AD06 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AD09 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AD0C JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8AD12..B8AD28

Classification evidence: name/source token: kong

- `B8AD18` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AD1A` write UNKNOWN `operand 30` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8AD15 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AD1C JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AD1F JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AD22 JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8AD28..B8AD3A

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8AD2B JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AD2E JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AD31 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AD34 JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8AD3A..B8AD5C

Classification evidence: name/source token: kong

- `B8AD3A` read UNKNOWN `operand 3C` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8AD43` write UNKNOWN `operand 3C` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8AD45 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AD50 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AD53 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AD56 JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8AE19..B8AE2C

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8AE1C JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AE22 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AE26 JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8AE2C..B8AE4E

Classification evidence: name/source token: kong

- `B8AE2C` read UNKNOWN `operand 3C` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8AE35` write UNKNOWN `operand 3C` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8AE37 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AE42 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AE45 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AE48 JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8AE4E..B8AE81

Classification evidence: name/source token: kong

- `B8AE54` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AE56` read UNKNOWN `operand 5C` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AE58` write UNKNOWN `operand 2A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AE5A` write UNKNOWN `operand 30` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AE66` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AE68` read UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AE75` write UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8AE51 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AE5F JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AE63 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AE7A JSL: M/X not assumed to survive; next variable length needs boundary evidence.

### B8AE81..B8AE94

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8AE84 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AE8A JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AE8E JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8AE94..B8AEB5

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8AE97 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AE9B JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AE9E JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AEA1 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AEA5 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AEA8 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AEAB JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AEAE JSL: M/X not assumed to survive; next variable length needs boundary evidence.

### B8AEB5..B8AEDB

Classification evidence: name/source token: kong

- `B8AEB5` read UNKNOWN `operand 3A` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8AEBB` write UNKNOWN `operand 3A` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8AEBE` read UNKNOWN `operand 4F9` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8AEC1` read UNKNOWN `operand 29` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AECB` read_write UNKNOWN `operand 1927` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8AECE JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AED1 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AED4 JSL: M/X not assumed to survive; next variable length needs boundary evidence.

### B8AEDB..B8AF11

Classification evidence: name/source token: kong

- `B8AEE5` read UNKNOWN `operand 1925` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8AEED` read UNKNOWN `operand 1923` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8AEF2` read UNKNOWN `operand 4F9` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8AEF5` read UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AF01` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AF03` write UNKNOWN `operand 24` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AF05` write UNKNOWN `operand 20` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AF07` write UNKNOWN `operand 5C` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AF0C` write UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8AEDB JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AEDE JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AEE1 JSL: M/X not assumed to survive; next variable length needs boundary evidence.

### B8AF11..B8AF27

Classification evidence: name/source token: kong

- `B8AF11` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AF13` read UNKNOWN `operand 5C` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AF17` read UNKNOWN `operand 4FD` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8AF1A` read UNKNOWN `operand 12` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8AF1D` write UNKNOWN `operand 12` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AF1F` read UNKNOWN `operand 16` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8AF22` write UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.

### B8AF27..B8AF3D

Classification evidence: name/source token: kong

- `B8AF2A` read_write UNKNOWN `operand 5AF` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8AF33` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AF35` write UNKNOWN `operand 60` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8AF30 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AF37 JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8AF3D..B8AFBF

Classification evidence: name/source token: kong

- `B8AF40` read_write UNKNOWN `operand 5AF` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8AF4F` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AF51` read_write UNKNOWN `operand 60` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AF53` write UNKNOWN `operand 3A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AF55` read UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AF62` write UNKNOWN `operand 2E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AF64` read UNKNOWN `operand 60` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AF71` write UNKNOWN `operand 2A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AF73` write UNKNOWN `operand 30` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AF7C` read UNKNOWN `operand 6A` (dily); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AF7E` write UNKNOWN `operand 2A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AF80` write UNKNOWN `operand 30` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AF85` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AF87` read UNKNOWN `operand 5E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AF8A` read UNKNOWN `operand 12` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AF95` write UNKNOWN `operand 5C` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AF97` read UNKNOWN `operand 12` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AF99` write UNKNOWN `operand 5E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AF9E` read_write UNKNOWN `operand 5C` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AFA0` read UNKNOWN `operand 5C` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AFAA` write UNKNOWN `operand 2E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AFAC` write UNKNOWN `operand 2A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AFAE` write UNKNOWN `operand 30` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AFB3` write UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8AF43 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AF49 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AF75 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AF82 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AFB8 JSL: M/X not assumed to survive; next variable length needs boundary evidence.

### B8AFBF..B8AFD8

Classification evidence: name/source token: kong

- `B8AFD5` pointer UNKNOWN `operand 4F5` (absil); Indirect control pointer; pointer bank, runtime index/state and target set require review.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8AFBF JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AFC5 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AFC8 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AFCB JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AFD2 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AFD5: indirect control flow; target set requires a reviewed dispatch contract or RAM state.

### B8AFD8..B8AFEF

Classification evidence: name/source token: kong

- `B8AFD9` read_write UNKNOWN `operand 5C` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AFE0` write UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8AFEC` pointer UNKNOWN `operand 4F5` (absil); Indirect control pointer; pointer bank, runtime index/state and target set require review.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8AFE2 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AFE8 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AFEC: indirect control flow; target set requires a reviewed dispatch contract or RAM state.

### B8AFEF..B8B086

Classification evidence: name/source token: kong

- `B8AFF0` write UNKNOWN `operand 3A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B001` pointer UNKNOWN `operand 4F5` (absil); Indirect control pointer; pointer bank, runtime index/state and target set require review.
- `B8B00B` read_write UNKNOWN `operand 5AF` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8B00E` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B013` write UNKNOWN `operand 10` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B015` write UNKNOWN `operand 14` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B017` read UNKNOWN `operand 4F9` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8B01A` read UNKNOWN `operand E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B01D` read UNKNOWN `operand E` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8B020` write UNKNOWN `operand E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B023` write UNKNOWN `operand E` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8B039` read UNKNOWN `operand 72` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B03B` read UNKNOWN `operand 0` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B03D` write UNKNOWN `operand 12` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8B047` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B04C` write UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B04E` read UNKNOWN `operand 4F9` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8B051` read UNKNOWN `operand 1939` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8B054` write UNKNOWN `operand 2A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B059` write UNKNOWN `operand 2E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B063` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B068` write UNKNOWN `operand 2E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B06A` read UNKNOWN `operand 4C4` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8B075` write UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B077` write UNKNOWN `operand 64` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8AFF2 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AFF7 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AFFA JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8AFFD JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B001: indirect control flow; target set requires a reviewed dispatch contract or RAM state.
- B8B004 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B026 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B02A JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B02E JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B031 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B035 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B043 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B05B JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B07F JSL: M/X not assumed to survive; next variable length needs boundary evidence.

### B8B0D3..B8B115

Classification evidence: name/source token: kong

- `B8B0DD` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B0DF` read_write UNKNOWN `operand 5C` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B0E3` read UNKNOWN `operand 60` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B0E6` read UNKNOWN `operand 62` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B0E8` write UNKNOWN `operand 60` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B0EB` read UNKNOWN `operand 5E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B0ED` write UNKNOWN `operand 5E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B0F9` read UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B0FB` write UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B100` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B102` read UNKNOWN `operand 4F9` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8B10B` write UNKNOWN `operand 38` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8B0D3 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B0D6 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B0D9 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B105 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B10E JSL: M/X not assumed to survive; next variable length needs boundary evidence.

### B8B115..B8B137

Classification evidence: name/source token: kong

- `B8B115` read UNKNOWN `operand 474` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8B11E` write UNKNOWN `operand 474` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8B121` read UNKNOWN `operand 5A` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8B126` pointer UNKNOWN `operand B129` (absix); Indirect control pointer; pointer bank, runtime index/state and target set require review.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8B126: indirect control flow; target set requires a reviewed dispatch contract or RAM state.
- DATA boundary at B8B129; use table command, not code decoding.
- ROM-verified dispatch `B8B129`, stride 2, 7 targets; index bounds and dynamic selection unknown.

### B8B5D5..B8B5F0

Classification evidence: name/source token: kong

- `B8B5D8` read_write UNKNOWN `operand 5AF` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8B5DE` read UNKNOWN `operand 4FD` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8B5E1` read UNKNOWN `operand 38` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8B5DB JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B5E9 JSL: M/X not assumed to survive; next variable length needs boundary evidence.

### B8B5F0..B8B614

Classification evidence: name/source token: kong

- `B8B5F3` read_write UNKNOWN `operand 1927` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8B5F9` read UNKNOWN `operand 1925` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8B601` read UNKNOWN `operand 1923` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8B606` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B60B` write UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8B5F6 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B60D JSL: M/X not assumed to survive; next variable length needs boundary evidence.

### B8B614..B8B627

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8B617 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B61A JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B61D JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B620 JSL: M/X not assumed to survive; next variable length needs boundary evidence.

### B8B627..B8B62A

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.

### B8B62A..B8B630

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8B62A JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8B630..B8B67B

Classification evidence: name/source token: kong

- `B8B636` read UNKNOWN `operand 2E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B640` read UNKNOWN `operand 4F9` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8B643` read UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B645` read UNKNOWN `operand 16` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8B663` write UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8B630 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B633 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B63D JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B64A JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B64D JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B654 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B658 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B65C JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B668 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B674 JSL: M/X not assumed to survive; next variable length needs boundary evidence.

### B8B67B..B8B694

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8B67E JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B681 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B684 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B687 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B68A JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B68E JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8B694..B8B6AD

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8B697 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B69A JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B69D JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B6A0 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B6A3 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B6A7 JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8B6AD..B8B6C0

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8B6B0 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B6B3 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B6B6 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B6BA JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8B6C0..B8B6CC

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8B6C3 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B6C6 JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8B6CC..B8B729

Classification evidence: name/source token: kong

- `B8B6F1` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B6F3` read UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B71C` write UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B71E` write UNKNOWN `operand 2A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8B6CC JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B6D0 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B6D4 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B6DA JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B6DE JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B6E2 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B6E9 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B6ED JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B6FA JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B6FD JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B705 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B70D JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B715 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B723 JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8B75D..B8B76F

Classification evidence: name/source token: kong

- `B8B760` read_write UNKNOWN `operand 5AF` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8B766 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B769 JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8B76F..B8B89D

Classification evidence: name/source token: kong

- `B8B776` read UNKNOWN `operand 6A` (dily); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B778` read UNKNOWN `operand 72` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B77A` write UNKNOWN `operand 8` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8B780` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B782` read UNKNOWN `operand 4FB` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8B785` read UNKNOWN `operand 4` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8B795` read UNKNOWN `operand 6A` (dily); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B79D` read UNKNOWN `operand 6A` (dily); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B79F` write UNKNOWN `operand 30` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B7A4` read UNKNOWN `operand 6A` (dily); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B7C0` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B7C2` read UNKNOWN `operand 2E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B7D3` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B7D5` read UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B7EC` read UNKNOWN `operand 775` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8B7F4` pointer UNKNOWN `operand 4F5` (absil); Indirect control pointer; pointer bank, runtime index/state and target set require review.
- `B8B7FC` read UNKNOWN `operand 4F9` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8B7FF` read UNKNOWN `operand E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B81C` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B821` write UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B826` write UNKNOWN `operand 3A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B82F` write UNKNOWN `operand 1929` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8B835` write UNKNOWN `operand 192B` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8B838` read UNKNOWN `operand 4F9` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8B83B` read UNKNOWN `operand 4FD` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8B83E` read UNKNOWN `operand 1A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B840` write UNKNOWN `operand 1A` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8B84D` write UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B84F` write UNKNOWN `operand 2A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B851` write UNKNOWN `operand 30` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B873` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B878` write UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B881` write UNKNOWN `operand 1929` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8B887` write UNKNOWN `operand 192B` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8B891` write UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B89A` pointer UNKNOWN `operand 4F5` (absil); Indirect control pointer; pointer bank, runtime index/state and target set require review.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8B76F JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B77D JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B7A6 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B7AA JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B7AD JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B7B1 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B7B8 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B7BC JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B7C6 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B7CE JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B7DF JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B7E7 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B7F4: indirect control flow; target set requires a reviewed dispatch contract or RAM state.
- B8B80C JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B813 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B818 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B82B JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B843 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B846 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B856 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B85D JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B861 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B865 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B869 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B86F JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B87D JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B88A JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B896 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B89A: indirect control flow; target set requires a reviewed dispatch contract or RAM state.

### B8B8C0..B8B923

Classification evidence: name/source token: kong

- `B8B8EC` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B8EE` read UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B8F1` read UNKNOWN `operand 1973` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8B902` read UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B909` read UNKNOWN `operand 4BE` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8B910` read UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B91A` read_write UNKNOWN `operand 5AF` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8B920` pointer UNKNOWN `operand 4F5` (absil); Indirect control pointer; pointer bank, runtime index/state and target set require review.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8B8C0 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B8C6 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B8CA JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B8CE JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B8D2 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B8D6 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B8DB JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B8DF JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B8E7 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B8FC JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B91D JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B920: indirect control flow; target set requires a reviewed dispatch contract or RAM state.

### B8B97C..B8B9C6

Classification evidence: name/source token: kong

- `B8B97F` read_write UNKNOWN `operand 1927` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8B989` read UNKNOWN `operand 1925` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8B991` read UNKNOWN `operand 1923` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8B999` write UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B99B` read UNKNOWN `operand 775` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8B9A6` read UNKNOWN `operand 4F9` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8B9A9` read UNKNOWN `operand E` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8B9AC` read UNKNOWN `operand E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8B9B9` write UNKNOWN `operand 18B5` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8B982 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B985 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- No verified instruction boundary at B8B9C0; stopped.

### B8B9C6..B8B9DF

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8B9C6 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B9C9 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B9CE JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8B9D8 JSL: M/X not assumed to survive; next variable length needs boundary evidence.

### B8BAB2..B8BAB8

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8BAB2 JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8BAB8..B8BBE4

Classification evidence: name/source token: kong

- `B8BABB` read UNKNOWN `operand 4FD` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8BABE` read UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BAC8` write UNKNOWN `operand 1921` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8BACB` write UNKNOWN `operand 191F` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8BAD7` read UNKNOWN `operand 775` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8BAE4` read UNKNOWN `operand 4F9` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8BAE7` read UNKNOWN `operand 4FD` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8BAEA` read UNKNOWN `operand E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BAEC` read UNKNOWN `operand E` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8BAF4` write UNKNOWN `operand 18B5` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8BACE JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BAD3 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- No verified instruction boundary at B8BAFB; stopped.

### B8BBE4..B8BD06

Classification evidence: name/source token: kong

- `B8BBEB` read UNKNOWN `operand 6A` (dily); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BBED` read UNKNOWN `operand 72` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BBEF` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BBF1` read UNKNOWN `operand 2E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BBF6` write UNKNOWN `operand 8` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8BBFC` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BBFE` read UNKNOWN `operand 4FB` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8BC01` read UNKNOWN `operand 4` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8BC11` read UNKNOWN `operand 6A` (dily); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BC19` read UNKNOWN `operand 6A` (dily); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BC1B` write UNKNOWN `operand 30` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BC20` read UNKNOWN `operand 6A` (dily); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BC26` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BC28` read UNKNOWN `operand 503` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8BC2D` read UNKNOWN `operand 2E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BC31` read UNKNOWN `operand 2A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BC36` read_write UNKNOWN `operand 2A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BC38` read UNKNOWN `operand 4A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BC3D` write UNKNOWN `operand 4A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BC55` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BC57` read UNKNOWN `operand 2E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BC68` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BC6A` read UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BC81` read UNKNOWN `operand 775` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8BC89` pointer UNKNOWN `operand 4F5` (absil); Indirect control pointer; pointer bank, runtime index/state and target set require review.
- `B8BC91` read UNKNOWN `operand 4F9` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8BC94` read UNKNOWN `operand E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BCDC` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BCE1` write UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BCEA` write UNKNOWN `operand 1929` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8BCF0` write UNKNOWN `operand 192B` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8BCFA` write UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BD03` pointer UNKNOWN `operand 4F5` (absil); Indirect control pointer; pointer bank, runtime index/state and target set require review.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8BBE4 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BBF9 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BC22 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BC3F JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BC43 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BC46 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BC4D JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BC51 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BC5B JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BC63 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BC74 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BC7C JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BC89: indirect control flow; target set requires a reviewed dispatch contract or RAM state.
- B8BC9E JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BCA6 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BCAA JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BCAE JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BCB2 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BCB6 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BCBC JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BCC0 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BCC4 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BCC8 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BCD1 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BCD8 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BCE6 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BCF3 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BCFF JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BD03: indirect control flow; target set requires a reviewed dispatch contract or RAM state.

### B8BD29..B8BDD7

Classification evidence: name/source token: kong

- `B8BD4E` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BD50` read UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BD72` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BD74` read UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BD7B` read UNKNOWN `operand 1E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BD80` write UNKNOWN `operand 1E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BD85` read UNKNOWN `operand 6A` (dily); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BD87` read UNKNOWN `operand 1E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BD8F` write UNKNOWN `operand 2A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BD91` write UNKNOWN `operand 30` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BD96` read UNKNOWN `operand 6A` (dily); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BD98` write UNKNOWN `operand 5C` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BD9D` write UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BDA6` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BDA8` read UNKNOWN `operand 12` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BDAA` write UNKNOWN `operand 2C` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BDAC` write UNKNOWN `operand 54` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BDAE` read UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BDB4` write UNKNOWN `operand 32` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BDBA` write UNKNOWN `operand 56` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BDBC` write UNKNOWN `operand 58` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BDC6` read UNKNOWN `operand 0` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BDC8` write UNKNOWN `operand 10` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8BDCE` write UNKNOWN `operand 26` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8BD29 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BD2D JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BD31 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BD37 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BD3B JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BD3F JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BD46 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BD4A JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BD57 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BD5A JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BD62 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BD67 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BD6D JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BDA2 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BDBE JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BDC2 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BDD1 JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8BDD7..B8BE76

Classification evidence: name/source token: kong

- `B8BDD8` read_write UNKNOWN `operand 5C` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BDDC` write UNKNOWN `operand 30` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BDED` read UNKNOWN `operand 2A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BE19` write UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BE24` read UNKNOWN `operand 4F9` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8BE27` read UNKNOWN `operand 3A` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8BE2F` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BE31` read UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BE34` read UNKNOWN `operand 16` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8BE41` read UNKNOWN `operand 12` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BE44` read UNKNOWN `operand 12` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8BE50` read UNKNOWN `operand 12` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BE56` write UNKNOWN `operand D0` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BE5C` write UNKNOWN `operand D4` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BE5E` read UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BE60` write UNKNOWN `operand D6` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BE66` write UNKNOWN `operand D2` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BE68` write UNKNOWN `operand 78` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BE73` write UNKNOWN `operand 5C` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8BDDE JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BDE1 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BDE6 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BDE9 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BDF1 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BDF4 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BDF9 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BE04 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BE08 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BE0F JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BE1E JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BE6A JSL: M/X not assumed to survive; next variable length needs boundary evidence.

### B8BEAC..B8BEE8

Classification evidence: name/source token: kong

- `B8BEAC` read UNKNOWN `operand 28` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8BEB4` read UNKNOWN `operand 4E` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8BEB8` read UNKNOWN `operand 50` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8BEBD` read UNKNOWN `operand 12` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8BEC0` write UNKNOWN `operand 52` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8BEC6 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BEC9 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BECC JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BECF JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BED8 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BEDB JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BEDF JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BEE2 JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8BF19..B8BF20

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8BF19 JSL: M/X not assumed to survive; next variable length needs boundary evidence.

### B8BF20..B8BF97

Classification evidence: name/source token: kong

- `B8BF20` write UNKNOWN `operand 1921` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8BF23` write UNKNOWN `operand 191F` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8BF2F` read UNKNOWN `operand 775` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8BF3C` read UNKNOWN `operand 4F9` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8BF3F` read UNKNOWN `operand 4FD` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8BF42` read UNKNOWN `operand E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BF44` read UNKNOWN `operand E` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8BF4C` write UNKNOWN `operand 18B5` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8BF26 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BF2B JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- No verified instruction boundary at B8BF53; stopped.

### B8BF97..B8BFB4

Classification evidence: name/source token: kong

- `B8BF98` write UNKNOWN `operand 2A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BF9A` read UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BF9C` read UNKNOWN `operand 50F` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8BFA4` write UNKNOWN `operand 2E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BFB1` pointer UNKNOWN `operand 4F5` (absil); Indirect control pointer; pointer bank, runtime index/state and target set require review.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8BFA6 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BFA9 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BFAD JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BFB1: indirect control flow; target set requires a reviewed dispatch contract or RAM state.

### B8BFB4..B8BFB7

Classification evidence: name/source token: kong

- `B8BFB4` pointer UNKNOWN `operand 4F5` (absil); Indirect control pointer; pointer bank, runtime index/state and target set require review.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8BFB4: indirect control flow; target set requires a reviewed dispatch contract or RAM state.

### B8BFB7..B8BFD3

Classification evidence: name/source token: kong

- `B8BFBA` read_write UNKNOWN `operand 1927` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8BFC0` read_write UNKNOWN `operand 5AF` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8BFC6 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BFC9 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BFCD JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8BFD3..B8BFDA

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8BFD3 JSL: M/X not assumed to survive; next variable length needs boundary evidence.

### B8BFDA..B8C037

Classification evidence: name/source token: kong

- `B8BFEA` read UNKNOWN `operand 7E` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BFF1` write UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8BFFF` read_write UNKNOWN `operand 5AF` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8C002` read_write UNKNOWN `operand 0` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C007` write UNKNOWN `operand 194D` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8C00A` read_write UNKNOWN `operand 64` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C00C` read UNKNOWN `operand 64` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C018` pointer UNKNOWN `operand 4F5` (absil); Indirect control pointer; pointer bank, runtime index/state and target set require review.
- `B8C01E` write UNKNOWN `operand 26` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C020` pointer UNKNOWN `operand 4F5` (absil); Indirect control pointer; pointer bank, runtime index/state and target set require review.
- `B8C023` write UNKNOWN `operand 26` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C025` read UNKNOWN `operand 5B9` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8C034` pointer UNKNOWN `operand 4F5` (absil); Indirect control pointer; pointer bank, runtime index/state and target set require review.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8BFDD JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BFE5 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8BFF6 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C018: indirect control flow; target set requires a reviewed dispatch contract or RAM state.
- B8C020: indirect control flow; target set requires a reviewed dispatch contract or RAM state.
- B8C030 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C034: indirect control flow; target set requires a reviewed dispatch contract or RAM state.

### B8C037..B8C04A

Classification evidence: name/source token: kong

- `B8C042` read UNKNOWN `operand 189D` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8C045` write UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8C03A JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8C04A..B8C06E

Classification evidence: name/source token: kong

- `B8C04A` read UNKNOWN `operand 1B63` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8C04F` write UNKNOWN `operand 2E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C051` read UNKNOWN `operand 12` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8C055` read UNKNOWN `operand 196D` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8C060` write UNKNOWN `operand 38` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8C063 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C067 JSL: M/X not assumed to survive; next variable length needs boundary evidence.

### B8C06E..B8C07C

Classification evidence: name/source token: kong

- `B8C06E` read UNKNOWN `operand 1B63` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8C073` write UNKNOWN `operand 2E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8C075 JSL: M/X not assumed to survive; next variable length needs boundary evidence.

### B8C07C..B8C09D

Classification evidence: name/source token: kong

- `B8C08F` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C091` write UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8C07F JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C082 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C085 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C088 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C08C JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C093 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C096 JSL: M/X not assumed to survive; next variable length needs boundary evidence.

### B8C09D..B8C0A4

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8C09D JSL: M/X not assumed to survive; next variable length needs boundary evidence.

### B8C0A4..B8C0D4

Classification evidence: name/source token: kong

- `B8C0AA` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C0AC` read UNKNOWN `operand 12` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C0AE` read UNKNOWN `operand 18A7` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8C0B3` read UNKNOWN `operand 18A9` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8C0C1` read UNKNOWN `operand 5A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C0C5` read_write UNKNOWN `operand 5C` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C0CC` write UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8C0A7 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C0B8 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C0BB JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C0CE JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8C0D4..B8C0E2

Classification evidence: name/source token: kong

- `B8C0D4` read UNKNOWN `operand 5A` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8C0D9` pointer UNKNOWN `operand C0DC` (absix); Indirect control pointer; pointer bank, runtime index/state and target set require review.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8C0D9: indirect control flow; target set requires a reviewed dispatch contract or RAM state.
- DATA boundary at B8C0DC; use table command, not code decoding.
- ROM-verified dispatch `B8C0DC`, stride 2, 3 targets; index bounds and dynamic selection unknown.

### B8C181..B8C195

Classification evidence: name/source token: kong

- `B8C181` read UNKNOWN `operand 5A` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8C186` pointer UNKNOWN `operand C189` (absix); Indirect control pointer; pointer bank, runtime index/state and target set require review.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8C186: indirect control flow; target set requires a reviewed dispatch contract or RAM state.
- DATA boundary at B8C189; use table command, not code decoding.
- ROM-verified dispatch `B8C189`, stride 2, 6 targets; index bounds and dynamic selection unknown.

### B8C265..B8C28B

Classification evidence: name/source token: kong

- `B8C268` read_write UNKNOWN `operand 1927` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8C274` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C276` read UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C27C` read UNKNOWN `operand 50F` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8C26E JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C271 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C284 JSL: M/X not assumed to survive; next variable length needs boundary evidence.

### B8C28B..B8C328

Classification evidence: name/source token: kong

- `B8C28B` read UNKNOWN `operand 5A` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8C296` read UNKNOWN `operand 1E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C29D` write UNKNOWN `operand 191F` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8C2A3` write UNKNOWN `operand 1921` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8C2A6` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C2A8` read UNKNOWN `operand 186B` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8C2AF` read UNKNOWN `operand 12` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8C2B3` read UNKNOWN `operand 12` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C2B5` read UNKNOWN `operand 1E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C2BD` write UNKNOWN `operand 186D` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8C2C0` read UNKNOWN `operand 16` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8C2C4` read UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C2C6` write UNKNOWN `operand 186F` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8C2CC` read UNKNOWN `operand 12` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C2CE` write UNKNOWN `operand 81C` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8C2D1` read UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C2D3` write UNKNOWN `operand 820` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8C2D6` write UNKNOWN `operand 4F9` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8C2E0` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C2E2` write UNKNOWN `operand 4F9` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8C2E5` read UNKNOWN `operand 81C` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8C2E8` write UNKNOWN `operand 5C` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C2EA` read_write UNKNOWN `operand 5A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C2FA` read UNKNOWN `operand 5C` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C2FC` read UNKNOWN `operand 12` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C302` read_write UNKNOWN `operand 12` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C306` read_write UNKNOWN `operand 12` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C315` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8C31A` write UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8C2AB JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C2C9 PLP: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C2DC JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C2EF JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C2F2 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C30B JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C30E JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C31F JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C322 JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8C328..B8C334

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8C32B JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C32E JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8C334..B8C33A

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8C334 JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8C3FA..B8C40C

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8C3FD JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C400 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C403 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C406 JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8C40C..B8C421

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8C40F JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C412 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C415 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C418 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C41B JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8C421..B8C433

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8C424 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C427 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C42A JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C42D JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8C433..B8C442

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8C436 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C439 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C43C JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8C442..B8C451

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8C445 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C448 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C44B JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8C451..B8C45D

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8C454 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C457 JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8C45D..B8C469

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8C460 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C463 JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8C469..B8C476

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8C469 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C46C JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C470 JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8C476..B8C483

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8C476 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C479 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C47D JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8F2BB..B8F2C1

Classification evidence: name/source token: kong

- `B8F2BE` pointer UNKNOWN `operand 4F5` (absil); Indirect control pointer; pointer bank, runtime index/state and target set require review.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8F2BB JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8F2BE: indirect control flow; target set requires a reviewed dispatch contract or RAM state.

### B8F2C1..B8F2CB

Classification evidence: name/source token: kong

- `B8F2C8` pointer UNKNOWN `operand 4F5` (absil); Indirect control pointer; pointer bank, runtime index/state and target set require review.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8F2C1 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8F2C5 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8F2C8: indirect control flow; target set requires a reviewed dispatch contract or RAM state.

### B8F2CE..B8F2E2

Classification evidence: name/source token: kong

- `B8F2DF` pointer UNKNOWN `operand 4F5` (absil); Indirect control pointer; pointer bank, runtime index/state and target set require review.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8F2D1 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8F2D5 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8F2D8 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8F2DC JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8F2DF: indirect control flow; target set requires a reviewed dispatch contract or RAM state.

### B8F2E2..B8F2F6

Classification evidence: name/source token: kong

- `B8F2F3` pointer UNKNOWN `operand 4F5` (absil); Indirect control pointer; pointer bank, runtime index/state and target set require review.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8F2E2 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8F2E5 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8F2E8 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8F2EC JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8F2F0 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8F2F3: indirect control flow; target set requires a reviewed dispatch contract or RAM state.

### B8F2F6..B8F339

Classification evidence: name/source token: kong

- `B8F2FC` read UNKNOWN `operand 12` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8F303` read UNKNOWN `operand 5C` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8F305` read UNKNOWN `operand 12` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8F30C` write UNKNOWN `operand 38` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8F311` read_write UNKNOWN `operand 5AF` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8F321` pointer UNKNOWN `operand 4F5` (absil); Indirect control pointer; pointer bank, runtime index/state and target set require review.
- `B8F32C` pointer UNKNOWN `operand 4F5` (absil); Indirect control pointer; pointer bank, runtime index/state and target set require review.
- `B8F336` pointer UNKNOWN `operand 4F5` (absil); Indirect control pointer; pointer bank, runtime index/state and target set require review.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8F2F6 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8F2F9 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8F31D JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8F321: indirect control flow; target set requires a reviewed dispatch contract or RAM state.
- B8F324 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8F328 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8F32C: indirect control flow; target set requires a reviewed dispatch contract or RAM state.
- B8F32F JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8F332 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8F336: indirect control flow; target set requires a reviewed dispatch contract or RAM state.

### B8F339..B8F348

Classification evidence: name/source token: kong

- `B8F33C` write UNKNOWN `operand 38` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8F33F` read UNKNOWN `operand 5C` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8F345` pointer UNKNOWN `operand 4F5` (absil); Indirect control pointer; pointer bank, runtime index/state and target set require review.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8F342 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8F345: indirect control flow; target set requires a reviewed dispatch contract or RAM state.

### B8F2CB..B8F2CE

Classification evidence: name/source token: kong

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8F2CB JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B8F348..B8F35B

Classification evidence: name/source token: kong

- `B8F34B` write UNKNOWN `operand 38` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B8F358` pointer UNKNOWN `operand 4F5` (absil); Indirect control pointer; pointer bank, runtime index/state and target set require review.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8F351 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8F355 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8F358: indirect control flow; target set requires a reviewed dispatch contract or RAM state.

### B9A015..B9A018

Classification evidence: No reviewed semantic contract; anonymous addresses do not identify behavior.

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.

### B8E587..B8E5B3

Classification evidence: No reviewed semantic contract; anonymous addresses do not identify behavior.

- `B8E587` read UNKNOWN `operand 6C` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8E589` write UNKNOWN `operand 44` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8E58B` read ROM `FF1C18` (longx); Base address only; runtime X and word wrapping require review.
- `B8E58F` write UNKNOWN `operand 42` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8E591` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8E593` write UNKNOWN `operand 62` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8E595` write UNKNOWN `operand 64` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8E597` write UNKNOWN `operand 66` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8E599` read UNKNOWN `operand 3A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8E59E` write UNKNOWN `operand 3A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8E5A3` read UNKNOWN `operand 42` (dily); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8E5A6` read UNKNOWN `operand 62` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B8E5B0` write UNKNOWN `operand 62` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.

### B9F1E0..B9F226

Classification evidence: No reviewed semantic contract; anonymous addresses do not identify behavior.

- `B9F1E0` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F1E2` read UNKNOWN `operand 29` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F1EC` read UNKNOWN `operand 2A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F1F2` read UNKNOWN `operand 11` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F1F4` write UNKNOWN `operand 11` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F1F7` read UNKNOWN `operand 13` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F1FB` write UNKNOWN `operand 13` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F200` read UNKNOWN `operand 2E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F204` read UNKNOWN `operand 18` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F206` write UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F208` read UNKNOWN `operand 52` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F20B` read UNKNOWN `operand 12` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F20D` write UNKNOWN `operand 12` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F212` read UNKNOWN `operand 2A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F218` read UNKNOWN `operand 11` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F21A` write UNKNOWN `operand 11` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F21D` read UNKNOWN `operand 13` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F221` write UNKNOWN `operand 13` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.

### B9F13A..B9F163

Classification evidence: No reviewed semantic contract; anonymous addresses do not identify behavior.

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B9F13A JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B9F14C JSL: M/X not assumed to survive; next variable length needs boundary evidence.

### B9F181..B9F1E0

Classification evidence: No reviewed semantic contract; anonymous addresses do not identify behavior.

- Source lead `src/core/RomTerrain.h:54`: // B9:F181..F1AD; called only after horizontal blockage is established.
- `B9F181` read UNKNOWN `operand 54` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F183` write UNKNOWN `operand 12` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F185` write UNKNOWN `operand 10` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F187` read UNKNOWN `operand 30` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F189` write UNKNOWN `operand AE` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F18B` write UNKNOWN `operand 30` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F18D` read UNKNOWN `operand 2A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F18F` write UNKNOWN `operand B0` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F191` write UNKNOWN `operand 2A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F196` read UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F198` write UNKNOWN `operand 28` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F1A2` write UNKNOWN `operand 8A` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F1A5` read UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F1A9` read UNKNOWN `operand 56` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F1AB` write UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F1AE` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F1B3` read UNKNOWN `operand 2A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F1B9` read UNKNOWN `operand 11` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F1BB` write UNKNOWN `operand 11` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F1BE` read UNKNOWN `operand 13` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F1C2` write UNKNOWN `operand 13` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F1C7` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F1CC` read UNKNOWN `operand 2E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F1D2` read UNKNOWN `operand 15` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F1D4` write UNKNOWN `operand 15` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F1D7` read UNKNOWN `operand 17` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F1DB` write UNKNOWN `operand 17` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B9F19F JSR: M/X not assumed to survive; next variable length needs boundary evidence.

### B9F165..B9F169

Classification evidence: No reviewed semantic contract; anonymous addresses do not identify behavior.

- `B9F165` write UNKNOWN `operand 1C` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F167` read UNKNOWN `operand 12` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.

### B9F226..B9F260

Classification evidence: No reviewed semantic contract; anonymous addresses do not identify behavior.

- `B9F226` read UNKNOWN `operand 70` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F228` read UNKNOWN `operand 29` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F232` read UNKNOWN `operand 2E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F238` read UNKNOWN `operand 15` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F23A` write UNKNOWN `operand 15` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F23D` read UNKNOWN `operand 17` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F241` write UNKNOWN `operand 17` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F246` read UNKNOWN `operand 4C` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F248` read UNKNOWN `operand 2E` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F24B` read UNKNOWN `operand 2E` (absy); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B9F250` read UNKNOWN `operand 18` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F256` write UNKNOWN `operand 16` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F258` write UNKNOWN `operand 1A` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B9F25D` write UNKNOWN `operand 14` (dpx); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.

### B28124..B28207

Classification evidence: No reviewed semantic contract; anonymous addresses do not identify behavior.

- `B28129` read UNKNOWN `operand 44A` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B2812E` read UNKNOWN `operand 436` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B28131` read UNKNOWN `operand 43A` (absx); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B2813E` read UNKNOWN `operand 43A` (absx); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B28144` write UNKNOWN `operand 43A` (absx); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B28147` write UNKNOWN `operand 436` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B28151` read UNKNOWN `operand 44A` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B2815F` read UNKNOWN `operand 428` (absx); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B28164` read UNKNOWN `operand 420` (absx); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B28169` write UNKNOWN `operand 428` (absx); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B28179` write UNKNOWN `operand 420` (absx); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B2817E` read UNKNOWN `operand 81F3` (absx); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B28181` read_write UNKNOWN `operand 430` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B28186` read UNKNOWN `operand 81F3` (absx); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B28189` read_write UNKNOWN `operand 430` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B2818C` read UNKNOWN `operand 420` (absx); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B28199` read UNKNOWN `operand 0` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B2819B` read UNKNOWN `operand 438` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B281A0` read UNKNOWN `operand 434` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B281A3` read UNKNOWN `operand 43A` (absx); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B281A8` write UNKNOWN `operand 43A` (absx); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B281AF` read UNKNOWN `operand 434` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B281B7` write UNKNOWN `operand 434` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B281BA` read UNKNOWN `operand 0` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B281BC` write UNKNOWN `operand 438` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B281C6` read UNKNOWN `operand 428` (absx); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B281C9` read UNKNOWN `operand 420` (absx); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B281D5` write UNKNOWN `operand 420` (absx); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B281DB` read UNKNOWN `operand 81F3` (absx); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B281DE` read_write UNKNOWN `operand 430` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B281E3` read UNKNOWN `operand 81F3` (absx); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B281E6` read_write UNKNOWN `operand 430` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B28128 PLB: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.
- B2814C PLB: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.
- B28150 PLB: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.
- B28170 PLB: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.
- B28192 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B28198 PLB: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.
- B281AB JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B281BF PLB: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.
- B281D3 PLB: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.
- B281EE JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B281F1 PLB: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.
- DATA boundary at B281F3; use table command, not code decoding.

### B2802D..B28104

Classification evidence: No reviewed semantic contract; anonymous addresses do not identify behavior.

- `B2803C` write UNKNOWN `operand 1A` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B28041` write UNKNOWN `operand 1C` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B2804E` write UNKNOWN `operand 8` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B28071` read UNKNOWN `operand 432` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B28080` write UNKNOWN `operand 8` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B2809E` read UNKNOWN `operand 432` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B280B1` write UNKNOWN `operand 8` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B280D9` read UNKNOWN `operand 432` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B280F8` read UNKNOWN `operand 432` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B2802F PLB: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.
- B28030 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B28033 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B28036 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B28043 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B28046 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B28049 PLB: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.
- B2804D PLB: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.
- B28053 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B28056 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B28059 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B2805C JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B2805F JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B28062 PLB: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.
- B28066 PLB: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.
- B28067 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B2806E JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B28078 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B2807B PLB: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.
- B2807F PLB: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.
- B28085 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B28088 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B2808B JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B2808E JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B28091 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B28094 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B2809B JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B280A5 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B280A8 PLB: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.
- B280AC PLB: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.
- B280B6 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B280B9 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B280BC JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B280BF JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B280C2 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B280C5 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B280D0 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B280D6 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B280E0 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B280E3 PLB: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.
- B280E7 PLB: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.
- B280EF JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B280F5 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B280FF JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B28102 PLB: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.

### B2804B..B28104

Classification evidence: No reviewed semantic contract; anonymous addresses do not identify behavior.

- `B2804E` write UNKNOWN `operand 8` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B28071` read UNKNOWN `operand 432` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B28080` write UNKNOWN `operand 8` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B2809E` read UNKNOWN `operand 432` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B280B1` write UNKNOWN `operand 8` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B280D9` read UNKNOWN `operand 432` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B280F8` read UNKNOWN `operand 432` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B2804D PLB: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.
- B28053 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B28056 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B28059 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B2805C JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B2805F JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B28062 PLB: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.
- B28066 PLB: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.
- B28067 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B2806E JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B28078 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B2807B PLB: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.
- B2807F PLB: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.
- B28085 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B28088 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B2808B JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B2808E JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B28091 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B28094 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B2809B JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B280A5 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B280A8 PLB: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.
- B280AC PLB: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.
- B280B6 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B280B9 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B280BC JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B280BF JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B280C2 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B280C5 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B280D0 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B280D6 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B280E0 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B280E3 PLB: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.
- B280E7 PLB: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.
- B280EF JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B280F5 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B280FF JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B28102 PLB: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.

### B28064..B28104

Classification evidence: No reviewed semantic contract; anonymous addresses do not identify behavior.

- `B28071` read UNKNOWN `operand 432` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B28080` write UNKNOWN `operand 8` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B2809E` read UNKNOWN `operand 432` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B280B1` write UNKNOWN `operand 8` (dp); Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.
- `B280D9` read UNKNOWN `operand 432` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- `B280F8` read UNKNOWN `operand 432` (abs); DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.
- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B28066 PLB: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.
- B28067 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B2806E JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B28078 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B2807B PLB: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.
- B2807F PLB: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.
- B28085 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B28088 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B2808B JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B2808E JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B28091 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B28094 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B2809B JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B280A5 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B280A8 PLB: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.
- B280AC PLB: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.
- B280B6 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B280B9 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B280BC JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B280BF JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B280C2 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B280C5 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B280D0 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B280D6 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B280E0 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B280E3 PLB: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.
- B280E7 PLB: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.
- B280EF JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B280F5 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B280FF JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B28102 PLB: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.


## Unknowns

- Runtime DBR/direct-page/register/flags contracts and indirect targets are not inferred.
- Level association is metadata/audit/source evidence, not proof that every selected routine executes in that level.
- Original instruction coverage and full function boundaries remain unknown.
- Native audio and level effects need observed original reference contracts.
