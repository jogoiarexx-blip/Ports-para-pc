# Native renderer contract

`NativeScene` is a host compositor over decoded tile, map, palette and RGBA sprite data. It does not execute a PPU, DMA or HDMA. These operations supply a semantic replacement interface; no DKC3 DMA pattern, water effect or original routine translation is verified by them.

Only Mode 1 (BG1/BG2 4bpp, BG3 2bpp, 8×8 tiles) is supported. `validateNativeScene` and `renderNativeSceneChecked` reject other modes and unsupported CGWSEL flags. The checked call leaves the destination untouched on failure; the compatibility `renderNativeScene` wrapper clears a bounded valid target to black. Main/subscreen selection, tile priorities, transparent index zero, tile flips, fixed/subscreen color add/subtract and brightness are supported. Direct color, mosaic, interlace, Mode 7, hardware window registers, OAM rotation/limits and cycle timing are unsupported.

| Host operation | Contract |
| --- | --- |
| `setPalette(scene, first, colors)` | Replace an existing range of 15-bit colors. |
| `updateTilemap(scene, layer, x, y, width, height, entries)` | Replace a bounded rectangular row-major tilemap region. |
| `updateTiles(scene, layer, firstTile, pixels)` | Replace complete 64-index tiles, checking the layer's bpp range. |
| `setLayerScroll(scene, layer, x, y)` | Set signed pixel scroll, with wrapped tilemap sampling. |
| `setLayerParallax(scene, layer, x256, y256)` | Scale camera motion by signed factors /256; integer division truncates toward zero. |
| `updateScanlineOffsets(scene, layer, rows)` | Add signed x/y offsets per viewport row; omitted rows use zero. |
| `updateGradient(scene, rows)` | Set fixed-color values per viewport row; omitted rows use `fixedColor`. |

Updates reject invalid ranges without changing scene data. Inputs may alias the updated vectors. Empty scanline/gradient arrays reset the override. Exported tile sampling retains `y + scrollY + cameraY + 1`, including the historical one-line offset.

A `NativePixelMask` has viewport dimensions and one byte per pixel. Empty means unrestricted; zero and out-of-mask coordinates reject the pixel. Each layer and scene sprite has independent main/subscreen masks. `colorMathMask` gates math after composition. Masks are already resolved host data; register window logic is not inferred.

`NativeScene::sprites` owns decoded `NativeSceneSprite` values. Positions are world pixels, camera subtraction follows the existing sprite origin convention, flips affect both axes, and OBJ must be selected by bit 4 of TM/TS. Priorities 0–3 occupy the existing Mode 1 ordering, including BG3 priority mode. Equal sprite priorities use submission order (later wins), a host contract rather than SNES OAM ordering. Partial alpha uses rounded straight-alpha blending with divisor 255. Sprite math requires explicit `colorMath=true`; its RGBA result is quantized to 15 bits for math. This flag replaces palette eligibility metadata that RGBA exports lack. Existing Game actors still use `drawNativeSprite`; submitting actors through the scene compositor is a separate integration step.

Three bugs were reproduced before the change: a disabled host layer still drew, `(31 + 31)/2` was incorrectly saturated before division, and half-alpha red over blue used divisor 256. They now produce black, red=31, and `0xff80007f` respectively. Empty subscreen pixels retain the fixed-color fallback; half is suppressed for that fallback. The intended arithmetic is explicitly tested, not certified against an executing SNES reference. Basic screen/color/window concepts were checked against Nintendo's SNES Development Manual, Book I §6–7 ([republished scan](https://www.scribd.com/document/508113076/snes-manual1)).

V1 scene exports record layer enable from TM. Loading normalizes it with TS so subscreen-only layers remain active; manually setting `enabled=false` disables both screens. Parsers bound tile/map/palette/sprite allocation, reject truncation and malformed records, and recognize `source_frame` as metadata. The binary assets retain their existing little-endian host format.

Validation: initial 7 checks reproduced 3 failures; the final 164 checks pass under C++20 with `-Wall -Wextra -Werror`, and ASan/UBSan pass with leak detection disabled because this environment blocks LeakSanitizer's process inspection. Tests cover transparency, enable/selection, all 48 background/sprite priority combinations, negative scroll, both tile/sprite flips, alpha, masks, arithmetic, parallax, scanline/gradient updates, update bounds, malformed assets and unsupported modes.

Original baseline and new 256×224 asset frames have identical hashes:

| Scene | Frame hash |
| --- | --- |
| Doorstop | `27ec6ec224a8886c` |
| Tidal page 0 | `87a9cca4d49dae00` |
| Tidal page 1 | `bed80ea9cc2ec1f4` |
| Tidal page 2 | `518b0ac426a29e44` |

Standalone command from the project root:

```sh
g++ -std=c++20 -Wall -Wextra -Werror -Isrc tests/native_renderer_tests.cpp src/core/NativeScene.cpp src/core/NativeSprite.cpp -o /tmp/native_renderer_tests
/tmp/native_renderer_tests
```

## Offline transfer converter

`python tools/convert_video_trace.py captured.json --output operations.json`
consumes `dkc3.video-transfer-trace.v1` and emits
`dkc3.native-video-operations.v1`. Each event must be explicitly complete.
Supported raw DMA captures are incrementing A-to-B transfers during vblank or
forced blank, in bus-write order: CGRAM port $2122/mode 0 with known low latch;
or VRAM $2118/mode 1/VMAIN $80 with an explicit tile/tilemap destination binding.
Tile uploads decode complete 2/4bpp planar tiles offline. Tilemaps require a
contiguous rectangle in a known SNES 32x32 page. Bounds/wrap/partial transfers
fail visibly; the command exits 2 if any event is unsupported.

Resolved semantic inputs can supply palettes, row-major maps, tiles, scanline
offsets and fixed-color gradients. These are explicitly labeled semantic
adapters, not raw HDMA decoding. Raw HDMA and OAM transfers are unsupported.
The JSON operations target the C++ API names in the table above; importing
arbitrary JSON into a live Game scene is not implemented. No captured original
DKC3 transfer sequence was supplied, so these unit-tested conversions do not
establish level-specific coverage.
