# Validação — DKC3 Native PC v0.64.0

## Objetivo

Avançar o gargalo MILL `$198D` sem quebrar PIER e corrigir o bloqueador de encoding que fazia o build Windows falhar no teste `native_map` ao escrever `ROM Trace → Native Map` usando o `charmap` local.

## Mudança estrutural

Foi criado `decodeRomScenarioLayout`, que segue as tabelas da própria ROM em vez de uma lista de offsets por fase. O caminho resolve `shared_data -> family index -> B7:B01B -> family config -> asset header -> streams` e descompacta level map, map32 e foreground, além de copiar as definições de terreno.

PIER usa o novo caminho para esses quatro blocos. Isso funciona como regressão: a família já jogável continua chegando aos mesmos dados enquanto MILL usa exatamente a mesma infraestrutura.

MILL `$198D/$1998` agora resolve família 5 / `B7:B302`, handler `B7:CB2B`, shape 7 e os assets documentados em `ROM-MILL-LAYOUT-PACKET.md`. `romScenarioMapMetatile` centraliza os strides e foi testado em coordenadas conhecidas de PIER, Doorstop e Squeals.

## Correção Windows UTF-8

- `BUILD-WINDOWS.cmd`: `PYTHONUTF8=1` e `PYTHONIOENCODING=utf-8`.
- testes Python disparados pelo CMake recebem o mesmo ambiente.
- `native_map.py` abre/lê/grava os artefatos relevantes em UTF-8 explícito.
- demais writers tocados nesta rodada também usam UTF-8 explícito.
- o teste do Native Map lê o Markdown como UTF-8 e exige literalmente `ROM Trace → Native Map`.
- o conjunto de 11 testes do Native Map também foi executado sob `LC_ALL=C`, `PYTHONUTF8=0` e `PYTHONIOENCODING=cp1252`: 11/11 passaram.

## Limites

Esta versão não chama MILL de renderer completo. `RomLevelRuntime::load` continua rejeitando shared_data diferente de PIER no caminho gráfico. O próximo gargalo é traduzir/integrar a semântica da shape 7 e `B7:CB2B`, depois palette/background/câmera, antes de retirar `doorstop.nscene`.

## Resultado de testes nesta árvore

- CMake/GCC Release: compilação concluída.
- CTest completo: **37/37 passed**, 0 falhas.
- Native Map sob ambiente restritivo equivalente ao problema de encoding: **11/11 passed**.
- Testes direcionados `native_rom_runtime`, `rom_workbench` e `native_map`: todos passaram após a mudança.
