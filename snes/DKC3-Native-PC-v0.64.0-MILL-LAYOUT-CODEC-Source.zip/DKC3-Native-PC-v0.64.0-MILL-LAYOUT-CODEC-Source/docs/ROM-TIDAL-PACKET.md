# Port packet: tidal

ROM SHA256: `2277a2d8dddb01fe5cb0ae9a0fa225d42b3a11adccaeafa18e3c339b3794a32b`

This is an analysis packet, not generated game code or a complete translation.

# ROM BB8FF9..BB9020

Static reading only; no CPU/PPU execution. Bytes and operands come from the current ROM.

Catalog entry: parse_initscript — entry M/X hint `0,0`; not an exit proof.

```text
BB8FF9  8B          PHB                      parse_initscript
BB8FFA  80 09       BRA $BB9005              
BB8FFC  5B          TCD                      set_sprite_config
BB8FFD  B9 01 00    LDA $0001,Y              
BB9000  95 00       STA $00,X                
BB9002  C8          INY                      initscript_next
BB9003  C8          INY                      
BB9004  C8          INY                      
BB9005  B9 00 00    LDA $0000,Y              parse_initscript_entry
BB9008  29 FF 00    AND #$00FF               
BB900B  C9 EF 00    CMP #$00EF               
BB900E  90 EC       BCC $BB8FFC              
BB9010  49 FF 00    EOR #$00FF               
BB9013  0A          ASL A                    
BB9014  AA          TAX                      
BB9015  7C 18 90    JMP ($9018,X)            
```

## References

- JSL from `BB91BF` to `BB8FF9`
- JSL from `BB91E5` to `BB8FF9`
- JSL from `BB9382` to `BB8FF9`
- BRA at `BB8FFA` to `BB9005` parse_initscript_entry
- BCC at `BB900E` to `BB8FFC` set_sprite_config
- Indirect contract (metadata): `indirect_dispatch 9015 17 ptrtail targets:BB9062,BB9071,BB9096,BB9119,BB9137,BB917E,BB91B4,BB91C9,BB91F4,BB92C2,BB9350,BB936B,BB9190,BB90AB,BB9452,BB9048,BB9041`
- Indirect contract (metadata): `ROM-verified table initscript_commands at BB9018; 17 targets, stride=2; index bounds not proven`

## Native source leads (not coverage proof)


## Unknowns and obligations

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- BB8FFC TCD: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.
- BB9015: indirect control flow; target set requires a reviewed dispatch contract or RAM state.
- DATA boundary at BB9018; use table command, not code decoding.
- Short memory operands require DBR/direct-page context; a source name or address mention alone does not establish a physical memory address.
- Preserve word wrap, carry/sign flags and memory offsets; verify the C++ with bounded original-routine oracles and input replays.

# ROM BBA0D1..BBA100

Static reading only; no CPU/PPU execution. Bytes and operands come from the current ROM.

Catalog entry: CODE_BBA0D1 — entry M/X hint `0,0`; not an exit proof.

```text
BBA0D1  A2 FD FF    LDX #$FFFD               CODE_BBA0D1
BBA0D4  A5 C0       LDA $C0                  
BBA0D6  F0 49       BEQ $BBA121              
BBA0D8  E2 20       SEP #$20                 
BBA0DA  3A          DEC A                    
BBA0DB  E8          INX                      CODE_BBA0DB
BBA0DC  E8          INX                      
BBA0DD  E8          INX                      
BBA0DE  DF BC B7 BB CMP $BBB7BC,X            
BBA0E2  B0 F7       BCS $BBA0DB              
BBA0E4  49 FF       EOR #$FF                 
BBA0E6  7F BC B7 BB ADC $BBB7BC,X            
BBA0EA  C2 20       REP #$20                 
BBA0EC  D0 33       BNE $BBA121              
BBA0EE  BF BE B7 BB LDA $BBB7BE,X            
BBA0F2  29 FF 00    AND #$00FF               
BBA0F5  8D 05 05    STA $0505                
BBA0F8  BF BD B7 BB LDA $BBB7BD,X            
BBA0FC  29 FF 00    AND #$00FF               
BBA0FF  0A          ASL A                    
```

## References

- JSR from `BB9C32` to `BBA0D1`
- JSR from `BB9C4D` to `BBA0D1`
- BEQ at `BBA0D6` to `BBA121` CODE_BBA121
- BCS at `BBA0E2` to `BBA0DB` CODE_BBA0DB
- BNE at `BBA0EC` to `BBA121` CODE_BBA121
- Long operand `BBB7BC` at `BBA0DE`; indexed=True. Size/payload type still require review.
- Long operand `BBB7BC` at `BBA0E6`; indexed=True. Size/payload type still require review.
- Long operand `BBB7BE` at `BBA0EE`; indexed=True. Size/payload type still require review.
- Long operand `BBB7BD` at `BBA0F8`; indexed=True. Size/payload type still require review.

## Native source leads (not coverage proof)

- `src/core/RomData.cpp:712` — // BB:A0D1 searches the ROM's level/index/behavior triples at BB:B7BC.

## Unknowns and obligations

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- Short memory operands require DBR/direct-page context; a source name or address mention alone does not establish a physical memory address.
- Preserve word wrap, carry/sign flags and memory offsets; verify the C++ with bounded original-routine oracles and input replays.

## TIDAL-SPAWN-AUDIT.txt

```text
placements=61 SUPPORTED=0 PARTIAL=27 UNKNOWN=34
index,sprite_id,descriptor,type,parameter,x,y,status,behavior,limitation,animation_id,initial_state,reward,conditional
0,0x160,0x5ad6,0x26,0x4,8112,585,PARTIAL,Level byte trigger,ROM clipping and byte operation; carried/thrown contact; original Kong state $4F and RAM consumers pending,0x0,0x1,0xffff,0
1,0x170,0x5da9,0x70,0x4,288,501,PARTIAL,Barrel respawner,ROM child type, spacing and timer; host active window; four-slot pool and original visibility pending,0x0,0x0,0x468,0
2,0x190,0x8a6b,0x5a4,0x4,576,617,PARTIAL,Koin and DK Coin controller,ROM steel-hit predicate, aim graphics and two-bit progress; host contact, coin flight and turn timing,0x0,0x0,0x0,0
3,0x3c8,0x8905,0x57c,0x1,864,585,PARTIAL,Kobble/Skidda,Pier Kobble only; non-Pier family variant selection pending,0x203,0x0,0x0,0
4,0x294,0x64c5,0x10c,0x1,1272,616,PARTIAL,KONG letter,Letter selected by original descriptor mask,0x144,0x0,0x78,0
5,0x2fc,0x7a5a,0x398,0x1,1504,630,UNKNOWN,Unimplemented object,Preserved for audit; no gameplay handler,0x139,0x0,0x0,0
6,0x2c4,0x718a,0x260,0x9,1536,560,PARTIAL,Floating DK Barrel,Native carry/throw/break/rescue; floating original states pending,0x15c,0x0,0x0,0
7,0x300,0x75a4,0x308,0x1,1728,688,UNKNOWN,Unimplemented object,Preserved for audit; no gameplay handler,0x141,0x0,0x0,0
8,0x2b4,0x6755,0x140,0x1,1832,540,PARTIAL,Barrel cannon,Lakeside type-specific destinations,0x20,0x0,0x0,0
9,0x3e0,0x8ab2,0x5a6,0x1,2223,617,UNKNOWN,Unimplemented object,Preserved for audit; no gameplay handler,0x21c,0x5,0x0,0
10,0x3e0,0x8ab2,0x5a6,0x1,2496,617,UNKNOWN,Unimplemented object,Preserved for audit; no gameplay handler,0x21c,0x5,0x0,0
11,0x294,0x64d5,0x10e,0x1,2640,528,PARTIAL,KONG letter,Letter selected by original descriptor mask,0x145,0x0,0x78,0
12,0x2b4,0x6870,0x166,0x1,2400,720,PARTIAL,Barrel cannon,Lakeside type-specific destinations,0x20,0x0,0x4,0
13,0x300,0x75ab,0x30a,0x1,2864,736,UNKNOWN,Unimplemented object,Preserved for audit; no gameplay handler,0x141,0x0,0x0,0
14,0x298,0x63f4,0xf4,0x1,3072,600,PARTIAL,Banana,Host overlap pickup,0x14d,0x0,0x0,0
15,0x300,0x75a4,0x308,0x1,3072,688,UNKNOWN,Unimplemented object,Preserved for audit; no gameplay handler,0x141,0x0,0x0,0
16,0x300,0x75ab,0x30a,0x1,3248,704,UNKNOWN,Unimplemented object,Preserved for audit; no gameplay handler,0x141,0x0,0x0,0
17,0x300,0x75a4,0x308,0x1,3248,736,UNKNOWN,Unimplemented object,Preserved for audit; no gameplay handler,0x141,0x0,0x0,0
18,0x300,0x75a4,0x308,0x1,3440,680,UNKNOWN,Unimplemented object,Preserved for audit; no gameplay handler,0x141,0x0,0x0,0
19,0x300,0x75ab,0x30a,0x1,3440,724,UNKNOWN,Unimplemented object,Preserved for audit; no gameplay handler,0x141,0x0,0x0,0
20,0x2b4,0x669d,0x12a,0x1,3568,724,PARTIAL,Barrel cannon,Lakeside type-specific destinations,0x20,0x0,0x0,0
21,0x2b4,0x66f3,0x134,0x1,3656,724,PARTIAL,Barrel cannon,Lakeside type-specific destinations,0x20,0x0,0x0,0
22,0x258,0x72be,0x286,0x1,3696,752,PARTIAL,No animal sign,ROM contact and reward; Ellie removal; Enguarde runtime pending,0x0,0x0,0x0,0
23,0x300,0x75ab,0x30a,0x1,3952,704,UNKNOWN,Unimplemented object,Preserved for audit; no gameplay handler,0x141,0x0,0x0,0
24,0x300,0x75a4,0x308,0x1,3952,736,UNKNOWN,Unimplemented object,Preserved for audit; no gameplay handler,0x141,0x0,0x0,0
25,0x2bc,0x8094,0x472,0xb,4224,608,PARTIAL,Checkpoint,Host full-height trigger,0x143,0x0,0x0,0
26,0x298,0x63d8,0xf2,0xc,4224,608,PARTIAL,Banana,Host overlap pickup,0x14d,0x0,0x0,0
27,0x2c4,0x719e,0x264,0x9,4352,736,PARTIAL,Floating DK Barrel,Native carry/throw/break/rescue; floating original states pending,0x15c,0x0,0x0,0
28,0x2fc,0x7a5a,0x398,0x1,4448,660,UNKNOWN,Unimplemented object,Preserved for audit; no gameplay handler,0x139,0x0,0x0,0
29,0x284,0x6234,0xc6,0x1,4448,624,PARTIAL,Bear coin,Host overlap pickup,0x148,0x0,0x0,0
30,0x2fc,0x7ab6,0x3a8,0x1,4645,592,UNKNOWN,Unimplemented object,Preserved for audit; no gameplay handler,0x139,0x0,0x0,0
31,0x2fc,0x7b23,0x3bc,0x1,4904,650,UNKNOWN,Unimplemented object,Preserved for audit; no gameplay handler,0x13b,0x0,0x0,0
32,0x284,0x624a,0xc8,0x1,4904,624,PARTIAL,Bear coin,Host overlap pickup,0x148,0x0,0x0,0
33,0x300,0x7440,0x2c8,0x1,5232,700,UNKNOWN,Unimplemented object,Preserved for audit; no gameplay handler,0x13e,0x0,0x0,0
34,0x2fc,0x7a5a,0x398,0x1,5456,656,UNKNOWN,Unimplemented object,Preserved for audit; no gameplay handler,0x139,0x0,0x0,0
35,0x300,0x75a4,0x308,0x1,5456,688,UNKNOWN,Unimplemented object,Preserved for audit; no gameplay handler,0x141,0x0,0x0,0
36,0x300,0x7478,0x2d2,0x1,5584,736,UNKNOWN,Unimplemented object,Preserved for audit; no gameplay handler,0x13e,0x0,0x0,0
37,0x428,0x9229,0x656,0x1,5728,664,UNKNOWN,Unimplemented object,Preserved for audit; no gameplay handler,0x239,0xc,0x0,0
38,0x428,0x9229,0x656,0x1,5792,632,UNKNOWN,Unimplemented object,Preserved for audit; no gameplay handler,0x239,0xc,0x0,0
39,0x434,0x959f,0x6cc,0x1,5968,496,PARTIAL,Booty Bird,ROM graphics and reward selection; host patrol and collision; original death and reward flight pending,0x277,0x700,0x2,0
40,0x3e0,0x8ab2,0x5a6,0x1,5968,585,UNKNOWN,Unimplemented object,Preserved for audit; no gameplay handler,0x21c,0x5,0x0,0
41,0x300,0x75a4,0x308,0x1,6160,704,UNKNOWN,Unimplemented object,Preserved for audit; no gameplay handler,0x141,0x0,0x0,0
42,0x300,0x75ab,0x30a,0x1,6160,736,UNKNOWN,Unimplemented object,Preserved for audit; no gameplay handler,0x141,0x0,0x0,0
43,0x2b4,0x66a4,0x12c,0x1,6386,472,PARTIAL,Barrel cannon,Lakeside type-specific destinations,0x20,0x0,0x0,0
44,0x2b4,0x66fd,0x136,0x1,6386,544,PARTIAL,Barrel cannon,Lakeside type-specific destinations,0x20,0x0,0x0,0
45,0x300,0x75ab,0x30a,0x1,6752,704,UNKNOWN,Unimplemented object,Preserved for audit; no gameplay handler,0x141,0x0,0x0,0
46,0x300,0x75a4,0x308,0x1,6752,736,UNKNOWN,Unimplemented object,Preserved for audit; no gameplay handler,0x141,0x0,0x0,0
47,0x2fc,0x7ab6,0x3a8,0x1,6885,597,UNKNOWN,Unimplemented object,Preserved for audit; no gameplay handler,0x139,0x0,0x0,0
48,0x2c4,0x719e,0x264,0x9,6976,736,PARTIAL,Floating DK Barrel,Native carry/throw/break/rescue; floating original states pending,0x15c,0x0,0x0,0
49,0x300,0x7478,0x2d2,0x1,7120,736,UNKNOWN,Unimplemented object,Preserved for audit; no gameplay handler,0x13e,0x0,0x0,0
50,0x2fc,0x7a5a,0x398,0x1,7152,656,UNKNOWN,Unimplemented object,Preserved for audit; no gameplay handler,0x139,0x0,0x0,0
51,0x300,0x75a4,0x308,0x1,7152,688,UNKNOWN,Unimplemented object,Preserved for audit; no gameplay handler,0x141,0x0,0x0,0
52,0x2fc,0x7a5a,0x398,0x1,7424,624,UNKNOWN,Unimplemented object,Preserved for audit; no gameplay handler,0x139,0x0,0x0,0
53,0x300,0x75a4,0x308,0x1,7424,688,UNKNOWN,Unimplemented object,Preserved for audit; no gameplay handler,0x141,0x0,0x0,0
54,0x294,0x64f5,0x112,0x1,7472,624,PARTIAL,KONG letter,Letter selected by original descriptor mask,0x147,0x0,0x78,0
55,0x300,0x7440,0x2c8,0x1,7728,688,UNKNOWN,Unimplemented object,Preserved for audit; no gameplay handler,0x13e,0x0,0x0,0
56,0x3e0,0x8abc,0x5a8,0x1,7936,617,UNKNOWN,Unimplemented object,Preserved for audit; no gameplay handler,0x21c,0x5,0x0,0
57,0x2b4,0xb1c2,0xa04,0x1,8112,628,PARTIAL,Barrel cannon,Lakeside type-specific destinations,0x0,0x0,0x4,0
58,0x29c,0x6457,0xfe,0x1,8112,624,PARTIAL,Life balloon,Red variant only; host overlap pickup,0x17e,0x0,0x8000,0
59,0x2b4,0x6782,0x142,0x1,8064,512,PARTIAL,Barrel cannon,Lakeside type-specific destinations,0x20,0x0,0x0,0
60,0x124,0x61f6,0xc2,0x3,8160,585,PARTIAL,End flag,Host full-height trigger,0x0,0x0,0x2206,0
```

## TIDAL-BONUS1-SPAWN-AUDIT.txt

```text
placements=3 SUPPORTED=0 PARTIAL=1 UNKNOWN=2
index,sprite_id,descriptor,type,parameter,x,y,status,behavior,limitation,animation_id,initial_state,reward,conditional
0,0x3b4,0x76f7,0x344,0x1,496,736,UNKNOWN,Unimplemented object,Preserved for audit; no gameplay handler,0x1c4,0x2,0x0,0
1,0x28c,0x6148,0xa6,0x7,704,736,PARTIAL,Bonus coin,Target-gated pickup and one-time reward; original object state machine pending,0x14a,0x0,0x2,0
2,0x2a8,0x61ad,0xae,0x1,320,720,UNKNOWN,Unimplemented object,Preserved for audit; no gameplay handler,0x0,0x0,0x0,0
```

## TIDAL-BONUS2-SPAWN-AUDIT.txt

```text
placements=7 SUPPORTED=0 PARTIAL=2 UNKNOWN=5
index,sprite_id,descriptor,type,parameter,x,y,status,behavior,limitation,animation_id,initial_state,reward,conditional
0,0x2b4,0x6a6c,0x19e,0x1,336,720,PARTIAL,Barrel cannon,Lakeside type-specific destinations,0x40,0x0,0x4,0
1,0x428,0x9229,0x656,0x1,416,570,UNKNOWN,Unimplemented object,Preserved for audit; no gameplay handler,0x239,0xc,0x0,0
2,0x428,0x9229,0x656,0x1,496,544,UNKNOWN,Unimplemented object,Preserved for audit; no gameplay handler,0x239,0xc,0x0,0
3,0x428,0x9229,0x656,0x1,608,570,UNKNOWN,Unimplemented object,Preserved for audit; no gameplay handler,0x239,0xc,0x0,0
4,0x428,0x9229,0x656,0x1,704,560,UNKNOWN,Unimplemented object,Preserved for audit; no gameplay handler,0x239,0xc,0x0,0
5,0x28c,0x6148,0xa6,0x7,856,712,PARTIAL,Bonus coin,Target-gated pickup and one-time reward; original object state machine pending,0x14a,0x0,0x2,0
6,0x2a8,0x619f,0xaa,0x1,336,512,UNKNOWN,Unimplemented object,Preserved for audit; no gameplay handler,0x0,0x0,0x0,0
```

