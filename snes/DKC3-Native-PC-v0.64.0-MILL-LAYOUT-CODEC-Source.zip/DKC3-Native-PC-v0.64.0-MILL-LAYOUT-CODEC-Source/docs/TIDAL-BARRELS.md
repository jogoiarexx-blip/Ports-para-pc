# Tidal ROM e ciclo dos barris — v0.49.0

## Dados de Tidal

`RomLevelRuntime` cataloga $27/$19F0/2. Os limites de submapa em B7:B431
selecionam as colunas 195..443 do bloco PierLevels (E5:2618). Resultado:
249 colunas, 7968×512 pixels. Stream FE:0926..FE:0B10: 61 placements.
Definições E5:4A01..E5:4C41: 180 superfícies. A busca BB:B7BC seleciona o
índice 8 de BB:B831 e retorna água Y=$0298 (408 no espaço nativo).
Spawn do header FD:071B: X=$013C/Y=$0269, pés nativos (60,361).
Checkpoint de retorno do mesmo header: pés (3840,352). As posições não são
mais as coordenadas visuais calibradas para a captura de abertura.

As três `.nscene` antigas permanecem no source somente para testes de
compatibilidade do streaming; Tidal ativa não as carrega, e o build Windows
remove a pasta dessas páginas do pacote portátil. Não foram criadas páginas
adicionais. Sprites OAM antigos ainda necessários como dependências de teste
/declarações de animação permanecem disponíveis.

A forma $4D (B7:D183) é um teto plano condicional: só retorna altura 31 quando
((queryY-1)&31)<16. Seu teto/slope são calculados em `RomPierTerrain::query`.
Ela não vira piso one-way nem parede sólida por inferência visual. O oracle
comparou 98.309 amostras e 20.132 consultas reais de Tidal com a ROM.

## Barris — v0.55

$02C4 cria Floating DK Barrel: dois em Lakeside, tres em Tidal.
$02C0 cria tres barris comuns de Lakeside. Apenas DK restaura o parceiro.
$0170 e BarrelRespawner: gera steel keg $02D4 por tipo filho $0468.
A identificacao anterior de $0170 como DK Barrel foi corrigida.

CarryBarrelBody separa Resting, Carried, Thrown, Dropped e Broken. Segure X
para carregar, solte para arremessar, baixo+X para colocar. Movimento pode
continuar com carga; dano/agua solta. O aco rebate paredes e continua apos
atingir inimigos. Nunca restaura parceiro. Graficos do aco usam a ROM.

Fisica/colisao/carga continuam parciais; estados originais completos, riding,
agua e gerenciamento dos quatro slots do respawner ainda pendentes.
Veja COMO-USAR-DK-COIN.txt para Koin, persistencia e replay da moeda.

## Replays e limites

native_stages_tests percorre spawn/checkpoint/saida em 3284 frames Lakeside e
6243 Tidal. Reexecucao compara coordenadas, vidas, danos e destino; so input.
Isso nao conclui Tidal: bonus, Warp e 34 placements UNKNOWN ainda faltam.
Triggers de checkpoint/saida continuam amplos. Skidda ainda nao esta jogavel.

Lakeside: 47 PARTIAL/0 UNKNOWN. Tidal: 27 PARTIAL/34 UNKNOWN. Zero SUPPORTED.
29 suites GCC/Linux; Windows EXE nao compilado/executado neste ambiente.

Os dados/rotinas foram conferidos na ROM fornecida e no disassembly original.
Nenhuma CPU emulada foi reintroduzida no runtime nativo.
