# Doorstop Dash — prioridade de migração após v0.64.0

Fonte principal: `DOORSTOP-SPAWN-AUDIT.txt`, gerado diretamente da ROM. Os quatro IDs que concentravam 91,9% dos UNKNOWN foram agora ligados aos handlers originais pelo workbench e receberam contratos C++ conservadores em `RomDoorstop.cpp`.

- Placements originais: **118**.
- Sprite IDs resolvidos: **118/118**.
- Handlers PARTIAL: **113**.
- Handlers ainda UNKNOWN: **5**.
- Redução desta rodada: **57 placements UNKNOWN -> PARTIAL**.

## Famílias fechadas nesta rodada

| Sprite ID | Placements | Handler original | Estado no port |
|---|---:|---|---|
| `0x02FC` | 14 | `buzz_main` `B6:8170` | PARTIAL: spawn/variantes e dispatch identificados; colisão/derrota/movimento completo pendentes |
| `0x038C` | 15 | `door_lever_handle_main` `B6:923F` | PARTIAL: quatro estados, parâmetros de ativação/fase e aritmética de posição preservados |
| `0x0390` | 14 | `metal_door_lever_controlled_main` `B6:9338` | PARTIAL: deslocamento controlado, passo de fechamento e fase preservados |
| `0x0394` | 14 | `door_gear_main` `B6:93FF` | PARTIAL: dois estados e palavra de movimento escalada pelo controle preservados |

O relatório ROM focado está em `ROM-DOORSTOP-OBJECTS-PACKET.md`.

## UNKNOWN restante

| Sprite ID | Placements | Tipos de placement |
|---|---:|---|
| `0x0144` | 3 | `0x009C`, `0x009E`, `0x00A0` |
| `0x027C` | 2 | `0x00D8`, `0x00DA` |

Esses cinco registros não são mais o bloqueio dominante da fase. Eles continuam UNKNOWN até o handler e os contratos serem confirmados pela ROM.

## Próximo alvo estrutural

O decoder estrutural **MILL `$198D/$1998`** já resolve família/config, streams, bounds e shape 7 pela ROM. Doorstop ainda usa `native/doorstop.nscene` porque o gargalo restante é ligar a consulta de terreno `B7:CB2B`, colisão row-major e palette/background/câmera ao `RomLevelRuntime`. Isso continua acima dos cinco objetos residuais em prioridade.
