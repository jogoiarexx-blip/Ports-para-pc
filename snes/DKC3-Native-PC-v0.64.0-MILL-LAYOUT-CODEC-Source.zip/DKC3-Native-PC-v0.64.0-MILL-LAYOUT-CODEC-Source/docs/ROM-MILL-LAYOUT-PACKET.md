# MILL layout/source packet — v0.64.0

Objetivo: retirar os offsets PIER hardcoded do caminho de extração e provar o primeiro estágio do codec MILL sem declarar renderer/colisão completos.

## Cadeia original usada pelo decoder

1. O registro `shared_data` no banco `FD` fornece o índice da família em `+8`.
2. `B7:F28D` usa esse índice na tabela `B7:B01B`.
3. A entrada da tabela fornece o ponteiro da configuração da família e o handler de consulta de terreno.
4. A configuração fornece o header de assets, base VRAM e registros de submapa.
5. O header de assets possui três ponteiros 24-bit: map32, definições de terreno e foreground; o level-map comprimido começa imediatamente após os 9 bytes do header.

## PIER usado como oráculo de regressão

- shared_data `$19F0` -> família `9`.
- config `B7:B431`.
- terrain handler `B7:CD1F`.
- header `E5:260F`; level stream `E5:2618`.
- map32 `E5:3A78`; terrain defs `E5:4A01`; foreground `E5:4C41`.
- shape `0`: column-major, 16 metatiles por coluna.

O runtime PIER agora recebe level map/map32/terrain defs/foreground pelo decoder genérico. Background, water art e palette ainda permanecem no bloco PIER específico.

## MILL `$198D/$1998`

- shared_data `$198D` e `$1998` -> família `5`.
- config `B7:B302`.
- terrain handler `B7:CB2B`.
- base VRAM `$7800`.
- header `E3:E3B0`.
- level stream `E3:E3B9`, comprimido `0x2D8F`, saída `0x9740`.
- map32 `E4:1148`, comprimido `0x202D`, saída `0x4400`.
- terrain defs `E4:3175..E4:3549`, `0x03D4` bytes.
- foreground `E4:3549`, comprimido `0x53B9`, saída `0x7120`.

Submapas comprovados na config:

| fase | shared_data | submap | X | Y | shape |
|---|---|---:|---|---|---:|
| Doorstop Dash | `$198D` | 0 | `$0000..$0A00` | `$0000..$07E0` | 7 |
| Squeals on Wheels | `$198D` | 1 | `$0000..$0A00` | `$07E0..$12C0` | 7 |
| Murky Mill | `$1998` | 2 | `$0000..$0A00` | `$12C0..$1B20` | 7 |

Shape 7 é row-major com stride de 160 bytes (80 metatiles). `romScenarioMapMetatile` aplica `xBegin/yBegin` e o stride da própria shape; também centraliza os layouts 0/1/4/5/6/7/8/9 conhecidos.

## Estado conservador

`$198D/$1998` passaram de UNKNOWN para PARTIAL apenas porque o layout e os quatro blocos de fonte já são decodificados. `RomLevelRuntime::load` ainda não aceita MILL para gameplay. Faltam:

- tradução/integracão da consulta de terreno `B7:CB2B`;
- construção de colisão shape 7;
- resolução ROM-first de palette/background e composição visual;
- câmera/limites e comparação de traces/replay de Doorstop.

Nenhum desses itens é inferido como pronto nesta versão.
