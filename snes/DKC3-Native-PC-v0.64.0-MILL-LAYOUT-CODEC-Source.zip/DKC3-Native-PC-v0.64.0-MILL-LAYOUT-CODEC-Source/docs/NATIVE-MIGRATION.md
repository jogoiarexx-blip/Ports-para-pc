# v0.64.0 — codec estrutural MILL e pipeline UTF-8 no Windows

Esta entrega parte da v0.62.0. Não certifica duas fases completas nem fidelidade total ao SNES.

## O que a auditoria encontrou

O ZIP já possuía renderer host, entidades C++, traduções aritméticas de rotinas,
assets próprios e SFX sintetizados. Ele **não contém** CPU 65816/PPU/DMA/HDMA/SPC
em execução. `tools/run_recomp_reference.py` chama um executável externo que não
foi fornecido. Por isso não existe fallback PPU local para reduzir, nem um PC
65816 executado que o trace nativo possa registrar legitimamente.

As duas primeiras fases são Lakeside Limbo e Doorstop Dash. Doorstop neste pacote
é uma seção de demonstração com colisões/objetos host, não a fase original
completa. Tidal Trouble foi mantida como regressão adicional.

## Alterações implementadas

- **Extração fora do runtime:** `dkc3_extract_native` reaproveita os decoders e gera
  `assets/native/runtime.nassets`. O formato contém pixels, máscaras, terreno,
  placements resolvidos, perfis de movimento, recompensas, dados Koin/Ellie e
  parâmetros de objetos. Não contém ROM disfarçada nem CPU serializada.
- **Modo sem ROM:** `DKC3_ASSET_MODE=native` exige o pacote validado. Carregamento
  de Lakeside/bonuses/Tidal, telas e mapas usa os dados extraídos. Doorstop usa os
  assets existentes. `auto` prefere assets e só usa ROM se o pacote não existir;
  pacote corrompido falha. `rom` mantém a extração original para comparação.
- **Compositor host:** BG1/BG2/BG3 em Mode 1, sprites com prioridades/flips,
  máscaras de pixels, color math, scroll/parallax, offsets por linha, gradientes
  e atualização de tiles/mapas/paletas. Veja `NATIVE-RENDERER.md`. Os atores de Game
  conservam seu desenho existente; a nova composição de sprites não substitui
  automaticamente todos esses atores.
- **Conversão inicial de vídeo:** `tools/convert_video_trace.py` converte capturas
  completas de DMA CGRAM e VRAM com destinos conhecidos para operações host.
  Rejeita transferências parciais/ambíguas. Offsets/gradientes resolvidos possuem
  adaptadores semânticos; **HDMA bruto ainda não é decodificado**. Não existe
  captura original das fases neste ZIP para alegar cobertura DMA/HDMA real.
- **ROM Trace → Native Map:** `tools/native_map.py` reutiliza o índice e decoder do
  workbench, valida SHA256 e gera JSON/Markdown, grafos, tabelas e pistas de
  código nativo. O relatório produzido está em `native-map.json`/`.md`.
- **Auditoria de placements desacoplada do cenário:** `decodeRomLevelPlacements`
  lê diretamente a tabela FE de placement streams e executa os Spawn Scripts FF
  usando o decoder semântico existente. `dkc3_native_rom_audit` não depende mais
  de `RomLevelRuntime` nem de um codec gráfico/terreno já implementado. Doorstop
  (`0x28`, shared_data MILL `$198D`) agora é auditável antes do renderer MILL: os
  118 placements têm Sprite ID resolvido. Buzz (`0x02FC`) e o mecanismo de porta
  (`0x038C/0x0390/0x0394`) foram ligados aos handlers originais e preservam os
  principais parâmetros/aritmética revisados: o audit agora mostra 113 PARTIAL e
  5 UNKNOWN. O auditor também aceita level id numérico `0..511`.
- **Trace dinâmico nativo:** o replay registra estado por frame, inputs,
  player/câmera/animação/objetos/placements/timers/colisões/transições, chamadas
  realmente executadas e eventos derivados de mudanças. Hash canônico preserva
  bits exatos de floats. PC/opcode/bank nativos ficam `null`; `source_pc` é apenas
  proveniência de uma tradução. RNG original não observado fica `null`.
- **Primeira divergência:** `tools/compare_native_traces.py` valida as duas
  sequências e informa primeiro frame, todas as variáveis diferentes, objetos,
  chamadas recentes e leituras associadas quando fornecidas. Uma reconvergência
  posterior não esconde o primeiro desvio. Inputs incompatíveis são erro.
- **Métricas:** tentativas de abertura da ROM, bytes realmente lidos/copiados e
  pedidos de views. Não transformamos pedidos de view em contagem fictícia de
  instruções de leitura. Cobertura CPU original e fallback PPU ficam não
  disponíveis/não aplicáveis.
- **Windows:** build inclui novas ferramentas/testes e produz pacote portátil
  sem pasta ROM. CRT estático configurado para MSVC. Build Windows não foi
  executado neste ambiente Linux.

## Reproduzir

Com CMake 3.20+, compilador C++20 e Python para ferramentas:

```text
cmake -S . -B build
cmake --build build --parallel
ctest --test-dir build --output-on-failure
build/dkc3_extract_native rom/dkc3_ptbr.sfc assets/native/runtime.nassets
build/dkc3_native_rom_audit rom/dkc3_ptbr.sfc doorstop > docs/DOORSTOP-SPAWN-AUDIT.txt
python tools/native_map.py --output-json docs/native-map.json --output-markdown docs/native-map.md
```

No Windows, `BUILD-WINDOWS.cmd` usa Visual Studio 2022. A ROM é entrada das
ferramentas/testes de desenvolvimento; não é copiada para `bin`. `RUN-WINDOWS.cmd`
ativa o modo nativo estrito. O ZIP de fontes preserva a entrada ROM já fornecida
para permitir reproduzir os testes.

Replay em Linux (em Windows, usar `set DKC3_ASSET_MODE=native` e o `.exe`):

```sh
DKC3_ASSET_MODE=native build/dkc3_native_replay game \
  tests/replays/lakeside-extended-v059.txt replay.csv lakeside-limbo \
  --trace-jsonl native.jsonl --metrics native-metrics.json
DKC3_ASSET_MODE=rom build/dkc3_native_replay game \
  tests/replays/lakeside-extended-v059.txt reference.csv lakeside-limbo \
  --trace-jsonl reference.jsonl --metrics reference-metrics.json
python tools/compare_native_traces.py reference.jsonl native.jsonl \
  --json comparison.json --markdown comparison.md
```

`--frames N` limita a captura e `--no-render` dispensa pixels. Compare capturas
com a mesma opção. Traces completos podem ocupar centenas de MB; nesta entrega
incluímos os relatórios e uma amostra curta, não cópias enormes redundantes.

**Essa comparação testa decodificação original versus dados extraídos do mesmo
port. Não é execução do jogo SNES original.** O comparador aceita traces externos
normalizados, mas não inventa equivalência de campos/PC ou autentica produtores.

## O que permanece parcial

| Área | Estado real |
| --- | --- |
| CPU traduzida | Aritmética existente preservada; não há dispatcher completo no ZIP. |
| Lakeside | 47 placements continuam PARTIAL; sem promoção artificial a SUPPORTED. |
| Doorstop | Seção host existente; 118/118 placements estão no pacote ROM-free. 113 usam contratos PARTIAL e 5 continuam UNKNOWN; layout/assets MILL agora PARTIAL; renderer/colisão shape 7 e B7:CB2B ainda pendentes. |
| Player/física/colisão | Traduções existentes preservadas; controlador original completo e casos desconhecidos não foram reconstruídos. |
| Tidal | Salas/terreno decodificados preservados; bônus e inimigos originais ainda parciais. |
| PPU | Não existe PPU legado local; Mode 7, mosaic, OAM limits/rotation e timing não implementados no compositor. |
| DMA/HDMA | Conversor offline limitado; padrões reais das fases/HDMA bruto ainda precisam de capturas e validação. |
| Áudio | SFX host sintéticos existentes; músicas/samples/SFX originais e SPC/DSP não foram portados. |
| Trace original | Sem executável de referência fornecido; RAM/VRAM/OAM originais e instruções não são observados pelo runtime host. |
| Assets | Conteúdo já decodificado roda sem ROM; isso não transforma conteúdo ausente em conteúdo portado. |

Resultados concretos e comandos utilizados: `VALIDACAO-v0.64.0.md` e arquivos em
`validation/`. O índice estático e suas classificações nunca representam
porcentagem de gameplay implementado.
