# Validação — DKC3 Native PC v0.63.0

## Objetivo

Fechar as quatro famílias que representavam 57/62 dos placements UNKNOWN de Doorstop sem promover comportamento não comprovado a SUPPORTED, e remover a dependência do codec MILL para transportar os placements de Doorstop no pacote nativo ROM-free.

## Resultado de Doorstop

- `118` placements lidos diretamente da ROM.
- `118/118` Sprite IDs resolvidos.
- Antes: `56 PARTIAL / 62 UNKNOWN`.
- Agora: **`113 PARTIAL / 5 UNKNOWN`**.
- Famílias migradas: `0x02FC` Buzz (14), `0x038C` alavanca (15), `0x0390` porta metálica (14), `0x0394` engrenagem (14).
- Handlers ROM confirmados: `B6:8170`, `B6:923F`, `B6:9338`, `B6:93FF`.

## Mudanças estruturais

1. `RomDoorstop.cpp/.h` preserva os parâmetros de spawn e a aritmética de 8 bits/high-byte usada pelo mecanismo de porta.
2. `NativeRuntimeAssets` ganhou `placementStreams`, separado de `RomLevelRuntime`. Isso permite empacotar uma fase cujos placements já são conhecidos mesmo sem renderer/terrain codec.
3. `runtime.nassets` passou para **format version 2** e inclui Doorstop `0x28` com os 118 placements resolvidos.
4. `Game::init` publica esses placements no `RomSpawnRuntime` de Doorstop em modo nativo, mantendo a seção host existente para cenário/colisão até o codec MILL.
5. O audit ganhou a coluna `rom_handler`; `native_map.py` foi tornado compatível com schemas de audit extensíveis sem depender de um número fixo de colunas após `limitation`.

## Evidência ROM

`docs/ROM-DOORSTOP-OBJECTS-PACKET.md` foi gerado com `tools/rom_workbench.py` e registra os dispatch tables e estados usados na tradução. A ferramenta é leitura estática; não representa execução de CPU/PPU.

## Testes

Build C++20 Release concluído no ambiente Linux. Resultado final:

`37/37 CTest passed, 0 failed`.

O teste novo `native_doorstop_objects` verifica:

- contagens 14/15/14/14 das quatro famílias;
- endereços dos quatro handlers;
- perfis de spawn aceitos/rejeitados;
- aritmética de deslocamento da porta/alavanca/engrenagem;
- audit `113 PARTIAL / 5 UNKNOWN`;
- extração dos 118 placements para `runtime.nassets`;
- inicialização de Doorstop com `romSpawnRuntime().records().size()==118`.

`tests/tools/test_native_map.py`: **11/11 passed** após regenerar `native-map.json/.md`.

## Limites preservados

- Nenhuma das quatro famílias foi marcada SUPPORTED.
- Buzz ainda não tem colisão, derrota e movimento original completos no `Game`.
- O mecanismo de porta ainda não tem ownership dos slots/grupos, colisão e interação completa ligados ao cenário MILL.
- Doorstop ainda usa a seção host para visual/terreno/câmera.
- `0x0144` e `0x027C` continuam UNKNOWN.
- A próxima prioridade é o codec MILL `$198D`.
