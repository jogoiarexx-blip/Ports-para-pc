# Port packet: controller

ROM SHA256: `2277a2d8dddb01fe5cb0ae9a0fa225d42b3a11adccaeafa18e3c339b3794a32b`

This is an analysis packet, not generated game code or a complete translation.

# ROM B89F3A..B89F50

Static reading only; no CPU/PPU execution. Bytes and operands come from the current ROM.

Catalog entry: kiddy_kong_main — entry M/X hint `0,0`; not an exit proof.

```text
B89F3A  86 72       STX $72                  kong_state_handler
B89F3C  84 74       STY $74                  
B89F3E  A4 70       LDY $70                  
B89F40  B9 06 00    LDA $0006,Y              
B89F43  85 6A       STA $6A                  
B89F45  4B          PHK                      
B89F46  AB          PLB                      
B89F47  B9 38 00    LDA $0038,Y              
B89F4A  0A          ASL A                    
B89F4B  0A          ASL A                    
B89F4C  AA          TAX                      
B89F4D  7C 91 A1    JMP ($A191,X)            
```

## References

- BRA from `B89F32` to `B89F3A`
- Indirect contract (metadata): `ROM-verified table kong_state_table at B8A191; 120 targets, stride=4; index bounds not proven`

## Native source leads (not coverage proof)


## Unknowns and obligations

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B89F46 PLB: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.
- B89F4D: indirect control flow; target set requires a reviewed dispatch contract or RAM state.
- Short memory operands require DBR/direct-page context; a source name or address mention alone does not establish a physical memory address.
- Preserve word wrap, carry/sign flags and memory offsets; verify the C++ with bounded original-routine oracles and input replays.

# ROM B8C6DE..B8C786

Static reading only; no CPU/PPU execution. Bytes and operands come from the current ROM.

Catalog entry: CODE_B8C6DE — entry M/X hint `0,0`; not an exit proof.

```text
B8C6DE  A0 28 02    LDY #$0228               CODE_B8C6DE
B8C6E1  B7 6A       LDA [$6A],Y              
B8C6E3  A4 72       LDY $72                  
B8C6E5  99 08 00    STA $0008,Y              
B8C6E8  A0 30 02    LDY #$0230               
B8C6EB  B7 6A       LDA [$6A],Y              
B8C6ED  A4 72       LDY $72                  
B8C6EF  99 0A 00    STA $000A,Y              
B8C6F2  60          RTS                      
B8C6F3  A6 70       LDX $70                  CODE_B8C6F3
B8C6F5  B5 3A       LDA $3A,X                
B8C6F7  29 FB FF    AND #$FFFB               
B8C6FA  95 3A       STA $3A,X                
B8C6FC  A9 25 00    LDA #$0025               
B8C6FF  95 38       STA $38,X                
B8C701  A9 0B 00    LDA #$000B               
B8C704  22 15 A0 B9 JSL $B9A015              
B8C708  A6 72       LDX $72                  
B8C70A  74 08       STZ $08,X                
B8C70C  A6 70       LDX $70                  
B8C70E  74 30       STZ $30,X                
B8C710  74 2E       STZ $2E,X                
B8C712  AD 0F 05    LDA $050F                
B8C715  18          CLC                      
B8C716  69 14 00    ADC #$0014               
B8C719  D5 16       CMP $16,X                
B8C71B  90 12       BCC $B8C72F              
B8C71D  95 16       STA $16,X                
B8C71F  AD AD 04    LDA $04AD                
B8C722  29 FF 00    AND #$00FF               
B8C725  49 FF FF    EOR #$FFFF               
B8C728  38          SEC                      
B8C729  6D 0F 05    ADC $050F                
B8C72C  8D A2 04    STA $04A2                
B8C72F  A2 00 00    LDX #$0000               CODE_B8C72F
B8C732  AC 7D 18    LDY $187D                
B8C735  22 87 E5 B8 JSL $B8E587              
B8C739  60          RTS                      
B8C73A  A6 70       LDX $70                  check_sprite_underwater
B8C73C  AD 0F 05    LDA $050F                
B8C73F  30 11       BMI $B8C752              
B8C741  38          SEC                      
B8C742  F5 16       SBC $16,X                
B8C744  C9 EC FF    CMP #$FFEC               
B8C747  30 0D       BMI $B8C756              
B8C749  C9 F8 FF    CMP #$FFF8               
B8C74C  10 04       BPL $B8C752              
B8C74E  A9 01 00    LDA #$0001               
B8C751  60          RTS                      
B8C752  A9 00 00    LDA #$0000               
B8C755  60          RTS                      
B8C756  A9 02 00    LDA #$0002               
B8C759  60          RTS                      
B8C75A  AD 55 19    LDA $1955                CODE_B8C75A
B8C75D  F0 05       BEQ $B8C764              
B8C75F  CE 55 19    DEC $1955                
B8C762  80 28       BRA $B8C78C              
B8C764  20 11 C9    JSR $C911                CODE_B8C764
B8C767  B0 23       BCS $B8C78C              
B8C769  AD 77 07    LDA $0777                
B8C76C  29 03 00    AND #$0003               
B8C76F  F0 05       BEQ $B8C776              
B8C771  20 74 C8    JSR $C874                
B8C774  B0 16       BCS $B8C78C              
B8C776  A4 72       LDY $72                  CODE_B8C776
B8C778  B9 28 00    LDA $0028,Y              
B8C77B  F0 0F       BEQ $B8C78C              
B8C77D  20 93 C7    JSR $C793                
B8C780  B0 0A       BCS $B8C78C              
B8C782  A4 72       LDY $72                  
```

## References

- JSR from `B8C6C9` to `B8C6DE`
- JSL at `B8C704` to `B9A015` set_anim_handle_animal_and_kiddy
- BCC at `B8C71B` to `B8C72F` CODE_B8C72F
- JSL at `B8C735` to `B8E587` CODE_B8E587
- BMI at `B8C73F` to `B8C752` 
- BMI at `B8C747` to `B8C756` 
- BPL at `B8C74C` to `B8C752` 
- BEQ at `B8C75D` to `B8C764` CODE_B8C764
- BRA at `B8C762` to `B8C78C` CODE_B8C78C
- JSR at `B8C764` to `B8C911` CODE_B8C911
- BCS at `B8C767` to `B8C78C` CODE_B8C78C
- BEQ at `B8C76F` to `B8C776` CODE_B8C776
- JSR at `B8C771` to `B8C874` CODE_B8C874
- BCS at `B8C774` to `B8C78C` CODE_B8C78C
- BEQ at `B8C77B` to `B8C78C` CODE_B8C78C
- JSR at `B8C77D` to `B8C793` CODE_B8C793
- BCS at `B8C780` to `B8C78C` CODE_B8C78C

## Native source leads (not coverage proof)

- `src/core/RomMotion.h:15` — // B8:C73A: original feet coordinate and water word, including CMP sign behavior.

## Unknowns and obligations

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B8C704 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C735 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C764 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C771 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B8C77D JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- Truncated instruction at B8C784
- Short memory operands require DBR/direct-page context; a source name or address mention alone does not establish a physical memory address.
- Preserve word wrap, carry/sign flags and memory offsets; verify the C++ with bounded original-routine oracles and input replays.

# ROM B9EEA0..B9EF0E

Static reading only; no CPU/PPU execution. Bytes and operands come from the current ROM.

Catalog entry: CODE_B9EEA0 — entry M/X hint `0,0`; not an exit proof.

```text
B9EEA0  8B          PHB                      CODE_B9EEA0
B9EEA1  A6 70       LDX $70                  
B9EEA3  E2 20       SEP #$20                 
B9EEA5  B5 28       LDA $28,X                
B9EEA7  95 29       STA $29,X                
B9EEA9  4A          LSR A                    
B9EEAA  4A          LSR A                    
B9EEAB  4A          LSR A                    
B9EEAC  4A          LSR A                    
B9EEAD  95 28       STA $28,X                
B9EEAF  C2 20       REP #$20                 
B9EEB1  B5 12       LDA $12,X                
B9EEB3  95 54       STA $54,X                
B9EEB5  B5 16       LDA $16,X                
B9EEB7  95 56       STA $56,X                
B9EEB9  B5 29       LDA $29,X                
B9EEBB  29 04 00    AND #$0004               
B9EEBE  F0 1F       BEQ $B9EEDF              
B9EEC0  20 E0 F1    JSR $F1E0                
B9EEC3  20 3A F1    JSR $F13A                
B9EEC6  85 8A       STA $8A                  
B9EEC8  38          SEC                      
B9EEC9  F5 16       SBC $16,X                
B9EECB  10 61       BPL $B9EF2E              
B9EECD  C9 FD FF    CMP #$FFFD               
B9EED0  10 58       BPL $B9EF2A              
B9EED2  A5 A2       LDA $A2                  
B9EED4  29 00 40    AND #$4000               
B9EED7  D0 57       BNE $B9EF30              
B9EED9  20 81 F1    JSR $F181                
B9EEDC  82 C3 01    BRL $B9F0A2              
B9EEDF  20 E0 F1    JSR $F1E0                CODE_B9EEDF
B9EEE2  64 A4       STZ $A4                  
B9EEE4  20 3A F1    JSR $F13A                
B9EEE7  85 8A       STA $8A                  
B9EEE9  38          SEC                      
B9EEEA  F5 16       SBC $16,X                
B9EEEC  10 40       BPL $B9EF2E              
B9EEEE  A8          TAY                      
B9EEEF  A5 A4       LDA $A4                  
B9EEF1  F0 40       BEQ $B9EF33              
B9EEF3  38          SEC                      
B9EEF4  F5 56       SBC $56,X                
B9EEF6  90 05       BCC $B9EEFD              
B9EEF8  C9 10 00    CMP #$0010               
B9EEFB  B0 36       BCS $B9EF33              
B9EEFD  A5 A4       LDA $A4                  CODE_B9EEFD
B9EEFF  85 8A       STA $8A                  
B9EF01  49 FF FF    EOR #$FFFF               
B9EF04  38          SEC                      
B9EF05  75 16       ADC $16,X                
B9EF07  C5 AA       CMP $AA                  
B9EF09  10 16       BPL $B9EF21              
B9EF0B  20 81 F1    JSR $F181                CODE_B9EF0B
```

## References

- JMP from `B9E006` to `B9EEA0`
- JSL from `B9EC0E` to `B9EEA0`
- JSL from `B9EC2F` to `B9EEA0`
- JSL from `B9ED20` to `B9EEA0`
- JSL from `B9ED39` to `B9EEA0`
- JSL from `B9ED44` to `B9EEA0`
- JSL from `B9ED85` to `B9EEA0`
- JSL from `B9EDB5` to `B9EEA0`
- JSL from `B9EDC4` to `B9EEA0`
- JSL from `B9EDC9` to `B9EEA0`
- JSL from `B9EDD8` to `B9EEA0`
- JSL from `B9EDEA` to `B9EEA0`
- JSL from `B9EE97` to `B9EEA0`
- BEQ at `B9EEBE` to `B9EEDF` CODE_B9EEDF
- JSR at `B9EEC0` to `B9F1E0` CODE_B9F1E0
- JSR at `B9EEC3` to `B9F13A` CODE_B9F13A
- BPL at `B9EECB` to `B9EF2E` CODE_B9EF2E
- BPL at `B9EED0` to `B9EF2A` CODE_B9EF2A
- BNE at `B9EED7` to `B9EF30` CODE_B9EF30
- JSR at `B9EED9` to `B9F181` CODE_B9F181
- BRL at `B9EEDC` to `B9F0A2` CODE_B9F0A2
- JSR at `B9EEDF` to `B9F1E0` CODE_B9F1E0
- JSR at `B9EEE4` to `B9F13A` CODE_B9F13A
- BPL at `B9EEEC` to `B9EF2E` CODE_B9EF2E
- BEQ at `B9EEF1` to `B9EF33` CODE_B9EF33
- BCC at `B9EEF6` to `B9EEFD` CODE_B9EEFD
- BCS at `B9EEFB` to `B9EF33` CODE_B9EF33
- BPL at `B9EF09` to `B9EF21` CODE_B9EF21
- JSR at `B9EF0B` to `B9F181` CODE_B9F181

## Native source leads (not coverage proof)

- `src/core/Player.cpp:149` — // Host crossing guard; full B9:EEA0 response is not translated yet.

## Unknowns and obligations

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B9EEC0 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B9EEC3 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B9EED9 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B9EEDF JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B9EEE4 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B9EF0B JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- Short memory operands require DBR/direct-page context; a source name or address mention alone does not establish a physical memory address.
- Preserve word wrap, carry/sign flags and memory offsets; verify the C++ with bounded original-routine oracles and input replays.

# ROM B9F060..B9F084

Static reading only; no CPU/PPU execution. Bytes and operands come from the current ROM.

Catalog entry: CODE_B9EEA0 — entry M/X hint `0,0`; not an exit proof.

```text
B9F060  95 1A       STA $1A,X                CODE_B9F060
B9F062  A5 A0       LDA $A0                  
B9F064  29 00 18    AND #$1800               
B9F067  D0 F2       BNE $B9F05B              
B9F069  B5 28       LDA $28,X                
B9F06B  29 00 11    AND #$1100               
B9F06E  F0 13       BEQ $B9F083              
B9F070  A5 A0       LDA $A0                  
B9F072  29 07 00    AND #$0007               
B9F075  F0 03       BEQ $B9F07A              
B9F077  A9 03 00    LDA #$0003               
B9F07A  1A          INC A                    CODE_B9F07A
B9F07B  D5 1A       CMP $1A,X                
B9F07D  B0 9A       BCS $B9F019              
B9F07F  80 02       BRA $B9F083              
B9F081  95 1A       STA $1A,X                CODE_B9F081
```

## References

- BPL from `B9F017` to `B9F060`
- BNE at `B9F067` to `B9F05B` CODE_B9F05B
- BEQ at `B9F06E` to `B9F083` CODE_B9F083
- BEQ at `B9F075` to `B9F07A` CODE_B9F07A
- BCS at `B9F07D` to `B9F019` CODE_B9F019
- BRA at `B9F07F` to `B9F083` CODE_B9F083

## Native source leads (not coverage proof)

- `src/core/RomTerrain.h:60` — // B9:F060..F083 selection, assuming the caller has a positive floor gap.

## Unknowns and obligations

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- Truncated instruction at B9F083
- Short memory operands require DBR/direct-page context; a source name or address mention alone does not establish a physical memory address.
- Preserve word wrap, carry/sign flags and memory offsets; verify the C++ with bounded original-routine oracles and input replays.

