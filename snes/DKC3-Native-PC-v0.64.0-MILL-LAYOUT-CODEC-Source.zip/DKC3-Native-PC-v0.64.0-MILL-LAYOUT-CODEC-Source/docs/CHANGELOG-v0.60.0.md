# v0.60.0 — Leitura da ROM para acelerar o port

- Workbench estatico integrado ao fluxo do Codex, com indice ROM-bound,
  limites de instrucoes, referencias, dispatch e ligacao com pistas no C++.
- 100597 limites; 21642 referencias; 278 dispatch tables; 120 estados Kong
  com destinos/flags conferidos. 217 anotacoes nao aceitas isoladas.
- Packets controlador/steel/Koin/Tidal e lista dos estados; nenhuma CPU/PPU
  executada, nenhum codigo de jogo automaticamente traduzido.
- Aplicacao nativa: perfil de mira Koin le limites e graficos das tabelas
  apontadas pelas instrucoes originais. Valida payload e falha em dados invalidos.
- 29 suites C++ e 8 testes Python; regressao dos percursos por input.

O usuario nao precisa operar a ferramenta. Warp, controlador completo, cordas,
objetos/objetivos Tidal e demais criterios de fechamento continuam pendentes.
Nenhum objeto promovido a SUPPORTED por causa do indice.
