# Ferramentas do DKC3Recomp - v0.46.0

Referencia: https://github.com/elliotttate/DKC3Recomp
Commit fixado: `3a033f19801a2bd3abf784d4b29c4462495d19de`.
Mesma ROM US En/Fr, SHA-256 `2277a2d8dddb01fe5cb0ae9a0fa225d42b3a11adccaeafa18e3c339b3794a32b`.

## O que foi aproveitado

| Recurso | Uso nesta entrega |
|---|---|
| input_playback / input_recording (MIT) | Formato comum de comandos; parser/gravação e CLI nativos |
| desktop_viewport (MIT) | Ajuste Windows com pixel SNES 7:6, quadro 256x224 em 4:3 |
| Metadados cfg | 4718 funções, 353 despachos, 540 regiões de dados indexados |
| Headless externo | Script para executar uma referência compilada separadamente e coletar dumps |
| Rotinas/ROM originais | Endereços ajudam a selecionar traduções e casos de teste |

Nenhum CPU, PPU, APU, intérprete, código de jogo gerado ou biblioteca snesrecomp
foi acrescentado ao runtime nativo. Recursos de áudio/rewind/savestate do recomp
dependem de outro modelo de estado; exigem adaptação antes de serem úteis aqui.

## Replay nativo

Execute na raiz do projeto (ou bin com assets e rom). O executável é compilado
pelo BUILD-WINDOWS.cmd. As ferramentas Python requerem Python 3.9+.

```text
bin/dkc3_native_replay.exe boat tests/replays/boat-entry.txt boat.csv
bin/dkc3_native_replay.exe game tests/replays/lakeside-jump.txt lakeside.csv
python tools/compare_replays.py boat.csv boat-again.csv
python tools/compare_replays.py boat.csv boat-again.csv --fields x,y,area --tolerance 0.001
python tools/recomp_catalog.py ellie
python tools/recomp_catalog.py B8E432
python tools/recomp_catalog.py targets: --kind dispatch
python tools/build_recomp_catalog.py /caminho/DKC3Recomp catalogo-regenerado.json
```

CSV: frame, mask, mode, x, y, vx, vy, grounded, area, level, framehash,
wall, air_wall, ground_follow. O comparador exige quadros consecutivos desde 0;
retorna 0 igual, 1 divergente, 2 entrada inválida. Tolerância somente para
x/y/vx/vy. Hash compara a imagem nativa 256x224, não a saída do PPU original.

Para gravar os comandos executados pelo CLI, defina `DKC3_NATIVE_INPUT_REC`
com o caminho do arquivo de saída antes de executá-lo. Não sobrescreva o
arquivo de entrada. A gravação da entrada Windows ao vivo ainda não está ligada.

Formato de comandos: máscara SNES hexadecimal de 6 dígitos por quadro;
`000082*100` repete 100 quadros. Comentários começam com #. B=bit0, Y=bit1,
Select=bit2, Start=bit3, cima/baixo/esquerda/direita=bits4/5/6/7,
A/X/L/R=bits8/9/10/11. O motor usa adaptadores: B pula; Y corre e ataca;
Select troca Kong. No barco B/Start confirmam, Select/A cancelam e Y/R aceleram.
O arquivo tem formato comum, mas os controles/estados não são equivalentes 1:1.

## Referência externa

Compile o headless no próprio DKC3Recomp seguindo suas instruções/licenças.
Não é distribuído neste ZIP e não foi executado nesta entrega.

```text
python tools/run_recomp_reference.py /caminho/dkc3_snesrecomp_headless rom/dkc3_ptbr.sfc tests/replays/boat-entry.txt 191 dumps --savestate /caminho/estado-original
```

O script configura SNESRECOMP_INPUT_PLAY e os dumps finais WRAM/VRAM/OAM;
sem savestate a referência inicia pelo boot, diferente do mapa nativo.
Antes de comparar motores será necessário alinhar cena/quadro/estado e decodificar
campos originais. O comparador CSV não faz essa conversão automaticamente.

## Próximas traduções

Catálogo confirma `animal_buddy_box_main` em B8EE88, `ellie_main` em B8E432
e `ellie_diagonal_water_shot_main` em B8E6FF. Encontrar uma função não basta:
seus despachos e subrotinas devem ser analisados, traduzidos e validados.
Para ampliar as cordas, distinguir estados gerais dos Kongs do objeto de Kong-Fused Cliffs;
um nome contendo rope não identifica sozinho o controlador de escalada.

O acesso nativo a Orangatanga usa entrada (382,398), rota na água e confirmação
separada para entrar na fase. Teste padrão chega à região em 38 ticks após Start;
colisões de margem, cancelamento, turbo e recuperação de saves continuam cobertos.
