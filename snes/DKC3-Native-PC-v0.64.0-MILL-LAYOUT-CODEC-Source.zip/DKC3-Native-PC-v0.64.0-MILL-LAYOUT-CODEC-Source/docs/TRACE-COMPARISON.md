# First divergence in native traces

The runtime writes `dkc3.trace.v1` JSONL: one complete record per frame, starting at
0 with consecutive frame numbers. Compare two runs of the same replay with:

```sh
python tools/compare_native_traces.py baseline.jsonl candidate.jsonl \
  --json comparison.json --markdown comparison.md --context 3
```

Exit status is 0 for matching state/input sequences, 1 for a state difference or
missing frame, and 2 for invalid evidence, incompatible inputs or output failure.
The detector scans chronologically; it never uses binary search. A difference
followed by reconvergence is still reported at its first frame. A later length
mismatch does not hide an earlier state difference. Both entire files are
validated, including records after the first difference; invalid evidence or an
input mismatch anywhere overrides a provisional difference.

Each record requires `schema`, `frame`, `input`, `state`, `state_hash`, `calls`,
`events`, `metrics` and `provenance`. State is a nonempty flattened object whose
values are canonical strings or null (unavailable). Integers are decimal,
booleans are `0`/`1`, and floating point values use exact lowercase hexadecimal
bits (`f32:3f800000` or `f64:3ff0000000000000`). Nonfinite floats are invalid.
The hash is standard FNV-1a64, offset basis `14695981039346656037`, multiplier
`1099511628211`, modulo 2^64: for each lexicographically sorted key, hash its UTF8
bytes, a zero byte, the value's UTF8 bytes, then a zero byte. Null is represented
by the literal `<unavailable>` in the hash. Hash output is 16 lowercase hex digits.
Keys and values cannot contain embedded zero bytes. The detector also compares
actual fields, so hash collisions and null versus literal `<unavailable>` cannot
hide a difference. Missing fields and present null fields remain distinct.

Native routine calls use `kind: "native"`, a function name and null `pc`,
`opcode`, and `bank`, plus a `rom_reads` list of objects. An optional `source_pc`
is a source annotation, never an observed instruction. Reference calls use
`kind: "reference"`; actual instruction fields may be present. Events have a
nonempty `type`. Metrics are reported as context; timing, read counts and event
metadata are not part of the compared state. Every state field is compared;
there is no JSONL field filter or numeric tolerance that could conceal drift.

The JSON/Markdown report lists every different variable at the first divergent
frame, recent calls/events/metrics and candidate functions. Recent ROM reads
are included even if their relation to state is unknown. Reads with explicit
`state_keys`, `object_key`, or `object_id` matching a changed object field are
listed separately as related reads. Association keys can also annotate a call.
Object prefixes of the form `objects.enemies.3`, `objects.0`, `objects[0]`,
`object.0` or `entities.0` can be identified. These are associations,
not evidence that the read or function caused the difference.

Provenance must be `native-runtime`, `reference-runtime`, or `snes-reference`,
and must stay constant within each file. Different producers can be compared,
but labels alone do not authenticate a reference. Native versus native proves
repeatability only. The report always leaves `snes_reference_proven` false and
`cause_confirmed` false. A matching trace only covers the state fields that its
producer emits; it does not prove complete original game coverage.

Empty traces, invalid UTF8, incomplete JSON, duplicate keys, nonfinite JSON
numbers, missing required fields, bad hashes, fabricated native instruction
fields and nonconsecutive frames are invalid. A cleanly truncated stream of
complete records is a missing-frame difference rather than malformed JSON.
Memory use is bounded by the current records and the configured recent context;
files are streamed once.

Legacy CSV routes remain supported by `tools/compare_replays.py`, including
`--fields` and `--tolerance`. Selected CSV fields are disclosed in the output;
inputs, when present, must still match. Its chronological comparison also
reports an earlier state difference before a later length difference. CSV
has no canonical state hash or native/reference instruction evidence.

Run the regression tests with:

```sh
python -m unittest discover -s tests/tools -p test_native_traces.py
```
