# Spawn Script e Lakeside — v0.60.0

O parser antigo tratava F9 como tail jump e juntava todos os IDs visitados.
BB:91B4 salva Y, chama o script-base, restaura Y e continua. Assim, FF:718A e
FF:719E terminam em $02C4, enquanto FF:9598/959F herdam $0430 e substituem
por $0434. Os campos $6C dessas duas variantes sao 3/2 (recompensa).

A nova decodificacao guarda palavras por offset da estrutura original,
animation handle, palette command e presenca de escrita. F4 traduz parametros
relativos a X/Y, limites, velocidade assinada e campos de movimento. F8 conserva
somente valores comuns aos dois ramos, sem inventar um valor da RAM global.
F6/F7 ainda nao instanciam filhos dinamicos; F1 conserva deslocamento sem aplicar
a direcao do sprite pai e F5 nao resolve as coordenadas globais semi-dinamicas.
Portanto este decoder nao representa o runtime original completo de spawn.

Os barris comuns compartilham o sistema nativo de carregar/lancar/quebrar, mas
a propriedade `rescuesPartner` separa a restauracao do parceiro dos demais
barris. A folha Objects & Effects fornece oito frames adicionais de barril comum.

## Entrada na agua

B8:C6DE seleciona gravidade/limite de nado dos offsets $0228/$0230 da tabela
FF:1840. B8:A035 aplica ADC e limita a velocidade positiva. O adapter agora
usa essa resposta ao entrar na agua: uma queda seca rapida nao persiste ate
atravessar o fundo do mapa. O restante do integrador de nado permanece host.

B8:C73A foi traduzido com a semantica N das comparacoes de palavra: agua
negativa desativa o probe; pes 8 pixels abaixo ainda secos; 9..20 superficie;
21 abaixo submerso. Player conserva o resultado para o port dos estados.
Usar esse probe sozinho para escolher movimento que ainda usa o adapter
invalidou os replays; essa integracao foi retirada. O teste cobre 65536 palavras.

## Percursos por input

| Replay | Frames | Resultado |
|---|---:|---|
| lakeside-bonus1-v050.txt | 1480 | 50 estrelas, moeda, retorno |
| lakeside-bonus2-v051.txt | 4289 | 15 bananas, moeda, checkpoint, retorno e saida |
| lakeside-both-bonuses-v054.txt | 4942 | Ambos, duas moedas, checkpoint e saida; cinco vidas |
| lakeside-extended-v059.txt | 6848 | DK Coin, ambos bonus, parceiro pelo DK Barrel, Ellie/Bear Coin, checkpoint e saida; cinco vidas |

O novo bot le X do Bonus Entry 2 das entidades da ROM, ajusta o input perto da
entrada e troca para Kiddy por input. Usa macros de input para as salas,
sem modificar coordenadas ou velocidades. A macro do Bonus 2 tem 1150 frames.
`lakeside_combined_input_tests` reproduz o percurso completo e repete com moedas
ja premiadas, verificando que nao sao duplicadas. Warp ainda nao foi percorrido.

CLI: `dkc3_native_route_bot lakeside output.txt`, `lakeside-bonus2 output.txt`
ou `lakeside-extended output.txt`, `tidal output.txt`. Executar da raiz do projeto. Tidal significa percurso
spawn/checkpoint/saida, sem seus bonus ou objetos ainda ausentes.

## Cobertura real

Lakeside: 47 registros, 47 PARTIAL e 0 UNKNOWN. Tidal: 61, 27 PARTIAL e 34
UNKNOWN. Nenhuma definicao foi promovida a SUPPORTED. Os CSVs mostram ID final,
descriptor, animation handle, estado, recompensa e ramos condicionais.

Os tres ultimos IDs agora possuem handlers PARTIAL. Todos os
placements resolvem ID; identificar o ID nao equivale a portar seu comportamento.
Controlador completo, Warp, triggers fiéis de checkpoint/saida, animais,
cordas/objetos originais e bonus de Tidal continuam objetivos abertos.

## Booty Bird — v0.52

O decoder de frames calcula os limites a partir dos grupos do header OAM e
consulta a tabela de palettes usada por BB:9651. Oito frames de D4:C583..D8B7
e palette $004F alimentam os dois placements $0434, sem importar outra folha.

B6:B894 seleciona a recompensa por campo $6C na tabela FF:257C. Lakeside usa
indice 3 (G), Tidal usa 2 (N). Um caminho de derrota compartilhado por golpes,
pisoes e barris libera uma recompensa, com offset original +21/-29 e Y-2.
Uma letra ja coletada usa indice 4 (banana), conforme B6:B897. A selecao e
resolvida no carregamento; derrotar o objeto nao reabre o arquivo da ROM.

Patrulha e hitbox usam adapters host. Movimento oscilatorio, morte e trajetoria
da recompensa originais nao estao completos. O objeto permanece PARTIAL.

`dkc3_native_route_bot lakeside-bird output.txt` reproduz ambos bonus e ajusta
a aproximacao/salto/rolamento usando a posicao observada do passaro. O replay
`lakeside-bird-and-bonuses-v055.txt` tem 4897 frames, duas Bonus Coins, G,
checkpoint e saida, com cinco vidas durante todo o percurso. Nao coleta as
outras tres letras nem percorre o Warp. Tests de colisao usam fixtures locais;
os dois replays completos continuam usando exclusivamente input.

## Ellie — v0.53

RomAnimal traduz o atraso da caixa B8:EEF3/EF1F (4 -> -1: cinco ticks), o
predicado da placa B8:ED8F..EDA7 e a extensao/mirror dos offsets B8:EE18..EE48.
O teste do contato verifica 65536 palavras, inclusive o bit N da subtracao,
e os limites horizontais assimetricos: animal entre signX-15 e signX+16.

Quatro idles, 14 walks, caixa fechada/aberta e placas Ellie/Enguarde usam os
headers/graficos originais, com palettes $16/$1C/$10. B8:9071/D4DB/D509
selecionam os offsets de salto/walk/run usando animal $0234 e a coluna do Kong.
O salto aplica o incremento $0100 do integrador; a gravidade reutiliza o perfil
Kong enquanto o restante da maquina de estados animal nao esta completo.

O dispatcher agora instancia a caixa e as placas. Impactos carregados e
arremessados compartilham o atraso, sem contar o tick do impacto. Colisoes com
Kongs e as transicoes de montar/desmontar usam adapters host. A protecao contra
animal duplicado e checada no impacto e novamente no spawn; o original escaneia
slots na inicializacao. A placa faz a selecao da recompensa por $5E em FF:257C;
Lakeside usa 5, tipo $00C6, Bear Coin (sprite $0284), conforme B8:891F e BB:D24E.
O offset $D040 significa +64/-64 X e -48 Y. A trajetoria original da recompensa
nao foi portada; o item fica no ponto calculado e pode ser coletado por input.

A placa Enguarde de Tidal tem visual/parametros e predicado generico, mas o
animal Enguarde ainda nao existe no runtime. O campo PARTIAL explicita isso.

`dkc3_native_route_bot lakeside-ellie output.txt` usa o replay anterior ate a
aproximacao da caixa e ajusta o input pela posicao/velocidade observadas. Salta
novamente quando uma parede interrompe a corrida. Offsets de navegacao sao
calibrados para Lakeside; nao representam AI original. O replay tem 4802
frames, 50 estrelas, 15 bananas, duas Bonus Coins, caixa, montaria, placa,
Bear Coin, checkpoint e saida. Cinco vidas durante todo o percurso. Nao inclui
Warp nem as quatro letras; a rota do Booty Bird continua separada.

29 suites GCC/Linux. Fixtures de colisao montam cenas controladas; os tres
percursos completos e suas repeticoes nunca alteram posicao/velocidade.

## Controles de fase — v0.54

O controlador $0190 de Lakeside cria **Koin $03D0 e DK Coin $03D4**:
B6:A073 chama tipos $D0/$D2, cujos scripts FF:30CD/30F2 confirmam os IDs.
A identificacao anterior como Knocka estava incorreta. O runtime preserva os
scripts filhos, desenha o corpo/escudo da tabela BC:8000 com palettes $57/$23,
e aplica contato solido host. Rolamento/pisao nao matam Koin. O aco, impacto, liberacao e persistencia receberam port parcial em v0.55,
conforme a secao abaixo. Estados completos de defesa/virada ainda faltam.

$0160 usa o retangulo BC:E14B[$16] (-32,-4,64,16), endereco $15E6 e comando
$0101 em Lakeside ($0301 em Tidal). BB:DE63 opera **um byte**: modo zero grava
zero; modo um faz OR com o byte alto; demais modos fazem XOR. O endereco e
armazenado em estado nativo local, sem CPU emulada. Contato de barris usa
adapter host e consome o trigger uma vez. Colisao original completa, estado
Kong $4F, cinco fragmentos e consumidores posteriores da RAM continuam pendentes.

$0138 nao tem IA/movimento: B6:805A chama BB:AB52. Aritmetica de timer traduzida:
onscreen copia o byte baixo para o alto; offscreen subtrai $0100 e remove no
borrow. Ativacao/janela/reativacao usam camera host, nao os grupos e tabelas
originais. Nao existe colisao nem sprite artificial para esse controle.

29 suites, incluindo control_tests: 16.777.216 combinacoes de comandos/bytes,
131.072 casos de timer, scripts e graficos ROM, trigger e colisao/reload.
Fixtures de unidade alteram posicoes e camera explicitamente; os replays ouro
continuam exclusivamente por input. O replay ambos-bonus v054 continua valido; G/Ellie foram renovados em v055
apos corrigir o gerador anteriormente contado como DK Barrel.
0 SUPPORTED, 47 PARTIAL/0 UNKNOWN em Lakeside; Tidal 27 PARTIAL/34 UNKNOWN.
Zero UNKNOWN indica existencia de handlers, nunca port completo da fase.


## Steel keg e DK Coin — v0.55

$0170/FF:5DA9 e BarrelRespawner, nao DK Barrel. Campos $5E/$60/$62/$6C
selecionam um filho, timer $3C00, espacamento $0008 e tipo $0468.
FF:0040[$0468] aponta para $02D4. BE:E656 troca os bytes do timer;
o countdown alto e reset pelo byte baixo foram portados. Ativacao por camera,
slots e contatos continuam host; a implementacao atende o filho unico usado aqui.

B6:A4FE..A580 foi traduzido para impacto de steel keg: testa altura, terreno
$0101, orientacao e excecao do escudo elevado. B6:A6C4..A735 seleciona nove
poses de mira usando divisao de palavra e limiares originais. Graficos $2431,
Koin $2DCD..$2DF5, escudos e DK Coin $2E3B usam dados/palettes da ROM.

O barril tem integrador separado em ticks de 60Hz, varredura de paredes/chao,
reflexao horizontal e continuidade apos atingir inimigos. Fisica, animacao e
estados completos BE:D68B..D993, riding/agua e pool de quatro slots pendentes.
A moeda espera 0,5s e aparece em offset host; o voo original ainda nao foi portado.

Progresso original de dois bits (0 protegido, 1 liberado, 2 coletado) preserva
fases vizinhas. Save V8 guarda flags e contador; V1..V7 ainda carregam. Revisita
no estado 1 conserva a moeda liberada; estado 2 nao duplica recompensa.

`lakeside-koin-v057.txt`: 1903 frames, Bonus 1/50 estrelas, DK Coin e cinco
vidas desde spawn, somente input. Termina na coleta. O mesmo input com a
moeda ja paga preserva o contador. Nao e o percurso completo ate a bandeira.
Os percursos completos separados permanecem: ambos bonus 4942, G 4897,
Ellie/Bear Coin 4802; cinco vidas em cada frame. DK+ambos+Ellie+saida agora cobertos pelo replay v059. Warp ainda aberto.

29 suites: 393216 casos de impacto, preservacao de flags vizinhas, fisica/ticks,
respawner ROM, defeat/reload/collect, save e replays. Fixtures de unidade alteram
posicoes explicitamente; replays ouro nao. Cobertura permanece 0 SUPPORTED:
Lakeside 47 PARTIAL, Tidal 27 PARTIAL/34 UNKNOWN.


## Lancamento e ricochete de aco — v0.56

BE:D960..D974 escreve $FF00 em y_velocity e $0200 em x_velocity e
x_target_velocity, negando o horizontal quando BIT $58 seta V (bit 14).
O adapter de input passa a direcao nativa e converte 8.8 por 60/256 para px/s.
Barris de madeira/DK conservam sua fisica parcial anterior.

BE:D781..D798 inverte OAM $4000 e nega as palavras pre-colisao $AE/$B0,
sem saturar -32768. A colisao por varredura host usa essa resposta traduzida.
Alvo horizontal e OAM sao preservados no corpo nativo do aco.
Isso ainda nao porta gravidade, movimento $004F, riding, agua, toda a
maquina de estados ou poses de carregar. Nenhum objeto foi promovido.

steel_state_tests confere 65536 flags de direcao, 196608 combinacoes de
palavras/OAM, ricochete duplo e release por input nos dois sentidos.
Os bytes dessas duas rotinas foram conferidos na ROM PT-BR fornecida.


## Gravidade e interpolacao do aco — v0.57

O descriptor do filho $0468/$02D4 aponta pelo campo $06 para FF:1DD4 e
seleciona movimento $004F. O loader le as tres palavras: gravidade $0070,
limite $0800, modo horizontal 8. Perfil invalido falha no carregamento.
B9:EE0D -> EBF8 -> EE78 soma gravidade em 16 bits, testa N e limita por CMP
unsigned. EE6E seleciona interpolacao 8 de F4B0; F54F calcula (absdiff>>4)
+ (absdiff>>6), preservando wrap, sinal N do diff e snap quando delta zero.

O integrador do aco aplica esses passos a cada tick de 60Hz. Conversao 8.8:
primeira aceleracao 26,25 px/s por tick, terminal 480 px/s. A posicao,
varredura, contatos/chao, probes completos, agua/riding/animacoes ainda host.
Nao se trata do movimento $004F completo nem do controlador Kong completo.
Nenhum placement foi promovido a SUPPORTED.

steel_motion_tests cobre perfil ROM, rejeicao, 65536 velocidades verticais,
262144 casos horizontais, limite, primeiro tick e equivalencia 30/60Hz.

Adapter de contato com escudo inverte velocidade e alvo juntos para evitar
reacelerar para dentro de Koin; isso e integracao host, nao port do contato original.


## Resposta de terreno do aco na agua — v0.58

B9:EC09..EC3B desativa a reducao para agua negativa. Caso contrario soma
$0010 em 16 bits e compara unsigned aos pes: ate water+16 usa velocidade
inteira; abaixo disso usa duas ASL no acumulador e duas ROR na palavra.
A segunda carry e o bit 14 original, nao o sinal repetido. Na faixa normal
isso produz um quarto da velocidade; extremos preservam a aritmetica original.

A consulta de terreno usa essas velocidades temporarias; depois o original
restaura $2E/$2A. O adapter usa o deslocamento reduzido e conserva velocidades
inteiras quando nao ha contato. Parede captura $B0 temporario e alvo $AE
inteiro (B9:F181); a resposta BE:D781 nega ambos. Colisao/posicao ainda host.

O nivel de agua vem do runtime ROM da fase, com offset nativo +256. Isso nao
porta B9:EEA0/F65E completos, transicao de agua profunda BE:D8E7, riding,
flutuacao, animacoes ou toda a maquina de estados. Continua PARTIAL.

steel_water_tests: 65536 pares de rotacoes, 262144 water/feet, fronteira +16,
valores extremos, deslocamento, restauracao, ticks divididos e parede submersa.

## Pipeline e percurso ampliado — v0.59

O codec PIER usa o header FD:0000, bounds B7:B431 e placements FE:0000.
Foi removido o catalogo de intervalos e quantidades por fase. O stream possui
registros de oito bytes e terminador word zero; leitura limitada ao banco FE,
com rejeicao de ponteiros para dentro da tabela. A contagem e evidencia de
regressao nos testes, nao parametro de carregamento. Outros codecs continuam
UNKNOWN. O decoder PIER aceita os submapas 0..6 conhecidos; submapa 1 ainda
nao tem cobertura de teste, nao e uma nova fase considerada portada.

Salas Tidal $54/5 e $55/6: 448x512 e 608x512, 3 e 7 placements, agua Y=408,
spawn (32,480) e (53,240). Ausencia de piso nao significa terreno invalido.
A segunda sala conserva a corda. Sem entrada/objetivo/canhoes integrados ainda.

O bot extended recupera o parceiro por contato com o Floating DK Barrel real,
aproximando-se pela agua/lateral e usando novos strokes de B. Nao muda posicao,
velocidade, vidas ou inventario. O replay de 6848 frames passa por ambos bonus,
DK Coin, Ellie, Bear Coin, checkpoint e saida, com cinco vidas em cada frame.
O segundo teste inicia DK e Bonus Coins pagas e confirma nao duplicacao e
mesmo estado/posicao final. G segue no replay separado, Warp/KONG nao cobertos.

Tentativas de salto direto ate Warp nao produziram rota valida. A geometria
atual e o salto disponivel nao bastaram; a causa exige investigar estados e
movimentos originais. Nao foi adicionado boost, teleporte ou forca de premio.

Auditoria das salas Tidal: Bonus 1 tem 1 PARTIAL/2 UNKNOWN; Bonus 2 tem
2 PARTIAL/5 UNKNOWN. Relatorios TIDAL-BONUS1/2-SPAWN-AUDIT.txt preservam
os IDs ainda sem comportamento. Nenhum SUPPORTED nessas salas.

## Mira e ferramenta — v0.60

O workbench verifica ponteiros em B6:A6DB/A6F3 e os payloads em B6:A718/A727.
RomKoinAimProfile agora le esses ponteiros/limiares/graficos da ROM. Testes
cobrem 65536 pares, overflow do quotient/INC, relocacao de tabelas e rejeicao
de perfil invalido. Replays mantidos sem alterar posicoes. Colisao/voo/estados
Koin continuam PARTIAL. Analise e protocolo: ROM-PORT-WORKFLOW.md.
