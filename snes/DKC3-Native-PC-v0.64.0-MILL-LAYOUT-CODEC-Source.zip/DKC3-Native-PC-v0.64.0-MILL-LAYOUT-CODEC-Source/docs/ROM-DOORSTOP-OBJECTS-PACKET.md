# Doorstop object packet — v0.63.0

Generated from the SHA-bound ROM with `tools/rom_workbench.py`. Static reading only; no CPU/PPU execution. The C++ port keeps these four families PARTIAL.

## Sprite mapping confirmed by spawn IDs + adjacent known families

| Sprite ID | Original routine | Address | Doorstop placements |
|---|---|---:|---:|
| `0x02FC` | `buzz_main` | `B6:8170` | 14 |
| `0x038C` | `door_lever_handle_main` | `B6:923F` | 15 |
| `0x0390` | `metal_door_lever_controlled_main` | `B6:9338` | 14 |
| `0x0394` | `door_gear_main` | `B6:93FF` | 14 |

The Buzz mapping is also cross-checked by the sprite sequence already used by the port: Sneek is `0x02F8`, Buzz uses the next family `0x02FC`, and Koco uses `0x0300` in Tidal. Doorstop spawn scripts use animations `0x0139/0x013B` for `0x02FC`.

## Reviewed dispatch tables
```text
B68173 817B
B68175 81A1
B68177 81BD
B68179 81C8
B69242 925E
B69244 9295
B69246 92E8
B69248 924A
B6933B 933F
B6933D 9350
B69402 9406
B69404 940D
```

## Buzz state 0
# ROM B6817B..B681A1

Static reading only; no CPU/PPU execution. Bytes and operands come from the current ROM.

Catalog entry: buzz_main_state_0 — entry M/X hint `0,0`; not an exit proof.

```text
B6817B  A9 38 00    LDA #$0038               buzz_main_state_0
B6817E  22 06 C0 BE JSL $BEC006              
B68182  B0 28       BCS $B681AC              
B68184  22 25 E4 BC JSL $BCE425              
B68188  A9 00 00    LDA #$0000               
B6818B  22 09 C0 BE JSL $BEC009              
B6818F  90 02       BCC $B68193              
B68191  D0 19       BNE $B681AC              
B68193  22 06 A0 B9 JSL $B9A006              
B68197  22 00 E0 B9 JSL $B9E000              
B6819B  20 12 82    JSR $8212                
B6819E  4C 5A 80    JMP $805A                
```

## References

- JSL at `B6817E` to `BEC006` check_throwable_collision
- BCS at `B68182` to `B681AC` 
- JSL at `B68184` to `BCE425` populate_sprite_clipping
- JSL at `B6818B` to `BEC009` CODE_BEC009
- BCC at `B6818F` to `B68193` 
- BNE at `B68191` to `B681AC` 
- JSL at `B68193` to `B9A006` process_sprite_animation
- JSL at `B68197` to `B9E000` process_current_movement
- JSR at `B6819B` to `B68212` CODE_B68212
- JMP at `B6819E` to `B6805A` barrel_switch_s_main / return_handle_despawn / unknown_sprite_0138_main

## Native source leads (not coverage proof)


## Unknowns and obligations

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B6817E JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B68184 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B6818B JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B68193 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B68197 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B6819B JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- Short memory operands require DBR/direct-page context; a source name or address mention alone does not establish a physical memory address.
- Preserve word wrap, carry/sign flags and memory offsets; verify the C++ with bounded original-routine oracles and input replays.

## Door lever active state
# ROM B6925E..B69295

Static reading only; no CPU/PPU execution. Bytes and operands come from the current ROM.

Catalog entry: CODE_B6925E — entry M/X hint `0,0`; not an exit proof.

```text
B6925E  BB          TYX                      CODE_B6925E
B6925F  B5 32       LDA $32,X                
B69261  95 16       STA $16,X                
B69263  20 41 94    JSR $9441                
B69266  20 01 93    JSR $9301                
B69269  F0 1C       BEQ $B69287              
B6926B  F6 38       INC $38,X                
B6926D  A9 6A 06    LDA #$066A               
B69270  22 12 80 B2 JSL $B28012              
B69274  A9 6B 07    LDA #$076B               
B69277  22 12 80 B2 JSL $B28012              
B6927B  A9 90 03    LDA #$0390               
B6927E  20 F9 92    JSR $92F9                
B69281  BB          TYX                      
B69282  F6 6A       INC $6A,X                
B69284  4C 5A 80    JMP $805A                CODE_B69284
B69287  A9 02 00    LDA #$0002               CODE_B69287
B6928A  22 0F C0 BE JSL $BEC00F              
B6928E  90 03       BCC $B69293              
B69290  DC F5 04    JML [$04F5]              
B69293  80 EF       BRA $B69284              CODE_B69293
```

## References

- JSR at `B69263` to `B69441` CODE_B69441
- JSR at `B69266` to `B69301` CODE_B69301
- BEQ at `B69269` to `B69287` CODE_B69287
- JSL at `B69270` to `B28012` queue_sound_effect
- JSL at `B69277` to `B28012` queue_sound_effect
- JSR at `B6927E` to `B692F9` CODE_B692F9
- JMP at `B69284` to `B6805A` barrel_switch_s_main / return_handle_despawn / unknown_sprite_0138_main
- JSL at `B6928A` to `BEC00F` CODE_BEC00F
- BCC at `B6928E` to `B69293` CODE_B69293
- BRA at `B69293` to `B69284` CODE_B69284

## Native source leads (not coverage proof)


## Unknowns and obligations

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B69263 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B69266 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B69270 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B69277 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B6927E JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B6928A JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B69290: indirect control flow; target set requires a reviewed dispatch contract or RAM state.
- Short memory operands require DBR/direct-page context; a source name or address mention alone does not establish a physical memory address.
- Preserve word wrap, carry/sign flags and memory offsets; verify the C++ with bounded original-routine oracles and input replays.

## Metal door motion state
# ROM B69350..B693FF

Static reading only; no CPU/PPU execution. Bytes and operands come from the current ROM.

Catalog entry: CODE_B69350 — entry M/X hint `0,0`; not an exit proof.

```text
B69350  BB          TYX                      CODE_B69350
B69351  B5 6A       LDA $6A,X                
B69353  F0 0F       BEQ $B69364              
B69355  22 86 F1 B6 JSL $B6F186              
B69359  B0 09       BCS $B69364              
B6935B  74 6A       STZ $6A,X                
B6935D  A9 74 07    LDA #$0774               
B69360  22 12 80 B2 JSL $B28012              
B69364  22 48 C0 BE JSL $BEC048              CODE_B69364
B69368  A9 94 03    LDA #$0394               
B6936B  20 F9 92    JSR $92F9                
B6936E  B5 60       LDA $60,X                
B69370  D0 02       BNE $B69374              
B69372  B5 62       LDA $62,X                
B69374  99 5E 00    STA $005E,Y              CODE_B69374
B69377  84 1A       STY $1A                  
B69379  E2 20       SEP #$20                 
B6937B  B5 5E       LDA $5E,X                
B6937D  8D 02 42    STA $4202                
B69380  C2 20       REP #$20                 
B69382  20 DD F2    JSR $F2DD                
B69385  A8          TAY                      
B69386  B9 6F 1B    LDA $1B6F,Y              
B69389  E2 20       SEP #$20                 
B6938B  8D 03 42    STA $4203                
B6938E  C2 20       REP #$20                 
B69390  EA          NOP                      
B69391  AD 16 42    LDA $4216                
B69394  EB          XBA                      
B69395  29 FF 00    AND #$00FF               
B69398  8D 15 1C    STA $1C15                
B6939B  B5 5C       LDA $5C,X                
B6939D  38          SEC                      
B6939E  ED 15 1C    SBC $1C15                
B693A1  95 16       STA $16,X                
B693A3  20 DD F2    JSR $F2DD                
B693A6  A8          TAY                      
B693A7  B5 60       LDA $60,X                
B693A9  F0 1C       BEQ $B693C7              
B693AB  18          CLC                      
B693AC  79 6F 1B    ADC $1B6F,Y              
B693AF  C9 FF 00    CMP #$00FF               
B693B2  90 08       BCC $B693BC              
B693B4  A9 FF 00    LDA #$00FF               
B693B7  99 6F 1B    STA $1B6F,Y              
B693BA  80 37       BRA $B693F3              
B693BC  99 6F 1B    STA $1B6F,Y              CODE_B693BC
B693BF  74 60       STZ $60,X                
B693C1  A9 01 00    LDA #$0001               
B693C4  48          PHA                      
B693C5  80 26       BRA $B693ED              
B693C7  B5 66       LDA $66,X                CODE_B693C7
B693C9  29 FF 00    AND #$00FF               
B693CC  18          CLC                      
B693CD  75 64       ADC $64,X                
B693CF  95 66       STA $66,X                
B693D1  C9 00 01    CMP #$0100               
B693D4  90 20       BCC $B693F6              
B693D6  B9 6F 1B    LDA $1B6F,Y              
B693D9  38          SEC                      
B693DA  F5 62       SBC $62,X                
B693DC  10 08       BPL $B693E6              
B693DE  A9 00 00    LDA #$0000               
B693E1  99 6F 1B    STA $1B6F,Y              
B693E4  80 0D       BRA $B693F3              
B693E6  99 6F 1B    STA $1B6F,Y              CODE_B693E6
B693E9  A9 00 00    LDA #$0000               CODE_B693E9
B693EC  48          PHA                      
B693ED  A4 1A       LDY $1A                  CODE_B693ED
B693EF  68          PLA                      
B693F0  99 5C 00    STA $005C,Y              
B693F3  4C 5A 80    JMP $805A                CODE_B693F3
B693F6  B9 6F 1B    LDA $1B6F,Y              CODE_B693F6
B693F9  A6 1A       LDX $1A                  
B693FB  F6 60       INC $60,X                
B693FD  80 EA       BRA $B693E9              
```

## References

- BEQ at `B69353` to `B69364` CODE_B69364
- JSL at `B69355` to `B6F186` CODE_B6F186
- BCS at `B69359` to `B69364` CODE_B69364
- JSL at `B69360` to `B28012` queue_sound_effect
- JSL at `B69364` to `BEC048` CODE_BEC048
- JSR at `B6936B` to `B692F9` CODE_B692F9
- BNE at `B69370` to `B69374` CODE_B69374
- JSR at `B69382` to `B6F2DD` CODE_B6F2DD
- JSR at `B693A3` to `B6F2DD` CODE_B6F2DD
- BEQ at `B693A9` to `B693C7` CODE_B693C7
- BCC at `B693B2` to `B693BC` CODE_B693BC
- BRA at `B693BA` to `B693F3` CODE_B693F3
- BRA at `B693C5` to `B693ED` CODE_B693ED
- BCC at `B693D4` to `B693F6` CODE_B693F6
- BPL at `B693DC` to `B693E6` CODE_B693E6
- BRA at `B693E4` to `B693F3` CODE_B693F3
- JMP at `B693F3` to `B6805A` barrel_switch_s_main / return_handle_despawn / unknown_sprite_0138_main
- BRA at `B693FD` to `B693E9` CODE_B693E9

## Native source leads (not coverage proof)


## Unknowns and obligations

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B69355 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B69360 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B69364 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B6936B JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B69382 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B693A3 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- Short memory operands require DBR/direct-page context; a source name or address mention alone does not establish a physical memory address.
- Preserve word wrap, carry/sign flags and memory offsets; verify the C++ with bounded original-routine oracles and input replays.

## Door gear state
# ROM B6940D..B69465

Static reading only; no CPU/PPU execution. Bytes and operands come from the current ROM.

Catalog entry: CODE_B6940D — entry M/X hint `0,0`; not an exit proof.

```text
B6940D  BB          TYX                      CODE_B6940D
B6940E  B5 60       LDA $60,X                
B69410  D0 28       BNE $B6943A              
B69412  20 DD F2    JSR $F2DD                
B69415  A8          TAY                      
B69416  B9 6F 1B    LDA $1B6F,Y              
B69419  F0 1F       BEQ $B6943A              
B6941B  C9 FF 00    CMP #$00FF               
B6941E  F0 1A       BEQ $B6943A              
B69420  E2 20       SEP #$20                 
B69422  A9 40       LDA #$40                 
B69424  8D 02 42    STA $4202                
B69427  B5 5E       LDA $5E,X                
B69429  8D 03 42    STA $4203                
B6942C  C2 20       REP #$20                 
B6942E  EA          NOP                      
B6942F  AD 16 42    LDA $4216                
B69432  95 44       STA $44,X                
B69434  22 06 A0 B9 JSL $B9A006              
B69438  80 02       BRA $B6943C              
B6943A  74 44       STZ $44,X                CODE_B6943A
B6943C  74 60       STZ $60,X                CODE_B6943C
B6943E  4C 5A 80    JMP $805A                
B69441  E2 20       SEP #$20                 CODE_B69441
B69443  B5 66       LDA $66,X                
B69445  8D 02 42    STA $4202                
B69448  C2 20       REP #$20                 
B6944A  20 DD F2    JSR $F2DD                
B6944D  A8          TAY                      
B6944E  B9 6F 1B    LDA $1B6F,Y              
B69451  E2 20       SEP #$20                 
B69453  8D 03 42    STA $4203                
B69456  C2 20       REP #$20                 
B69458  EA          NOP                      
B69459  AD 17 42    LDA $4217                
B6945C  29 FF 00    AND #$00FF               
B6945F  18          CLC                      
B69460  75 64       ADC $64,X                
B69462  95 32       STA $32,X                
B69464  60          RTS                      
```

## References

- BNE at `B69410` to `B6943A` CODE_B6943A
- JSR at `B69412` to `B6F2DD` CODE_B6F2DD
- BEQ at `B69419` to `B6943A` CODE_B6943A
- BEQ at `B6941E` to `B6943A` CODE_B6943A
- JSL at `B69434` to `B9A006` process_sprite_animation
- BRA at `B69438` to `B6943C` CODE_B6943C
- JMP at `B6943E` to `B6805A` barrel_switch_s_main / return_handle_despawn / unknown_sprite_0138_main
- JSR at `B6944A` to `B6F2DD` CODE_B6F2DD

## Native source leads (not coverage proof)


## Unknowns and obligations

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B69412 JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- B69434 JSL: M/X not assumed to survive; next variable length needs boundary evidence.
- B6944A JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- Short memory operands require DBR/direct-page context; a source name or address mention alone does not establish a physical memory address.
- Preserve word wrap, carry/sign flags and memory offsets; verify the C++ with bounded original-routine oracles and input replays.

## Shared multiply helper used by lever/door
# ROM B69441..B69465

Static reading only; no CPU/PPU execution. Bytes and operands come from the current ROM.

Catalog entry: CODE_B69441 — entry M/X hint `0,0`; not an exit proof.

```text
B69441  E2 20       SEP #$20                 CODE_B69441
B69443  B5 66       LDA $66,X                
B69445  8D 02 42    STA $4202                
B69448  C2 20       REP #$20                 
B6944A  20 DD F2    JSR $F2DD                
B6944D  A8          TAY                      
B6944E  B9 6F 1B    LDA $1B6F,Y              
B69451  E2 20       SEP #$20                 
B69453  8D 03 42    STA $4203                
B69456  C2 20       REP #$20                 
B69458  EA          NOP                      
B69459  AD 17 42    LDA $4217                
B6945C  29 FF 00    AND #$00FF               
B6945F  18          CLC                      
B69460  75 64       ADC $64,X                
B69462  95 32       STA $32,X                
B69464  60          RTS                      
```

## References

- JSR from `B69263` to `B69441`
- JSR from `B692BC` to `B69441`
- JSR from `B692F3` to `B69441`
- JSR at `B6944A` to `B6F2DD` CODE_B6F2DD

## Native source leads (not coverage proof)


## Unknowns and obligations

- Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.
- B6944A JSR: M/X not assumed to survive; next variable length needs boundary evidence.
- Short memory operands require DBR/direct-page context; a source name or address mention alone does not establish a physical memory address.
- Preserve word wrap, carry/sign flags and memory offsets; verify the C++ with bounded original-routine oracles and input replays.

## Port boundary

- Exact 8-bit multiply/high-byte position arithmetic is translated in `RomDoorstop.cpp`.
- Spawn-authored animation, flags, travel, close step and phase values are preserved.
- Collision, group-slot ownership, player interaction, defeat behavior and MILL rendering remain pending, so these families are PARTIAL, not SUPPORTED.
