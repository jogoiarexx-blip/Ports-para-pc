# ROM Trace → Native Map

`tools/native_map.py` reuses `rom_workbench.Workbench.report`, its decoder, the ROM-bound instruction index and the structural DKC3Recomp catalog. Both catalog and index SHA256 must match the normalized 4 MiB ROM. Copier headers are stripped by the existing reader. Mismatches fail; there is no override.

Generate the attached-ROM map from the project root:

```sh
python tools/native_map.py --output-json docs/native-map.json --output-markdown docs/native-map.md
python tests/tools/test_native_map.py
```

The shipped generated report selects six maintenance leads plus one hop of direct calls/jumps and verified Kong dispatch targets. The default limit is 256 routine spans. It records 134 spans without traversal truncation for this ROM, 1,706 nodes and 2,731 edges. This bounded selection is not whole-ROM or runtime coverage. Lakeside Limbo and Doorstop Dash are included by default. An explicit level selection replaces these defaults:

```sh
python tools/native_map.py --level lakeside --level doorstop --level tidal --output-json docs/native-map-with-tidal.json --output-markdown docs/native-map-with-tidal.md
python tools/native_map.py --span B8:9F3A..B8:9F50 --depth 0 --json
python tools/native_map.py --routine queue_sound_effect --depth 1
```

The JSON schema is `dkc3.native-map.v1`. It contains ROM/catalog/index provenance, bounded routine intervals, classification evidence, source mentions, memory operands, dispatch contracts, level fields, raw placements and a typed graph. The Markdown includes a compact Mermaid excerpt, span summaries, placements and unresolved contracts. Every graph edge has a provenance/evidence tag. Native source addresses and prior placement audits remain leads. A classification is a heuristic with explicit tokens or operands; suggested destinations are maintenance guidance, never generated code or proof of behavior.

Short memory operands retain `address: null` when DBR or direct-page D is unknown; possible IO operands are candidates only. Explicit long operands identify a base address and address space. Indexed operands retain an unknown effective address. Verified dispatch payloads retain unknown runtime selection and index bounds. Data regions and missing instruction boundaries stop decoding. Catalog intervals are structural entries, not complete functions; listings do not execute branches or prove exit contracts.

The Python level parser mirrors the field layout documented in `RomData.cpp`; it does not execute spawn scripts itself. It reads FD level-header and FE placement pointer tables, eight-byte placement records and FF descriptor pointers directly from the SHA-bound ROM. Spawn semantics now come from `dkc3_native_rom_audit`, whose generic `decodeRomLevelPlacements` path reads the same FE stream and executes the reviewed FF Spawn Script decoder without requiring a graphics/terrain scenario codec. This is why Doorstop can be audited even though shared data MILL `$198D` is not yet rendered by `RomLevelRuntime`. The shipped Doorstop audit resolves all 118 Sprite IDs: 113 rows match PARTIAL handlers and 5 remain UNKNOWN after the v0.63.0 Buzz/lever/door/gear pass. Matching audit rows are still leads, and indexing never adds SUPPORTED objects. Audio song IDs, shared-data values and native level files are metadata dependencies. Actual song/scanline/transition contracts remain unknown.

## Optional trace ingestion

```sh
python tools/native_map.py --trace PATH/native.trace.jsonl --output-json docs/native-map-traced.json --output-markdown docs/native-map-traced.md
```

Each nonblank JSONL record uses `dkc3.trace.v1`:

```json
{"schema":"dkc3.trace.v1","frame":0,"input":1,"state":{"player":{"x":64}},"state_hash":"PRODUCER_CANONICAL_HASH","calls":[{"function":"Player::update","pc":null,"opcode":null,"bank":null,"kind":"native","rom_reads":[]}],"events":[],"metrics":{"rom_bytes_read":0}}
```

The analyzer requires increasing frame IDs, input integers, state/hash, calls/events arrays and a metrics object. State hashing/comparison belongs to the trace producer/comparator; this tool validates and joins evidence. Native calls require null PC/opcode/bank. Semantic reference calls may also use null instruction fields. `rom_reads` accepts explicit 24-bit HiROM integer addresses or objects with an integer `address`. PC file offsets are not interchangeable with these addresses. An optional record-level `rom_sha256` claim must match the analyzed ROM.

An external producer that actually observes original instructions may submit `kind: "reference"` calls with PC/opcode/bank, or individual events of this form:

```json
{"type":"instruction_reference","pc":12100410,"opcode":169,"bank":184,"space":"RAM","address":8257552,"access":"read"}
```

The numbers above illustrate field types only; use actual observations. `pc` is a 24-bit original bus address; `opcode` is a byte; `bank` is optional or must equal PC's bank. `address` is a resolved bus address, `space` is ROM/RAM/IO and must match the mapping, and `access` is read/write/read_write/execute. Opcodes are checked against this ROM. This check does not prove that a producer executed the instruction, or that a claimed effective access follows from its register state. Such edges carry `observed_instruction` and producer-provenance limitations. Ordered semantic calls do not establish caller/callee stack relationships; graph edges link producers to calls and calls/instructions to observed accesses instead.

The ZIP supplies a native C++ runtime and static workbench. It contains no executing CPU dispatcher, PPU, DMA/HDMA or SPC engine. DKC3Recomp is an external reference executable, not provided here. Native semantic traces must never be described as original SNES execution. Original runtime coverage and translated-function fractions stay `null`.

## Regression checks

Tests first failed because `native_map` did not exist, then implementation was added. The eleven tests cover both SHA gates, call/bank graphs, unresolved short operands, explicit long RAM/ROM operands, dispatch bounds, data/unverified-boundary stops, semantic versus instruction observations, opcode validation, malformed frame/provenance fields, CLI JSON/Markdown, overlapping explicitly bounded spans, and the attached-ROM level records including optional Tidal. Existing workbench tests also pass. Register `tests/tools/test_native_map.py` as a Python CTest next to `rom_workbench` when integrating; this implementation does not change CMake.
