# Validação v0.61.0 — 6 de outubro de 2026

## Resultados medidos

| Verificação | Resultado |
| --- | --- |
| Suítes C++20 GCC, assertions ativas | 32/32 passaram |
| Testes Python: workbench/analyzer/comparador/conversor | 8 + 11 + 17 + 11 = 47 passaram |
| Lakeside, replay gold `lakeside-extended-v059.txt` | 6.848 frames, 14 campos CSV idênticos à v0.60.0 |
| Tidal, replay gold `tidal-trouble-route-v049.txt` | 6.243 frames, 14 campos CSV idênticos à v0.60.0 |
| Doorstop, sequência `lakeside-jump.txt` | 280 frames, 14 campos CSV idênticos à v0.60.0 |
| Lakeside: comparação JSONL extração-ROM × pacote nativo | 6.848 frames; todos os campos de estado e inputs iguais |
| Inicialização/gameplay nativo nos três replays | Zero tentativas de abrir ROM; zero bytes de ROM lidos |
| Diretório da execução nativa | Cópia apenas de assets; sem `.sfc`, `.smc` ou pasta ROM |
| Analyzer estático gerado | 134 intervalos, 1.706 nós, 2.731 arestas; sem corte pelo limite de travessia |
| Quatro cenas de assets anteriores | Hashes de pixels preservados; 164 verificações do renderer |

Os CSVs incluem posição, velocidade, estado de contato, fase, contadores de
colisão e **hash da imagem**. Doorstop usa uma sequência curta de inputs; isso não
é uma prova de conclusão da fase original.

O trace JSONL compara bits exatos de floats, timers, animações, câmera, objetos,
placements, controles, progressos e transições que o produtor emite. O RNG
original permanece indisponível. Chamadas são contexto de diagnóstico, não causa
confirmada. A referência desta comparação é o mesmo port com extração direta;
nenhum executável do SNES original foi executado.

## Dependência da ROM: medida, não estimativa

Lakeside, mesma rota de 6.848 frames:

| Métrica | Modo `rom` final | Modo `native` |
| --- | ---: | ---: |
| Aberturas da ROM no carregamento | 15 | 0 |
| Bytes da ROM lidos no carregamento | 62.914.560 | 0 |
| Bytes copiados por `RomImage::range` | 780.449 | 0 |
| Pedidos de view `bytes()` | 1.413 | 0 |
| Bytes de arquivo ROM durante gameplay | 0 | 0 |
| Frames renderizados pelo host | 6.848 | 6.848 |

O modo `rom` decodifica o pacote completo (telas/mapas/fases/bonuses/perfis).
Esses 60 MiB incluem releituras do arquivo de 4 MiB; não representam 60 MiB de
conteúdo distinto. Pedidos de view não medem leituras individuais da CPU.
O ganho demonstrado está no **carregamento e independência do arquivo ROM**.
Não alegamos redução de leituras por frame onde o valor já era zero.
PPU fallback e chamadas de hardware virtual são não aplicáveis ao runtime deste
ZIP. Cobertura de CPU/jogo original continua desconhecida.

## O que os testes adicionais protegem

- Exportar/carregar/reexportar o pacote conserva os dados; terreno e placements
  são comparados com os decoders existentes.
- Pacotes truncados, corrompidos, com versão inválida ou bytes adicionais falham
  sem publicar objeto parcialmente decodificado.
- Salas bônus PIER $50/$51/$54/$55 continuam disponíveis; uma requisição inválida
  limpa o estado anterior conforme o contrato do carregador original.
- O comparador detecta primeira diferença antes de reconvergência/truncamento,
  valida inputs/hash/schema e rejeita evidência inválida mesmo após um desvio.
- Conversor DMA rejeita capturas parciais, modos desconhecidos e retângulos que
  ultrapassam os limites do mapa.
- Máscaras, prioridades, flips, transparência, color math, scroll e operações
  semânticas têm casos de pixel e limites independentes.

A revisão independente encontrou e levou à correção do limite de tilemaps e da
configuração CRT do portátil Windows. Também foi corrigido o retorno de diretório
no script de empacotamento após seu verificador.

## Ambiente e reprodução

Compilação realizada com GCC 13, C++20, `-O1 -g`, sem `NDEBUG`, biblioteca estática
e executáveis de teste. CMake não estava instalado no ambiente; os fontes e
alvos declarados no CMake foram compilados diretamente com `g++`/`ar`.
CMake/MSVC e executável gráfico Windows **não foram executados**. As configurações
e scripts Windows são entregues para compilação local.

Os comandos CMake e de replay estão em `NATIVE-MIGRATION.md`. A sequência de
verificação usada foi: compilar a base intacta; registrar seus replays; compilar
a versão alterada; executar todas as suítes; repetir os inputs em um diretório
com apenas assets no modo nativo; comparar CSV; comparar traces semânticos de
Lakeside em ordem cronológica.

Evidência compacta está em `validation/`: resultados de cada suíte, métricas,
comparação semântica e amostra dos primeiros oito frames. Traces completos são
reproduzíveis pelos comandos; ficam fora do ZIP para evitar centenas de MB extras.

`runtime.nassets`: 48.129.769 bytes.
SHA256: `c7db06557f79ab7d73848fb31907ce759c79265f92eded71ec3a92ae590c6c2c`.

## Limite da conclusão

Esta entrega demonstra migração da carga de dados para assets e ausência de
regressão nas sequências verificadas. Player, inimigos, Doorstop completo, efeitos
HDMA e áudio original continuam com as limitações descritas em
`NATIVE-MIGRATION.md`. Não equivale a duas fases 100% portadas.
