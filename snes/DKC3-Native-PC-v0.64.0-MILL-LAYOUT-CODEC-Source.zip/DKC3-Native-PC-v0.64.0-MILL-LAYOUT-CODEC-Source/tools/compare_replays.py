#!/usr/bin/env python3
"""Compare aligned legacy native CSV traces; exit 0 equal, 1 different, 2 invalid.

For hashed JSONL state/context evidence use compare_native_traces.py.
"""
import argparse
import csv
import math
import sys


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('left')
    parser.add_argument('right')
    parser.add_argument('--fields', help='comma-separated fields (default all)')
    parser.add_argument('--tolerance', type=float, default=0)
    args = parser.parse_args(argv)
    try:
        if args.tolerance < 0 or not math.isfinite(args.tolerance):
            raise ValueError('invalid tolerance')
        with open(args.left, newline='', encoding='utf-8') as stream:
            reader = csv.DictReader(stream)
            left_columns = reader.fieldnames
            left = list(reader)
        with open(args.right, newline='', encoding='utf-8') as stream:
            reader = csv.DictReader(stream)
            right_columns = reader.fieldnames
            right = list(reader)
        if not left or not right:
            raise ValueError('empty trace')
        if not left_columns or not right_columns or len(set(left_columns)) != len(left_columns) or len(set(right_columns)) != len(right_columns):
            raise ValueError('invalid or duplicate columns')
        fields = args.fields.split(',') if args.fields else list(left_columns)
        if not args.fields and set(left_columns) != set(right_columns):
            raise ValueError('column schema mismatch')
        if not fields or any(key not in left_columns or key not in right_columns for key in fields):
            raise ValueError('missing column')
        for label, rows in (('left', left), ('right', right)):
            if any(None in row or any(value is None for value in row.values()) for row in rows):
                raise ValueError(label + ' malformed row')
            if any(int(row['frame']) != number for number, row in enumerate(rows)):
                raise ValueError(label + ' frames must start at 0 and be consecutive')
        scope = f'; selected {len(fields)}/{len(left_columns)} fields' if args.fields else ''
        first = None
        for number, (lrow, rrow) in enumerate(zip(left, right)):
            for key in ('input', 'buttons'):
                if key in left_columns and key in right_columns and lrow[key] != rrow[key]:
                    raise ValueError(f'input mismatch at frame {number}: {lrow[key]} / {rrow[key]}')
            for key in fields:
                same = lrow[key] == rrow[key]
                if not same and key in {'x', 'y', 'vx', 'vy'}:
                    lvalue, rvalue = float(lrow[key]), float(rrow[key])
                    if not math.isfinite(lvalue) or not math.isfinite(rvalue):
                        raise ValueError(f'nonfinite {key} at frame {number}')
                    same = abs(lvalue - rvalue) <= args.tolerance
                if not same and first is None:
                    first = f'DIFFERENT frame={number} field={key}: {lrow[key]} / {rrow[key]}'
        if first:
            print(first + scope)
            return 1
        if len(left) != len(right):
            print(f'DIFFERENT frame={min(len(left), len(right))} missing={"left" if len(left) < len(right) else "right"}; '
                  f'lengths {len(left)} / {len(right)}' + scope)
            return 1
        print(f'MATCH {len(left)} frames; {len(fields)} fields' + scope)
        return 0
    except (OSError, UnicodeError, ValueError, KeyError, csv.Error) as error:
        print(f'INVALID: {error}', file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
