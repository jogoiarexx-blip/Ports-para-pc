#!/usr/bin/env python3
"""Explicit DKC3 allowlist. Generates native sprite assets; never imports DKC2/Unused regions."""
from pathlib import Path
import argparse,json,struct,hashlib
import numpy as np
from PIL import Image,ImageDraw

def main():
 ap=argparse.ArgumentParser();ap.add_argument('source_directory',type=Path);ap.add_argument('--output',type=Path,default=Path(__file__).resolve().parents[1]/'assets/sprites/dkc3');args=ap.parse_args()
 out=args.output;(out/'sprites').mkdir(parents=True,exist_ok=True);(out/'anims').mkdir(exist_ok=True);(out/'screens').mkdir(exist_ok=True)
 prefix="SNES - Donkey Kong Country 3_ Dixie Kong's Double Trouble - "
 files={'kiddy':'Playable Characters - Kiddy Kong(1).png','dixie':'Playable Characters - Dixie Kong.png','wrinkly':'Non-Playable Characters - Wrinkly Kong.png','objects':'Miscellaneous - Objects & Effects.png','kremlings':'Enemies - Kremling Kreeps.png','intro':'Miscellaneous - Intro, Title, & Game Over.png'}
 images={k:Image.open(args.source_directory/(prefix+v)).convert('RGBA') for k,v in files.items()}
 keys={'dixie':(0,255,255),'kiddy':(255,0,255),'wrinkly':(255,0,255),'objects':(255,0,255),'kremlings':(0,0,255),'intro':images['intro'].getpixel((0,0))[:3]}
 manifest={'policy':'explicit allowlist; Dixie only y>=1467 DKC3 section; no Kremling Unused or alternate palettes','sources':{k:{'name':v,'size':images[k].size,'sha256':hashlib.sha256((args.source_directory/(prefix+v)).read_bytes()).hexdigest()} for k,v in files.items()},'animations':{},'screens':{}}
 thumbs=[]
 def write_sprite(im,path,origin):
  arr=np.array(im.convert('RGBA'),dtype=np.uint8);rgba=arr.copy();rgba=rgba[:,:,[2,1,0,3]]
  path.write_bytes(struct.pack('<4sHHHHhhI',b'NSPR',1,0,im.width,im.height,origin[0],origin[1],im.width*im.height)+rgba.tobytes())
 def extract(sheet,box):
  if sheet=='dixie':assert box[1]>=1467,'DKC2 excluded'
  if sheet=='kremlings':assert box[3]<=188,'Only audited standard Kobble region'
  im=images[sheet].crop(box);a=np.array(im);bg=np.all(a[:,:,:3]==keys[sheet],axis=2)
  if sheet=='dixie':bg|=(a[:,:,0]<3)&(np.abs(a[:,:,1].astype(int)-a[:,:,2].astype(int))<3)&(a[:,:,1]>3)
  if sheet=='kremlings':
   bg|=(a[:,:,2]>244)&(np.abs(a[:,:,0].astype(int)-a[:,:,1].astype(int))<3)
   # Borders are annotation, not sprite: audited cells are inset from the grid.
   bg|=np.all(a[:,:,:3]>235,axis=2)&((np.indices(bg.shape)[0]==0)|(np.indices(bg.shape)[1]==0))
  a[bg,3]=0;im=Image.fromarray(a)
  b=im.getbbox();assert b,box
  if sheet=='kiddy':
   # Black captions under swimming/idle rows are not part of the sprite.
   colored=(a[:,:,3]>0)&((np.max(a[:,:,:3],axis=2).astype(int)-np.min(a[:,:,:3],axis=2).astype(int))>20)
   yy,xx=np.where(colored)
   if len(xx):b=(max(b[0],int(xx.min())-1),max(b[1],int(yy.min())-1),min(b[2],int(xx.max())+2),min(b[3],int(yy.max())+2))
  return im.crop(b)
 def row(sheet,box):
  a=np.array(images[sheet].crop(box));m=np.any(a[:,:,:3]!=keys[sheet],axis=2)&(np.max(a[:,:,:3],axis=2)>45)
  if sheet=='kremlings':m&=~np.all(a[:,:,:3]>220,axis=2)
  xx=m.any(axis=0);runs=[];start=None
  for x,v in enumerate(xx):
   if v and start is None:start=x
   if not v and start is not None:runs.append((start,x));start=None
  if start is not None:runs.append((start,len(xx)))
  # Merge narrow fragments of a single sprite separated by 1px columns.
  merged=[]
  for lo,hi in runs:
   if merged and lo-merged[-1][1]<=1 and (hi-lo<4 or merged[-1][1]-merged[-1][0]<4):merged[-1]=(merged[-1][0],hi)
   else:merged.append((lo,hi))
  return [(box[0]+lo,box[1],box[0]+hi,box[3]) for lo,hi in merged if hi-lo>=4]
 def anim(name,sheet,boxes,model=(0,0),anchor='feet',scale=1.0,ms=100,loop=True):
  assert boxes
  lines=['NATIVE_ANIMATION 1',f'loop {int(loop)}'];records=[]
  for i,box in enumerate(boxes):
   im=extract(sheet,box)
   if scale!=1:im=im.resize((max(1,round(im.width*scale)),max(1,round(im.height*scale))),Image.Resampling.NEAREST)
   if anchor=='feet':origin=(im.width//2-model[0]//2,im.height-model[1])
   elif anchor=='center':origin=(im.width//2-model[0]//2,im.height//2-model[1]//2)
   else:origin=(im.width//2,im.height)
   filename=f'{name}-{i:03}.nspr';write_sprite(im,out/'sprites'/filename,origin);lines.append(f'frame ../sprites/{filename} {ms} 0 0')
   records.append({'rect':box,'size':im.size,'origin':origin})
   if i==0:thumbs.append((name,im))
  (out/'anims'/f'{name}.nanim').write_text('\n'.join(lines)+'\n',encoding='utf-8');manifest['animations'][name]={'sheet':sheet,'frames':records,'loop':loop,'frame_ms':ms}
 # Side-view Kiddy only; no riding/team-up poses are mislabeled as regular motion.
 idle=row('kiddy',(0,7,940,53));walk=row('kiddy',(0,108,1240,162))+row('kiddy',(0,183,425,231));jump=row('kiddy',(0,252,870,297))+row('kiddy',(0,308,625,354));roll=row('kiddy',(0,482,700,527));swim=row('kiddy',(0,850,675,908))
 anim('kiddy-idle','kiddy',idle,(23,38),ms=140)
 anim('kiddy-run','kiddy',walk,(23,38),ms=55)
 anim('kiddy-jump','kiddy',jump[:8],(23,38),ms=70,loop=False)
 anim('kiddy-fall','kiddy',jump[-4:],(23,38),ms=90)
 anim('kiddy-attack','kiddy',roll,(23,38),ms=30,loop=False)
 anim('kiddy-swim','kiddy',swim,(23,38),ms=95)
 anim('kiddy-hang','kiddy',[(31,675,67,752)],(23,38),ms=120)
 anim('kiddy-duck','kiddy',row('kiddy',(0,426,520,464)),(23,38),ms=100)
 anim('kiddy-hit','kiddy',row('kiddy',(0,539,935,587)),(23,38),ms=70,loop=False)
 # Section DKC3 starts at y=1467. Hair flick and rope idle are explicitly labeled.
 anim('dixie-idle','dixie',row('dixie',(0,1490,254,1518)),(18,34),scale=1.5,ms=140)
 anim('dixie-hang','dixie',[(166,1532,185,1560),(185,1532,203,1560),(203,1532,224,1560),(229,1532,246,1560)],(18,34),scale=1.5,ms=180)
 anim('dixie-map','dixie',row('dixie',(380,1513,473,1528)),(0,0),anchor='point',scale=1.5,ms=100)
 anim('wrinkly-idle','wrinkly',row('wrinkly',(0,3,470,59)),(0,0),anchor='point',ms=180)
 # Audited top cells. Do not import minor recolors or any "Unused" area.
 boundaries=[0,31,61,92,122,152,183,213,244]
 kobble=[(boundaries[i]+1,1,boundaries[i+1],35) for i in range(8)]
 anim('kobble-walk','kremlings',kobble,(24,36),ms=85)
 anim('kobble-death','kremlings',[(1,150,38,188),(39,150,78,188),(79,150,115,188)],(24,36),ms=85,loop=False)
 # Native object images centered on existing interaction boxes.
 anim('banana','objects',row('objects',(0,0,108,22)),(16,16),anchor='center',ms=75)
 anim('green-banana','objects',row('objects',(0,23,109,45)),(16,16),anchor='center',ms=75)
 anim('bear-coin','objects',row('objects',(790,53,997,94)),(20,20),anchor='center',ms=85)
 anim('life-balloon','objects',row('objects',(0,170,269,232)),(24,36),anchor='center',ms=95)
 anim('bonus-star','objects',row('objects',(0,116,85,140)),(14,14),anchor='center',ms=75)
 anim('bonus-coin','objects',row('objects',(532,0,945,58)),(24,24),anchor='center',ms=85)
 for index,letter in enumerate('KONG'):
  y=[0,35,69,104][index];end=[34,68,103,138][index]
  anim('kong-'+letter,'objects',row('objects',(147,y,342,end)),(16,16),anchor='center',ms=90)
 anim('barrel','objects',row('objects',(742,953,1059,999)),(30,38),anchor='feet',ms=110)
 anim('dk-barrel','objects',row('objects',(742,902,1059,952)),(30,38),anchor='feet',ms=110)
 # Sample effects are tied to actual pickup/damage events, not permanent decorations.
 anim('pickup-spark','objects',row('objects',(536,104,741,136)),(0,0),anchor='center',ms=45,loop=False)
 anim('smoke','objects',row('objects',(0,746,561,779)),(0,0),anchor='center',ms=45,loop=False)
 # Original intro/title/game-over artwork. Background keys removed only on logos.
 def screen(name,box):
  im=images['intro'].crop(box).resize((256,224),Image.Resampling.NEAREST);im.save(out/'screens'/f'{name}.bmp');manifest['screens'][name]={'rect':box,'size':im.size}
 screen('title',(1001,697,1207,877));screen('game-over',(1630,700,1835,880))
 for name,box in [('publisher',(522,700,658,787)),('studio',(550,790,621,883))]:
  im=extract('intro',box);canvas=Image.new('RGBA',(256,224),(0,0,0,255));canvas.alpha_composite(im,((256-im.width)//2,(224-im.height)//2));canvas.save(out/'screens'/f'{name}.bmp');manifest['screens'][name]={'rect':box,'size':canvas.size}
 (out/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
 (out/'CREDITS.txt').write_text('''Supplied sheets: original Donkey Kong Country 3 artwork, Rare/Nintendo.
Kiddy/Dixie/Objects/Wrinkly rips include credits to A.J. Nitro, Ant19831893, Tonberry2k, Michael Peterson, Deathbringer, Mighty Jetters and contributors named on the supplied sheets.
Kremling Kreeps: edited by christopherpaul089; rips via SNES emulator/Animget; source credits Mattrizzle and Tallikku for unused sprites (not imported).
Intro/Title/Game Over: rip by Davias.
Only the explicit manifest rectangles are imported. No DKC2 section or Unused variants are activated.
''',encoding='utf-8')
 # Contact sheet for import QA, never loaded by the game.
 preview=Image.new('RGB',(640,((len(thumbs)+3)//4)*100),'#202832');draw=ImageDraw.Draw(preview)
 for idx,(name,im) in enumerate(thumbs):
  x=(idx%4)*160;y=(idx//4)*100;draw.text((x+4,y+4),name,fill='white');preview.paste(im,(x+70-im.width//2,y+82-im.height),im)
 preview.save(out/'import-preview.png')
 print('Imported',len(manifest['animations']),'animations,',sum(len(a['frames']) for a in manifest['animations'].values()),'frames')
if __name__=='__main__':main()
