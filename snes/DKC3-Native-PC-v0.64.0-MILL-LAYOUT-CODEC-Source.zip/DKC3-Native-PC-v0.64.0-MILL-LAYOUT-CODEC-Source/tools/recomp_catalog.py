#!/usr/bin/env python3
"""Search pinned upstream routine metadata; no ROM execution."""
import argparse,json,pathlib
p=argparse.ArgumentParser();p.add_argument("query",help="name fragment or hex address, e.g. ellie or B8E432");p.add_argument("--kind",choices=["functions","dispatch","data_regions","all"],default="functions");a=p.parse_args()
d=json.loads((pathlib.Path(__file__).parent/"reference/recomp-catalog.json").read_text())
try: address=int(a.query.removeprefix("$"),16)
except ValueError: address=None
for f in (d["functions"] if a.kind in ("functions","all") else []):
 if a.query.lower() in f["name"].lower() or (address is not None and f["address"]<=address<f["end_address"]):
  print(f"{f['address']:06X}..{f['end_address']:06X} {f['name']} entry_mx={f['entry_mx']}")

if a.kind in ("dispatch","all"):
 for row in d["dispatch"]:
  addr=(row["bank"]<<16)|int(row["spec"].split()[1],16)
  if a.query.lower() in row["spec"].lower() or address==addr: print(f"{addr:06X} {row['spec']}")
if a.kind in ("data_regions","all"):
 for row in d["data_regions"]:
  start=(row["bank"]<<16)|row["start"];end=(row["bank"]<<16)+row["end"]
  if address is not None and start<=address<end: print(f"{start:06X}..{end:06X} data")
