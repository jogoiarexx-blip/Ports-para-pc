#!/usr/bin/env python3
"""Static ROM workbench. No CPU, PPU or instruction execution.

Source annotations are optional boundary evidence; operands always come from ROM.
The shipped index contains structural facts only, not assembly source or ROM bytes.
"""
from __future__ import annotations
import argparse, bisect, gzip, hashlib, json, re, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
# WDC 65816 opcode matrix. A/X immediates require width evidence.
MATRIX = '''
BRK:sig ORA:idx COP:sig ORA:sr TSB:dp ORA:dp ASL:dp ORA:dil PHP:imp ORA:ia ASL:acc PHD:imp TSB:abs ORA:abs ASL:abs ORA:long
BPL:rel ORA:idy ORA:ind ORA:sriy TRB:dp ORA:dpx ASL:dpx ORA:dily CLC:imp ORA:absy INC:acc TCS:imp TRB:abs ORA:absx ASL:absx ORA:longx
JSR:abs AND:idx JSL:long AND:sr BIT:dp AND:dp ROL:dp AND:dil PLP:imp AND:ia ROL:acc PLD:imp BIT:abs AND:abs ROL:abs AND:long
BMI:rel AND:idy AND:ind AND:sriy BIT:dpx AND:dpx ROL:dpx AND:dily SEC:imp AND:absy DEC:acc TSC:imp BIT:absx AND:absx ROL:absx AND:longx
RTI:imp EOR:idx WDM:sig EOR:sr MVP:move EOR:dp LSR:dp EOR:dil PHA:imp EOR:ia LSR:acc PHK:imp JMP:abs EOR:abs LSR:abs EOR:long
BVC:rel EOR:idy EOR:ind EOR:sriy MVN:move EOR:dpx LSR:dpx EOR:dily CLI:imp EOR:absy PHY:imp TCD:imp JML:long EOR:absx LSR:absx EOR:longx
RTS:imp ADC:idx PER:rell ADC:sr STZ:dp ADC:dp ROR:dp ADC:dil PLA:imp ADC:ia ROR:acc RTL:imp JMP:absi ADC:abs ROR:abs ADC:long
BVS:rel ADC:idy ADC:ind ADC:sriy STZ:dpx ADC:dpx ROR:dpx ADC:dily SEI:imp ADC:absy PLY:imp TDC:imp JMP:absix ADC:absx ROR:absx ADC:longx
BRA:rel STA:idx BRL:rell STA:sr STY:dp STA:dp STX:dp STA:dil DEY:imp BIT:ia TXA:imp PHB:imp STY:abs STA:abs STX:abs STA:long
BCC:rel STA:idy STA:ind STA:sriy STY:dpx STA:dpx STX:dpy STA:dily TYA:imp STA:absy TXS:imp TXY:imp STZ:abs STA:absx STZ:absx STA:longx
LDY:ix LDA:idx LDX:ix LDA:sr LDY:dp LDA:dp LDX:dp LDA:dil TAY:imp LDA:ia TAX:imp PLB:imp LDY:abs LDA:abs LDX:abs LDA:long
BCS:rel LDA:idy LDA:ind LDA:sriy LDY:dpx LDA:dpx LDX:dpy LDA:dily CLV:imp LDA:absy TSX:imp TYX:imp LDY:absx LDA:absx LDX:absy LDA:longx
CPY:ix CMP:idx REP:sig CMP:sr CPY:dp CMP:dp DEC:dp CMP:dil INY:imp CMP:ia DEX:imp WAI:imp CPY:abs CMP:abs DEC:abs CMP:long
BNE:rel CMP:idy CMP:ind CMP:sriy PEI:ind CMP:dpx DEC:dpx CMP:dily CLD:imp CMP:absy PHX:imp STP:imp JML:absil CMP:absx DEC:absx CMP:longx
CPX:ix SBC:idx SEP:sig SBC:sr CPX:dp SBC:dp INC:dp SBC:dil INX:imp SBC:ia NOP:imp XBA:imp CPX:abs SBC:abs INC:abs SBC:long
BEQ:rel SBC:idy SBC:ind SBC:sriy PEA:abs SBC:dpx INC:dpx SBC:dily SED:imp SBC:absy PLX:imp XCE:imp JSR:absix SBC:absx INC:absx SBC:longx
'''
OPS = [tuple(s.split(':')) for s in MATRIX.split()]
assert len(OPS) == 256
LEN = {m: 2 for m in ('sig','dp','dpx','dpy','idx','idy','ind','dil','dily','sr','sriy','rel')}
LEN.update({m: 3 for m in ('abs','absx','absy','absi','absix','absil','rell','move')})
LEN.update(imp=1,acc=1,long=4,longx=4)
ADDRESS = re.compile(r';\s*\$([0-9A-Fa-f]{6})')
INSTRUCTION = re.compile(r'^\s*([A-Z]{3})(?:\.([bwl]))?\s*(.*?)\s*$', re.I)
LABEL = re.compile(r'^([A-Za-z_][\w.]*)\s*:\s*(?:;.*)?$')

def number(s):
    return int(s.strip().removeprefix('$').replace(':','').removeprefix('0x'),16)

def pc(address):
    bank, low = address >> 16, address & 65535
    if address < 0 or address > 0xffffff or bank in (0x7e,0x7f) or (bank & 0x40 == 0 and low < 0x8000):
        raise ValueError(f'{address:06X} is not a mapped HiROM ROM address')
    return address & 0x3fffff

def read_rom(path):
    b = Path(path).read_bytes()
    if len(b) == 0x400200: b = b[512:]
    if len(b) != 0x400000: raise ValueError('Expected 4 MiB DKC3 HiROM (optional 512-byte copier header)')
    return b

def read_json(path):
    path=Path(path)
    return json.loads(gzip.decompress(path.read_bytes()) if path.suffix=='.gz' else path.read_bytes())

def target(address, name, mode, data):
    value = int.from_bytes(data[1:], 'little')
    if mode in ('rel','rell') and name != 'PER':
        bits = (len(data)-1)*8
        if value & (1 << (bits-1)): value -= 1 << bits
        return (address & 0xff0000) | ((address+len(data)+value) & 65535)
    if name in ('JSR','JSL','JMP','JML') and mode in ('abs','long'):
        return value if mode=='long' else (address & 0xff0000) | value
    return None

def decode(rom, address, end, widths=(None,None), boundary=None):
    off=pc(address); name, mode=OPS[rom[off]]
    evidence='fixed opcode length'
    if mode in ('ia','ix'):
        width=widths[0 if mode=='ia' else 1]
        if boundary is not None:
            size=boundary
            evidence='ROM-bound source boundary'
            if size not in (2,3): raise ValueError(f'Invalid immediate boundary at {address:06X}')
        elif width is not None:
            size=2 if width else 3; evidence='explicit width context'
        else:
            raise ValueError(f'UNKNOWN M/X width at {address:06X}; supply --mx or a ROM-bound source index')
    else: size=LEN[mode]
    if address+size>end or (address&65535)+size>65536 or off+size>len(rom):
        raise ValueError(f'Truncated instruction at {address:06X}')
    data=rom[off:off+size]; dest=target(address,name,mode,data)
    value=int.from_bytes(data[1:],'little'); val=f'${value:0{(size-1)*2}X}'
    forms={'ia':'#{}','ix':'#{}','sig':'#{}','dp':'{}','dpx':'{},X','dpy':'{},Y','idx':'({},X)',
           'idy':'({}),Y','ind':'({})','dil':'[{}]','dily':'[{}],Y','sr':'{},S','sriy':'({},S),Y',
           'abs':'{}','absx':'{},X','absy':'{},Y','long':'{}','longx':'{},X','absi':'({})',
           'absix':'({},X)','absil':'[{}]'}
    operand='A' if mode=='acc' else '' if mode=='imp' else forms.get(mode,'{}').format(val)
    if mode in ('rel','rell'):
        if name=='PER': operand=f'${(address+size+int.from_bytes(data[1:],"little",signed=True))&65535:04X} (PC-relative stack value)'
        else: operand=f'${dest:06X}'
    if mode=='move': operand=f'${data[1]:02X},${data[2]:02X} (encoded bank bytes)'
    return {'address':address,'size':size,'bytes':data.hex(' ').upper(),'mnemonic':name,'mode':mode,
            'operand':operand,'target':dest,'evidence':evidence}

def import_index(asm_dir,rom,output):
    if not Path(asm_dir).is_dir() or not list(Path(asm_dir).glob("bank*.asm")):
        raise ValueError("Assembly directory has no bank*.asm files")
    records={}; labels={}; source_hashes={}; issues=[]; pending=[]; table_rows={}; sites=[]
    for path in sorted(Path(asm_dir).glob('bank*.asm')):
        source_hashes[path.name]=hashlib.sha256(path.read_bytes()).hexdigest()
        raw=[]; pending=[]; current_table=None
        for line_no,line in enumerate(path.read_text().splitlines(),1):
            label=LABEL.match(line.strip())
            if label:
                name=label[1]; m=re.search(r'_([0-9A-Fa-f]{6})$',name)
                if m: labels[name]=int(m[1],16)
                pending.append(name); current_table=name; continue
            clean=line.split(';')[0].strip()
            words=re.match(r'^dw\s+(.+)$',clean,re.I)
            if words and current_table:
                tokens=[token.strip() for token in words[1].split(',')]
                if all(re.fullmatch(r'[A-Za-z_][\w.]*|\$[\da-fA-F]+',token) for token in tokens):
                    table_rows.setdefault(current_table,[]).extend(tokens)
            if re.match(r'^(?:db|dw|dl|dd|incbin)\b',clean,re.I): pending=[]
            at=ADDRESS.search(line)
            if not at: continue
            address=int(at[1],16)
            for name in pending:
                if not re.search(r"_[0-9A-Fa-f]{6}$",name): labels[name]=address
            pending=[]
            ins=INSTRUCTION.match(line.split(';')[0])
            if ins and ins[1].upper() in {op[0] for op in OPS}:
                raw.append((address,ins[1].upper(),ins[2],path.name,line_no))
                indirect=re.fullmatch(r'\(\s*([A-Za-z_][\w.]*)\s*,\s*[xX]\s*\)',ins[3])
                if indirect and ins[1].upper() in ('JSR','JMP'):sites.append((address,indirect[1]))
                current_table=None
        for i,(address,mnemonic,suffix,filename,line_no) in enumerate(raw):
            try:
                name,mode=OPS[rom[pc(address)]]
                if name!=mnemonic: raise ValueError('opcode/mnemonic mismatch')
                if mode in ('ia','ix'):
                    size=2 if suffix=='b' else 3 if suffix=='w' else raw[i+1][0]-address if i+1<len(raw) else 0
                    if size not in (2,3): raise ValueError('unknown immediate boundary')
                else: size=LEN[mode]
                if i+1<len(raw) and raw[i+1][0]>address and raw[i+1][0]<address+size:
                    raise ValueError('overlapping instruction annotation')
                decoded=decode(rom,address,address+size,boundary=size)
                records[address]=[size,filename,line_no]
            except ValueError as e:
                issues.append({'address':address,'source':filename,'line':line_no,'reason':str(e)})
    if not records:raise ValueError("No ROM-matching instruction boundaries found")
    edges=[]
    for address,record in sorted(records.items()):
        row=decode(rom,address,address+record[0],boundary=record[0])
        if row['target'] is not None:
            edges.append([address,row['target'],row['mnemonic']])
    verified_dispatch=[]
    for address,name in sites:
        if address not in records:continue
        row=decode(rom,address,address+records[address][0],boundary=records[address][0])
        if row['mode']!='absix':continue
        table=(address&0xff0000)|int.from_bytes(rom[pc(address)+1:pc(address)+3],'little')
        labels[name]=table
        tokens=table_rows.get(name,[])
        stride=4 if len(tokens)>1 and tokens[1].startswith('$') else 2
        targets=[];flags=[];valid=bool(tokens) and len(tokens)%(stride//2)==0
        for i in range(0,len(tokens),stride//2):
            symbol=tokens[i];expected=labels.get(symbol)
            if expected is None or expected>>16!=address>>16:valid=False;break
            offset=pc(table)+i*2
            if offset+stride>len(rom):valid=False;break
            actual=int.from_bytes(rom[offset:offset+2],'little')|(address&0xff0000)
            if actual!=expected:valid=False;break
            targets.append(actual)
            if stride==4:
                value=int(tokens[i+1][1:],16)
                if value!=int.from_bytes(rom[offset+2:offset+4],'little'):valid=False;break
                flags.append(value)
        if valid:verified_dispatch.append({'site':address,'table':table,'name':name,'stride':stride,'targets':targets,'flags':flags})
    ram={}
    for filename in ('ram.asm','mmio.asm'):
        path=Path(asm_dir)/filename
        if path.exists():
            source_hashes[filename]=hashlib.sha256(path.read_bytes()).hexdigest()
            for name,value in re.findall(r'^\s*([\w.]+)\s*=\s*\$([\da-fA-F]+)\s*(?:;.*)?$',path.read_text(),re.M):
                ram[name]=int(value,16)
    result={'schema':1,'rom_sha256':hashlib.sha256(rom).hexdigest(),'source_sha256':source_hashes,
            'instructions':{f'{at:06X}':v for at,v in sorted(records.items())},'symbols':labels,
            'edges':edges,'ram_symbols':ram,'issues':issues,'verified_dispatch':verified_dispatch,
            'scope':'Structural boundaries/references only. No assembly source or ROM bytes. Opcode checks do not prove operand text or function boundaries.'}
    payload=json.dumps(result,separators=(',',':'),sort_keys=True).encode()
    Path(output).parent.mkdir(parents=True,exist_ok=True)
    Path(output).write_bytes(gzip.compress(payload,mtime=0) if str(output).endswith('.gz') else payload)
    return {'instructions':len(records),'symbols':len(labels),'edges':len(edges),'issues':len(issues),'dispatch_tables':len(verified_dispatch),'sha256':result['rom_sha256']}

class Workbench:
    def __init__(self,rom,index=None,catalog=None):
        self.rom=rom; self.index=index or {}; self.catalog=catalog or {}
        if self.index and self.index.get('rom_sha256')!=hashlib.sha256(rom).hexdigest():
            raise ValueError('ROM/index SHA256 mismatch; regenerate the index for this ROM before analysis')
        self.functions=sorted(self.catalog.get('functions',[]),key=lambda f:f['address'])
        self.starts=[f['address'] for f in self.functions]
        self.symbols=self.index.get('symbols',{}) | {f['name']:f['address'] for f in self.functions}
        self.names={}
        for name,at in self.symbols.items(): self.names.setdefault(at,[]).append(name)
    def locate(self,query):
        if query in self.symbols: return self.symbols[query]
        try: return number(query)
        except ValueError:
            matches={a for n,a in self.symbols.items() if query.lower() in n.lower()}
            if len(matches)!=1: raise ValueError(f'Query has {len(matches)} matches; use search or an exact symbol/address')
            return matches.pop()
    def containing(self,address):
        i=bisect.bisect_right(self.starts,address)-1
        if i>=0 and address<self.functions[i]['end_address']:return self.functions[i]
        return None
    def data_region(self,address):
        for region in self.catalog.get('data_regions',[]):
            if (region['bank']<<16)|region['start'] <= address < (region['bank']<<16)+region['end']: return region
        return None
    def report(self,query,end=None,mx=None,limit=80):
        if not 1<=limit<=10000:raise ValueError("instruction limit must be 1..10000")
        address=self.locate(query); function=self.containing(address)
        end=end or (function['end_address'] if function else address+64)
        if end<=address or end-address>65536: raise ValueError('Invalid analysis span (maximum one bank)')
        width=tuple(int(v) for v in mx.split(',')) if mx else (None,None)
        if mx and (len(width)!=2 or any(v not in (0,1) for v in width)):raise ValueError('--mx must be M,X bits: 0,0 or 1,1 etc.')
        result={'query':query,'start':address,'end':end,'structural_span':function,'instructions':[],
                'incoming':[e for e in self.index.get('edges',[]) if e[1]==address],
                'dispatch':[],'warnings':[],'tables':[],'outgoing':[]}
        for row in self.catalog.get('dispatch',[]):
            parts=row['spec'].split();at=(row['bank']<<16)|int(parts[1],16)
            if address<=at<end: result['dispatch'].append(row)
        for row in self.index.get('verified_dispatch',[]):
            if address<=row['site']<end:result['dispatch'].append({'bank':row['site']>>16,'spec':f"ROM-verified table {row['name']} at {row['table']:06X}; {len(row['targets'])} targets, stride={row['stride']}; index bounds not proven",'contract':row})
        if function:result['warnings'].append('Catalog span is a structural entry interval, not proof of a complete routine or exit M/X contract.')
        at=address
        while at<end and len(result['instructions'])<limit:
            if self.data_region(at):result['warnings'].append(f'DATA boundary at {at:06X}; use table command, not code decoding.');break
            boundary=self.index.get('instructions',{}).get(f'{at:06X}')
            if self.index and boundary is None:
                result['warnings'].append(f'No verified instruction boundary at {at:06X}; stopped.');break
            try: row=decode(self.rom,at,end,width,boundary[0] if boundary else None)
            except ValueError as e:result['warnings'].append(str(e));break
            if boundary:row['source']={'file':boundary[1],'line':boundary[2]}
            row['symbols']=self.names.get(at,[])
            if row['target'] is not None:
                result['outgoing'].append({'site':at,'address':row['target'],'kind':row['mnemonic'],'names':self.names.get(row['target'],[])})
            result['instructions'].append(row)
            name,mode=row['mnemonic'],row['mode']
            if name in ('REP','SEP'):
                flags=self.rom[pc(at)+1];w=list(width)
                for i,bit in enumerate((0x20,0x10)):
                    if flags&bit:w[i]=int(name=='SEP')
                width=tuple(w)
            if name in ('JSR','JSL','PLP','RTI','XCE'):
                width=(None,None)
                result['warnings'].append(f'{at:06X} {name}: M/X not assumed to survive; next variable length needs boundary evidence.')
            if name in ('PLB','PLD','TCD','MVN','MVP'):
                result['warnings'].append(f'{at:06X} {name}: DBR/direct-page context changes; short memory addresses are not resolved as ROM tables.')
            if mode=='long' and name not in ('JSL','JML') or mode=='longx':
                value=int.from_bytes(self.rom[pc(at)+1:pc(at)+4],'little')
                try: pc(value);result['tables'].append({'instruction':at,'address':value,'indexed':mode=='longx','symbol':self.names.get(value,[])})
                except ValueError: pass
            if mode in ('absi','absix','absil'):
                result['warnings'].append(f'{at:06X}: indirect control flow; target set requires a reviewed dispatch contract or RAM state.')
            # Linear listing is not symbolic execution and does not infer joins.
            if mode in ('rel','rell') and name!='PER': width=(None,None)
            at+=row['size']
        if at<end and len(result['instructions'])>=limit: result['warnings'].append(f'Listing limited to {limit} instructions.')
        result['warnings']=list(dict.fromkeys(result['warnings']))
        return result

def native_evidence(root,start,end):
    matches=[]
    # Source mentions identify leads, not verified implementation coverage.
    for path in sorted((Path(root)/'src/core').glob('*.[ch]*')):
        for line_no,line in enumerate(path.read_text().splitlines(),1):
            addresses=re.findall(r'\b([89A-Fa-f][\da-fA-F]):([\da-fA-F]{4})\b|\b(?:CODE_|DATA_)([\da-fA-F]{6})\b',line)
            if any(start<=int((bank+word) if bank else full,16)<end for bank,word,full in addresses):
                matches.append({'file':path.relative_to(root).as_posix(),'line':line_no,'text':line.strip()})
    return matches

def render(report,root=ROOT):
    lines=[f"# ROM {report['start']:06X}..{report['end']:06X}",'',
           'Static reading only; no CPU/PPU execution. Bytes and operands come from the current ROM.','']
    if report['structural_span']:
        f=report['structural_span'];lines.append(f"Catalog entry: {f['name']} — entry M/X hint `{f.get('entry_mx')}`; not an exit proof.\n")
    lines+=['```text']
    for row in report['instructions']:
        labels=' '.join(row['symbols'])
        lines.append(f"{row['address']:06X}  {row['bytes']:<11} {row['mnemonic']} {row['operand']:<20} {labels}")
    lines+=['```','', '## References','']
    for source,dest,kind in report['incoming'][:30]: lines.append(f'- {kind} from `{source:06X}` to `{dest:06X}`')
    for row in report['outgoing']:
        lines.append(f"- {row['kind']} at `{row['site']:06X}` to `{row['address']:06X}` {' / '.join(row['names'])}")
    for row in report['dispatch']: lines.append(f"- Indirect contract (metadata): `{row['spec']}`")
    for row in report['tables']:lines.append(f"- Long operand `{row['address']:06X}` at `{row['instruction']:06X}`; indexed={row['indexed']}. Size/payload type still require review.")
    lines+=['','## Native source leads (not coverage proof)','']
    for row in native_evidence(root,report['start'],report['end']):
        lines.append(f"- `{row['file']}:{row['line']}` — {row['text']}")
    lines+=['','## Unknowns and obligations','']+[f'- {w}' for w in report['warnings']]
    lines+=['- Short memory operands require DBR/direct-page context; a source name or address mention alone does not establish a physical memory address.', '- Preserve word wrap, carry/sign flags and memory offsets; verify the C++ with bounded original-routine oracles and input replays.']
    return '\n'.join(lines)+'\n'

def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--rom',default=str(ROOT/'rom/dkc3_ptbr.sfc'))
    parser.add_argument('--index',default=str(ROOT/'tools/reference/rom-analysis-index.json.gz'))
    parser.add_argument('--catalog',default=str(ROOT/'tools/reference/recomp-catalog.json'))
    sub=parser.add_subparsers(dest='command',required=True)
    p=sub.add_parser('index');p.add_argument('--asm-dir',required=True);p.add_argument('--output',required=True)
    p=sub.add_parser('search');p.add_argument('query');p.add_argument('--limit',type=int,default=40)
    p=sub.add_parser('report');p.add_argument('query');p.add_argument('--end',type=number);p.add_argument('--mx');p.add_argument('--limit',type=int,default=80);p.add_argument('--json',action='store_true');p.add_argument('--output')
    p=sub.add_parser('table');p.add_argument('address',type=number);p.add_argument('--count',type=int,default=16);p.add_argument('--width',type=int,choices=(1,2,3),default=2)
    p=sub.add_parser('packet');p.add_argument('topic',choices=('controller','steel','koin','tidal'));p.add_argument('--output',required=True)
    args=parser.parse_args(argv)
    try:
        rom=read_rom(args.rom)
        if args.command=='index':print(json.dumps(import_index(args.asm_dir,rom,args.output),indent=2));return 0
        catalog=read_json(args.catalog);index=read_json(args.index) if Path(args.index).exists() else None
        work=Workbench(rom,index,catalog)
        if args.command=='search':
            query=args.query.lower();matches=[]
            try:at=number(query)
            except ValueError:at=None
            for name,address in sorted(work.symbols.items(),key=lambda x:(x[1],x[0])):
                if query in name.lower() or address==at:matches.append((name,address))
            if at is not None and work.containing(at):
                f=work.containing(at);matches.append((f['name']+' (containing interval)',f['address']))
            for name,address in matches[:args.limit]:print(f'{address:06X} {name}')
            print(f'{len(matches)} matches; limit={args.limit}')
        elif args.command=='report':
            report=work.report(args.query,args.end,args.mx,args.limit)
            text=json.dumps(report,indent=2) if args.json else render(report)
            if args.output:Path(args.output).write_text(text,encoding='utf-8')
            else:print(text,end='')
        elif args.command=='table':
            if not 1<=args.count<=4096:raise ValueError('count must be 1..4096')
            off=pc(args.address);size=args.count*args.width
            if off+size>len(rom) or (args.address&65535)+size>65536:raise ValueError('table exceeds ROM/bank')
            for i in range(args.count):
                value=int.from_bytes(rom[off+i*args.width:off+(i+1)*args.width],'little')
                print(f'{args.address+i*args.width:06X} {value:0{args.width*2}X}')
        elif args.command=='packet':
            topics={'controller':[(0xb89f3a,0xb89f50),(0xb8c6de,0xb8c786),(0xb9eea0,0xb9ef0e),(0xb9f060,0xb9f084)],
                    'steel':[(0xbed960,0xbed975),(0xb9ec09,0xb9ec3c),(0xb9f54f,0xb9f55e)],
                    'koin':[(0xb6a6c4,0xb6a718),(0xb6a742,0xb6a78e)],
                    'tidal':[(0xbb8ff9,0xbb9020),(0xbba0d1,0xbba100)]}
            text=f'# Port packet: {args.topic}\n\nROM SHA256: `{hashlib.sha256(rom).hexdigest()}`\n\n'
            text+='This is an analysis packet, not generated game code or a complete translation.\n\n'
            for start,end in topics[args.topic]:text+=render(work.report(f'{start:06X}',end))+'\n'
            if args.topic=='tidal':
                for name in ('TIDAL-SPAWN-AUDIT.txt','TIDAL-BONUS1-SPAWN-AUDIT.txt','TIDAL-BONUS2-SPAWN-AUDIT.txt'):
                    path=ROOT/'docs'/name
                    if path.exists():text+='## '+name+'\n\n```text\n'+path.read_text(encoding='utf-8')+'```\n\n'
            Path(args.output).write_text(text,encoding='utf-8')
        return 0
    except (ValueError,OSError,KeyError,json.JSONDecodeError) as error:
        print(f'ROM_WORKBENCH_ERROR: {error}',file=sys.stderr);return 2
if __name__=='__main__':sys.exit(main())
