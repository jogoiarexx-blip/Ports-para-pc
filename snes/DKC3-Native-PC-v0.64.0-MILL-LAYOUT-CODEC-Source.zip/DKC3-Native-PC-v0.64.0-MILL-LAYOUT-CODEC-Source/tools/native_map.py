#!/usr/bin/env python3
"""ROM Trace -> Native Map: ROM-bound structural analysis and optional trace evidence.

No CPU/PPU execution. A catalog interval is not a proven complete function.
Uses rom_workbench's validated index and decoder, never a second disassembler.
"""
from __future__ import annotations
import argparse, csv, hashlib, json, sys
from pathlib import Path
import rom_workbench as w

ROOT = w.ROOT
DEFAULT_ROUTINES = ['B89F3A', 'B8C6DE', 'B9EEA0', 'B9F060', 'queue_sound_effect', 'upload_spc_engine']
LEVELS = {'lakeside': ('Lakeside Limbo', 0x25, 'lakeside-limbo', 'LAKESIDE'),
          'doorstop': ('Doorstop Dash', 0x28, 'doorstop', 'DOORSTOP'),
          'tidal': ('Tidal Trouble', 0x27, 'tidal-trouble', 'TIDAL')}
CATEGORIES = [
    ('audio', ('audio', 'sound', 'song', 'spc', 'sample'), 'native_audio'),
    ('hardware_glue', ('dma', 'hdma', 'nmi', 'irq', 'vram_payload'), 'context_review'),
    ('asset_loading', ('decompress', 'load_asset', 'graphics_data', 'palette_data'), 'asset_export'),
    ('rendering', ('camera', 'scroll', 'palette', 'render', 'tilemap', 'sprite_graphic'), 'native_renderer'),
    ('level_logic', ('level', 'bonus', 'checkpoint', 'door', 'lever'), 'native_logic'),
    ('gameplay', ('kong', 'motion', 'collision', 'barrel', 'koin', 'terrain', 'rope', 'enemy'), 'native_logic')]
MEMORY_MODES = {'dp','dpx','dpy','idx','idy','ind','dil','dily','sr','sriy','abs','absx','absy','long','longx','absi','absix','absil'}
CONTROL = {'JSR','JSL','JMP','JML'}


def integer(value, label, maximum=0xffffff):
    if type(value) is not int or not 0 <= value <= maximum:
        raise ValueError(f'{label} must be an integer in 0..{maximum}')
    return value


def space(address):
    bank, low = address >> 16, address & 0xffff
    if bank in (0x7e,0x7f) or (bank & 0x40 == 0 and low < 0x2000):return 'RAM'
    if bank & 0x40 == 0 and 0x2000 <= low < 0x6000:return 'IO'
    try:w.pc(address);return 'ROM'
    except ValueError:return 'UNKNOWN'


def classify(names, leads, references):
    text = ' '.join(names + [row['text'] for row in leads]).lower()
    for category, tokens, destination in CATEGORIES:
        matches = [token for token in tokens if token in text]
        if matches:
            return {'category':category, 'suggested_destination':destination, 'evidence_level':'heuristic',
                    'evidence':[f'name/source token: {token}' for token in matches], 'runtime_behavior_proven':False}
    io = [ref for ref in references if ref['space']=='IO']
    if io:
        return {'category':'hardware_glue','suggested_destination':'context_review','evidence_level':'heuristic',
                'evidence':[f"explicit long IO operand at {ref['instruction']:06X}" for ref in io], 'runtime_behavior_proven':False}
    return {'category':'unknown','suggested_destination':'unknown','evidence_level':'unknown',
            'evidence':['No reviewed semantic contract; anonymous addresses do not identify behavior.'], 'runtime_behavior_proven':False}


class Analyzer:
    def __init__(self, rom, index, catalog, root=ROOT):
        self.sha = hashlib.sha256(rom).hexdigest()
        for label, metadata in (('index',index),('catalog',catalog)):
            if metadata.get('rom_sha256') != self.sha:
                raise ValueError(f'ROM/{label} SHA256 mismatch or missing SHA256; regenerate reviewed metadata before analysis')
        self.work = w.Workbench(rom,index,catalog)
        self.root = Path(root)
        self.ram_names = {}
        for name, address in index.get('ram_symbols',{}).items():self.ram_names.setdefault(address,[]).append(name)
        self.native_leads = w.native_evidence(self.root,0,0x1000000)

    def leads(self, start, end):
        # Reuse the workbench's source scanner; mentions are never coverage evidence.
        result=[]
        for row in self.native_leads:
            matches=w.re.findall(r'\b([89A-Fa-f][\da-fA-F]):([\da-fA-F]{4})\b|\b(?:CODE_|DATA_)([\da-fA-F]{6})\b',row['text'])
            if any(start<=int(bank+low if bank else full,16)<end for bank,low,full in matches):result.append(row)
        return result

    def memory(self, row):
        name, mode = row['mnemonic'], row['mode']
        if mode not in MEMORY_MODES or (name in CONTROL and mode in ('abs','long')) or name=='PEA':return None
        value = int.from_bytes(self.work.rom[w.pc(row['address'])+1:w.pc(row['address'])+row['size']],'little')
        access = 'write' if name in ('STA','STX','STY','STZ') else 'read_write' if name in ('INC','DEC','ASL','LSR','ROL','ROR','TRB','TSB') else 'pointer' if name in CONTROL else 'read'
        result = {'instruction':row['address'],'mnemonic':name,'mode':mode,'operand_value':value,'access':access,
                  'space':'UNKNOWN','candidate_space':None,'address':None,'effective_address':None,
                  'symbol_candidates':self.ram_names.get(value,[]),'evidence':'ROM_operand','unknown':None}
        if mode in ('long','longx'):
            result.update(space=space(value),address=value,candidate_space=space(value))
            result['effective_address']=value if mode=='long' else None
            if mode=='longx':result['unknown']='Base address only; runtime X and word wrapping require review.'
        elif mode in ('abs','absx','absy'):
            result['candidate_space']='IO' if 0x2000<=value<0x6000 else 'RAM' if value<0x2000 else None
            result['unknown']='DBR is unknown; short operand is not a resolved physical address. Indexed modes also require X/Y.'
        elif mode in ('sr','sriy'):
            result['unknown']='Stack register S and indirect data-bank context are unknown.'
        elif mode in ('absi','absix','absil'):
            result['unknown']='Indirect control pointer; pointer bank, runtime index/state and target set require review.'
        else:
            result['unknown']='Runtime direct-page D is unknown; indirect/indexed operands also require pointer and register context.'
        return result

    def level(self, key):
        if key not in LEVELS:raise ValueError(f'Unknown level {key}; choose lakeside, doorstop, tidal')
        title, level_id, folder, audit_prefix = LEVELS[key]
        rom=self.work.rom
        def word(address):
            off=w.pc(address)
            if (address&0xffff)==0xffff:raise ValueError('Word crosses bank boundary')
            return int.from_bytes(rom[off:off+2],'little')
        header_pointer=0xfd0000+level_id*2
        header=0xfd0000|word(header_pointer)
        off=w.pc(header); kind=rom[off]
        if kind not in (1,2):raise ValueError(f'Unsupported level header type {kind} for {title}')
        shared_offset=5 if kind==2 else 3
        shared=word(header+shared_offset);submap=rom[off+shared_offset+2]
        point_offset=18 if kind==2 else 16
        result={'key':key,'name':title,'level_id':level_id,'header_pointer':header_pointer,'header_address':header,
                'header_type':kind,'song_id':rom[off+2],'shared_data':shared,'submap':submap,
                'start_point':{'x':word(header+point_offset)-256,'y':word(header+point_offset+2)-256},
                'evidence':'ROM_fields_with_RomData_layout','provenance':['src/core/RomData.cpp: RomLevelRuntime::load and readLevelPlacementStream'],
                'native_level_file':f'assets/levels/{folder}/{folder}.level',
                'unknowns':{'audio':'Song ID is metadata. Native synthetic audio is not a translated SPC/song engine.',
                            'effects':'Original per-level scanline, DMA/HDMA, palette and transition timing require reference observations.',
                            'dispatch':'Descriptors and placements do not prove object handler implementations or complete level behavior.'}}
        metadata=self.root/'assets/levels/original_metadata'/('doorstop-dash.original.txt' if key=='doorstop' else folder+'.original.txt')
        if metadata.exists():
            result['original_metadata_file']=metadata.relative_to(self.root).as_posix()
            result['original_metadata_lead'] = metadata.read_text(encoding='utf-8').splitlines()
        stream_pointer=0xfe0000+level_id*2; stream=0xfe0000|word(stream_pointer)
        if stream&0xffff<0x400:raise ValueError('Placement stream points inside the pointer table')
        result.update(placement_pointer=stream_pointer,placement_address=stream,placements=[])
        audit_path=self.root/'docs'/f'{audit_prefix}-SPAWN-AUDIT.txt'
        audit={}
        if audit_path.exists():
            with audit_path.open(encoding='utf-8') as file:
                next(file,None)
                header=next(csv.reader(file))
                for values in csv.reader(file):
                    # Audit text leaves commas in the limitation field unquoted. Keep
                    # the schema extensible by deriving how many columns follow limitation.
                    if len(values)>len(header):
                        tail=len(header)-10
                        values=values[:9]+[','.join(values[9:-tail])]+values[-tail:]
                    if len(values)!=len(header):continue
                    row=dict(zip(header,values));audit[int(row['index'])]=row
            result['placement_audit_lead']=audit_path.relative_to(self.root).as_posix()
        at=stream
        while at&0xffff<=0xfffe:
            parameter=word(at)
            if parameter==0:
                result['placement_end']=at+2
                break
            if at&0xffff>0xfff8:raise ValueError(f'Truncated placement record for {title}')
            x,y,placement_type=word(at+2),word(at+4),word(at+6)
            table=0xff0040+placement_type
            if table>0xfffffe:raise ValueError('Placement descriptor pointer outside FF bank')
            descriptor=word(table)
            p={'index':len(result['placements']),'address':at,'parameter':parameter,'x':x,'y':y,'type':placement_type,
               'descriptor_pointer':table,'descriptor':descriptor,'descriptor_address':0xff0000|descriptor,
               'port_status':'UNKNOWN','sprite_id':None,'evidence':'ROM_placement_record',
               'unknown':'Spawn-script execution, conditional branches and object handler semantics require review.'}
            row=audit.get(p['index'])
            if row and all(int(row[field],0)==p[field] for field in ('parameter','x','y','type','descriptor')):
                p.update(sprite_id=int(row['sprite_id'],0),port_status='PARTIAL' if row['status'] in ('PARTIAL','SUPPORTED') else 'UNKNOWN',
                         audit_lead=row,audit_evidence='Matching raw fields; sprite/behavior/status are prior audit claims, not re-proven by indexing.')
            result['placements'].append(p);at+=8
        else:raise ValueError(f'Missing/truncated placement terminator for {title}')
        return result

    def trace(self, path):
        summary={'file':str(path),'frames':0,'native_calls':0,'reference_calls':0,'instruction_events':0,
                 'semantic_calls':[],'observed_references':[],'metrics_last':{},'rom_sha256_claim':None,
                 'evidence_limit':'Trace producer claims provenance. Native semantic events are not original instruction execution; no call-stack edges are inferred from ordering.'}
        previous=-1
        def instruction(pc,opcode,bank):
            integer(pc,'trace pc');integer(opcode,'trace opcode',255)
            if bank is not None and integer(bank,'trace bank',255)!=pc>>16:raise ValueError('Trace bank does not match pc')
            if self.work.rom[w.pc(pc)]!=opcode:raise ValueError(f'Trace opcode mismatch against ROM at {pc:06X}')
        with Path(path).open() as file:
            for line_no,line in enumerate(file,1):
                if not line.strip():continue
                try:frame=json.loads(line)
                except json.JSONDecodeError as error:raise ValueError(f'{path}:{line_no}: invalid trace JSON: {error}')
                if not isinstance(frame,dict) or frame.get('schema')!='dkc3.trace.v1':raise ValueError('Unsupported trace schema; expected dkc3.trace.v1')
                frame_id=integer(frame.get('frame'),'trace frame',2**63-1)
                if frame_id<=previous:raise ValueError('Trace frames must be strictly increasing')
                previous=frame_id
                integer(frame.get('input'),'trace input',2**32-1)
                if not isinstance(frame.get('state'),dict) or not isinstance(frame.get('state_hash'),str):raise ValueError('Trace state/state_hash are required')
                if not isinstance(frame.get('metrics'),dict):raise ValueError('Trace metrics object is required')
                for field in ('calls','events'):
                    if not isinstance(frame.get(field),list):raise ValueError(f'Trace {field} array is required')
                if 'rom_sha256' in frame:
                    if frame['rom_sha256']!=self.sha:raise ValueError('Trace ROM SHA256 mismatch')
                    summary['rom_sha256_claim']=frame['rom_sha256']
                summary['frames']+=1;summary['metrics_last']=frame['metrics']
                for call in frame['calls']:
                    if not isinstance(call,dict) or call.get('kind') not in ('native','reference') or not isinstance(call.get('function'),str):raise ValueError('Invalid trace call kind/function')
                    for field in ('pc','opcode','bank','rom_reads'):
                        if field not in call:raise ValueError(f'Trace call {field} is required')
                    if call['kind']=='native' and any(call[field] is not None for field in ('pc','opcode','bank')):raise ValueError('native semantic calls must have null pc/opcode/bank')
                    if call['pc'] is None:
                        if call['opcode'] is not None or call['bank'] is not None:raise ValueError('Trace opcode/bank require an observed pc')
                    else:instruction(call['pc'],call['opcode'],call['bank']);summary['instruction_events']+=1
                    if not isinstance(call['rom_reads'],list):raise ValueError('Trace rom_reads must be an array')
                    summary[call['kind']+'_calls']+=1
                    summary['semantic_calls'].append({'frame':frame_id,**call})
                    for read in call['rom_reads']:
                        address=read if type(read) is int else read.get('address') if isinstance(read,dict) else None
                        integer(address,'trace ROM read address');w.pc(address)
                        summary['observed_references'].append({'frame':frame_id,'function':call['function'],'kind':call['kind'],'space':'ROM','address':address,'access':'read','pc':call['pc'],'opcode':call['opcode'],'evidence':'observed_instruction' if call['pc'] is not None else 'observed_semantic'})
                for event in frame['events']:
                    if not isinstance(event,dict) or not isinstance(event.get('type'),str):raise ValueError('Trace event type is required')
                    if event['type']!='instruction_reference':continue
                    instruction(event.get('pc'),event.get('opcode'),event.get('bank'))
                    address=integer(event.get('address'),'trace reference address')
                    if event.get('space') not in ('ROM','RAM','IO') or space(address)!=event['space']:raise ValueError('Trace reference address/space mismatch')
                    if event.get('access') not in ('read','write','read_write','execute'):raise ValueError('Invalid trace reference access')
                    summary['instruction_events']+=1
                    summary['observed_references'].append({'frame':frame_id,**event,'evidence':'observed_instruction'})
        return summary

    def build(self, routines=None, levels=None, depth=1, max_routines=256, traces=()):
        if not 0<=depth<=8 or not 1<=max_routines<=2048:raise ValueError('depth must be 0..8 and max-routines 1..2048')
        routines=DEFAULT_ROUTINES if routines is None else routines
        levels=['lakeside','doorstop'] if levels is None else levels
        graph={'nodes':[],'edges':[]};nodes={};edges=set()
        def node(identifier,node_type,**data):
            if identifier not in nodes:nodes[identifier]={'id':identifier,'type':node_type,**data}
            elif node_type=='routine_span':nodes[identifier].update(type=node_type,**data)
            return identifier
        def edge(source,target,kind,evidence,**data):
            key=(source,target,kind,evidence,json.dumps(data,sort_keys=True))
            if key not in edges:edges.add(key);graph['edges'].append({'source':source,'target':target,'kind':kind,'evidence':evidence,**data})
        def rom_node(address,kind='memory'):
            return node(f'{kind}:{address:06X}',kind,address=address,space=space(address),names=self.work.names.get(address,[]))
        def bank_node(address):return node(f'bank:{address>>16:02X}','bank',bank=address>>16)
        selected=[];seen=set();queue=[];truncated=False
        for query in routines:
            if isinstance(query,(list,tuple)):start=self.work.locate(str(query[0]));end=w.number(str(query[1]))
            else:start=self.work.locate(str(query));end=None
            queue.append((start,end,0))
        while queue:
            start,end,hop=queue.pop(0)
            function=self.work.containing(start)
            if end is None:end=function['end_address'] if function else min(start+64,(start&0xff0000)+0x10000)
            key=(start,end)
            if key in seen:continue
            if len(selected)>=max_routines:truncated=True;break
            seen.add(key)
            report=self.work.report(f'{start:06X}',end,limit=10000)
            names=self.work.names.get(start,[]) or [f'ROM_{start:06X}']
            leads=self.leads(start,end)
            refs=[ref for row in report['instructions'] if (ref:=self.memory(row)) is not None]
            contracts=[{**row['contract'],'index_bounds_proven':False} for row in report['dispatch'] if 'contract' in row]
            routine={'start':start,'end':end,'names':names,'structural_span':report['structural_span'],
                     'complete_function_proven':False,'instruction_count':len(report['instructions']),
                     'classification':classify(names,leads,refs),'native_source_leads':leads,
                     'memory_references':refs,'dispatch_tables':contracts,'control_references':report['outgoing'],
                     'table_candidates':report['tables'],'warnings':report['warnings']}
            selected.append(routine)
            source=node(f'routine:{start:06X}..{end:06X}','routine_span',start=start,end=end,names=names,complete_function_proven=False)
            entry=node(f'routine:{start:06X}','routine_target',start=start,names=names,complete_function_proven=False)
            edge(entry,source,'bounded_span_definition','structural')
            edge(source,bank_node(start),'in_bank','structural')
            for lead in leads:
                target=node(f"native:{lead['file']}:{lead['line']}",'native_source',**lead)
                edge(source,target,'source_mention','source_lead')
            for ref in refs:
                if ref['address'] is None:
                    target=node(f"unknown:{ref['instruction']:06X}",'unresolved_memory',**ref)
                else:
                    target=rom_node(ref['address'])
                    edge(target,bank_node(ref['address']),'address_bank','ROM_operand')
                edge(source,target,ref['access'],'ROM_operand',site=ref['instruction'],effective_address_known=ref['effective_address'] is not None)
            for control in report['outgoing']:
                target=node(f"routine:{control['address']:06X}",'routine_target',start=control['address'],names=control['names'],complete_function_proven=False)
                edge(source,target,control['kind'],'structural',site=control['site'])
                if hop<depth and control['kind'] in ('JSR','JSL','JMP','JML'):queue.append((control['address'],None,hop+1))
            for table in contracts:
                target=rom_node(table['table'],'dispatch_table')
                edge(source,target,'dispatch_table','ROM_verified_table',site=table['site'],index_bounds_proven=False)
                for address in table['targets']:
                    destination=node(f'routine:{address:06X}','routine_target',start=address,names=self.work.names.get(address,[]),complete_function_proven=False)
                    edge(target,destination,'dispatch_target','ROM_verified_table')
                    if hop<depth:queue.append((address,None,hop+1))
        level_maps=[self.level(key) for key in levels]
        for level in level_maps:
            source=node('level:'+level['key'],'level',name=level['name'],level_id=level['level_id'])
            edge(source,rom_node(level['header_address'],'level_header'),'metadata','ROM_fields')
            edge(source,node('native-file:'+level['native_level_file'],'native_level_file',file=level['native_level_file']),'native_level_lead','source_lead')
            edge(source,node(f"shared-data:{level['shared_data']:04X}",'shared_data_metadata',value=level['shared_data'],physical_address=None),'scenario_metadata','ROM_fields')
            for api in ('RomLevelRuntime::load','decodeRomPlacements'):
                path=self.root/'src/core/RomData.cpp'
                if path.exists():
                    for line_no,line in enumerate(path.read_text().splitlines(),1):
                        if api+'(' in line and (line.startswith('bool ') or line.startswith('static bool ')):
                            target=node(f'native:src/core/RomData.cpp:{line_no}','native_source',file='src/core/RomData.cpp',line=line_no,text=line.strip())
                            edge(source,target,'loader_layout_lead','source_lead')
            edge(source,rom_node(level['placement_address'],'placement_stream'),'placements','ROM_fields')
            edge(source,node(f"song:{level['song_id']:02X}",'audio_unknown',song_id=level['song_id'],translation_proven=False),'song_metadata','ROM_fields')
            edge(source,node('effects:'+level['key'],'effects_unknown',reason=level['unknowns']['effects']),'effect_contract','unknown')
            for placement in level['placements']:
                target=node(f"placement:{level['key']}:{placement['index']}",'placement',**placement)
                edge(source,target,'contains_placement','ROM_fields')
                descriptor=rom_node(placement['descriptor_address'],'spawn_descriptor')
                edge(target,descriptor,'descriptor','ROM_fields')
        trace_maps=[self.trace(path) for path in traces]
        for i,trace in enumerate(trace_maps):
            source=node(f'trace:{i}','trace',file=trace['file'],frames=trace['frames'])
            for call in trace['semantic_calls']:
                target=node(f"call:{call['kind']}:{call['function']}",'semantic_routine',function=call['function'],kind=call['kind'])
                edge(source,target,'observed_call','observed_semantic',frame=call['frame'])
                if call['pc'] is not None:
                    observed=node(f"instruction:{call['pc']:06X}",'observed_instruction',pc=call['pc'],opcode=call['opcode'])
                    edge(target,observed,'observed_pc','observed_instruction',frame=call['frame'])
                    edge(observed,bank_node(call['pc']),'in_bank','observed_instruction')
            for ref in trace['observed_references']:
                origin=node(f"instruction:{ref['pc']:06X}",'observed_instruction',pc=ref['pc'],opcode=ref['opcode']) if ref['pc'] is not None else node(f"call:{ref['kind']}:{ref['function']}",'semantic_routine',function=ref['function'],kind=ref['kind'])
                edge(origin,rom_node(ref['address']),ref['access'],ref['evidence'],frame=ref['frame'])
        graph['nodes']=list(nodes.values())
        return {'schema':'dkc3.native-map.v1','rom_sha256':self.sha,
                'provenance':{'index_rom_sha256':self.work.index['rom_sha256'],'catalog_rom_sha256':self.work.catalog['rom_sha256'],
                              'catalog_upstream':self.work.catalog.get('upstream'),'catalog_commit':self.work.catalog.get('commit'),
                              'source_sha256':self.work.index.get('source_sha256',{}),'method':'rom_workbench.Workbench.report and decode'},
                'scope':'No CPU/PPU execution. Static bounded spans and source mentions are leads, not complete functions or runtime coverage. External DKC3Recomp reference executable is not supplied in this ZIP.',
                'coverage':{'original_runtime_fraction':None,'translated_function_fraction':None,'native_map_complete':False},
                'selection':{'depth':depth,'max_routines':max_routines,'truncated':truncated,'pending_spans':len(queue)},
                'routines':selected,'levels':level_maps,'traces':trace_maps,'graph':graph,
                'unknowns':['Runtime DBR/direct-page/register/flags contracts and indirect targets are not inferred.',
                            'Level association is metadata/audit/source evidence, not proof that every selected routine executes in that level.',
                            'Original instruction coverage and full function boundaries remain unknown.',
                            'Native audio and level effects need observed original reference contracts.']}


def render_markdown(result):
    lines=['# ROM Trace → Native Map','',f"ROM SHA256: `{result['rom_sha256']}`",'',result['scope'],'',
           f"Selected {len(result['routines'])} bounded routine spans; {len(result['graph']['nodes'])} graph nodes and {len(result['graph']['edges'])} edges. Original runtime coverage: unknown.",
           f"Traversal depth {result['selection']['depth']}; routine limit {result['selection']['max_routines']}; truncated: {result['selection']['truncated']}.",'',
           '## Dependency graph excerpt','', 'The JSON contains the complete selected graph. This excerpt combines control, bank and table dependencies; it does not show an observed call stack.','', '```mermaid','flowchart TD']
    chosen=[];known={}
    if result['routines']:
        first=f"routine:{result['routines'][0]['start']:06X}..{result['routines'][0]['end']:06X}"
        chosen=[edge for edge in result['graph']['edges'] if edge['source']==first and edge['kind'] in ('in_bank','dispatch_table')][:3]
        for table in [edge['target'] for edge in chosen if edge['kind']=='dispatch_table']:
            children=[edge for edge in result['graph']['edges'] if edge['source']==table and edge['kind']=='dispatch_target'][:3]
            chosen+=children
            for child in children:
                definitions=[edge for edge in result['graph']['edges'] if edge['source']==child['target'] and edge['kind']=='bounded_span_definition'][:1]
                chosen += definitions
                for definition in definitions:
                    chosen += [edge for edge in result['graph']['edges'] if edge['source']==definition['target'] and edge['kind']=='in_bank'][:1]
        if not any(edge['kind']=='dispatch_table' for edge in chosen):
            calls=[edge for edge in result['graph']['edges'] if edge['source']==first and edge['kind'] in ('JSR','JSL')][:2]
            chosen+=calls
            for child in calls:
                definitions=[edge for edge in result['graph']['edges'] if edge['source']==child['target'] and edge['kind']=='bounded_span_definition'][:1]
                chosen += definitions
                for definition in definitions:
                    chosen += [edge for edge in result['graph']['edges'] if edge['source']==definition['target'] and edge['kind']=='in_bank'][:1]
    node_lookup={node['id']:node for node in result['graph']['nodes']}
    for edge in chosen:
        for identifier in (edge['source'],edge['target']):
            if identifier not in known:
                alias=f'n{len(known)}';known[identifier]=alias
                data=node_lookup[identifier]
                label=(data.get('names') or [identifier])[0]
                if data['type']=='routine_span':label+=f" {data['start']:06X}..{data['end']:06X}"
                elif data['type']=='routine_target':label+=' entry'
                label=label.replace('"',"'").replace('\n',' ')
                lines.append(f'  {alias}["{label}"]')
        lines.append(f"  {known[edge['source']]} -->|{edge['kind']}| {known[edge['target']]}")
    lines+=['```','','## Routine spans','','| Span | Name | Heuristic category | Destination | Instructions | Native leads |','|---|---|---|---|---:|---:|']
    for routine in result['routines']:
        c=routine['classification'];name=' / '.join(routine['names'][:3])
        lines.append(f"| `{routine['start']:06X}..{routine['end']:06X}` | {name} | {c['category']} | {c['suggested_destination']} | {routine['instruction_count']} | {len(routine['native_source_leads'])} |")
    for level in result['levels']:
        statuses={status:sum(p['port_status']==status for p in level['placements']) for status in ('PARTIAL','UNKNOWN')}
        lines+=['',f"## {level['name']}",'',f"Level `{level['level_id']:02X}`, header `{level['header_address']:06X}`, shared data `{level['shared_data']:04X}`, submap {level['submap']}, song `{level['song_id']:02X}`.",'',
                f"Placement stream `{level['placement_address']:06X}..{level['placement_end']:06X}`: {len(level['placements'])} records; prior matching audit claims PARTIAL {statuses['PARTIAL']}, UNKNOWN {statuses['UNKNOWN']}. Indexing adds no SUPPORTED objects.",
                '',f"Native level lead: `{level['native_level_file']}`.",'', '| # | Original address | Type | Descriptor | XY | Audit status | Sprite lead |','|---:|---|---|---|---|---|---|']
        for p in level['placements']:
            sprite='unknown' if p['sprite_id'] is None else f"{p['sprite_id']:04X}"
            lines.append(f"| {p['index']} | `{p['address']:06X}` | `{p['type']:04X}` | `{p['descriptor_address']:06X}` | {p['x']}, {p['y']} | {p['port_status']} | {sprite} |")
        lines+=['']+[f'- {value}' for value in level['unknowns'].values()]
    lines+=['','## Evidence and unresolved contracts','']
    for routine in result['routines']:
        lines+=[f"### {routine['start']:06X}..{routine['end']:06X}",'', 'Classification evidence: '+ '; '.join(routine['classification']['evidence']), '']
        for lead in routine['native_source_leads']:lines.append(f"- Source lead `{lead['file']}:{lead['line']}`: {lead['text']}")
        for ref in routine['memory_references']:
            value=f"{ref['address']:06X}" if ref['address'] is not None else f"operand {ref['operand_value']:X}"
            lines.append(f"- `{ref['instruction']:06X}` {ref['access']} {ref['space']} `{value}` ({ref['mode']}); {ref['unknown'] or 'explicit operand, not proof of runtime access.'}")
        lines += [f'- {warning}' for warning in routine['warnings']]
        for table in routine['dispatch_tables']:lines.append(f"- ROM-verified dispatch `{table['table']:06X}`, stride {table['stride']}, {len(table['targets'])} targets; index bounds and dynamic selection unknown.")
        lines+=['']
    if result['traces']:
        lines+=['## Imported traces','']
        for trace in result['traces']:
            lines.append(f"- `{trace['file']}`: {trace['frames']} frames, {trace['native_calls']} native calls, {trace['reference_calls']} reference calls, {trace['instruction_events']} claimed instruction observations validated against ROM opcodes. {trace['evidence_limit']}")
    lines+=['','## Unknowns','']+[f'- {unknown}' for unknown in result['unknowns']]
    return '\n'.join(lines)+'\n'


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--rom',default=str(ROOT/'rom/dkc3_ptbr.sfc'))
    parser.add_argument('--index',default=str(ROOT/'tools/reference/rom-analysis-index.json.gz'))
    parser.add_argument('--catalog',default=str(ROOT/'tools/reference/recomp-catalog.json'))
    parser.add_argument('--root',type=Path,default=ROOT)
    parser.add_argument('--routine',action='append',help='Exact symbol/address; repeat to select entry intervals')
    parser.add_argument('--span',action='append',default=[],help='Explicit START..END interval, e.g. B8:9F3A..B8:9F50')
    parser.add_argument('--level',action='append',choices=tuple(LEVELS),help='Default lakeside and doorstop; tidal optional')
    parser.add_argument('--depth',type=int,default=1)
    parser.add_argument('--max-routines',type=int,default=256)
    parser.add_argument('--trace',type=Path,action='append',default=[])
    parser.add_argument('--output-json',type=Path)
    parser.add_argument('--output-markdown',type=Path)
    parser.add_argument('--json',action='store_true',help='Print JSON instead of Markdown when no output file is given')
    args=parser.parse_args(argv)
    try:
        spans=[]
        for span in args.span:
            fields=span.split('..')
            if len(fields)!=2:raise ValueError('--span requires START..END')
            spans.append(fields)
        routines=(args.routine or [])+spans if args.routine or spans else None
        analyzer=Analyzer(w.read_rom(args.rom),w.read_json(args.index),w.read_json(args.catalog),args.root)
        result=analyzer.build(routines,args.level,args.depth,args.max_routines,args.trace)
        encoded=json.dumps(result,indent=2,sort_keys=True)+'\n'
        markdown=render_markdown(result)
        for path,content in ((args.output_json,encoded),(args.output_markdown,markdown)):
            if path:path.parent.mkdir(parents=True,exist_ok=True);path.write_text(content,encoding='utf-8')
        if not args.output_json and not args.output_markdown:print(encoded if args.json else markdown,end='')
        else:print(json.dumps({'routine_spans':len(result['routines']),'levels':len(result['levels']),'nodes':len(result['graph']['nodes']),'edges':len(result['graph']['edges']),'truncated':result['selection']['truncated'],'rom_sha256':result['rom_sha256']}))
        return 0
    except (ValueError,OSError,KeyError,TypeError,json.JSONDecodeError) as error:
        print(f'NATIVE_MAP_ERROR: {error}',file=sys.stderr);return 2

if __name__=='__main__':sys.exit(main())
