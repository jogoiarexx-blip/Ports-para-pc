#!/usr/bin/env python3
"""Run a separately built upstream reference; never links its runtime into native."""
import argparse,hashlib,os,pathlib,subprocess,sys
p=argparse.ArgumentParser();p.add_argument("executable");p.add_argument("rom");p.add_argument("replay");p.add_argument("frames",type=int);p.add_argument("output_dir");p.add_argument("--savestate");a=p.parse_args()
try:
 rom=pathlib.Path(a.rom).resolve();exe=pathlib.Path(a.executable).resolve();replay=pathlib.Path(a.replay).resolve()
 if a.frames<=0: raise ValueError("frames must be positive")
 if hashlib.sha256(rom.read_bytes()).hexdigest()!="2277a2d8dddb01fe5cb0ae9a0fa225d42b3a11adccaeafa18e3c339b3794a32b": raise ValueError("reference ROM hash mismatch")
 if not replay.is_file() or not exe.is_file(): raise ValueError("missing executable or replay")
 dest=pathlib.Path(a.output_dir).resolve();dest.mkdir(parents=True,exist_ok=True)
 env=os.environ.copy();env["SNESRECOMP_INPUT_PLAY"]=str(replay)
 for region in ["WRAM","VRAM","OAM"]: env["DKC3_"+region+"_OUTPUT"]=str(dest/(region.lower()+".bin"))
 if a.savestate: env["DKC3_SAVESTATE_INPUT"]=str(pathlib.Path(a.savestate).resolve())
 with (dest/"reference.log").open("w") as log: result=subprocess.run([str(exe),str(rom),str(a.frames)],env=env,stdout=log,stderr=subprocess.STDOUT)
 sys.exit(result.returncode)
except (OSError,ValueError) as e: print(e,file=sys.stderr);sys.exit(2)
