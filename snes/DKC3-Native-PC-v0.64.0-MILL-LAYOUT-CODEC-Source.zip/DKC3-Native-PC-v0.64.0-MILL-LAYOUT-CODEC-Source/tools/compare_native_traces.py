#!/usr/bin/env python3
"""Stream validated frame traces and report the first chronological divergence.

Exit 0: identical state/input sequences; 1: state or length difference;
2: invalid traces, mismatched inputs, or output failure. No emulator is involved.
"""
import argparse
from collections import deque
import json
import math
from pathlib import Path
import re
import sys

SCHEMA = 'dkc3.trace.v1'
PROVENANCE = {'native-runtime', 'reference-runtime', 'snes-reference'}
EVIDENCE_LIMIT = ('Native-to-native comparison establishes replay repeatability only. '
                  'Reference provenance labels are supplied by the producer; this tool '
                  'does not authenticate SNES execution or establish a confirmed cause.')


def state_hash(state):
    """FNV-1a64 of sorted UTF8 key\0value\0; null uses <unavailable>."""
    value = 0xcbf29ce484222325
    for key in sorted(state):
        raw = (key + '\0' + ('<unavailable>' if state[key] is None else state[key]) + '\0').encode('utf-8')
        for byte in raw:
            value = ((value ^ byte) * 0x100000001b3) & 0xffffffffffffffff
    return f'{value:016x}'


def _integer(value, name, minimum=0, maximum=None):
    if type(value) is not int or value < minimum or (maximum is not None and value > maximum):
        raise ValueError(f'{name} must be an integer in range')


def _state(state):
    if not isinstance(state, dict) or not state:
        raise ValueError('state must be a nonempty flattened object')
    for key, value in state.items():
        if not isinstance(key, str) or not key or '\0' in key:
            raise ValueError('invalid state key')
        if value is None:
            continue
        if not isinstance(value, str) or '\0' in value:
            raise ValueError(f'state {key} must be a canonical string or null')
        if value.lower() in {'nan', '+nan', '-nan', 'inf', '+inf', '-inf', 'infinity', '+infinity', '-infinity', 'unknown'}:
            raise ValueError(f'state {key} has nonfinite or unknown value; unavailable is null')
        if value.startswith(('f32:', 'f64:')):
            width = 8 if value.startswith('f32:') else 16
            if not re.fullmatch(r'[0-9a-f]{' + str(width) + '}', value[4:]):
                raise ValueError(f'state {key} has malformed float bits')
            bits = int(value[4:], 16)
            exponent_mask = 0x7f800000 if width == 8 else 0x7ff0000000000000
            if bits & exponent_mask == exponent_mask:
                raise ValueError(f'state {key} has nonfinite float bits')


def _validate(record, expected_frame, provenance):
    if not isinstance(record, dict) or record.get('schema') != SCHEMA:
        raise ValueError(f'schema must be {SCHEMA}')
    required = {'frame', 'input', 'state', 'state_hash', 'calls', 'events', 'metrics', 'provenance'}
    missing = required - record.keys()
    if missing:
        raise ValueError('missing fields: ' + ', '.join(sorted(missing)))
    _integer(record['frame'], 'frame')
    if record['frame'] != expected_frame:
        raise ValueError(f'frames must start at 0 and be consecutive; expected frame {expected_frame}')
    _integer(record['input'], 'input', maximum=0xffffffff)
    if record['provenance'] not in PROVENANCE:
        raise ValueError('unknown provenance')
    if provenance is not None and record['provenance'] != provenance:
        raise ValueError('provenance changed within trace')
    _state(record['state'])
    if not isinstance(record['state_hash'], str) or not re.fullmatch('[0-9a-f]{16}', record['state_hash']):
        raise ValueError('state_hash must be 16 lowercase hexadecimal digits')
    if record['state_hash'] != state_hash(record['state']):
        raise ValueError('state_hash does not match canonical state')
    if not isinstance(record['calls'], list) or not isinstance(record['events'], list) or not isinstance(record['metrics'], dict):
        raise ValueError('calls/events must be lists and metrics must be an object')
    for call in record['calls']:
        if not isinstance(call, dict) or not isinstance(call.get('function'), str) or not call['function']:
            raise ValueError('call requires a function name')
        if call.get('kind') not in {'native', 'reference'}:
            raise ValueError('call kind must be native or reference')
        for key, limit in [('pc', 0xffffff), ('opcode', 0xff), ('bank', 0xff)]:
            if key not in call:
                raise ValueError(f'call requires {key}, null when unavailable')
            if call[key] is not None:
                _integer(call[key], 'call ' + key, maximum=limit)
            if call['kind'] == 'native' and call[key] is not None:
                raise ValueError(f'native call {key} must be null; source_pc is an annotation')
        if 'source_pc' in call and call['source_pc'] is not None:
            _integer(call['source_pc'], 'call source_pc', maximum=0xffffff)
        if not isinstance(call.get('rom_reads'), list) or any(not isinstance(x, dict) for x in call['rom_reads']):
            raise ValueError('call rom_reads must be a list of objects')
    for event in record['events']:
        if not isinstance(event, dict) or not isinstance(event.get('type'), str) or not event['type']:
            raise ValueError('event requires a type')
    return record


def _pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f'duplicate JSON key {key}')
        result[key] = value
    return result


def _constant(value):
    raise ValueError('nonfinite JSON constant ' + value)


def _float(value):
    parsed = float(value)
    if not math.isfinite(parsed):
        raise ValueError('nonfinite JSON number')
    return parsed


def _unicode(value):
    if isinstance(value, str):
        value.encode('utf-8')
    elif isinstance(value, dict):
        for key, item in value.items():
            _unicode(key)
            _unicode(item)
    elif isinstance(value, list):
        for item in value:
            _unicode(item)


def read_trace(path, side):
    """Yield validated records without retaining the trace in memory."""
    count = 0
    provenance = None
    try:
        with open(path, encoding='utf-8', errors='strict') as stream:
            for line_number, line in enumerate(stream, 1):
                try:
                    if not line.strip():
                        raise ValueError('blank trace record')
                    record = json.loads(line, object_pairs_hook=_pairs, parse_constant=_constant, parse_float=_float)
                    _unicode(record)
                    _validate(record, count, provenance)
                except (ValueError, TypeError, UnicodeError, RecursionError) as error:
                    raise ValueError(f'{side} line {line_number}: {error}') from error
                provenance = record['provenance']
                count += 1
                yield record
        if not count:
            raise ValueError(f'{side}: empty trace')
    except (OSError, UnicodeError) as error:
        raise ValueError(f'{side}: {error}') from error


def _context(history):
    return [{'frame': x['frame'], 'calls': x['calls'], 'events': x['events'],
             'metrics': x['metrics']} for x in history]


def _object_keys(fields):
    result = set()
    for key in fields:
        match = re.match(r'((?:objects?|entities)\.[^.]+\.\d+)(?:\.|$)', key)
        if match:
            result.add(match.group(1))
            continue
        match = re.match(r'((?:objects?|entities)\.[^.]+)(?:\.|$)', key)
        if match:
            result.add(match.group(1))
        match = re.match(r'((?:objects?|entities)\[[^]]+\])(?:\.|$)', key)
        if match:
            result.add(match.group(1))
    return sorted(result)


def _details(first, histories):
    context = {side: _context(history) for side, history in histories.items()}
    fields = [v['field'] for v in first.get('variables', [])]
    object_keys = _object_keys(fields)
    calls = [(side, frame['frame'], call) for side, frames in context.items()
             for frame in frames for call in frame['calls']]
    candidates = sorted({call['function'] for _, _, call in calls})
    reads = []
    for side, number, call in calls:
        for read in call['rom_reads']:
            keys = read.get('state_keys', call.get('state_keys', []))
            if not isinstance(keys, list):
                keys = []
            object_key = read.get('object_key', call.get('object_key'))
            related = bool(set(fields).intersection(k for k in keys if isinstance(k, str))) or object_key in object_keys
            if 'object_id' in read:
                related = related or any(k in object_keys for k in (f'objects.{read["object_id"]}', f'objects[{read["object_id"]}]'))
            reads.append({'side': side, 'frame': number, 'function': call['function'],
                          'read': read, 'correlation': 'explicit_state_or_object_key' if related else 'unknown'})
    first.update(context=context, candidate_functions=candidates, affected_object_keys=object_keys,
                 rom_reads=reads, related_rom_reads=[r for r in reads if r['correlation'] != 'unknown'],
                 cause_confirmed=False)
    return first


def compare(left_path, right_path, context=3):
    """Scan chronologically; later invalid data overrides an earlier difference."""
    _integer(context, 'context', minimum=1, maximum=1000)
    streams = {'left': iter(read_trace(left_path, 'left')), 'right': iter(read_trace(right_path, 'right'))}
    histories = {side: deque(maxlen=context) for side in streams}
    counts = {'left': 0, 'right': 0, 'aligned': 0}
    provenance = {}
    first = None
    number = 0
    while True:
        records = {side: next(stream, None) for side, stream in streams.items()}
        if all(record is None for record in records.values()):
            break
        for side, record in records.items():
            if record is not None:
                counts[side] += 1
                provenance[side] = record['provenance']
                histories[side].append(record)
        left, right = records['left'], records['right']
        if left is not None and right is not None:
            counts['aligned'] += 1
            if left['input'] != right['input']:
                raise ValueError(f'input mismatch at frame {number}: {left["input"]} / {right["input"]}')
            # Compare actual fields even when hashes agree (collisions and null sentinel).
            if first is None:
                variables = [{'field': key,
                              'left': {'present': key in left['state'], 'value': left['state'].get(key)},
                              'right': {'present': key in right['state'], 'value': right['state'].get(key)}}
                             for key in sorted(left['state'].keys() | right['state'].keys())
                             if (key in left['state']) != (key in right['state']) or left['state'].get(key) != right['state'].get(key)]
                if variables:
                    first = _details({'kind': 'state', 'frame': number, 'input': left['input'],
                                      'variables': variables, 'state_hashes': {'left': left['state_hash'], 'right': right['state_hash']}}, histories)
        elif first is None:
            first = _details({'kind': 'missing_frame', 'frame': number,
                              'missing_side': 'left' if left is None else 'right', 'variables': []}, histories)
        number += 1
    return {'schema': 'dkc3.trace-comparison.v1', 'status': 'different' if first else 'match',
            'paths': {'left': str(left_path), 'right': str(right_path)}, 'frames': counts,
            'provenance': provenance, 'first_difference': first,
            'comparison_scope': 'all_state_fields_and_inputs', 'snes_reference_proven': False,
            'evidence_limit': EVIDENCE_LIMIT}


def render_markdown(report):
    lines = ['# Trace comparison', '', f'Status: **{report["status"]}**.', '',
             f'Validated frames: left {report["frames"]["left"]}, right {report["frames"]["right"]}; '
             f'aligned {report["frames"]["aligned"]}. All state fields and inputs compared.', '',
             report['evidence_limit'], '']
    first = report['first_difference']
    if first:
        lines += [f'First difference: frame **{first["frame"]}**, {first["kind"]}.', '']
        if first['kind'] == 'missing_frame':
            lines += [f'Missing frame on {first["missing_side"]}.', '']
        else:
            lines += ['| Field | Left | Right |', '| --- | --- | --- |']
            for variable in first['variables']:
                def display(side):
                    value = variable[side]
                    return json.dumps(value['value'], ensure_ascii=False) if value['present'] else '<missing>'
                cells = [variable['field'], display('left'), display('right')]
                lines.append('| ' + ' | '.join(c.replace('|', '\\|').replace('\n', '\\n') for c in cells) + ' |')
            lines.append('')
        lines += ['Candidate functions only; no confirmed cause: ' +
                  (', '.join(first['candidate_functions']) or 'none observed') + '.', '',
                  'Affected object keys: ' + (', '.join(first['affected_object_keys']) or 'none') + '.', '',
                  'Recent calls, events, metrics and ROM reads (unknown correlation remains unknown):', '',
                  '```json', json.dumps({key: first[key] for key in ('context', 'rom_reads', 'related_rom_reads')},
                                        ensure_ascii=False, indent=2, sort_keys=True), '```', '']
    return '\n'.join(lines)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('left')
    parser.add_argument('right')
    parser.add_argument('--context', type=int, default=3, help='recent frames including divergence (1..1000)')
    parser.add_argument('--json', type=Path, metavar='PATH', help='write machine-readable report')
    parser.add_argument('--markdown', type=Path, metavar='PATH', help='write full human-readable report')
    args = parser.parse_args(argv)
    try:
        report = compare(args.left, args.right, context=args.context)
        if args.json:
            args.json.write_text(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True) + '\n', encoding='utf-8')
        if args.markdown:
            args.markdown.write_text(render_markdown(report), encoding='utf-8')
        first = report['first_difference']
        if first:
            print(f'DIFFERENT frame={first["frame"]} kind={first["kind"]}')
            for variable in first['variables']:
                print(f'  {variable["field"]}: {json.dumps(variable["left"])} / {json.dumps(variable["right"])}')
            if first['kind'] == 'missing_frame':
                print(f'  missing side: {first["missing_side"]}')
            print('Candidate functions only: ' + (', '.join(first['candidate_functions']) or 'none observed'))
        else:
            print(f'MATCH {report["frames"]["aligned"]} frames; all state fields and inputs')
        print(EVIDENCE_LIMIT)
        return 1 if first else 0
    except (OSError, ValueError, TypeError) as error:
        print(f'INVALID: {error}', file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
