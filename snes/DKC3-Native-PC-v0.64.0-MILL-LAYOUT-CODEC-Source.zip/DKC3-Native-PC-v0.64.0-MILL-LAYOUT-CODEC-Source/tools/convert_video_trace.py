#!/usr/bin/env python3
"""Bounded offline captured-video adapter; never executes DMA/HDMA or reads ROM."""
import argparse
import json
import struct
from pathlib import Path

INPUT_SCHEMA = 'dkc3.video-transfer-trace.v1'
OUTPUT_SCHEMA = 'dkc3.native-video-operations.v1'
MAX_PAYLOAD = 65536
MAX_EVENTS = 4096


def integer(value, name, low=0, high=0x7fffffff):
    if type(value) is not int or not low <= value <= high:
        raise ValueError(f'{name} must be an integer in [{low}, {high}]')
    return value


def payload(event):
    encoded = event.get('payload_hex')
    if not isinstance(encoded, str) or not encoded or len(encoded) > MAX_PAYLOAD * 2 or len(encoded) % 2:
        raise ValueError('payload_hex must contain 1..65536 complete bytes')
    if any(c not in '0123456789abcdefABCDEF' for c in encoded):
        raise ValueError('payload_hex must be contiguous hex without separators')
    return bytes.fromhex(encoded)


def words(data):
    if len(data) % 2:
        raise ValueError('partial word payload unsupported')
    return list(struct.unpack('<' + 'H' * (len(data) // 2), data))


def colors(values):
    if not isinstance(values, list) or len(values) > 4096:
        raise ValueError('colors must be a bounded list')
    return [integer(v, 'color', 0, 0x7fff) for v in values]


def decode_tiles(data, bpp):
    if bpp not in (2, 4):
        raise ValueError('only explicit 2/4bpp SNES planar tiles supported')
    size = bpp * 8
    if not data or len(data) % size or len(data) // size > 1024:
        raise ValueError('tile payload must contain 1..1024 complete planar tiles')
    result = []
    for tile in range(0, len(data), size):
        for y in range(8):
            for x in range(8):
                result.append(sum(((data[tile + (plane // 2) * 16 + y * 2 + plane % 2] >> (7-x)) & 1) << plane for plane in range(bpp)))
    return result


def layer(value):
    return integer(value, 'layer', 0, 2)


def tilemap_args(event, data):
    w = integer(event.get('width'), 'width', 1, 1024)
    h = integer(event.get('height'), 'height', 1, 1024)
    entries = words(data)
    if len(entries) != w * h:
        raise ValueError('tilemap payload length does not match rectangle')
    x = integer(event.get('x'), 'x', 0, 1023)
    y = integer(event.get('y'), 'y', 0, 1023)
    mw = integer(event.get('map_width', 1024), 'map_width', 1, 1024)
    mh = integer(event.get('map_height', 1024), 'map_height', 1, 1024)
    if x + w > mw or y + h > mh:
        raise ValueError('tilemap rectangle exceeds destination bounds')
    return {'layer': layer(event.get('layer')), 'x': x, 'y': y,
            'width': w, 'height': h, 'entries': entries}


def tiles_args(event, data):
    bpp = integer(event.get('bpp'), 'bpp', 2, 4)
    li = layer(event.get('layer'))
    if bpp != (2 if li == 2 else 4):
        raise ValueError('bpp does not match native Mode 1 layer')
    if event.get('format') != 'snes-planar':
        raise ValueError('tiles require explicit snes-planar format')
    first = integer(event.get('first_tile'), 'first_tile', 0, 1023)
    pixels = decode_tiles(data, bpp)
    if first + len(pixels) // 64 > 1024:
        raise ValueError('tile destination exceeds 1024 tiles')
    return {'layer': li, 'firstTile': first, 'pixels': pixels}


def semantic(event):
    op = event.get('operation')
    if op == 'setPalette':
        vals = colors(event.get('colors'))
        first = integer(event.get('first'), 'first', 0, 255)
        if not vals or first + len(vals) > 256:
            raise ValueError('palette destination range invalid')
        return op, {'first': first, 'colors': vals}
    if op == 'updateTilemap':
        if event.get('layout') != 'row-major':
            raise ValueError('semantic tilemap requires explicit row-major layout')
        return op, tilemap_args(event, payload(event))
    if op == 'updateTiles':
        return op, tiles_args(event, payload(event))
    if op == 'updateGradient':
        return op, {'fixedColorRows': colors(event.get('fixed_color_rows'))}
    if op == 'updateScanlineOffsets':
        rows = event.get('rows')
        if not isinstance(rows, list) or len(rows) > 4096:
            raise ValueError('scanline rows must be a bounded list')
        converted = []
        for row in rows:
            if not isinstance(row, dict):
                raise ValueError('scanline row must contain x/y')
            converted.append({'x': integer(row.get('x'), 'x', -0x80000000),
                              'y': integer(row.get('y'), 'y', -0x80000000)})
        return op, {'layer': layer(event.get('layer')), 'rows': converted}
    raise ValueError('unsupported semantic operation')


def dma(event):
    if event.get('direction') != 'a_to_b' or event.get('source_step') != 'increment':
        raise ValueError('only default incrementing A-to-B DMA supported')
    if event.get('display_phase') not in ('vblank', 'forced_blank'):
        raise ValueError('DMA requires captured vblank/forced_blank phase')
    if event.get('payload_order') != 'bus':
        raise ValueError('DMA payload must be captured in bus-write order')
    data = payload(event)
    if integer(event.get('transfer_size'), 'transfer_size', 1, MAX_PAYLOAD) != len(data):
        raise ValueError('capture length differs from full transfer size')
    port = integer(event.get('target'), 'target', 0x2100, 0x21ff)
    mode = integer(event.get('transfer_mode'), 'transfer_mode', 0, 7)
    if port == 0x2122 and mode == 0:
        if event.get('cgram_latch') != 'low':
            raise ValueError('CGRAM initial low-byte latch must be captured')
        first = integer(event.get('cgram_start_color'), 'cgram_start_color', 0, 255)
        vals = [v & 0x7fff for v in words(data)]
        if first + len(vals) > 256:
            raise ValueError('CGRAM wrapping transfer unsupported')
        return 'setPalette', {'first': first, 'colors': vals}
    if port != 0x2118 or mode != 1 or event.get('vmain') != 0x80:
        raise ValueError('unsupported DMA port/mode/VMAIN; only CGRAM mode0 or VRAM mode1 VMAIN=0x80')
    start = integer(event.get('vram_start_word'), 'vram_start_word', 0, 0x7fff)
    if start + len(data) // 2 > 0x8000 or len(data) % 2:
        raise ValueError('VRAM wrap/partial word unsupported')
    binding = event.get('binding')
    if not isinstance(binding, dict) or not isinstance(binding.get('asset'), str) or not binding['asset']:
        raise ValueError('VRAM transfer requires explicit named destination asset binding')
    base = integer(binding.get('base_word'), 'base_word', 0, 0x7fff)
    if binding.get('kind') == 'tilemap_page':
        args = tilemap_args(binding, data)
        if binding.get('layout') != 'snes-32x32-page':
            raise ValueError('raw tilemap conversion supports explicit SNES 32x32 page only')
        x, y, w, h = (args[k] for k in ('x', 'y', 'width', 'height'))
        if x+w > 32 or y+h > 32 or (h > 1 and (x != 0 or w != 32)):
            raise ValueError('DMA rectangle not contiguous inside 32x32 page')
        expected = base + y * 32 + x
        op = 'updateTilemap'
    elif binding.get('kind') == 'tiles':
        args = tiles_args(binding, data)
        expected = base + args['firstTile'] * binding['bpp'] * 4
        op = 'updateTiles'
    else:
        raise ValueError('unknown VRAM destination binding')
    if start != expected:
        raise ValueError('captured VRAM address does not match asset binding')
    return op, args


def convert_trace(document):
    if not isinstance(document, dict) or document.get('schema') != INPUT_SCHEMA:
        raise ValueError('unsupported input schema')
    events = document.get('events')
    if not isinstance(events, list) or len(events) > MAX_EVENTS:
        raise ValueError('events must be a list of at most 4096 captures')
    records = []
    for index, event in enumerate(events):
        record = {'eventIndex': index, 'status': 'unsupported'}
        try:
            if not isinstance(event, dict) or event.get('complete') is not True:
                raise ValueError('event must be an explicitly complete capture')
            kind = event.get('kind')
            if kind == 'dma':
                op, args = dma(event)
                evidence = 'captured_raw_dma'
            elif kind == 'semantic':
                op, args = semantic(event)
                evidence = 'resolved_semantic_adapter'
            else:
                raise ValueError('raw HDMA/unknown event unsupported; resolved rows require kind=semantic')
            record.update(status='converted', operation=op, args=args, evidence=evidence)
        except (ValueError, TypeError, KeyError) as exc:
            record['reason'] = str(exc)
        records.append(record)
    count = sum(r['status'] == 'converted' for r in records)
    return {'schema': OUTPUT_SCHEMA, 'records': records, 'converted': count,
            'unsupported': len(records)-count, 'referenceExecutionVerified': False}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('capture', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args(argv)
    try:
        if args.capture.stat().st_size > 16 * 1024 * 1024:
            raise ValueError('capture exceeds 16 MiB input bound')
        result = convert_trace(json.loads(args.capture.read_text(encoding='utf-8')))
    except (OSError, ValueError) as exc:
        parser.error(str(exc))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    print(f"converted={result['converted']} unsupported={result['unsupported']}")
    return 2 if result['unsupported'] else 0


if __name__ == '__main__':
    raise SystemExit(main())
