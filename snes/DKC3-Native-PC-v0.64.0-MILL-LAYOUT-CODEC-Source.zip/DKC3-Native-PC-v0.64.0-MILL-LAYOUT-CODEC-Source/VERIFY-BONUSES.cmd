@echo off
setlocal
cd /d "%~dp0"
if not exist build-win\Release\dkc3_native_bonus_input_tests.exe (echo Execute BUILD-WINDOWS.cmd primeiro.& pause & exit /b 1)
build-win\Release\dkc3_native_bonus_input_tests.exe || exit /b 1
build-win\Release\dkc3_native_lakeside_combined_input_tests.exe || exit /b 1
build-win\Release\dkc3_native_booty_bird_tests.exe || exit /b 1
build-win\Release\dkc3_native_animal_runtime_tests.exe || exit /b 1
build-win\Release\dkc3_native_control_tests.exe || exit /b 1
build-win\Release\dkc3_native_koin_tests.exe || exit /b 1
build-win\Release\dkc3_native_steel_state_tests.exe || exit /b 1
build-win\Release\dkc3_native_steel_motion_tests.exe || exit /b 1
build-win\Release\dkc3_native_steel_water_tests.exe || exit /b 1
echo OK: replay ampliado com DK Coin, 50 estrelas, 15 bananas, Ellie/Bear Coin e saida, somente input.
echo Warp e bonus Tidal ainda nao cobertos.
pause
