@echo off
setlocal
cd /d "%~dp0"
set BAD=0
if not exist DKC3NativePC.exe (echo ERRO: DKC3NativePC.exe nao encontrado.& set BAD=1)
if not exist rom\dkc3_ptbr.sfc (echo ERRO: rom\dkc3_ptbr.sfc nao encontrada.& set BAD=1)
for %%D in (input tools src tests docs) do if exist "%%D" (echo ERRO: pasta de desenvolvimento presente no runtime: %%D& set BAD=1)
if exist assets\levels\original_metadata (echo ERRO: metadados de desenvolvimento presentes no runtime.& set BAD=1)
dir /S /B assets\*_preview.bmp >nul 2>nul && (echo ERRO: previews de desenvolvimento presentes no runtime.& set BAD=1)
if "%BAD%"=="1" exit /b 1
echo OK: runtime ROM-first limpo.
exit /b 0
