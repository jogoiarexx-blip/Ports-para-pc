@echo off
setlocal
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
cd /d "%~dp0"
where cmake >nul 2>nul || (echo ERRO: CMake nao encontrado.& pause & exit /b 1)
cmake -S . -B build-win -G "Visual Studio 17 2022" -A x64 || goto :err
cmake --build build-win --config Release || goto :err
if not exist assets\native\runtime.nassets build-win\Release\dkc3_extract_native.exe || goto :err
ctest --test-dir build-win -C Release --output-on-failure || goto :err
if exist bin rmdir /S /Q bin
mkdir bin
copy /Y build-win\Release\DKC3NativePC.exe bin\DKC3NativePC.exe >nul
copy /Y build-win\Release\dkc3_native_replay.exe bin\dkc3_native_replay.exe >nul
xcopy /E /I /Y assets bin\assets >nul
if exist bin\assets\levels\tidal-trouble\native\pages rmdir /S /Q bin\assets\levels\tidal-trouble\native\pages
if exist bin\assets\sprites\dkc3\import-preview.png del /Q bin\assets\sprites\dkc3\import-preview.png
for /R bin\assets %%F in (*_preview.bmp) do del /Q "%%F"
if exist bin\assets\levels\original_metadata rmdir /S /Q bin\assets\levels\original_metadata
copy /Y RUN-WINDOWS.cmd bin\RUN-WINDOWS.cmd >nul
copy /Y VERIFY-NATIVE-RUNTIME.cmd bin\VERIFY-NATIVE-RUNTIME.cmd >nul
copy /Y README.txt bin\README.txt >nul
copy /Y VERSION.txt bin\VERSION.txt >nul
copy /Y COMO-USAR-BARRIS.txt bin\COMO-USAR-BARRIS.txt >nul
copy /Y COMO-USAR-DK-COIN.txt bin\COMO-USAR-DK-COIN.txt >nul
copy /Y COMO-USAR-ELLIE.txt bin\COMO-USAR-ELLIE.txt >nul
copy /Y COMO-USAR-CAVERNA.txt bin\COMO-USAR-CAVERNA.txt >nul
copy /Y THIRD-PARTY-NOTICES.txt bin\THIRD-PARTY-NOTICES.txt >nul
call bin\VERIFY-NATIVE-RUNTIME.cmd || goto :err
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Compress-Archive -Path 'bin\*' -DestinationPath 'DKC3-Native-PC-v0.64.0-MILL-LAYOUT-CODEC-Portable-Windows-x64.zip' -Force" || goto :err
echo.
echo OK: bin\DKC3NativePC.exe
echo OK: DKC3-Native-PC-v0.64.0-MILL-LAYOUT-CODEC-Portable-Windows-x64.zip
pause
exit /b 0
:err
echo.
echo FALHA NO BUILD NATIVO.
pause
exit /b 1
