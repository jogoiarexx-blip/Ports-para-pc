#include "core/Game.h"
#include "core/NativeReplay.h"
#include "core/Bmp.h"
#include <array>
#include <iostream>
#include <vector>
#include <cmath>
using namespace dkc3;
#define CHECK(x) do {if(!(x)){std::cerr<<"LAKESIDE_ROUTE_FAIL line="<<__LINE__<<" "<<#x<<'\n';return 1;}}while(0)
int main(){
  for(const char* path:{"tests/replays/lakeside-both-bonuses-v054.txt","tests/replays/lakeside-bird-and-bonuses-v055.txt","tests/replays/lakeside-ellie-and-bonuses-v055.txt","tests/replays/lakeside-extended-v059.txt"}){
  NativeReplay replay;std::string error;
  CHECK(replay.load(path,error));
  Game game;CHECK(game.init("assets/levels/lakeside-limbo/lakeside-limbo.level"));
  std::array<int,2> maxima{},entries{},returns{};bool wasBonus=false;int lastRoom=0;
  const int initialLives=game.lives();bool ridingSnapshot=false;int ridingTicks=0;
  for(size_t frame=0;frame<replay.count();++frame){
    game.step(nativeInputFromSnes(replay.frame(frame)),1.f/60);
    CHECK(game.lives()==initialLives);
    ridingTicks=game.animal().mounted?ridingTicks+1:0;
    if(ridingTicks>=30&&!ridingSnapshot){std::vector<uint32_t> frame(256*224);game.render(frame.data(),256,224);CHECK(saveBmp32("docs/ellie-riding-v053.bmp",frame.data(),256,224));ridingSnapshot=true;}

    if(game.inBonus()){
      const int room=game.activeBonus();CHECK(room==1||room==2);lastRoom=room;
      if(!wasBonus)++entries[room-1];
      maxima[room-1]=std::max(maxima[room-1],game.bonusCollected());
    }else if(wasBonus)++returns[lastRoom-1];
    wasBonus=game.inBonus();
  }
  CHECK(maxima[0]==50&&maxima[1]==15);CHECK(entries[0]==1&&entries[1]==1&&returns[0]==1&&returns[1]==1);
  CHECK(game.bonusCoins()==2&&game.lakesideBonusMask()==3);
  CHECK(game.checkpointActivations()==1&&game.pendingLevel()=="doorstop");
  if(std::string(path).find("bird")!=std::string::npos){
    CHECK(game.kongMask()&8u);int birds=0;for(const auto& e:game.enemies())if(e.spriteId==0x434){++birds;CHECK(!e.active);}CHECK(birds==1);
  }
  if(std::string(path).find("ellie")!=std::string::npos||std::string(path).find("extended")!=std::string::npos){
    CHECK(ridingSnapshot&&game.animalMounts()>=1&&game.animalSignRewards()==1);
    CHECK(game.animalBoxes()[0].lifecycle.state==RomAnimalBoxState::Spent);
    CHECK(!game.animal().active&&!game.animal().mounted&&game.coins()==1);
  }
  if(std::string(path).find("extended")!=std::string::npos){CHECK(game.dkCoins()==1&&romKoinProgress(game.persistentState().koinFlags,0x25)==2);CHECK(game.teamBarrelRescues()>=1);}
  CHECK(game.romSpawnRuntime().records().size()==47);
  CHECK(game.player().nativeRopeGrabs>0);CHECK(game.player().nativeMotion.swimTerminalSpeed==288);
  std::vector<uint32_t> pixels(256*224);game.render(pixels.data(),256,224);
  CHECK(saveBmp32("docs/lakeside-both-bonuses-end-v051.bmp",pixels.data(),256,224));
  // A full second run checks determinism and already-awarded coin persistence.
  GamePersistentState paid;paid.bonusCoins=2;paid.lakesideBonusMask=3;
  const bool extended=std::string(path).find("extended")!=std::string::npos;
  if(extended){paid.dkCoins=1;CHECK(setRomKoinProgress(paid.koinFlags,0x25,2));}
  Game again;CHECK(again.init("assets/levels/lakeside-limbo/lakeside-limbo.level",&paid));
  for(size_t frame=0;frame<replay.count();++frame)again.step(nativeInputFromSnes(replay.frame(frame)),1.f/60);
  CHECK(again.bonusCoins()==2&&again.lakesideBonusMask()==3);
  if(extended)CHECK(again.dkCoins()==1&&romKoinProgress(again.persistentState().koinFlags,0x25)==2);
  CHECK(again.pendingLevel()==game.pendingLevel()&&again.lives()==game.lives());
  CHECK(std::fabs(again.player().pos.x-game.player().pos.x)<.001f&&std::fabs(again.player().pos.y-game.player().pos.y)<.001f);
  std::cout<<"LAKESIDE_BOTH_BONUSES_OK frames="<<replay.count()<<" stars=50 bananas=15 bonus_coins=2 checkpoint=1 exit=doorstop lives="<<game.lives()<<" animal_rewards="<<game.animalSignRewards()<<" dk_coins="<<game.dkCoins()<<" bear_coins="<<game.coins()<<" partner_rescues="<<game.teamBarrelRescues()<<" kong_mask="<<game.kongMask()<<" no position injection; Warp not covered\n";
  }
}
