#include "core/NativeScene.h"
#include "core/NativeSprite.h"
#include <array>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <limits>
#include <vector>
using namespace dkc3;
static int failures=0,checks=0;
#define CHECK(x) do { ++checks; if(!(x)){++failures;std::cerr<<"FAIL line "<<__LINE__<<": "<<#x<<'\n';} } while(0)
static uint32_t rgb(int r,int g=0,int b=0){auto c=[](int v){return (v<<3)|(v>>2);};return 0xff000000u|(c(r)<<16)|(c(g)<<8)|c(b);}
static NativeLayer layer(int index=0,uint8_t color=1){NativeLayer l;l.enabled=true;l.bpp=index==2?2:4;l.tiles.bpp=l.bpp;l.tiles.tileCount=1;l.tiles.pixels.assign(64,color);l.map.width=l.map.height=1;l.map.entries={0};return l;}
static NativeScene scene(){NativeScene s;s.palette.resize(256);s.palette[1]=31;s.palette[2]=31<<5;s.palette[3]=31<<10;s.tm=1;s.layers.push_back(layer());return s;}
static uint32_t pixel(const NativeScene&s,int x=0,int y=0){uint32_t p=0;renderNativeScene(s,&p,1,1,x,y);return p;}
static NativeSceneSprite sprite(uint32_t color=0xff00ff00,uint8_t priority=3){NativeSceneSprite o;o.sprite.width=o.sprite.height=1;o.sprite.bgra={color};o.priority=priority;return o;}
static void composition(){
  auto s=scene();CHECK(pixel(s)==rgb(31));s.layers[0].tiles.pixels.assign(64,0);CHECK(pixel(s)==rgb(0));
  s=scene();s.layers[0].enabled=false;CHECK(pixel(s)==rgb(0));s.layers[0].enabled=true;s.tm=0;CHECK(pixel(s)==rgb(0));
  s=scene();s.layers[0].tiles.pixels.assign(64,0);s.layers[0].tiles.pixels[15]=2;CHECK(pixel(s,-1,0)==rgb(0,31));
  s=scene();s.layers[0].tiles.pixels.assign(64,0);s.layers[0].tiles.pixels[8]=2;CHECK(pixel(s)==rgb(0,31)); // exported +1 row
  s.layers[0].map.entries[0]=0x4000;CHECK(pixel(s)==rgb(0));s.layers[0].tiles.pixels[15]=3;CHECK(pixel(s)==rgb(0,0,31));
  s.layers[0].map.entries[0]=0x8000;s.layers[0].tiles.pixels[48]=1;CHECK(pixel(s)==rgb(31));
  s=scene();s.layers.push_back(layer(1,2));s.tm=3;CHECK(pixel(s)==rgb(31));s.layers[1].map.entries[0]=0x2000;CHECK(pixel(s)==rgb(0,31));
  s.layers[0].map.entries[0]=0x2000;CHECK(pixel(s)==rgb(31));
  s=scene();s.layers[0].mainMask={2,1,{0,1}};uint32_t p[3]={};CHECK(renderNativeSceneChecked(s,p,3,1));CHECK(p[0]==rgb(0));CHECK(p[1]==rgb(31));CHECK(p[2]==rgb(0));
  s=scene();s.palette[1]=10;s.cgadsub=1;s.fixedColor=5;s.colorMathMask={2,1,{0,1}};CHECK(renderNativeSceneChecked(s,p,3,1));CHECK(p[0]==rgb(10));CHECK(p[1]==rgb(15));CHECK(p[2]==rgb(10));
  s=scene();s.layers.push_back(layer(1,2));s.ts=2;s.cgwsel=2;s.cgadsub=1;s.layers[1].subMask={2,1,{0,1}};CHECK(renderNativeSceneChecked(s,p,2,1));CHECK(p[0]==rgb(31));CHECK(p[1]==rgb(31,31));
  s=scene();s.brightness=0;CHECK(pixel(s)==0xff000000);
}
static void math(){
  auto s=scene();s.cgadsub=1;s.fixedColor=31;CHECK(pixel(s)==rgb(31));s.cgadsub=0x41;CHECK(pixel(s)==rgb(31));
  s.palette[1]=20;s.fixedColor=6;s.cgadsub=0x81;CHECK(pixel(s)==rgb(14));s.cgadsub=0xc1;CHECK(pixel(s)==rgb(7));s.fixedColor=30;CHECK(pixel(s)==rgb(0));
  s=scene();s.palette[1]=uint16_t(20|(12<<5)|(7<<10));s.fixedColor=uint16_t(8|(20<<5)|(14<<10));s.cgadsub=0x41;CHECK(pixel(s)==rgb(14,16,10));
  s=scene();s.palette[1]=10;s.fixedColor=6;s.cgadsub=0x41;s.cgwsel=2;CHECK(pixel(s)==rgb(16)); // empty subscreen: fixed fallback, no half
  s.layers.push_back(layer(1,2));s.palette[2]=20;s.ts=2;CHECK(pixel(s)==rgb(15));s.layers[1].enabled=false;CHECK(pixel(s)==rgb(16));
  s=scene();s.tm=0;s.cgadsub=0x20;s.fixedColor=3;CHECK(pixel(s)==rgb(3));
}
static void sprites(){
  NativeSprite sp;sp.width=sp.height=1;sp.bgra={0x80ff0000};uint32_t d=0xff0000ff;drawNativeSprite(sp,&d,1,1,0,0);CHECK(d==0xff80007f);
  CHECK(blendNativeSpritePixel(0x00ffffff,d)==d);CHECK(blendNativeSpritePixel(0xff123456,d)==0xff123456);CHECK(blendNativeSpritePixel(0x01ffffff,0xff000000)==0xff010101);
  sp.width=sp.height=2;sp.bgra={0xffff0000,0xff00ff00,0xff0000ff,0xffffffff};uint32_t p[4]{};drawNativeSprite(sp,p,2,2,0,0,true,true);CHECK(p[0]==0xffffffff&&p[1]==0xff0000ff&&p[2]==0xff00ff00&&p[3]==0xffff0000);
  sp.originX=sp.originY=1;drawNativeSprite(sp,p,2,2,1,1);CHECK(p[0]==0xffff0000);drawNativeSprite(sp,p,2,2,std::numeric_limits<int>::min(),0);CHECK(p[0]==0xffff0000);
  for(bool bg3:{false,true})for(int li=0;li<3;++li)for(bool high:{false,true})for(uint8_t priority=0;priority<4;++priority){auto s=scene();s.bg3Priority=bg3;s.layers.clear();for(int i=0;i<3;++i)s.layers.push_back(layer(i,i==li?1:0));s.layers[size_t(li)].map.entries[0]=high?0x2000:0;s.tm=uint8_t((1<<li)|0x10);s.sprites.push_back(sprite(0xff00ff00,priority));constexpr int bgNormal[2][3]={{6,5,1},{9,8,3}},bgSpecial[2][3]={{5,4,1},{8,7,10}},objNormal[4]={2,4,7,10},objSpecial[4]={2,3,6,9};int bz=bg3?bgSpecial[high][li]:bgNormal[high][li],oz=bg3?objSpecial[priority]:objNormal[priority];CHECK(pixel(s)==(oz>bz?rgb(0,31):rgb(31)));}
  auto s=scene();s.tm|=0x10;s.sprites.push_back(sprite(0x800000ff));CHECK(pixel(s)==0xff7f0080);s.sprites[0].enabled=false;CHECK(pixel(s)==rgb(31));s.sprites[0].enabled=true;s.sprites[0].mainMask={1,1,{0}};CHECK(pixel(s)==rgb(31));
  s=scene();s.tm=0x10;s.sprites.push_back(sprite());s.sprites[0].sprite=sp;s.sprites[0].x=s.sprites[0].y=1;s.sprites[0].flipX=s.sprites[0].flipY=true;CHECK(pixel(s)==0xffffffff);CHECK(pixel(s,1,1)==0xffff0000);
  s=scene();s.tm=0x10;s.sprites={sprite(0xffff0000,3),sprite(0xff00ff00,0)};CHECK(pixel(s)==rgb(31));s.sprites[1].priority=3;CHECK(pixel(s)==rgb(0,31));
  s=scene();s.tm=0x10;s.sprites={sprite(0xffff0000)};s.cgadsub=0x90;s.fixedColor=10;CHECK(pixel(s)==rgb(31));s.sprites[0].colorMath=true;CHECK(pixel(s)==rgb(21));
}
static void updates(){
  auto s=scene();std::array<uint16_t,1> green={uint16_t(31<<5)};CHECK(setPalette(s,1,green));CHECK(pixel(s)==rgb(0,31));CHECK(!setPalette(s,256,green));CHECK(!setPalette(s,0,std::array<uint16_t,1>{0x8000}));
  std::vector<uint8_t> blue(64,3);CHECK(updateTiles(s,0,0,blue));CHECK(pixel(s)==rgb(0,0,31));CHECK(!updateTiles(s,0,1,blue));blue[0]=16;CHECK(!updateTiles(s,0,0,blue));CHECK(!updateTiles(s,0,0,std::span<const uint8_t>(blue.data(),63)));
  CHECK(updateTilemap(s,0,0,0,1,1,std::array<uint16_t,1>{0x4000}));CHECK(!updateTilemap(s,0,1,0,1,1,std::array<uint16_t,1>{0}));CHECK(!updateTilemap(s,0,0,0,std::numeric_limits<int>::max(),1,std::array<uint16_t,1>{0}));
  CHECK(!setLayerScroll(s,1,0,0));CHECK(!setLayerParallax(s,1,0,0));CHECK(!updateScanlineOffsets(s,1,{}));
  s=scene();s.layers[0].tiles.pixels.assign(64,0);s.layers[0].tiles.pixels[10]=2;CHECK(setLayerScroll(s,0,1,0));CHECK(setLayerParallax(s,0,128,0));CHECK(pixel(s,2,100)==rgb(0,31));
  CHECK(updateScanlineOffsets(s,0,std::array<NativeScanlineOffset,1>{{{-1,0}}}));CHECK(pixel(s,4,100)==rgb(0,31));CHECK(updateScanlineOffsets(s,0,{}));CHECK(pixel(s,4,100)==rgb(0));
  s=scene();s.palette[1]=10;s.cgadsub=1;s.fixedColor=4;CHECK(updateGradient(s,std::array<uint16_t,2>{1,2}));uint32_t p[3];CHECK(renderNativeSceneChecked(s,p,1,3));CHECK(p[0]==rgb(11)&&p[1]==rgb(12)&&p[2]==rgb(14));CHECK(!updateGradient(s,std::array<uint16_t,1>{0xffff}));CHECK(updateGradient(s,{}));CHECK(pixel(s)==rgb(14));
  s=scene();std::string error;uint32_t d=0x12345678;s.mode=7;CHECK(!renderNativeSceneChecked(s,&d,1,1,0,0,&error));CHECK(d==0x12345678&&!error.empty());s=scene();s.layers[0].map.entries.clear();CHECK(!validateNativeScene(s));s=scene();s.layers[0].tiles.pixels[0]=16;CHECK(!validateNativeScene(s));s=scene();s.colorMathMask={2,2,{1}};CHECK(!validateNativeScene(s));s=scene();s.cgwsel=0x80;CHECK(!validateNativeScene(s));
}
static void files(){
  size_t assetIndex=0;constexpr uint64_t assetHashes[]={0x27ec6ec224a8886cull,0x87a9cca4d49dae00ull,0xbed80ea9cc2ec1f4ull,0x518b0ac426a29e44ull};
  for(const char* path:{"assets/levels/doorstop/native/doorstop.nscene","assets/levels/tidal-trouble/native/pages/page0/tidal-page0.nscene","assets/levels/tidal-trouble/native/pages/page1/tidal-page1.nscene","assets/levels/tidal-trouble/native/pages/page2/tidal-page2.nscene"}){NativeScene s;CHECK(loadNativeScene(path,s));std::vector<uint32_t> p(256*224);CHECK(renderNativeSceneChecked(s,p.data(),256,224));CHECK(hashFrame(p.data(),p.size())==assetHashes[assetIndex++]);std::cout<<path<<" hash="<<std::hex<<hashFrame(p.data(),p.size())<<std::dec<<'\n';}
  auto dir=std::filesystem::temp_directory_path()/"dkc3-native-renderer-fixtures";std::filesystem::create_directories(dir);
  auto malformed=[&](const std::string& text){std::ofstream(dir/"bad.nscene")<<text;NativeScene s=scene();CHECK(!loadNativeScene((dir/"bad.nscene").string(),s));CHECK(s.layers.empty());};
  malformed("NATIVE_SCENE nope\n");malformed("NATIVE_SCENE 1\nlayer broken\n");malformed("NATIVE_SCENE 1\ntm 256\n");malformed("NATIVE_SCENE 1\nbrightness 15 garbage\n");
  // Oversized tile header rejected before allocation; all fields little endian.
  const std::array<uint8_t,24> hugeTiles={'N','T','I','L',1,0,4,0,255,255,255,255,8,0,0,0,8,0,0,0,0,0,0,0};std::ofstream tile(dir/"huge.ntiles",std::ios::binary);tile.write((const char*)hugeTiles.data(),hugeTiles.size());tile.close();malformed("NATIVE_SCENE 1\nlayer bg1 4 1 1 0 0 1 huge.ntiles unused.nmap\n");
  std::ofstream(dir/"bad.nspr",std::ios::binary)<<"NSPR";NativeSprite sp;CHECK(!loadNativeSprite((dir/"bad.nspr").string(),sp));CHECK(!sp.valid());
  auto write=[&](const char* name,std::span<const uint8_t> bytes){std::ofstream f(dir/name,std::ios::binary);f.write((const char*)bytes.data(),std::streamsize(bytes.size()));};
  std::filesystem::copy_file("assets/levels/doorstop/native/bg1.ntiles",dir/"valid.ntiles",std::filesystem::copy_options::overwrite_existing);
  const std::array<uint8_t,20> hugeMap={'N','M','A','P',1,0,0,0,255,255,255,255,1,0,0,0,0,0,0,0};write("huge.nmap",hugeMap);malformed("NATIVE_SCENE 1\nlayer bg1 4 1 1 0 0 1 valid.ntiles huge.nmap\n");
  const std::array<uint8_t,8> hugePal={'N','P','A','L',1,0,1,1};write("huge.npal",hugePal);malformed("NATIVE_SCENE 1\npalette huge.npal\n");
  const std::array<uint8_t,24> shortTiles={'N','T','I','L',1,0,4,0,1,0,0,0,8,0,0,0,8,0,0,0,0,0,0,0};write("short.ntiles",shortTiles);malformed("NATIVE_SCENE 1\nlayer bg1 4 1 1 0 0 1 short.ntiles unused.nmap\n");
  const std::array<uint8_t,20> hugeSprite={'N','S','P','R',1,0,0,0,255,255,255,255,0,0,0,0,1,0,254,255};write("huge.nspr",hugeSprite);CHECK(!loadNativeSprite((dir/"huge.nspr").string(),sp));CHECK(!sp.valid());
  std::filesystem::remove_all(dir);
}
int main(){composition();math();sprites();updates();files();std::cout<<checks<<" renderer checks, "<<failures<<" failures\n";return failures?1:0;}
