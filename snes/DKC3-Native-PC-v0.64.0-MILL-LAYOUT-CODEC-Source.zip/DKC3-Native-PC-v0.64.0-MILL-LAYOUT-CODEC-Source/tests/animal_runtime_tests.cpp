#include "core/Game.h"
#include "core/Bmp.h"
#include <iostream>
#include <cmath>
#define CHECK(x) do{if(!(x)){std::cerr<<"ANIMAL_FAIL "<<__LINE__<<" "<<#x<<'\n';return 1;}}while(0)
using namespace dkc3;
int main(){
 for(bool duplicate:{false,true}){
  RomAnimalBoxStateMachine box;CHECK(box.hit(duplicate));CHECK(!box.hit(false));
  for(int tick=0;tick<4;++tick){CHECK(!box.tick());CHECK(box.state==RomAnimalBoxState::Opening);}
  CHECK(box.tick()==!duplicate);CHECK(box.state==RomAnimalBoxState::Spent);CHECK(!box.tick()&&!box.hit(false));
 }
 for(unsigned word=0;word<65536;++word){
  const bool expected=!(static_cast<uint16_t>(1000+8-word)&0x8000);
  CHECK(romAnimalSignContact(1000,1000,1000,(uint16_t)word)==expected);
 }
 CHECK(romAnimalSignContact(1000,1000,985,1008));CHECK(!romAnimalSignContact(1000,1000,984,1008));
 CHECK(romAnimalSignContact(1000,1000,1016,1008));CHECK(!romAnimalSignContact(1000,1000,1017,1008));
 const auto right=romAnimalSignOffset(0xd040,true),left=romAnimalSignOffset(0xd040,false);CHECK(right.x==64&&left.x==-64&&right.y==-48&&left.y==-48);
 RomImage rom;CHECK(rom.load("rom/dkc3_ptbr.sfc"));RomMotionProfile dixie,kiddy,ellie;
 CHECK(loadRomMotionProfiles("rom/dkc3_ptbr.sfc",dixie,kiddy));CHECK(loadRomEllieMotion(rom,dixie,ellie));
 CHECK(ellie.walkSpeed==0x240&&ellie.runSpeed==0x300&&ellie.jumpImpulse<0);
 RomEllieVisuals visuals;CHECK(loadRomEllieVisuals(rom,visuals));CHECK(visuals.idle.size()==4&&visuals.walk.size()==14);
 CHECK(saveBmp32("docs/ellie-rom-v053.bmp",visuals.idle[0].pixels.data(),visuals.idle[0].width,visuals.idle[0].height));
 Game g;CHECK(g.init("assets/levels/lakeside-limbo/lakeside-limbo.level"));CHECK(g.animalBoxes().size()==1&&g.animalSigns().size()==1);
 CHECK(g.animalBoxes()[0].animalType==0x234&&g.animalSigns()[0].rewardIndex==5&&g.animalSigns()[0].reward.placementType==0xc6);
 // Collision fixtures set positions here only; gold replays never do this.
 auto& player=const_cast<Player&>(g.player());const auto box=g.animalBoxes()[0].bounds();player.pos={box.x+4,box.y-player.height-1};player.vel={0,120};player.grounded=false;player.motion=PlayerMotion::Air;
 g.step({},1.f/60);CHECK(g.animalBoxes()[0].lifecycle.state==RomAnimalBoxState::Opening);CHECK(!g.animal().active);
 for(int tick=0;tick<4;++tick){g.step({},1.f/60);CHECK(!g.animal().active);}
 g.step({},1.f/60);CHECK(g.animal().active&&!g.animal().mounted);CHECK(g.animalBoxes()[0].lifecycle.state==RomAnimalBoxState::Spent);
 player.pos=g.animal().body.pos;player.vel={};InputState mount;mount.up=true;g.step(mount,1.f/60);CHECK(g.animal().mounted&&g.animalMounts()==1);CHECK(player.nativeMotion.walkSpeed==0x240);
 InputState leave;leave.down=true;leave.switchCharacter=true;const auto character=g.activeCharacter();g.step(leave,1.f/60);
 CHECK(!g.animal().mounted&&g.animal().active&&g.activeCharacter()==character);CHECK(player.nativeMotion.walkSpeed==dixie.walkSpeed);
 player.pos=g.animal().body.pos;player.vel={};g.step(mount,1.f/60);CHECK(g.animal().mounted&&g.animalMounts()==2);
 const auto sign=g.animalSigns()[0].feet;player.pos={sign.x-player.width/2,sign.y-player.height};player.vel={};const auto coins=g.collectibles().size();g.step({},1.f/60);
 CHECK(!g.animal().active&&!g.animal().mounted&&g.animalSignRewards()==1);CHECK(g.collectibles().size()==coins+1);CHECK(g.collectibles().back().id=="rom-bear-coin");CHECK(player.nativeMotion.walkSpeed==dixie.walkSpeed);
 const auto reward=g.collectibles().back().pos;player.pos=reward;g.step({},1.f/60);CHECK(g.coins()==1);
 for(int i=0;i<15;++i)g.step({},1.f/60);CHECK(g.animalSignRewards()==1&&g.coins()==1);

 // Carried and swept thrown barrels share the same delay, including the hit tick.
 for(bool carried:{false,true}){
  Game hit;CHECK(hit.init("assets/levels/lakeside-limbo/lakeside-limbo.level"));
  auto& actor=const_cast<Player&>(hit.player());const auto bounds=hit.animalBoxes()[0].bounds();
  auto& barrels=const_cast<std::vector<RuntimeTeamBarrel>&>(hit.teamBarrels());CHECK(!barrels.empty());auto& barrel=barrels[0];
  if(carried){actor.pos={bounds.x-25,bounds.y};actor.grounded=true;actor.motion=PlayerMotion::Ground;actor.vel={};barrel.pos={actor.pos.x+actor.width+4,actor.pos.y};barrel.state=CarryBarrelState::Resting;barrel.velocity={};}
  else{barrel.pos={bounds.x-25,bounds.y};barrel.state=CarryBarrelState::Thrown;barrel.velocity={600,0};}
  barrel.active=true;barrel.remainder=0;InputState held;held.attack=carried;
  for(int i=0;i<10&&hit.animalBoxes()[0].lifecycle.state==RomAnimalBoxState::Closed;++i)hit.step(held,1.f/60);
  CHECK(hit.animalBoxes()[0].lifecycle.state==RomAnimalBoxState::Opening);CHECK(hit.animalBoxes()[0].lifecycle.delay==4);CHECK(!barrel.active);
  for(int i=0;i<4;++i){hit.step({},1.f/60);CHECK(!hit.animal().active);}
  hit.step({},1.f/60);CHECK(hit.animal().active);CHECK(hit.animalBoxes()[0].lifecycle.state==RomAnimalBoxState::Spent);
 }
 std::cout<<"ANIMAL_RUNTIME_OK box five ticks/duplicate, 65536 sign words, offsets, ROM frames/profile, mount/remove/reward\n";
}
