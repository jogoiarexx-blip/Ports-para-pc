#include "core/RomDoorstop.h"
#include "core/RomObjectRuntime.h"
#include "core/NativeAssets.h"
#include "core/Game.h"
#include <iostream>
using namespace dkc3;
#define CHECK(x) do{if(!(x)){std::cerr<<"DOORSTOP_OBJECT_FAIL "<<__LINE__<<" "<<#x<<'\n';return 1;}}while(0)
int main(){
  RomImage rom;CHECK(rom.load("rom/dkc3_ptbr.sfc"));
  std::vector<RomLevelPlacement> placements;CHECK(decodeRomLevelPlacements(rom,0x28,placements));CHECK(placements.size()==118);
  size_t buzz=0,lever=0,door=0,gear=0;
  for(const auto& p:placements){
    if(p.spriteId==0x02fc){RomBuzzProfile v;CHECK(loadRomBuzzProfile(p,v));CHECK(v.variant==5||v.variant==6);CHECK(v.animationId==0x139||v.animationId==0x13b);++buzz;}
    if(p.spriteId==0x038c){RomDoorLeverProfile v;CHECK(loadRomDoorLeverProfile(p,v));CHECK(v.initialState==3&&v.activationStep==4&&v.phaseStep==0x10);++lever;}
    if(p.spriteId==0x0390){RomMetalDoorProfile v;CHECK(loadRomMetalDoorProfile(p,v));CHECK(v.travel==0x40&&v.closeStep==1);++door;}
    if(p.spriteId==0x0394){RomDoorGearProfile v;CHECK(loadRomDoorGearProfile(p,v));++gear;}
  }
  CHECK(buzz==14&&lever==15&&door==14&&gear==14);
  CHECK(findRomObject(0x02fc).support==RomSupport::Partial&&findRomObject(0x02fc).romHandler==0xB68170u);
  CHECK(findRomObject(0x038c).romHandler==0xB6923Fu&&findRomObject(0x0390).romHandler==0xB69338u&&findRomObject(0x0394).romHandler==0xB693FFu);
  CHECK(romDoorScaledOffset(0x40,0xff)==0x3f);CHECK(romDoorY(0x088f,0x40,0xff)==0x0850);
  CHECK(romDoorLeverAxis(0x0827,0x10,0x80)==0x082f);CHECK(romDoorGearMotion(0xff)==0x3fc0);
  RomSpawnRuntime spawn;spawn.build(placements);CHECK(spawn.count(RomSupport::Partial)==113);CHECK(spawn.count(RomSupport::Unknown)==5);
  std::string error;NativeRuntimeAssets assets;CHECK(extractNativeAssets("rom/dkc3_ptbr.sfc",assets,error));
  CHECK(assets.placementStreams.count(0x28)&&assets.placementStreams.at(0x28).size()==118);
  Game game;CHECK(game.init("assets/levels/doorstop/doorstop.level"));CHECK(game.romSpawnRuntime().records().size()==118);
  std::cout<<"DOORSTOP_OBJECTS_OK Buzz=14 lever=15 door=14 gear=14 partial=113 unknown=5 ROM-free placement stream contract\n";
}
