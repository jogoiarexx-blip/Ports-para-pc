#include "core/Game.h"
#include "core/Bmp.h"
#include <iostream>
using namespace dkc3;
int main(){
  for(unsigned old=0;old<256;++old)for(unsigned c=0;c<65536;++c){
    unsigned mode=c&255,value=c>>8;unsigned expected=mode==0?0:mode==1?(old|value):(old^value);
    if(romTriggerByte(old,c)!=expected)return 1;
  }
  for(unsigned n=0;n<65536;++n){
    uint16_t timer=n;if(romOffscreenTick(timer,true)||timer!=(n?((n&255)*257):0))return 2;
    timer=n;if(romOffscreenTick(timer,false)!=(n<256)||timer!=(n<256?n:n-256))return 3;
  }
  RomImage rom;if(!rom.load("rom/dkc3_ptbr.sfc"))return 4;
  RomKoinChildren children;if(!loadRomKoinChildren(rom,children)||children.koin.spriteId!=0x3d0||children.coin.spriteId!=0x3d4)return 5;
  RomSpriteFrame f;if(!decodeRomGraphicId(rom,0x2dcd,0x57,f)||f.pixels.empty())return 6;
  if(decodeRomGraphicId(rom,0x2dcc,0x57,f))return 7;
  Game g;if(!g.init("assets/levels/lakeside-limbo/lakeside-limbo.level"))return 8;
  if(g.romTriggers().size()!=1||g.romControls().size()!=1||g.koins().size()!=1)return 9;
  {auto& camera=const_cast<Camera&>(g.camera());camera.x=g.koins().front().feet.x-128;camera.y=g.koins().front().feet.y-160;
   std::vector<uint32_t> image(256*224);g.render(image.data(),256,224);
   if(!saveBmp32("docs/koin-rom-v054.bmp",image.data(),256,224))return 17;camera={};}
  const auto t=g.romTriggers().front();if(t.address!=0x15e6||t.command!=0x101||t.state!=1||t.reward!=0xffff)return 10;
  if(g.romLevelByte(0x15e6)!=0)return 11;
  // Unit fixture only: place an existing carried barrel inside the ROM trigger.
  // Gold replays never change positions.
  auto& barrels=const_cast<std::vector<RuntimeTeamBarrel>&>(g.teamBarrels());
  auto& b=barrels.front();b.state=CarryBarrelState::Thrown;b.pos={t.bounds.x,t.bounds.y};b.velocity={};
  g.step({},1.f/60);if(!g.romTriggers().front().activated||g.romLevelByte(0x15e6)!=1||b.active)return 12;
  g.step({},1.f/60);if(g.romLevelByte(0x15e6)!=1)return 13;
  // Koin is immune to the ordinary enemy roll/stomp list and guards his coin.
  auto& p=const_cast<Player&>(g.player());const auto box=g.koins().front().bounds();
  p.pos={box.x-p.width+1,box.y+5};p.vel={60,0};p.grounded=false;p.motion=PlayerMotion::Air;
  InputState in;in.right=true;g.step(in,1.f/60);
  if(p.pos.x+p.width>box.x+.01f)return 14;
  const auto anchor=g.romControls().front().anchor;p.pos={anchor.x,anchor.y};
  auto& camera=const_cast<Camera&>(g.camera());camera.x=anchor.x-128;camera.y=anchor.y-112;
  for(int i=0;i<10;++i)g.step({},1.f/60);
  if(g.romControls().front().activations==0)return 15;
  if(!g.init("assets/levels/lakeside-limbo/lakeside-limbo.level")||g.romLevelByte(0x15e6)!=0||g.romTriggers().front().activated)return 16;
  std::cout<<"CONTROL_OK 16,777,216 byte cases; 131,072 timer cases; ROM Koin children; trigger, shield and reload fixtures\n";
}
