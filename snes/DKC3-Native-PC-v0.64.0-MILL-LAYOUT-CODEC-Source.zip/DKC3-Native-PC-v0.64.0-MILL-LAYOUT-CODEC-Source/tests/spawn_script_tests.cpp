#include "core/RomData.h"
#include <filesystem>
#include <fstream>
#include <iostream>
#include <vector>
using namespace dkc3;
#define CHECK(x) do { if(!(x)){std::cerr<<"SPAWN_FAIL line="<<__LINE__<<" "<<#x<<'\n';return 1;} } while(0)
int main(){
  std::vector<uint8_t> image(0x400000);
  auto script=[&](uint16_t address,std::initializer_list<uint8_t> bytes){
    std::copy(bytes.begin(),bytes.end(),image.begin()+0x3f0000+address);
  };
  script(0x8000,{0xff,0x30,0x04,0x38,0x01,0x00,0xfa,0x10,0x02,0xef});
  // Multiple base calls are valid; FF after the call overrides its inherited type.
  script(0x8020,{0xf9,0x00,0x80,0xff,0x34,0x04,0xf9,0x00,0x80,0xff,0x34,0x04,0x38,0x07,0x00,0xef});
  script(0x8040,{0xf5,0xff,0xc4,0x02,0xef});
  script(0x8060,{0xf9,0x60,0x80,0xef}); // cycle must fail, not invent an ID
  script(0x8080,{0xf8,0xe6,0x15,0x01,0x00,0x00,0x80,0x40,0x80,0xff,0xc0,0x02,0xef});
  script(0x80a0,{0xf4,0x00,0x80,0x80,0x13,0xf0,0x03,0x04,0xfe,0x05,0x20,0x10,0xef});
  // Op EF-1 writes an unaligned word just like the original direct-page store.
  script(0x80c0,{0xee,0x34,0x12,0xff,0xc0,0x02,0xef});
  script(0xffff,{0xff}); // operand must never wrap across the bank
  // Generic level placement stream: FE pointer table -> FE:9000, type $0100
  // -> descriptor FF:8000. This path must work without a PIER/MILL renderer.
  const size_t fe=0x3e0000,ff=0x3f0000;
  image[fe+0x28*2]=0x00;image[fe+0x28*2+1]=0x90;
  const uint8_t placement[]={0x01,0x00,0xe8,0x03,0xb0,0x04,0x00,0x01,0x00,0x00};
  std::copy(std::begin(placement),std::end(placement),image.begin()+fe+0x9000);
  image[ff+0x0140]=0x00;image[ff+0x0141]=0x80;
  const auto path=std::filesystem::temp_directory_path()/"dkc3-native-spawn-fixture.sfc";
  {std::ofstream out(path,std::ios::binary);out.write(reinterpret_cast<const char*>(image.data()),image.size());}
  RomImage rom;CHECK(rom.load(path.string()));std::filesystem::remove(path);
  RomSpawnSpec spec;
  CHECK(decodeRomSpawnScript(rom,0x8020,spec));CHECK(spec.spriteId==0x0434);CHECK(spec.word(0x38)==7);CHECK(spec.animationId==0x0210);
  CHECK(decodeRomSpawnScript(rom,0x8040,spec));CHECK(spec.spriteId==0x02c4);
  CHECK(!decodeRomSpawnScript(rom,0x8060,spec));CHECK(spec.spriteId==0xffff);
  CHECK(decodeRomSpawnScript(rom,0x8080,spec));CHECK(spec.conditional&&spec.spriteId==0x02c0);
  CHECK(decodeRomSpawnScript(rom,0x80a0,spec,1000,1200));
  CHECK(spec.word(0x5c)==1176&&spec.word(0x5e)==1232);CHECK(spec.word(0x34)==0xffe0);
  CHECK(spec.word(0x44)==0xff00&&spec.word(0x36)==80);CHECK(spec.word(0x46)==0x1030&&spec.word(0x48)==0x3000);
  CHECK(spec.word(0x18)==32&&spec.word(0x1a)==48);
  CHECK(decodeRomSpawnScript(rom,0x80c0,spec));CHECK(spec.word(0xee)==0x1234);
  CHECK(!decodeRomSpawnScript(rom,0xffff,spec));
  std::vector<RomLevelPlacement> placements;std::vector<uint8_t> raw;
  CHECK(decodeRomLevelPlacements(rom,0x28,placements,&raw));CHECK(placements.size()==1);CHECK(raw.size()==10);
  CHECK(placements[0].parameter==1&&placements[0].x==1000&&placements[0].y==1200&&placements[0].type==0x0100);
  CHECK(placements[0].descriptor==0x8000&&placements[0].spriteId==0x0430);
  CHECK(!decodeRomLevelPlacements(rom,0x200,placements));CHECK(placements.empty());
  std::cout<<"SPAWN_SCRIPT_OK inherited calls, overrides, F5 continuation, conditional merge, relative movement, bank bounds, cycles, generic level placement audit\n";
}
