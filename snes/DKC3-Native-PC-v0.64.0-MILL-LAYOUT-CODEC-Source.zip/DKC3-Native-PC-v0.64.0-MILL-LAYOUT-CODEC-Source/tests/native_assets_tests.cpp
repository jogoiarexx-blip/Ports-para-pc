#include "core/NativeAssets.h"
#include "core/Game.h"
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iostream>
using namespace dkc3;
#define CHECK(x) do{if(!(x)){std::cerr<<"NATIVE_ASSET_FAIL "<<__LINE__<<" "<<#x<<'\n';return 1;}}while(0)
static void env(const char* key,const char* value){
#ifdef _WIN32
  _putenv_s(key,value);
#else
  setenv(key,value,1);
#endif
}
static std::vector<char> bytes(const std::string& p){std::ifstream f(p,std::ios::binary);return {std::istreambuf_iterator<char>(f),std::istreambuf_iterator<char>()};}
static void write(const std::string& p,const std::vector<char>& b){std::ofstream f(p,std::ios::binary);f.write(b.data(),b.size());}
int main(){
  std::string error;NativeRuntimeAssets reference,loaded;
  // Check missing-file failure before extraction or any runtime initialization.
  CHECK(!readNativeAssets("tests/data/does-not-exist.nassets",loaded,error));
  CHECK(extractNativeAssets("rom/dkc3_ptbr.sfc",reference,error));
  auto dir=std::filesystem::temp_directory_path()/"dkc3-native-assets-tests";std::filesystem::create_directories(dir);
  auto a=(dir/"reference.nassets").string(),b=(dir/"roundtrip.nassets").string(),c=(dir/"runtime.nassets").string();
  CHECK(writeNativeAssets(a,reference,error));CHECK(readNativeAssets(a,loaded,error));CHECK(writeNativeAssets(b,loaded,error));
  CHECK(bytes(a)==bytes(b)); // Canonical roundtrip covers every serialized field.
  for(auto& [id,l]:reference.levels){const auto& n=loaded.levels.at(id);CHECK(l.placementData()==n.placementData());
    for(int y=0;y<512;y+=7)for(int x=0;x<l.width();x+=3){auto r=l.terrain().query(x,y+256),s=n.terrain().query(x,y+256);CHECK(r.supported==s.supported&&r.encoded==s.encoded&&r.attributes==s.attributes&&r.initialAttributes==s.initialAttributes&&r.ceiling==s.ceiling&&r.ceilingSlope==s.ceilingSlope);CHECK(l.terrain().solidBodyPoint(x,y)==n.terrain().solidBodyPoint(x,y));}
  }
  // Failed decoding must not partially publish into the caller's live object.
  const auto oldPixels=loaded.levels.at(0x25).pixels();auto damaged=bytes(a);damaged.back()^=1;write(c,damaged);CHECK(!readNativeAssets(c,loaded,error));CHECK(loaded.levels.at(0x25).pixels()==oldPixels);
  damaged=bytes(a);damaged.pop_back();write(c,damaged);CHECK(!readNativeAssets(c,loaded,error));
  damaged=bytes(a);damaged.push_back('x');write(c,damaged);CHECK(!readNativeAssets(c,loaded,error));
  damaged=bytes(a);damaged[13]=99;write(c,damaged);CHECK(!readNativeAssets(c,loaded,error));
  env("DKC3_NATIVE_ASSET_DIR",dir.string().c_str());env("DKC3_ASSET_MODE","native");env("DKC3_ROM_PATH","tests/data/does-not-exist.sfc");
  resetRomIoMetrics();CHECK(!runtimeNativeAssets(error));CHECK(romIoMetrics().loadAttempts==0); // Corrupt strict-native package fails closed.
  CHECK(writeNativeAssets(c,reference,error));
  resetRomIoMetrics();
  {auto assets=runtimeNativeAssets(error);CHECK(assets);RomFrontendVisuals frontend;RomWorldMapVisuals world;RomLakeOrangatangaVisuals lake;CHECK(frontend.load()&&world.load()&&lake.load());
    Game lakeside,tidal,doorstop;CHECK(lakeside.init("assets/levels/lakeside-limbo/lakeside-limbo.level"));CHECK(tidal.init("assets/levels/tidal-trouble/tidal-trouble.level"));CHECK(doorstop.init("assets/levels/doorstop/doorstop.level"));
    for(int i=0;i<120;++i){lakeside.step({},1.f/60);tidal.step({},1.f/60);doorstop.step({},1.f/60);}
  }
  CHECK(romIoMetrics().loadAttempts==0&&romIoMetrics().fileBytesRead==0&&romIoMetrics().rangeBytesRead==0&&romIoMetrics().byteViewRequests==0);
  env("DKC3_ASSET_MODE","rom");env("DKC3_ROM_PATH","rom/dkc3_ptbr.sfc");resetRomIoMetrics();CHECK(runtimeNativeAssets(error));CHECK(romIoMetrics().successfulLoads>0&&romIoMetrics().fileBytesRead>0);
  std::filesystem::remove_all(dir);std::cout<<"Native semantic roundtrip, terrain parity, integrity failures, atomic publication, ROM-free runtime passed\n";
}
