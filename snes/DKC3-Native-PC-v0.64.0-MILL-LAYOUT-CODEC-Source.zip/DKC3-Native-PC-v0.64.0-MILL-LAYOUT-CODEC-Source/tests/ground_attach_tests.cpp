#include "core/RomTerrain.h"
#include "core/RomData.h"
#include <array>
#include <iostream>
#include <stdexcept>
#define CHECK(x) do{if(!(x)){std::cerr<<"FAIL line "<<__LINE__<<"\n";return 1;}}while(0)
using namespace dkc3;
// Bounded test-only ROM execution. Runtime remains native C++.
struct Probe {
 const std::vector<uint8_t>& rom;std::array<uint16_t,65536> mem{};uint16_t a=0,x=0,y=0,pc=0;
 uint8_t byte(){return rom[0x390000+pc++];}uint16_t word(){auto l=byte();return l|(byte()<<8);}
 void run(){pc=0xf027;for(int i=0;i<30;i++){switch(byte()){
 case 0xa5:a=mem[byte()];break;case 0x29:a&=word();break;case 0x0a:a=uint16_t(a<<1);break;case 0xaa:x=a;break;
 case 0xbf:{uint32_t addr=word();addr|=uint32_t(byte())<<16;addr=(addr+x)&0x3fffff;a=rom[addr]|(uint16_t(rom[addr+1])<<8);break;}
 case 0xa6:x=mem[byte()];break;case 0x95:mem[uint16_t(x+byte())]=a;break;case 0x94:mem[uint16_t(x+byte())]=y;break;case 0x74:mem[uint16_t(x+byte())]=0;break;
 case 0xa9:a=word();break;case 0x15:a|=mem[uint16_t(x+byte())];break;
 case 0x82:return;default:throw std::runtime_error("unexpected attach opcode");}}
 throw std::runtime_error("attach probe did not terminate");}
};
int main(){RomImage rom;CHECK(rom.load("rom/dkc3_ptbr.sfc")&&rom.info().crc32==0x448eec19);std::array<int16_t,8> speeds;for(int i=0;i<8;i++)speeds[i]=static_cast<int16_t>(rom.bytes()[0x39f126+i*2]|uint16_t(rom.bytes()[0x39f127+i*2])<<8);Probe p{rom.bytes()};uint32_t random=37;for(int i=0;i<20000;i++){random=random*1664525+1013904223;auto attr=uint16_t(random);random=random*1664525+1013904223;auto flags=uint16_t(random>>8);auto floor=uint16_t(random);p.mem[0x70]=0x1000;p.mem[0xa0]=attr;p.mem[0x1028]=flags;p.mem[0x1014]=77;p.mem[0x101a]=88;p.y=floor;p.run();auto r=romDryGroundAttach(floor,attr,flags,speeds.data());CHECK(r.position==p.mem[0x1016]&&r.fraction==p.mem[0x1014]&&r.nextSurface==p.mem[0x1018]&&r.distance==p.mem[0x101a]&&r.flags==p.mem[0x1028]&&uint16_t(r.velocity)==p.mem[0x102e]);}std::cout<<"DRY_GROUND_ATTACH_OK original B9:F027 response 20000 cases\n";}
