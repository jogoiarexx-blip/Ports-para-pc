#include "core/NativeReplay.h"
#include "core/input_recording.h"
#include "core/desktop_viewport.h"
#include <fstream>
#include <cstdio>
#include <iostream>
#define CHECK(x) do{if(!(x)){std::cerr<<"BRIDGE_FAIL "<<__LINE__<<" "<<#x<<"\n";return 1;}}while(0)
int main(){using namespace dkc3;
 const char*path="bridge-input-test.txt";{std::ofstream f(path);f<<"# compatible input stream\n000000 * 40\n000008\n000000 150\n";}
 NativeReplay a;std::string error;CHECK(a.load(path,error)&&error.empty()&&a.count()==191);CHECK(a.frame(40)==8&&a.frame(191)==0);
 WorldMap first,second;CHECK(first.init({},"rom/dkc3_ptbr.sfc"));CHECK(second.init({},"rom/dkc3_ptbr.sfc"));
 for(size_t i=0;i<a.count();++i){const auto in=nativeMapInputFromSnes(a.frame(i));first.step(in,1.f/60);second.step(in,1.f/60);CHECK(first.state().boatX==second.state().boatX&&first.state().boatY==second.state().boatY&&first.area()==second.area());}
 CHECK(first.area()==WorldArea::LakeOrangatanga&&first.state().boatX==382&&first.state().boatY==398);
 Dkc3InputRecorder recorder{};char message[256]{};CHECK(Dkc3InputRecorderOpen(&recorder,path,message,sizeof message));
 for(uint32_t m:{0u,1u,0x82u,0xffffffu}){CHECK(Dkc3InputRecorderWrite(&recorder,m,message,sizeof message));}CHECK(recorder.frames==4);CHECK(Dkc3InputRecorderClose(&recorder,message,sizeof message));
 CHECK(a.load(path,error)&&a.count()==4&&a.frame(2)==0x82&&a.frame(3)==0xffffff);
 {std::ofstream f(path);f<<"1000000\n";}CHECK(!a.load(path,error)&&a.count()==0&&!error.empty());
 {std::ofstream f(path);f<<"000000 * 0\n";}CHECK(!a.load(path,error));std::remove(path);
 const auto shoulder=nativeInputFromSnes(0x880);CHECK(shoulder.run&&shoulder.right&&!shoulder.attack);const auto in=nativeInputFromSnes(0xd7);CHECK(in.jump&&in.run&&in.attack&&in.switchCharacter&&in.up&&in.left&&in.right&&!in.down);
 Dkc3DesktopViewport view{};CHECK(Dkc3DesktopComputeViewport(1920,1080,256,224,&view));CHECK(view.x==240&&view.y==0&&view.width==1440&&view.height==1080);
 CHECK(Dkc3DesktopComputeViewport(1080,1920,256,224,&view)&&view.width==1080&&view.height==810&&view.y==555);
 CHECK(Dkc3DesktopComputeViewport(160,100,256,224,&view)&&view.width<=160&&view.height<=100&&view.x>=0&&view.y>=0);
 CHECK(!Dkc3DesktopComputeViewport(0,100,256,224,&view));CHECK(!Dkc3DesktopComputeViewport(100,100,256,224,nullptr));
 std::cout<<"NATIVE_RECOMP_BRIDGE_OK compatible replay/record, repeatability, boat route, bad files, input mapping, 4:3 and small viewport\n";
}
