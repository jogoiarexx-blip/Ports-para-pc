#include "core/NativeTrace.h"
#define CHECK(x) do { if(!(x)) { std::cerr<<"TRACE_FAIL line="<<__LINE__<<" "<<#x<<"\n";return 1; } } while(0)
#include <limits>
#include <sstream>
#include <iostream>
using namespace dkc3;
int main(){
 TraceState s;s.set("b",2);s.set("a",1);
 CHECK(s.hash()=="ba7ba27f8aa4322d"); // FNV-1a of literal bytes a\0 1\0 b\0 2\0
 TraceState t;t.set("a",1);t.set("b",2);CHECK(t.hash()==s.hash());
 t.set("b",3);CHECK(t.hash()!=s.hash());
 s.set("zero",0.0f);s.set("negativeZero",-0.0f);s.unavailable("rng");
 CHECK(s.fields.at("zero")=="f32:00000000");CHECK(s.fields.at("negativeZero")=="f32:80000000");
 bool rejected=false;try{s.set("bad",std::numeric_limits<float>::infinity());}catch(...){rejected=true;}CHECK(rejected);
 std::ostringstream out;TraceRecorder rec(out);rec.beginFrame(0,256);recordNativeCall("update\"player",0xB8A035);rec.endFrame(s,{},{});
 auto json=out.str();CHECK(json.find("update\\\"player")!=std::string::npos);CHECK(json.find("\"pc\":null")!=std::string::npos);CHECK(json.find("\"source_pc\":12099637")!=std::string::npos);
 CHECK(json.find("\"rng\":null")!=std::string::npos);
 std::ostringstream many;TraceRecorder bounded(many);bounded.beginFrame(0,0);for(int i=0;i<100;++i)recordNativeCall("tick");bounded.endFrame(t,{},{});
 CHECK(many.str().find("\"calls_dropped\":36")!=std::string::npos);
 std::ostringstream after;TraceRecorder quiet(after);quiet.beginFrame(0,0);quiet.endFrame(t,{},{});recordNativeCall("outside");CHECK(after.str().find("outside")==std::string::npos);
 std::cout<<"NATIVE_TRACE_OK canonical hash, exact float, JSON, bounds, disabled instrumentation\n";
}
