#include "core/Player.h"
#include "core/RomTerrain.h"
#include <iostream>
#define CHECK(x) do{if(!(x)){std::cerr<<"WALL_FAIL "<<__LINE__<<" "<<#x<<"\n";return 1;}}while(0)
int main(){using namespace dkc3;
 auto r=romWallCollision(20,300,310,768,0xff00,0x1000,305);CHECK(r.x==20&&r.y==300&&r.savedTarget==768&&r.savedVelocity==0xff00&&r.flags==0x1002&&r.fraction==0&&r.velocity==0&&r.target==0);
 r=romWallCollision(20,300,310,768,256,0,305);CHECK(r.y==310&&r.flags==2);
 r=romWallCollision(20,300,0,0,0,0x1000,0xffff);CHECK(r.y==300);
 std::vector<uint8_t> map(64,0),defs(576,0),attrs(168,0);defs[4]=defs[6]=1;map[18]=1;map[48]=map[50]=1;
 RomPierTerrain terrain;CHECK(terrain.load(map,defs,attrs,2));RomMotionProfile dixie,kiddy;CHECK(loadRomMotionProfiles("rom/dkc3_ptbr.sfc",dixie,kiddy));
 Player p;p.nativeMotion=dixie;p.width=18;p.height=10;p.pos={18,279};p.grounded=true;p.vel.x=180;p.nativeControlFlags=4;InputState in;in.right=true;in.run=true;
 for(int i=0;i<120&&p.nativeWallHits==0;++i)updatePlayer(p,in,1.f/60,nullptr,0,nullptr,0,&terrain);
 CHECK(p.nativeWallHits>0&&p.pos.x+p.width/2<32&&p.vel.x==0&&p.grounded);
 CHECK(p.nativeBlockedTarget==768&&p.nativeBlockedVelocity>0&&(p.nativeTerrainFlags&2));
 for(int i=0;i<120;++i){const auto before=p.nativeWallHits;updatePlayer(p,in,1.f/60,nullptr,0,nullptr,0,&terrain);CHECK(p.pos.x+p.width/2<32);if(p.nativeWallHits>before)CHECK(p.vel.x==0&&p.nativeHorizontalTarget==0);}
 const auto beforeStop=p.nativeWallHits;for(int i=0;i<120&&p.nativeWallHits==beforeStop;++i)updatePlayer(p,in,1.f/60,nullptr,0,nullptr,0,&terrain);
 CHECK(p.nativeWallHits>beforeStop&&p.vel.x==0);
 const float stopped=p.pos.x;const auto hits=p.nativeWallHits;in.right=false;in.left=true;
 for(int i=0;i<10;++i)updatePlayer(p,in,1.f/60,nullptr,0,nullptr,0,&terrain);
 CHECK(p.pos.x<stopped&&p.vel.x<0&&p.nativeWallHits==hits);
 // Mirror: wall to the left.
 map.assign(64,0);map[16]=map[18]=1;map[50]=1;CHECK(terrain.load(map,defs,attrs,2));
 p={};p.nativeMotion=dixie;p.height=10;p.pos={36,279};p.grounded=true;p.vel.x=-180;p.nativeControlFlags=4;
 for(int i=0;i<120&&p.nativeWallHits==0;++i)updatePlayer(p,in,1.f/60,nullptr,0,nullptr,0,&terrain);
 CHECK(p.nativeWallHits>0&&p.pos.x+p.width/2>=32&&p.vel.x==0&&p.grounded&&p.nativeBlockedVelocity<0);
 // Small rise on ROM half-slope follows the surface without blockage.
 map.assign(64,0);map[16]=2;defs[8]=defs[10]=24;CHECK(terrain.load(map,defs,attrs,2));
 p={};p.nativeMotion=dixie;p.height=10;p.pos={18,249};p.grounded=true;p.vel.x=180;p.nativeControlFlags=4;in.left=false;in.right=true;
 updatePlayer(p,in,1.f/60,nullptr,0,nullptr,0,&terrain);CHECK(p.nativeWallHits==0&&p.grounded&&p.pos.y+p.height==257&&p.pos.x==21);
 // Rope flags exclude lateral solid response.
 map.assign(64,0);map[18]=1;map[48]=map[50]=2;defs[8]=defs[10]=64;defs[9]=defs[11]=64;CHECK(terrain.load(map,defs,attrs,2));
 p={};p.nativeMotion=dixie;p.height=10;p.pos={23,279};p.grounded=true;p.vel.x=180;p.nativeControlFlags=4;
 updatePlayer(p,in,1.f/60,nullptr,0,nullptr,0,&terrain);CHECK(p.nativeWallHits==0&&p.pos.x>23);
 std::cout<<"NATIVE_WALL_OK right/left blockage, reverse input, speed/target preservation, slope rise, rope exclusion\n";
}
