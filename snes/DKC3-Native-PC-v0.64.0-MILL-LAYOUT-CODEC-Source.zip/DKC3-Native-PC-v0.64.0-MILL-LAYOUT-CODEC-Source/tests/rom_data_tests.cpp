#include "core/RomData.h"
#include <cstdint>
#include <iostream>
using namespace dkc3;
static uint64_t fnvPixels(const std::vector<uint32_t>& v){uint64_t h=1469598103934665603ull;for(uint32_t x:v)for(int s=0;s<32;s+=8){h^=(x>>s)&255u;h*=1099511628211ull;}return h;}
static uint64_t fnvBytes(const std::vector<uint8_t>& v){uint64_t h=1469598103934665603ull;for(uint8_t x:v){h^=x;h*=1099511628211ull;}return h;}
int main(){
  RomFrontendVisuals f;if(!f.load("rom/dkc3_ptbr.sfc")){std::cerr<<"ROM frontend load failed\n";return 1;}
  if(!f.romInfo().valid||f.romInfo().size!=4194304u||f.romInfo().crc32!=0x448eec19u){std::cerr<<"ROM identity mismatch\n";return 2;}
  if(f.title().size()!=256u*224u||fnvPixels(f.title())!=0xde7ad96ff84b31a0ull){std::cerr<<"title decode mismatch\n";return 3;}
  if(f.fileSelect().size()!=256u*224u||fnvPixels(f.fileSelect())!=0xc04516d7d31d6e34ull){std::cerr<<"file select decode mismatch\n";return 4;}
  RomWorldMapVisuals m;if(!m.load("rom/dkc3_ptbr.sfc")){std::cerr<<"ROM world map load failed\n";return 5;}
  if(m.width()!=512||m.height()!=512||m.mapPixels().size()!=512u*512u||m.landMask().size()!=512u*512u){std::cerr<<"world map dimensions mismatch\n";return 6;}
  if(m.boatFrames().size()!=9u){std::cerr<<"boat pose count mismatch\n";return 7;}
  if(fnvPixels(m.mapPixels())!=0x3c94e156e2bcfddfull){std::cerr<<"world map decode mismatch\n";return 8;}
  if(fnvBytes(m.landMask())!=0x39a27635f67c1401ull){std::cerr<<"world map land mask mismatch\n";return 9;}
  uint64_t boatHash=1469598103934665603ull;
  for(const auto& frame:m.boatFrames())for(uint32_t x:frame.pixels)for(int sh=0;sh<32;sh+=8){boatHash^=(x>>sh)&255u;boatHash*=1099511628211ull;}
  if(boatHash!=0x8dd0a6704447a9dbull){std::cerr<<"boat pose decode mismatch\n";return 10;}
  if(m.boatBlocked(348.0f,420.0f)){std::cerr<<"safe water start unexpectedly blocked\n";return 11;}
  RomLakesideLimboVisuals lakeside;if(!lakeside.load("rom/dkc3_ptbr.sfc")){std::cerr<<"Lakeside Limbo ROM load failed\n";return 12;}
  if(lakeside.width()!=6240||lakeside.height()!=512||lakeside.pixels().size()!=6240u*512u||lakeside.foregroundMask().size()!=6240u*512u){std::cerr<<"Lakeside dimensions mismatch\n";return 13;}
  if(lakeside.placements().size()!=47u||lakeside.placementData().size()!=378u){std::cerr<<"Lakeside placement decode mismatch\n";return 14;}
  if(fnvPixels(lakeside.pixels())!=0x8041ca8954f353e1ull){std::cerr<<"Lakeside scene decode mismatch\n";return 15;}
  if(fnvBytes(lakeside.foregroundMask())!=0x7924ba42caecfd9eull){std::cerr<<"Lakeside foreground mask mismatch\n";return 16;}
  if(fnvBytes(lakeside.placementData())!=0x4e0b107049bd98fdull){std::cerr<<"Lakeside placement blob mismatch\n";return 17;}
  if(lakeside.groundSpans().size()!=3u||lakeside.waterGaps().size()!=2u||lakeside.collisionRects().size()!=375u||lakeside.waterSurfaceY()!=408){std::cerr<<"Lakeside terrain/platform span mismatch\n";return 23;}
  if(lakeside.kobbleWalkFrames().size()!=8u){std::cerr<<"Kobble frame count mismatch\n";return 28;}
  uint64_t kobbleHash=1469598103934665603ull;for(const auto& frame:lakeside.kobbleWalkFrames())for(uint32_t x:frame.pixels)for(int sh=0;sh<32;sh+=8){kobbleHash^=(x>>sh)&255u;kobbleHash*=1099511628211ull;}
  if(kobbleHash!=0x62b14f58337fffdeull){std::cerr<<"Kobble ROM animation mismatch\n";return 29;}
  if(lakeside.bananaSpinFrames().size()!=8u||lakeside.bearCoinFrames().size()!=8u||lakeside.lifeBalloonFrames().size()!=8u||lakeside.kongLetterFrames().size()!=4u){std::cerr<<"collectible ROM frame count mismatch\n";return 30;}
  auto hashFrames=[](const std::vector<RomSpriteFrame>& frames){uint64_t h=1469598103934665603ull;for(const auto& frame:frames)for(uint32_t x:frame.pixels)for(int sh=0;sh<32;sh+=8){h^=(x>>sh)&255u;h*=1099511628211ull;}return h;};
  if(hashFrames(lakeside.bananaSpinFrames())!=0xe1e3f267de0dc1c7ull||hashFrames(lakeside.bearCoinFrames())!=0xce457166b1135cc4ull||hashFrames(lakeside.lifeBalloonFrames())!=0x61b7b5e43ec79f1dull||hashFrames(lakeside.kongLetterFrames())!=0x720707bb444a6527ull){std::cerr<<"collectible ROM graphics mismatch\n";return 31;}
  if(lakeside.barrelCannonFrames().size()!=16u||lakeside.barrelCannonAutoFrames().size()!=16u){std::cerr<<"barrel cannon ROM frame count mismatch\n";return 32;}
  if(hashFrames(lakeside.barrelCannonFrames())!=0xba4169c7aa4afc52ull||hashFrames(lakeside.barrelCannonAutoFrames())!=0xe557ca5d6e86313full){std::cerr<<"barrel cannon ROM graphics mismatch\n";return 33;}
  RomLakesideBonusVisuals bonus1,bonus2;if(!bonus1.load(1,"rom/dkc3_ptbr.sfc")||!bonus2.load(2,"rom/dkc3_ptbr.sfc")){std::cerr<<"Lakeside bonus ROM load failed\n";return 34;}
  if(bonus1.width()!=384||bonus1.height()!=512||bonus2.width()!=384||bonus2.height()!=512){std::cerr<<"Lakeside bonus dimensions mismatch\n";return 35;}
  if(bonus1.targetCount()!=50||bonus1.timeLimit()!=20||bonus2.targetCount()!=15||bonus2.timeLimit()!=30){std::cerr<<"Lakeside bonus objective mismatch\n";return 36;}
  if(bonus1.starPositions().size()!=50u||bonus2.greenBananaPositions().size()!=15u){std::cerr<<"Lakeside bonus item decode mismatch\n";return 37;}
  if(bonus1.placements().size()!=2u||bonus2.placements().size()!=3u||bonus1.collisionRects().size()!=14u||bonus2.collisionRects().size()!=3u){std::cerr<<"Lakeside bonus placement/collision mismatch\n";return 38;}
  if(fnvPixels(bonus1.pixels())!=0xf9428bdbce38277aull||fnvPixels(bonus2.pixels())!=0xb6a45547c419a8c0ull){std::cerr<<"Lakeside bonus scene hash mismatch\n";return 39;}
  if(hashFrames(bonus1.starFrames())!=0xebe803e02502b7f1ull||hashFrames(bonus1.greenBananaFrames())!=0xafbebb5613cda1faull||hashFrames(bonus1.bonusCoinFrames())!=0xaee9a30bfcc30348ull){std::cerr<<"Lakeside bonus object graphics mismatch\n";return 40;}
  if(bonus1.placements()[0].spriteId!=0x02a8u||bonus1.placements()[1].spriteId!=0x028cu||bonus2.placements()[0].spriteId!=0x0154u||bonus2.placements()[1].spriteId!=0x028cu||bonus2.placements()[2].spriteId!=0x02a8u){std::cerr<<"Lakeside bonus sprite IDs mismatch\n";return 41;}
  const int expectedGroundX[3]={0,3664,3952};
  const int expectedGroundW[3]={3344,256,2288};
  const int expectedGapX[2]={3344,3920};
  const int expectedGapW[2]={320,32};
  for(size_t i=0;i<3u;i++)if(lakeside.groundSpans()[i].x!=expectedGroundX[i]||lakeside.groundSpans()[i].width!=expectedGroundW[i]){std::cerr<<"ROM terrain projection mismatch\n";return 24;}
  for(size_t i=0;i<2u;i++)if(lakeside.waterGaps()[i].x!=expectedGapX[i]||lakeside.waterGaps()[i].width!=expectedGapW[i]){std::cerr<<"ROM terrain gap projection mismatch\n";return 25;}
  if(lakeside.placements()[0].descriptor!=0x5ac8u||lakeside.placements()[23].descriptor!=0x8094u||lakeside.placements()[42].descriptor!=0x6782u){std::cerr<<"Lakeside placement handler resolution mismatch\n";return 26;}
  size_t sneeks=0,kobbles=0,checkpoint=0,endflag=0,kong=0,bananas=0,bearCoins=0,balloons=0,barrelCannons=0;for(const auto&p:lakeside.placements()){sneeks+=p.spriteId==0x02f8u;kobbles+=p.spriteId==0x03c8u;checkpoint+=p.spriteId==0x02bcu;endflag+=p.spriteId==0x0124u;kong+=p.spriteId==0x0294u;bananas+=p.spriteId==0x0298u;bearCoins+=p.spriteId==0x0284u;balloons+=p.spriteId==0x029cu;barrelCannons+=p.spriteId==0x02b4u;}
  if(sneeks!=5u||kobbles!=6u||checkpoint!=1u||endflag!=1u||kong!=3u||bananas!=5u||bearCoins!=3u||balloons!=5u||barrelCannons!=6u){std::cerr<<"Lakeside spawn-script sprite resolution mismatch\n";return 27;}
    RomLakeOrangatangaVisuals lake;if(!lake.load("rom/dkc3_ptbr.sfc")){std::cerr<<"Lake Orangatanga load failed\n";return 18;}
  if(lake.mapPixels().size()!=256u*224u||lake.collisionData().size()!=155u||lake.dixieWalkFrames().size()!=8u){std::cerr<<"Lake Orangatanga dimensions mismatch\n";return 19;}
  if(fnvPixels(lake.mapPixels())!=0x66ff253611fa8c71ull){std::cerr<<"Lake Orangatanga map decode mismatch\n";return 20;}
  if(fnvBytes(lake.collisionData())!=0x527bb393335c2a88ull){std::cerr<<"Lake Orangatanga collision blob mismatch\n";return 21;}
  uint64_t dixieHash=1469598103934665603ull;for(const auto& frame:lake.dixieWalkFrames())for(uint32_t x:frame.pixels)for(int sh=0;sh<32;sh+=8){dixieHash^=(x>>sh)&255u;dixieHash*=1099511628211ull;}
  if(dixieHash!=0x91370acfa83e204eull){std::cerr<<"Lake Orangatanga Dixie walk decode mismatch\n";return 22;}
  std::cout<<"ROM_DATA_OK CRC32=448eec19 title/file-select/main-map/boat/lakeside/lake\n";return 0;
}
