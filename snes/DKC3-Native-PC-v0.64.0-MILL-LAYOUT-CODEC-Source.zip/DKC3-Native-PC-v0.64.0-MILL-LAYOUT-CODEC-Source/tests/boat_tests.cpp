#include "core/WorldMap.h"
#include "core/Game.h"
#include <cmath>
#include <iostream>
#include <limits>
#define CHECK(x) do{if(!(x)){std::cerr<<"BOAT_FAIL "<<__LINE__<<" "<<#x<<"\n";return 1;}}while(0)
void settle(dkc3::WorldMap&m){dkc3::WorldMapInput n;for(int i=0;i<40;++i)m.step(n,1.f/60);}
int main(){using namespace dkc3;RomWorldMapVisuals visual;CHECK(visual.load("rom/dkc3_ptbr.sfc"));
 CHECK(visual.boatBlocked(445,420));CHECK(!visual.boatBlocked(382,398));
 // Default spawn, ordinary held direction then enter; no position injection.
 WorldMap manual;CHECK(manual.init({},"rom/dkc3_ptbr.sfc"));settle(manual);WorldMapInput right;right.right=true;
 for(int i=0;i<120;++i){manual.step(right,1.f/60);CHECK(!visual.boatBlocked(manual.state().boatX,manual.state().boatY));}
 CHECK(manual.canEnterLake());CHECK(manual.state().boatX>370&&manual.state().boatX<382);
 WorldMapInput enter;enter.confirm=true;manual.step(enter,1.f/60);CHECK(manual.area()==WorldArea::LakeOrangatanga);
 // Assistance follows navigable water, never changes area/position by teleport.
 WorldMap assisted;CHECK(assisted.init({},"rom/dkc3_ptbr.sfc"));assisted.setRuntimeAvailableMask(WorldMap::stageBit("lakeside-limbo"));settle(assisted);
 assisted.step(enter,1.f/60);CHECK(assisted.navigatingBoat()&&assisted.area()==WorldArea::NorthernKremisphere);
 int ticks=0;float x=assisted.state().boatX,y=assisted.state().boatY;
 for(;ticks<600&&assisted.area()==WorldArea::NorthernKremisphere;++ticks){assisted.step(enter,1.f/60);CHECK(!visual.boatBlocked(assisted.state().boatX,assisted.state().boatY));CHECK(std::hypot(assisted.state().boatX-x,assisted.state().boatY-y)<=1.501f);x=assisted.state().boatX;y=assisted.state().boatY;}
 CHECK(assisted.area()==WorldArea::LakeOrangatanga&&ticks>0&&ticks<120&&!assisted.navigatingBoat());
 std::string level;for(int i=0;i<90;++i)assisted.step(enter,1.f/60);CHECK(!assisted.takeLaunchRequest(level));
 WorldMapInput none;assisted.step(none,1.f/60);assisted.step(enter,1.f/60);
 for(int i=0;i<50&&level.empty();++i){assisted.step(none,1.f/60);assisted.takeLaunchRequest(level);}CHECK(level=="lakeside-limbo");
 Game lake;CHECK(lake.init("assets/levels/lakeside-limbo/lakeside-limbo.level"));CHECK(lake.hasRomScene());
 // Manual input and cancel interrupt assistance without entering a level.
 for(bool useDirection:{false,true}){WorldMap m;CHECK(m.init({},"rom/dkc3_ptbr.sfc"));settle(m);m.step(enter,1.f/60);for(int i=0;i<3;++i)m.step(none,1.f/60);CHECK(m.navigatingBoat());WorldMapInput stop;stop.left=useDirection;stop.cancel=!useDirection;m.step(stop,1.f/60);CHECK(!m.navigatingBoat()&&m.area()==WorldArea::NorthernKremisphere);}
 // Faster input moves farther, remains shore-limited even at maximum dt.
 WorldMap normal,turbo;CHECK(normal.init({},"rom/dkc3_ptbr.sfc"));CHECK(turbo.init({},"rom/dkc3_ptbr.sfc"));settle(normal);settle(turbo);
 normal.step(right,0.1f);right.fast=true;turbo.step(right,0.1f);CHECK(turbo.state().boatX>normal.state().boatX+4);
 for(int i=0;i<100;++i){turbo.step(right,0.1f);CHECK(!visual.boatBlocked(turbo.state().boatX,turbo.state().boatY));}CHECK(turbo.canEnterLake());
 // Legacy isolated save and invalid coordinates recover to connected spawn.
 WorldMapState legacy;legacy.boatX=430;legacy.boatY=420;WorldMap recovered;CHECK(recovered.init(legacy,"rom/dkc3_ptbr.sfc"));CHECK(recovered.state().boatX==348&&recovered.state().boatY==420);
 legacy.boatX=std::numeric_limits<float>::quiet_NaN();legacy.boatY=std::numeric_limits<float>::infinity();recovered.setState(legacy);CHECK(std::isfinite(recovered.state().boatX)&&std::isfinite(recovered.state().boatY));
 const auto before=recovered.state();recovered.step(right,std::numeric_limits<float>::quiet_NaN());CHECK(recovered.state().boatX==before.boatX&&recovered.state().boatY==before.boatY);
 // A farther connected save navigates from its own position, without recovery.
 WorldMapState far;far.boatX=348;far.boatY=450;WorldMap distant;CHECK(distant.init(far,"rom/dkc3_ptbr.sfc"));CHECK(distant.state().boatX==348&&distant.state().boatY==450);settle(distant);distant.step(enter,1.f/60);
 for(int i=0;i<180&&distant.area()==WorldArea::NorthernKremisphere;++i){distant.step(none,1.f/60);CHECK(!visual.boatBlocked(distant.state().boatX,distant.state().boatY));}CHECK(distant.area()==WorldArea::LakeOrangatanga);
 // A saved position on connected water can use the same assistance.
 WorldMapState saved=turbo.state();WorldMap resumed;CHECK(resumed.init(saved,"rom/dkc3_ptbr.sfc"));settle(resumed);resumed.step(enter,1.f/60);CHECK(resumed.area()==WorldArea::LakeOrangatanga);
 // Legacy lake-area save also exits into accessible water.
 legacy={};legacy.area=static_cast<int>(WorldArea::LakeOrangatanga);legacy.boatX=430;legacy.boatY=420;WorldMap oldLake;CHECK(oldLake.init(legacy,"rom/dkc3_ptbr.sfc"));settle(oldLake);WorldMapInput leave;leave.cancel=true;oldLake.step(leave,1.f/60);CHECK(oldLake.area()==WorldArea::NorthernKremisphere&&oldLake.canEnterLake());CHECK(!visual.boatBlocked(oldLake.state().boatX,oldLake.state().boatY));
 // Lake exit returns to the accessible dock and can immediately be re-entered.
 settle(manual);WorldMapInput back;back.cancel=true;manual.step(back,1.f/60);CHECK(manual.area()==WorldArea::NorthernKremisphere);settle(manual);CHECK(manual.canEnterLake());manual.step(enter,1.f/60);CHECK(manual.area()==WorldArea::LakeOrangatanga);
 std::cout<<"NATIVE_BOAT_ACCESS_OK manual/default, assisted water route "<<ticks<<" ticks, cancel, turbo, shore, saves, lake enter/exit and Lakeside launch\n";
}
