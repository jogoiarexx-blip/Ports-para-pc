#include "core/Game.h"
#include "core/CarryBarrel.h"
#include "core/Bmp.h"
#include <iostream>
#include <cmath>
#include <vector>
#define CHECK(x) do{if(!(x)){std::cerr<<"CHECK_FAIL line="<<__LINE__<<" "<<#x<<"\n";return 1;}}while(0)
using namespace dkc3;
static void ticks(Game&g,InputState in,int n){for(int i=0;i<n;++i)g.step(in,1.f/60);}
int main(){
 for(auto character:{CharacterId::Dixie,CharacterId::Kiddy})for(bool left:{false,true}){
  GamePersistentState state;state.activeCharacter=character;Game g;
  CHECK(g.init(left?"tests/data/carry-barrel-left-test.level":"tests/data/carry-barrel-test.level",&state));ticks(g,{},30);
  InputState hold;hold.attack=true;hold.left=left;g.step(hold,1.f/60);CHECK(g.carryingBarrel());CHECK(g.barrelPickups()==1);CHECK(!g.attacking());
  hold.left=false;hold.switchCharacter=true;g.step(hold,1.f/60);CHECK(g.activeCharacter()==character);hold.switchCharacter=false;
  auto y=g.player().pos.y;hold.jump=true;g.step(hold,1.f/60);CHECK(g.carryingBarrel());CHECK(g.player().pos.y<y);hold.jump=false;ticks(g,hold,70);CHECK(g.player().grounded);
  if(!left&&character==CharacterId::Dixie){std::vector<uint32_t> image(256*224);g.render(image.data(),256,224);CHECK(saveBmp32("docs/barrel-carried-v049.bmp",image.data(),256,224));}
  InputState release;release.left=left;g.step(release,1.f/60);CHECK(!g.carryingBarrel());CHECK(g.barrelThrows()==1);ticks(g,{},70);
  CHECK(g.barrelBreaks()==1);CHECK(g.barrelEnemyHits()==1);CHECK(g.defeatedEnemies()==1);CHECK(g.teamBarrels()[0].state==CarryBarrelState::Broken);CHECK(!g.teamBarrels()[0].active);CHECK(g.damageCount()==0);ticks(g,{},30);CHECK(g.barrelBreaks()==1);
 }
 // Down + held attack places the barrel; releasing the button must not throw it.
 {Game g;CHECK(g.init("tests/data/carry-barrel-test.level"));ticks(g,{},30);InputState in;in.attack=true;g.step(in,1.f/60);in.down=true;g.step(in,1.f/60);CHECK(!g.carryingBarrel());ticks(g,in,30);ticks(g,{},10);CHECK(g.barrelThrows()==0);CHECK(g.teamBarrels()[0].active);CHECK(g.teamBarrels()[0].state==CarryBarrelState::Resting);in.down=false;g.step(in,1.f/60);CHECK(g.carryingBarrel());CHECK(g.barrelPickups()==2);}
 // A carried barrel protects the player by hitting the enemy first.
 {Game g;CHECK(g.init("tests/data/carry-barrel-test.level"));ticks(g,{},30);InputState hold;hold.attack=true;g.step(hold,1.f/60);hold.right=true;ticks(g,hold,50);CHECK(g.barrelEnemyHits()==1);CHECK(g.damageCount()==0);CHECK(g.barrelThrows()==0);CHECK(!g.carryingBarrel());}
 // SOLO touch restoration is one break, not repeated per-frame overlap.
 {GamePersistentState solo;solo.partnerAvailable=false;Game g;CHECK(g.init("tests/data/team-barrel-test.level",&solo));g.step({},1.f/60);CHECK(g.partnerAvailable());CHECK(g.teamBarrelRescues()==1);CHECK(g.barrelBreaks()==1);ticks(g,{},10);CHECK(g.teamBarrelRescues()==1);}
 // Ordinary barrels share carry/throw but never restore a missing partner.
 {GamePersistentState solo;solo.partnerAvailable=false;Game g;CHECK(g.init("tests/data/ordinary-barrel-test.level",&solo));ticks(g,{},30);
  CHECK(!g.partnerAvailable());CHECK(!g.teamBarrels()[0].rescuesPartner);InputState hold;hold.attack=true;g.step(hold,1.f/60);CHECK(g.carryingBarrel());
  g.step({},1.f/60);ticks(g,{},70);CHECK(g.barrelEnemyHits()==1);CHECK(g.barrelBreaks()==1);CHECK(g.teamBarrelRescues()==0);CHECK(!g.partnerAvailable());}
 // A wall absorbs the projectile before the enemy behind it.
 {Game g;CHECK(g.init("tests/data/carry-barrel-wall-test.level"));ticks(g,{},30);InputState hold;hold.attack=true;g.step(hold,1.f/60);g.step({},1.f/60);ticks(g,{},60);CHECK(g.barrelBreaks()==1);CHECK(g.barrelEnemyHits()==0);CHECK(g.enemies()[0].active);}
 // Thin walls and platforms cannot be tunneled through at high speed.
 {CarryBarrelBody b;b.pos={10,80};b.velocity={2000,0};b.state=CarryBarrelState::Thrown;std::vector<Rect> wall{{100,0,1,224}};CHECK(advanceCarryBarrel(b,.25f,wall,{},nullptr,512,224)==CarryBarrelImpact::Terrain);CHECK(b.pos.x+b.w<=100.001f);}
 {CarryBarrelBody b;b.pos={10,80};b.velocity={0,800};b.state=CarryBarrelState::Dropped;CHECK(advanceCarryBarrel(b,.25f,{},{{0,160,512,1}},nullptr,512,224)==CarryBarrelImpact::None);CHECK(b.state==CarryBarrelState::Resting);CHECK(std::fabs(b.pos.y+b.h-160)<.001f);}
 // Split dt is deterministic for the object integrator.
 {CarryBarrelBody a,b;a.pos=b.pos={100,20};a.velocity=b.velocity={280,-100};a.state=b.state=CarryBarrelState::Thrown;for(int i=0;i<20;++i)advanceCarryBarrel(a,1.f/60,{}, {},nullptr,2048,512);for(int i=0;i<10;++i)advanceCarryBarrel(b,1.f/30,{}, {},nullptr,2048,512);CHECK(std::fabs(a.pos.x-b.pos.x)<.001f);CHECK(std::fabs(a.pos.y-b.pos.y)<.001f);}
 for(const auto* level:{"lakeside-limbo","tidal-trouble"}){Game g;const auto path=std::string("assets/levels/")+level+"/"+level+".level";CHECK(g.init(path.c_str()));size_t rescue=0,ordinary=0;for(const auto& b:g.teamBarrels()){
   if(b.rescuesPartner){++rescue;CHECK(b.id=="rom-dk-barrel");}
   else if(!b.steel){++ordinary;CHECK(b.id=="rom-barrel");}
  }
  CHECK(rescue==(std::string(level)=="lakeside-limbo"?2u:3u));
  CHECK(ordinary==(std::string(level)=="lakeside-limbo"?3u:0u));}
 std::cout<<"CARRY_BARREL_OK both Kongs/directions, carry/jump, throw/kill, drop/regrab, solo rescue, swept terrain, fixed tick, ROM placements\n";
}
