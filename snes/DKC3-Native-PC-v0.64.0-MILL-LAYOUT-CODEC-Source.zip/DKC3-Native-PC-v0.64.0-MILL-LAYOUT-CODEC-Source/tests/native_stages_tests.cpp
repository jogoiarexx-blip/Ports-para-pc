#include "core/Game.h"
#include "core/NativeReplay.h"
#include "core/Bmp.h"
#include <iostream>
#include <fstream>
#include <cmath>
#include <vector>
#define CHECK(x) do{if(!(x)){std::cerr<<"CHECK_FAIL line="<<__LINE__<<" "<<#x<<"\n";return 1;}}while(0)
using namespace dkc3;
static uint64_t hashPixels(const std::vector<uint32_t>&p){return hashFrame(p.data(),p.size());}
int main(){
 RomLevelRuntime tidal;CHECK(tidal.load(RomLevelRequest{0x27,0x19f0,2}));CHECK(tidal.width()==7968&&tidal.height()==512);CHECK(tidal.waterSurfaceY()==408);CHECK(tidal.collisionRects().size()==180);CHECK(tidal.placements().size()==61);CHECK(tidal.startPoint()==std::pair(60,361));
 CHECK(hashPixels(tidal.pixels())!=0);RomSpawnRuntime coverage;coverage.build(tidal.placements());std::ofstream audit("docs/TIDAL-SPAWN-COVERAGE.csv");audit<<coverage.report();audit.close();
 for(const char* level:{"lakeside-limbo","tidal-trouble"}){
  const bool lake=std::string(level)=="lakeside-limbo";const auto path=std::string("assets/levels/")+level+"/"+level+".level";
  Game g;CHECK(g.init(path.c_str()));CHECK(g.world().nativeScenePages.empty());CHECK(g.hasRomScene());CHECK(g.teamBarrels().size()==(lake?5u:3u));
  std::vector<uint32_t> pixels(256*224);g.render(pixels.data(),256,224);CHECK(saveBmp32(std::string("docs/")+level+"-v049.bmp",pixels.data(),256,224));
  std::vector<uint32_t> masks;std::ofstream trace(std::string("docs/")+level+"-route-v049.csv");trace<<"frame,mask,x,y,grounded,water,lives,checkpoint,barrel_pickups,barrel_throws,exit\n";
  for(int i=0;i<10000&&g.pendingLevel().empty();++i){
   uint32_t mask=0x880; // right + native run shoulder; separate from the barrel/roll button.
   if(i%100<15)mask|=1;
   if(g.inWater())mask|=0x11;else if(i%34==0)mask|=2;
   masks.push_back(mask);g.step(nativeInputFromSnes(mask),1.f/60);
   trace<<i<<','<<std::hex<<mask<<std::dec<<','<<g.player().pos.x<<','<<g.player().pos.y<<','<<g.player().grounded<<','<<g.inWater()<<','<<g.lives()<<','<<g.checkpointActivations()<<','<<g.barrelPickups()<<','<<g.barrelThrows()<<','<<g.pendingLevel()<<'\n';
  }
  CHECK(g.pendingLevel()==(lake?"doorstop":"skiddas-row"));CHECK(g.checkpointActivations()==1);CHECK(g.lives()>0);CHECK(g.player().nativeMotion.valid);CHECK(g.damageCount()<=2);
  const auto replayPath=std::string("tests/replays/")+level+"-route-v049.txt";std::ofstream inputs(replayPath);for(auto mask:masks)inputs<<std::hex<<mask<<'\n';inputs.close();
  NativeReplay replay;std::string error;CHECK(replay.load(replayPath,error));CHECK(replay.count()==masks.size());Game again;CHECK(again.init(path.c_str()));
  for(size_t i=0;i<replay.count();++i)again.step(nativeInputFromSnes(replay.frame(i)),1.f/60);
  CHECK(again.pendingLevel()==g.pendingLevel());CHECK(again.lives()==g.lives());CHECK(again.damageCount()==g.damageCount());CHECK(std::fabs(again.player().pos.x-g.player().pos.x)<.001f);CHECK(std::fabs(again.player().pos.y-g.player().pos.y)<.001f);
  g.render(pixels.data(),256,224);CHECK(saveBmp32(std::string("docs/")+level+"-end-v049.bmp",pixels.data(),256,224));
  std::cout<<level<<" INPUT_REPLAY_OK frames="<<masks.size()<<" checkpoint=1 exit="<<g.pendingLevel()<<" lives="<<g.lives()<<"\n";
 }
 std::cout<<"NATIVE_STAGES_OK PIER submap 2, no captured pages, ROM spawn/placements, repeatable input routes\n";
}
