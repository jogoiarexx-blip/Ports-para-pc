#include "core/Game.h"
#include "core/Bmp.h"
#include <iostream>
#include <algorithm>
#define CHECK(x) do{if(!(x)){std::cerr<<"CHECK_FAIL line="<<__LINE__<<" "<<#x<<'\n';return 1;}}while(0)
using namespace dkc3;
int main(){
 RomImage rom;CHECK(rom.load("rom/dkc3_ptbr.sfc"));
 std::vector<RomSpriteFrame> frames;CHECK(loadRomBootyBirdFrames(rom,frames));CHECK(frames.size()==8);
 for(const auto& f:frames){CHECK(f.width>16&&f.width<=128&&f.height>16&&f.height<=128);CHECK(std::count_if(f.pixels.begin(),f.pixels.end(),[](auto p){return p>>24;})>100);}
 CHECK(saveBmp32("docs/booty-bird-rom-v052.bmp",frames[0].pixels.data(),frames[0].width,frames[0].height));
 RomSpriteFrame sentinel;sentinel.width=123;CHECK(!decodeRomObjectFrame(rom,0xffffff,0x4f,sentinel));CHECK(sentinel.width==123);
 RomObjectReward reward;CHECK(readRomObjectReward(rom,3,reward));CHECK(reward.placementType==0x112&&reward.animation==0x147);
 CHECK(readRomObjectReward(rom,18,reward));CHECK(!readRomObjectReward(rom,19,reward));
 // Positions are arranged only in these collision fixtures, never in route replays.
 for(bool tidal:{false,true})for(int method=0;method<4;++method){
  Game g;CHECK(g.init(tidal?"assets/levels/tidal-trouble/tidal-trouble.level":"assets/levels/lakeside-limbo/lakeside-limbo.level"));
  auto& enemies=const_cast<std::vector<RuntimeEnemy>&>(g.enemies());
  auto bird=std::find_if(enemies.begin(),enemies.end(),[](const auto& e){return e.spriteId==0x434;});CHECK(bird!=enemies.end());
  CHECK(bird->rewardIndex==(tidal?2:3));CHECK(bird->animation.frames.size()==8);bird->speed=0;
  const auto before=g.kongLetters().size();const auto kills=g.defeatedEnemies();
  auto& player=const_cast<Player&>(g.player());
  if(method==0){
   player.pos={bird->pos.x+4,bird->pos.y-player.height-1};player.vel={0,120};player.grounded=false;player.motion=PlayerMotion::Air;
   g.step({},1.f/60);
  }else if(method==1){
   auto& barrels=const_cast<std::vector<RuntimeTeamBarrel>&>(g.teamBarrels());CHECK(!barrels.empty());
   auto& b=barrels[0];b.pos={bird->pos.x-30,bird->pos.y};b.velocity={600,0};b.state=CarryBarrelState::Thrown;b.active=true;b.remainder=0;
   for(int i=0;i<5&&bird->active;++i)g.step({},1.f/60);CHECK(g.barrelEnemyHits()==1);
  }else{
   for(int i=0;i<60;++i)g.step({},1.f/60);
   bird->pos={player.pos.x+player.width+22,player.pos.y};bird->minX=bird->maxX=bird->pos.x;
   InputState in;in.attack=true;in.right=true;
   if(method==3){
    auto& barrels=const_cast<std::vector<RuntimeTeamBarrel>&>(g.teamBarrels());CHECK(!barrels.empty());
    auto& b=barrels[0];b.pos={player.pos.x+player.width+4,player.pos.y};b.state=CarryBarrelState::Resting;b.active=true;b.velocity={};
   }
   for(int i=0;i<15&&bird->active;++i)g.step(in,1.f/60);
   if(method==3)CHECK(g.barrelPickups()==1&&g.barrelEnemyHits()==1&&g.barrelThrows()==0);
  }
  CHECK(!bird->active);CHECK(g.defeatedEnemies()==kills+1);CHECK(g.kongLetters().size()==before+1);
  const auto& letter=g.kongLetters().back();CHECK(letter.letter==(tidal?'N':'G'));
  for(int i=0;i<10;++i)g.step({},1.f/60);CHECK(g.kongLetters().size()==before+1);
  if(method==0){
   // Another reward request for an owned letter uses row 4, not a second letter.
   const auto pickup=g.kongLetters().back().pos;player.pos=pickup;player.vel={};g.step({},1.f/60);
   CHECK(g.kongMask()&(tidal?4u:8u));
   bird->active=true;const auto bananas=g.collectibles().size();
   player.pos={bird->pos.x+4,bird->pos.y-player.height-1};player.vel={0,120};player.grounded=false;player.motion=PlayerMotion::Air;g.step({},1.f/60);
   CHECK(!bird->active);CHECK(g.kongLetters().size()==before+1);CHECK(g.collectibles().size()==bananas+1);CHECK(g.collectibles().back().id=="rom-banana");
  }
 }
 std::cout<<"BOOTY_BIRD_OK ROM frames/rewards, both levels, stomp/throw/roll/carried, duplicate-to-banana, one-shot\n";
}
