#include "core/Game.h"
#include "core/NativeReplay.h"
#include "core/Bmp.h"
#include <fstream>
#include <algorithm>
#include <cmath>
#include <iostream>
#define CHECK(x) do{if(!(x)){std::cerr<<"FAIL line="<<__LINE__<<" "<<#x<<"\n";return 1;}}while(0)
using namespace dkc3;
int main(){
 for(int bonus=1;bonus<=2;++bonus){
  NativeReplay replay;std::string error;
  CHECK(replay.load("tests/replays/lakeside-bonus"+std::to_string(bonus)+(bonus==1?"-v050.txt":"-v051.txt"),error));
  Game g;CHECK(g.init("assets/levels/lakeside-limbo/lakeside-limbo.level"));
  bool entered=false,returned=false,coinShown=false;int collected=0,entryFrame=0;Vec2 savedRespawn{};
  for(size_t i=0;i<replay.count();++i){
   const auto before=g.respawnPoint();
   g.step(nativeInputFromSnes(replay.frame(i)),1.f/60);
   CHECK(g.lives()>0);
   if(g.inBonus()&&g.bonusCollected()==g.bonusTarget()&&!coinShown){
    CHECK(g.bonusCoin().active);coinShown=true;std::vector<uint32_t> pixels(256*224);g.render(pixels.data(),256,224);
    CHECK(saveBmp32("docs/bonus"+std::to_string(bonus)+"-complete-v050.bmp",pixels.data(),256,224));
   }
   collected=std::max(collected,g.bonusCollected());
   if(g.inBonus()&&!entered){CHECK(g.activeBonus()==bonus);entered=true;entryFrame=(int)i+1;savedRespawn=before;}
   if(entered&&!g.inBonus())returned=true;
  }
  CHECK(entered&&returned&&coinShown);CHECK(collected==(bonus==1?50:15));CHECK(g.bonusCoins()==1);
  CHECK(g.lakesideBonusMask()==(1u<<(bonus-1)));CHECK(g.player().nativeRopeGrabs>0);
  CHECK(std::fabs(g.respawnPoint().x-savedRespawn.x)<.001f&&std::fabs(g.respawnPoint().y-savedRespawn.y)<.001f);
  if(bonus==2)CHECK(g.checkpointActivations()==1);
  // Repeating from the same spawn reproduces input and never awards twice.
  GamePersistentState already;already.bonusCoins=1;already.lakesideBonusMask=1u<<(bonus-1);
  Game again;CHECK(again.init("assets/levels/lakeside-limbo/lakeside-limbo.level",&already));
  for(size_t i=0;i<replay.count();++i)again.step(nativeInputFromSnes(replay.frame(i)),1.f/60);
  CHECK(!again.inBonus()&&again.bonusCoins()==1&&again.lakesideBonusMask()==g.lakesideBonusMask());
  CHECK(std::fabs(again.player().pos.x-g.player().pos.x)<.001f&&std::fabs(again.player().pos.y-g.player().pos.y)<.001f);
  std::cout<<"BONUS_INPUT_OK room="<<bonus<<" collected="<<collected<<" frames="<<replay.count()<<" entry="<<entryFrame<<" checkpoint="<<g.checkpointActivations()<<" no position injection\n";
 }
}
