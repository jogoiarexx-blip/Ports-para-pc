#include "core/WorldMap.h"
#include "core/Frontend.h"
#include "core/NativeScene.h"
#include <filesystem>
#include <iostream>
#include <vector>
#define CHECK(x) do { if(!(x)){std::cerr<<"WRINKLY_FAIL "<<__LINE__<<"\n";return 1;} }while(0)
int main(){
  using namespace dkc3;
  WrinklyCave cave;CHECK(cave.init());CHECK(cave.hd());
  std::vector<uint32_t> hd(512*448),original(512*448);
  cave.render(hd.data(),512,448);cave.toggleGraphics();CHECK(!cave.hd());cave.render(original.data(),512,448);
  CHECK(hashFrame(hd.data(),hd.size())!=hashFrame(original.data(),original.size()));
  // No separator magenta may reach the actual scene (exclude UI panels).
  for(int y=36;y<380;++y)for(int x=0;x<512;++x){const auto p=hd[y*512+x];CHECK(!(((p>>16)&255)>245 && ((p>>8)&255)<10 && (p&255)>245));}
  CHECK(saveBmp32("docs/wrinkly-runtime-hd.bmp",hd.data(),512,448));
  cave.render(nullptr,512,448);cave.render(hd.data(),0,0);
  WrinklyCave missing;CHECK(!missing.init("tests/no-wrinkly-assets"));CHECK(!missing.ready());
  WorldMapState state;state.area=static_cast<int>(WorldArea::LakeOrangatanga);state.lakeNode=0;
  WorldMap map;CHECK(map.init(state,"rom/dkc3_ptbr.sfc"));
  for(int i=0;i<40;++i)map.step({},1.f/60);
  WorldMapInput enter;enter.cave=true;map.step(enter,1.f/60);CHECK(map.caveOpen());
  const auto snapshot=map.state();
  map.step({},1.f/60);WorldMapInput travel;travel.right=true;travel.up=true;
  for(int i=0;i<60;++i)map.step(travel,1.f/60);
  CHECK(map.state().area==snapshot.area && map.state().lakeNode==snapshot.lakeNode && map.state().boatX==snapshot.boatX && map.state().boatY==snapshot.boatY);
  std::string launch;CHECK(!map.takeLaunchRequest(launch));
  WorldMapInput save;save.confirm=true;map.step(save,1.f/60);CHECK(map.takeCaveSaveRequest());
  map.step(save,1.f/60);CHECK(!map.takeCaveSaveRequest());
  // Exercise the same persistence consumer used by the Windows app.
  const std::string dir="wrinkly_test_saves";std::filesystem::remove_all(dir);
  Frontend frontend;CHECK(frontend.init(dir,"rom/dkc3_ptbr.sfc"));
  for(int i=0;i<160;++i)frontend.step({},1.f/60);
  FrontendInput ok;ok.start=true;frontend.step(ok,1.f/60);frontend.step({},1.f/60);frontend.step(ok,1.f/60);
  FrontendLaunchRequest request;CHECK(frontend.takeLaunchRequest(request));
  GamePersistentState profile;profile.coins=19;profile.lives=8;
  CHECK(frontend.syncActiveSave("lakeside-limbo",profile,&snapshot));map.acknowledgeCaveSave(true);
  Frontend reopened;CHECK(reopened.init(dir,"rom/dkc3_ptbr.sfc"));CHECK(reopened.slots()[0].persistent.coins==19 && reopened.slots()[0].persistent.lives==8);
  CHECK(reopened.slots()[0].worldMap.area==snapshot.area && reopened.slots()[0].worldMap.lakeNode==snapshot.lakeNode);
  map.render(hd.data(),512,448);
  CHECK(saveBmp32("docs/wrinkly-runtime-saved.bmp",hd.data(),512,448));
  WorldMapInput exit;exit.cancel=true;map.step(exit,1.f/60);CHECK(!map.caveOpen());CHECK(!map.takeCaveSaveRequest());
  std::filesystem::remove_all(dir);
  std::cout<<"WRINKLY_OK HD/original, no separators, enter/exit, frozen map, save edge, persistence reload\n";
}
