#include "core/RomObjectRuntime.h"
#include "core/Game.h"
#include <iostream>
using namespace dkc3;
int main(){
  RomLevelRuntime level;
  if(!level.load({0x25,0x19f0,0},"rom/dkc3_ptbr.sfc"))return 1;
  RomSpawnRuntime spawn;spawn.build(level.placements());
  if(spawn.records().size()!=47)return 2;
  for(size_t i=0;i<47;++i)if(spawn.records()[i].placementIndex!=i ||
     spawn.records()[i].placement.descriptor!=level.placements()[i].descriptor)return 3;
  if(spawn.count(RomSupport::Supported)+spawn.count(RomSupport::Partial)+spawn.count(RomSupport::Unknown)!=47)return 4;
  if(spawn.count(RomSupport::Partial)!=47 || spawn.count(RomSupport::Unknown)!=0 || spawn.count(RomSupport::Supported)!=0)return 14;
  RomLevelRuntime bonusRuntime;RomLakesideBonusVisuals bonus;
  for(int index=1;index<=2;++index){
    if(!bonusRuntime.load(RomLevelRequest{static_cast<uint16_t>(0x4f+index),0x19f0,static_cast<uint8_t>(2+index)},"rom/dkc3_ptbr.sfc") ||
       !bonus.load(index,"rom/dkc3_ptbr.sfc"))return 15;
    if(bonusRuntime.width()!=384 || bonusRuntime.pixels()!=bonus.pixels() ||
       bonusRuntime.foregroundMask()!=bonus.foregroundMask() || bonusRuntime.placements().size()!=static_cast<size_t>(index+1))return 16;
  }
  // Tidal's rooms use the same family codec and FE:0000 pointer table.
  for(int index=0;index<2;++index){
    if(!bonusRuntime.load(RomLevelRequest{static_cast<uint16_t>(0x54+index),0x19f0,static_cast<uint8_t>(5+index)}))return 28;
    if(bonusRuntime.height()!=512 || bonusRuntime.width()<=0 || bonusRuntime.pixels().empty() ||
       bonusRuntime.placements().size()!=size_t(index?7:3) || bonusRuntime.waterSurfaceY()!=408)return 29;
    if(bonusRuntime.startPoint()!=(index?std::pair(53,240):std::pair(32,480)))return 30;
  }
  if(bonusRuntime.load(RomLevelRequest{0x54,0x19f0,6}) || bonusRuntime.valid() || !bonusRuntime.pixels().empty())return 31;
  if(bonusRuntime.load(RomLevelRequest{512,0x19f0,5}) || bonusRuntime.load(RomLevelRequest{0x54,0x19f0,7}))return 32;
  RomImage rom;if(!rom.load("rom/dkc3_ptbr.sfc"))return 17;
  RomScenarioLayout pierLayout,millLayout,murkyLayout;
  if(!decodeRomScenarioLayout(rom,0x19f0,0,pierLayout) ||
     pierLayout.familyIndex!=9u || pierLayout.familyConfigAddress!=0xB7B431u ||
     pierLayout.terrainQueryHandler!=0xB7CD1Fu || pierLayout.terrainVramBase!=0x7800u ||
     pierLayout.shape!=0u || pierLayout.xBegin!=0u || pierLayout.xEnd!=0x1860u ||
     pierLayout.yBegin!=0u || pierLayout.yEnd!=0x0200u ||
     pierLayout.levelMap.size()!=0x6A60u || pierLayout.map32.size()!=0x1F80u ||
     pierLayout.terrainDefinitions.size()!=576u || pierLayout.foregroundGfx.size()!=0x5D60u)return 33;
  if(!decodeRomScenarioLayout(rom,0x198d,0,millLayout) ||
     millLayout.familyIndex!=5u || millLayout.familyConfigAddress!=0xB7B302u ||
     millLayout.terrainQueryHandler!=0xB7CB2Bu || millLayout.terrainVramBase!=0x7800u ||
     millLayout.assetHeaderAddress!=0xE3E3B0u || millLayout.levelStreamAddress!=0xE3E3B9u ||
     millLayout.map32StreamAddress!=0xE41148u || millLayout.terrainDefinitionsAddress!=0xE43175u ||
     millLayout.foregroundStreamAddress!=0xE43549u || millLayout.shape!=7u ||
     millLayout.xBegin!=0u || millLayout.xEnd!=0x0A00u || millLayout.yBegin!=0u || millLayout.yEnd!=0x07E0u ||
     millLayout.levelCompressedBytes!=0x2D8Fu || millLayout.map32CompressedBytes!=0x202Du ||
     millLayout.foregroundCompressedBytes!=0x53B9u || millLayout.levelMap.size()!=0x9740u ||
     millLayout.map32.size()!=0x4400u || millLayout.terrainDefinitions.size()!=0x03D4u ||
     millLayout.foregroundGfx.size()!=0x7120u)return 34;
  if(!decodeRomScenarioLayout(rom,0x1998,2,murkyLayout) || murkyLayout.familyIndex!=5u ||
     murkyLayout.familyConfigAddress!=millLayout.familyConfigAddress || murkyLayout.shape!=7u ||
     murkyLayout.yBegin!=0x12C0u || murkyLayout.yEnd!=0x1B20u)return 35;
  uint16_t mapWord=0;
  if(!romScenarioMapMetatile(pierLayout,48,480,mapWord)||mapWord!=0x0098u)return 36;
  if(!romScenarioMapMetatile(millLayout,48,1901,mapWord)||mapWord!=0x0093u)return 37;
  if(!romScenarioMapMetatile(millLayout,848,2096,mapWord)||mapWord!=0x0106u)return 38;
  RomScenarioLayout squealsLayout;
  if(!decodeRomScenarioLayout(rom,0x198d,1,squealsLayout)||squealsLayout.yBegin!=0x07E0u ||
     !romScenarioMapMetatile(squealsLayout,48,2637,mapWord)||mapWord!=0x0093u)return 39;
  auto unsupportedShape=millLayout;unsupportedShape.shape=3;
  if(romScenarioMapMetatile(unsupportedShape,48,1901,mapWord))return 40;
  // Base-script calls return; the last FF assignment determines the actual type.
  RomSpawnSpec spec;
  for(uint16_t descriptor:{0x718a,0x719e}){
    if(!decodeRomSpawnScript(rom,descriptor,spec)||spec.spriteId!=0x02c4||spec.animationId!=0x015c)return 22;
  }
  if(!decodeRomSpawnScript(rom,0x719e,spec)||spec.word(0x44)!=0x00a0)return 23;
  if(!decodeRomSpawnScript(rom,0x959f,spec)||spec.spriteId!=0x0434||spec.animationId!=0x0277||spec.word(0x6c)!=2)return 24;
  if(!decodeRomSpawnScript(rom,0x9598,spec)||spec.spriteId!=0x0434||spec.word(0x6c)!=3)return 25;
  // F4 decodes signed speeds and relative limits using the placement origin.
  if(!decodeRomSpawnScript(rom,0x78ff,spec,848,585)||spec.spriteId!=0x02f8)return 26;
  if(spec.word(0x12)!=848||spec.word(0x16)!=585)return 27;
  std::vector<RomLevelPlacement> decoded;
  auto truncated=level.placementData();truncated.resize(7);
  if(decodeRomPlacements(rom,truncated,decoded) || !decoded.empty())return 18;
  auto unterminated=level.placementData();unterminated.resize(unterminated.size()-2);
  if(decodeRomPlacements(rom,unterminated,decoded) || !decoded.empty())return 19;
  if(!decodeRomPlacements(rom,level.placementData(),decoded) || decoded.size()!=47)return 20;
  Game game;if(!game.init("assets/levels/lakeside-limbo/lakeside-limbo.level"))return 5;
  if(game.romSpawnRuntime().records().size()!=47)return 6;
  if(!level.load({0x27,0x19f0,2},"rom/dkc3_ptbr.sfc") || !level.valid() ||
     level.width()!=7968 || level.height()!=512 || level.placements().size()!=61 || level.waterSurfaceY()!=408)return 7;
  if(level.load({0x27,0x19f0,0},"rom/dkc3_ptbr.sfc") || level.valid() || !level.pixels().empty())return 21;
  if(level.load({0x25,0x19f0,1},"rom/dkc3_ptbr.sfc"))return 8;
  if(level.load({0x25,0x1234,0},"rom/dkc3_ptbr.sfc"))return 9;
  if(!level.load({0x25,0x19f0,0},"rom/dkc3_ptbr.sfc"))return 10;
  spawn.build({});if(!spawn.records().empty())return 11;
  for(uint16_t family:{0x19f0,0x198d,0x1998,0x19da})if(!findRomScenarioCodec(family))return 12;
  if(findRomObject(0xffff).support!=RomSupport::Unknown)return 13;
  std::cout<<"ROM_RUNTIME_OK generic B7 scenario layout/map geometry (PIER+MILL); six PIER submaps; ROM placement pointers; request guards, reload, registry, game integration\n";
}
