#include "core/Player.h"
#include "core/RomTerrain.h"
#include <iostream>
#define CHECK(x) do{if(!(x)){std::cerr<<"AIR_WALL_FAIL "<<__LINE__<<" "<<#x<<"\n";return 1;}}while(0)
int main(){using namespace dkc3;
 std::vector<uint8_t> map(96,0),defs(576,0),attrs(168,0);defs[4]=defs[6]=1;
 auto tile=[&](int column,int row,int id){map[(column*16+row)*2]=static_cast<uint8_t>(id);};
 for(int row=6;row<=9;++row)tile(1,row,1);
 RomPierTerrain terrain;CHECK(terrain.load(map,defs,attrs,3));
 CHECK(!terrain.solidBodyPoint(32,192)&&terrain.solidBodyPoint(32,193)&&terrain.solidBodyPoint(63,319));
 CHECK(!terrain.solidBodyPoint(-1,220)&&!terrain.solidBodyPoint(96,220)&&!terrain.solidBodyPoint(32,-1)&&!terrain.solidBodyPoint(32,512));
 RomMotionProfile dixie,kiddy;CHECK(loadRomMotionProfiles("rom/dkc3_ptbr.sfc",dixie,kiddy));
 auto player=[&](float x,float y,float vx,float vy){Player p;p.nativeMotion=dixie;p.width=18;p.height=10;p.pos={x,y};p.vel={vx,vy};p.nativeGravity=dixie.risingGravity;p.nativeControlFlags=4;p.motion=PlayerMotion::Air;return p;};
 InputState in;in.right=true;in.run=true;in.jump=true;
 auto p=player(14,220,180,-240);updatePlayer(p,in,1.f/60,nullptr,0,nullptr,0,&terrain);
 CHECK(p.nativeAirWallHits==1&&p.nativeWallHits==1&&p.pos.x==14&&p.vel.x==0&&p.vel.y<0&&p.pos.y<220&&!p.grounded&&p.jumping);
 CHECK(p.nativeBlockedTarget==768&&p.nativeBlockedVelocity>0&&(p.nativeTerrainFlags&2));
 in.right=false;in.left=true;updatePlayer(p,in,1.f/60,nullptr,0,nullptr,0,&terrain);CHECK(p.pos.x<14&&p.nativeAirWallHits==1&&p.vel.y<0);
 // Kiddy body dimensions and subdivided fixed-tick updates share the contact.
 in.left=false;in.right=true;auto full=player(9,220,180,-240);full.nativeMotion=kiddy;full.width=23;full.height=38;auto split=full;
 updatePlayer(full,in,1.f/60,nullptr,0,nullptr,0,&terrain);
 updatePlayer(split,in,1.f/120,nullptr,0,nullptr,0,&terrain);CHECK(split.nativeAirWallHits==0);
 updatePlayer(split,in,1.f/120,nullptr,0,nullptr,0,&terrain);
 CHECK(full.nativeAirWallHits==1&&split.nativeAirWallHits==1&&full.pos.x==split.pos.x&&full.pos.y==split.pos.y&&full.vel.y==split.vel.y);
 // Falling contact also preserves vertical movement.
 in.left=false;in.right=true;in.jump=false;p=player(14,240,180,120);updatePlayer(p,in,1.f/60,nullptr,0,nullptr,0,&terrain);
 CHECK(p.nativeAirWallHits==1&&p.pos.x==14&&p.vel.x==0&&p.vel.y>0&&p.pos.y>240&&!p.grounded);
 // Sweep catches a wall even when the final edge is beyond its far side.
 p=player(14,220,6000,-240);updatePlayer(p,in,1.f/60,nullptr,0,nullptr,0,&terrain);CHECK(p.nativeAirWallHits==1&&p.pos.x==14);
 // Mirror leftward contact.
 map.assign(96,0);for(int row=6;row<=9;++row)tile(0,row,1);CHECK(terrain.load(map,defs,attrs,3));
 in.right=false;in.left=true;p=player(32,220,-180,-240);updatePlayer(p,in,1.f/60,nullptr,0,nullptr,0,&terrain);
 CHECK(p.nativeAirWallHits==1&&p.pos.x==32&&p.nativeBlockedVelocity<0&&p.vel.y<0);
 // A thin strip at the bottom of a tile is caught, even away from body center.
 map.assign(96,0);defs[4]=defs[6]=8;tile(1,7,1);CHECK(terrain.load(map,defs,attrs,3));
 CHECK(!terrain.solidBodyPoint(32,252)&&terrain.solidBodyPoint(32,253));
 in.left=false;in.right=true;p=player(14,250,180,0);p.height=6;updatePlayer(p,in,1.f/60,nullptr,0,nullptr,0,&terrain);CHECK(p.nativeAirWallHits==1);
 // Rope, decorative and conditional ceiling descriptors aren't wall volume.
 for(int shape:{64,75,76,99}){defs[4]=defs[6]=static_cast<uint8_t>(shape);CHECK(terrain.load(map,defs,attrs,3));p=player(14,250,180,0);updatePlayer(p,in,1.f/60,nullptr,0,nullptr,0,&terrain);CHECK(p.nativeAirWallHits==0&&p.pos.x>14);}
 // Empty space permits travel; existing overlap may move out of a wall.
 defs[4]=defs[6]=1;map.assign(96,0);tile(1,7,1);CHECK(terrain.load(map,defs,attrs,3));
 p=player(62,230,180,0);updatePlayer(p,in,1.f/60,nullptr,0,nullptr,0,&terrain);CHECK(p.nativeAirWallHits==0&&p.pos.x>62);
 map.assign(96,0);for(int c=0;c<3;++c)tile(c,10,1);CHECK(terrain.load(map,defs,attrs,3));
 p=player(8,280,0,120);in={};for(int i=0;i<30&&!p.grounded;++i)updatePlayer(p,in,1.f/60,nullptr,0,nullptr,0,&terrain);
 CHECK(p.grounded&&p.pos.y==311&&p.nativeAirWallHits==0);
 std::cout<<"NATIVE_AIR_WALL_OK rising/falling, reverse, left/right, sweep, thin strip, exclusions, escape, landing\n";
}
