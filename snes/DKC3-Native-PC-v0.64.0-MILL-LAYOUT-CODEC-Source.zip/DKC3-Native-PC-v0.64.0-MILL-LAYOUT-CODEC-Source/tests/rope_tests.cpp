#include "core/Game.h"
#include "core/RomTerrain.h"
#include <array>
#include <cmath>
#include <iostream>
#include <stdexcept>
using namespace dkc3;
#define CHECK(x) do{if(!(x)){std::cerr<<"ROPE_FAIL line "<<__LINE__<<" "<<#x<<"\n";return 1;}}while(0)
// Test-only bounded 16-bit instruction execution of the ROM's A4A0..A4C8.
// No CPU/hardware interpreter is linked into the game library.
struct Probe {
 std::array<uint16_t,65536> mem{};const std::vector<uint8_t>& rom;
 uint16_t a=0,y=0,pc=0;bool carry=false,zero=false;
 explicit Probe(const std::vector<uint8_t>& b):rom(b){}
 uint8_t byte(){return rom[0x380000u+pc++];}
 uint16_t word(){const auto l=byte();return static_cast<uint16_t>(l|(byte()<<8));}
 void load(uint16_t v){a=v;zero=a==0;}
 void run(){pc=0xa4a0;carry=false;zero=false;
  for(int steps=0;steps<40;++steps){
   const auto op=byte();switch(op){
    case 0xa0:y=word();zero=y==0;break;
    case 0xa5:load(mem[byte()]);break;
    case 0xb5:load(mem[0x1000+byte()]);break;
    case 0xd5:{const auto v=mem[0x1000+byte()];carry=a>=v;zero=a==v;break;}
    case 0xb0:case 0x90:case 0xf0:case 0xd0:{const int8_t delta=static_cast<int8_t>(byte());const bool take=op==0xb0?carry:op==0x90?!carry:op==0xf0?zero:!zero;if(take)pc=static_cast<uint16_t>(pc+delta);break;}
    case 0x94:mem[0x1000+byte()]=y;break;
    case 0x95:mem[0x1000+byte()]=a;break;
    case 0x74:mem[0x1000+byte()]=0;break;
    case 0x9c:mem[word()]=0;break;
    case 0x18:carry=false;break;
    case 0x38:carry=true;break;
    case 0x60:return;
    default:throw std::runtime_error("unsupported ROM probe opcode");
   }
  }throw std::runtime_error("ROM probe did not terminate");
 }
};
int main(){
 RomImage image;CHECK(image.load("rom/dkc3_ptbr.sfc")&&image.info().crc32==0x448eec19u);Probe cpu(image.bytes());uint32_t rng=1;unsigned cases=0;
 auto random=[&](){rng=rng*1664525u+1013904223u;return static_cast<uint16_t>(rng>>8);};
 for(unsigned i=0;i<80000;++i){uint16_t lo=random(),hi=random();if(lo>hi)std::swap(lo,hi);const uint16_t x=i%5==0?lo:i%5==1?hi:random(),frac=random(),target=random(),vel=random(),direction=random();
  cpu.mem[0x3a]=lo;cpu.mem[0x3c]=hi;cpu.mem[0x1012]=x;cpu.mem[0x1010]=frac;cpu.mem[0x1030]=target;cpu.mem[0x102a]=vel;cpu.mem[0x105c]=direction;cpu.mem[0x1036]=0;cpu.mem[0x0507]=99;cpu.run();
  const auto r=romHorizontalRopeClamp(x,frac,lo,hi,target,vel,direction);
  CHECK(r.x==cpu.mem[0x1012]&&r.fraction==cpu.mem[0x1010]&&r.target==cpu.mem[0x1030]&&r.velocity==cpu.mem[0x102a]&&r.direction==cpu.mem[0x105c]&&r.stopped==!cpu.carry);++cases;
 }
 CHECK(image.bytes()[0x39f584]==0x4a&&image.bytes()[0x39f585]==0x4a&&image.bytes()[0x39f586]==0x4a&&image.bytes()[0x39f587]==0x60);
 CHECK(romInterpolateSpeed(0,128,11)==16&&romInterpolateSpeed(0,-128,11)==-16&&romInterpolateSpeed(127,128,11)==128);
 RomLakesideBonusVisuals one,two;CHECK(one.load(1,"rom/dkc3_ptbr.sfc")&&two.load(2,"rom/dkc3_ptbr.sfc"));CHECK(one.width()==384&&two.width()==384);
 CHECK(one.startPoint()==std::make_pair(16,233)&&two.startPoint()==std::make_pair(40,361));
 CHECK(one.terrain().ropes().size()==1&&two.terrain().ropes().size()==1);
 const auto r1=one.terrain().ropes()[0],r2=two.terrain().ropes()[0];CHECK(r1.x==64&&r1.y==145&&r1.width==256&&r2.x==32&&r2.y==273&&r2.width==192);
 RomMotionProfile dixie,kiddy;CHECK(loadRomMotionProfiles("rom/dkc3_ptbr.sfc",dixie,kiddy));
 Player p;p.nativeMotion=dixie;p.pos={100,151};InputState up;up.up=true;updateRomRopePlayer(p,up,1.f/60,one.terrain());CHECK(p.nativeRope==0&&p.motion==PlayerMotion::Hang&&p.nativeRopeGrabs==1);
 InputState right;right.right=true;Player low=p;
 for(int i=0;i<600;++i)updateRomRopePlayer(p,right,1.f/60,one.terrain());
 CHECK(p.pos.x+p.width*.5f<321.0f&&p.nativeRopeStops>0&&std::fabs(p.pos.y-151)<0.001f);
 const float beforeY=p.pos.y;for(int i=0;i<30;++i)updateRomRopePlayer(p,up,1.f/60,one.terrain());CHECK(p.pos.y==beforeY);
 Player a=low,b=low;for(int i=0;i<120;++i)updateRomRopePlayer(a,right,1.f/60,one.terrain());for(int i=0;i<60;++i)updateRomRopePlayer(b,right,1.f/30,one.terrain());CHECK(std::fabs(a.pos.x-b.pos.x)<0.001f&&a.vel.x==b.vel.x);
 InputState down;down.down=true;down.jump=true;updateRomRopePlayer(a,down,1.f/60,one.terrain());CHECK(a.motion==PlayerMotion::Air&&a.nativeRope==-1&&a.vel.y>0);
 InputState jump;jump.jump=true;jump.left=true;updateRomRopePlayer(b,jump,1.f/60,one.terrain());CHECK(b.nativeRope==-1&&b.vel.x==-150);
 Player fake;fake.nativeMotion=dixie;fake.pos={20,180};updateRomRopePlayer(fake,up,1.f/60,one.terrain());CHECK(fake.motion!=PlayerMotion::Hang&&fake.nativeRope==-1);
 for(int character=0;character<2;++character){Game game;GamePersistentState persistent;persistent.activeCharacter=character?CharacterId::Kiddy:CharacterId::Dixie;CHECK(game.init("assets/levels/lakeside-limbo/lakeside-limbo.level",&persistent));
  auto& player=const_cast<Player&>(game.player());const RuntimeBarrelCannon* barrel=nullptr;for(const auto& v:game.barrelCannons())if(v.role==BarrelCannonRole::BonusEntry1){barrel=&v;break;}CHECK(barrel);
  player.pos={barrel->pos.x,barrel->pos.y};player.vel={};game.step(up,1.f/60);CHECK(game.inBonus()&&game.world().width==384&&game.player().motion!=PlayerMotion::Hang);
  InputState none;for(int i=0;i<10;++i)game.step(none,1.f/60);CHECK(game.player().grounded);
  // Real input from the authored bonus spawn: run+jump right, release jump,
  // catch the rope on descent. No positioning after room entry.
  InputState travel;travel.right=true;travel.run=true;
  for(int i=0;i<20;++i){game.step(travel,1.f/60);}travel.jump=true;
  for(int i=0;i<16;++i){game.step(travel,1.f/60);}travel.jump=false;
  for(int i=0;i<55&&game.player().nativeRope<0;++i)game.step(travel,1.f/60);
  CHECK(game.player().nativeRope==0&&game.player().nativeRopeGrabs>0&&game.bonusCollected()>0);
 }
 std::cout<<"NATIVE_ROPE_OK ROM clamp "<<cases<<" cases, original bonus bounds, geometry, grab, edges, drop, dt, both Kongs live entry\n";
}
