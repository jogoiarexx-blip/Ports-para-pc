#include "core/RomTerrain.h"
extern "C" void rising_response(unsigned position,unsigned ceiling,unsigned slope,unsigned next,unsigned nextSlope,unsigned flags,uint16_t* out){
 auto r=dkc3::romRisingCollision(position,ceiling,slope,next,nextSlope,flags);out[0]=r.position;out[1]=r.velocity;out[2]=r.targetVelocity;out[3]=r.nextSurface;out[4]=r.distance;out[5]=r.flags;out[6]=r.attributes;
}
