"""Chronological trace comparisons, including reconvergence and invalid evidence."""
import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'tools'))
import compare_native_traces as traces


def frame(number, **state):
    state = state or {'player.x': 'f32:3f800000', 'objects.0.active': '1'}
    return {'schema': 'dkc3.trace.v1', 'frame': number, 'input': 0,
            'state': state, 'state_hash': traces.state_hash(state),
            'calls': [], 'events': [], 'metrics': {}, 'provenance': 'native-runtime'}


class NativeTraceTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.left = Path(self.tmp.name) / 'left.jsonl'
        self.right = Path(self.tmp.name) / 'right.jsonl'

    def write(self, path, records):
        path.write_text(''.join(json.dumps(x, ensure_ascii=False) + '\n' for x in records), encoding='utf-8')

    def compare(self, left, right, **options):
        self.write(self.left, left)
        self.write(self.right, right)
        return traces.compare(self.left, self.right, **options)

    def test_canonical_hash_utf8_sorted_with_null(self):
        # Independent published FNV-1a algorithm, explicit canonical byte stream.
        value = 0xcbf29ce484222325
        for byte in b'a\x00<unavailable>\x00z\x001\x00\xc3\xa9\x002\x00':
            value = ((value ^ byte) * 0x100000001b3) & 0xffffffffffffffff
        self.assertEqual(traces.state_hash({'é': '2', 'z': '1', 'a': None}), f'{value:016x}')
        self.assertEqual(traces.state_hash({'z': '1', 'a': None}), traces.state_hash({'a': None, 'z': '1'}))

    def test_match_makes_native_evidence_limit_explicit(self):
        result = self.compare([frame(0), frame(1)], [frame(0), frame(1)])
        self.assertEqual(result['status'], 'match')
        self.assertEqual(result['frames'], {'left': 2, 'right': 2, 'aligned': 2})
        self.assertFalse(result['snes_reference_proven'])
        self.assertIn('native', traces.render_markdown(result))

    def test_first_difference_before_reconvergence_and_all_variables(self):
        left = [frame(0), frame(1, **{'player.x': '1', 'objects.0.active': '1', 'removed': None}), frame(2)]
        right = copy.deepcopy(left)
        right[1]['state'] = {'player.x': '2', 'objects.0.active': '0', 'added': None}
        right[1]['state_hash'] = traces.state_hash(right[1]['state'])
        result = self.compare(left, right)
        self.assertEqual(result['first_difference']['frame'], 1)
        self.assertEqual([d['field'] for d in result['first_difference']['variables']],
                         ['added', 'objects.0.active', 'player.x', 'removed'])
        removed = result['first_difference']['variables'][-1]
        self.assertTrue(removed['left']['present'])
        self.assertFalse(removed['right']['present'])

    def test_earlier_state_difference_wins_over_length(self):
        result = self.compare([frame(0), frame(1, x='1')], [frame(0), frame(1, x='2'), frame(2)])
        self.assertEqual(result['first_difference']['kind'], 'state')
        self.assertEqual(result['first_difference']['frame'], 1)
        self.assertEqual(result['frames']['right'], 3)

    def test_hash_collision_from_null_sentinel_cannot_hide_difference(self):
        left, right = frame(0, x=None), frame(0, x='<unavailable>')
        self.assertEqual(left['state_hash'], right['state_hash'])
        result = self.compare([left], [right])
        self.assertEqual(result['first_difference']['variables'][0]['field'], 'x')

    def test_reference_label_does_not_authenticate_snes_execution(self):
        reference = frame(0)
        reference['provenance'] = 'reference-runtime'
        reference['calls'] = [{'function': 'kong_update', 'kind': 'reference',
                              'pc': 0xB88000, 'opcode': 0x22, 'bank': 0xB8, 'rom_reads': []}]
        result = self.compare([reference], [frame(0)])
        self.assertEqual(result['status'], 'match')
        self.assertFalse(result['snes_reference_proven'])

    def test_gapped_tail_and_nonfinite_metadata_are_invalid(self):
        for bad in [frame(3), frame(1)]:
            if bad['frame'] == 1:
                bad['metrics']['seconds'] = float('inf')
            with self.assertRaises(ValueError):
                self.compare([frame(0), frame(1)], [frame(0), bad])

    def test_truncation_points_to_missing_frame(self):
        result = self.compare([frame(0)], [frame(0), frame(1)])
        self.assertEqual(result['first_difference']['kind'], 'missing_frame')
        self.assertEqual(result['first_difference']['frame'], 1)
        self.assertEqual(result['first_difference']['missing_side'], 'left')

    def test_input_mismatch_is_invalid_even_after_state_difference(self):
        right = [frame(0, x='2'), frame(1)]
        right[1]['input'] = 1
        with self.assertRaisesRegex(ValueError, 'input.*frame 1'):
            self.compare([frame(0, x='1'), frame(1)], right)

    def test_invalid_tail_not_hidden_by_first_divergence(self):
        right = [frame(0, x='2'), frame(1)]
        right[1]['state_hash'] = '0000000000000000'
        with self.assertRaisesRegex(ValueError, 'hash'):
            self.compare([frame(0, x='1'), frame(1)], right)

    def test_schema_frames_provenance_hash_and_unknown_state_are_rejected(self):
        changes = [('schema', 'wrong'), ('frame', 1), ('frame', True),
                   ('provenance', 'unknown'), ('state_hash', 'abc'),
                   ('state', {'x': 1}), ('state', {'x': 'NaN'}),
                   ('state', {'x': 'f32:7fc00000'})]
        for key, value in changes:
            with self.subTest(key=key, value=value):
                bad = frame(0)
                bad[key] = value
                with self.assertRaises(ValueError):
                    self.compare([frame(0)], [bad])
        changed = [frame(0), frame(1)]
        changed[1]['provenance'] = 'reference-runtime'
        with self.assertRaisesRegex(ValueError, 'provenance'):
            self.compare(changed, changed)

    def test_native_calls_cannot_claim_pc_opcode_bank(self):
        for key, value in [('pc', 0xB88000), ('opcode', 0x22), ('bank', 0xB8)]:
            bad = frame(0)
            bad['calls'] = [{'function': 'Game::step', 'kind': 'native',
                             'pc': None, 'opcode': None, 'bank': None, 'rom_reads': []}]
            bad['calls'][0][key] = value
            with self.assertRaisesRegex(ValueError, 'native'):
                self.compare([bad], [bad])

    def test_context_candidate_functions_and_explicit_rom_correlation(self):
        left = [frame(0), frame(1, **{'objects.0.active': '1'})]
        right = [frame(0), frame(1, **{'objects.0.active': '0'})]
        left[0]['calls'] = [{'function': 'Object::step', 'kind': 'native', 'pc': None,
                            'opcode': None, 'bank': None, 'source_pc': 0xB88000,
                            'rom_reads': [{'address': 0xC08200, 'state_keys': ['objects.0.active']}]}]
        left[1]['events'] = [{'type': 'object_transition', 'object_id': 0}]
        result = self.compare(left, right, context=2)
        details = result['first_difference']
        self.assertEqual(details['candidate_functions'], ['Object::step'])
        self.assertEqual(details['related_rom_reads'][0]['read']['address'], 0xC08200)
        self.assertEqual(details['context']['left'][1]['events'][0]['type'], 'object_transition')
        self.assertFalse(details['cause_confirmed'])

    def test_grouped_runtime_object_keys_identify_individual_object(self):
        left, right = frame(0, **{'objects.enemies.3.active': '1'}), frame(0, **{'objects.enemies.3.active': '0'})
        left['calls'] = [{'function': 'Game::enemies', 'kind': 'native', 'pc': None,
                         'opcode': None, 'bank': None, 'object_key': 'objects.enemies.3',
                         'rom_reads': [{'address': 0xC00000}]}]
        first = self.compare([left], [right])['first_difference']
        self.assertEqual(first['affected_object_keys'], ['objects.enemies.3'])
        self.assertEqual(len(first['related_rom_reads']), 1)

    def test_empty_bad_utf8_duplicate_keys_truncated_json_and_nan_are_invalid(self):
        self.write(self.left, [frame(0)])
        for raw in [b'', b'\xff\n', b'{"schema":', b'{"a":1,"a":2}\n', b'{"a":NaN}\n']:
            with self.subTest(raw=raw):
                self.right.write_bytes(raw)
                with self.assertRaises(ValueError):
                    traces.compare(self.left, self.right)

    def test_cli_exit_codes_json_and_markdown(self):
        self.write(self.left, [frame(0, x='1')])
        self.write(self.right, [frame(0, x='2')])
        output = Path(self.tmp.name) / 'report.json'
        markdown = Path(self.tmp.name) / 'report.md'
        command = [sys.executable, str(ROOT / 'tools/compare_native_traces.py'),
                   str(self.left), str(self.right), '--json', str(output), '--markdown', str(markdown)]
        different = subprocess.run(command, capture_output=True, text=True)
        self.assertEqual(different.returncode, 1, different.stderr)
        self.assertEqual(json.loads(output.read_text())['first_difference']['frame'], 0)
        self.assertIn('candidate', markdown.read_text().lower())
        self.right.write_bytes(self.left.read_bytes())
        self.assertEqual(subprocess.run(command, capture_output=True).returncode, 0)
        self.right.write_text('{')
        self.assertEqual(subprocess.run(command, capture_output=True).returncode, 2)

    def test_csv_earlier_difference_wins_over_length_and_fields_preserved(self):
        self.left.write_text('frame,x,y,input\n0,1,2,0\n1,3,2,0\n')
        self.right.write_text('frame,x,y,input\n0,1,2,0\n1,4,2,0\n2,4,2,0\n')
        command = [sys.executable, str(ROOT / 'tools/compare_replays.py'), str(self.left), str(self.right)]
        result = subprocess.run(command, capture_output=True, text=True)
        self.assertEqual(result.returncode, 1)
        self.assertIn('frame=1 field=x', result.stdout)
        selected = subprocess.run(command + ['--fields', 'y'], capture_output=True, text=True)
        self.assertEqual(selected.returncode, 1)
        self.assertIn('frame=2', selected.stdout)
        self.assertIn('selected', selected.stdout)


if __name__ == '__main__':
    unittest.main(verbosity=2)
