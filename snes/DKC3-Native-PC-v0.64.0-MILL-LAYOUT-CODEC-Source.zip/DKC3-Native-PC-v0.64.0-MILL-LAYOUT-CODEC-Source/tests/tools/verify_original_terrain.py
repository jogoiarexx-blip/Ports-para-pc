# Test-only bounded 65816 oracle. The game runtime executes only native C++.
import ctypes,subprocess,tempfile,os,struct,random
from pathlib import Path
root=Path(__file__).resolve().parents[2]
os.chdir(root)
rom=(root/'rom/dkc3_ptbr.sfc').read_bytes()
with tempfile.TemporaryDirectory() as tmp:
 so=Path(tmp)/'terrain.so'
 subprocess.run([os.environ.get('CXX','g++'),'-std=c++20','-O2','-shared','-fPIC','-I'+str(root/'src'),str(root/'tests/tools/terrain_oracle_shim.cpp'),str(root/'src/core/RomTerrain.cpp'),str(root/'src/core/RomData.cpp'),'-o',str(so)],check=True)
 lib=ctypes.CDLL(str(so));lib.terrain_sample.restype=ctypes.c_uint32
 level=(ctypes.c_uint8*6240)();assert lib.terrain_level(level)
 lib.terrain_query.argtypes=[ctypes.c_uint,ctypes.c_uint,ctypes.POINTER(ctypes.c_uint16)]
 def original(tile,xpos,qy,query=False):
  mem=bytearray(65536);a=x=0;y=2;pc=0xcf68;c=n=z=v=0;stack=[]
  def wr(at,val):mem[at&65535]=val&255;mem[(at+1)&65535]=(val>>8)&255
  def rd(at):return mem[at&65535]|mem[(at+1)&65535]<<8
  def bus(at):
   if at<65536:return rd(at)
   at&=0x3fffff;return rom[at]|rom[at+1]<<8
  def fetch():
   nonlocal pc
   b=rom[0x370000+pc];pc=(pc+1)&65535;return b
  def word():return fetch()|fetch()<<8
  def nz(val):
   nonlocal n,z
   n=bool(val&32768);z=val==0;return val
  wr(0x8c,0x1000);mem[0x8e]=0;wr(0x1002,tile);wr(0x90,0x4a01);mem[0x92]=0xe5;wr(0x94,144);wr(0x9a,xpos);wr(0x1c,qy)
  if query:
   pc=0xcd1f;mem[0x2000:0x2000+len(level)]=bytes(level);wr(0x8c,0x2000);wr(0x1a,xpos)
  for _ in range(800):
   op=fetch()
   if op==0xa5:a=nz(rd(fetch()))
   elif op==0x85:wr(fetch(),a)
   elif op==0xb7:
    dp=fetch();a=nz(bus((rd(dp)|(mem[dp+2]<<16))+y))
   elif op==0xbb:x=nz(y)
   elif op==0x9b:y=nz(x)
   elif op==0xa8:y=nz(a)
   elif op==0xaa:x=nz(a)
   elif op==0xa6:x=nz(rd(fetch()))
   elif op==0xbf:
    at=word()|fetch()<<16;a=nz(bus(at+x))
   elif op==0x49:a=nz(a^word())
   elif op==0x29:a=nz(a&word())
   elif op in (0xc9,0xc5):
    b=word() if op==0xc9 else rd(fetch());c=a>=b;nz((a-b)&65535)
   elif op in (0x89,0x24):
    b=word() if op==0x89 else rd(fetch());z=(a&b)==0
    if op==0x24:v=bool(b&0x4000);n=bool(b&0x8000)
   elif op==0x0a:c=bool(a&32768);a=nz((a<<1)&65535)
   elif op==0x4a:c=a&1;a=nz(a>>1)
   elif op==0xc8:y=nz((y+1)&65535)
   elif op==0x88:y=nz((y-1)&65535)
   elif op==0x98:a=nz(y)
   elif op==0x64:wr(fetch(),0)
   elif op==0x48:stack.append(a)
   elif op==0x68:a=nz(stack.pop())
   elif op==0x4c:pc=word()
   elif op==0xbd:a=nz(bus(0xb70000+((word()+x)&65535)))
   elif op==0xc0:
    b=word();c=y>=b;nz((y-b)&65535)
   elif op==0x65:
    b=rd(fetch());ss=a+b+c;c=ss>65535;a=nz(ss&65535)
   elif op==0x14:
    at=fetch();z=(a&rd(at))==0;wr(at,rd(at)&(~a&65535))
   elif op==0x38:c=1
   elif op==0x18:c=0
   elif op==0x3a:a=nz((a-1)&65535)
   elif op==0x1a:a=nz((a+1)&65535)
   elif op==0xa9:a=nz(word())
   elif op==0x69:
    b=word();s=a+b+c;c=s>65535;a=nz(s&65535)
   elif op==0xe9:
    b=word();s=a-b-(not c);c=s>=0;a=nz(s&65535)
   elif op==0x05:a=nz(a|rd(fetch()))
   elif op==0x09:a=nz(a|word())
   elif op==0x04:
    at=fetch();z=(a&rd(at))==0;wr(at,rd(at)|a)
   elif op==0x20:at=word();stack.append(pc);pc=at
   elif op==0x6c:pc=rd(word())
   elif op in (0xf0,0xd0,0x90,0xb0,0x50,0x30,0x10,0x80):
    rel=fetch();rel=rel if rel<128 else rel-256
    if {0xf0:z,0xd0:not z,0x90:not c,0xb0:c,0x50:not v,0x30:n,0x10:not n,0x80:True}[op]:pc=(pc+rel)&65535
   elif op==0x6b:return (a,rd(0xa0),rd(0xa2),rd(0xa4),rd(0xa6))
   elif op==0x60:
    if stack:pc=stack.pop()
    else:return (rd(0xa0)<<16)|a
   else:raise RuntimeError((hex(pc-1),hex(op)))
  raise RuntimeError('instruction limit')
 # All static/conditional shapes and descriptors present in Lakeside main.
 descriptors=[0,1,3,6,0x4040,18,20,22,24,75,76,77]
 count=0
 for left in descriptors:
  for flip in (0,0x8000):
   for tileflip in (0,0x4000,0x8000,0xc000):
    # Use a synthetic copy of collision entry 1 in the oracle ROM.
    work=bytearray(rom);struct.pack_into('<HH',work,0x254a05,left|flip,6);rom=bytes(work)
    for x in range(32):
     for qy in range(32):
      t=1|tileflip;expected=original(t,x,qy);actual=lib.terrain_sample(t,left|flip,6,x,qy)
      assert expected==actual,(hex(t),hex(left|flip),x,qy,hex(expected),hex(actual))
      count+=1
 for t in (0,144,255,0x4000,0x4090):
  assert original(t,0,0)==lib.terrain_sample(t,0,0,0,0);count+=1
 print(f'ROM_TERRAIN_ORACLE_PASS {count} height/attribute comparisons against B7:CF68 and Pier shape instructions')

 # Real, unmodified Pier submap: boundaries and randomized original queries.
 rom=(root/'rom/dkc3_ptbr.sfc').read_bytes()
 query_count=0;out=(ctypes.c_uint16*5)();rng=random.Random(38)
 cases=[(x,y) for x in (0,1,15,16,31,32,80,1344,3344,6239) for y in (0,255,256,257,287,288,289,511,512,767,768,1024)]
 cases += [(rng.randrange(6240),rng.randrange(224,800)) for _ in range(20000)]
 for x,y in cases:
  expected=original(0,x,y,True);assert lib.terrain_query(x,y,out)
  assert tuple(out)==expected,(x,y,tuple(out),expected)
  query_count+=1
 print(f'ROM_QUERY_ORACLE_PASS {query_count} comparisons of return/A0/A2/A4/A6 against original B7:CD1F')

 # Tidal's full submap and the newly supported flat conditional ceiling $4D.
 level=(ctypes.c_uint8*7968)();assert lib.terrain_tidal_level(level)
 lib.terrain_tidal_query.argtypes=[ctypes.c_uint,ctypes.c_uint,ctypes.POINTER(ctypes.c_uint16)]
 tidal_count=0
 cases=[(x,y) for x in (0,1,15,16,31,32,319,608,3968,7904,7967) for y in (0,255,256,257,287,288,289,511,512,767,768,1024)]
 cases += [(rng.randrange(7968),rng.randrange(224,800)) for _ in range(20000)]
 for x,y in cases:
  expected=original(0,x,y,True);assert lib.terrain_tidal_query(x,y,out)
  assert tuple(out)==expected,("tidal",x,y,tuple(out),expected)
  tidal_count+=1
 print(f'ROM_TIDAL_QUERY_ORACLE_PASS {tidal_count} full-submap query comparisons including conditional ceiling $4D')
