"""Meaningful static-analysis regressions; no emulated game runtime."""
import hashlib, importlib.util, json, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('rom_workbench',ROOT/'tools/rom_workbench.py')
w=importlib.util.module_from_spec(spec);spec.loader.exec_module(w)

class WorkbenchTests(unittest.TestCase):
    def setUp(self):self.rom=bytearray(0x400000)
    def write(self,address,data):self.rom[w.pc(address):w.pc(address)+len(data)]=bytes(data)
    def test_hirom_mirrors_and_ram_exclusion(self):
        self.assertEqual(w.pc(0xb8a191),0x38a191)
        self.assertEqual(w.pc(0xf8a191),0x38a191)
        for address in (0x7e8000,0x7f9000,0x004204,0x8080000,0xb80010):
            with self.assertRaises(ValueError):w.pc(address)
    def test_ambiguous_immediates_and_rep_sep(self):
        self.write(0xb88000,[0xa9,0x34,0x12,0xe2,0x20,0xa9,0x56,0x60])
        with self.assertRaisesRegex(ValueError,'UNKNOWN M/X'):w.decode(self.rom,0xb88000,0xb88008)
        a=w.decode(self.rom,0xb88000,0xb88008,(0,0));self.assertEqual(a['operand'],'#$1234')
        report=w.Workbench(self.rom).report('B88000',0xb88008,'0,0')
        self.assertEqual([r['size'] for r in report['instructions']],[3,2,2,1])
        self.assertEqual(report['instructions'][2]['operand'],'#$56')
    def test_call_and_branch_do_not_assume_width_survival(self):
        self.write(0xb88000,[0x20,0x10,0x80,0xa9,0x01,0x02])
        report=w.Workbench(self.rom).report('B88000',0xb88006,'0,0')
        self.assertEqual(len(report['instructions']),1)
        self.assertTrue(any('UNKNOWN' in s for s in report['warnings']))
        self.write(0xb88000,[0xd0,0x02,0xa9,0x01,0x02])
        report=w.Workbench(self.rom).report('B88000',0xb88005,'0,0')
        self.assertEqual(len(report['instructions']),1)
    def test_relative_wrap_and_truncation(self):
        self.write(0xb88000,[0x80,0xfc])
        self.assertEqual(w.decode(self.rom,0xb88000,0xb88002)['target'],0xb87ffe)
        self.write(0xb8fffe,[0x80,0x01])
        self.assertEqual(w.decode(self.rom,0xb8fffe,0xb90000)['target'],0xb80001)
        self.write(0xb88000,[0x22,0x01,0x80,0xb9])
        with self.assertRaisesRegex(ValueError,'Truncated'):w.decode(self.rom,0xb88000,0xb88003)
    def test_source_index_checks_opcodes_and_reads_rom_operands(self):
        self.write(0xb88000,[0x7c,0x00,0x81,0xa9,0x34,0x12,0x6b])
        self.write(0xb88100,[0x20,0x81,0x09,0x00])
        self.write(0xb88120,[0x60])
        self.write(0xb88130,[0xea]) # Assembly annotation deliberately wrong.
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp);(p/'bank_B8.asm').write_text('''handler:
 JMP (state_table,x) ;$B88000
 LDA.w #$FFFF ;$B88003
 RTL ;$B88006
state_table:
 dw STATE_B88120, $0009
DATA_B88110:
 db $00
STATE_B88120:
 RTS ;$B88120
bad_annotation:
 LDA.b $00 ;$B88130
''')
            w.import_index(p,self.rom,p/'index.gz');index=w.read_json(p/'index.gz')
            self.assertEqual(index['symbols']['DATA_B88110'],0xb88110)
            self.assertEqual(index['symbols']['state_table'],0xb88100)
            self.assertNotIn('B88130',index['instructions'])
            self.assertEqual(len(index['issues']),1)
            self.assertEqual(index['verified_dispatch'][0]['flags'],[9])
            report=w.Workbench(self.rom,index).report('handler',0xb88007)
            self.assertEqual(report['instructions'][1]['operand'],'#$1234')
            self.assertEqual(report['dispatch'][0]['contract']['targets'],[0xb88120])
            self.rom[0]+=1
            with self.assertRaisesRegex(ValueError,'SHA256 mismatch'):w.Workbench(self.rom,index)
    def test_data_is_never_decoded_as_code(self):
        self.write(0xb88000,[0xea,0xea])
        catalog={'data_regions':[{'bank':0xb8,'start':0x8000,'end':0x8002}]}
        report=w.Workbench(self.rom,catalog=catalog).report('B88000',0xb88002)
        self.assertFalse(report['instructions']);self.assertIn('DATA boundary',report['warnings'][0])
    def test_copier_header_and_bad_rom_size(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'rom.sfc';p.write_bytes(b'x'*512+self.rom)
            self.assertEqual(w.read_rom(p),bytes(self.rom))
            p.write_bytes(b'bad')
            with self.assertRaises(ValueError):w.read_rom(p)
    def test_shipped_kong_dispatch_against_rom(self):
        rom=w.read_rom(ROOT/'rom/dkc3_ptbr.sfc');index=w.read_json(ROOT/'tools/reference/rom-analysis-index.json.gz')
        work=w.Workbench(rom,index,w.read_json(ROOT/'tools/reference/recomp-catalog.json'))
        row=next(r for r in index['verified_dispatch'] if r['site']==0xb89f4d)
        self.assertEqual((row['table'],row['stride'],len(row['targets'])),(0xb8a191,4,120))
        for i,(address,flags) in enumerate(zip(row['targets'],row['flags'])):
            off=w.pc(row['table'])+i*4
            self.assertEqual(int.from_bytes(rom[off:off+2],'little')|0xb80000,address)
            self.assertEqual(int.from_bytes(rom[off+2:off+4],'little'),flags)
        report=work.report('B6A6C4',0xb6a718)
        self.assertEqual(len(report['instructions']),38)
        self.assertTrue(any(r['operand']=='#$A718' for r in report['instructions']))
        self.assertEqual(work.locate('DATA_B6A727'),0xb6a727)

if __name__=='__main__':unittest.main(verbosity=2)
