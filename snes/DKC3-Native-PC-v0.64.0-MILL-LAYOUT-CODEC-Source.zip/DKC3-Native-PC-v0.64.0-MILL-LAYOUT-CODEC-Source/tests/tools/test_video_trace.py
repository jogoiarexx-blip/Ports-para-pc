"""Captured-transfer conversion tests; no emulator/reference execution claim."""
import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location('video_trace', ROOT/'tools/convert_video_trace.py')
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)


def dma(**changes):
    result = dict(kind='dma', complete=True, direction='a_to_b', source_step='increment',
                  display_phase='vblank', payload_order='bus', target=0x2122,
                  transfer_mode=0, transfer_size=4, payload_hex='1f00ff83',
                  cgram_start_color=5, cgram_latch='low')
    result.update(changes)
    return result


def convert(*events):
    return v.convert_trace({'schema': v.INPUT_SCHEMA, 'events': list(events)})


class VideoTraceTests(unittest.TestCase):
    def test_semantic_rectangle_extent_must_fit_native_map(self):
        event = dict(kind='semantic', complete=True, operation='updateTilemap',
                     layout='row-major', layer=0, x=1023, y=0, width=2, height=1,
                     payload_hex='00000000')
        self.assertEqual(convert(event)['unsupported'], 1)
        event.update(x=0, y=1023, width=1, height=2)
        self.assertEqual(convert(event)['unsupported'], 1)
        event.update(x=31, y=0, width=2, height=1, map_width=32, map_height=32)
        self.assertEqual(convert(event)['unsupported'], 1)
        event.update(x=30)
        self.assertEqual(convert(event)['converted'], 1)

    def test_cgram_actual_port_sequence(self):
        report = convert(dma())
        self.assertEqual(report['converted'], 1)
        r = report['records'][0]
        self.assertEqual(r['operation'], 'setPalette')
        self.assertEqual(r['args'], {'first': 5, 'colors': [31, 1023]})
        self.assertEqual(r['evidence'], 'captured_raw_dma')
        self.assertFalse(report['referenceExecutionVerified'])

    def test_partial_nondefault_and_unknown_dma_are_visible(self):
        for changes in [dict(complete=False), dict(transfer_size=6), dict(payload_hex='1f'),
                        dict(cgram_latch='high'), dict(cgram_start_color=255),
                        dict(direction='b_to_a'), dict(source_step='fixed'),
                        dict(display_phase='active'), dict(payload_order='source_memory'),
                        dict(transfer_mode=2), dict(target=0x2104), dict(payload_hex='0x1f')]:
            with self.subTest(changes=changes):
                report = convert(dma(**changes))
                self.assertEqual(report['unsupported'], 1)
                self.assertIn('reason', report['records'][0])
                self.assertNotIn('operation', report['records'][0])

    def test_vram_known_single_row_tilemap_binding(self):
        e = dma(target=0x2118, transfer_mode=1, vmain=0x80, vram_start_word=0x1043,
                payload_hex='012003c0', binding=dict(kind='tilemap_page', asset='bg1.nmap',
                base_word=0x1000, layer=0, layout='snes-32x32-page', x=3, y=2, width=2, height=1))
        r = convert(e)['records'][0]
        self.assertEqual(r['operation'], 'updateTilemap')
        self.assertEqual(r['args']['entries'], [0x2001, 0xc003])
        self.assertEqual((r['args']['x'], r['args']['y']), (3, 2))
        for changes in [dict(vmain=0), dict(vmain=0x81), dict(vram_start_word=0x1044), dict(binding=None)]:
            self.assertEqual(convert({**e, **changes})['unsupported'], 1)
        e['binding']['height'] = 2
        e['payload_hex'] *= 2
        e['transfer_size'] *= 2
        self.assertIn('not contiguous', convert(e)['records'][0]['reason'])

    def test_vram_full_page_rows_and_wrap_bounds(self):
        e = dma(target=0x2118, transfer_mode=1, vmain=0x80, vram_start_word=0x1020,
                payload_hex='0100'*64, transfer_size=128, binding=dict(kind='tilemap_page',
                asset='bg1.nmap', base_word=0x1000, layer=0, layout='snes-32x32-page',
                x=0, y=1, width=32, height=2))
        self.assertEqual(convert(e)['converted'], 1)
        self.assertEqual(len(convert(e)['records'][0]['args']['entries']), 64)
        e['vram_start_word'] = 0x7fff
        self.assertIn('wrap', convert(e)['records'][0]['reason'])

    def test_planar_tiles_2_and_4bpp_exact_indices(self):
        data = bytearray(32)
        data[0] = 0x80     # p0 left row0
        data[1] = 0x40     # p1 next pixel row0
        data[16] = 0x20    # p2 third pixel row0
        data[17] = 0x10    # p3 fourth pixel row0
        data[30] = 0x01    # p2 last pixel last row
        data[31] = 0x01    # p3 last pixel last row
        pixels = v.decode_tiles(bytes(data), 4)
        self.assertEqual(pixels[:8], [1, 2, 4, 8, 0, 0, 0, 0])
        self.assertEqual(pixels[-1], 12)
        self.assertEqual(v.decode_tiles(bytes(data[:16]), 2)[:8], [1,2,0,0,0,0,0,0])
        with self.assertRaises(ValueError): v.decode_tiles(bytes(data[:17]), 2)
        with self.assertRaises(ValueError): v.decode_tiles(bytes(data), 3)

    def test_raw_tile_binding_decodes_and_checks_destination(self):
        data = bytearray(32)
        data[0] = 0x80
        e = dma(target=0x2118, transfer_mode=1, vmain=0x80, vram_start_word=0x2040,
                payload_hex=data.hex(), transfer_size=32, binding=dict(kind='tiles',
                asset='bg1.ntiles', base_word=0x2000, layer=0, bpp=4,
                format='snes-planar', first_tile=4))
        r = convert(e)['records'][0]
        self.assertEqual(r['operation'], 'updateTiles')
        self.assertEqual(r['args']['firstTile'], 4)
        self.assertEqual(r['args']['pixels'], [1]+[0]*63)
        e['binding']['bpp'] = 2
        self.assertEqual(convert(e)['unsupported'], 1)

    def test_resolved_rows_and_gradient_are_semantic_not_hdma(self):
        rows = dict(kind='semantic', complete=True, operation='updateScanlineOffsets',
                    layer=1, rows=[dict(x=-4, y=2), dict(x=0, y=-1)])
        grad = dict(kind='semantic', complete=True, operation='updateGradient', fixed_color_rows=[31,992])
        report = convert(rows, grad)
        self.assertEqual(report['converted'], 2)
        self.assertTrue(all(r['evidence']=='resolved_semantic_adapter' for r in report['records']))
        self.assertEqual(report['records'][0]['args']['rows'][0], dict(x=-4,y=2))
        self.assertEqual(convert({**rows, 'kind':'hdma'})['unsupported'], 1)
        self.assertEqual(convert({**grad, 'fixed_color_rows':[0x8000]})['unsupported'], 1)
        self.assertEqual(convert({**rows, 'rows':[dict(x=0)]})['unsupported'], 1)

    def test_semantic_palette_and_asset_uploads(self):
        e = dict(kind='semantic', complete=True, operation='setPalette', first=0, colors=[31])
        self.assertEqual(convert(e)['records'][0]['args']['colors'], [31])
        m = dict(kind='semantic', complete=True, operation='updateTilemap', layer=0,
                 x=0,y=0,width=1,height=1,layout='row-major',payload_hex='00e0')
        self.assertEqual(convert(m)['records'][0]['args']['entries'], [0xe000])
        t = dict(kind='semantic', complete=True, operation='updateTiles', layer=2,
                 bpp=2,first_tile=0,format='snes-planar',payload_hex='00'*16)
        self.assertEqual(convert(t)['records'][0]['args']['pixels'], [0]*64)

    def test_limits_and_invalid_schema(self):
        for doc in [{}, {'schema':v.INPUT_SCHEMA,'events':'bad'}, {'schema':v.INPUT_SCHEMA,'events':[{}]*4097}]:
            with self.assertRaises(ValueError): v.convert_trace(doc)
        self.assertEqual(convert(dma(payload_hex='00'*65537))['unsupported'], 1)
        self.assertEqual(convert(dma(cgram_start_color=True))['unsupported'], 1)

    def test_cli_writes_rejections_and_nonzero_status(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory)/'trace.json'
            dest = Path(directory)/'ops.json'
            source.write_text(json.dumps({'schema':v.INPUT_SCHEMA,'events':[dma(),{'kind':'hdma','complete':True}]}))
            result = subprocess.run([sys.executable,str(ROOT/'tools/convert_video_trace.py'),str(source),'--output',str(dest)],capture_output=True,text=True)
            self.assertEqual(result.returncode,2)
            self.assertEqual(json.loads(dest.read_text())['unsupported'],1)
            self.assertIn('converted=1 unsupported=1',result.stdout)


if __name__ == '__main__':
    unittest.main()
