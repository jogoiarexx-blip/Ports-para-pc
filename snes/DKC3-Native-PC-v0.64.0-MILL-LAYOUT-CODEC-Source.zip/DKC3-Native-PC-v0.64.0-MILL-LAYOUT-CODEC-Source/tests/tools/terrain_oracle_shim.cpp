#include "core/RomTerrain.h"
extern "C" uint32_t terrain_sample(unsigned tile,unsigned left,unsigned right,unsigned x,unsigned y){auto r=dkc3::romPierTerrainSample(tile,left,right,x,y);return (static_cast<uint32_t>(r.attributes)<<16)|static_cast<uint16_t>(r.height);}
#include "core/RomData.h"
extern "C" int terrain_query(unsigned x,unsigned y,uint16_t* out){
  static dkc3::RomPierTerrain terrain;
  static const bool loaded=[](){dkc3::RomImage rom;if(!rom.load("rom/dkc3_ptbr.sfc"))return false;
    std::vector<uint8_t> packed,level,defs,attributes;rom.range(0x252618,0x253a78,packed);
    if(!dkc3::dkc3BigDataDecompress(packed.data(),packed.size(),level))return false;
    rom.range(0x254a01,0x254c41,defs);rom.range(0x37cfd0,0x37d078,attributes);return terrain.load(level,defs,attributes,195); }();
  if(!loaded)return 0;
  auto r=terrain.query(x,y);out[0]=r.encoded;out[1]=r.attributes;out[2]=r.initialAttributes;out[3]=r.ceiling;out[4]=r.ceilingSlope;return r.supported;
}
extern "C" int terrain_level(uint8_t* out){dkc3::RomImage rom;if(!rom.load("rom/dkc3_ptbr.sfc"))return 0;std::vector<uint8_t> packed,level;rom.range(0x252618,0x253a78,packed);if(!dkc3::dkc3BigDataDecompress(packed.data(),packed.size(),level))return 0;for(unsigned i=0;i<6240;++i)out[i]=level[i];return 1;}
extern "C" int terrain_tidal_query(unsigned x,unsigned y,uint16_t* out){
 static dkc3::RomPierTerrain terrain;
 static const bool loaded=[](){dkc3::RomImage rom;if(!rom.load("rom/dkc3_ptbr.sfc"))return false;
  std::vector<uint8_t> packed,level,defs,attrs;rom.range(0x252618,0x253a78,packed);
  if(!dkc3::dkc3BigDataDecompress(packed.data(),packed.size(),level))return false;
  level=std::vector<uint8_t>(level.begin()+6240,level.begin()+14208);
  rom.range(0x254a01,0x254c41,defs);rom.range(0x37cfd0,0x37d078,attrs);return terrain.load(level,defs,attrs,249);}();
 if(!loaded)return 0;auto r=terrain.query(x,y);out[0]=r.encoded;out[1]=r.attributes;out[2]=r.initialAttributes;out[3]=r.ceiling;out[4]=r.ceilingSlope;return r.supported;
}
extern "C" int terrain_tidal_level(uint8_t* out){
 dkc3::RomImage rom;if(!rom.load("rom/dkc3_ptbr.sfc"))return 0;std::vector<uint8_t> packed,level;rom.range(0x252618,0x253a78,packed);
 if(!dkc3::dkc3BigDataDecompress(packed.data(),packed.size(),level))return 0;for(unsigned i=0;i<7968;++i)out[i]=level[i+6240];return 1;
}
