# Test-only interpreter for two bounded original ROM routines. Never packaged in runtime.
import ctypes,random
from pathlib import Path
import subprocess,tempfile,os
root=Path(__file__).resolve().parents[2]
os.chdir(root)
_tmp=tempfile.TemporaryDirectory()
lib_path=Path(_tmp.name)/'motion_oracle.so'
subprocess.run([os.environ.get('CXX','g++'),'-std=c++20','-O2','-shared','-fPIC','-I'+str(root/'src'),str(root/'tests/tools/oracle_shim.cpp'),str(root/'src/core/RomMotion.cpp'),str(root/'src/core/RomData.cpp'),str(root/'src/core/RomTerrain.cpp'),'-o',str(lib_path)],check=True)
rom=(root/'rom/dkc3_ptbr.sfc').read_bytes()
lib=ctypes.CDLL(str(lib_path))
for name in ['gravity','interpolate']:
 f=getattr(lib,name);f.argtypes=[ctypes.c_int16,ctypes.c_int16,ctypes.c_uint16];f.restype=ctypes.c_int16

def original(pc,velocity=0,target=0,mode=3,character=0,flags=0):
 entry=pc
 bank=pc&0xff0000;pc&=65535;mem=bytearray(65536);a=mode;x=y=0;c=n=z=0;stack=[]
 def wr(at,v):mem[at&65535]=v&255;mem[(at+1)&65535]=(v>>8)&255
 def rd(at):return mem[at&65535]|mem[(at+1)&65535]<<8
 def data_word(at):
  off=at&0x3fffff;return rom[off]|rom[off+1]<<8
 def fetch():
  nonlocal pc
  v=rom[((bank|pc)&0x3fffff)];pc=(pc+1)&65535;return v
 def word():return fetch()|fetch()<<8
 def nz(v):
  nonlocal n,z
  n=bool(v&32768);z=v==0;return v
 def add(v):
  nonlocal a,c
  r=a+v+c;c=r>65535;a=nz(r&65535)
 def sub(v):
  nonlocal a,c
  r=a-v-(not c);c=r>=0;a=nz(r&65535)
 wr(0x70,0x1000);wr(0x72,0x1100)
 # Actual DP current_sprite/current_kong_control_variables patched by caller below.
 wr(CURRENT,0x1000);wr(CONTROL,0x1100)
 wr(0x1106,flags);wr(0x6a,0x1840+character*2);mem[0x6c]=0xff
 wr(0x102a,velocity);wr(0x1030,target);wr(0x1036,0);wr(0x102e,velocity);wr(0x1108,target);wr(0x110a,2048)
 for _ in range(200):
  op=fetch()
  if op==0x0a:c=bool(a&32768);a=nz((a<<1)&65535)
  elif op==0xaa:x=nz(a)
  elif op==0xbb:x=nz(y)
  elif op==0xa0:y=nz(word())
  elif op==0xa9:a=nz(word())
  elif op==0xa2:x=nz(word())
  elif op==0xad:a=nz(rd(word()))
  elif op==0xa5:a=nz(rd(fetch()))
  elif op==0x29:a=nz(a&word())
  elif op==0xb7:
   dp=fetch();at=rd(dp)|(mem[(dp+2)&65535]<<16);a=nz(data_word((at+y)&0xffffff))
  elif op==0x20:at=word();stack.append(pc);pc=at
  elif op==0xa6:x=nz(rd(fetch()))
  elif op==0xa4:y=nz(rd(fetch()))
  elif op==0xb9:a=nz(rd((word()+y)&65535))
  elif op==0xb5:a=nz(rd((fetch()+x)&65535))
  elif op==0x18:c=0
  elif op==0x38:c=1
  elif op==0x79:add(rd((word()+y)&65535))
  elif op==0x75:add(rd((fetch()+x)&65535))
  elif op==0x65:add(rd(fetch()))
  elif op==0xf9:sub(rd((word()+y)&65535))
  elif op==0xd9:
   v=rd((word()+y)&65535);r=(a-v)&65535;c=a>=v;nz(r)
  elif op==0x49:a=nz(a^word())
  elif op==0x1a:a=nz((a+1)&65535)
  elif op==0x4a:c=a&1;a=nz(a>>1)
  elif op==0x85:wr(fetch(),a)
  elif op==0x95:wr((fetch()+x)&65535,a)
  elif op==0x99:wr((word()+y)&65535,a)
  elif op==0xfc:
   at=(word()+x)&65535;stack.append(pc);off=((bank|at)&0x3fffff);pc=rom[off]|rom[off+1]<<8
  elif op in [0x30,0x10,0x90,0xf0,0xd0]:
   rel=fetch();rel=rel if rel<128 else rel-256
   cond={0x30:n,0x10:not n,0x90:not c,0xf0:z,0xd0:not z}[op]
   if cond:pc=(pc+rel)&65535
  elif op in [0x60,0x6b]:
   if stack:pc=stack.pop()
   else:
    if entry==0xb8d4c2:return a if a<32768 else a-65536
    v=rd(0x1030 if entry in (0xb8d3c2,0xb8d448) else (0x102e if bank==0xb80000 else 0x102a));return v if v<32768 else v-65536
  else:raise RuntimeError((hex(bank|((pc-1)&65535)),hex(op)))
 raise RuntimeError('instruction limit')
# Decode actual direct-page operands from the original routines.
CURRENT=rom[0x38a036];CONTROL=rom[0x38a038]
rng=random.Random(35)
count=0
for vel in range(-32768,32768):
 for gravity in (90,112):
  expected=original(0xb8a035,vel,gravity)
  actual=lib.gravity(vel,gravity,2048)
  assert actual==expected,(vel,gravity,actual,expected)
  count+=1
for _ in range(20000):
 v=rng.randrange(-32768,32768);t=rng.randrange(-32768,32768);m=rng.choice((3,7))
 expected=original(0xb9f4b0,v,t,m);actual=lib.interpolate(v,t,m)
 assert actual==expected,(v,t,m,actual,expected)
 count+=1
print(f'ROM_ORACLE_PASS {count} cases; original B8:A035 and B9:F4B0 instructions versus C++; test only')

lib.target_speed.argtypes=[ctypes.c_uint16,ctypes.c_uint16,ctypes.c_uint16]
lib.target_speed.restype=ctypes.c_int16
speed_count=0
for character in (0,1):
 for flags in range(65536):
  for pc,buttons in ((0xb8d3c2,0x200),(0xb8d448,0x100)):
   expected=original(pc,character=character,flags=flags)
   actual=lib.target_speed(character,flags,buttons)
   assert actual==expected,(character,flags,buttons,actual,expected)
   speed_count+=1
print(f'ROM_SPEED_ORACLE_PASS {speed_count} comparisons against B8:D3C2/D448 -> D4C2')
