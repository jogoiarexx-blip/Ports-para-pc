# Test-only bounded B9:F060..F083 decision. Not in game runtime.
import ctypes,os,random,subprocess,tempfile
from pathlib import Path
root=Path(__file__).resolve().parents[2];rom=(root/'rom/dkc3_ptbr.sfc').read_bytes()
with tempfile.TemporaryDirectory() as tmp:
 so=Path(tmp)/'ground.so';subprocess.run([os.environ.get('CXX','g++'),'-std=c++20','-O2','-shared','-fPIC','-I'+str(root/'src'),str(root/'tests/tools/ground_follow_oracle_shim.cpp'),str(root/'src/core/RomTerrain.cpp'),'-o',str(so)],check=True)
 lib=ctypes.CDLL(str(so));lib.ground_follow.argtypes=[ctypes.c_uint]*3+[ctypes.POINTER(ctypes.c_uint16)]
 def original(distance,attributes,flags):
  mem={0xa0:attributes,0x1028:flags};pc=0xf060;a=distance;x=0x1000;z=c=False
  def fetch():
   nonlocal pc
   v=rom[0x390000+pc];pc=(pc+1)&65535;return v
  def word():return fetch()|fetch()<<8
  def nz(v):
   nonlocal z
   z=v==0;return v
  for _ in range(40):
   if pc in (0xf019,0xf083):return mem[0x101a],int(pc==0xf019)
   op=fetch()
   if op==0x95:mem[fetch()+x]=a
   elif op==0xa5:a=nz(mem[fetch()])
   elif op==0xb5:a=nz(mem[fetch()+x])
   elif op==0x29:a=nz(a&word())
   elif op==0xa9:a=nz(word())
   elif op==0x1a:a=nz((a+1)&65535)
   elif op==0xd5:v=mem[fetch()+x];c=a>=v;z=a==v
   elif op in (0xd0,0xf0,0xb0,0x80):
    rel=fetch();rel=rel if rel<128 else rel-256
    if {0xd0:not z,0xf0:z,0xb0:c,0x80:True}[op]:pc=(pc+rel)&65535
   else:raise RuntimeError((hex(pc-1),hex(op)))
  raise RuntimeError('instruction limit')
 rng=random.Random(42);out=(ctypes.c_uint16*2)();count=0
 cases=[(d,rng.randrange(8),rng.randrange(65536)) for d in range(65536)]
 cases += [(d,a,f) for d in (0,1,2,3,4,5,32767,65535) for a in range(8) for f in (0,0x100,0x1000,0x1100,0x1101)]
 cases += [tuple(rng.randrange(65536) for _ in range(3)) for _ in range(20000)]
 for args in cases:
  expected=original(*args);lib.ground_follow(*args,out);assert tuple(out)==expected,(args,tuple(out),expected);count+=1
 print(f'ROM_GROUND_FOLLOW_ORACLE_PASS {count} comparisons of distance and F019/F083 exit against original B9:F060..F083')
