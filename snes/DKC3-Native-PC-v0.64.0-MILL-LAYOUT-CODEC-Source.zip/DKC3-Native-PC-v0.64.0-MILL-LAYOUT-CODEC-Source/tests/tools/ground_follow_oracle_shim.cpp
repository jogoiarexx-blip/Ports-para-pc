#include "core/RomTerrain.h"
extern "C" void ground_follow(unsigned d,unsigned a,unsigned f,unsigned short*out){auto r=dkc3::romGroundFollow(static_cast<uint16_t>(d),static_cast<uint16_t>(a),static_cast<uint16_t>(f));out[0]=r.distance;out[1]=r.attach?1:0;}
