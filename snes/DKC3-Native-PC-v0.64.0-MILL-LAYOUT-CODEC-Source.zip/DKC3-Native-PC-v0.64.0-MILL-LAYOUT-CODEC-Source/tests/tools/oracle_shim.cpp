#include "core/RomMotion.h"
extern "C" int16_t gravity(int16_t v,int16_t g,uint16_t l){return dkc3::romGravityStep(v,g,static_cast<int16_t>(l));}
extern "C" int16_t interpolate(int16_t v,int16_t t,uint16_t m){return dkc3::romInterpolateSpeed(v,t,m);}

extern "C" int16_t target_speed(uint16_t character,uint16_t flags,uint16_t buttons){
  static dkc3::RomMotionProfile dixie,kiddy;
  static bool loaded=dkc3::loadRomMotionProfiles("rom/dkc3_ptbr.sfc",dixie,kiddy);
  if(!loaded)return -32768;
  return dkc3::romHorizontalTarget(character?kiddy:dixie,flags,(buttons&0x200u)!=0,(buttons&0x100u)!=0);
}
