# Test-only bounded oracle for B9:EFB9..EFF0. No interpreter in game runtime.
import ctypes,os,random,subprocess,tempfile
from pathlib import Path
root=Path(__file__).resolve().parents[2];rom=(root/'rom/dkc3_ptbr.sfc').read_bytes()
with tempfile.TemporaryDirectory() as tmp:
 so=Path(tmp)/'rising.so'
 subprocess.run([os.environ.get('CXX','g++'),'-std=c++20','-O2','-shared','-fPIC','-I'+str(root/'src'),str(root/'tests/tools/rising_oracle_shim.cpp'),str(root/'src/core/RomTerrain.cpp'),'-o',str(so)],check=True)
 lib=ctypes.CDLL(str(so));lib.rising_response.argtypes=[ctypes.c_uint]*6+[ctypes.POINTER(ctypes.c_uint16)]
 def original(position,ceiling,slope,next_ceiling,next_slope,flags):
  mem=bytearray(65536);pc=0xefb9;a=0;x=0x1000;n=z=c=0
  def wr(at,v):mem[at&65535]=v&255;mem[(at+1)&65535]=(v>>8)&255
  def rd(at):return mem[at&65535]|mem[(at+1)&65535]<<8
  def fetch():
   nonlocal pc
   v=rom[0x390000+pc];pc=(pc+1)&65535;return v
  def word():return fetch()|fetch()<<8
  def nz(v):
   nonlocal n,z
   n=bool(v&32768);z=v==0;return v
  wr(0xa4,ceiling);wr(0xa6,slope);wr(0x1016,position);wr(0x1028,flags);wr(0x102e,0xf900);wr(0x1034,0x1234)
  for _ in range(80):
   if pc==0xeff0:return tuple(rd(p) for p in (0x1016,0x102e,0x1034,0x1018,0x101a,0x1028,0xa0))
   op=fetch()
   if op==0xa5:a=nz(rd(fetch()))
   elif op==0xb5:a=nz(rd(fetch()+x))
   elif op==0x85:wr(fetch(),a)
   elif op==0x95:wr(fetch()+x,a)
   elif op==0x64:wr(fetch(),0)
   elif op==0x74:wr(fetch()+x,0)
   elif op==0xa9:a=nz(word())
   elif op==0x29:a=nz(a&word())
   elif op==0x09:a=nz(a|word())
   elif op==0x15:a=nz(a|rd(fetch()+x))
   elif op==0x18:c=0
   elif op==0x69:
    v=a+word()+c;c=v>65535;a=nz(v&65535)
   elif op==0x1a:a=nz((a+1)&65535)
   elif op in (0xd0,0xf0):
    rel=fetch();rel=rel if rel<128 else rel-256
    if (not z if op==0xd0 else z):pc=(pc+rel)&65535
   elif op==0x20:
    target=word();assert target==0xf13a
    # Terrain lookup was verified separately; inject its A4/A6 outputs.
    wr(0xa4,next_ceiling);wr(0xa6,next_slope)
   else:raise RuntimeError((hex(pc-1),hex(op)))
  raise RuntimeError('instruction limit')
 out=(ctypes.c_uint16*7)();rng=random.Random(39);count=0
 cases=[(p,0,0,0,0,rng.randrange(65536)) for p in range(65536)]
 cases += [(rng.randrange(65536),rng.choice((0,rng.randrange(1,65536))),rng.randrange(65536),rng.randrange(65536),rng.randrange(65536),rng.randrange(65536)) for _ in range(20000)]
 for args in cases:
  expected=original(*args);lib.rising_response(*args,out)
  assert tuple(out)==expected,(args,tuple(out),expected);count+=1
 print(f'ROM_RISING_ORACLE_PASS {count} comparisons of position/velocity/target/surface/distance/flags/A0 against B9:EFB9..EFF0')
