#include "core/RomTerrain.h"
extern "C" void wall_response(unsigned px,unsigned py,unsigned y,unsigned target,unsigned speed,unsigned flags,unsigned surface,uint16_t* out){auto r=dkc3::romWallCollision(px,py,y,target,speed,flags,surface);out[0]=r.x;out[1]=r.y;out[2]=r.fraction;out[3]=r.target;out[4]=r.velocity;out[5]=r.savedTarget;out[6]=r.savedVelocity;out[7]=r.flags;}
