"""ROM-bound map and semantic trace regressions; no CPU/PPU execution."""
import contextlib, hashlib, importlib.util, io, json, sys, tempfile, unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'tools'))
import native_map as n
import rom_workbench as w

class NativeMapTests(unittest.TestCase):
    def setUp(self):
        self.rom = bytearray(0x400000)
        self.start = 0xb88000
        code = bytes([0x22,0x00,0x81,0xb8, 0x8f,0x10,0x00,0x7e, 0xad,0x00,0x21,
                      0xa5,0x10, 0xaf,0x00,0x82,0xc0, 0x7c,0x00,0x83, 0x6b])
        self.rom[w.pc(self.start):w.pc(self.start)+len(code)] = code
        self.rom[w.pc(0xb88100)] = 0x6b
        sizes = [(0,4),(4,4),(8,3),(11,2),(13,4),(17,3),(20,1)]
        sha = hashlib.sha256(self.rom).hexdigest()
        self.index = {'rom_sha256':sha, 'instructions':{f'{self.start+off:06X}':[size,'bank_B8.asm',off+1] for off,size in sizes},
                      'symbols':{'kong_test':self.start}, 'edges':[[self.start,0xb88100,'JSL']],
                      'ram_symbols':{'frame_counter':0x10}, 'verified_dispatch':[]}
        self.index['instructions']['B88100'] = [1,'bank_B8.asm',99]
        self.catalog = {'rom_sha256':sha,'functions':[{'name':'kong_test','address':self.start,'end_address':self.start+len(code)},
                       {'name':'audio_test','address':0xb88100,'end_address':0xb88101}]}
    def analyzer(self):return n.Analyzer(self.rom,self.index,self.catalog,ROOT)
    def test_both_rom_hashes_are_required_and_checked(self):
        for metadata in (self.index,self.catalog):
            original=metadata['rom_sha256'];metadata['rom_sha256']='wrong'
            with self.assertRaisesRegex(ValueError,'SHA256'):self.analyzer()
            metadata['rom_sha256']=original
        with self.assertRaisesRegex(ValueError,'SHA256'):n.Analyzer(self.rom,{},self.catalog,ROOT)
    def test_graph_calls_banks_and_explicit_bounded_span(self):
        result=self.analyzer().build(['kong_test'],levels=[],depth=1)
        self.assertEqual(len(result['routines']),2)
        routine=result['routines'][0]
        self.assertFalse(routine['complete_function_proven'])
        self.assertEqual(routine['classification']['category'],'gameplay')
        self.assertTrue(any(e['kind']=='JSL' for e in result['graph']['edges']))
        self.assertTrue(any(node['type']=='bank' for node in result['graph']['nodes']))
        self.assertTrue(any('Catalog span' in x for x in routine['warnings']))
    def test_short_operands_remain_unresolved_but_long_ram_rom_resolve(self):
        routine=self.analyzer().build(['kong_test'],levels=[],depth=0)['routines'][0]
        refs=routine['memory_references']
        self.assertTrue(any(r['space']=='RAM' and r['address']==0x7e0010 for r in refs))
        self.assertTrue(any(r['space']=='ROM' and r['address']==0xc08200 for r in refs))
        io=next(r for r in refs if r['operand_value']==0x2100)
        self.assertEqual(io['space'],'UNKNOWN');self.assertEqual(io['candidate_space'],'IO')
        self.assertIn('DBR',io['unknown'])
        dp=next(r for r in refs if r['mode']=='dp')
        self.assertIsNone(dp['address']);self.assertIn('direct-page',dp['unknown'])
        self.assertEqual(dp['symbol_candidates'],['frame_counter'])
        self.assertTrue(any('indirect' in x.lower() for x in routine['warnings']))
    def test_dispatch_remains_contract_and_unknown_bounds(self):
        self.index['verified_dispatch']=[{'site':self.start+17,'table':0xb88300,'stride':2,'targets':[0xb88100],'flags':[],'name':'test_dispatch'}]
        result=self.analyzer().build(['kong_test'],levels=[],depth=0)
        tables=result['routines'][0]['dispatch_tables']
        self.assertEqual(tables[0]['targets'],[0xb88100])
        self.assertFalse(tables[0]['index_bounds_proven'])
    def test_native_semantic_trace_does_not_claim_original_execution(self):
        frame={'schema':'dkc3.trace.v1','frame':0,'input':1,'state':{},'state_hash':'abc',
               'calls':[{'function':'Player::update','pc':None,'opcode':None,'bank':None,'kind':'native','rom_reads':[]}],
               'events':[],'metrics':{'rom_bytes_read':0}}
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'trace.jsonl';path.write_text(json.dumps(frame)+'\n')
            result=self.analyzer().build(['kong_test'],levels=[],depth=0,traces=[path])
            self.assertEqual(result['traces'][0]['native_calls'],1)
            self.assertEqual(result['traces'][0]['instruction_events'],0)
            self.assertIsNone(result['coverage']['original_runtime_fraction'])
            self.assertFalse(any(e['evidence']=='observed_instruction' for e in result['graph']['edges']))
    def test_observed_reference_opcode_is_validated_against_rom(self):
        frame={'schema':'dkc3.trace.v1','frame':0,'input':0,'state':{},'state_hash':'abc','calls':[],
               'events':[{'type':'instruction_reference','pc':self.start,'opcode':0x22,'bank':0xb8,'space':'ROM','address':0xc08200,'access':'read'}],'metrics':{}}
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'reference.jsonl';path.write_text(json.dumps(frame)+'\n')
            result=self.analyzer().build(['kong_test'],levels=[],depth=0,traces=[path])
            self.assertEqual(result['traces'][0]['instruction_events'],1)
            self.assertTrue(any(e['evidence']=='observed_instruction' for e in result['graph']['edges']))
            frame['events'][0]['opcode']=0xea;path.write_text(json.dumps(frame)+'\n')
            with self.assertRaisesRegex(ValueError,'opcode'):self.analyzer().build(['kong_test'],levels=[],traces=[path])
    def test_bad_trace_schema_native_pc_and_nonmonotonic_frames_rejected(self):
        frame={'schema':'dkc3.trace.v1','frame':0,'input':0,'state':{},'state_hash':'abc',
               'calls':[{'function':'Player::update','pc':self.start,'opcode':0x22,'bank':0xb8,'kind':'native','rom_reads':[]}],'events':[],'metrics':{}}
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'trace.jsonl';path.write_text(json.dumps(frame)+'\n')
            with self.assertRaisesRegex(ValueError,'native'):self.analyzer().build(['kong_test'],levels=[],traces=[path])
            frame['calls']=[];path.write_text((json.dumps(frame)+'\n')*2)
            with self.assertRaisesRegex(ValueError,'increasing'):self.analyzer().build(['kong_test'],levels=[],traces=[path])
            frame['schema']='fake';path.write_text(json.dumps(frame)+'\n')
            with self.assertRaisesRegex(ValueError,'schema'):self.analyzer().build(['kong_test'],levels=[],traces=[path])
    def test_two_bounded_spans_with_same_entry_keep_distinct_graph_nodes(self):
        result=self.analyzer().build([('B88000','B88004'),('B88000','B88008')],levels=[],depth=0)
        spans=[node for node in result['graph']['nodes'] if node['type']=='routine_span']
        self.assertEqual(len(spans),2)
        self.assertEqual({node['end'] for node in spans},{0xb88004,0xb88008})
        self.assertTrue(all(node['complete_function_proven'] is False for node in spans))
    def test_data_boundary_and_unverified_bytes_are_not_decoded(self):
        self.catalog['data_regions']=[{'bank':0xb8,'start':0x800d,'end':0x8011}]
        result=self.analyzer().build([('B88000','B88015')],levels=[],depth=0)
        routine=result['routines'][0]
        self.assertEqual(routine['end'],0xb88015)
        self.assertEqual(routine['instruction_count'],4)
        self.assertTrue(any('DATA boundary' in warning for warning in routine['warnings']))
        del self.index['instructions']['B8800B']
        result=self.analyzer().build(['kong_test'],levels=[],depth=0)
        self.assertEqual(result['routines'][0]['instruction_count'],3)
        self.assertTrue(any('No verified instruction boundary' in warning for warning in result['routines'][0]['warnings']))
    def test_cli_writes_serializable_json_markdown_and_optional_tidal(self):
        with tempfile.TemporaryDirectory() as tmp:
            json_path=Path(tmp)/'map.json';markdown_path=Path(tmp)/'map.md'
            with contextlib.redirect_stdout(io.StringIO()):
                code=n.main(['--routine','B89F3A','--depth','0','--level','tidal','--output-json',str(json_path),'--output-markdown',str(markdown_path)])
            self.assertEqual(code,0)
            result=json.loads(json_path.read_text(encoding='utf-8'))
            self.assertEqual(result['levels'][0]['level_id'],0x27)
            self.assertEqual(len(result['levels'][0]['placements']),61)
            markdown=markdown_path.read_text(encoding='utf-8')
            self.assertIn('ROM Trace → Native Map',markdown)
            self.assertIn('Tidal Trouble',markdown)
            self.assertFalse(result['selection']['truncated'])
    def test_shipped_levels_and_placement_records_are_rom_bound(self):
        rom=w.read_rom(ROOT/'rom/dkc3_ptbr.sfc')
        analyzer=n.Analyzer(rom,w.read_json(ROOT/'tools/reference/rom-analysis-index.json.gz'),w.read_json(ROOT/'tools/reference/recomp-catalog.json'),ROOT)
        result=analyzer.build(['B89F3A'],levels=['lakeside','doorstop'],depth=0)
        lakeside,doorstop=result['levels']
        self.assertEqual((lakeside['level_id'],lakeside['song_id'],lakeside['shared_data']),(0x25,0xf,0x19f0))
        self.assertEqual((doorstop['level_id'],doorstop['song_id'],doorstop['shared_data']),(0x28,0xe,0x198d))
        self.assertEqual(len(lakeside['placements']),47)
        self.assertGreater(len(doorstop['placements']),0)
        self.assertEqual(lakeside['placements'][0]['descriptor'],0x5ac8)
        self.assertTrue(all(p['port_status']!='SUPPORTED' for p in lakeside['placements']))
        self.assertTrue(all(p['sprite_id'] is not None for p in doorstop['placements']))
        self.assertTrue(any(p['port_status']=='PARTIAL' for p in doorstop['placements']))
        self.assertTrue(any(p['port_status']=='UNKNOWN' for p in doorstop['placements']))
        self.assertIn('audio',lakeside['unknowns'])
        markdown=n.render_markdown(result)
        self.assertIn('```mermaid',markdown)
        self.assertIn('No CPU/PPU',markdown)
        self.assertIn('Doorstop',markdown)

if __name__=='__main__':unittest.main(verbosity=2)
