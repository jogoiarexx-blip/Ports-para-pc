# Test only, bounded B9:F181..F1AD. No interpreter in the game runtime.
import ctypes,os,random,subprocess,tempfile
from pathlib import Path
root=Path(__file__).resolve().parents[2];rom=(root/'rom/dkc3_ptbr.sfc').read_bytes()
with tempfile.TemporaryDirectory() as tmp:
 so=Path(tmp)/'wall.so';subprocess.run([os.environ.get('CXX','g++'),'-std=c++20','-O2','-shared','-fPIC','-I'+str(root/'src'),str(root/'tests/tools/wall_oracle_shim.cpp'),str(root/'src/core/RomTerrain.cpp'),'-o',str(so)],check=True)
 lib=ctypes.CDLL(str(so));lib.wall_response.argtypes=[ctypes.c_uint]*7+[ctypes.POINTER(ctypes.c_uint16)]
 def original(px,py,y,target,speed,flags,surface):
  mem=bytearray(65536);pc=0xf181;a=0;x=0x1000;n=z=c=0
  def wr(at,v):mem[at&65535]=v&255;mem[(at+1)&65535]=(v>>8)&255
  def rd(at):return mem[at&65535]|mem[(at+1)&65535]<<8
  def fetch():
   nonlocal pc
   v=rom[0x390000+pc];pc=(pc+1)&65535;return v
  def word():return fetch()|fetch()<<8
  def nz(v):
   nonlocal n,z
   n=bool(v&32768);z=v==0;return v
  for at,v in ((0x1054,px),(0x1056,py),(0x1016,y),(0x1030,target),(0x102a,speed),(0x1028,flags),(0x1010,65535)):wr(at,v)
  for _ in range(60):
   op=fetch()
   if op==0xb5:a=nz(rd(fetch()+x))
   elif op==0x95:wr(fetch()+x,a)
   elif op==0x74:wr(fetch()+x,0)
   elif op==0x85:wr(fetch(),a)
   elif op==0xa9:a=nz(word())
   elif op==0x29:a=nz(a&word())
   elif op==0x15:a=nz(a|rd(fetch()+x))
   elif op==0x38:c=1
   elif op==0xf5:
    v=a-rd(fetch()+x)-(not c);c=v>=0;a=nz(v&65535)
   elif op in (0xf0,0x10):
    rel=fetch();rel=rel if rel<128 else rel-256
    if (z if op==0xf0 else not n):pc=(pc+rel)&65535
   elif op==0x20:assert word()==0xf13a;a=nz(surface) # Verified query injected.
   elif op==0x60:return tuple(rd(at) for at in (0x1012,0x1016,0x1010,0x1030,0x102a,0xae,0xb0,0x1028))
   else:raise RuntimeError((hex(pc-1),hex(op)))
  raise RuntimeError('instruction limit')
 rng=random.Random(40);out=(ctypes.c_uint16*8)();count=0
 cases=[(rng.randrange(65536),rng.randrange(65536),0x4000,rng.randrange(65536),rng.randrange(65536),rng.randrange(65536)|0x1000,s) for s in range(65536)]
 cases += [tuple(rng.randrange(65536) for _ in range(7)) for _ in range(20000)]
 for args in cases:
  expected=original(*args);lib.wall_response(*args,out);assert tuple(out)==expected,(args,tuple(out),expected);count+=1
 print(f'ROM_WALL_ORACLE_PASS {count} comparisons of X/Y/fraction/target/speed/saved target/saved speed/flags against B9:F181..F1AD')
