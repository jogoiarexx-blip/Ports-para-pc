#include "core/RomSteelKeg.h"
#include "core/CarryBarrel.h"
#include <iostream>
#include <cmath>
using namespace dkc3;
#define CHECK(x) do{if(!(x)){std::cerr<<"STEEL_WATER_FAIL "<<__LINE__<<'\n';return 1;}}while(0)
int main(){
 // Independent carry oracle: A shifts; memory rotates twice; A is not reloaded.
 auto oracle=[](uint16_t v){unsigned a=v,m=v;for(int i=0;i<2;++i){unsigned carry=(a>>15)&1;a=(a*2)&65535;m=(m>>1)|(carry<<15);}return m;};
 for(unsigned v=0;v<65536;++v){auto p=romSteelWaterProbe(400,417,v,uint16_t(v^0xabcd));CHECK(p.slowed&&p.x==oracle(v)&&p.y==oracle(uint16_t(v^0xabcd)));}
 for(unsigned feet=0;feet<65536;++feet)for(uint16_t water:{0u,400u,0x7fffu,0xffffu}){auto p=romSteelWaterProbe(water,feet,0x200,0xff00);
  bool slow=water<0x8000&&((unsigned(water)+16)&65535)<feet;CHECK(p.slowed==slow);CHECK(p.x==(slow?0x80:0x200)&&p.y==(slow?0xffc0:0xff00));}
 CHECK(!romSteelWaterProbe(400,416,0,0).slowed&&romSteelWaterProbe(400,417,0,0).slowed);
 CHECK(romSteelWaterProbe(0,17,0x8000,0x4000).x==0x6000&&romSteelWaterProbe(0,17,0x8000,0x4000).y==0x9000);
 CarryBarrelBody dry;dry.state=CarryBarrelState::Thrown;dry.pos={100,200};dry.velocity={120,120};dry.steelTarget=0x200;dry.steelProfile={true,0xff1dd4,0x70,0x800,8};auto wet=dry;
 advanceSteelKeg(dry,1.f/60,{}, {},nullptr,1000,1000);advanceSteelKeg(wet,1.f/60,{}, {},nullptr,1000,1000,400);
 CHECK(std::fabs((dry.pos.x-100)-4*(wet.pos.x-100))<.001f);CHECK(std::fabs((dry.pos.y-200)-4*(wet.pos.y-200))<.001f);
 CHECK(dry.velocity.x==wet.velocity.x&&dry.velocity.y==wet.velocity.y); // restore, not permanent drag
 auto split=wet,whole=wet;for(int i=0;i<20;++i)advanceSteelKeg(split,1.f/60,{}, {},nullptr,1000,1000,400);
 for(int i=0;i<10;++i)advanceSteelKeg(whole,1.f/30,{}, {},nullptr,1000,1000,400);
 CHECK(std::fabs(split.pos.x-whole.pos.x)<.001f&&std::fabs(split.pos.y-whole.pos.y)<.001f);
 auto wall=wet;wall.pos={100,200};const auto r=advanceSteelKeg(wall,1.f/60,{{128.25f,0,20,1000}}, {},nullptr,1000,1000,400);
 CHECK(r.wall&&wall.velocity.x==-30&&wall.steelTarget==0xfe00);
 std::cout<<"STEEL_WATER_OK 65536 carry rotations; 262144 water/feet cases; boundary, quarter displacement, velocity restore, dt and wet wall\n";
}
