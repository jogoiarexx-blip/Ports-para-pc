#include "core/SuppliedSprites.h"
#include "core/Game.h"
#include "core/WrinklyCave.h"
#include "core/LevelSession.h"
#include "core/Bmp.h"
#include <iostream>
#include <vector>
#define CHECK(x) do{if(!(x)){std::cerr<<"CHECK_FAIL line="<<__LINE__<<" "<<#x<<"\n";return 1;}}while(0)
int main(){using namespace dkc3;
 SuppliedSprites pack;CHECK(pack.load());CHECK(pack.animations().size()==29);CHECK(!pack.animation("unused"));CHECK(!pack.animation("dixie-dkc2"));
 size_t total=0;for(const auto&[name,anim]:pack.animations()){
  CHECK(anim.valid());total+=anim.frames.size();
  for(const auto&f:anim.frames){CHECK(f.sprite.valid());CHECK(f.duration>0);bool opaque=false;
   for(auto pixel:f.sprite.bgra)if(pixel>>24){opaque=true;CHECK((pixel&0xffffff)!=0xff00ff);CHECK((pixel&0xffffff)!=0x00ffff);}
   CHECK(opaque);
   if(name.rfind("kiddy-",0)==0)CHECK(f.sprite.height-f.sprite.originY==38);
   if(name=="dixie-idle"||name=="dixie-hang")CHECK(f.sprite.height-f.sprite.originY==34);
  }
  AnimationPlayer player;float duration=0;for(const auto&f:anim.frames)duration+=f.duration;
  player.step(anim,duration+.01f);CHECK(anim.loop?!player.finished:player.finished);
 }
 CHECK(total==254);CHECK(pack.animation("kobble-walk")->frames.size()==8);
 Game g;CHECK(g.init("assets/levels/lakeside-limbo/lakeside-limbo.level"));
 for(const auto&e:g.enemies())if(e.id=="rom-kobble")CHECK(hashSprite(e.animation.frames[0].sprite)==hashSprite(pack.animation("kobble-walk")->frames[0].sprite));
 CHECK(g.kongLetters().size()==3);for(const auto&k:g.kongLetters())CHECK(hashSprite(k.animation.frames[0].sprite)==hashSprite(pack.animation(std::string("kong-")+k.letter)->frames[0].sprite));
 std::vector<uint32_t> frame(256*224);g.render(frame.data(),256,224);CHECK(saveBmp32("docs/sprites-lakeside.bmp",frame.data(),256,224));
 GamePersistentState state;state.activeCharacter=CharacterId::Kiddy;
 CHECK(g.init("assets/levels/tidal-trouble/tidal-trouble.level",&state));InputState wet;wet.right=true;wet.run=true;for(int i=0;i<3000&&!g.inWater();++i){wet.jump=i%100<15;wet.attack=i%34==0;g.step(wet,1.f/60);}CHECK(g.playerAnimationState()=="swim");g.render(frame.data(),256,224);CHECK(saveBmp32("docs/sprites-tidal.bmp",frame.data(),256,224));
 state.lives=0;CHECK(g.init("assets/levels/tidal-trouble/tidal-trouble.level",&state));auto pos=g.player().pos;InputState right;right.right=true;for(int i=0;i<60;++i)g.step(right,1.f/60);CHECK(g.player().pos.x==pos.x&&g.player().pos.y==pos.y);
 Bitmap over;CHECK(loadBmp32("assets/sprites/dkc3/screens/game-over.bmp",over));g.render(frame.data(),256,224);for(size_t i=0;i<256*180;++i)CHECK(frame[i]==(over.bgra[i]|0xff000000));
 GameSession session;CHECK(session.init("assets/levels/levels.index","tidal-trouble",&state));CHECK(session.restart());CHECK(session.game().lives()==5);
 WrinklyCave cave;CHECK(cave.init());frame.resize(512*448);cave.render(frame.data(),512,448);auto first=hashFrame(frame.data(),frame.size());CHECK(saveBmp32("docs/sprites-wrinkly.bmp",frame.data(),512,448));cave.step(.19f);cave.render(frame.data(),512,448);CHECK(hashFrame(frame.data(),frame.size())!=first);
 CHECK(!pack.load("assets/sprites/does-not-exist"));CHECK(pack.animations().empty());
 std::cout<<"SUPPLIED_SPRITES_OK 29 animations, 254 frames, alpha, foot anchors, KONG/Kobble binding, swim, game-over/restart, animated NPC\n";
}
