#include "core/Game.h"
#include "core/RomMotion.h"
#include <cmath>
#include <iostream>
using namespace dkc3;
#define CHECK(x) do {if(!(x)){std::cerr<<"motion check failed line "<<__LINE__<<": "<<#x<<"\n";return 1;}}while(0)
int main(){
  // Exact C73A boundaries: feet 8px below water are dry; 9..20 are surface.
  CHECK(romWaterState(664,672)==RomWaterState::Dry);
  CHECK(romWaterState(664,673)==RomWaterState::Surface);
  CHECK(romWaterState(664,684)==RomWaterState::Surface);
  CHECK(romWaterState(664,685)==RomWaterState::Underwater);
  CHECK(romWaterState(0xffff,1000)==RomWaterState::Dry);
  // Independent instruction-level branch oracle over every possible foot word.
  for(unsigned foot=0;foot<65536;++foot){
    unsigned a=(664-foot)&0xffff;
    const bool underwater=((a+20)&0xffff)>=32768;
    const bool dry=((a+8)&0xffff)<32768;
    CHECK(romWaterState(664,static_cast<uint16_t>(foot))==(underwater?RomWaterState::Underwater:(dry?RomWaterState::Dry:RomWaterState::Surface)));
  }
  RomMotionProfile dixie,kiddy;
  CHECK(loadRomMotionProfiles("rom/dkc3_ptbr.sfc",dixie,kiddy));
  CHECK(dixie.sourceAddress==0xff1840u&&kiddy.sourceAddress==0xff1842u);
  CHECK(dixie.risingGravity==0x5a&&dixie.fallingGravity==0x70&&dixie.terminalSpeed==0x800&&dixie.jumpImpulse==-0x700);
  CHECK(dixie.walkSpeed==0x240&&kiddy.walkSpeed==0x200&&dixie.runSpeed==0x300&&kiddy.runSpeed==0x300);
  CHECK(romHorizontalTarget(dixie,0,false,true)==0x240);
  CHECK(romHorizontalTarget(kiddy,0,true,false)==-0x200);
  CHECK(romHorizontalTarget(dixie,4,false,true)==0x300);
  CHECK(romHorizontalTarget(dixie,4,true,false)==-0x300);
  CHECK(romHorizontalTarget(dixie,4,true,true)==0x300);
  CHECK(romHorizontalTarget(dixie,4,false,false)==0);
  CHECK(dixie.swimGravity==10&&dixie.swimTerminalSpeed==288&&kiddy.swimTerminalSpeed==288);
  CHECK(kiddy.risingGravity==0x5a&&kiddy.fallingGravity==0x70&&kiddy.jumpImpulse==-0x700);
  CHECK(!loadRomMotionProfiles("missing.sfc",dixie,kiddy)&&!dixie.valid&&!kiddy.valid);
  CHECK(loadRomMotionProfiles("rom/dkc3_ptbr.sfc",dixie,kiddy));
  CHECK(romGravityStep(-1792,90,2048)==-1702);
  CHECK(romGravityStep(-22,90,2048)==68);
  CHECK(romGravityStep(2000,112,2048)==2048);
  CHECK(romGravityStep(32760,112,2048)==-32664); // original 16-bit ADC wrap
  CHECK(romInterpolateSpeed(0,640,3)==20);
  CHECK(romInterpolateSpeed(0,-640,3)==-20);
  CHECK(romInterpolateSpeed(639,640,3)==640);
  CHECK(romInterpolateSpeed(-639,-640,3)==-640);
  CHECK(romInterpolateSpeed(100,0,7)==94);
  CHECK(romInterpolateSpeed(-100,0,7)==-94);
  CHECK(romInterpolateSpeed(32767,-32768,3)==-32768);
  CHECK(romInterpolateSpeed(-32768,0,3)==31744);
  // Entry from a terminal dry fall must use the original positive swim limit.
  Player fast;fast.nativeMotion=dixie;fast.vel.y=480;fast.pos={100,375};InputState surface;surface.up=surface.jump=true;
  updateSwimPlayer(fast,surface,1.f/60,nullptr,0);
  CHECK(fast.vel.y<67.5f&&fast.pos.y<377);
  Rect floor{0,300,3000,32};InputState none,jump,right;jump.jump=true;right.right=true;right.run=true;
  Player p;p.nativeMotion=dixie;p.pos={100,266};p.grounded=true;p.motion=PlayerMotion::Ground;
  updatePlayer(p,jump,1.0f/60,nullptr,0,&floor,1);
  CHECK(p.justJumped&&!p.grounded);CHECK(std::fabs(p.vel.y-(-1702.0f*60/256))<0.0001f);
  CHECK(p.coyoteTimer==0&&p.jumpBuffer==0);
  int jumps=1;for(int i=0;i<240;++i){updatePlayer(p,jump,1.0f/60,nullptr,0,&floor,1);jumps+=p.justJumped;}
  CHECK(jumps==1&&p.grounded);
  updatePlayer(p,none,1.0f/60,nullptr,0,&floor,1);updatePlayer(p,jump,1.0f/60,nullptr,0,&floor,1);CHECK(p.justJumped);
  Player a,b;a.nativeMotion=dixie;a.pos={100,266};a.grounded=true;a.motion=PlayerMotion::Ground;b=a;
  for(int i=0;i<60;++i)updatePlayer(a,right,1.0f/60,nullptr,0,&floor,1);
  for(int i=0;i<30;++i)updatePlayer(b,right,1.0f/30,nullptr,0,&floor,1);
  CHECK(std::fabs(a.pos.x-b.pos.x)<0.001f&&std::fabs(a.vel.x-b.vel.x)<0.001f);
  Player c;c.nativeMotion=dixie;c.pos={100,266};c.grounded=true;c.motion=PlayerMotion::Ground;
  updatePlayer(c,jump,1.0f/240,nullptr,0,&floor,1);CHECK(!c.justJumped);
  for(int i=0;i<3;++i)updatePlayer(c,none,1.0f/240,nullptr,0,&floor,1);
  CHECK(c.justJumped&&!c.grounded); // short input survives until the next native tick
  // Original Y/run flag is applied AFTER direction lookup, so it affects the next tick.
  Player run;run.nativeMotion=dixie;run.pos={100,266};run.grounded=true;run.motion=PlayerMotion::Ground;
  updatePlayer(run,right,1.0f/60,nullptr,0,&floor,1);
  CHECK(run.nativeControlFlags==4&&std::fabs(run.vel.x-36.0f*60/256)<0.001f);
  updatePlayer(run,right,1.0f/60,nullptr,0,&floor,1);
  CHECK(std::fabs(run.vel.x-81.0f*60/256)<0.001f);
  for(int i=0;i<300;++i)updatePlayer(run,right,1.0f/60,nullptr,0,&floor,1);
  CHECK(std::fabs(run.vel.x-180.0f)<0.001f);
  InputState walk;walk.right=true;
  for(int i=0;i<300;++i)updatePlayer(run,walk,1.0f/60,nullptr,0,&floor,1);
  CHECK(std::fabs(run.vel.x-135.0f)<0.001f&&run.nativeControlFlags==0);
  run.nativeMotion=kiddy;
  for(int i=0;i<300;++i)updatePlayer(run,walk,1.0f/60,nullptr,0,&floor,1);
  CHECK(std::fabs(run.vel.x-120.0f)<0.001f);
  for(int i=0;i<300;++i)updatePlayer(run,none,1.0f/60,nullptr,0,&floor,1);
  CHECK(run.vel.x==0.0f);
  Player held,released;held.nativeMotion=dixie;held.pos={100,266};held.grounded=true;held.motion=PlayerMotion::Ground;released=held;
  updatePlayer(held,jump,1.0f/60,nullptr,0,&floor,1);updatePlayer(released,jump,1.0f/60,nullptr,0,&floor,1);
  updatePlayer(held,jump,1.0f/60,nullptr,0,&floor,1);updatePlayer(released,none,1.0f/60,nullptr,0,&floor,1);
  CHECK(held.nativeGravity==0x5a&&released.nativeGravity==0x70);
  CHECK(held.vel.y<released.vel.y);
  updatePlayer(released,jump,1.0f/60,nullptr,0,&floor,1);
  CHECK(!released.justJumped&&released.nativeGravity==0x70);
  Player both;both.nativeMotion=dixie;both.pos={100,266};both.grounded=true;both.motion=PlayerMotion::Ground;
  InputState lr;lr.left=lr.right=true;updatePlayer(both,lr,1.0f/60,nullptr,0,&floor,1);
  CHECK(both.facingRight&&both.vel.x>0.0f);
  Game game;CHECK(game.init("assets/levels/lakeside-limbo/lakeside-limbo.level"));
  CHECK(game.player().nativeMotion.valid&&game.player().nativeMotion.sourceAddress==0xff1840u);
  InputState change;change.switchCharacter=true;game.step(change,1.0f/60);
  CHECK(game.player().nativeMotion.sourceAddress==0xff1842u);
  Game legacy;CHECK(legacy.init("tests/data/flat-test.level"));CHECK(!legacy.player().nativeMotion.valid);
  std::cout<<"NATIVE_MOTION_OK ROM walk/run, gravity release, input order, boundaries, fixed tick, character switch\n";
}
