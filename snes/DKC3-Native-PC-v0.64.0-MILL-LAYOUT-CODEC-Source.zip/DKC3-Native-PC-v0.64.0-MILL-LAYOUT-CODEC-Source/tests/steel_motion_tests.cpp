#include "core/RomSteelKeg.h"
#include "core/RomControl.h"
#include "core/CarryBarrel.h"
#include "core/Game.h"
#include <iostream>
#include <cmath>
using namespace dkc3;
#define CHECK(x) do{if(!(x)){std::cerr<<"STEEL_MOTION_FAIL "<<__LINE__<<'\n';return 1;}}while(0)
int main(){
 RomImage rom;CHECK(rom.load("rom/dkc3_ptbr.sfc"));RomSpawnSpec child;CHECK(readRomPlacementType(rom,0x468,child));
 RomSteelProfile p;CHECK(loadRomSteelProfile(rom,child,p));CHECK(p.source==0xff1dd4&&p.gravity==0x70&&p.terminal==0x800&&p.interpolation==8);
 const uint8_t gravityBytes[]={0xa6,0x70,0xa0,0x00,0x00,0xb7,0x6a,0xa0,0x02,0x00,0x18,0x75,0x2e,0x30,0x06,0xd7,0x6a,0x90,0x02,0xb7,0x6a,0x95,0x2e,0x60};
 const uint8_t mode8Bytes[]={0x4a,0x4a,0x4a,0x4a,0x85,0x42,0x4a,0x4a,0x18,0x65,0x42,0x60};
 for(size_t i=0;i<sizeof gravityBytes;++i)CHECK(rom.bytes()[0x39ee78+i]==gravityBytes[i]);
 for(size_t i=0;i<sizeof mode8Bytes;++i)CHECK(rom.bytes()[0x39f54f+i]==mode8Bytes[i]);
 for(const char* path:{"assets/levels/lakeside-limbo/lakeside-limbo.level","assets/levels/tidal-trouble/tidal-trouble.level"}){
  Game game;CHECK(game.init(path));CHECK(game.barrelRespawners().size()==1);
  auto& camera=const_cast<Camera&>(game.camera());camera.x=game.barrelRespawners()[0].feet.x-128;
  game.step({},1.f/60);game.step({},1.f/60);auto index=game.barrelRespawners()[0].current;CHECK(index>=0);
  CHECK(game.teamBarrels()[index].steelProfile.valid&&game.teamBarrels()[index].steelProfile.source==p.source);
 }
 // Explicit host shield-contact fixture; gold replays never inject coordinates.
 {Game game;CHECK(game.init("assets/levels/lakeside-limbo/lakeside-limbo.level"));
  auto& camera=const_cast<Camera&>(game.camera());camera.x=2200;game.step({},1.f/60);game.step({},1.f/60);
  auto index=game.barrelRespawners()[0].current;CHECK(index>=0);auto feet=game.koins()[0].feet;
  auto& kong=const_cast<Player&>(game.player());kong.pos={feet.x+70,feet.y-kong.height};kong.vel={};kong.grounded=true;kong.motion=PlayerMotion::Ground;
  auto& keg=const_cast<RuntimeTeamBarrel&>(game.teamBarrels()[index]);keg.pos={feet.x+18,feet.y-keg.h};keg.velocity={-120,0};keg.steelTarget=0xfe00;keg.state=CarryBarrelState::Thrown;
  game.step({},1.f/60);CHECK(game.koins()[0].guardedHits==1&&!game.koins()[0].defeated);
  CHECK(keg.velocity.x==120&&keg.steelTarget==0x200);const auto x=keg.pos.x;
  for(int i=0;i<5;++i)game.step({},1.f/60);CHECK(keg.pos.x>x+5&&game.koins()[0].guardedHits==1);
 }
 RomSteelProfile bad;RomSpawnSpec empty;CHECK(!loadRomSteelProfile(rom,empty,bad)&&!bad.valid);
 for(unsigned word=0;word<65536;++word){
  unsigned sum=(word+0x70)&0xffff;CHECK(romSteelGravity(word,p)==((sum>=0x8000||sum<0x800)?sum:0x800));
  for(uint16_t target:{0u,0x200u,0xfe00u,0x8000u}){
   unsigned diff=(target-word)&65535;int sign=diff>=32768?-1:1;unsigned magnitude=sign<0?65536-diff:diff;
   unsigned delta=magnitude/16+magnitude/64;unsigned expect=delta?((int(word)+sign*int(delta))&65535):target;
   CHECK(romSteelInterpolate(word,target)==expect);
  }
 }
 CHECK(romSteelInterpolate(0,0x200)==40&&romSteelInterpolate(0,0xfe00)==uint16_t(-40));
 CHECK(romSteelGravity(0xff00,p)==0xff70&&romSteelGravity(0xff70,p)==0xffe0&&romSteelGravity(0xffe0,p)==0x50);
 CarryBarrelBody a;a.state=CarryBarrelState::Thrown;a.pos={300,0};a.velocity={0,-60};a.steelTarget=0x200;a.steelProfile=p;auto b=a;
 for(int i=0;i<120;++i)advanceSteelKeg(a,1.f/60,{}, {},nullptr,2000,2000);
 for(int i=0;i<60;++i)advanceSteelKeg(b,1.f/30,{}, {},nullptr,2000,2000);
 CHECK(std::fabs(a.pos.x-b.pos.x)<.001f&&std::fabs(a.pos.y-b.pos.y)<.001f);CHECK(a.velocity.x==120&&a.velocity.y==480);
 CarryBarrelBody native;native.state=CarryBarrelState::Dropped;native.pos={100,0};native.steelProfile=p;
 advanceSteelKeg(native,1.f/60,{}, {},nullptr,1000,1000);CHECK(native.velocity.y==26.25f);
 std::cout<<"STEEL_MOTION_OK ROM descriptor/profile; 65536 gravity and 262144 interpolation cases; split ticks; terminal 480; native acceleration\n";
}
