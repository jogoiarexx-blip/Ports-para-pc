#include "core/Player.h"
#include "core/RomTerrain.h"
#include <iostream>
#include <cmath>
#define CHECK(x) do{if(!(x)){std::cerr<<"GROUND_FOLLOW_FAIL "<<__LINE__<<" "<<#x<<"\n";return 1;}}while(0)
int main(){using namespace dkc3;
 CHECK(romGroundFollow(1,0,0x100).attach);CHECK(!romGroundFollow(2,0,0x100).attach);
 CHECK(romGroundFollow(4,3,0x100).attach);CHECK(!romGroundFollow(5,3,0x100).attach);
 CHECK(!romGroundFollow(1,3,0).attach);CHECK(romGroundFollow(4,7,0x1000).attach);
 auto excluded=romGroundFollow(1,0x1803,0x100);CHECK(!excluded.attach&&excluded.distance==0x8050);
 std::vector<uint8_t> map(64,0),defs(576,0),attrs(168,0);defs[4]=defs[6]=24;attrs[48]=2;map[16]=1;
 RomPierTerrain terrain;CHECK(terrain.load(map,defs,attrs,2));RomMotionProfile dixie,kiddy;CHECK(loadRomMotionProfiles("rom/dkc3_ptbr.sfc",dixie,kiddy));
 // A descent along the original half-slope, without repositioning between ticks.
 Player p;p.nativeMotion=dixie;p.height=10;p.pos={5,247};p.grounded=true;p.vel.x=-180;p.nativeControlFlags=4;
 InputState in;in.left=true;in.run=true;
 updatePlayer(p,in,1.f/60,nullptr,0,nullptr,0,&terrain);
 CHECK(p.pos.x==2&&p.grounded&&p.pos.y+p.height==259&&p.vel.y==0&&p.nativeGroundFollows==1);
 updatePlayer(p,in,1.f/60,nullptr,0,nullptr,0,&terrain);
 CHECK(p.pos.x<2&&p.grounded&&p.pos.y+p.height==260&&p.nativeGroundFollows==2);
 // Continue the descent, then check the mirrored ROM tile moving right.
 for(int i=0;i<2;++i){updatePlayer(p,in,1.f/60,nullptr,0,nullptr,0,&terrain);const auto floor=terrain.query(static_cast<uint16_t>(std::floor(p.pos.x+p.width/2)),static_cast<uint16_t>(p.pos.y+p.height+256)).surfaceY();CHECK(p.grounded&&p.pos.y+p.height==floor);}
 CHECK(p.nativeGroundFollows==4);
 map.assign(64,0);map[48]=1;map[49]=0x40;CHECK(terrain.load(map,defs,attrs,2));
 p={};p.nativeMotion=dixie;p.height=10;p.pos={23,247};p.grounded=true;p.vel.x=180;p.nativeControlFlags=4;in.left=false;in.right=true;
 updatePlayer(p,in,1.f/60,nullptr,0,nullptr,0,&terrain);CHECK(p.grounded&&p.pos.y+p.height==258&&p.nativeGroundFollows==1);
 updatePlayer(p,in,1.f/60,nullptr,0,nullptr,0,&terrain);CHECK(p.grounded&&p.pos.y+p.height==260&&p.nativeGroundFollows==2);
 // Grounded descent is bounded; a larger ledge releases into the air.
 defs[4]=defs[6]=8;map.assign(64,0);map[16]=1;CHECK(terrain.load(map,defs,attrs,2));
 p={};p.nativeMotion=dixie;p.height=10;p.pos={5,240};p.grounded=true;in={};
 updatePlayer(p,in,1.f/60,nullptr,0,nullptr,0,&terrain);CHECK(!p.grounded&&p.nativeGroundFollows==0&&p.vel.y>0);
 // Flat one-pixel gap follows, two-pixel gap falls.
 for(int gap:{1,2}){p={};p.nativeMotion=dixie;p.height=10;p.pos={5,static_cast<float>(275-gap)};p.grounded=true;
 updatePlayer(p,in,1.f/60,nullptr,0,nullptr,0,&terrain);CHECK(p.grounded==(gap==1));CHECK(p.nativeGroundFollows==(gap==1?1u:0u));}
 // An airborne player near a slope does not gain grounded-state snapping.
 defs[4]=defs[6]=24;CHECK(terrain.load(map,defs,attrs,2));p={};p.nativeMotion=dixie;p.height=10;p.pos={5,245};p.vel.y=0;
 updatePlayer(p,in,1.f/60,nullptr,0,nullptr,0,&terrain);CHECK(!p.grounded&&p.nativeGroundFollows==0);
 // Jump edge must detach even when starting grounded on a slope.
 p={};p.nativeMotion=dixie;p.height=10;p.pos={5,247};p.grounded=true;in.jump=true;
 updatePlayer(p,in,1.f/60,nullptr,0,nullptr,0,&terrain);CHECK(!p.grounded&&p.vel.y<0&&p.nativeGroundFollows==0);
 // Unsupported or rope shape cannot become a following floor.
 for(int shape:{64,99}){defs[4]=defs[6]=static_cast<uint8_t>(shape);CHECK(terrain.load(map,defs,attrs,2));p={};p.nativeMotion=dixie;p.height=10;p.pos={5,262};p.grounded=true;in={};updatePlayer(p,in,1.f/60,nullptr,0,nullptr,0,&terrain);CHECK(!p.grounded&&p.nativeGroundFollows==0);}
 std::cout<<"NATIVE_GROUND_FOLLOW_OK slope descent, bounded flat/slope gaps, ledge release, air/jump/rope exclusion\n";
}
