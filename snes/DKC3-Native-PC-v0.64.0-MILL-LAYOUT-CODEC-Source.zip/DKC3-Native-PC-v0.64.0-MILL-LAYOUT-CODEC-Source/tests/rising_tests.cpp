#include "core/Player.h"
#include "core/RomTerrain.h"
#include <iostream>
#define CHECK(x) do{if(!(x)){std::cerr<<"RISING_FAIL "<<__LINE__<<" "<<#x<<"\n";return 1;}}while(0)
int main(){using namespace dkc3;
  auto r=romRisingCollision(0xffff,0,0xaaaa,0,0,0x1234);CHECK(r.position==1&&r.velocity==0&&r.flags==0x1235&&r.attributes==8);
  r=romRisingCollision(500,600,0x8003,700,4,0);CHECK(r.position==600&&r.attributes==0x800b);
  r=romRisingCollision(500,0,4,700,3,0);CHECK(r.position==700&&r.attributes==11);
  std::vector<uint8_t> map(32,0),defs(576,0),attrs(168,0);map[12]=1;map[18]=2;defs[4]=defs[6]=1;defs[8]=defs[10]=3;
  RomPierTerrain terrain;CHECK(terrain.load(map,defs,attrs,1));
  RomMotionProfile dixie,kiddy;CHECK(loadRomMotionProfiles("rom/dkc3_ptbr.sfc",dixie,kiddy));
  Player p;p.nativeMotion=dixie;p.pos={4,226};p.height=10;p.vel.y=-420;p.nativeGravity=90;InputState in;in.jump=true;
  updatePlayer(p,in,1.0f/60.0f,nullptr,0,nullptr,0,&terrain);
  CHECK(p.nativeCeilingHits==1&&p.pos.y==225&&p.vel.y==0&&!p.jumping&&!p.grounded);
  CHECK(p.nativeTerrainFlags==1&&p.nativeTerrainAttributes==8);
  in.jump=false;for(int i=0;i<90;++i)updatePlayer(p,in,1.0f/60.0f,nullptr,0,nullptr,0,&terrain);
  CHECK(p.grounded&&p.pos.y+p.height==297&&p.nativeCeilingHits==1);
  // Rope descriptor is not a solid roof.
  defs[4]=defs[6]=64;defs[5]=defs[7]=64;CHECK(terrain.load(map,defs,attrs,1));
  p={};p.nativeMotion=dixie;p.pos={4,226};p.height=10;p.vel.y=-420;p.nativeGravity=90;in.jump=true;
  updatePlayer(p,in,1.0f/60.0f,nullptr,0,nullptr,0,&terrain);CHECK(p.nativeCeilingHits==0&&p.pos.y<225);
  // Conditional slope ceiling uses the ROM A4/A6 result.
  defs[4]=defs[6]=75;defs[5]=defs[7]=0;CHECK(terrain.load(map,defs,attrs,1));
  p={};p.nativeMotion=dixie;p.pos={0,225};p.width=2;p.height=10;p.vel.y=-420;p.nativeGravity=90;
  updatePlayer(p,in,1.0f/60.0f,nullptr,0,nullptr,0,&terrain);
  CHECK(p.nativeCeilingHits==1&&p.pos.y==224&&p.nativeTerrainAttributes==11);
  std::cout<<"NATIVE_RISING_COLLISION_OK flat roof, ROM slope ceiling, rope exclusion, stop/fall/land\n";
}
