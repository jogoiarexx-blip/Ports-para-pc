#include "core/RomSteelKeg.h"
#include "core/Game.h"
#include <iostream>
#include <cmath>
using namespace dkc3;
#define CHECK(x) do{if(!(x)){std::cerr<<"STEEL_STATE_FAIL "<<__LINE__<<'\n';return 1;}}while(0)
int main(){
 RomImage rom;CHECK(rom.load("rom/dkc3_ptbr.sfc"));
 const uint8_t releaseBytes[]={0xa9,0x00,0xff,0x95,0x2e,0xa9,0x00,0x02,0x34,0x58,0x50,0x04,0x49,0xff,0xff,0x1a,0x95,0x2a,0x95,0x30,0x74,0x28};
 const uint8_t wallBytes[]={0xa6,0x70,0xb5,0x1e,0x49,0x00,0x40,0x95,0x1e,0xa5,0xae,0x49,0xff,0xff,0x1a,0x95,0x30,0xa5,0xb0,0x49,0xff,0xff,0x1a,0x95,0x2a,0xdc,0xf5,0x04};
 for(size_t i=0;i<sizeof releaseBytes;++i)CHECK(rom.bytes()[0x3ed960+i]==releaseBytes[i]);
 for(size_t i=0;i<sizeof wallBytes;++i)CHECK(rom.bytes()[0x3ed781+i]==wallBytes[i]);

 for(unsigned direction=0;direction<65536;++direction){auto v=romSteelRelease(direction,0xa123);
  CHECK(v.x==((direction&0x4000)?0xfe00:0x0200));CHECK(v.target==v.x&&v.y==0xff00&&v.terrain==0&&v.oam==0xa123);}
 for(unsigned word=0;word<65536;++word)for(uint16_t oam:{0u,0x4000u,0xa123u}){
  RomSteelVelocity v;v.oam=oam;v.y=0x8123;v.terrain=0x101;
  const auto target=uint16_t(word^0x72ab);romSteelWall(v,target,word);
  CHECK(v.x==uint16_t(0u-word)&&v.target==uint16_t(0u-target));CHECK(v.oam==(oam^0x4000)&&v.y==0x8123&&v.terrain==0x101);
  romSteelWall(v,v.target,v.x);CHECK(v.x==word&&v.target==target&&v.oam==oam);
 }
 // Explicit native integration fixture: pickup/release through inputs, both directions.
 for(bool right:{false,true}){
  Game g;CHECK(g.init("assets/levels/lakeside-limbo/lakeside-limbo.level"));
  auto& camera=const_cast<Camera&>(g.camera());camera.x=2200;g.step({},1.f/60);g.step({},1.f/60);
  auto index=g.barrelRespawners()[0].current;CHECK(index>=0);
  auto& b=const_cast<RuntimeTeamBarrel&>(g.teamBarrels()[index]);b.state=CarryBarrelState::Resting;b.pos={2400,333};
  auto& p=const_cast<Player&>(g.player());p.pos={2400,323};p.vel={};p.grounded=true;p.motion=PlayerMotion::Ground;p.facingRight=right;
  InputState held;held.attack=true;g.step(held,0);CHECK(g.carryingBarrel());g.step({},0);
  CHECK(!g.carryingBarrel()&&b.state==CarryBarrelState::Thrown);
  CHECK(b.velocity.x==(right?120.f:-120.f)&&b.velocity.y==-60.f);CHECK(b.steelTarget==(right?0x0200:0xfe00));
 }
 std::cout<<"STEEL_STATE_OK 65536 release flags; 196608 wall words/OAM; double bounce; live input release both directions\n";
}
