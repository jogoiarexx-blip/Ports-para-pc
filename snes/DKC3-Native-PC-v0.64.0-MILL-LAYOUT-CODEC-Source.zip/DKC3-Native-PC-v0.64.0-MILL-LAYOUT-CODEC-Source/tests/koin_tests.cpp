#include "core/Game.h"
#include "core/Bmp.h"
#include "core/NativeReplay.h"
#include <iostream>
#include <cmath>
using namespace dkc3;
#define CHECK(x) do{if(!(x)){std::cerr<<"KOIN_FAIL "<<__LINE__<<" "<<#x<<'\n';return 1;}}while(0)
int main(){
 for(unsigned delta=0;delta<65536;++delta)for(uint16_t terrain:{0u,1u,0x101u})for(uint16_t oam:{0u,0x4000u}){
  const uint16_t ky=1000,by=uint16_t(ky-delta);const auto result=romKoinSteelHit(1000,ky,980,by,oam,terrain,0x211,0x2dcd);
  if(terrain!=0x101&&((delta-20)&0x8000)==0)CHECK(result==RomKoinHit::TooHigh);
  else CHECK(result==(oam?RomKoinHit::Guarded:RomKoinHit::Defeat));
 }
 CHECK(romKoinSteelHit(1000,1000,1020,1000,0,0,0x211,0x2dcd)==RomKoinHit::Guarded);
 CHECK(romKoinSteelHit(1000,1000,1020,1000,0,0,0,0x2df5)==RomKoinHit::Defeat);
 RomImage aimRom;CHECK(aimRom.load("rom/dkc3_ptbr.sfc"));RomKoinAimProfile aim;
 CHECK(loadRomKoinAimProfile(aimRom,aim)&&aim.valid);
 CHECK(aim.source[0]==0xb6a718&&aim.source[1]==0xb6a727);
 CHECK(romKoinAimGraphic(80,0,aim)==0x2dcd&&romKoinAimGraphic(0,80,aim)==0x2df5&&romKoinAimGraphic(80,80,aim)==0x2de1);
 CHECK(romKoinAimGraphic(0,0,aim)==0x2df5); // FFFF quotient INC wraps to zero.
 CHECK(romKoinAimGraphic(80,0,RomKoinAimProfile{})==0);
 auto varied=aim;varied.graphics[0][0]=0x2dd2;
 CHECK(romKoinAimGraphic(80,0,varied)==0x2dd2); // Uses loaded profile, no hardcoded pose.
 for(unsigned dx=0;dx<256;++dx)for(unsigned dy=0;dy<256;++dy){
   const unsigned axis=dy<dx?0:1;const unsigned divisor=(axis?dy:dx)&255;
   const uint16_t dividend=uint16_t((axis?dx:dy)<<8);
   const uint16_t increment=uint16_t((divisor?dividend/divisor:0xffff)+1);
   const unsigned ratio=std::min(255u,unsigned(increment));
   uint16_t expected=0;
   for(unsigned row=0;row<5;++row){const auto at=(aim.source[axis]&0x3fffff)+row*3;
     if(ratio<=aimRom.bytes()[at]){expected=aimRom.bytes()[at+1]|(uint16_t(aimRom.bytes()[at+2])<<8);break;}}
   CHECK(romKoinAimGraphic(uint16_t(dx),uint16_t(dy),aim)==expected);
 }

 // Fixtures alter private ROM copies, never the supplied file or a gold replay.
 {
   auto moved=aimRom;auto& data=const_cast<std::vector<uint8_t>&>(moved.bytes());
   for(unsigned axis=0;axis<2;++axis){
     const size_t from=aim.source[axis]&0x3fffff,to=0x36f800+axis*16;
     for(unsigned i=0;i<15;++i)data[to+i]=data[from+i];
     const size_t operand=axis?0x36a6f3:0x36a6db;data[operand+1]=axis?0x10:0;data[operand+2]=0xf8;
   }
   RomKoinAimProfile relocated;CHECK(loadRomKoinAimProfile(moved,relocated));
   CHECK(relocated.source[0]==0xb6f800&&relocated.source[1]==0xb6f810);
   CHECK(romKoinAimGraphic(80,0,relocated)==romKoinAimGraphic(80,0,aim));
 }
 for(unsigned fixture=0;fixture<5;++fixture){
   auto bad=aimRom;auto& data=const_cast<std::vector<uint8_t>&>(bad.bytes());
   if(fixture==0)data[0x36a6db]=0xa9; // Not LDY.w.
   if(fixture==1)data[0x36a718+12]=0xfe; // Missing final FF threshold.
   if(fixture==2)data[0x36a718+3]=0x30; // Decreasing threshold.
   if(fixture==3)data[0x36a719]=data[0x36a71a]=0; // Invalid graphic.
   if(fixture==4){data[0x36a6dc]=0xf8;data[0x36a6dd]=0xff;} // Bank overflow.
   RomKoinAimProfile rejected=aim;CHECK(!loadRomKoinAimProfile(bad,rejected)&&!rejected.valid);
 }
 std::array<uint8_t,32> flags{};flags.fill(0xaa);
 for(uint16_t level=0x25;level<0xa5;++level){auto f=flags;CHECK(setRomKoinProgress(f,level,1));CHECK(romKoinProgress(f,level)==1);
  for(uint16_t other=0x25;other<0xa5;++other)if(other!=level)CHECK(romKoinProgress(f,other)==2);}
 CHECK(!setRomKoinProgress(flags,0x24,1)&&!setRomKoinProgress(flags,0xa5,1)&&!setRomKoinProgress(flags,0x25,3));
 // Steel integrator: floor landing, wall ricochet, no break, fixed-tick split dt.
 CarryBarrelBody a,b;a.pos={30,60};a.w=a.h=28;a.velocity={120,100};a.state=CarryBarrelState::Thrown;b=a;
 unsigned walls=0;for(int i=0;i<100;++i)walls+=advanceSteelKeg(a,1.f/60,{{160,0,16,200}},{{0,160,512,1}},nullptr,512,256).wall;
 for(int i=0;i<50;++i)advanceSteelKeg(b,1.f/30,{{160,0,16,200}},{{0,160,512,1}},nullptr,512,256);
 CHECK(walls>0&&a.state==CarryBarrelState::Thrown);CHECK(std::fabs(a.pos.x-b.pos.x)<.001f&&std::fabs(a.pos.y-b.pos.y)<.001f);
 CHECK(std::fabs(a.pos.y+a.h-160)<.001f);
 Game g;CHECK(g.init("assets/levels/lakeside-limbo/lakeside-limbo.level"));CHECK(g.barrelRespawners().size()==1);CHECK(g.koins()[0].aimProfile.valid);
 CHECK(g.barrelRespawners()[0].child.spriteId==0x2d4&&g.barrelRespawners()[0].type==0x468);
 // Unit fixtures explicitly position actors/camera. Input gold tests do not.
 auto& camera=const_cast<Camera&>(g.camera());camera.x=2000;
 auto& p=const_cast<Player&>(g.player());p.pos={2090,323};p.vel={};p.grounded=true;p.motion=PlayerMotion::Ground;
 g.step({},1.f/60);g.step({},1.f/60);CHECK(g.barrelRespawners()[0].spawns==1);
 const int index=g.barrelRespawners()[0].current;CHECK(index>=0&&g.teamBarrels()[index].steel&&!g.teamBarrels()[index].rescuesPartner);
 const auto feet=g.koins()[0].feet;
 auto& barrel=const_cast<RuntimeTeamBarrel&>(g.teamBarrels()[index]);barrel.pos={feet.x-38,feet.y-28};barrel.velocity={280,0};barrel.state=CarryBarrelState::Thrown;
 g.step({},1.f/60);CHECK(g.koins()[0].defeated&&romKoinProgress(g.persistentState().koinFlags,0x25)==1&&g.dkCoins()==0);
 auto released=g.persistentState();Game restored;CHECK(restored.init("assets/levels/lakeside-limbo/lakeside-limbo.level",&released));CHECK(restored.koins()[0].defeated&&!restored.koins()[0].coinCollected);
 for(int i=0;i<35;++i)g.step({},1.f/60);
 {std::vector<uint32_t> picture(256*224);camera.x=feet.x-128;camera.y=feet.y-160;g.render(picture.data(),256,224);CHECK(saveBmp32("docs/dk-coin-released-v055.bmp",picture.data(),256,224));}
 const auto coin=g.koins()[0].coinPos;p.pos={coin.x-p.width/2,coin.y-p.height/2};p.vel={};g.step({},1.f/60);
 CHECK(g.dkCoins()==1&&romKoinProgress(g.persistentState().koinFlags,0x25)==2);
 for(int i=0;i<20;++i)g.step({},1.f/60);CHECK(g.dkCoins()==1);
 auto paid=g.persistentState();Game repeat;CHECK(repeat.init("assets/levels/lakeside-limbo/lakeside-limbo.level",&paid));CHECK(repeat.koins()[0].coinCollected&&repeat.dkCoins()==1);
 std::vector<uint32_t> image(256*224);camera.x=feet.x-128;camera.y=feet.y-160;g.render(image.data(),256,224);CHECK(saveBmp32("docs/dk-coin-v055.bmp",image.data(),256,224));
 NativeReplay replay;std::string error;CHECK(replay.load("tests/replays/lakeside-koin-v057.txt",error));
 Game input;CHECK(input.init("assets/levels/lakeside-limbo/lakeside-limbo.level"));
 for(size_t i=0;i<replay.count();++i){input.step(nativeInputFromSnes(replay.frame(i)),1.f/60);CHECK(input.lives()==5);}
 CHECK(input.dkCoins()==1&&input.bonusCoins()==1&&input.koins()[0].defeated&&input.koins()[0].coinCollected);
 CHECK(romKoinProgress(input.persistentState().koinFlags,0x25)==2);
 GamePersistentState inputPaid;inputPaid.dkCoins=1;setRomKoinProgress(inputPaid.koinFlags,0x25,2);
 Game inputAgain;CHECK(inputAgain.init("assets/levels/lakeside-limbo/lakeside-limbo.level",&inputPaid));
 for(size_t i=0;i<replay.count();++i)inputAgain.step(nativeInputFromSnes(replay.frame(i)),1.f/60);
 CHECK(inputAgain.dkCoins()==1&&inputAgain.bonusCoins()==1&&inputAgain.lives()==5);
 std::cout<<"KOIN_INPUT_OK frames="<<replay.count()<<" bonus1=50 dk_coins=1 lives=5 no position injection; ends at coin\n";
 std::cout<<"KOIN_OK ROM pointer aim profile; 65536 aim pairs; 393216 hit cases; packed neighbor preservation; steel floor/ricochet/dt; ROM generator; defeat/release/collect/reload/no duplicate\n";
}
