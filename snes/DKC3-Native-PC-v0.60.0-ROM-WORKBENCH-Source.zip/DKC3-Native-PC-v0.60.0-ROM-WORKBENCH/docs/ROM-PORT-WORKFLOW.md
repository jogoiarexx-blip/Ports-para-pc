# Leitura da ROM e aplicação no port — v0.60.0

Este fluxo é operado pelo Codex durante a manutenção. O usuário não precisa
executar a ferramenta ou estudar assembly. Python é ferramenta de desenvolvimento;
o jogo continua C++ nativo e não depende dela para jogar.

## Problema e mudança

O catálogo anterior mostrava nomes e intervalos. Era necessário procurar manualmente
as chamadas, acompanhar tabelas, reencontrar os endereços nos bancos ASM e relacionar
isso ao C++ em cada port. `rom_workbench.py` reutiliza esse catálogo e acrescenta
limites de instruções ligados ao SHA256 da ROM, referências de controle, dispatch
com linhas verificadas e relatórios com os pontos correspondentes do código nativo.

O índice tem 100.597 limites de instruções, 23.427 símbolos, 21.642 referências de
controle e 278 tabelas de dispatch verificadas. Inclui a tabela Kong de 120 estados
em B8:A191, stride 4, usada pelo salto B8:9F4D. Os flags e destinos de cada linha
foram comparados à ROM. A validação de limite do índice de estado e a tradução
completa de cada handler continuam pendentes.

217 anotações não foram aceitas: divergências opcode/mnemonic, aliases não
normalizados e um limite sobreposto. Elas ficam registradas como questões no índice;
não se conclui que todas são bugs da fonte. Nenhuma foi usada como limite de código
validado. O índice não contém texto assembly ou bytes da ROM. Os operandos exibidos
vêm sempre do arquivo ROM atual, incluindo o efeito de REP/SEP e tamanhos variáveis.

## Sequência de trabalho do Codex

1. Buscar nome/endereço e gerar relatório da rotina. Escolher explicitamente o
   intervalo quando a entrada catalogada for apenas parte de um handler.
2. Examinar referências, tabelas, contexto M/X, DBR/direct page e efeitos de flags.
   Catálogo, limite de instrução e comentários C++ não provam fidelidade.
3. Ler os payloads das tabelas separadamente; dados não devem virar instruções.
   O comando `table` exige largura/quantidade explícitas, não adivinha estruturas.
4. Portar a operação para C++ e carregar os perfis pelos ponteiros da ROM.
5. Comparar casos de fronteira/overflow e testar o efeito no runtime. Executar
   os replays por input afetados e manter status PARTIAL/UNKNOWN quando necessário.
6. Regenerar o relatório relevante e atualizar a evidência da mudança. Em alteração
   da ROM, reconstruir o índice; SHA256 divergente interrompe a análise.

## Comandos de manutenção (não exigidos do usuário)

Executar da raiz do projeto; somente biblioteca padrão Python 3.9+.

```text
python tools/rom_workbench.py search kong_state
python tools/rom_workbench.py report B8:9F3A --end B8:9F50
python tools/rom_workbench.py report B6:A6C4 --end B6:A718 --json
python tools/rom_workbench.py table B6:A718 --width 3 --count 5
python tools/rom_workbench.py packet controller --output docs/ROM-CONTROLLER-PACKET.md
python tools/rom_workbench.py packet tidal --output docs/ROM-TIDAL-PACKET.md
python tests/tools/test_rom_workbench.py
```

Os packets controller/steel/koin/tidal já estão no pacote. KONG-STATE-INDEX.csv
lista todos os estados e flags, com port_status UNREVIEWED. Isso evita confundir
uma tabela localizada com controlador concluído. O packet Tidal inclui os audits
atuais dos 61 placements e dos dois bônus, sem inventar handlers ausentes.

Para regenerar usando a fonte externa revisada:

```text
python tools/rom_workbench.py index --asm-dir CAMINHO_DISASSEMBLY --output tools/reference/rom-analysis-index.json.gz
```

O índice guarda hashes dos bancos consultados e da ROM. A fonte externa é a
referência DKC3-Disassembly já mencionada em THIRD-PARTY-NOTICES.txt; ela não é
redistribuída. O catálogo DKC3Recomp mantém sua identidade/commit original.

## Segurança da leitura

- ROM HiROM de 4 MiB, com suporte a header copier de 512 bytes.
- Endereços RAM/IO não são aceitos como endereços ROM; espelhos HiROM tratados.
- M/X desconhecido interrompe instruções de tamanho variável sem evidência.
- Chamadas, branches e restauração de flags não preservam M/X por suposição.
- Listagem linear não é execução simbólica nem análise de todos os caminhos.
- Contratos indiretos conservam seus limites: RAM/estado e bounds precisam de revisão.
- Uma menção no C++ é exibida como pista, nunca como porcentagem implementada.

## Primeira aplicação real

Koin agora usa `RomKoinAimProfile`. B6:A6DB e B6:A6F3 fornecem os ponteiros das
tabelas de cinco linhas {limiar byte, graphic word}. O runtime lê limites e gráficos
da ROM, sem copiar esses valores para arrays constantes. A divisão/XBA/INC/clamp
permanece uma tradução C++ direta. Não se emula o registrador de divisão da CPU.

O teste verifica 65.536 pares de mira, relocação das tabelas por ponteiros, rejeição
de perfil inválido e replays existentes. Perfil inválido falha no carregamento.
Koin continua PARTIAL: colisões, voo da moeda e estados completos ainda faltam.

## Medição

No ambiente Linux desta entrega, carregar catálogo/índice, validar a ROM e gerar
um relatório de 38 instruções levou mediana de aproximadamente 138 ms em cinco
medições. Detalhes em ROM-ANALYSIS-RESULTS.json. Não é uma medição de ganho percentual
na velocidade de tradução; o ganho pretendido é reduzir pesquisa e conferência
repetidas. A tradução semântica e os testes ainda precisam ser feitos.
