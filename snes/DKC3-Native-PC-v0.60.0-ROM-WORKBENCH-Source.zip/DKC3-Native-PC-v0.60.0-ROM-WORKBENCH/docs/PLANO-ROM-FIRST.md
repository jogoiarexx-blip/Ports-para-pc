# Criterios ainda abertos — v0.60.0

PIER atende Lakeside $25/0, Tidal $27/2 e salas Lakeside $50/3, $51/4, Tidal $54/5, $55/6.
Requests desconhecidos falham; $198D/$1998/$19DA nao possuem decoder ainda.

1. Completar os 47 handlers PARTIAL de Lakeside e abrir os 34 UNKNOWN de Tidal.
2. Completar controlador/probes originais e retirar adapters, incluindo nado,
   carga, animais, cordas e transicoes; triggers fiéis de checkpoint/bandeira.
3. Adicionar Warp ao replay combinado Lakeside. Ambos bonus + checkpoint +
   saida, DK Coin e Ellie/Bear Coin passam num unico percurso de 6848 frames,
   com duas Bonus Coins e cinco vidas. G fica no replay separado; KONG falta.
4. Integrar destinos/canhoes e objetivos por input de Tidal. Cenarios $54/5
   e $55/6 agora carregam pelo pipeline generico; jogo dos bonus ainda falta.
5. Cordas verticais/sliding/regrab; flutuacao/rolagem/bounce e poses dos barris.
6. Skidda, Murky e Belcha; mapa original E9:26FB e musica/SFX nativos.

Resultados atuais: SPAWN-AND-LAKESIDE.md e VALIDACAO-v0.60.0.txt.
Nao considerar as duas fases completas enquanto os criterios acima faltarem.

Booty Bird agora libera G/N; o percurso lakeside-bird cobre G e ambos bonus.
A patrulha, colisao e morte do passaro continuam parciais; Ellie agora tem caixa/montaria/placa parcial; estados completos ainda faltam.

A rota lakeside-ellie cobre ambos bonus, caixa, montaria, placa, Bear Coin e
saida em 4802 frames. Warp, KONG completo e bonus Tidal continuam abertos.

Steel keg/DK Coin possuem runtime parcial e replay ate a moeda (1903 frames).
DK Coin + ambos bonus + Ellie + saida agora cobertos em 6848 frames.
Warp no percurso unico e controlador completo continuam abertos.

Fluxo para acelerar cada port: ROM-PORT-WORKFLOW.md e packets de analise.
Tabela dos 120 estados Kong localizada/verificada; traducao ainda pendente.
Mira Koin agora le perfil pelos ponteiros da ROM; handler continua PARTIAL.
