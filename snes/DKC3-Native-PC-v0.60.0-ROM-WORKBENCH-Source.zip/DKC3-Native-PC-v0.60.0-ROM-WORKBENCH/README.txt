DKC3 Native PC v0.60.0 - Leitura de ROM para acelerar o port

NOVIDADES
- Workbench estatico usado pelo Codex: bytes/operandos da ROM, chamadas,
  tabelas, widths M/X e pistas no C++. O usuario nao precisa operar a ferramenta.
- Indice: 100597 limites de instrucoes, 21642 referencias de controle,
  278 tabelas de dispatch; tabela dos 120 estados Kong verificada na ROM.
  Indexar estados nao significa que o controlador ja foi portado.
- Packets de controlador, steel, Koin e Tidal; 217 anotacoes nao aceitas ficam
  isoladas. SHA256 divergente interrompe analise; nenhuma execucao CPU/PPU.
- Aplicado ao runtime: mira Koin carrega limites/graficos pelos ponteiros
  originais, com validacao e 65536 pares de mira. Koin continua PARTIAL.
- Testes: 29 suites nativas e 8 testes Python da ferramenta.
- Novo bot lakeside-extended: DK Coin, Bonus 1/50 estrelas, Bonus 2/15 bananas,
  recuperacao do parceiro pelo segundo Floating DK Barrel, Ellie/Bear Coin,
  checkpoint e saida num unico replay de 6848 frames. Cinco vidas em cada frame.
- Repeticao com DK Coin e Bonus Coins ja pagas nao duplica moedas.
- Carregador PIER le placements pela tabela original FE:0000 e terminador,
  sem intervalos/counts por fase. Header da ROM valida ID/shared_data/submapa.
- Salas Tidal $54/5 e $55/6 agora carregam graficos, terreno e 3/7 placements.
  Mapas sem piso sao validos; objetivos/canhoes dessas salas ainda faltam.
- Aco na agua: B9:EC09..EC3B reduz temporariamente as velocidades usadas
  no terreno para um quarto; conserva ASL/ROR, limite +16 e restauracao.
- Movimento submerso usa a resposta traduzida, sem acumular drag permanente.
  Colisao/posicao/agua profunda e estados de riding ainda sao parciais.
- Steel keg le FF:1DD4 pelo ponteiro do descriptor: gravidade $0070,
  terminal $0800 e interpolacao 8. Traduz B9:EE78 e B9:F54F em palavras.
  O runtime do aco usa esses parametros; colisao/posicao/agua continuam host.
- Steel keg: lancamento usa BE:D960..D974, velocidade assinada 8.8
  $0200/$FE00 horizontal e $FF00 vertical (120/-120 e -60 px/s).
- Ricochete usa BE:D781..D798: inverte velocidade/alvo anteriores e bit
  $4000 de OAM, incluindo wrap de palavra. Colisao/fisica ainda host.
- $0170 corrigido: gerador de steel keg, nao DK Barrel. Tipo filho $0468
  e timer extraidos da ROM; barril de aco $02D4 nao restaura o parceiro.
- Steel keg: carregar, arremessar, colocar no chao, rolar e rebater paredes.
  Graficos da ROM; integrador fisico host, estados originais ainda parciais.
- Koin: predicado original de impacto de aco, altura, lado e escudo elevado;
  nove poses de mira e escudos da ROM. Liberacao/contato da moeda ainda host.
- DK Coin: progresso original de dois bits por fase, sem duplicar recompensa.
  Save V8 grava contador e flags; formatos V1..V7 continuam aceitos.
- Bot lakeside-koin: spawn, Bonus 1 e DK Coin em 1903 frames, cinco vidas,
  somente input. Termina na moeda; a rota extended junta Bonus 2 e saida. Warp ainda falta.
- $0160: retangulo da ROM, contato com barris, operacao de byte BB:DE63 e
  efeito ao ativar. Estado Kong $4F e consumidores da RAM original pendentes.
- $0138: ciclo de ativacao/desativacao com aritmetica original do timer.
  Janela de camera e reativacao host; grupos/tabelas de placement pendentes.
- Replays atuais: ambos bonus 4942 frames; com G 4897 frames.
  Bot busca a letra liberada antes de prosseguir; nenhum ajuste de posicao.
- Caixa Ellie $0250: quebra por pisao/rolamento/barril; espera original de
  cinco ticks antes de liberar o animal, com protecao contra duplicacao.
- Ellie: quatro frames idle e 14 de caminhada extraidos da ROM; velocidades
  walk/run/jump selecionadas pelos offsets originais do tipo $0234.
- Placa $0258: limites de contato e offsets originais; remove Ellie e libera
  Bear Coin uma vez. Montaria por Up/aterrissagem; baixo+troca desmonta.
- Bot lakeside-ellie: ambos bonus, caixa, montaria, placa, Bear Coin,
  checkpoint e saida em 4802 frames, cinco vidas, somente input.
- Ellie ainda usa adapters de colisao, nado, entrada/saida e animacao.
  Medo de Sneek, tromba/agua, barris pela tromba e estados completos pendentes.
- A placa Enguarde de Tidal aparece, mas seu animal ainda nao foi portado.
- Spawn Script: F9 chama o script-base e continua; a ultima escrita determina
  o SpriteID. F5 continua; parametros herdados, animacao, estados e movimento
  relativo F4 ficam disponiveis para o runtime. Ciclos/truncamentos falham.
- Dois Floating DK Barrels de Lakeside e tres de Tidal passam a existir.
- Tres barris comuns de Lakeside podem ser carregados, lancados e quebrados;
  usam oito frames da folha fornecida e nunca restauram o parceiro.
- Booty Bird $0434 nas duas fases: oito frames extraidos da ROM, recompensa
  FF:257C, G de Lakeside/N de Tidal por golpe, pisao ou barril. Letra ja
  coletada vira banana; entrega unica. Patrulha/colisao/morte ainda parciais.
- Novo percurso lakeside-bird: ambos bonus, G do passaro, checkpoint e saida
  em 4897 frames, cinco vidas mantidas, sem injetar posicao. Nao completa KONG.
- Resposta de entrada na agua usa gravidade/limite da tabela original: evita
  manter a velocidade de queda seca e atravessar o fundo apos um bonus.
- Probe original de agua B8:C73A traduzido e verificado em 65536 coordenadas.
  O estado original e registrado separadamente; o movimento de nado continua
  parcial. Nao combinamos esse probe com metade da maquina de estados.
- Novo bot e replay combinado: spawn -> Bonus 1 (50 estrelas) -> retorno ->
  checkpoint -> Bonus 2 (15 bananas) -> retorno -> saida. 4942 frames, duas
  Bonus Coins, cinco vidas mantidas, nenhum ajuste de posicao/velocidade.
- Reexecutar o percurso com as moedas ja premiadas nao duplica recompensas.
- Bot tambem atravessa Tidal por input. Isso nao conclui seus bonus/objetos.
- Sprites Dixie DKC2 e Kremlings Unused continuam excluidos. Logos/titulo/
  Game Over da versao anterior permanecem integrados.

CONTROLES
SHIFT/ombro direito: correr sem pegar/rolar. X: segurar para carregar; soltar
para lancar; baixo+X coloca no chao. Apenas DK Barrel restaura o parceiro.
Leia COMO-USAR-BARRIS.txt, COMO-USAR-CAVERNA.txt e COMO-USAR-AS-CORDAS.txt.

WINDOWS
BUILD-WINDOWS.cmd requer Visual Studio 2022 C++ e CMake. Compila jogo,
29 suites, bot, headless, replay e auditor; roda CTest e monta ZIP portatil.
VERIFY-BONUSES.cmd verifica os bonus separados e o percurso combinado.
Este pacote contem fontes/assets. EXE Windows nao foi compilado/validado aqui.

LIMITES
- Lakeside: 47 placements identificados, 47 PARTIAL, 0 UNKNOWN, 0 SUPPORTED.
  Todos possuem handlers parciais; fidelidade completa ainda nao foi demonstrada.
- Tidal: 61 placements, 27 PARTIAL, 34 UNKNOWN. Bonus, destinos de canhoes
  e boa parte dos inimigos/peixes continuam pendentes.
- Replay combinado ainda nao cobre Warp Barrel. Bandeira/checkpoint usam
  triggers amplos; o teste nao prova fidelidade completa desses objetos.
- Controlador original completo, probes corporais, estados de nado/animacao,
  cordas verticais/sliding/regrab e rotina SNES completa dos barris pendentes.
- Os barris usam velocidades host; flutuacao original dos DK ainda falta.
- Skidda/Murky/Belcha, mapa original e musica/SFX originais ainda pendentes.

VALIDACAO
29 suites Linux/GCC C++20 -O2, bot e sessao headless.
80000 casos da corda; 20000 da aterrissagem; 65536 do probe de agua.
Resultados: docs/VALIDACAO-v0.60.0.txt. Detalhes: docs/SPAWN-AND-LAKESIDE.md.

Manutencao da ROM: docs/ROM-PORT-WORKFLOW.md. Python nao e dependencia do jogo.
