@echo off
setlocal
cd /d "%~dp0"
where cmake >nul 2>nul || (echo ERRO: CMake nao encontrado.& pause & exit /b 1)
cmake -S . -B build-win -G "Visual Studio 17 2022" -A x64 || goto :err
cmake --build build-win --config Release --target DKC3NativePC dkc3_native_core_tests dkc3_native_frontend_tests dkc3_native_worldmap_tests dkc3_native_rom_tests dkc3_native_motion_tests dkc3_native_terrain_tests dkc3_native_rising_tests dkc3_native_wall_tests dkc3_native_air_wall_tests dkc3_native_ground_follow_tests dkc3_native_boat_tests dkc3_native_recomp_bridge_tests dkc3_native_rope_tests dkc3_native_rom_runtime_tests dkc3_native_rom_audit dkc3_native_wrinkly_tests dkc3_native_supplied_sprites_tests dkc3_native_carry_barrel_tests dkc3_native_stages_tests dkc3_native_bonus_input_tests dkc3_native_ground_attach_tests dkc3_native_spawn_script_tests dkc3_native_lakeside_combined_input_tests dkc3_native_booty_bird_tests dkc3_native_animal_runtime_tests dkc3_native_control_tests dkc3_native_koin_tests dkc3_native_steel_state_tests dkc3_native_steel_motion_tests dkc3_native_steel_water_tests dkc3_native_route_bot dkc3_native_headless dkc3_native_replay || goto :err
ctest --test-dir build-win -C Release --output-on-failure || goto :err
if exist bin rmdir /S /Q bin
mkdir bin
mkdir bin\rom
copy /Y build-win\Release\DKC3NativePC.exe bin\DKC3NativePC.exe >nul
copy /Y build-win\Release\dkc3_native_replay.exe bin\dkc3_native_replay.exe >nul
xcopy /E /I /Y assets bin\assets >nul
if exist bin\assets\levels\tidal-trouble\native\pages rmdir /S /Q bin\assets\levels\tidal-trouble\native\pages
if exist bin\assets\sprites\dkc3\import-preview.png del /Q bin\assets\sprites\dkc3\import-preview.png
for /R bin\assets %%F in (*_preview.bmp) do del /Q "%%F"
if exist bin\assets\levels\original_metadata rmdir /S /Q bin\assets\levels\original_metadata
copy /Y rom\dkc3_ptbr.sfc bin\rom\dkc3_ptbr.sfc >nul
copy /Y RUN-WINDOWS.cmd bin\RUN-WINDOWS.cmd >nul
copy /Y VERIFY-ROM-FIRST-RUNTIME.cmd bin\VERIFY-ROM-FIRST-RUNTIME.cmd >nul
copy /Y ROM-FIRST-README.txt bin\ROM-FIRST-README.txt >nul
copy /Y VERSION.txt bin\VERSION.txt >nul
copy /Y COMO-USAR-BARRIS.txt bin\COMO-USAR-BARRIS.txt >nul
copy /Y COMO-USAR-DK-COIN.txt bin\COMO-USAR-DK-COIN.txt >nul
copy /Y COMO-USAR-ELLIE.txt bin\COMO-USAR-ELLIE.txt >nul
copy /Y COMO-USAR-CAVERNA.txt bin\COMO-USAR-CAVERNA.txt >nul
copy /Y THIRD-PARTY-NOTICES.txt bin\THIRD-PARTY-NOTICES.txt >nul
call bin\VERIFY-ROM-FIRST-RUNTIME.cmd || goto :err
powershell -NoProfile -ExecutionPolicy Bypass -Command "Compress-Archive -Path 'bin\*' -DestinationPath 'DKC3-Native-PC-v0.60.0-ROM-WORKBENCH-Portable-Windows-x64.zip' -Force" || goto :err
echo.
echo OK: bin\DKC3NativePC.exe
echo OK: DKC3-Native-PC-v0.60.0-ROM-WORKBENCH-Portable-Windows-x64.zip
pause
exit /b 0
:err
echo.
echo FALHA NO BUILD ROM-FIRST.
pause
exit /b 1
