#include "core/RomObjectRuntime.h"
#include <iostream>
int main(int argc,char** argv){
  dkc3::RomLevelRuntime level;
  dkc3::RomLevelRequest request{};
  if(argc>2){
    const std::string name=argv[2];
    if(name=="tidal")request={0x27,0x19f0,2};
    else if(name=="lakeside-bonus1")request={0x50,0x19f0,3};
    else if(name=="lakeside-bonus2")request={0x51,0x19f0,4};
    else if(name=="tidal-bonus1")request={0x54,0x19f0,5};
    else if(name=="tidal-bonus2")request={0x55,0x19f0,6};
    else if(name!="lakeside"){std::cerr<<"Level must be lakeside, tidal, lakeside-bonus1/2 or tidal-bonus1/2\n";return 2;}
  }
  if(!level.load(request,argc>1?argv[1]:"rom/dkc3_ptbr.sfc")){
    std::cerr<<"ROM level load failed: "<<level.error()<<"\n";return 1;}
  dkc3::RomSpawnRuntime spawn;spawn.build(level.placements());
  std::cout<<spawn.report();return 0;
}
