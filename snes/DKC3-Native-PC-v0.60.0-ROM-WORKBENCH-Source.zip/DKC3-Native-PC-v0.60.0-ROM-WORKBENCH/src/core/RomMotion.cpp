#include "RomMotion.h"
#include "RomData.h"
namespace dkc3 {
namespace {
int16_t signedWord(uint16_t v){return static_cast<int16_t>(v<0x8000u?static_cast<int>(v):static_cast<int>(v)-65536);}
}
RomWaterState romWaterState(uint16_t waterY,uint16_t feetY){
  if(waterY&0x8000u)return RomWaterState::Dry;
  const uint16_t delta=static_cast<uint16_t>(waterY-feetY);
  // CMP branches on N, not N xor V: preserve the actual word subtraction.
  if(static_cast<uint16_t>(delta-0xffecu)&0x8000u)return RomWaterState::Underwater;
  if(!(static_cast<uint16_t>(delta-0xfff8u)&0x8000u))return RomWaterState::Dry;
  return RomWaterState::Surface;
}
int16_t romGravityStep(int16_t velocity,int16_t gravity,int16_t limit){
  const auto sum=signedWord(static_cast<uint16_t>(static_cast<int>(velocity)+gravity));
  return sum<0||static_cast<uint16_t>(sum)<static_cast<uint16_t>(limit)?sum:limit;
}
int16_t romInterpolateSpeed(int16_t velocity,int16_t target,uint16_t mode){
  // Both paths preserve the original word-sized difference, logical shifts,
  // negation and zero-result snap. No CPU instruction interpreter is involved.
  if(mode!=3u&&mode!=7u&&mode!=11u)return velocity;
  const auto diff=signedWord(static_cast<uint16_t>(static_cast<int>(target)-velocity));
  const uint16_t magnitude=diff<0?static_cast<uint16_t>(-static_cast<int>(diff)):static_cast<uint16_t>(diff);
  const uint16_t delta=magnitude>>(mode==3u?5u:(mode==7u?4u:3u));
  if(!delta)return target;
  return signedWord(static_cast<uint16_t>(static_cast<int>(velocity)+(diff<0?-static_cast<int>(delta):static_cast<int>(delta))));
}
int16_t romHorizontalTarget(const RomMotionProfile& profile,uint16_t controlFlags,bool left,bool right){
  if(!profile.valid||(!left&&!right))return 0;
  const int16_t speed=(controlFlags&4u)?profile.runSpeed:profile.walkSpeed;
  // B8:CD13 checks right ($0100) before falling through to the left table.
  return right?speed:signedWord(static_cast<uint16_t>(-static_cast<int>(speed)));
}
bool loadRomMotionProfiles(const std::string& path,RomMotionProfile& dixie,RomMotionProfile& kiddy){
  dixie={};kiddy={};RomImage rom;if(!rom.load(path)||rom.info().crc32!=0x448eec19u)return false;
  const auto& b=rom.bytes();
  // B8:9CE8 is LDA.l dixie_kong_constants. Read its long operand, rather
  // than copying the gravity/jump values from the disassembly into the host.
  constexpr size_t operand=0x389ce8u;
  if(b.size()<=operand+3u||b[operand]!=0xafu)return false;
  const uint32_t addr=b[operand+1u]|(uint32_t(b[operand+2u])<<8u)|(uint32_t(b[operand+3u])<<16u);
  if((addr>>16u)!=0xffu)return false;
  const size_t base=addr&0x3fffffu;if(base+0x23au+2u>b.size())return false;
  const auto word=[&](size_t off){return static_cast<uint16_t>(b[base+off]|(uint16_t(b[base+off+1u])<<8u));};
  for(unsigned character=0;character<2;++character){
    auto& p=character?kiddy:dixie;const size_t col=character*2u;
    // Original dry-floor response indexes B9:F126 with attributes & 7.
    for(size_t i=0;i<8;++i)p.terrainLandingSpeeds[i]=signedWord(static_cast<uint16_t>(b[0x39f126+i*2]|(uint16_t(b[0x39f127+i*2])<<8)));
    p.sourceAddress=addr+static_cast<uint32_t>(col);
    p.fallingGravity=signedWord(word(col));p.risingGravity=signedWord(word(0x10u+col));
    p.terminalSpeed=signedWord(word(0x08u+col));
    // B8:D8AF -> B8:9071 (unladen jump) adds $0100 before gravity.
    p.jumpImpulse=signedWord(static_cast<uint16_t>(word(0x30u+col)+0x100u));
    p.groundInterpolation=word(0xc8u+col);p.airInterpolation=word(0xd0u+col);
    p.swimGravity=signedWord(word(0x228u+col));p.swimTerminalSpeed=signedWord(word(0x230u+col));
    p.walkSpeed=signedWord(word(0xa0u+col));p.runSpeed=signedWord(word(0xb0u+col));
    p.valid=p.fallingGravity>0&&p.risingGravity>0&&p.terminalSpeed>0&&p.jumpImpulse<0&&p.groundInterpolation==7u&&p.airInterpolation==3u&&p.walkSpeed>0&&p.runSpeed>=p.walkSpeed;
    if(!p.valid){dixie={};kiddy={};return false;}
  }
  return true;
}
}
