#include "RomTerrain.h"
#include <algorithm>
namespace dkc3 {
RomTerrainSample romPierTerrainSample(uint16_t tile,uint16_t left,uint16_t right,uint16_t localX,uint16_t queryY){
  RomTerrainSample result;
  if(tile==0||(tile&0x3fff)>=144)return result;
  unsigned x=localX&31u;
  if(tile&0x4000)x^=31u;
  uint16_t descriptor=(x&16u)?right:left;
  if(descriptor&0x8000)x^=15u;
  result.attributes=descriptor^((tile&0x4000)?0x8000:0);
  x&=15u;
  const unsigned shape=descriptor&255u;
  int height=-1;
  if(shape>=1&&shape<=8)height=35-static_cast<int>(shape)*4;
  else if(shape>=18&&shape<=24)height=static_cast<int>(x/2u)+static_cast<int>(shape-18u)*4;
  else if(shape==0)height=-1;
  else if(shape==64){height=15;result.attributes|=0x0800;}
  else if(shape==75){height=(((static_cast<unsigned>(queryY)-1u)&31u)^31u)>=x?31:-1;}
  else if(shape==77)height=((static_cast<unsigned>(queryY)-1u)&31u)<16u?31:-1; // B7:D183 flat conditional ceiling
  else if(shape==76)height=(((static_cast<unsigned>(queryY)-1u)&31u)^31u)>=x+16u?31:-1;
  else result.supported=false;
  result.height=static_cast<int16_t>(std::min(height,31));
  return result;
}
bool buildRomPierSurfaces(const std::vector<uint8_t>& level,const std::vector<uint8_t>& defs,int columns,int rows,std::vector<RomTerrainSurface>& out){
  out.clear();
  if(columns<=0||rows<=0||level.size()<static_cast<size_t>(columns)*static_cast<size_t>(rows)*2u||defs.size()!=576u)return false;
  auto word=[](const std::vector<uint8_t>& v,size_t off){return static_cast<uint16_t>(v[off]|(static_cast<uint16_t>(v[off+1])<<8));};
  // Build per-pixel surface runs; never infer terrain from image opacity.
  for(int row=0;row<rows;++row){
    for(int column=0;column<columns;++column){
      const uint16_t tile=word(level,(static_cast<size_t>(column)*static_cast<size_t>(rows)+static_cast<size_t>(row))*2u);
      const unsigned id=tile&0x3fff;
      if(id==0||id>=144u)continue;
      const uint16_t left=word(defs,id*4u),right=word(defs,id*4u+2u);
      for(int px=0;px<32;++px){
        auto sample=romPierTerrainSample(tile,left,right,static_cast<uint16_t>(px));
        if(!sample.supported)return false;
        // $40 is rope; $4B/$4C set conditional ceilings, not a floor.
        if(sample.height<0||(sample.attributes&0x0800)||((sample.attributes&255u)==75u||(sample.attributes&255u)==76u||(sample.attributes&255u)==77u))continue;
        const int y=row*32+32-sample.height;
        const int x=column*32+px;
        if(!out.empty()&&out.back().y==y&&out.back().x+out.back().width==x)++out.back().width;
        else out.push_back({x,y,1,8});
      }
    }
  }
  // A valid submap may contain only water, ropes or decorative metatiles.
  // An empty floor list is distinct from malformed/unsupported terrain.
  return true;
}
}

namespace dkc3 {
bool RomPierTerrain::load(const std::vector<uint8_t>& level,const std::vector<uint8_t>& definitions,const std::vector<uint8_t>& attributeTable,int columns){
  columns_=0;ropes_.clear();level_.clear();definitions_.clear();attributeTable_.clear();
  if(columns<=0||level.size()<static_cast<size_t>(columns)*32u||definitions.size()!=576u||attributeTable.size()!=168u)return false;
  level_=level;definitions_=definitions;attributeTable_=attributeTable;columns_=columns;return buildRomPierRopes(level,definitions,columns,16,ropes_);
}
RomTerrainQuery RomPierTerrain::query(uint16_t worldX,uint16_t originalY) const{
  RomTerrainQuery r;
  if(columns_==0||worldX>=static_cast<unsigned>(columns_)*32u){r.supported=false;return r;}
  auto word=[](const std::vector<uint8_t>& v,size_t off){return static_cast<uint16_t>(v[off]|(static_cast<uint16_t>(v[off+1])<<8));};
  const int16_t relative=static_cast<int16_t>(static_cast<uint16_t>(originalY-0x100u));
  const unsigned py=static_cast<unsigned>(std::clamp(static_cast<int>(relative),0,511));
  uint16_t base=static_cast<uint16_t>((0u-py)&0x1e0u);
  unsigned row=(base^0x1e0u)/32u;
  uint16_t qy=originalY;
  auto evaluate=[&](unsigned at)->int{
    const size_t offset=(static_cast<size_t>(worldX/32u)*16u+at)*2u;
    if(offset==0)return -1; // CF68's TYX/BEQ at map offset zero.
    const uint16_t tile=word(level_,offset),id=tile&0x3fffu;
    if(id>=144u)return -1; // Original leaves A0 unchanged on decorative IDs.
    const uint16_t left=word(definitions_,id*4u),right=word(definitions_,id*4u+2u);
    const auto s=romPierTerrainSample(tile,left,right,worldX&31u,qy);
    r.supported=r.supported&&s.supported;r.attributes=s.attributes;
    const unsigned shape=s.attributes&255u;
    if(s.height>=0&&(shape==75u||shape==76u||shape==77u)){
      unsigned x=worldX&31u;if(tile&0x4000u)x^=31u;
      if(((x&16u)?right:left)&0x8000u)x^=15u;
      x=shape==77u?16u:(x&15u)+(shape==76u?16u:0u);
      r.ceiling=static_cast<uint16_t>(0x101u-(base|x));
      r.ceilingSlope=shape==77u?0u:static_cast<uint16_t>((s.attributes&0x8000u)|3u);
    }
    return s.height;
  };
  int height=evaluate(row);r.initialAttributes=r.attributes;
  uint16_t combined=0;
  if(height<0){
    qy=1;
    for(int n=0;n<2&&height<0;++n){
      if(++row>=16u){r.attributes=0;return r;}
      base=static_cast<uint16_t>(base-32u);height=evaluate(row);
    }
    if(height<0){r.attributes=0;return r;}
    combined=static_cast<uint16_t>(base|static_cast<unsigned>(height));
  }else if(height==31){
    if(row==0){height=31;combined=0x1ff;}
    else{
      const uint16_t previous=r.attributes;
      const int above=evaluate(row-1u);
      if(above>=0){height=above;combined=static_cast<uint16_t>(base+(static_cast<unsigned>(above)|32u));}
      else{r.attributes=previous;combined=static_cast<uint16_t>(base|31u);}
    }
  }else combined=static_cast<uint16_t>(base|static_cast<unsigned>(height));
  auto ropeFlag=[](uint16_t attributes){return static_cast<uint16_t>(static_cast<uint16_t>((attributes&0x7fffu)-0x4000u)<9u?attributes|0x2000u:attributes);};
  r.attributes=ropeFlag(r.attributes);
  const unsigned type=r.attributes&127u;
  if(type>=attributeTable_.size()/2u){r.supported=false;return r;}
  uint16_t slope=word(attributeTable_,type*2u)&0x801fu;
  if(height!=15)slope&=0x1fu;
  r.attributes=static_cast<uint16_t>((r.attributes&~127u)|slope);
  r.initialAttributes=ropeFlag(r.initialAttributes);
  if(r.ceiling)r.ceiling=static_cast<uint16_t>(r.ceiling+0x200u);
  if(combined==0x1ffu)combined=0x800u;
  r.encoded=static_cast<uint16_t>(combined+0x6000u);
  return r;
}
}

namespace dkc3 {
RomRisingCollision romRisingCollision(uint16_t position,uint16_t ceiling,uint16_t ceilingSlope,uint16_t nextCeiling,uint16_t nextSlope,uint16_t flags){
  RomRisingCollision r;
  if(ceiling){r.position=ceiling;r.attributes=ceilingSlope;}
  else{
    r.position=static_cast<uint16_t>((static_cast<uint16_t>(position+31u)&0xffe0u)+1u);
    r.attributes=nextSlope;
    if(nextCeiling)r.position=nextCeiling;
  }
  r.flags=flags|1u;r.attributes|=8u;return r;
}
}

namespace dkc3 {
RomWallCollision romWallCollision(uint16_t previousX,uint16_t previousY,uint16_t currentY,uint16_t target,uint16_t velocity,uint16_t flags,uint16_t queriedSurface){
  RomWallCollision r;r.x=previousX;r.y=currentY;r.savedTarget=target;r.savedVelocity=velocity;r.flags=flags|2u;
  // BPL tests the sign bit of the wrapped subtraction, not C++ ordering.
  if((r.flags&0x1000u)&&(static_cast<uint16_t>(queriedSurface-currentY)&0x8000u))r.y=previousY;
  return r;
}
}

namespace dkc3 {
bool RomPierTerrain::solidBodyPoint(int worldX,int worldY) const{
  if(columns_<=0||worldX<0||worldY<0||worldY>=512||worldX/32>=columns_)return false;
  auto word=[](const std::vector<uint8_t>& v,size_t off){return static_cast<uint16_t>(v[off]|(static_cast<uint16_t>(v[off+1])<<8));};
  const size_t offset=(static_cast<size_t>(worldX/32)*16u+static_cast<unsigned>(worldY/32))*2u;
  if(offset==0)return false;
  const auto tile=word(level_,offset);const unsigned id=tile&0x3fffu;
  if(id==0||id>=144u)return false;
  const auto sample=romPierTerrainSample(tile,word(definitions_,id*4u),word(definitions_,id*4u+2u),static_cast<uint16_t>(worldX&31),static_cast<uint16_t>(worldY+256));
  const unsigned shape=sample.attributes&255u;
  if(!sample.supported||sample.height<0||(sample.attributes&0x5800u)||shape==75u||shape==76u||shape==77u)return false;
  return (worldY&31)>=32-sample.height;
}
}

namespace dkc3 {
RomGroundFollow romGroundFollow(uint16_t distance,uint16_t attributes,uint16_t flags){
  RomGroundFollow r;r.distance=distance;
  if(attributes&0x1800u){r.distance=0x8050;return r;}
  if((flags&0x1100u)==0)return r;
  const uint16_t limit=(attributes&7u)?4u:1u;
  r.attach=distance<=limit;return r;
}
}

namespace dkc3 {
bool buildRomPierRopes(const std::vector<uint8_t>& level,const std::vector<uint8_t>& defs,int columns,int rows,std::vector<RomHorizontalRope>& out){
 out.clear();if(columns<=0||rows<=0||level.size()<static_cast<size_t>(columns)*static_cast<size_t>(rows)*2u||defs.size()!=576u)return false;
 const auto word=[](const std::vector<uint8_t>& v,size_t at){return static_cast<uint16_t>(v[at]|(static_cast<uint16_t>(v[at+1])<<8));};
 for(int row=0;row<rows;++row)for(int col=0;col<columns;++col){
  const auto tile=word(level,(static_cast<size_t>(col)*rows+row)*2u);const auto id=tile&0x3fffu;if(!id||id>=144u)continue;
  for(int px=0;px<32;++px){const auto q=romPierTerrainSample(tile,word(defs,id*4u),word(defs,id*4u+2u),static_cast<uint16_t>(px));
   if(!q.supported)continue;
   if(q.height<0||(q.attributes&0x0800u)==0)continue;
   const int x=col*32+px,y=row*32+32-q.height;
   if(!out.empty()&&out.back().y==y&&out.back().x+out.back().width==x)++out.back().width;
   else out.push_back({x,y,1});
  }
 }
 return true;
}
RomRopeClamp romHorizontalRopeClamp(uint16_t x,uint16_t fraction,uint16_t lower,uint16_t upper,uint16_t target,uint16_t velocity,uint16_t direction){
 RomRopeClamp r{x,fraction,target,velocity,direction,false};
 if(lower>=x){if(lower==x)return r;r.x=lower;r.direction=0xffffu;}
 else if(upper<x){r.x=upper;r.direction=1;}
 else return r;
 r.fraction=0;r.target=0;r.velocity=0;r.stopped=true;return r;
}
}

namespace dkc3 {
RomGroundAttach romDryGroundAttach(uint16_t surface,uint16_t attributes,uint16_t flags,const int16_t* velocityTable){
 return {surface,0,surface,0,static_cast<uint16_t>(flags|1u),velocityTable[attributes&7u]};
}
}
