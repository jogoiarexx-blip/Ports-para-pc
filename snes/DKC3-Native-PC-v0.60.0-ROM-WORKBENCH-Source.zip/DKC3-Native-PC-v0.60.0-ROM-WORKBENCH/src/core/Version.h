#pragma once
namespace dkc3 {
constexpr const char* kVersion = "0.50.0";
constexpr const char* kVersionName = "Lakeside Bonus Input and Frontend Flow";
}
