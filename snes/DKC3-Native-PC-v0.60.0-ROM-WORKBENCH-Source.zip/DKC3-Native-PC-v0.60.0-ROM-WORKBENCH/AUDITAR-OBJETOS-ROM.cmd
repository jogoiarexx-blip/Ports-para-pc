@echo off
setlocal
cd /d "%~dp0"
if not exist build-win\Release\dkc3_native_rom_audit.exe (
  echo Compile primeiro com BUILD-WINDOWS.cmd.
  pause
  exit /b 1
)
build-win\Release\dkc3_native_rom_audit.exe rom\dkc3_ptbr.sfc > docs\LAKESIDE-SPAWN-AUDIT.txt
if errorlevel 1 (
  echo Falha na auditoria.
  pause
  exit /b 1
)
build-win\Release\dkc3_native_rom_audit.exe rom\dkc3_ptbr.sfc tidal > docs\TIDAL-SPAWN-AUDIT.txt
if errorlevel 1 exit /b 1
type docs\LAKESIDE-SPAWN-AUDIT.txt
type docs\TIDAL-SPAWN-AUDIT.txt
pause
