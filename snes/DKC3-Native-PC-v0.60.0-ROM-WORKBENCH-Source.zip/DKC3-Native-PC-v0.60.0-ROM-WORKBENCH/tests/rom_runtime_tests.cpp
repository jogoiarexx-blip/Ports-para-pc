#include "core/RomObjectRuntime.h"
#include "core/Game.h"
#include <iostream>
using namespace dkc3;
int main(){
  RomLevelRuntime level;
  if(!level.load({0x25,0x19f0,0},"rom/dkc3_ptbr.sfc"))return 1;
  RomSpawnRuntime spawn;spawn.build(level.placements());
  if(spawn.records().size()!=47)return 2;
  for(size_t i=0;i<47;++i)if(spawn.records()[i].placementIndex!=i ||
     spawn.records()[i].placement.descriptor!=level.placements()[i].descriptor)return 3;
  if(spawn.count(RomSupport::Supported)+spawn.count(RomSupport::Partial)+spawn.count(RomSupport::Unknown)!=47)return 4;
  if(spawn.count(RomSupport::Partial)!=47 || spawn.count(RomSupport::Unknown)!=0 || spawn.count(RomSupport::Supported)!=0)return 14;
  RomLevelRuntime bonusRuntime;RomLakesideBonusVisuals bonus;
  for(int index=1;index<=2;++index){
    if(!bonusRuntime.load(RomLevelRequest{static_cast<uint16_t>(0x4f+index),0x19f0,static_cast<uint8_t>(2+index)},"rom/dkc3_ptbr.sfc") ||
       !bonus.load(index,"rom/dkc3_ptbr.sfc"))return 15;
    if(bonusRuntime.width()!=384 || bonusRuntime.pixels()!=bonus.pixels() ||
       bonusRuntime.foregroundMask()!=bonus.foregroundMask() || bonusRuntime.placements().size()!=static_cast<size_t>(index+1))return 16;
  }
  // Tidal's rooms use the same family codec and FE:0000 pointer table.
  for(int index=0;index<2;++index){
    if(!bonusRuntime.load(RomLevelRequest{static_cast<uint16_t>(0x54+index),0x19f0,static_cast<uint8_t>(5+index)}))return 28;
    if(bonusRuntime.height()!=512 || bonusRuntime.width()<=0 || bonusRuntime.pixels().empty() ||
       bonusRuntime.placements().size()!=size_t(index?7:3) || bonusRuntime.waterSurfaceY()!=408)return 29;
    if(bonusRuntime.startPoint()!=(index?std::pair(53,240):std::pair(32,480)))return 30;
  }
  if(bonusRuntime.load(RomLevelRequest{0x54,0x19f0,6}) || bonusRuntime.valid() || !bonusRuntime.pixels().empty())return 31;
  if(bonusRuntime.load(RomLevelRequest{512,0x19f0,5}) || bonusRuntime.load(RomLevelRequest{0x54,0x19f0,7}))return 32;
  RomImage rom;if(!rom.load("rom/dkc3_ptbr.sfc"))return 17;
  // Base-script calls return; the last FF assignment determines the actual type.
  RomSpawnSpec spec;
  for(uint16_t descriptor:{0x718a,0x719e}){
    if(!decodeRomSpawnScript(rom,descriptor,spec)||spec.spriteId!=0x02c4||spec.animationId!=0x015c)return 22;
  }
  if(!decodeRomSpawnScript(rom,0x719e,spec)||spec.word(0x44)!=0x00a0)return 23;
  if(!decodeRomSpawnScript(rom,0x959f,spec)||spec.spriteId!=0x0434||spec.animationId!=0x0277||spec.word(0x6c)!=2)return 24;
  if(!decodeRomSpawnScript(rom,0x9598,spec)||spec.spriteId!=0x0434||spec.word(0x6c)!=3)return 25;
  // F4 decodes signed speeds and relative limits using the placement origin.
  if(!decodeRomSpawnScript(rom,0x78ff,spec,848,585)||spec.spriteId!=0x02f8)return 26;
  if(spec.word(0x12)!=848||spec.word(0x16)!=585)return 27;
  std::vector<RomLevelPlacement> decoded;
  auto truncated=level.placementData();truncated.resize(7);
  if(decodeRomPlacements(rom,truncated,decoded) || !decoded.empty())return 18;
  auto unterminated=level.placementData();unterminated.resize(unterminated.size()-2);
  if(decodeRomPlacements(rom,unterminated,decoded) || !decoded.empty())return 19;
  if(!decodeRomPlacements(rom,level.placementData(),decoded) || decoded.size()!=47)return 20;
  Game game;if(!game.init("assets/levels/lakeside-limbo/lakeside-limbo.level"))return 5;
  if(game.romSpawnRuntime().records().size()!=47)return 6;
  if(!level.load({0x27,0x19f0,2},"rom/dkc3_ptbr.sfc") || !level.valid() ||
     level.width()!=7968 || level.height()!=512 || level.placements().size()!=61 || level.waterSurfaceY()!=408)return 7;
  if(level.load({0x27,0x19f0,0},"rom/dkc3_ptbr.sfc") || level.valid() || !level.pixels().empty())return 21;
  if(level.load({0x25,0x19f0,1},"rom/dkc3_ptbr.sfc"))return 8;
  if(level.load({0x25,0x1234,0},"rom/dkc3_ptbr.sfc"))return 9;
  if(!level.load({0x25,0x19f0,0},"rom/dkc3_ptbr.sfc"))return 10;
  spawn.build({});if(!spawn.records().empty())return 11;
  for(uint16_t family:{0x19f0,0x198d,0x1998,0x19da})if(!findRomScenarioCodec(family))return 12;
  if(findRomObject(0xffff).support!=RomSupport::Unknown)return 13;
  std::cout<<"ROM_RUNTIME_OK six PIER submaps; ROM placement pointers; request guards, reload, registry, game integration\n";
}
