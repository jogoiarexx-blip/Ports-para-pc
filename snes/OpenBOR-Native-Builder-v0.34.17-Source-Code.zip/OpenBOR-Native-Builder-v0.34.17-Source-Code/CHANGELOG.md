# v0.34.17 — fluxo de fase/cenas e semântica Build 3797

- Base integral preservada: v0.34.16.
- Runtime passa a executar `spawn`, `wait`, `group` e `blockade` na ordem original do arquivo de fase, inclusive quando os valores `at` não estão em ordem crescente.
- `next` de `levels.txt` cria limites de capítulo; HP é preservado entre partes do mesmo capítulo com recuperação legacy de +5 e volta ao máximo ao cruzar `next`.
- Cenas de `levels.txt` agora são ligadas corretamente antes/depois da fase e no encerramento; `skipone`, `noskip`, `music` e `silence` mantêm a ordem do arquivo de cena.
- `direction up/down` usa progresso vertical equivalente ao OpenBOR Build 3797 (~100 px/s) e movimenta o background repetido sem transformar o painel em scroll vertical.
- `canSave` de `levels.txt` agora é preservado e impede gravações quando vale 0; ao entrar em uma nova fase o save passa a registrar a fase nova, evitando Continue voltar para a etapa anterior.
- Spawn padrão P1–P4 segue o layout legacy (20/50/80/110 à direita e 300/270/240/210 à esquerda, Z = zmin+5); `spawn1..4` explícitos continuam tendo prioridade.
- Fases `direction left` iniciam a câmera no extremo direito do mapa e os jogadores entram virados para a esquerda.
- Regressão e runtime tests ampliados para cobrir campanhas, ordem de ações, cenas, capítulos, save e spawn/câmera legacy.

# v0.34.16 — flipping/pivô OpenBOR e comparação seletiva com port direto

- Base integral preservada: v0.34.15 (Unicode/PAKs antigos e melhorias anteriores).
- `flipframe` sem parâmetro agora segue a semântica legacy de `GET_INT_ARG(1)`: valor padrão 0, portanto vira no frame 0. Isso cobre 72 ocorrências reais no Final Fight X v1.0.0.
- O renderer agora mantém o pivô authored `offset X/Y` ao espelhar a sprite, inclusive com scale/flip/shift/rotate de `drawmethod`; antes a imagem podia deslocar enquanto bbox/attackbox permaneciam corretas.
- Regressão específica compara a sintaxe do Final Fight X e exige a fórmula de pivô espelhado no runtime gerado.
- Final Fight X validado com 99 modelos, 21 fases e 1106 animações: 15465 SUPPORTED / 0 PARTIAL / 0 UNSUPPORTED / 0 UNKNOWN; runtime compilado e smoke test exit 0.
- Política de evolução: comparar port direto, Builder e OpenBOR original por subsistema, promovendo ao Builder apenas comportamentos comprovadamente melhores e genéricos.

# v0.34.15 — Unicode e PAKs antigos

- Correção de conversões de caracteres em caminhos na análise, geração, relatórios, empacotamento e runtime.
- Caminhos UTF-8 explícitos e APIs/argumentos UTF-16 no Windows.
- Nomes e referências de PAKs Windows-1252 são decodificados consistentemente.
- CMake/PowerShell/tar iniciados diretamente, sem CMD interpretando nomes de arquivos.
- MSVC com /utf-8; novos testes de conversão/empacotamento e recursos Unicode.
- Base preservada: v0.34.14.

# v0.34.14 — Evil Dead: 362 UNKNOWN -> 0, 294/427 PARTIAL -> 9

- Auditoria genérica usando Evil Dead v1.4.0 como caso real, sem regras específicas por nome de jogo.
- Suporte ampliado para movimento, sombra, camadas, plataforma, câmera, remap, charge/rise invulnerability e comandos de animação legados.
- `blast` clássico + forma transitória de 10 parâmetros; `pbombframe`/`tossframe`; `throw` com distância/altura.
- `bglayer`/`fglayer` com parallax, repeat e alpha blend OpenBOR; `cameraoffset` aplicado à projeção nativa.
- Recuperação de remap por mesmo stem/única extensão alternativa suportada.
- Regressão 0 falhas; runtime completo do Evil Dead compilado e smoke test com exit code 0.
- Restam 9 PARTIAL exclusivamente por includes de bibliotecas externas ausentes do PAK original.

# v0.34.13 — Final Fight X: 139 UNKNOWN -> 0 e diagnóstico de inicialização Windows

- Final Fight X: 15465 SUPPORTED / 0 PARTIAL / 0 UNSUPPORTED / 0 UNKNOWN.
- Novo parsing/emissão para `makeinv`, `playshotno`, `grabback`, `grabfinish`, `throwframewait` e `fastattack`.
- Catálogo explícito de diretivas legadas de HUD/menu/levels; itens exclusivos do frontend antigo são `IGNORED_SAFELY`, não falsos `SUPPORTED`.
- Detector genérico para nome de modelo solto em arquivo de fase (linha malformada/no-op), cobrindo o `andore` perdido do Final Fight X sem hardcode do jogo.
- Runtime Windows passa a validar `assets/openbor-data`, fixar o diretório de trabalho e gravar `runtime-startup.log`.
- Falhas de inicialização mostram MessageBox no Windows e o launcher `INICIAR-PORT.cmd` mantém o código/log visível.
- Novo `COMPILAR-E-INICIAR-WINDOWS.cmd`.
- Regressão e 8 suítes de runtime verdes; Final Fight X headless exit 0.

# v0.34.11 — Final Fight X: 255 PARTIAL -> 47

- damageonlanding 0 1, aimove chase, indexed GIF palette/remap, platform parsing, scene e outras correções dirigidas pelo Final Fight X.

# v0.34.10 — redução de PARTIAL em @cmd e combate legado

- Resolução de helpers de animation script e melhorias em attackone/dropv.
