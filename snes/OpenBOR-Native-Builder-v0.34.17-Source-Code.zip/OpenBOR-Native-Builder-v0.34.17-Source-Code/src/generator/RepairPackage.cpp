#include "PathEncoding.hpp"
#include "RepairPackage.hpp"
#include <fstream>
#include <set>
namespace {
std::string escapeJson(const std::string& s) {
    std::string out;
    for (char c : s) {
        switch (c) {
            case '\\': out += "\\\\"; break;
            case '"': out += "\\\""; break;
            case '\n': out += "\\n"; break;
            case '\r': break;
            case '\t': out += "\\t"; break;
            default: out += c; break;
        }
    }
    return out;
}
}
void RepairPackage::generate(const ScanReport& scan, const CompatibilityReport& compatibility,
                             const std::filesystem::path& outDir) {
    const auto repair = outDir / "AI-Repair";
    std::filesystem::create_directories(repair / "original-sources");
    std::filesystem::create_directories(repair / "logs");
    std::set<std::filesystem::path> copied;
    for (const auto& issue : compatibility.issues) {
        if (!copied.insert(issue.file).second) continue;
        auto src = scan.root / issue.file;
        if (!std::filesystem::exists(src)) continue;
        auto dst = repair / "original-sources" / issue.file;
        std::filesystem::create_directories(dst.parent_path());
        std::filesystem::copy_file(src, dst, std::filesystem::copy_options::overwrite_existing);
    }
    std::ofstream json(repair / "issues.json");
    json << "{\n  \"source\": \"" << escapeJson(PathEncoding::utf8(scan.root)) << "\",\n  \"issues\": [\n";
    for (std::size_t i = 0; i < compatibility.issues.size(); ++i) {
        const auto& v = compatibility.issues[i];
        json << "    {\"level\":\"" << CompatibilityAnalyzer::levelName(v.level)
             << "\",\"file\":\"" << escapeJson(PathEncoding::utf8(v.file))
             << "\",\"line\":" << v.line
             << ",\"command\":\"" << escapeJson(v.command)
             << "\",\"message\":\"" << escapeJson(v.message) << "\"}";
        if (i + 1 != compatibility.issues.size()) json << ',';
        json << "\n";
    }
    json << "  ]\n}\n";
    std::ofstream md(repair / "README-AI-REPAIR.md");
    md << "# AI Repair Package\n\nPacote gerado pelo OpenBOR Native Builder. Use `issues.json` para localizar incompatibilidades.\n\n"
          "## Fluxo sugerido\n\n1. Corrigir itens RED primeiro.\n2. Adaptar itens YELLOW.\n3. Recompilar o runtime.\n4. Rodar testes e anexar `runtime.log`.\n5. Incorporar correcoes genericas ao conversor.\n";
    std::ofstream log(repair / "logs" / "runtime.log");
    log << "Runtime log placeholder. The generated native runtime will write diagnostics here.\n";
}
